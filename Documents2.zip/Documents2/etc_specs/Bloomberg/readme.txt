To decrypt a file do the following:

1)	Download the encrypted file, let's call it encrypt.out
2)	Download the appropriate version of the encryption
	software based on your operating system. Be sure to
	download the file in binary mode.
3)	To decrypt the file, type the following:

		des -D -u -k "memememe" encrypt.out anyname.out

    	Where:	des		is the name of the software (this example
				uses the name of the software for Windows
			 	'95 or Windows NT;

		"memememe"	is the encryption key used. The same
				key is used to decrypt the file. The key
				must be in double quotes.

		encrypt.out	is an example name for a downloaded encrypted 
				sample file
			

		anyname.out	is an example name for the new file where the 
				decrypted, or clear data, will be redirected to.

4)	You can now read the decrypted, or clear, file.

