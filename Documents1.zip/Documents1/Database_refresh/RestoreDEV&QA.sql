-- Refresh.sql

/*

USE Research
GO

EXEC sp_addrolemember @rolename = 'db_owner', @membername = 'ac\fusillofp'
EXEC sp_addrolemember @rolename = 'db_owner', @membername = 'ac\fusillofp_dev'
EXEC sp_addrolemember @rolename = 'db_owner', @membername = 'ac\kjosyu'
EXEC sp_addrolemember @rolename = 'db_owner', @membername = 'ac\nharja'
EXEC sp_addrolemember @rolename = 'db_owner', @membername = 'ac\ssures1'
EXEC sp_addrolemember @rolename = 'db_owner', @membername = 'ac\asingh13'
*/

USE Research
GO

select * from Configuration

-- RESTORE CONFIGURATION IN DEV
UPDATE Configuration SET Value = 'TRUE'                                            WHERE Name = 'BlockNotify'
UPDATE Configuration SET Value = 'http://institutional-dev.beehive.com/research/'  WHERE Name = 'BaseWeb'
UPDATE Configuration SET Value = '\\researchfs.acml.com\researchdev\pubs\'         WHERE Name = 'UNCPrivate'
UPDATE Configuration SET Value = '\\researchfs.acml.com\researchdev\links\'        WHERE Name = 'UNCPublic'

-- RESTORE CONFIGURATION IN QA
UPDATE Configuration SET Value = 'TRUE'                                            WHERE Name = 'BlockNotify'
UPDATE Configuration SET Value = 'http://institutional-qa.beehive.com/research/'   WHERE Name = 'BaseWeb'
UPDATE Configuration SET Value = '\\researchfs.acml.com\researchqa\pubs\'          WHERE Name = 'UNCPrivate'
UPDATE Configuration SET Value = '\\researchfs.acml.com\researchqa\links\'         WHERE Name = 'UNCPublic'

select * from BloombergRequests

--UPDATE BLOOMBERG REQUESTS IN DEV AND QA
UPDATE BloombergRequests SET ReqFile = 'DEV_' + ReqFile WHERE ReqFile not like 'DEV_%'
DELETE FROM BloombergRequests WHERE RequestId IN (1,2,7,10,11, 12) -- EOD Not-US feeds

-- --UPDATE BLOOMBERG REQUESTS IN QA
-- UPDATE BloombergRequests SET ReqFile = 'QA_' + ReqFile WHERE ReqFile not like 'QA_%'

--CANCEL OUTSTANDING DISTRIBUTION ITEMS
-- After the database refresh, run the following sql to verify if there are outstanding distribution queues
SELECT DQ.DistributionID, DQ.SiteID, DQ.PubNo, DQ.Operation, DQ.Received, DQ.Scheduled, ISNULL(CONVERT(VARCHAR, DQ.RetryCount), '') RetryCount
FROM DistributionQueue DQ 
WHERE (DQ.Scheduled IS NOT NULL) AND (DQ.Cancelled IS NULL AND DQ.Transferred IS NULL)
ORDER BY DQ.Operation DESC, DQ.RetryCount ASC, DQ.PubNo ASC, DQ.DistributionID DESC

-- If there are outstanding distribution queues, use below query to cancel them.
UPDATE DistributionQueue SET Cancelled = GETDATE()
WHERE DistributionID IN
(SELECT DQ.DistributionID FROM DistributionQueue DQ WHERE (DQ.Scheduled IS NOT NULL) AND (DQ.Cancelled IS NULL AND DQ.Transferred IS NULL))

-- If there are outstanding analystblast queues, use below query to cancel them.
UPDATE AnalystBlastQueue SET Cancelled = GETDATE()
WHERE BlastId IN
(SELECT AQ.BlastId FROM AnalystBlastQueue AQ WHERE (AQ.Scheduled IS NOT NULL) AND (AQ.Cancelled IS NULL AND AQ.Completed IS NULL))

--Update Internal Use Only Commentary ListEmail's to point to ISTG-Research in DEV/QA
UPDATE CommentaryLists
SET ListEmail = 'ISTG-Research@alliancebernstein.com'
INSERT INTO CommentaryLists(ListName,ListEmail,EditorId,EditDate)
SELECT 'Market Commentary - Test','MarketCommentary-Test@bernstein.com',1126,getdate()

--Update EventLogNotifications EmailSubject in DEV
SELECT * FROM  EventLogNotifications
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0121 - Distribution Service Error' WHERE Source = 'DISTRIBUTION' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0121 - Distribution Service Information' WHERE Source = 'DISTRIBUTION' AND Type = 'I'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0121 - Cube ControlM Job Error' WHERE Source = 'CUBE' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0121 - TickerSheetLoader Service' WHERE Source = 'TickerSheetLoader Service' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0121 - Email Wizard Error' WHERE Source = 'Email Wizard' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0121 - Bernstein Analyst Blast Service' WHERE Source = 'AnalystBlast' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0121 - Job Scheduler Service' WHERE Source = 'JobController' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0121 - Ticker Sheet Error' WHERE Source = 'TickerSheet ' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0121 - Publishing Service Error' WHERE Source = 'Publishing ' AND Type = 'E'

--Update EventLogNotifications EmailSubject in QA
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0123 - Distribution Service Error' WHERE Source = 'DISTRIBUTION' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0123 - Distribution Service Information' WHERE Source = 'DISTRIBUTION' AND Type = 'I'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0123 - Cube ControlM Job Error' WHERE Source = 'CUBE' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0123 - TickerSheetLoader Service' WHERE Source = 'TickerSheetLoader Service' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0123 - Email Wizard Error' WHERE Source = 'Email Wizard' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0123 - Bernstein Analyst Blast Service' WHERE Source = 'AnalystBlast' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0123 - Job Scheduler Service' WHERE Source = 'JobController' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0123 - Ticker Sheet Error' WHERE Source = 'TickerSheet ' AND Type = 'E'
UPDATE EventLogNotifications SET EmailSubject = 'SYSALERT ON D06CL0123 - Publishing Service Error' WHERE Source = 'Publishing ' AND Type = 'E'
select * from EventLogNotifications


--Update Distribution outfolders in DEV
UPDATE DistributionSites SET FtpFolder = '\\researchfs\researchdev\Content\PRDCTL\out\RestrictedList' WHERE Site = 'Restricted List'
UPDATE DistributionSites SET FtpFolder = '\\researchfs.acml.com\researchdev\Content\DevStubs\Autonomy' WHERE Site = 'Autonomy'

--Update Distribution outfolders in QA
UPDATE DistributionSites SET FtpFolder = '\\researchfs\researchqa\Content\PRDCTL\out\RestrictedList' WHERE Site = 'Restricted List'
UPDATE DistributionSites SET FtpFolder = '\\researchfs.acml.com\researchqa\Content\DevStubs\Autonomy' WHERE Site = 'Autonomy'

-- Preserve database - folder integrity
-- DEV - Refresh \\researchfs\researchdev\links folder based on RVDocuments - save output as CopyDEVLinks.cmd script
-- select min(Date), count(*) from RVDocuments
SELECT Top 30000 'copy \\researchfs\research\links\' + Filename + ' \\researchfs\researchdev\links\' + Filename FROM Research..RVDocuments ORDER BY Date desc

-- DEV - Refresh \\researchfs\researchdev\pubs folder --save output as CopyDEVPubs.cmd script
SELECT TOP 50000 'copy \\researchfs\research\pubs\' + Filename + ' \\researchfs\researchdev\pubs\' + Filename FROM Documents ORDER BY pubno DESC

-- DEV - Refresh \\researchfs\researchdev\links\models folder --save output as CopyDEVModels.cmd script
SELECT TOP 3500 'copy \\researchfs\research\links\models\' + Filename + ' \\researchfs\researchdev\links\models\' + Filename FROM Models ORDER BY ModelId DESC

-- DEV - Refresh \\researchfs\researchdev\links\assets folder --save output as CopyDEVAssets.cmd script
SELECT TOP 1000 'copy \\researchfs\research\links\assets\' + Filename + ' \\researchfs\researchdev\links\assets\' + Filename FROM Assets ORDER BY AssetId DESC

--DEV - Publishing folder
--Do not copy files to publishing folde. This will result in publishing queue page on dev not opening any docx or debug file??

-- QA - Refresh \\researchfs\researchqa\links folder based on RVDocuments - save output as CopyQALinks.cmd script
-- select min(Date), count(*) from RVDocuments
SELECT Top 10000 'copy \\researchfs\research\links\' + Filename + ' \\researchfs\researchqa\links\' + Filename FROM Research..RVDocuments WHERE DocTypeId <> 10 ORDER BY Date desc

-- QA - Refresh \\researchfs\researchqa\pubs folder --save output as CopyQAPubs.cmd script
SELECT TOP 20000 'copy \\researchfs\research\pubs\' + Filename + ' \\researchfs\researchqa\pubs\' + Filename FROM Documents ORDER BY pubno DESC

-- QA - Refresh \\researchfs\researchqa\links\models folder --save output as CopyQAModels.cmd script
SELECT TOP 2500 'copy \\researchfs\research\links\models\' + Filename + ' \\researchfs\researchqa\links\models\' + Filename FROM Models ORDER BY ModelId DESC

-- QA - Refresh \\researchfs\researchqa\links\assets folder --save output as CopyQAAssets.cmd script
SELECT TOP 3500 'copy \\researchfs\research\links\assets\' + Filename + ' \\researchfs\researchqa\links\assets\' + Filename FROM Assets ORDER BY AssetId DESC

