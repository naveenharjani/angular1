USE [SlxExternal]
GO

/****** Object:  Table [dbo].[UsageLogshipper]    Script Date: 12/17/2018 8:14:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[UsageLogshipper](
	[UsageId] [int] IDENTITY(1,1) NOT NULL,
	[ContactId] [char](16) NULL,
	[Status] [bit] NULL,
	[AccessMailAddr] [varchar](120) NULL,
	[ContentId] [varchar](45) NULL,
	[ContentType] [varchar](15) NULL,
	[ContentSource] [varchar](120) NULL,
	[UsageTime] [datetime] NULL,
	[UserHost] [varchar](60) NOT NULL,
	[UserAgent] [varchar](300) NULL,
	[FileFound] [bit] NULL,
	[SourceId] [int] NULL,
	[ServerName] [varchar](90) NULL,
	[SourceInternal] [bit] NULL,
	[Info] [xml] NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [char](12) NULL,
PRIMARY KEY NONCLUSTERED 
(
	[UsageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


