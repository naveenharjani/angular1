USE [SlxExternal]
GO

CREATE TABLE [dbo].[WebUsage](
	[WebUsageId] [int] IDENTITY(1,1) NOT NULL,
	[CONTACTID] [varchar](16) NOT NULL,
	[PUBNO] [int] NULL,
	[STATUS] [char](1) NULL,
	[ACCESSDATE] [datetime] NULL,
	[NUMOFACCESS] [smallint] NULL,
	[ACCESS_EMAIL_ADDR] [varchar](100) NULL,
	[DOMAIN_NAME] [varchar](128) NULL,
	[FILEFOUND] [char](1) NULL,
	[SOURCEID] [int] NULL,
	[SERVER_NAME] [varchar](90) NULL,
	[SOURCE_INTERNAL] [char](1) NULL,
	[CONTENT_SOURCE] [varchar](120) NULL,
	[USER_AGENT] [varchar](300) NULL,
	[INFO] [xml] NULL,
	[CREATEUSER] [varchar](16) NULL,
	[CREATEDATE] [datetime] NULL,
	[MODIFYUSER] [varchar](16) NULL,
	[MODIFYDATE] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO