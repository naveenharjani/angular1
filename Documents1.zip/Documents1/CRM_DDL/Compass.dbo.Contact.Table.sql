USE [Compass]
GO

/****** Object:  Table [dbo].[Contact]    Script Date: 12/17/2018 8:16:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ARITHABORT ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Contact](
	[ContactID]  AS ('C'+right('00000000000000'+CONVERT([varchar](15),[CSID]),(15))) PERSISTED NOT NULL,
	[SLXContactID] [dbo].[SlxID] NULL,
	[SFContactID] [dbo].[SFID] NULL,
	[AccountID] [dbo].[CompassID] NULL,
	[ContactRole] [varchar](64) NULL,
	[Influence] [varchar](32) NULL,
	[Title] [nvarchar](256) NULL,
	[Team] [varchar](1024) NULL,
	[GeographicResponsibility] [varchar](255) NULL,
	[Email] [dbo].[Email] NULL,
	[WorkPhone] [dbo].[Phone] NULL,
	[AddressID] [dbo].[CompassID] NULL,
	[ContactOf] [varchar](128) NULL,
	[KeyNotes] [nvarchar](4000) NULL,
	[Status] [char](1) NULL,
	[StatusEffectiveOn] [datetime] NULL,
	[BloombergUUID] [varchar](32) NULL,
	[BloombergUsername] [varchar](32) NULL,
	[DealogicID] [varchar](32) NULL,
	[FirstName] [nvarchar](32) NULL,
	[MiddleName] [nvarchar](32) NULL,
	[LastName] [nvarchar](32) NULL,
	[BirthDate] [datetime] NULL,
	[AltEmail] [dbo].[Email] NULL,
	[MobilePhone] [dbo].[Phone] NULL,
	[HomePhone] [dbo].[Phone] NULL,
	[DoNotEmail] [char](1) NULL,
	[LowImpact] [char](1) NULL,
	[CSID] [int] IDENTITY(1,1) NOT NULL,
	[Source] [varchar](16) NULL,
	[PrimaryVB] [varchar](32) NULL,
	[AsstEmail] [varchar](128) NULL,
	[AsstPhone] [varchar](32) NULL,
	[Assistant] [varchar](64) NULL,
	[LastModifiedOn] [datetime] NOT NULL,
	[LastModifiedBy] [dbo].[CompassID] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[CreatedBy] [dbo].[CompassID] NOT NULL,
	[Department] [varchar](80) NULL,
	[ReportsTo] [dbo].[CompassID] NULL,
	[InactiveComments] [varchar](255) NULL,
	[IsAway] [char](1) NULL,
	[Photo] [text] NULL,
	[CoverageStartDate] [date] NULL,
	[CoverageEndDate] [date] NULL,
	[CoverageRole] [varchar](1024) NULL,
	[SFContactCoverageID] [dbo].[SFID] NULL,
	[ContactName]  AS ((((rtrim(coalesce([LastName],''))+', ')+rtrim(coalesce([FirstName],'')))+' ')+rtrim(coalesce([MiddleName],''))),
	[CSAAgreementID] [varchar](16) NULL,
PRIMARY KEY CLUSTERED 
(
	[ContactID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Contact]  WITH NOCHECK ADD  CONSTRAINT [FK_Con_AccountID] FOREIGN KEY([AccountID])
REFERENCES [dbo].[Account] ([AccountID])
GO

ALTER TABLE [dbo].[Contact] CHECK CONSTRAINT [FK_Con_AccountID]
GO

ALTER TABLE [dbo].[Contact]  WITH NOCHECK ADD  CONSTRAINT [FK_Con_CreatedBy] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[Contact] CHECK CONSTRAINT [FK_Con_CreatedBy]
GO

ALTER TABLE [dbo].[Contact]  WITH NOCHECK ADD  CONSTRAINT [FK_Con_LastModifiedBy] FOREIGN KEY([LastModifiedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[Contact] CHECK CONSTRAINT [FK_Con_LastModifiedBy]
GO


