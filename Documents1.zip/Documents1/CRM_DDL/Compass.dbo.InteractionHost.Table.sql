USE Compass  
Go
IF OBJECT_ID('dbo.InteractionHost', 'U') IS NOT NULL
DROP TABLE dbo.[InteractionHost]
Go
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ARITHABORT ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[InteractionHost](
	[InteractionHostID]  AS ('IH'+right('0000000000000'+CONVERT([varchar](14),[IHID]),(14))) PERSISTED NOT NULL,
	[InteractionsID] [dbo].[CompassID] NOT NULL,
	[SFCallReportID] [dbo].[SFID] NULL,
	[SFInteractionHostID] [dbo].[SFID] NULL,
	[HostID] [dbo].[CompassID] NULL,
	[HostName] [varchar](200) NULL,
	[HostType] [varchar](100) NULL,
	[NotificationReason] [varchar](max) NULL,
	[Source] [varchar](100) NULL,
	[IHID] [int] IDENTITY(1,1) NOT NULL,
	[LastModifiedOn] [datetime] NOT NULL,
	[LastModifiedBy] [dbo].[CompassID] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[CreatedBy] [dbo].[CompassID] NOT NULL,
	[Title] [varchar](128) NULL,
	[Department] [varchar](32) NULL,
	[ProductRegion] [varchar](32) NULL,
PRIMARY KEY CLUSTERED 
(
	[InteractionHostID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[InteractionHost]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionHost_CreatedBy] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[InteractionHost] NOCHECK CONSTRAINT [FK_InteractionHost_CreatedBy]
GO

ALTER TABLE [dbo].[InteractionHost]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionHost_InteractionsID] FOREIGN KEY([InteractionsID])
REFERENCES [dbo].[Interactions] ([InteractionsID])
GO

ALTER TABLE [dbo].[InteractionHost] NOCHECK CONSTRAINT [FK_InteractionHost_InteractionsID]
GO

ALTER TABLE [dbo].[InteractionHost]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionHost_LastModifiedBy] FOREIGN KEY([LastModifiedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[InteractionHost] NOCHECK CONSTRAINT [FK_InteractionHost_LastModifiedBy]
GO

CREATE NONCLUSTERED INDEX [ix_InteractionHost_HostID] ON [dbo].[InteractionHost]
(
	[HostID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [ix_InteractionHost_InteractionsID] ON [dbo].[InteractionHost]
(
	[InteractionsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED COLUMNSTORE INDEX [csix_InteractionHost_InteractionsID] ON [dbo].[InteractionHost]
(
	[InteractionsID],
	[HostID]
)WITH (DROP_EXISTING = OFF, COMPRESSION_DELAY = 0) ON [PRIMARY]
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[InteractionHost] TO [compass_app_role]
GO
GRANT SELECT ON [dbo].[InteractionHost] TO [research_app_role]
GO
