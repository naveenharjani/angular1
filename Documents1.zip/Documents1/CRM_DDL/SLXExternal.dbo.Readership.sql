USE [SlxExternal]
GO

/****** Object:  Table [dbo].[Readership]    Script Date: 12/11/2019 11:49:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ARITHABORT ON
GO

CREATE TABLE [dbo].[Readership](
	[ReadershipID] [varchar](16) NOT NULL,
	[PubNo] [int] NULL,
	[ContactID] [varchar](16) NULL,
	[ContactName] [varchar](128) NULL,
	[AccountID] [varchar](16) NULL,
	[AccountName] [varchar](128) NULL,
	[AccountType] [varchar](64) NULL,
	[SFContactID] [varchar](18) NULL,
	[SFAccountID] [varchar](18) NULL,
	[Email] [varchar](200) NULL,
	[ReadDate] [date] NULL,
	[Source] [varchar](50) NULL,
	[Type] [varchar](20) NULL,
	[RSID] [int] IDENTITY(1,1) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[CreatedBy] [varchar](16) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ReadershipID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


