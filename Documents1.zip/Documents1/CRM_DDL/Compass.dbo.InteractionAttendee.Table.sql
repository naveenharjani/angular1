--[Muzeeb 11/09/2016] Created the Table
--[Sharmil 11/30/2016] merged both CallReportAttendeeClient and CallReportAttendeeInternal to CallReportAttendee.
--[sharmil 1/13/2017] changed name of the table to InteractionsAttendee

USE Compass 
Go 
IF OBJECT_ID('dbo.InteractionAttendee', 'U') IS NOT NULL
DROP TABLE dbo.[InteractionAttendee]
Go
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ARITHABORT ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[InteractionAttendee](
	[InteractionAttendeeID]  AS ('IA'+right('0000000000000'+CONVERT([varchar](14),[IAID]),(14))) PERSISTED NOT NULL,
	[InteractionsID] [dbo].[CompassID] NOT NULL,
	[SFCallReportId] [dbo].[SFID] NULL,
	[SFInteractionAttendeeID] [dbo].[SFID] NULL,
	[AccountId] [dbo].[CompassID] NULL,
	[AccountName] [varchar](128) NULL,
	[ContactId] [dbo].[CompassID] NULL,
	[ContactName] [varchar](128) NULL,
	[USERDEF1] [varchar](255) NULL,
	[USERDEF2] [varchar](255) NULL,
	[Source] [varchar](100) NULL,
	[IAID] [int] IDENTITY(1,1) NOT NULL,
	[LastModifiedOn] [datetime] NOT NULL,
	[LastModifiedBy] [dbo].[CompassID] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[CreatedBy] [dbo].[CompassID] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[InteractionAttendeeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[InteractionAttendee]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionAttendee_AccountId] FOREIGN KEY([AccountId])
REFERENCES [dbo].[Account] ([AccountID])
GO

ALTER TABLE [dbo].[InteractionAttendee] NOCHECK CONSTRAINT [FK_InteractionAttendee_AccountId]
GO

ALTER TABLE [dbo].[InteractionAttendee]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionAttendee_ContactId] FOREIGN KEY([ContactId])
REFERENCES [dbo].[Contact] ([ContactID])
GO

ALTER TABLE [dbo].[InteractionAttendee] NOCHECK CONSTRAINT [FK_InteractionAttendee_ContactId]
GO

ALTER TABLE [dbo].[InteractionAttendee]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionAttendee_CreatedBy] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[InteractionAttendee] NOCHECK CONSTRAINT [FK_InteractionAttendee_CreatedBy]
GO

ALTER TABLE [dbo].[InteractionAttendee]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionAttendee_LastModifiedBy] FOREIGN KEY([LastModifiedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[InteractionAttendee] NOCHECK CONSTRAINT [FK_InteractionAttendee_LastModifiedBy]
GO

CREATE NONCLUSTERED INDEX [ix_InteractionAttendee_ContactID] ON [dbo].[InteractionAttendee]
(
	[ContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO


CREATE NONCLUSTERED INDEX [ix_InteractionAttendee_Idx1] ON [dbo].[InteractionAttendee]
(
	[AccountId] ASC,
	[ContactId] ASC,
	[InteractionsID] ASC
)
INCLUDE ( 	[USERDEF1],
	[USERDEF2],
	[Source]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [ix_InteractionAttendee_InteractionsID] ON [dbo].[InteractionAttendee]
(
	[InteractionsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED COLUMNSTORE INDEX [csix_InteractionAttendee_InteractionsID] ON [dbo].[InteractionAttendee]
(
	[InteractionsID],
	[AccountId],
	[ContactId]
)WITH (DROP_EXISTING = OFF, COMPRESSION_DELAY = 0) ON [PRIMARY]

GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[InteractionAttendee] TO [compass_app_role]
GO
GRANT SELECT ON [dbo].[InteractionAttendee] TO [research_app_role]
GO
