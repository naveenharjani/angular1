USE [SlxExternal]
GO

/****** Object:  Table [dbo].[WSGSiteActivity]    Script Date: 12/17/2018 8:14:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[WSGSiteActivity](
	[ActivityTypeUID] [int] NULL,
	[ActivityName] [varchar](60) NULL,
	[ActivityUID] [int] NULL,
	[FileServerGuid] [uniqueidentifier] NULL,
	[SiteGuid] [uniqueidentifier] NULL,
	[UserGuid] [uniqueidentifier] NULL,
	[DateTimeStamp] [datetime] NULL,
	[Msg] [varchar](1024) NULL,
	[SiteTitle] [varchar](1024) NULL,
	[UserEmail] [varchar](255) NULL,
	[FileServerName] [varchar](1024) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


