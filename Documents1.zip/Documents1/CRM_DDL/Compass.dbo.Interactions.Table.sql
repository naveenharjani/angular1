--[Muzeeb 11/09/2016] Created the Table
--[Sharmil 11/30/2016] merged both CallReportAttendeeClient and CallReportAttendeeInternal to CallReportAttendee.
--[Balu 2/2/2017] altered LoggedFrom from Datetime to varchar(100)
--[Balu 3/1/2017] Removed unwanted fields as per DM
--[Balu 3/7/2017] Added Timezone field.
--[Balu 3/27/2017] Rename LoggedBy to PrimaryHost

USE Compass
Go  
IF OBJECT_ID('dbo.Interactions', 'U') IS NOT NULL
DROP TABLE dbo.[Interactions]
Go
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ARITHABORT ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Interactions](
	[InteractionsID]  AS ('I'+right('00000000000000'+CONVERT([varchar](15),[INID]),(15))) PERSISTED NOT NULL,
	[SFCallReportID] [dbo].[SFID] NULL,
	[ServiceType] [varchar](100) NULL,
	[ServiceSubType] [varchar](200) NULL,
	[Description] [varchar](1024) NULL,
	[Duration] [int] NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[CompletedDate] [datetime] NULL,
	[Notes] [varchar](max) NULL,
	[LongNotes] [varchar](max) NULL,
	[IntegrationType] [varchar](100) NULL,
	[IntegrationId] [varchar](100) NULL,
	[ServicePoints] [decimal](18, 2) NULL,
	[Location] [varchar](1000) NULL,
	[PrimaryHost] [varchar](18) NULL,
	[LoggedFrom] [varchar](100) NULL,
	[Rating] [int] NULL,
	[RelatedEvent] [varchar](18) NULL,
	[Timezone] [varchar](16) NULL,
	[Source] [varchar](10) NULL,
	[INID] [int] IDENTITY(1,1) NOT NULL,
	[LastModifiedOn] [datetime] NOT NULL,
	[LastModifiedBy] [dbo].[CompassID] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[CreatedBy] [dbo].[CompassID] NOT NULL,
	[MeetingType] [varchar](516) NULL,
PRIMARY KEY CLUSTERED 
(
	[InteractionsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

Alter Table Compass.dbo.Interactions Add City varchar(255) NULL
Alter Table Compass.dbo.Interactions Add State varchar(255) NULL
Alter Table Compass.dbo.Interactions Add Country varchar(255) NULL

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Interactions]  WITH NOCHECK ADD  CONSTRAINT [FK_Interactions_CreatedBy] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[Interactions] NOCHECK CONSTRAINT [FK_Interactions_CreatedBy]
GO

ALTER TABLE [dbo].[Interactions]  WITH NOCHECK ADD  CONSTRAINT [FK_Interactions_LastModifiedBy] FOREIGN KEY([LastModifiedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[Interactions] NOCHECK CONSTRAINT [FK_Interactions_LastModifiedBy]
GO


CREATE NONCLUSTERED INDEX [ix_Interactions_Idx1] ON [dbo].[Interactions]
(
	[StartDate] ASC,
	[ServiceType] ASC,
	[IntegrationId] ASC
)
INCLUDE ( 	[RelatedEvent],
	[Source]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO


CREATE NONCLUSTERED INDEX [ix_Interactions_Idx2] ON [dbo].[Interactions]
(
	[IntegrationId] ASC,
	[InteractionsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [ix_Interactions_IntegrationId] ON [dbo].[Interactions]
(
	[IntegrationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [ix_Interactions_ServiceType] ON [dbo].[Interactions]
(
	[ServiceType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [ix_Interactions_SFCallReportID] ON [dbo].[Interactions]
(
	[SFCallReportID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [ix_Interactions_StartDate] ON [dbo].[Interactions]
(
	[StartDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO
CREATE NONCLUSTERED COLUMNSTORE INDEX [csix_Interactions] ON [dbo].[Interactions]
(
	[ServiceType],
	[ServiceSubType],
	[Description],
	[Duration],
	[StartDate],
	[IntegrationId],
	[IntegrationType]
)WITH (DROP_EXISTING = OFF, COMPRESSION_DELAY = 0) ON [PRIMARY]
GO
GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[Interactions] TO [compass_app_role]
GO
GRANT SELECT ON [dbo].[Interactions] TO [research_app_role]
GO





