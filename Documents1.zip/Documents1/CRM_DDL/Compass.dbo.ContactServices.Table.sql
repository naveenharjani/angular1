/*
This table will be used to store the additional services offered to the contact (one to many)
one row in this table will represent one service
type of services and the field usage is given below:

1. Research Preference
ContactID			ServiceID			ServiceName			ServiceType	HasOptedEmail	HasOptedBBWB	VBLists
C000000000069315	IND0000000000102	<Industry Name>		Research	T				T				210

2. Contact Product Group
ContactID			ServiceID			ServiceName			ServiceType
C000000000045211	PG00000000000002	<Contact Product Name>	BR.com

3. Quant Service
ContactID			ServiceID				ServiceName				ServiceType			ServiceStatus	ServiceStartDate	ServiceEndtDate
C000000000045211	<UqantServiceID>		<Quant Service Name>	Quant				<QuantStatus>	<QuantStartDate>	<DeactivationDate>

3. BR Access
ContactID			ServiceID	ServiceName		ServiceType		LoginID			ServiceResetDate			ServiceStatus	
C000000000045211				BR.com Access	BRAccess		<WebUserID>		<WebLoginUnlocked>			<WebEnable>		

4. Quant Access
ContactID			ServiceID	ServiceName			ServiceType		ServiceStatus	HasOptedEmail			ServiceInfo	
C000000000045211				BR.com Quant Access	QuantAccess		<GQSEnabled>	<GQSEmailNotify>		<QSDocumentsDirectory>

5. Portfolio Monitor
ContactID			ServiceID	ServiceName					ServiceType		ServiceInfo				PfMonitorAdmin	PfMonitorClient 
C000000000045211				Portfolio Monitor Access	PfMonitor		<PfMonitorClientIds>	T				F				

6. PT Strategy	
ContactID			ServiceID	ServiceName		ServiceType		ServiceStartDate	ServiceEndDate	ServiceInfo
C000000000045211	<SENTBY>	PT Strategy		PTStrategy		<SENDDATE>			<EXPDATE>		<PTVER>

6. Portal Entitlement	
ContactID			ServiceID	ServiceName		ServiceType			ServiceStatus		ServiceStartDate	ServiceEndDate		ServiceInfo	ServiceRequestedBy
C000000000045211	<PORTAL_ID>	<PORTAL_NAME>	PortalEntitlement	T/F					ENTITLEMENT_DATE	DISENTITLEMENT_DATE	NOTE		REQUESTED_BY_ID
																	(if DISENTITLEMENT_DATE 
																	> today then �T�)

*/


USE Compass
IF OBJECT_ID('dbo.ContactServices', 'U') IS NOT NULL
DROP TABLE dbo.[ContactServices]
GO

CREATE TABLE [dbo].[ContactServices](
	[ContactServicesID] AS 'CS'+RIGHT('0000000000000'+CONVERT(VARCHAR(14),CSSID),14) PERSISTED PRIMARY KEY CLUSTERED NOT NULL,
	
	[SLXContactServicesID] SlxID NULL, -- this id may be from SCB_CDV_PRODUCTGROUP, INF_CDV_RESEARCH_INTS or SCB_QUANT_SERVICE
	[SFContactServicesID] SFID NULL, --this id may be from Contact_Entitlement__c, T1C_Base__Interest__c or Quant_Service__c

	[ContactID] CompassID NULL CONSTRAINT FK_ContactServices_ContactId FOREIGN KEY REFERENCES dbo.Contact (ContactID),
	[ServiceID] varchar(64)  NULL,
	[ServiceName] varchar(256) NULL,
	[ServiceType] varchar(128) NOT NULL, -- Research, BR.com, Quant 
	[ServiceStatus] varchar(24) NULL,
	[ServiceStartDate] date NULL,
	[ServiceEndDate] date NULL,
	[ServiceRequestedBy] CompassID NULL,

	--Research Preference
	[HasOptedEmail] [char](1) NULL,
	[HasOptedBBWB] [char](1) NULL,
	[VBLists] [varchar](255) NULL, -- We will not be importing VBSelected [Research Pref's sub table 'SCB_VB_SELECTED' in SLX]
		
	--BR Access
	[LoginID] Email NULL, -- BR.com login ID
	[ServiceResetDate] datetime NULL, --WebLoginUnlocked
	
	--Quant Access
	[ServiceInfo] varchar(max) NULL,	--Quant Service report directory  --QSDocumentsDirectory

	--Portfolio Monitor	
	[PfMonitorAdmin] char(1) NULL,
	[PfMonitorClient] char(1) NULL,
	
	--System fields 
	[CSSID] INT NOT NULL IDENTITY(1,1),--This field has no business value. But necessary to derive the ResearchInterestID field.
	[Source] varchar(16) NULL, 
	[LastModifiedOn] datetime NOT NULL,
	[LastModifiedBy] CompassID NOT NULL CONSTRAINT FK_ContactServices_LastModifiedBy FOREIGN KEY REFERENCES dbo.Users (UserID),
	[CreatedOn] datetime not NULL,
	[CreatedBy] CompassID NOT NULL CONSTRAINT FK_ContactServices_CreatedBy FOREIGN KEY REFERENCES dbo.Users (UserID)
)
GO


--ALTER TABLE [dbo].[ContactServices] ADD [ServiceRequestedBy] CompassID
--ALTER TABLE [dbo].[ContactServices] ALTER COLUMN [ServiceID] varchar(64) 


GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[ContactServices] TO [compass_app_role]
GO
GRANT SELECT ON [dbo].[ContactServices] TO [research_app_role]
GO
CREATE NONCLUSTERED INDEX IX_SERVICE_SLXID ON dbo.ContactServices (SLXContactServicesID)
GO
CREATE NONCLUSTERED INDEX IX_SERVICE_COMPASSID ON dbo.ContactServices (ContactID)
GO
CREATE NONCLUSTERED INDEX IX_SERVICE_SFID  ON dbo.ContactServices (SFContactServicesID)
GO
CREATE NONCLUSTERED INDEX IX_SERVICE_STYPE ON dbo.ContactServices (ContactID,ServiceType)
Go

