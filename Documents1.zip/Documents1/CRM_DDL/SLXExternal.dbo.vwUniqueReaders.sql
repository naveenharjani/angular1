--[Sharmil 08/30/2016 ] view to get Unique Readers from WebUsage table and from RVPortalUsage
USE [SlxExternal]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwUniqueReaders]') AND type in (N'V'))
DROP VIEW [dbo].[vwUniqueReaders]
GO

CREATE VIEW [dbo].[vwUniqueReaders]
AS

	-- query from vwUniqueReaders (used by research team)


	 Select SW.PubNo, C.ContactID, C.SLXContactID, C.SFContactID, A.SFAccountID
	 , SW.AccessDate as READ_DATE, S.Source, ISNULL(MW.SOURCEID,CW.SourceId) as SourceID --, SS.SOURCEID
	 , 'ResearchUsage' Type
	 from
	 (
		 Select contactid, SLXContactID, SFContactID, pubno, convert(date,ACCESSDATE) as AccessDate, MIN(AccessDate) as MINDATE, MIN(webusageid) as MINID from
			(
				Select c.contactid, c.SLXContactID, c.SFContactID, pubno, AccessDate, sourceid, WebUsageId
					from slxexternal.dbo.webusage w with (nolock) 
				inner join compass.dbo.contact c with (nolock) on c.slxcontactid = w.CONTACTID AND w.filefound IN ('Y','T') and w.pubno != '99999999'
				UNION ALL
				Select c.contactid, c.SLXContactID, c.SFContactID, ContentId, ACCESSDATE, sourceid, UsageId
					from slxexternal.dbo.ContentUsage w with (nolock) 
				inner join compass.dbo.contact c with (nolock) on c.slxcontactid = w.CONTACTID and ContentTypeId = 'R' AND w.STATUS IN ('100','101')
				UNION ALL
				Select c.contactid, c.SLXContactID, c.SFContactID, pubno, AccessDate, sourceid, WebUsageId
					from slxexternal.dbo.webusage w with (nolock) 
				inner join compass.dbo.contact c with (nolock) on c.contactid = w.CONTACTID AND w.filefound IN ('Y','T') and w.pubno != '99999999'
				UNION ALL
				Select c.contactid, c.SLXContactID, c.SFContactID, ContentId, ACCESSDATE, sourceid, UsageId
					from slxexternal.dbo.ContentUsage w with (nolock) 
				inner join compass.dbo.contact c with (nolock) on c.contactid = w.CONTACTID and ContentTypeId = 'R' AND w.STATUS IN ('100','101')
			) TOT
		 GROUP BY contactid, SLXContactID, SFContactID, PUBNO, convert(date,ACCESSDATE)
	 ) SW
 		 inner join compass.dbo.contact c with (nolock) on c.contactid = sw.CONTACTID
		 inner join compass.dbo.account a with (nolock) on c.AccountID = a.AccountID
		 left join SlxExternal.dbo.WebUsage mw with (nolock) on mw.WebUsageId = SW.MINID --and mw.CONTACTID = SW.ContactID
		 left join SlxExternal.dbo.ContentUsage cw with (nolock) on cw.UsageId = SW.MINID --and mw.CONTACTID = SW.ContactID
		 /*cross apply (Select 1 as SourceID
			/*Select top 1 SourceID FROM
			(
				Select SourceID from SLXExternal.dbo.WebUsage with (nolock) where WebUsageId = MINID
				 --where filefound IN ('Y','T') and pubno != '99999999' AND ContactID IN (C.CONTACTID, C.SLXContactID) AND PUBNO = SW.PUBNO
				 --AND AccessDate = SW.MINDATE
				 UNION
 				Select SourceID from SLXExternal.dbo.ContentUsage with (nolock) where UsageID = MINID
				 --where ContactID IN (C.CONTACTID, C.SLXContactID) AND ContentTypeId = 'R' AND STATUS IN ('100','101') AND ContentID = SW.PUBNO
				 --AND AccessDate = SW.MINDATE
			) TOT*/
		 ) SS*/
		 LEFT JOIN SlxExternal.dbo.RVLinkSources s with (NOLOCK) on ISNULL(mw.sourceid,cw.sourceid) = s.SourceId
		 WHERE ISNULL(A.TYPE, '') NOT LIKE '%press%' AND ISNULL(A.TYPE, '') NOT LIKE '%Industry%' AND ISNULL(A.TYPE, '') NOT LIKE '%Internal%'
	/*

	SELECT DISTINCT SWU.PUBNO, c.ContactID,c.SLXContactID, c.SFContactID, a.SFAccountID
		, convert(date, SWU.ACCESSDATE )  AS READ_DATE
		, s.Source
		, 'ResearchUsage' Type
	FROM   slxexternal.dbo.WebUsage SWU with (NOLOCK)  INNER JOIN
			--do not join to sv_contact as it does not have former contacts, so prior reads will get filtered
           --SlxExternal.dbo.SV_Contact svc with (NOLOCK) ON svc.CONTACTID = SWU.CONTACTID AND SWU.FILEFOUND IN ('Y', 'T') INNER JOIN
		   compass.dbo.contact c with (nolock) on SWU.Contactid = c.SLXContactID   AND SWU.FILEFOUND IN ('Y', 'T') inner join 
           Compass.dbo.ACCOUNT A with (NOLOCK) ON c.ACCOUNTID = a.AccountID  
		   AND ISNULL(A.TYPE, '') NOT LIKE '%press%' AND ISNULL(A.TYPE, '') NOT LIKE '%Industry%' AND ISNULL(A.TYPE, '') NOT LIKE '%Internal%'
		   INNER JOIN SlxExternal.dbo.RVLinkSources s with (NOLOCK) on SWU.SOURCEID = s.SourceId
	UNION

	SELECT DISTINCT SWU.PUBNO, c.ContactID,c.SLXContactID, c.SFContactID, a.SFAccountID
		, convert(date, SWU.ACCESSDATE )  AS READ_DATE
		, s.Source
		, 'ResearchUsage' Type
	FROM   slxexternal.dbo.WebUsage SWU with (NOLOCK)  INNER JOIN
			--do not join to sv_contact as it does not have former contacts, so prior reads will get filtered
           --SlxExternal.dbo.SV_Contact svc with (NOLOCK) ON svc.CONTACTID = SWU.CONTACTID AND SWU.FILEFOUND IN ('Y', 'T') INNER JOIN
		   compass.dbo.contact c with (nolock) on SWU.Contactid = c.Contactid  AND SWU.FILEFOUND IN ('Y', 'T') inner join 
           Compass.dbo.ACCOUNT A with (NOLOCK) ON c.ACCOUNTID = a.AccountID  
		   AND ISNULL(A.TYPE, '') NOT LIKE '%press%' AND ISNULL(A.TYPE, '') NOT LIKE '%Industry%' AND ISNULL(A.TYPE, '') NOT LIKE '%Internal%'
		   INNER JOIN SlxExternal.dbo.RVLinkSources s with (NOLOCK) on SWU.SOURCEID = s.SourceId
	UNION	

	SELECT DISTINCT SWU.ContentId, c.ContactID,c.SLXContactID, c.SFContactID, a.SFAccountID, DATEADD(day, 0, DATEDIFF(day, 0, SWU.ACCESSDATE ))  AS READ_DATE, s.Source, 'ResearchUsage' Type
	FROM  SlxExternal.dbo.ContentUsage SWU with (nolock)  
		   INNER JOIN compass.dbo.contact c with (nolock) on SWU.Contactid = c.SLXContactID AND SWU.STATUS IN (100, 101) AND SWU.ContentTypeId = 'R'
		   inner join Compass.dbo.ACCOUNT A with (NOLOCK) ON c.ACCOUNTID = a.AccountID
		   AND ISNULL(A.TYPE, '') NOT LIKE '%press%' AND ISNULL(A.TYPE, '') NOT LIKE '%Industry%' AND ISNULL(A.TYPE, '') NOT LIKE '%Internal%'
		   INNER JOIN SlxExternal.dbo.RVLinkSources s with (NOLOCK) on SWU.SOURCEID = s.SourceId
	UNION	

	SELECT DISTINCT SWU.ContentId, c.ContactID,c.SLXContactID, c.SFContactID, a.SFAccountID, DATEADD(day, 0, DATEDIFF(day, 0, SWU.ACCESSDATE ))  AS READ_DATE, s.Source, 'ResearchUsage' Type
	FROM  SlxExternal.dbo.ContentUsage SWU with (nolock)  
		   INNER JOIN compass.dbo.contact c with (nolock) on SWU.Contactid = c.Contactid AND SWU.STATUS IN (100, 101) AND SWU.ContentTypeId = 'R'
		   inner join Compass.dbo.ACCOUNT A with (NOLOCK) ON c.ACCOUNTID = a.AccountID
		   AND ISNULL(A.TYPE, '') NOT LIKE '%press%' AND ISNULL(A.TYPE, '') NOT LIKE '%Industry%' AND ISNULL(A.TYPE, '') NOT LIKE '%Internal%'
		   INNER JOIN SlxExternal.dbo.RVLinkSources s with (NOLOCK) on SWU.SOURCEID = s.SourceId

			
	-- filter condition in slx 
	--filefound IN ('Y','T') and pubno != '99999999'
	
	
	--UNION
	
 --  select  UsageId Id, pu.PubNo, c.ContactID,c.SLXContactID, c.SFContactID,a.SFAccountID,  DATEADD(day, 0, DATEDIFF(day, 0, pu.ReadDate ))  AS READ_DATE, PMap.UsageName site, 'PortalUsage' Type
 --   from 
	--	(Select distinct	
	--		P.UsageId
	--		, P.Pubno
	-- 		, P.Site
	--		, CONVERT(datetime,convert(varchar(12),P.READDATE,101)) AS [READDATE]
	--		, substring(P.ContactID, 1, (case when charIndex('@', P.ContactID) = 0 then len(P.ContactID) else charIndex('@', P.ContactID) - 1 end)) as ContactID
	--		, P.Contact
	--		, P.Email
	--		, P.AccountID
	--		, P.Account
	--	from slxexternal.dbo.RVPortalUsage P with (nolock) )pu	
	--left outer join
	--(select 'Bloomberg (SANB)' as UsageName, 'Bloomberg' as EntitlementName
	--	union select 'Reuters', 'Reuters'  		
	--	union select 'FactSet', 'FactSet'  
	--	union select 'CapitalIQ', 'Capital IQ' 
	--	union select 'TheMarkets.com', 'TMC' 
	--	union select 'AB','AB'
	--) PMap on PMap.UsageName = pu.Site 
	--left outer join 
	--compass.dbo.ContactServices cs with (nolock) on cs.ServiceID = pu.ContactId
	--inner join compass.dbo.contact c with (nolock) on cs.ContactID = c.ContactID  
	--inner join compass.dbo.account a with (nolock) on c.AccountID = A.AccountID
	
	*/


GO
GRANT SELECT ON [dbo].[vwUniqueReaders] TO [compass_app_role]
GO
GRANT SELECT ON [dbo].[vwUniqueReaders] TO [research_app_role]
GO







