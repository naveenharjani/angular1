-- _readsummary.sql
--exec slxexternal.dbo.GetReadSummary 322, '1/1/2014', '12/30/2015'
--[GetReadSummary] '', '01/01/2018', '04/19/2018'
USE [SlxExternal]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetReadSummary]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetReadSummary]
GO

CREATE PROCEDURE [dbo].[GetReadSummary]
(
 @vAnalystId		VARCHAR(100),
 @vSinceDate		VARCHAR(100),
 @vUntilDate		VARCHAR(100)
)
AS	
BEGIN
	SET NOCOUNT ON
	
	DECLARE @AnalystID varchar(100), @PubStartDate DATETIME, @PubEndDate DATETIME
	SET @AnalystID = @vAnalystId
	SET @PubStartDate = @vSinceDate
	SET @PubEndDate = @vUntilDate

	SELECT v.PUBNO, 'read_count' = count(*) 
	  ,d.Date
	  ,'Type' = 
		CASE T.DocType
		  WHEN 'Research Note' THEN 'Note'
		  WHEN 'Black Book' THEN 'Blackbook'
		  WHEN 'White Book' THEN 'Whitebook'
		  WHEN 'Research Call' THEN (CASE substring(D.Title, 1, 10) WHEN 'Quick Take' THEN 'Flash' ELSE 'Call' END)
		  ELSE T.DocType
		END	 
	  ,d.Title
	  ,'Author' = A.Last
	  ,d.Filename
	FROM SlxExternal.dbo.vwUniqueReaders v with (nolock) 
	inner join SlxExternal.dbo.RVDocuments d with (nolock) on v.PUBNO = d.DocId
	--INNER JOIN  SlxExternal.dbo.RVDocAnalysts A with (nolock) on A.docid = D.docid 	
	--INNER JOIN  SlxExternal.dbo.RVDocAnalysts A with (nolock) on A.docid = D.docid and  A.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = D.DocId) --Primary Author
	cross apply 
	(
		Select top 1 AnalystId, Last from SlxExternal.dbo.RVDocAnalysts A 
		where A.docid = D.DocId order by OrdinalId
	) A
	INNER JOIN SlxExternal.dbo.RVTypes T with (nolock) ON T.DocTypeId = D.DocTypeId
	WHERE  v.READ_DATE >= @PubStartDate AND d.Date BETWEEN  @PubStartDate and @PubEndDate
	AND D.DocId IN (SELECT DISTINCT DocID from SlxExternal.dbo.RVDocAnalysts I where (isnull(@AnalystID, '') = '' OR I.AnalystId = @AnalystID))
	    --AND (isnull(@vAnalystId, '') = '' OR a.AnalystId = @vAnalystId )
	GROUP BY v.PUBNO, D.Date, T.DocType, D.Title, D.filename, A.Last
	UNION
	SELECT v.PUBNO, 'read_count' = count(*) 
	  ,d.Date
	  ,'Type' = 
		CASE T.DocType
		  WHEN 'Research Note' THEN 'Note'
		  WHEN 'Black Book' THEN 'Blackbook'
		  WHEN 'White Book' THEN 'Whitebook'
		  WHEN 'Research Call' THEN (CASE substring(D.Title, 1, 10) WHEN 'Quick Take' THEN 'Flash' ELSE 'Call' END)
		  ELSE T.DocType
		END	 
	  ,d.Title
	  ,'Author' = A.Last
	  ,d.Filename
	FROM SlxExternal.dbo.vwUniqueReaders v with (nolock) 
	inner join SlxExternal.dbo.RVDocuments d with (nolock) on v.PUBNO = d.DocId
	--INNER JOIN  SlxExternal.dbo.RVAltDocAnalysts A with (nolock) on A.docid = D.docid 	
	--INNER JOIN  SlxExternal.dbo.RVAltDocAnalysts A with (nolock) on A.docid = D.docid and  A.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = D.DocId) --Primary Author
	cross apply 
	(
		Select top 1 AnalystId, Last from SlxExternal.dbo.RVAltDocAnalysts A 
		where A.docid = D.DocId	order by OrdinalId
	) A
	INNER JOIN SlxExternal.dbo.RVTypes T with (nolock) ON T.DocTypeId = D.DocTypeId
	WHERE  v.READ_DATE >= @PubStartDate AND d.Date BETWEEN  @PubStartDate and @PubEndDate
	--AND (isnull(@vAnalystId, '') = '' OR a.AnalystId = @vAnalystId )
	AND D.DocId IN (SELECT DISTINCT DocID from SlxExternal.dbo.RVAltDocAnalysts I where (isnull(@AnalystID, '') = '' OR I.AnalystId = @AnalystID))
	GROUP BY v.PUBNO, D.Date, T.DocType, D.Title, D.filename, A.Last
	ORDER BY d.Date DESC, v.PubNo DESC


END
GO

GRANT EXECUTE ON [dbo].[GetReadSummary] TO [research_app_role]
GRANT EXECUTE ON [dbo].[GetReadSummary] TO [compass_app_role]

GO