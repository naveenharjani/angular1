USE [Compass]
GO

/****** Object:  Table [dbo].[Account]    Script Date: 12/17/2018 8:16:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ARITHABORT ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Account](
	[AccountID]  AS ('A'+right('00000000000000'+CONVERT([varchar](15),[ASID]),(15))) PERSISTED NOT NULL,
	[SLXAccountID] [dbo].[SlxID] NULL,
	[SFAccountID] [dbo].[SFID] NULL,
	[AccountName] [nvarchar](128) NULL,
	[InvestmentStyle] [varchar](32) NULL,
	[KeyNotes] [nvarchar](4000) NULL,
	[Description] [varchar](4000) NULL,
	[Phone] [dbo].[Phone] NULL,
	[AddressID] [dbo].[CompassID] NULL,
	[AltAddressID] [dbo].[CompassID] NULL,
	[CSAParentID] [varchar](16) NULL,
	[ReportParentID] [varchar](16) NULL,
	[AccountRegion] [varchar](64) NULL,
	[Type] [varchar](32) NULL,
	[SubType] [varchar](64) NULL,
	[Status] [char](1) NULL,
	[SubStatus] [varchar](128) NULL,
	[StatusEffectiveOn] [datetime] NULL,
	[USTier] [varchar](8) NULL,
	[EUTier] [varchar](8) NULL,
	[APTier] [varchar](8) NULL,
	[IsGlobal] [char](1) NULL,
	[ExecOnly] [char](1) NULL,
	[MiddleMarketAccount] [char](1) NULL,
	[ClientVotes] [char](1) NULL,
	[WebEnable] [char](1) NULL,
	[ShortName] [varchar](max) NULL,
	[ClientTradingInstructions] [varchar](4000) NULL,
	[USTrading] [char](1) NULL,
	[EUTrading] [char](1) NULL,
	[APTrading] [char](1) NULL,
	[APCategory] [char](1) NULL,
	[IndiaTrading] [char](1) NULL,
	[USOptions] [varchar](64) NULL,
	[EUContactPermitted] [char](1) NULL,
	[DealogicID] [varchar](32) NULL,
	[ASID] [int] IDENTITY(1,1) NOT NULL,
	[Source] [varchar](16) NULL,
	[LastModifiedOn] [datetime] NOT NULL,
	[LastModifiedBy] [dbo].[CompassID] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[CreatedBy] [dbo].[CompassID] NOT NULL,
	[IsIn15A6] [char](1) NULL,
	[BrokerLiason] [dbo].[CompassID] NULL,
	[TradingLevel] [smallint] NULL,
	[TradingType] [varchar](32) NULL,
	[InitialVerificationDate] [datetime] NULL,
	[LatestVerificationDate] [datetime] NULL,
	[StatusVerificationDate] [datetime] NULL,
	[LastSignDate] [datetime] NULL,
	[WebAddress] [varchar](128) NULL,
	[CoveredCompany] [char](1) NULL,
	[BernsteinAnalyst] [dbo].[CompassID] NULL,
	[TickerSymbol] [varchar](max) NULL,
	[UnBundlingStatus] [varchar](32) NULL,
	[UnBundlingDate] [date] NULL,
	[UnBundlingNotes] [nvarchar](max) NULL,
	[MethodOfPaymentSource] [varchar](32) NULL,
	[MethodOfPaymentResearchTrackOn] [varchar](1) NULL,
	[InteractionSubmitBernstein] [varchar](1) NULL,
	[InteractionSubmitVendor] [varchar](64) NULL,
	[InteractionSubmitUsers] [varchar](max) NULL,
	[InteractionSubmitNotes] [nvarchar](max) NULL,
	[PayForResearchAgreedPrice] [decimal](18, 2) NULL,
	[PayForResearchAgreementType] [varchar](32) NULL,
	[PayForResearchAgreementDetail] [nvarchar](max) NULL,
	[MethodOfPaymentNotes] [varchar](max) NULL,
	[ModelAccessEnabled] [char](1) NULL,
	[ResearchQuotaEnabled] [char](1) NULL,
	[PublicationsPerMonth] [int] NULL,
	[PaymentFrequency] [varchar](64) NULL,
	[Timing] [varchar](64) NULL,
	[USBPSPrayer] [varchar](1) NULL,
	[VAT] [varchar](64) NULL,
	[VATNumber] [varchar](64) NULL,
	[PricingYear] [int] NULL,
	[IsVotingAccount] [char](1) NULL,
	[VendorEmail] [varchar](225) NULL,
PRIMARY KEY CLUSTERED 
(
	[AccountID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [FK_Acc_AddressID] FOREIGN KEY([AddressID])
REFERENCES [dbo].[Address] ([AddressID])
GO

ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [FK_Acc_AddressID]
GO

ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [FK_Acc_AltAddressID] FOREIGN KEY([AltAddressID])
REFERENCES [dbo].[Address] ([AddressID])
GO

ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [FK_Acc_AltAddressID]
GO

ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [FK_Acc_CreatedBy] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [FK_Acc_CreatedBy]
GO

ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [FK_Acc_LastModifiedBy] FOREIGN KEY([LastModifiedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [FK_Acc_LastModifiedBy]
GO

ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [FK_Account_CSAParentID] FOREIGN KEY([CSAParentID])
REFERENCES [dbo].[AccountParent] ([ParentID])
GO

ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [FK_Account_CSAParentID]
GO

ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [FK_Account_ReportParentID] FOREIGN KEY([ReportParentID])
REFERENCES [dbo].[AccountParent] ([ParentID])
GO

ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [FK_Account_ReportParentID]
GO


