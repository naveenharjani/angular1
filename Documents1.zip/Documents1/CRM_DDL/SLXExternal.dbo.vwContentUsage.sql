--[Sharmil 7/04/2016 ] vew to get content usage data
USE [SlxExternal]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwContentUsage]') AND type in (N'V'))
DROP VIEW [dbo].[vwContentUsage]
GO

CREATE View [dbo].[vwContentUsage]
AS

SELECT 
  U.ContentType CONTENT_TYPE,
  U.ContentSource CONTENT_SOURCE,
  U.UsageTime USAGETIME,   -- Date Accessed
  U.CreatedOn CREATEDATE,  -- Date Logged
  U.AccessMailAddr ACCESS_EMAIL_ADDR,
  U.SourceId SOURCEID,
  RVLS.Source,
  'STATUS'    = CASE U.STATUS    WHEN 1 THEN 'T' ELSE 'F' END,
  'FILEFOUND' = CASE U.FILEFOUND WHEN 1 THEN 'T' ELSE 'F' END,
  U.ServerName SERVER_NAME,
  'SOURCE_INTERNAL' = CASE U.SourceInternal WHEN 1 THEN 'T' ELSE 'F' END,
  E.EVENT_TYPE As EVENT_TYPE,
  E.NAME As NAME,
  --C.AccountID,
  C.ACCOUNT 
FROM dbo.UsageLogshipper U with (nolock)
INNER JOIN SalesLogix.sysdba.SCB_EVENT E with (nolock) ON E.SCB_EVENTID = U.ContentId
LEFT JOIN SV_CONTACT C with (nolock) ON C.ContactId = U.CONTACTID
--LEFT JOIN Compass.dbo.Contact CC ON c.CompContactId = cc.ContactID
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS with (nolock) ON RVLS.SourceId = U.SOURCEID

UNION

SELECT 
  U.ContentType CONTENT_TYPE,
  U.ContentSource CONTENT_SOURCE,
  U.UsageTime USAGETIME,   -- Date Accessed
  U.CreatedOn CREATEDATE,  -- Date Logged
  U.AccessMailAddr ACCESS_EMAIL_ADDR,
  U.SourceId SOURCEID,
  RVLS.Source,
  'STATUS'    = CASE U.STATUS    WHEN 1 THEN 'T' ELSE 'F' END,
  'FILEFOUND' = CASE U.FILEFOUND WHEN 1 THEN 'T' ELSE 'F' END,
  U.ServerName SERVER_NAME,
  'SOURCE_INTERNAL' = CASE U.SourceInternal WHEN 1 THEN 'T' ELSE 'F' END,
  E.Types  As EVENT_TYPE,
  E.NAME As NAME,
  --C.AccountID,
  C.ACCOUNT 
FROM dbo.UsageLogshipper U with (nolock)
INNER JOIN compass.dbo.Event E with (nolock) ON E.EVENTID = U.ContentId
LEFT join SV_CONTACT C with (nolock) ON C.ContactId = U.CONTACTID
--LEFT JOIN Compass.dbo.Contact CC ON c.CompContactId = cc.ContactID
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS with (nolock) ON RVLS.SourceId = U.SOURCEID


GO
GRANT SELECT ON [dbo].[vwContentUsage] TO [research_app_role]
-- Grant select to research_app_role to underlying tables (if owned by different user)
GRANT SELECT ON [dbo].[SV_CONTACT] TO [research_app_role]
GRANT SELECT ON dbo.RVLinkSources TO [research_app_role]
USE [SalesLogix]
GRANT SELECT ON [sysdba].[SCB_EVENT] TO  [research_app_role]

