--[Sharmil 6/28/2016 ] vew to get web usage data
USE [SlxExternal]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwWebUsage]') AND type in (N'V'))
DROP VIEW [dbo].[vwWebUsage]
GO


CREATE View [dbo].[vwWebUsage]
AS

SELECT 
  U.PUBNO,
  U.ACCESSDATE, -- Date Accessed
  U.CREATEDATE, -- Date Logged
  U.ACCESS_EMAIL_ADDR,
  U.SOURCEID,
  RVLS.Source,
  U.STATUS,
  U.FILEFOUND,
  U.SERVER_NAME,
  U.CONTENT_SOURCE,
  U.SOURCE_INTERNAL,
  RVD.Date, 
  RVD.Title
FROM 
(	
	Select PubNo, AccessDate, CreateDate, ACCESS_EMAIL_ADDR, SOURCEID, STATUS, FILEFOUND
	, SERVER_NAME, CONTENT_SOURCE, SOURCE_INTERNAL FROM
	SlxExternal.dbo.webusage U with (nolock)
	UNION ALL
	Select ContentId, AccessDate, CreatedOn, LoginId, SOURCEID
	, CASE WHEN STATUS IN (100,101) THEN 'T' ELSE 'F' END as Status
	, CASE WHEN ContentId IN (0) THEN 'F' ELSE 'T' END as FILEFOUND
	, SERVERNAME, CONTENTSOURCE, CASE WHEN SourceInternal IN (1) THEN 'T' ELSE 'F' END as SourceInternal FROM
	SlxExternal.dbo.ContentUsage U with (nolock) WHERE ContentTypeId = 'R'

 ) U
LEFT JOIN SlxExternal.dbo.RVDocuments RVD with (nolock)  ON RVD.DocId = U.PUBNO
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS with (nolock) ON RVLS.SourceId = U.SOURCEID
--$WHERE
--ORDER BY ACCESSDATE DESC

GO
GRANT SELECT ON [dbo].[vwWebUsage] TO [research_app_role]
GRANT SELECT ON [dbo].[vwWebUsage] TO [br_app_role]
GO


