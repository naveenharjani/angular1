--[Sharmil 7/5/2016 ] view to get Unique Read Details from WebUsage, RVDocuments, RVAltDocuments table
USE [SlxExternal]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwReadDetails]') AND type in (N'V'))
DROP VIEW [dbo].[vwReadDetails]
GO

--Research

CREATE VIEW [dbo].[vwReadDetails]
AS

SELECT
  SWU.PUBNO,
  SWU.ACCESSDATE,
  SWU.ACCESS_EMAIL_ADDR,
  --C.ACCOUNT,
  A.AccountName as ACCOUNT,
  D.Title AS Title,
  SWU.SOURCEID,
  CASE SWU.SOURCEID
    WHEN 0  THEN 'Analyst Blast'
    WHEN 1  THEN 'Morning Summary'
    WHEN 2  THEN 'Cart'
    WHEN 10 THEN 'bernsteinresearch.com'
    ELSE 'Other'
  END AS SOURCE
FROM ( 
 Select ContactId, PubNo, AccessDate, ACCESS_EMAIL_ADDR, SOURCEID from
 SlxExternal.dbo.WebUsage SWU with (nolock) where filefound IN ('Y','T') and pubno != '99999999'
 UNION
 Select ContactId, ContentId, AccessDate, LoginId, SOURCEID from
 SlxExternal.dbo.ContentUsage SWU with (nolock) where ContentTypeId = 'R' AND STATUS IN ('100','101')
 ) SWU
--INNER JOIN Compass.dbo.CONTACT C on C.CONTACTID = SWU.CONTACTID
INNER JOIN SlxExternal.dbo.SV_Contact C with (nolock) on C.CONTACTID = SWU.CONTACTID
INNER JOIN SlxExternal.dbo.RVDocuments D with (nolock) ON D.docid = SWU.PUBNO
INNER JOIN Compass.dbo.Account A with (nolock) on C.AccountId = A.AccountID or C.AccountID = ISNULL(A.SLXACCOUNTID,'')
WHERE ISNULL(A.TYPE, '') NOT LIKE '%press%' AND ISNULL(A.TYPE, '') NOT LIKE '%Industry%' AND ISNULL(A.TYPE, '') NOT LIKE '%Internal%'
-- Use the SLX view to get the required contacts for each research document
/*
INNER JOIN SlxExternal.dbo.vwUniqueReaders UR with (nolock) on UR.PUBNO = SWU.PUBNO AND (UR.SLXContactID = SWU.CONTACTID or UR.ContactID = SWU.CONTACTID )
INNER JOIN Compass.dbo.Account A with (nolock) on C.AccountId = A.SLXAccountID
*/
--WHERE SWU.PUBNO = {0}


--UNION

---- Non-research

--SELECT
--  SWU.PUBNO,
--  SWU.ACCESSDATE,
--  SWU.ACCESS_EMAIL_ADDR,
--  --C.ACCOUNT,
--  A.AccountName,
--  D.Title AS Title,
--  SWU.SOURCEID,
--  CASE SWU.SOURCEID
--    WHEN 0  THEN 'Analyst Blast'
--    WHEN 1  THEN 'Morning Summary'
--    WHEN 2  THEN 'Cart'
--    WHEN 10 THEN 'bernsteinresearch.com'
--    ELSE 'Other'
--  END AS SOURCE
--FROM SlxExternal.dbo.WebUsage SWU
----INNER JOIN Compass.dbo.CONTACT C on C.CONTACTID = SWU.CONTACTID
--INNER JOIN SlxExternal.dbo.SV_Contact C with (nolock) on C.CONTACTID = SWU.CONTACTID
--INNER JOIN SlxExternal.dbo.RVAltDocuments D with (nolock) ON D.docid = SWU.PUBNO
---- Use the SLX view to get the required contacts for each research document
--INNER JOIN SlxExternal.dbo.vwUniqueReaders UR with (nolock) on UR.PUBNO = SWU.PUBNO AND (UR.SLXContactID = SWU.CONTACTID or UR.ContactID = SWU.CONTACTID )
--INNER JOIN Compass.dbo.Account A with (nolock) on C.AccountId = A.AccountId
--WHERE SWU.PUBNO = {0}
--ORDER BY ACCESSDATE DESC


GO
GRANT SELECT ON [dbo].[vwReadDetails] TO [research_app_role]
GO





