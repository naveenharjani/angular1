
--This procedures returns emails of contacts for the analyst sector(s). 
--This is used to send email blast of analyst publications from BR.com.

--GetDistribution '''IND0000000000095'''

--GetDistribution '''IND0000000000095'',''IND0000000000179'''
--Modified By Mitesh Saraf 2016-11-17- Suppress contacts with blank emails as discussed with Krishna J
--[Sharmil 5/16] : updated procedure to get research preference records from contact service table.
--[Mitesh 10/18/2018] : Added nolock to Contact and Account table to avoid deadlocks on sync jobs


use [SlxExternal]
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetDistribution]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetDistribution]
GO

CREATE PROCEDURE [dbo].[GetDistribution]
 @IndustryID varchar(1024),
 @excludePI char(1) = Null  -- for excluding press and industry contacts
AS  
	BEGIN  
	 -- SET NOCOUNT ON added to prevent extra result sets from  
	 -- interfering with SELECT statements.  
	 Declare @strSQL  varchar(1024)  
	 Declare @strEmailSuffix char(1)  
	   
	 if (charindex('_DEV',@@servername) > 0 or charindex('_qa',@@servername) > 0)  select @strEmailSuffix = 'X'    
	 else select @strEmailSuffix = ''  

	/*select @strSQL = 'SELECT distinct c.lastname, c.firstname, ''' + @strEmailSuffix + ''' + + c.email   
			as email from compass.dbo.Contact C  
			LEFT JOIN compass.dbo.Account A ON C.AccountID = A.AccountID
			WHERE isnull(A.STATUS,'''') = ''T''
			AND isNull(c.email,	'''') != ''''
			AND ( EXISTS ( SELECT DISTINCT CONTACTID FROM 
			compass.dbo.ResearchPreference R with (nolock) WHERE R.CONTACTID = C.CONTACTID AND R.IndustryID in (' + @IndustryID + ')
			AND R.HasEmail = ''T'') )'*/

			select @strSQL = 'SELECT distinct c.lastname, c.firstname, ''' + @strEmailSuffix + ''' + + c.email   
			as email from compass.dbo.Contact C (nolock) 
			LEFT JOIN compass.dbo.Account A (nolock) ON C.AccountID = A.AccountID
			WHERE isnull(A.STATUS,'''') = ''T''
			AND isNull(c.email,	'''') != ''''
			AND ( EXISTS ( SELECT DISTINCT CONTACTID FROM 
			compass.dbo.ContactServices R with (nolock) WHERE R.CONTACTID = C.CONTACTID AND R.ServiceID in (' + @IndustryID + ')
			AND R.HasOptedEmail = ''T''  and R.ServiceType = ''Research'' and isnull(c.Status, ''T'') = ''T'' and isnull(R.ServiceStatus, ''T'') = ''T'')   )'

			

	If @excludePI is not null
		begin 
			select @strsql = @strsql + ' and a.type not in ( ''Press'',''Industry'') '
		end

	select @strsql = @strsql + ' order by email'  
   
	  print @strsQL  
	  Execute (@strSQL)  
 
	END 
GO
GRANT EXECUTE ON [dbo].[GetDistribution] TO [research_app_role]
GRANT EXECUTE ON [dbo].[GetDistribution] TO [compass_app_role]

