USE [SlxExternal]
GO

/****** Object:  Table [dbo].[ContentUsage]    Script Date: 12/17/2018 8:12:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ContentUsage](
	[UsageId] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[LoginId] [varchar](128) NULL,
	[ContactId] [varchar](16) NULL,
	[ContentTypeId] [char](1) NULL,
	[ContentId] [int] NULL,
	[Status] [int] NULL,
	[AuthenticationCheck] [bit] NULL,
	[EntitlementCheck] [bit] NULL,
	[QuotaCheck] [bit] NULL,
	[SourceId] [int] NULL,
	[ContentSource] [varchar](120) NULL,
	[SourceInternal] [bit] NULL,
	[AccessDate] [datetime] NULL,
	[LogDate] [datetime] NULL,
	[UserHost] [varchar](60) NULL,
	[UserAgent] [varchar](300) NULL,
	[ServerName] [varchar](90) NULL,
	[EncryptedPayload] [varchar](max) NULL,
	[DecryptedPayload] [varchar](max) NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [varchar](12) NULL,
PRIMARY KEY NONCLUSTERED 
(
	[UsageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


