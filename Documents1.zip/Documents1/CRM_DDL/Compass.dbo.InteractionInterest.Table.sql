--[Muzeeb 11/09/2016] Created the Table
--[Sharmil 11/30/2016] merged both CallReportAttendeeClient and CallReportAttendeeInternal to CallReportAttendee.
--[sharmil 1/13/2017] changed name of the table to InteractionsAttendee
USE Compass  
IF OBJECT_ID('dbo.InteractionInterest', 'U') IS NOT NULL
DROP TABLE dbo.[InteractionInterest]
Go
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ARITHABORT ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[InteractionInterest](
	[InteractionInterestID]  AS ('ISA'+right('000000000000'+CONVERT([varchar](13),[ISID]),(13))) PERSISTED NOT NULL,
	[InteractionsID] [varchar](16) NOT NULL,
	[SFCallReportID] [dbo].[SFID] NULL,
	[SFInteractionInterestID] [dbo].[SFID] NULL,
	[InterestSubjectId] [dbo].[CompassID] NULL,
	[InterestSubjectName] [varchar](max) NULL,
	[InterestSubjectType] [varchar](100) NULL,
	[Source] [varchar](100) NULL,
	[ISID] [int] IDENTITY(1,1) NOT NULL,
	[CreatedBy] [dbo].[CompassID] NOT NULL,
	[LastModifiedBy] [dbo].[CompassID] NOT NULL,
	[LastModifiedOn] [datetime] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[InteractionInterestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


ALTER TABLE [dbo].[InteractionInterest]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionInterest_CreatedBy] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[InteractionInterest] NOCHECK CONSTRAINT [FK_InteractionInterest_CreatedBy]
GO

ALTER TABLE [dbo].[InteractionInterest]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionInterest_InteractionID] FOREIGN KEY([InteractionsID])
REFERENCES [dbo].[Interactions] ([InteractionsID])
GO

ALTER TABLE [dbo].[InteractionInterest] NOCHECK CONSTRAINT [FK_InteractionInterest_InteractionID]
GO

ALTER TABLE [dbo].[InteractionInterest]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionInterest_InteractionSubjectID] FOREIGN KEY([InterestSubjectId])
REFERENCES [dbo].[InterestSubject] ([InterestSubjectID])
GO

ALTER TABLE [dbo].[InteractionInterest] NOCHECK CONSTRAINT [FK_InteractionInterest_InteractionSubjectID]
GO

ALTER TABLE [dbo].[InteractionInterest]  WITH NOCHECK ADD  CONSTRAINT [FK_InteractionInterest_LastModifiedBy] FOREIGN KEY([LastModifiedBy])
REFERENCES [dbo].[Users] ([UserID])
GO

ALTER TABLE [dbo].[InteractionInterest] NOCHECK CONSTRAINT [FK_InteractionInterest_LastModifiedBy]
GO

CREATE NONCLUSTERED INDEX [ix_InteractionInterest_CreatedBy] ON [dbo].[InteractionInterest]
(
	[CreatedBy] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO


CREATE NONCLUSTERED INDEX [ix_InteractionInterest_InteractionsID] ON [dbo].[InteractionInterest]
(
	[InteractionsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [ix_InteractionInterest_InterestSubjectId] ON [dbo].[InteractionInterest]
(
	[InterestSubjectId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [ix_InteractionInterest_LastModifiedBy] ON [dbo].[InteractionInterest]
(
	[LastModifiedBy] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[InteractionInterest] TO [compass_app_role]
GO
GRANT SELECT ON [dbo].[InteractionInterest] TO [research_app_role]
GO

