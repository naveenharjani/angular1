use [SlxExternal]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetReadership]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetReadership]
GO

CREATE PROCEDURE [dbo].[GetReadership]
AS	
BEGIN
	SET NOCOUNT ON

	declare @Admin as varchar(16)
	select @Admin  = UserID  from compass.dbo.users where NTID = 'ADMIN'

  DECLARE @DELTADATE DATE
  SET @DELTADATE = CONVERT(DATE,DATEADD(yy,-1,GETDATE()))

	--Insert web usage and Content usage 
	insert into slxexternal.dbo.Readership
	(
		[PubNo] ,
		[ContactID], 
		[ContactName],
		[AccountID],
		[AccountName],
		[AccountType],
		[SFContactID],
		[SFAccountID] ,
		Email,
		[ReadDate] ,
		[Source] ,
		[Type] ,
		[CreatedOn],
		[CreatedBy]
	)

	Select distinct sw.pubno, c.ContactID, C.ContactName
		, c.AccountID
		, A.AccountName
		, isnull(ActType.ClientFlag, 'Other')
		, c.SFContactID
		, a.SFAccountID
		, sw.Email
		, sw.ACCESSDATE
		, s.Source
		, 'ResearchUsage'
		,GETUTCDATE(), @Admin
 from
 (
	 Select WebUsageId, ContactID, PUBNO, Convert(date,AccessDate) as AccessDate, sourceid, Status, FileFound, numofaccess, access_email_addr as email
	 , domain_name, streamer
	 , ROW_NUMBER() OVER (PARTITION BY ContactID, PubNo, Convert(date,AccessDate) ORDER BY AccessDate) as RowNo
	 from
		(
			Select webUsageid, contactid, pubno, status, ACCESSDATE, numofaccess
				, access_email_addr, domain_name, filefound, sourceid, 'WebUsage' as Streamer
				from slxexternal.dbo.webusage (nolock) where filefound IN ('Y','T') and pubno != '99999999' and ACCESSDATE >= @DELTADATE
			UNION
			Select UsageId, contactid, ContentId, 'T', ACCESSDATE, 1
				, loginid, UserHost, 'T', sourceid, 'ContentUsage' as Streamer
				from slxexternal.dbo.ContentUsage (nolock) where ContentTypeId = 'R' AND STATUS IN ('100','101') and ACCESSDATE >= @DELTADATE
		) TOT
 ) SW 
		 inner join slxexternal.dbo.sv_contact sc on sw.contactid = sc.contactid
		 inner join compass.dbo.contact c with (nolock) on c.contactid = sc.compcontactId
		 inner join compass.dbo.account a with (nolock) on c.AccountID = a.AccountID
		 left JOIN SlxExternal.dbo.RVLinkSources s with (NOLOCK) on SW.SOURCEID = s.SourceId
		 left outer join SLXExternal.dbo.ServicePointAccountType ActType on ActType.AccountType = a.Type
		 where RowNo = 1 AND NOT EXISTS (SELECT 1 FROM slxexternal.dbo.Readership(nolock) sr where ReadDate >= @DELTADATE and Type = 'ResearchUsage' and 
		  c.contactid = sr.contactid and LTRIM(ISNULL(sw.pubno,'')) = LTRIM(ISNULL(sr.pubno,''))
		  and sw.ACCESSDATE = sr.ReadDate)


	--Insert Portal Usage 


	insert into slxexternal.dbo.Readership
	(
		[PubNo] ,
		[ContactID], 
		[ContactName],
		[AccountID] ,
		[AccountName],
		[AccountType],
		[SFContactID],
		[SFAccountID],
		Email,
		[ReadDate] ,
		[Source] ,
		[Type] ,
		[CreatedOn],
		[CreatedBy])
	   select  DISTINCT pu.PubNo, c.ContactID, c.ContactName, a.AccountID, a.AccountName, isnull(ActType.ClientFlag, 'Other'), c.SFContactID,a.SFAccountID, Pu.Email, ReadDate, PMap.UsageName Source, 'PortalUsage' Type
		,GETUTCDATE(), @Admin
      from 
		(Select distinct 
			  P.Pubno
	 		, P.Site
			, CONVERT(date,P.READDATE) AS [READDATE]
			, substring(P.ContactID, 1, (case when charIndex('@', P.ContactID) = 0 then len(P.ContactID) else charIndex('@', P.ContactID) - 1 end)) as ContactID
			--, P.Contact
			, P.Email
			--, P.AccountID
			--, P.Account
		from slxexternal.dbo.RVPortalUsage P with (nolock) where ReadDate >= '2016-01-01')pu	
	left outer join
	(select 'Bloomberg (SANB)' as UsageName, 'Bloomberg' as EntitlementName
	union select 'Reuters', 'Reuters'  
	 --union select 'Reuters', 'Thomson' 
	 union select 'FactSet', 'FactSet'  
	 union select 'CapitalIQ', 'Capital IQ' 
	 union select 'TheMarkets.com', 'TMC' 
	 union select 'AB','AB'
	 union select 'BlueMatrix', 'BlueMatrix'
	 union select 'RSRCHX', 'RSRCHX'
	 union select 'Red Deer', 'Red Deer'
	 union select 'ONEaccess', 'Visible Alpha/ONEaccess'
	 union select 'ONEaccess', 'Visible Alpha'
	 union select 'Thomson Reuters', 'Thomson'
	 union select 'Thomson Reuters', 'Reuters'
	) PMap on PMap.UsageName = pu.Site 
	left outer join 
	compass.dbo.ContactServices cs with (nolock) on cs.ServiceType = 'PortalEntitlement' and cs.ServiceName = Pmap.EntitlementName and cs.ServiceID = pu.ContactId
	inner join compass.dbo.contact c with (nolock) on cs.ContactID = c.ContactID  
	inner join compass.dbo.account a with (nolock) on c.AccountID = A.AccountID
	left outer join SLXExternal.dbo.ServicePointAccountType ActType on ActType.AccountType = a.Type
	where NOT EXISTS (SELECT 1 FROM slxexternal.dbo.Readership(nolock) sr where ReadDate >= '2016-01-01' and Type = 'PortalUsage' and 
		  c.contactid = sr.contactid and LTRIM(ISNULL(pu.pubno,'')) = LTRIM(ISNULL(sr.pubno,''))
		  and pu.ReadDate = CONVERT(date,sr.ReadDate) 
		  AND LTRIM(ISNULL(PMap.UsageName,'')) = LTRIM(ISNULL(sr.SOURCE,'')))	
END
GO

GRANT EXECUTE ON [dbo].[GetReadership] TO [research_app_role]
GRANT EXECUTE ON [dbo].[GetReadership] TO [compass_app_role]

GO