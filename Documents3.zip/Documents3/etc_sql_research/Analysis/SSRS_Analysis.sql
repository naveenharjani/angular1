-- SSRS_Analysis.sql
-- 11/30/2016

USE ReportServer
GO

-- select * from Catalog
-- select * from Subscriptions

-- Subscriptions w/ schedule is not readily available

-- Subscriptions w/o schedule
SELECT
  --convert(S.LastRunTime,),
  C.Name AS ReportName,
  C.Description,
  Convert(XML,S.[ExtensionSettings]).value('(//ParameterValue/Value[../Name="Subject"])[1]','nvarchar(200)') as [Subject],
  Convert(XML,S.[ExtensionSettings]).value('(//ParameterValue/Value[../Name="TO"])[1]','nvarchar(200)') as [To],
  Convert(XML,S.[ExtensionSettings]).value('(//ParameterValue/Value[../Name="CC"])[1]','nvarchar(200)') as [Cc],
  S.LastRunTime,
  C.CreationDate, S.InactiveFlags, S.*
FROM [dbo].[Catalog] C
LEFT JOIN [Subscriptions] S ON S.Report_OID = C.ItemID
WHERE C.Type = 2   -- Reports
AND DATEDIFF(d, S.LastRunTime, getdate()) <= 180  -- Active report subscriptions in last 31 days
--AND Convert(XML,S.[ExtensionSettings]).value('(//ParameterValue/Value[../Name="TO"])[1]','nvarchar(200)') LIKE '%abglobal.com%'
--AND Convert(XML,S.[ExtensionSettings]).value('(//ParameterValue/Value[../Name="CC"])[1]','nvarchar(200)') LIKE '%abglobal.com%'
ORDER BY 1, 3 --C.CreationDate
GO


-- Subscriptions w/ last run info
SELECT
  C.Name AS ReportName,
  C.Description,
  Convert(XML,S.[ExtensionSettings]).value('(//ParameterValue/Value[../Name="Subject"])[1]','nvarchar(200)') as [Subject],
  Convert(XML,S.[ExtensionSettings]).value('(//ParameterValue/Value[../Name="TO"])[1]','nvarchar(200)') as [To],
  Convert(XML,S.[ExtensionSettings]).value('(//ParameterValue/Value[../Name="CC"])[1]','nvarchar(200)') as [Cc],
  C.CreationDate,
  S.LastRunTime,
  DATENAME(dw, S.LastRunTime) AS 'LastReportRunDay',
  CONVERT(VARCHAR(8),S.LastRunTime,108) AS 'LastReportRunTime',
  S.DeliveryExtension,
  Sch.DaysInterval, Sch.DaysOfMonth, Sch.DaysOfWeek, Sch.MinutesInterval, Sch.MonthlyWeek, Sch.ScheduledRunTimeout,
  Sch.NextRunTime, Sch.Month, Sch.StartDate, Sch.EndDate, RS.ReportAction, S.LastStatus 
FROM [dbo].[Catalog] C
LEFT JOIN [Subscriptions] S ON S.Report_OID = C.ItemID
LEFT JOIN [ReportSchedule] RS ON RS.SubscriptionID = S.SubscriptionID
LEFT JOIN [Schedule] Sch ON Sch.ScheduleID = RS.ScheduleID
WHERE C.Type = 2   -- Reports
AND DATEDIFF(d, S.LastRunTime, getdate()) <= 31  -- Active report subscriptions in last 31 days
--AND DATEDIFF(d, S.LastRunTime, getdate()) > 31   -- Inactive report subscriptions
ORDER BY S.LastRunTime, C.CreationDate
GO

-- There are SQL Agent System procs that derive the job/report schedule info as per the various fields in the Schedule table