-- DropAnalysis.sql
-- 10/04/2017

-- Show reports with portal reads that occurred after ticker dropped date
SELECT P.PubNo, P.Date AS ReportDate,
       S.Ticker, RC.DropDate,
	   DS.Site, PU.ReadDate, PU.Email
FROM Publications P
JOIN Properties Pr ON Pr.PubNo = P.PubNo 
JOIN Securities2 S ON Pr.PropValue = S.Ticker
JOIN ResearchCoverage RC ON RC.SecurityId = S.SecurityId
JOIN PortalUsage PU ON PU.PubNo = P.PubNo
JOIN DistributionSites DS ON DS.SiteId = PU.SiteId
WHERE Pr.PropId = 13  --Ticker
--AND   RC.DropDate IS NOT NULL
AND   RC.DropDate >= '01/01/2017'    -- tickers dropped this year
--AND   S.Ticker IN ('1072.HK', '600875.CH', 'DRX.LN', '3337.HK', '1251.HK')  -- last 5 dropped tickers
AND CONVERT(date, PU.ReadDate) > RC.DropDate   -- portal reads after ticker drop date
ORDER BY RC.DropDate DESC, P.Date DESC

/*
-- Get dropped tickers list
SELECT TOP 20 RC.SecurityId, S.Ticker, S.Company, RC.DropDate 
FROM ResearchCoverage RC
JOIN Securities2 S ON RC.SecurityId = S.SecurityId
WHERE RC.DropDate IS NOT NULL
ORDER BY RC.DropDate desc
*/	