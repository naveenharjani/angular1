use BernsteinResearch
go
/* DETAIL DATA */
PRINT 'DETAIL DATA'
--LOGIN PROMPTS
select Convert(varchar(11),ActivityTime),* from BernsteinResearch.dbo.BRSiteActivity
where source = 'ViewLogin.aspx' and ActivityInfo like '%<info>Password-Prompt</info>%' and ActivityInfo like '%viewresearch.aspx%' and ActivityInfo like '%<urlHasDownloadId></urlHasDownloadId>%'
and ActivityTime >= '07/09/2018'
order by ActivityTime desc

--ALREADY HAVE PASSWORD
select Convert(varchar(11),ActivityTime),* from BernsteinResearch.dbo.BRSiteActivity
where source = 'ViewLogin.aspx' and ActivityInfo like '%<info>Password-LoginSuccess</info>%' and ActivityInfo like '%viewresearch.aspx%' and ActivityInfo like '%<urlHasDownloadId></urlHasDownloadId>%'
and ActivityTime >= '07/09/2018'

--FORGOT PASSWORD
select Convert(varchar(11),ActivityTime),* from BernsteinResearch.dbo.BRSiteActivity
where source = 'ForgotPassword.aspx' and ActivityInfo like '%<info>Password-Requested</info>%' and ActivityInfo like '%viewresearch.aspx%' and ActivityInfo like '%<urlHasDownloadId></urlHasDownloadId>%'
and ActivityTime >= '07/09/2018' 

--PASSWORD COMPLETED
select Convert(varchar(11),ActivityTime),* from BernsteinResearch.dbo.BRSiteActivity
where source = 'NewPassword.aspx' and ActivityInfo like '%<info>Password-Completed</info>%' and ActivityInfo like '%viewresearch.aspx%' and ActivityInfo like '%<urlHasDownloadId></urlHasDownloadId>%'
and ActivityTime >= '07/09/2018' 

/* -- SUMMARY DATA -- */
PRINT 'SUMMMARY DATA'

create table #TmpActivity
(ActionType varchar(30),
ActivityDate datetime,
ClickCount	int)
go
--PASSWORD PROMPTS
insert into #TmpActivity(ActionType,ActivityDate,ClickCount)
select 'Login Prompts' ActionType, Convert(varchar(11),ActivityTime),count(*) 
from BernsteinResearch.dbo.BRSiteActivity
where source = 'ViewLogin.aspx' and ActivityInfo like '%<info>Password-Prompt</info>%' and ActivityInfo like '%viewresearch.aspx%' and ActivityInfo like '%<urlHasDownloadId></urlHasDownloadId>%'
and ActivityTime >= '06/29/2018'
group by Convert(varchar(11),ActivityTime)

--ALREADY HAVE PASSWORD
insert into #TmpActivity(ActionType,ActivityDate,ClickCount)
select 'Already have password', Convert(varchar(11),ActivityTime),count(*) 
from BernsteinResearch.dbo.BRSiteActivity
where source = 'ViewLogin.aspx' and ActivityInfo like '%<info>Password-LoginSuccess</info>%' and ActivityInfo like '%viewresearch.aspx%' and ActivityInfo like '%<urlHasDownloadId></urlHasDownloadId>%'
and ActivityTime >= '06/29/2018'
group by Convert(varchar(11),ActivityTime)

--FORGOT PASSWORD
insert into #TmpActivity(ActionType,ActivityDate,ClickCount)
select 'Forgot Password', Convert(varchar(11),ActivityTime),count(*)  
from BernsteinResearch.dbo.BRSiteActivity
where source = 'ForgotPassword.aspx' and ActivityInfo like '%<info>Password-Requested</info>%' and ActivityInfo like '%viewresearch.aspx%' and ActivityInfo like '%<urlHasDownloadId></urlHasDownloadId>%'
and ActivityTime >= '06/29/2018'
group by Convert(varchar(11),ActivityTime)

--PASSWORD COMPLETED
insert into #TmpActivity(ActionType,ActivityDate,ClickCount)
select 'Password established', Convert(varchar(11),ActivityTime),count(*)  
from BernsteinResearch.dbo.BRSiteActivity
where source = 'NewPassword.aspx' and ActivityInfo like '%<info>Password-Completed</info>%' and ActivityInfo like '%viewresearch.aspx%' and ActivityInfo like '%<urlHasDownloadId></urlHasDownloadId>%'
and ActivityTime >= '06/29/2018'
group by Convert(varchar(11),ActivityTime)

/*
--update Login Prompts count to remove duplicate browser prompts and duplicate device prompts 
update #TmpActivity
set Count = Count - (select Count from #TmpActivity where ActionType = 'Already have password')
from 
where ActionType = 'Login Prompts' 
*/


PRINT 'PIVOT DATA'
--pivot data
SELECT *
FROM #TmpActivity
  PIVOT(SUM(ClickCount) 
  FOR ActivityDate IN([06/29/2018],[07/02/2018],[07/03/2018],[07/04/2018],[07/05/2018],[07/06/2018],[07/07/2018],[07/08/2018],[07/09/2018],[07/10/2018],[07/11/2018])
  ) AS PivotCount;

go
drop table #TmpActivity
go
