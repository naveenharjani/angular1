-- PortalUsageActivity.sql
-- 12/12/2017

-- For the last 4 months of portal usage data that was loaded, 
-- Monitor most reads by UserId, DeliveryType for each portal 

DECLARE @StartDate datetime, 
        @EndDate   datetime

set @StartDate = '10/01/2017'
set @EndDate   = '10/30/2017'

print '*** List Contacts with #Reads >= 250 total'
select ds.Site, pu.Contact, pu.ContactId, pu.Account, count(*) as TotalReads
from PortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
--where ReadDate between @StartDate and @EndDate
where ReadDate between '09/01/2017' and '09/30/2017'
 and ( [Contact] <> 'N/A' AND [Contact] <> '***' AND [Contact] <> 'Restricted' AND [Contact] <> 'Unattributed')
 --and Site = 'CapitalIQ'
 --and Site = 'Reuters'
group by ds.Site, pu.Contact, pu.ContactId, pu.Account
having count(*) >= 250
order by count(*) desc

print '*** List Reads by Contacts with #Reads >= 35 per day'
select ds.Site, pu.Contact, pu.ContactId, pu.Account, CONVERT(date, pu.ReadDate) AS ReadDate, count(*) AS ReadsPerDay
from PortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
where ReadDate between @StartDate and @EndDate
 and ( [Contact] <> 'N/A' AND [Contact] <> '***' AND [Contact] <> 'Restricted' AND [Contact] <> 'Unattributed')
--where ReadDate between '08/01/2017' and '11/30/2017'
 --and ( [ContactId] in ('yeetin.chau@2996', 'ernest.chow1@61559', '4928', '151024', 'w.giles@18735', 'james.hubbard@6246', '631531'))
 --and Site = 'CapitalIQ'
 --and Site = 'Reuters'
group by ds.Site, pu.Contact, pu.ContactId, pu.Account, CONVERT(date, pu.ReadDate)
HAVING count(*) >= 30
--order by CONVERT(date, pu.ReadDate) desc
order by count(*) desc

print '*** List Delivery Type with most Reads'
select ds.Site, Delivery, count(*) as TotalReads
from PortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
--where ReadDate between @StartDate and @EndDate
where ReadDate between '10/01/2017' and '10/31/2017'
group by ds.Site, Delivery
order by count(*) desc

print '*** List Reads for Delivery Type = NASDAQ, AlphaSense, Sentieo'
select ds.Site, pu.Delivery, pu.ReadDate, pu.ContactId, pu.Account, pu.FirmType
from PortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
where ReadDate between @StartDate and @EndDate
--where ReadDate between '08/01/2017' and '11/30/2017'
and Delivery IN ('NASDAQ', 'AlphaSense', 'Sentieo')
order by pu.ReadDate desc

print '*** List Distribution Sites with ProductGroup, RixmlEntitlement, PortalProductGroupCode'
select 
DS.Site, PG.ProductGroupId, PG.ProductGroupName,
DE.RixmlEntitlement,
'' AS PortalProductGroupCode, -- Get from Portals
DS.SiteId, DE.PublicationTypeId, DE.EntitlementId
from DistributionEntitlements DE
join ProductGroups PG on PG.ProductGroupId = DE.ProductGroupId
join DistributionSites DS on DS.SiteId = DE.SiteId
where DS.Active = -1

/*
-- ALL product group set at Subscription level
select DSU.*, DSI.*
from DistributionSubscriptions DSU
join DistributionSites DSI on DSI.SiteId = DSU.SiteId
where RixmlEntitlement is not null
--and DSU.Active = -1
order by DSU.SiteId, RixmlEntitlement
*/