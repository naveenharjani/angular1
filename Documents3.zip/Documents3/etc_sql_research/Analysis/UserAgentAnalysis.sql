-- UserAgentAnalysis.sql
-- 01/31/2013

/*  SLX PRD query - SLXPRDDB\SALGX_PRD,16083  */

SELECT COUNT(*), USER_AGENT FROM sysdba.SCB_WEB_USAGE        GROUP BY USER_AGENT ORDER BY 1 DESC
SELECT COUNT(*), USER_AGENT FROM sysdba.SCB_USAGE_LOGSHIPPER GROUP BY USER_AGENT ORDER BY 1 DESC

SELECT top 1000 * FROM sysdba.SCB_WEB_USAGE WHERE USER_AGENT IS NOT NULL AND ACCESSDATE > '02/03/2012 18:13' ORDER BY ACCESSDATE ASC

SELECT COUNT(*), USER_AGENT FROM sysdba.SCB_WEB_USAGE WHERE USER_AGENT LIKE '%android%' GROUP BY USER_AGENT ORDER BY 1 DESC
SELECT COUNT(*), USER_AGENT FROM sysdba.SCB_WEB_USAGE WHERE USER_AGENT LIKE '%iphone%'  GROUP BY USER_AGENT ORDER BY 1 DESC
SELECT COUNT(*), USER_AGENT FROM sysdba.SCB_WEB_USAGE WHERE USER_AGENT LIKE '%ipad%'    GROUP BY USER_AGENT ORDER BY 1 DESC
SELECT COUNT(*), USER_AGENT FROM sysdba.SCB_WEB_USAGE WHERE USER_AGENT LIKE '%MSIE%'    GROUP BY USER_AGENT ORDER BY 1 DESC
SELECT COUNT(*), USER_AGENT FROM sysdba.SCB_WEB_USAGE WHERE USER_AGENT LIKE '%Firefox%' GROUP BY USER_AGENT ORDER BY 1 DESC
SELECT COUNT(*), USER_AGENT FROM sysdba.SCB_WEB_USAGE WHERE USER_AGENT LIKE '%chrome%'  GROUP BY USER_AGENT ORDER BY 1 DESC
SELECT COUNT(*), USER_AGENT FROM sysdba.SCB_WEB_USAGE WHERE USER_AGENT LIKE '%safari%'  GROUP BY USER_AGENT ORDER BY 1 DESC

-- BernsteinResearch app
select USER_AGENT, ACCESSDATE, * from sysdba.SCB_WEB_USAGE where USER_AGENT LIKE 'IPAD%' order by 1, 2 desc

-- By: Browser, Browser version, OS, device
SELECT
  Count(*)                                                                         AS [Total],
  --Browser
  SUM(CASE WHEN USER_AGENT LIKE '%MSIE 9.0; Windows NT 6.1%'    THEN 1 ELSE 0 END) AS [MSIE9.x],
  SUM(CASE WHEN USER_AGENT LIKE '%MSIE 8.0; Windows NT 5.1%'    THEN 1 ELSE 0 END) AS [MSIE8.x],
  SUM(CASE WHEN USER_AGENT LIKE '%MSIE 4.01; Windows NT%'       THEN 1 ELSE 0 END) AS [MSIE4.x],
  SUM(CASE WHEN USER_AGENT LIKE '%Firefox/11.%'                 THEN 1 ELSE 0 END) AS [Firefox11.x],
  SUM(CASE WHEN USER_AGENT LIKE '%Firefox/10.%'                 THEN 1 ELSE 0 END) AS [Firefox10.x],
  SUM(CASE WHEN USER_AGENT LIKE '%Firefox/9.%'                  THEN 1 ELSE 0 END) AS [Firefox9.x],
  SUM(CASE WHEN USER_AGENT LIKE '%Firefox/8.%'                  THEN 1 ELSE 0 END) AS [Firefox8.x],
  SUM(CASE WHEN USER_AGENT LIKE '%Firefox/7.%'                  THEN 1 ELSE 0 END) AS [Firefox7.x],
  --SCB App - iPad/iPhone
  SUM(CASE WHEN USER_AGENT = 'IPAD,appver:1.0.2'                THEN 1 ELSE 0 END) AS [iPad_App_1.0.2],
  SUM(CASE WHEN USER_AGENT = 'IPAD,appver:1.0.1'                THEN 1 ELSE 0 END) AS [iPad_App_1.0.1],
  SUM(CASE WHEN USER_AGENT = 'IPAD,appver:1.0'                  THEN 1 ELSE 0 END) AS [iPad_App_1.0],
  SUM(CASE WHEN USER_AGENT LIKE '%IPAD SIMULATOR%'              THEN 1 ELSE 0 END) AS [iPad_App_Simulator],
  SUM(CASE WHEN USER_AGENT = 'IPHONE,appver:1.0.2'              THEN 1 ELSE 0 END) AS [iPhone_App_1.0.2],
  SUM(CASE WHEN USER_AGENT = 'IPHONE,appver:1.0'                THEN 1 ELSE 0 END) AS [iPhone_App_1.0],
  --OS: iPad
  SUM(CASE WHEN USER_AGENT LIKE '%iPad; CPU OS 5_%'             THEN 1 ELSE 0 END) AS [iPad_OS_5.x],
  SUM(CASE WHEN USER_AGENT LIKE '%iPad; U; CPU OS 4_%'          THEN 1 ELSE 0 END) AS [iPad_OS_4.x],
  SUM(CASE WHEN USER_AGENT LIKE '%iPad; U; CPU OS 3_%'          THEN 1 ELSE 0 END) AS [iPad_OS_3.x],
  --OS : iPhone
  SUM(CASE WHEN USER_AGENT LIKE '%iPhone; CPU iPhone OS 5_%'    THEN 1 ELSE 0 END) AS [iPhone_OS_5.x],
  SUM(CASE WHEN USER_AGENT LIKE '%iPhone; U; CPU iPhone OS 4_%' THEN 1 ELSE 0 END) AS [iPhone_OS_4.x],
  SUM(CASE WHEN USER_AGENT LIKE '%iPhone; U; CPU iPhone OS 3_%' THEN 1 ELSE 0 END) AS [iPhone_OS_3.x],
  --OS: Android
  SUM(CASE WHEN USER_AGENT LIKE '%android 2.%'                  THEN 1 ELSE 0 END) AS [Android_2.x_GingerBread],
  SUM(CASE WHEN USER_AGENT LIKE '%android 3.%'                  THEN 1 ELSE 0 END) AS [Android_3.x_HoneyComb],
  SUM(CASE WHEN USER_AGENT LIKE '%android 4.%'                  THEN 1 ELSE 0 END) AS [Android_4.x_ICS],
  --Tablets
  SUM(CASE WHEN USER_AGENT LIKE '%GT-P7510%'                    THEN 1 ELSE 0 END) AS [SamsungGalaxyTab],
  SUM(CASE WHEN USER_AGENT LIKE '%Xoom%'                        THEN 1 ELSE 0 END) AS [MotorolaXoom],
  SUM(CASE WHEN USER_AGENT LIKE '%AT100%'                       THEN 1 ELSE 0 END) AS [ToshibaAT100],
  --SmartPhones
  SUM(CASE WHEN USER_AGENT LIKE '%DROID%'                       THEN 1 ELSE 0 END) AS [MotorolaDroid],
  SUM(CASE WHEN USER_AGENT LIKE '%Galaxy Nexus%'                THEN 1 ELSE 0 END) AS [GoogleNexus],
  SUM(CASE WHEN USER_AGENT LIKE '%HTC-A9192%'                   THEN 1 ELSE 0 END) AS [HTCA9192],
  SUM(CASE WHEN USER_AGENT LIKE '%GT-N7000%'                    THEN 1 ELSE 0 END) AS [SamsungGalaxyNote],
  SUM(CASE WHEN USER_AGENT LIKE '%SGH_I777%'                    THEN 1 ELSE 0 END) AS [SamsungGalaxySII],
  SUM(CASE WHEN ISNULL(USER_AGENT,'') = ''                      THEN 1 ELSE 0 END) AS [NoAgent],
  --iPad - Others
  SUM(CASE WHEN USER_AGENT LIKE '%GoodReaderIPad%'              THEN 1 ELSE 0 END) AS [iPadGoodReader]
FROM sysdba.SCB_WEB_USAGE
WHERE ACCESSDATE > '02/03/2012 18:13'  --USERAGENT Release date
GO

-- BEEHIVE
-- 06/04/2014

select top 500 * from SessionLog
where UserId in (1100)
order by SessionId desc

select * from Users where LastName like '%dowd%'

