-- AutonomousAnalysis.sql
-- 03/29/2019

/*

BC_Coverage_YYYY-MM-DDTHH-MM-SS.xml - Daily SFTP file from BlueCurve

<price_data>
  <entities>
    <entity>
      <ISIN>DE0005408116</ISIN>
      <company_id>5000</company_id>
      <instrument_id>6000</instrument_id>
      <name>Aareal</name>
      <ticker>ARL GY</ticker>
      <country>Germany</country>
      <sub_region>Western Europe</sub_region>
      <region>Europe</region>
      <sub_sector>Universal Banks</sub_sector>
      <sector>Banks</sector>
      <instrument_name>Aareal (ARL GY)</instrument_name>
      <instrument_currency>EUR</instrument_currency>
      <primary_analyst>Britta Schmidt</primary_analyst>
      <primary_analyst_id>29</primary_analyst_id>
      <close_price>29.81</close_price>
      <date>2020-01-23T09:00:09</date>
      <CDS>
        <five_y_senior_CDS />
        <five_y_sub_CDS />
      </CDS>
      <active>true</active>
    </entity>
  </entities>
  <analysts>
    <analyst>
      <scb_login>arosen2</scb_login>
      <id>112</id>
      <name>Alec Rosenbruch</name>
      <email>arosenbruch@autonomous.com</email>
      <phone>+1 646 561 6261</phone>
      <office>New York</office>
      <published>true</published>
      <active>true</active>
    </analyst>
  </analysts>
</price_data>

*/

-- Load daily xml
select * from AutonomousStagingTickers -- <entities>
order by active -- ISIN

select * from AutonomousStagingAuthors -- <analysts>

select * from Securities2 where TypeId = 2 and IsActive = -1  -- spLoadAutonomousTickers

select * from Authors where TypeId = 2 and IsActive = -1 and isAnalyst = -1  -- spLoadAutonomousAuthors

-- When cross-covered, only 1 row in Securities2, TypeId = 2

-- Autonomous ~coverage

select
  'Brand'    = 'AUTONOMOUS',
  'Industry' = sub_sector,
  'Analyst'  = primary_analyst,
  'Company'  = name,
  'Ticker'   = ticker,
  'ISIN'     = ISIN
from AutonomousStagingTickers
where active = 'true' -- Launched
order by 1, 2, 3, 4, 5

select
  'Brand' = 'BERNSTEIN',
  'Industry' = I.IndustryName,
  'Analyst'  = A.Last + ', ' + A.First,
  S.Company,
  S.Ticker,
  S.ISIN
from ResearchCoverage RC
join Industries I on I.IndustryId = RC.IndustryId
join Authors A on A.AuthorId = RC.AnalystId
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null 
order by 1, 2, 4, S.OrdNo

-- cross-coverage
select S.* from ResearchCoverage RC join Securities2 S on RC.SecurityID = S.SecurityID
where  LaunchDate > '04/01/2019'
and S.Ticker in (select Ticker from Securities2 where TypeId = 2) 

-- Disclosures

-- [Square] is covered by both the Autonomous brand and the Bernstein brand. For the research ratings and price target history please go to https://bcprod.autonomous.com/disclosure_portal/portal.html for securities covered by Autonomous brand and www.bernsteinresearch.com/go/disclosures for securities covered by the Bernstein brand.

select * from SecurityTextDisclosures

select * from Securities2 where SecurityId in (select SecurityId from SecurityTextDisclosures)

sp_helptext spGetSecurityTextDisclosures
go

sp_helptext spLoadAutonomousTickers

