-- ProductGroupAnalysis.sql
-- 04/12/2014

select * from ProductGroups
select * from ProductGroupFieldTypes
select * from ProductGroupFields
select * from ProductGroupDocuments
select * from ProductGroupModels

select * from RVProductGroups
select * from RVProductGroupDocuments
select * from RVProductGroupModels

select * from DistributionSites where Active = -1
select * from DistributionAdapters
select * from DistributionEntitlements order by SiteId, ProductGroupId  -- Admin via PDU -- US, PE, AP
select * from DistributionModelEntitlements

-- Product Group definition matrix
select
  PG.ProductGroupName [Product Group],
  PGFT.FieldName [Field],
  case
    when PGF.FieldId = 4 then PT.PublicationType
    when PGF.FieldId = 1 then I.IndustryName
    when PGF.FieldId = 3 then A.Last + ', ' + A.First
    when PGF.FieldId = 2 then S.Ticker + ' / ' + S.Company
  end [Field Value]
--  PGF.*,
--  PG.*,
--  PGFT.*
from ProductGroupFields PGF
join ProductGroups PG on PG.ProductGroupId = PGF.ProductGroupId
join ProductGroupFieldTypes PGFT on PGFT.FieldId = PGF.FieldId
left join PublicationTypes PT on PT.PublicationTypeId = PGF.FieldValue and PGF.FieldId = 4
left join Industries I on I.IndustryId = PGF.FieldValue and PGF.FieldId = 1
left join Authors A on A.AuthorId = PGF.FieldValue and PGF.FieldId = 3
left join Securities2 S on S.SecurityId = PGF.FieldValue and PGF.FieldId = 2
--where PG.ProductGroupId in (1, 2, 4, 15, 16)
order by 1, 2, 3

-- Product group content distribution
select
  DS.Site [Site],
  DS.SiteType [Type],
  PG.ProductGroupName [Product Group],
  DA.Adapter
--  ,DS.*
from DistributionSites DS
left join ProductGroups PG on PG.ProductGroupId = DS.ProductGroupId
left join DistributionAdapters DA on DA.AdapterId = DS.AdapterId
where DS.Active = -1
order by 4, 1

-- Product group content entitlement
select
  DS.Site [Site],
  PG.ProductGroupName [Product Group],
  DE.RixmlEntitlement [RIXML Entitlement]
--  ,DE.*
from DistributionEntitlements DE
left join DistributionSites DS on DS.SiteId = DE.SiteId
left join ProductGroups PG on PG.ProductGroupId = DE.ProductGroupId
where DS.Active = -1
order by 1, 2, 3


PRINT '-- ***'
PRINT '-- *** INDUSTRIES THAT HAVE NOT BEEN ASSIGNED TO A PRODCUT GROUP, I.E BR.COM ENTITLEMENTS NOT INITIALIZED'
PRINT '-- ***'

SELECT *
FROM Industries
WHERE IndustryId NOT IN
(SELECT pgf.FieldValue 
 FROM ProductGroupFields pgf JOIN ProductGroupFieldTypes pgft ON pgf.FieldId = pgft.FieldId
 WHERE pgft.FieldName = 'Industry'
)


-- Pivot - Industries x Core Product Groups
select
  IndustryName Industry,
  max(case ProductGroupId when  1 then 'X' else ' ' end) as [US Research],
  max(case ProductGroupId when  2 then 'X' else ' ' end) as [Pan-Euro Research],
  max(case ProductGroupId when  4 then 'X' else ' ' end) as [Asia-Pacific Research],
  max(case ProductGroupId when 15 then 'X' else ' ' end) as [Quant Research],
  max(case ProductGroupId when 16 then 'X' else ' ' end) as [Macro Research]
from Industries I
left join ProductGroupFields PF on I.IndustryId = PF.FieldValue
left join ResearchCoverage RC on I.IndustryId = RC.IndustryId
where RC.DropDate is null
group by I.IndustryId, IndustryName
order by 1

-- By coverage
select
  I.IndustryName Industry,
  A.Last + ', ' + A.First Analyst,
  max(case when RC.DropDate is null then 'T' else ' ' end) as [Active],
  max(case PGF.ProductGroupId when  1 then 'X' else ' ' end) as [US Research],
  max(case PGF.ProductGroupId when  2 then 'X' else ' ' end) as [Pan-Euro Research],
  max(case PGF.ProductGroupId when  4 then 'X' else ' ' end) as [Asia-Pacific Research],
  max(case PGF.ProductGroupId when 15 then 'X' else ' ' end) as [Quant Research],
  max(case PGF.ProductGroupId when 16 then 'X' else ' ' end) as [Macro Research]
from ResearchCoverage RC
join Industries I on I.IndustryId = RC.IndustryId
join Authors A on A.AuthorId = RC.AnalystId
left join ProductGroupFields PGF on PGF.FieldValue = I.IndustryId and PGF.FieldId = 1 -- Industry
--where (I.IndustryName like '%strat%' or I.IndustryName like '%quant%')
where RC.DropDate is null
group by I.IndustryName, A.Last + ', ' + A.First
order by 1, 2

-- GEM Tickers: ProductGroupName = 'Autonomous GEM Feed' - Naveen
select 'Industry' = I.IndustryName, S.Company, S.Ticker, RC.SecurityId
from ResearchCoverage RC
join Industries I on I.IndustryId = RC.IndustryId
join Securities2 S on S.SecurityId = RC.SecurityId
join ProductGroupFields PGF on PGF.FieldValue = RC.IndustryId
join ProductGroups PG on PG.ProductGroupId = PGF.ProductGroupId
where PG.ProductGroupName = 'Autonomous GEM Feed'
and PGF.FieldId = 1
and RC.DropDate is null
order by I.IndustryName, S.Ticker

