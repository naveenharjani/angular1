-- SolactiveAnalysis.sql
-- 02/21/2017

-- Recent coverage changes
SELECT
  CONVERT(date, RC.EditDate, 101) AS Date,
  A.Last + ', ' + A.First AS Analyst,
  S.Company,
  S.Ticker,
  S.IsPrimary
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN Authors A ON A.AuthorId = RC.AnalystId
WHERE RC.LaunchDate is null and RC.DropDate is null
AND RC.EditDate BETWEEN getdate() - 30 AND getdate()    -- coverage updates in last 1 day
ORDER BY CONVERT(date, RC.EditDate, 101), S.Company, S.IsPrimary DESC
--ORDER BY YEAR(RC.EditDate) DESC, MONTH(RC.EditDate) DESC, DAY(RC.EditDate), S.Company, S.IsPrimary
--CONVERT(datetime, RC.EditDate, 101)

-- How many covered primary tickers are not in index?
print 'Covered primary tickers not added to an index'
select
  A.Last + ', ' + A.First as Analyst,
  S.Company,
  S.Ticker,
  S.IsPrimary
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join Authors A on A.AuthorId = RC.AnalystId
where RC.DropDate is null
and S.IsPrimary = 'Y'
and RC.SecurityId not in (select SecurityId from SolactiveIndexTickers)
order by S.Ticker

-- How many covered non-primary tickers are in index?
print 'Covered non-primary tickers added to an index'
select
  A.Last + ', ' + A.First as Analyst,
  S.Company,
  S.Ticker,
  S.IsPrimary
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join Authors A on A.AuthorId = RC.AnalystId
where RC.DropDate is null
and S.IsPrimary <> 'Y'
and RC.SecurityId in (select SecurityId from SolactiveIndexTickers)
order by S.Ticker

-- How many dual ratings held?
-- From \Etc\sql\Research\_CC_Future\Estimates\Analysis\Screens
-- Dual rating
-- n.b. Ratings vary by ticker
select distinct
  A.Last + ', ' + A.First as Analyst,
  S.Company,
  count(distinct(VFNL.Value)) as RatingCount
from vFinancialNumbersLatest VFNL
join Securities2 S on S.SecurityId = VFNL.SecurityId
join ResearchCoverage RC on RC.CoverageId = VFNL.CoverageId
join Authors A on A.AuthorId = RC.AnalystId
where VFNL.FinancialNumberTypeId = 1 and VFNL.IsDraft = 0
and RC.LaunchDate is not null and RC.DropDate is null
group by A.Last + ', ' + A.First, S.CompanyId, S.Company
having count(distinct(VFNL.Value)) > 1
order by 1, 2

-- Analyst primary vs. industry primary



/*

select * from ResearchCoverage order by EditDate desc

select top 5000 * from AdminLog order by EditDate desc

select top 5000 * from AdminLog where [Table] = 'Coverage' order by EditDate desc

*/

--select * from FinancialNumberTypes where FinancialNumberTypeCat = 'M' order by FinancialNumberTypeCatOrd

-- EXEC spSendCoverageAlert

select * from SolactiveIndexes

select * from SolactiveIndexTickers

sp_helptext spSearchSolactiveIndexTickers
go

sp_helptext spSearchSolactiveNotes
go

sp_helptext spSaveSolactiveIndexTicker
go

declare @Ct int

exec spSearchSolactiveIndexTickers 1, 'a', 1, 5000, @Ct output

select @Ct

-- *** Ack flag

-- DEV 03/24/2017
-- insert into SolactiveIndexes (IndexId, IndexCode, EditorId, EditDate) values (6, 'ACK', 1, getdate())

-- insert into SolactiveIndexTickers
select 6, SecurityId, 1, getdate() from ResearchCoverage where SecurityId is not null and DropDate is null and EditDate < '03/23/2017'
--select 6, SecurityId, 1, getdate() from ResearchCoverage where DropDate is null and EditDate < '03/23/2017'


select * from SolactiveIndexTickers where SecurityId not in (select SecurityId from ResearchCoverage where DropDate is null)

select SecurityId from ResearchCoverage where DropDate is null and SecurityId not in (select SecurityId from SolactiveIndexTickers)
order by 1

-- Covered tickers not in 
select RC.SecurityId, S.Ticker, S.isPrimary from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
 where DropDate is null and RC.SecurityId not in (select SecurityId from SolactiveIndexTickers)
order by 1


-- *** Logging

select * from AdminLog where [Table] = 'SolactiveIndexTickers'

select EditorId, count(*) from AdminLog where [Table] = 'SolactiveIndexTickers' group by EditorId 

select
  S.Company,
  S.Ticker,
  AL.Operation,
  AL.New as 'Index | Ticker',
  U.LastName + ', ' + U.FirstName as Editor,
  AL.EditDate
--  AL.*
from AdminLog AL
join Users U on U.UserId = AL.EditorId
join Securities2 S on S.SecurityId = AL.Id
where [Table] = 'SolactiveIndexTickers'
order by AL.EditDate

order by AL.EditorId, AL.EditDate

-- *****
-- *****
-- *****

-- 06/29/2017
-- Solactive Notes

/*

Model after Analyst Text Disclosures

http://institutional-dev.beehive.com/disclosures/securitytextdisclosures.asp
http://institutional-dev.beehive.com/disclosures/authortextdisclosures.asp

*/

select * from SecurityTextDisclosures

select * from AuthorTextDisclosures

sp_helptext spGetSecurityTextDisclosures
go

sp_helptext spGetAuthorTextDisclosures
go

sp_helptext spSaveSecurityTextDisclosure
go

sp_helptext spSaveAuthorTextDisclosure
go


-- Get Tickers list for a Solactive Index
SELECT S.Company, S.Ticker, S.SEDOL, S.ISIN --, SI.IndexCode AS SolactiveIndex
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN SolactiveIndexTickers SIT ON SIT.SecurityId = S.SecurityId
JOIN SolactiveIndexes SI ON SI.IndexId = SIT.IndexId
WHERE RC.DropDate IS NULL
--AND SI.IndexCode = 'BERNUS'
AND SI.IndexCode = 'BERNGLBL'
ORDER BY 1, 2
GO


-- DEBUG
/*
SELECT * FROM SolactiveIndexTickers
SELECT * FROM SolactiveIndexes
*/

sp_helptext spSearchSolactiveindexTickers


spSearchSolactiveIndexTickers

select *
from ResearchCoverage RC
join Solactive



SELECT *
FROM
(
  SELECT
  RC.SecurityId,
  AR.Region,
  A.Last + ', ' + A.First AS Analyst,
  S.Company,
  S.Ticker,
  S.OrdNo,
  RC.LaunchDate,
  SN.Note,
  SI.IndexCode
  FROM ResearchCoverage RC
  JOIN Securities2 S ON S.SecurityId = RC.SecurityId
  JOIN Authors A ON A.AuthorId = RC.AnalystId
  JOIN AuthorRegions AR ON AR.RegionId = A.RegionId
  LEFT JOIN SolactiveNotes SN ON SN.SecurityId = RC.SecurityId
  LEFT JOIN SolactiveIndexTickers SIT ON SIT.SecurityId = RC.SecurityId
  LEFT JOIN SolactiveIndexes SI ON SI.IndexId = SIT.IndexId
  WHERE RC.DropDate IS NULL
) as p
PIVOT
(
  count(IndexCode)
  for IndexCode in ([BERNUS], [BERNINTL], [BERNGLBL], [BERNAPAC], [BERNEURO], [ACK])
) piv
order by 1


' + @SortCol + @SortDir + @SortCol2

-- print @SelectQuery

EXEC sp_executesql @SelectQuery

SET @Ct = @@ROWCOUNT 