-- DisclosuresAnalysis.sql
-- 02/08/2019

-- Find reports containing dynamic disclosures

-- Reports with authors + ticker holdings
-- Star Compliance holdings activated on 02/05/2019
SELECT
	CONVERT(varchar, P.Date, 101) as Date,
	P.PubNo,
	P.Title,
	'Author' = Pr1.PropValue,
	'Ticker' = Pr2.PropValue,
	VH.Text
FROM Publications P
JOIN Properties Pr1 ON Pr1.PropId = 5 AND Pr1.PubNo = P.PubNo    -- Authors
JOIN Authors A ON Pr1.PropValue = A.Name
JOIN Properties Pr2  ON Pr2.PropId = 13 AND Pr2.PubNo = P.PubNo  -- Tickers
JOIN Securities2 S ON Pr2.PropValue = S.Ticker
JOIN vHoldings VH ON VH.AuthorId = A.AuthorId AND VH.SecurityId = S.SecurityId
WHERE DATEDIFF(d, P.Date, getdate()) <= 10
AND S.TickerType = 'STOCK'
AND DATEDIFF(dd, '02/05/2019', Date) > 1 -- Holdings activated
--AND A.IsAnalyst = -1                    -- Analysts only
ORDER BY CONVERT(varchar, P.Date, 101), P.PubNo

-- Author Text Disclosures
SELECT
	CONVERT(varchar, P.Date, 101) as Date,
	P.PubNo,
	P.Title,
	'Author' = Pr.PropValue,
	D.Disclosure
FROM Publications P
JOIN Properties Pr  ON Pr.PropId = 5 AND Pr.PubNo = P.PubNo  -- Authors
JOIN Authors A ON Pr.PropValue = A.Name
JOIN AuthorTextDisclosures D ON D.AuthorId = A.AuthorId
WHERE DATEDIFF(d, P.Date, getdate()) <= 10
ORDER BY CONVERT(varchar, P.Date, 101), P.PubNo, A.Name

-- Security Text Disclosures
SELECT
	CONVERT(varchar, P.Date, 101) as Date,
	P.PubNo,
	P.Title,
	'Ticker' = Pr.PropValue,
	D.Disclosure
FROM Publications P
JOIN Properties Pr  ON Pr.PropId = 13 AND Pr.PubNo = P.PubNo -- Ticker
JOIN Securities2 S ON Pr.PropValue = S.Ticker
JOIN SecurityTextDisclosures D ON D.SecurityID = S.SecurityID
WHERE DATEDIFF(d, P.Date, getdate()) <= 10
AND S.TickerType = 'STOCK'
ORDER BY CONVERT(varchar, P.Date, 101), P.PubNo, S.Ticker

-- Firm Disclosures - 1%
SELECT
	CONVERT(varchar, P.Date, 101) as Date,
	P.PubNo,
	P.Title,
	'Ticker' = Pr.PropValue,
	SCT.Disclosure
FROM Publications P
JOIN Properties Pr  ON Pr.PropId = 13 AND Pr.PubNo = P.PubNo -- Ticker
JOIN Securities2 S ON Pr.PropValue = S.Ticker
JOIN SecurityCheckboxDisclosures D ON D.SecurityID = S.SecurityID
JOIN SecurityCheckboxTypes SCT on SCT.DisclosureId = D.DisclosureId
WHERE DATEDIFF(d, P.Date, getdate()) <= 10
AND S.TickerType = 'STOCK'
-- AND SCT.DisclosureId = 1 -- 1% holding - Brenda Coulter
AND SCT.DisclosureId <> 1 -- Gary Krueger
ORDER BY CONVERT(varchar, P.Date, 101) desc, P.PubNo desc, S.Ticker

