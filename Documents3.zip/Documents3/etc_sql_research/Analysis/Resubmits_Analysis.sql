-- ResubmitsAnalysis.sql
-- 04/24/2013
-- 01/21/2021

-- 04/24/2013 - For Cheryl de Krei (07/01/2014 - 09/30/2014)

-- 01/20/2021 - Sujeet Joshi
-- Do you capture data on number of resubmits (with standard identifying data � doc ID, analyst etc.)? 
-- If yes, is it possible to provide this for 2019 and 2020 ?

USE Research
GO

DECLARE @StartDate datetime,
        @EndDate   datetime

SELECT @StartDate = '07/01/2014',
       @EndDate   = '09/30/2014'

DECLARE @TotalCount FLOAT

SELECT @TotalCount = count(*)
FROM Publications WHERE Type IN ('RESEARCH CALL', 'EXTERNAL FLASH') AND Date BETWEEN @StartDate AND @EndDate

-- Resubmits by Version
SELECT
  Version,
  count(*) [# Reports],
  round(count(*) * (Version - 1) * 100 / @TotalCount, 2) [% Resubmit]
FROM Publications WHERE Type IN ('RESEARCH CALL', 'EXTERNAL FLASH') AND Date BETWEEN @StartDate AND @EndDate
GROUP BY Version WITH ROLLUP

-- Resubmits by Version
PRINT 'RESUBMITS - FOR SPECIFIED DATE RANGE (EXCLUDES CO-AUTHORING)'
SELECT
  '# Reports'   = COUNT(*),
  '# Resubmits' = SUM(Version - 1),
  '% Resubmits' = CONVERT(decimal(10,1), CONVERT(decimal, SUM(Version - 1)) / CONVERT(decimal, COUNT(*)) * 100 )
FROM Publications WHERE Type IN ('RESEARCH CALL', 'EXTERNAL FLASH') AND Date BETWEEN @StartDate AND @EndDate

-- Resubmits by Franchise
PRINT 'RESUBMITS - BY ANALYST FOR SPECIFIED DATE RANGE (INCLUDES CO-AUTHORING)'
SELECT
  'Analyst'     = A.Last,
  '# Reports'   = COUNT(*),
  '# Resubmits' = SUM(Version - 1),
  '% Resubmits' = CONVERT(decimal(10,1), CONVERT(decimal, SUM(Version - 1)) / CONVERT(decimal, COUNT(*)) * 100 )
FROM Publications PU
JOIN Properties PV ON PV.PubNo = PU.PubNo AND PV.PropID = 5 -- Authors
JOIN Authors A ON A.Name = PV.PropValue AND A.IsAnalyst = -1 -- AND PV.PropValue = 'Colin McGranahan' -- FILTERS
WHERE PU.Type in ('RESEARCH CALL','EXTERNAL FLASH') AND PU.Date BETWEEN @StartDate AND @EndDate
GROUP BY A.Last WITH ROLLUP
ORDER BY 4 DESC

-- Resubmits by Report
SELECT
  PU.PubNo,
  PU.Version,
  'Primary Analyst' = A.Last + ', ' + A.First,
  PU.Date, PU.Type, PU.Title
FROM Publications PU
JOIN Properties PV ON PV.PubNo = PU.PubNo
JOIN Authors A ON A.Name = PV.PropValue -- AND A.IsAnalyst = -1 -- AND PV.PropValue = 'Colin McGranahan' -- FILTERS
WHERE --PU.Type in ('RESEARCH CALL','EXTERNAL FLASH') AND 
PU.Date BETWEEN '01/01/2019' AND '12/31/2020'
AND PU.Version > 1
AND PV.PropNo = (select MIN(PropNo) FROM Properties WHERE PubNo = PU.PubNo AND PropID = 5) -- Primary analyst
ORDER BY 2 DESC, 1

