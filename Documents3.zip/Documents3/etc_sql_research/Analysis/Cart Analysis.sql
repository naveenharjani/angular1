-- Cart Analysis.sql
-- 12/09/2013

-- 08/31/2016 - Review cart attachment usage
-- 02/02/2017 - Beehive watermark enabled 

/*

Large number of pdf's that will not get tracked.

Cart types captured since 9/13/2013

*/

select * from CartTypes

select CartTypeId, min(EditDate) from CartLog group by CartTypeId order by 1

select * from CartLog order by CartId desc

select * from CartLog where CartTypeId = 3 and EditDate > '05/01/2016'

select top 500 CL.*, CT.*
from CartLog CL
join CartTypes CT on CT.CartTypeId = CL.CartTypeId
order by CL.CartId desc

-- Num Carts Summary by Type
select CT.CartType, count(*) as 'Num Carts'
from CartLog CL
join CartTypes CT on CT.CartTypeId = CL.CartTypeId
--where CL.EditDate > '10/1/2017'
where CL.EditDate >= '10/01/2017' and CL.EditDate <= '12/31/2017' -- On 01/19/2018 For Chris and Colin
group by CT.CartType
order by 2 desc

-- Num Carts Summary by Type + User
select CT.CartType, U.LastName + ', ' + U.FirstName as 'User', count(*) as 'Num Carts'
from CartLog CL
join CartTypes CT on CT.CartTypeId = CL.CartTypeId
join Users U on U.UserId = CL.UserId
--where CL.EditDate > '10/1/2017'
where CL.EditDate >= '10/01/2017' and CL.EditDate <= '12/31/2017' -- On 01/19/2018 For Chris and Colin
group by CT.CartType, U.LastName + ', ' + U.FirstName
order by 1, 3 desc, 2

-- Num Carts Summary by Type + User w/ cart counts
select CT.CartType, CL.UserId, count(distinct CL.CartId) as 'Num Carts', count(CA.CartId) as 'Num Reports'
into #tmp1
from CartLog CL
join CartTypes CT on CT.CartTypeId = CL.CartTypeId
join CartAttachments CA on CA.CartId = CL.CartId
--where CL.EditDate > '10/1/2017'
where CL.EditDate >= '10/01/2017' and CL.EditDate <= '12/31/2017' -- On 01/19/2018 For Chris and Colin
group by CT.CartType, CL.UserId
order by 1, 3 desc, 2

select CartType, U.LastName + ', ' + U.FirstName as [User], D.Department, [Num Carts], [Num Reports]
from #tmp1 T
join Users U on T.UserId = U.UserId
join Departments D on D.DepartmentId = U.DepartmentId
order by 1, [Num Carts] desc, [User]

drop table #tmp1

--
select
  CL.CartID,
  'Date' = CL.EditDate,
  'User' = U.LastName + ', ' + U.FirstName + ' (' + U.UserName + ')',
  D.Department,
  CA.Type,
  CA.Title
--  CL.*,
--  U.*,
--  CA.*
from CartLog CL
join Users U on U.UserId = CL.UserId
join CartAttachments CA on CA.CartId = CL.CartId
join Departments D on D.DepartmentId = U.DepartmentId
where CartTypeId = 3
--and CL.EditDate > '06/01/2016' -- On 08/31/2016 for Chris, Jan, Colin, Declan, Fred
--and CL.EditDate > '08/01/2016' -- On 03/01/2017 for Declan
and CL.EditDate >= '10/01/2017' and CL.EditDate <= '12/31/2017' -- On 01/19/2018 For Chris and Colin
order by 1

select * from CartAttachments

select * from CartTypes

select * from Users

select * from Departments

