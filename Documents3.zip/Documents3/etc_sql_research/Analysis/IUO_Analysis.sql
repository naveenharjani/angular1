-- IUO_Analysis.sql
-- 03/06/2014

select * from Commentary order by CommentaryId desc
select * from CommentaryReadLog
select * from CommentaryReadLog CRL where CRL.UserId = 1 order by ReadDate desc
select * from CommentaryReadLog CRL where CRL.UserId = 1 and datediff(d, CRL.ReadDate, getdate()) < 30 order by ReadDate desc

-- ***
-- *** IUO Email Relay Service
-- ***

-- Mobile usage
select
  'User' = convert(varchar(50), U.LastName + ', ' + U.FirstName + ' ('+ U.UserName + ')'),
  CRL.ReadDate,
  CRL.UserAgent,
  CRL.*
from CommentaryReadLog CRL
join Users U on U.UserId = CRL.UserId
where CRL.UserAgent like '%ipad%' or CRL.UserAgent like '%iphone%'
--where CRL.UserAgent like '%blackberry%'
order by CRL.ReadDate desc

-- Mobile usage - user latest
select
  'User' = convert(varchar(50), U.LastName + ', ' + U.FirstName + ' ('+ U.UserName + ')'),
  CRL.ReadDate,
  CRL.UserAgent,
  CRL.*
from CommentaryReadLog CRL
join Users U on U.UserId = CRL.UserId
join (select UserId,max(ReadDate) ReadDate from CommentaryReadLog where UserAgent like '%ipad%' or UserAgent like '%iphone%' group by UserId) v on CRL.UserId = v.UserId and CRL.ReadDate = v.ReadDate
where CRL.UserAgent like '%ipad%' or
CRL.UserAgent like '%iphone%' or
CRL.UserAgent like '%blackberry%'
order by CRL.ReadDate desc

-- Mobile usage - user count
select
  'User' = convert(varchar(50), U.LastName + ', ' + U.FirstName + ' ('+ U.UserName + ')'),
  Count(ReadDate)
from CommentaryReadLog CRL
join Users U on U.UserId = CRL.UserId
--where (CRL.UserAgent like '%msie%')
where (CRL.UserAgent like '%ipad%' or CRL.UserAgent like '%iphone%')
--where CRL.UserAgent like '%blackberry%'
and datediff(d, CRL.ReadDate, getdate()) < 90
group by convert(varchar(50), U.LastName + ', ' + U.FirstName + ' ('+ U.UserName + ')')
order by 2 desc

-- Mobile usage
select
  C.CommentaryId,
  'US' = case when C.ToList like 'MarketCommentary-US@bernstein.com%' then 'Y' else '' end,
  'EU' = case when C.ToList like 'MarketCommentary-EU@bernstein.com%' then 'Y' else '' end,
  'AP' = case when C.ToList like 'MarketCommentary-AP@bernstein.com%' then 'Y' else '' end,
 -- C.*,
  'User' = convert(varchar(50), U.LastName + ', ' + U.FirstName + ' ('+ U.UserName + ')'),
  CRL.ReadDate,
  CRL.UserAgent,
  CRL.*
from Commentary C
join CommentaryReadLog CRL on CRL.CommentaryId = C.CommentaryId
join Users U on U.UserId = CRL.UserId
where C.CreateDate > '01/01/2014' --CRL.UserAgent like '%ipad%' or CRL.UserAgent like '%iphone%'
--where CRL.UserAgent like '%blackberry%'
order by 1

/*

12/11/2014 - Per Chris Hogbin

Create a monthly report for me that shows the number of IUO�s that each EU analysts posted in the last month and last 3 months, 
and the average �readership�/clicks.?

Run History
12-15-2014
01-05-2015

SSRS
IUO Productivity and Readership
spRptIUOProductivity

*/

USE Research
GO

SELECT
  'Region'  = AR.Region,
  'Analyst' = A.Last + ', ' + A.First,
  -- 30 days
  '30_DAY_NUM_IUO'         = (SELECT COUNT(CommentaryId) FROM Commentary WHERE CreateDate >= getdate() - 30 AND AnalystId = A.AuthorId),
  '30_DAY_TOTAL_IUO_READS' = (SELECT COUNT(CommentaryReadLogId) FROM CommentaryReadLog WHERE CommentaryId IN
    (SELECT CommentaryId FROM Commentary WHERE CreateDate >= getdate() - 30 AND AnalystId = A.AuthorId)),
  -- 90 days
  '90_DAY_NUM_IUO'         = (SELECT COUNT(CommentaryId) FROM Commentary WHERE CreateDate >= getdate() - 90 AND AnalystId = A.AuthorId),
  '90_DAY_TOTAL_IUO_READS' = (SELECT COUNT(CommentaryReadLogId) FROM CommentaryReadLog WHERE CommentaryId IN
    (SELECT CommentaryId FROM Commentary WHERE CreateDate >= getdate() - 90 AND AnalystId = A.AuthorId))
INTO #CommentaryReads
FROM Authors A
LEFT JOIN AuthorRegions AR ON AR.RegionID = A.RegionId
WHERE A.IsAnalyst = -1 and A.Status = 1 -- Active Analysts
GROUP BY AR.Region, A.Last + ', ' + A.First, A.AuthorId
ORDER BY AR.Region, A.Last + ', ' + A.First, A.AuthorId

SELECT
  Region,
  Analyst,
  "30_DAY_NUM_IUO",
  "30_DAY_TOTAL_IUO_READS",
  "30_DAY_AVG_IUO_READS" = (CASE WHEN "30_DAY_NUM_IUO" = 0 THEN 0 ELSE ("30_DAY_TOTAL_IUO_READS"/"30_DAY_NUM_IUO") END),
  "90_DAY_NUM_IUO",
  "90_DAY_TOTAL_IUO_READS",
  "90_DAY_AVG_IUO_READS" = (CASE WHEN "90_DAY_NUM_IUO" = 0 THEN 0 ELSE ("90_DAY_TOTAL_IUO_READS"/"90_DAY_NUM_IUO") END)
FROM #CommentaryReads
ORDER BY Region, Analyst

DROP Table #CommentaryReads

-- ***
-- *** IUO Email Relay Service
-- ***

select * from Commentary where CreatorId = 0 order by CommentaryId desc

select Creator, count(*) Num from Commentary where Creator like '%@%' group by Creator order by Num desc
select Creator, count(*) Num from Commentary where Creator like '%@%' and CreateDate >= '01/01/2017' group by Creator order by Num desc

select Creator, count(*) Num from Commentary where datediff(d, CreateDate, getdate()) < 90 group by Creator order by Num desc

select A.Last, C.Creator, AR.Region, count(*) Num from Commentary C
join Authors A on A.AuthorId = C.AnalystId
join AuthorRegions AR on AR.RegionId = A.RegionId
where datediff(d, CreateDate, getdate()) < 90 group by A.Last, C.Creator, AR.Region order by Num desc

select
  Total = (select count(*) from Commentary where datediff(d, CreateDate, getdate()) < 60),
  Relay = (select count(*) from Commentary where CreatorId = 0 and datediff(d, CreateDate, getdate()) < 60)

-- Verify Beehive email matches adress book SMTP email for relay service recogition
select distinct
  A.Last + ', ' + A.First Analyst,
  A.ExtEmail Email
from ResearchCoverage RC
join Authors A on A.AuthorId = RC.AnalystId
where RC.DropDate is null
order by 1


spGetIUOAnalyst 'David.Vernon@bernstein.com'

spGetIUOAnalyst 'dhananjay@bernstein.com'

spGetIUOAnalyst 'beth.hopper@bernstein.com'
