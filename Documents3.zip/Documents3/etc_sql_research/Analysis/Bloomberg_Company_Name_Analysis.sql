-- Bloomberg_Company_Name_Analysis.sql
-- 10/23/2013

select FieldId, Mnemonic, * from BloombergFields where Active = 'Y'

select * from BloombergPivotTickerStatus where FieldId = 46 -- ISSUER
select * from BloombergPivotTickerStatus where FieldId = 47 -- LONG_COMP_NAME

select Ticker, Value PARENT_TICKER_EXCHANGE, * from BloombergPivotTickerStatus where FieldId = 54 -- PARENT_TICKER_EXCHANGE

select Ticker, Value CNTRY_OF_INCORPORATION, * from BloombergPivotTickerStatus where FieldId = 64 order by 2, 1  -- CNTRY_OF_INCORPORATION

select Ticker, Value LONG_COMP_NAME, * from BloombergPivotTickerStatus where FieldId = 47 -- LONG_COMP_NAME

select distinct
  TS.Ticker,
  'LONG_COMP_NAME' = TS.Value,
  'Securities2.Company' = S.Company,
  '-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = ''' + TS.Value +
  ''' where Ticker = ''' + S.Ticker + ''' -- ' + S.Company
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join BloombergPivotTickerStatus TS on TS.Ticker = S.Ticker and TS.FieldId = 47 -- LONG_COMP_NAME
where RC.DropDate is null
and TS.Value <> S.Company
--and TS.Value not like '%/%'
--and TS.Value not like '%/The'
--and charindex('/', TS.Value) > 0 and substring(TS.Value, 1, charindex('/', TS.Value)-1) <> S.Company  --filters out non '/' values
order by 1

-- *** Update the EditDate to trigger refresh of iPad data

-- 10/24/2013
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Verizon Communications Inc' where SecurityId = 671 -- Verizon
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'WPP PLC' where SecurityId = 826 -- WPP Group PLC
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Sprint Corp' where SecurityId = 922 -- Sprint Nextel Corp
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'BlackBerry Ltd' where SecurityId = 1144 -- Research In Motion Ltd
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'BlackBerry Ltd' where SecurityId = 1153 -- Research In Motion Ltd
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Hewlett-Packard Co' where SecurityId = 279 -- Hewlett Packard
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Liberty Global PLC' where SecurityId = 1477 -- Liberty Global Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Liberty Global PLC' where SecurityId = 1478 -- Liberty Global Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Liberty Global PLC' where SecurityId = 1479 -- Liberty Global Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'XL Group PLC' where SecurityId = 588 -- XL Capital Ltd
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Zurich Insurance Group AG' where SecurityId = 1075 -- Zurich Financial Services AG
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'BHP Billiton Ltd' where SecurityId = 1432 -- BHP Billiton PLC
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'BHP Billiton Ltd' where SecurityId = 1437 -- BHP Billiton PLC

-- 11/26/2013
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Accenture PLC' where Ticker = 'ACN' -- Accenture Ltd
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Acer Inc' where Ticker = '2353.TT' -- Acer Group
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Actavis plc' where Ticker = 'ACT' -- Actavis Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Agricultural Bank of China Ltd' where Ticker = '1288.HK' -- Agricultural Bank of China
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'American International Group Inc' where Ticker = 'AIG' -- American International Group
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Automatic Data Processing Inc' where Ticker = 'ADP' -- Automatic Data Processing
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Bank Mandiri Persero Tbk PT' where Ticker = 'BMRI.IJ' -- Bank Mandiri Tbk PT
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Bayerische Motoren Werke AG' where Ticker = 'BMW.GR' -- BMW Bayerische Motoren Werke AG
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'BNP Paribas SA' where Ticker = 'BNP.FP' -- BNP Paribas SABNP Paribas SA
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'British Sky Broadcasting Group PLC' where Ticker = 'BSY.LN' -- British Sky Broadcasting PLC
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'BT Group PLC' where Ticker = 'BT/A.LN' -- British Telecom
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Capital One Financial Corp' where Ticker = 'COF' -- Capital One
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'China CITIC Bank Corp Ltd' where Ticker = '998.HK' -- China CITIC Bank
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Cie Financiere Richemont SA' where Ticker = 'CFR.VX' -- Compagnie Financiere Richemont SA
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Danone' where Ticker = 'BN.FP' -- Groupe Danone
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Deutsche Telekom AG' where Ticker = 'DTE.GR' -- Deutsche Telekom
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Eli Lilly & Co' where Ticker = 'LLY' -- Eli Lilly
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'ENN Energy Holdings Ltd' where Ticker = '2688.HK' -- ENN Energy Holdings Limited
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Ensco PLC' where Ticker = 'ESV' -- ENSCO International Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'European Aeronautic Defence and Space Co NV' where Ticker = 'EAD.FP' -- European Aeronautic Defense
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Freescale Semiconductor Ltd' where Ticker = 'FSL' -- Freescale Semiconductor Holdings I Ltd
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Henkel AG & Co KGaA' where Ticker = 'HEN.GR' -- Henkel KGaA
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Henkel AG & Co KGaA' where Ticker = 'HEN3.GR' -- Henkel KGaA
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Hillshire Brands Co' where Ticker = 'HSH' -- Hillshire Brands 
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Huaneng Renewables Corp Ltd' where Ticker = '958.HK' -- Huaneng Renewables
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Huntington Ingalls Industries Inc' where Ticker = 'HII' -- Huntington Ingalls Industries, Inc. 
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Industrial & Commercial Bank of China Ltd' where Ticker = '1398.HK' -- Industrial & Commercial Bank of China
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Infosys Ltd' where Ticker = 'INFY' -- Infosys Technologies Ltd
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Ingersoll-Rand PLC' where Ticker = 'IR' -- Ingersoll-Rand Co Ltd
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'IntercontinentalExchange Group Inc' where Ticker = 'ICE' -- IntercontinentalExchange Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'International Business Machines Corp' where Ticker = 'IBM' -- IBM
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'J Sainsbury PLC' where Ticker = 'SBRY.LN' -- Sainsbury PLC
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Kering' where Ticker = 'KER.FP' -- PPR SA
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Kunlun Energy Co Ltd' where Ticker = '135.HK' -- Kunlun Energy Company Limited
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Lexmark International Inc' where Ticker = 'LXK' -- Lexmark
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Lloyds Banking Group PLC' where Ticker = 'LLOY.LN' -- Lloyds TSB Group PLC
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'LPL Financial Holdings Inc' where Ticker = 'LPLA' -- LPL Investment Holdings 
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Metropole Television SA' where Ticker = 'MMT.FP' -- M6-Metropole Television
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Micron Technology Inc' where Ticker = 'MU' -- Micron Technology Inc.,
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'NextEra Energy Inc' where Ticker = 'NEE' -- NextEra Energy
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Noble Corp plc' where Ticker = 'NE' -- Noble Corp
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Pentair Ltd' where Ticker = 'PNR' -- Pentair Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Pernod Ricard SA' where Ticker = 'RI.FP' -- Pernod-Ricard SA
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Reckitt Benckiser Group PLC' where Ticker = 'RB/.LN' -- Reckitt Benckiser PLC
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'RenaissanceRe Holdings Ltd' where Ticker = 'RNR' -- RenaissanceRe Ltd
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Repsol SA' where Ticker = 'REP.SM' -- Repsol YPF SA
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Rolls-Royce Holdings PLC' where Ticker = 'RR/.LN' -- Rolls-Royce Group PLC
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Rowan Cos Plc' where Ticker = 'RDC' -- Rowan Cos Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Sampo' where Ticker = 'SAMAS.FH' -- Sampo Oyj
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Swiss Re AG' where Ticker = 'SREN.VX' -- Swiss Re Ltd
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Telefonica SA' where Ticker = 'TEF.SM' -- Telefonica de Espana
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Total SA' where Ticker = 'FP.FP' -- TotalFinaElf SA
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Transocean Ltd' where Ticker = 'RIG' -- Transocean Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'United Parcel Service Inc' where Ticker = 'UPS' -- United Parcel Service
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Windstream Holdings Inc' where Ticker = 'WIN' -- Windstream Corp
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'WM Morrison Supermarkets PLC' where Ticker = 'MRW.LN' -- Morrison Supermarkets PLC
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Novo Nordisk A/S' where Ticker = 'NOVOB.DC' -- Novo-Nordisk A/S
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Novo Nordisk A/S' where Ticker = 'NVO' -- Novo-Nordisk A/S
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Allstate Corp' where Ticker = 'ALL' -- The Allstate Corporation
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Chubb Corp' where Ticker = 'CB' -- Chubb
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'CME Group Inc' where Ticker = 'CME' -- Chicago Mercantile Exchange Holdings Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'EMC Corp' where Ticker = 'EMC' -- EMC
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Estee Lauder Cos Inc' where Ticker = 'EL' -- Estee Lauder
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Goldman Sachs Group Inc' where Ticker = 'GS' -- Goldman Sachs
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Mylan Inc' where Ticker = 'MYL' -- Mylan Laboratories Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Progressive Corp' where Ticker = 'PGR' -- Progressive
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Travelers Cos Inc' where Ticker = 'TRV' -- Travelers Companies Inc
-- update Securities2 set EditorId = 1229, EditDate = getdate(), Company = 'Wendy''s Co' where Ticker = 'WEN' -- Wendy's/Arby's Group Inc
