-- MarketCapUSDAnalysis.sql
-- 02/23/2017
-- 05/24/2017

-- Get Market Cap in USD to identify if a company is a small cap (< 5 Bln) or not
-- Market Cap (CUR_MKT_CAP) � Pricing currency, reported in million
-- Exception: For LN Tickers, PriceCur is GBp which is applicable to per share/close price.
--            However Market Cap represented in major currency, e.g. GBP

SELECT
  S.Company,
  S.Ticker,
  FORMAT(CAST(VMDL.Value AS Decimal(18,2)), '#,###') AS MarketCap,
  UPPER(VMDL.CurCode) AS MarketCapCur,
  FORMAT(CASE WHEN ISNUMERIC(VMDL.Value) <> 1 THEN ''
              WHEN VMDL.CurCode IN ('USD') THEN CAST(VMDL.Value AS DECIMAL(18,6))
              ELSE CAST(VMDL.Value AS DECIMAL(18,2)) * CAST(ISNULL(VFXL.Price, 1) as decimal(18,6))
         END, '#,###') AS MarketCapUSD,
  CASE WHEN VMDL.CurCode = 'USD' THEN '1' ELSE ISNULL(VFXL.Price, '') END AS Fx
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN vMarketDataLatest VMDL ON VMDL.SecurityId = S.SecurityId AND VMDL.FinancialNumberTypeId = 86 -- MarketCap
LEFT JOIN vFxLatest VFXL ON VFXL.Ticker COLLATE SQL_Latin1_General_CP1_CS_AS = UPPER(VMDL.CurCode) + 'USD' -- Price Cur : USD
WHERE RC.DropDate IS NULL
AND ISNUMERIC(VMDL.Value) = 1
AND CAST(VMDL.Value AS DECIMAL(18,2)) * CAST(ISNULL(VFXL.Price, 1) as decimal(18,6)) < 5000000000
ORDER BY CAST(VMDL.Value AS DECIMAL(18,2)) * ISNULL(VFXL.Price, 1) DESC

/*

-- DEBUG

select * from vMarketDataLatest

select * from vFxLatest

SELECT * FROM vFxLatest where ticker IN ('GBPUSD', 'GBpUSD')

SELECT * FROM vBloombergFxLatest where ticker IN ('GBPUSD', 'GBpUSD')

SELECT * FROM FinancialNumberTypes WHERE FinancialNumberTypeCat = 'M' AND FinancialNumberType = 'CUR_MKT_CAP'

SELECT DISTINCT CurCode FROM FinancialSecuritySettings

-- Notes:
-- 1. FOR LN Tickers, PriceCur is GBp(pence), which is applicable for per share estimates
--    For Market Cap & non per share estimates, Cur is GBP(Pounds)
--    There are tickers(e.g. GSK.LN, RDSA.LN) that have per share in minor Cur(e.g. GBp) and non per share in major Cur (e.g. GBP)

-- 2. To get GBpUSD, we need one active ticker with Pricing Currency of 'GBP' (Pounds) in database for spGetBloombergSecurities 
--    to pickup that Fx cross combo

*/

select distinct CurrencyCode from Securities2

-- Num covered pricing currencies
select distinct S.CurrencyCode from ResearchCoverage RC join Securities2 S on S.SecurityId = RC.SecurityId where RC.DropDate is null

-- Pricing data - Market Cap

select * from FinancialNumberTypes where FinancialNumberTypeCat = 'M'
-- 86 / CUR_MKT_CAP

select * from BloombergFields order by Field
-- 52 / Market Cap / CUR_MKT_CAP
-- 3 / Currency / CRNCY
-- 54 / Fundamental Currency / EQY_FUND_CRNCY

select * from BloombergPivotPricing where FieldId = 52 order by Ticker, PX_CLOSE_DT -- 5 day retention

select * from vBloombergPricingLatest where FieldId = 52 order by 1 -- Last day retention

-- Self join of market cap and fundamental currency
select
  BPF1.Ticker,
  BPF1.Value as MarketCap,
  BPF2.Value as Cur,
  BPF2.Value + 'USD' as FX_Ticker
from vBloombergPricingLatest BPF1
join vBloombergPricingLatest BPF2 on BPF2.Ticker = BPF1.Ticker
where BPF1.FieldId = 52 -- CUR_MKT_CAP
and BPF2.FieldId = 3 -- CRNCY
order by 1

-- FX

select * from BloombergPivotFx order by LoadDate, Ticker, FieldId -- 5 day retention

select BF.Mnemonic, BPF.*
from BloombergPivotFx BPF
join BloombergFields BF on BF.FieldId = BPF.FieldId

select distinct FieldId from BloombergPivotFx order by FieldId

select * from BloombergFields where RequestTypeId = 5 order by Field -- Contains unneccessary fields

select * from vBloombergFXLatest -- Contains multiple runs for same day
-- *** Clean up
-- *** Remove unneccessary mnemonics
-- *** Remove unneccessary intraday runs
-- *** Maybe remove 5 day retention

select * from BloombergSecurityTypes

-- Inventory of captured fx cross rates (for fundamental currencies)
select * from BloombergSecurities where SecurityTypeCode = 'FXSEC'
and right(Identifier, 3) = 'USD'
order by Identifier

-- Dynamic FX cross rate tickers

-- Pricing cur : USD
select distinct S.CurrencyCode + 'USD'
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.DropDate is null
--order by 1

union

-- Pricing cur : Model cur
select distinct S.CurrencyCode + FSS.CurCode
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join FinancialSecuritySettings FSS on FSS.SecurityId = RC.SecurityId
where RC.DropDate is null
--and S.CurrencyCode <> FSS.CurCode

order by 1 -- S.CurrencyCode, FSS.CurCode

sp_helptext spRenderModelCurrencies -- analystsettingsadm.asp

select * from FinancialNumberTypes where FinancialNumberTypeCat = 'M'

-- *** TO DO
-- *** Synthesize desired view
select
  BPF1.Ticker,
  BPF1.Value as CloseDate,
  BPF2.Value as CrossRate
from BloombergPivotFx BPF1
join BloombergPivotFx BPF2 on BPF2.Ticker = BPF1.Ticker and BPF2.LoadDate = BPF1.LoadDate
where BPF1.FieldId = 36 -- PRIOR_CLOSE_MID
and BPF2.FieldId = 37 -- LAST_UPDATE_DT
and BPF1.LoadDate = (select max(LoadDate) from BloombergPivotFx)
order by 1, 2

-- Market Cap in USD

-- Confirm market cap currency is in fundamental currency
-- Confirm market cap amount quoted in M millions

select v1.*, v2.*,
  case when isnumeric(v1.MarketCap) = 1 then cast(v1.MarketCap as float) * cast(v2.CrossRate as float)
       else 0 end as MarketCapUSD
from 
(
-- Synthesized market cap with currency table
select
  BPF1.Ticker,
  BPF1.Value as MarketCap,
  BPF2.Value as Cur,
  BPF2.Value + 'USD' as FX_Ticker
from vBloombergPricingLatest BPF1
join vBloombergPricingLatest BPF2 on BPF2.Ticker = BPF1.Ticker
where BPF1.FieldId = 52 -- CUR_MKT_CAP
and BPF2.FieldId =  3 -- CRNCY
) as v1
left join
(
-- Synthesized fx cross rate table (should be vFxRates)
select
  BPF1.Ticker,
  BPF1.Value as CloseDate,
  BPF2.Value as CrossRate
from BloombergPivotFx BPF1
join BloombergPivotFx BPF2 on BPF2.Ticker = BPF1.Ticker and BPF2.LoadDate = BPF1.LoadDate
where BPF1.FieldId = 36 -- PRIOR_CLOSE_MID
and BPF2.FieldId = 37 -- LAST_UPDATE_DT
and BPF1.LoadDate = (select max(LoadDate) from BloombergPivotFx)
) v2 on v2.Ticker = v1.FX_Ticker

--where MarketCapUSD > 5000
order by MarketCapUSD, FX_Ticker


-- Does Company report display proper market cap currency gor GBp (market currency)?  Is naveen upshifting to GBP?

select * from vMarketDataLatest

select * from vMarketDataLatest where SecurityId = 61 and FinancialNumberTypeId = 86 order by 1

select * from Securities2 where Ticker = 'AZN.LN'
