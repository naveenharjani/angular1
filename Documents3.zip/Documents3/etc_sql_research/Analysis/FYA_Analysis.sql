-- FYA_Analysis.sql
-- 10/23/2017

-- Analyse tickers where BaseYear <> FYE by greatest rollover lag

-- Exceptions due to:
-- 1. Ticker FY Rollover yet to take place/in process
-- 2. BaseYear was rolled over to be in sync with other tickers in the Ticker table, in line with Footnotes
-- 3. Analyst ticker launch in process. Contact Franchise for any unlaunched tickers since long

PRINT '#Days Lag to rollover a company - Compare EQY_FISCAL_YR_END to FCS.BASEYEAR'
SELECT A.Last AS Analyst, 
       S.Ticker, 
       V1.EQY_FISCAL_YR_END,
       V1.LATEST_ANN_CIE_FILING,
	     FCS.BaseYear AS 'FCS.BASEYEAR',
       -- Make it first of next month
       DATEDIFF(d,
                DATEADD(m, 1, CONVERT(datetime, LEFT(V1.EQY_FISCAL_YR_END,3) + '01/' + SUBSTRING(V1.EQY_FISCAL_YR_END, 4, 4))),
                getdate() )
                AS FYELagDays,
       V2.LastRolloverDate,
       CASE 
		   WHEN V2.LastRolloverDate IS NULL THEN ''
		   ELSE DATEDIFF(d, LEFT(V1.EQY_FISCAL_YR_END,3) + '01/' + SUBSTRING(V1.EQY_FISCAL_YR_END, 4, 4),
							V2.LastRolloverDate)
       END AS LastRolloverDaysSinceFYE,
       CASE 
		   WHEN V2.LastRolloverDate IS NULL THEN ''
		   ELSE DATEDIFF(d, getdate(),
							V2.LastRolloverDate)
       END AS LastRolloverDaysSinceToday,
       CASE 
		   WHEN V2.LastRolloverDate IS NULL THEN 'Not rolled over(once) yet'
		   WHEN DATEDIFF(d, LEFT(V1.EQY_FISCAL_YR_END,3) + '01/' + SUBSTRING(V1.EQY_FISCAL_YR_END, 4, 4),
							V2.LastRolloverDate) > 0 THEN 'Last Rollover was done after last FYE'
		   WHEN DATEDIFF(d, LEFT(V1.EQY_FISCAL_YR_END,3) + '01/' + SUBSTRING(V1.EQY_FISCAL_YR_END, 4, 4),
							V2.LastRolloverDate) < 0 THEN 'Not Rolled over since. Rollover now'
		   ELSE ''
       END AS Notes
FROM ResearchCoverage RC
-- exclude new launches
JOIN Securities2 S on S.SecurityId = RC.SecurityId AND RC.DropDate IS NULL AND RC.LaunchDate IS NOT NULL
JOIN Authors A ON A.AuthorId = RC.AnalystId
JOIN FinancialCompanySettings FCS on  FCS.CompanyId = S.CompanyId 
-- Bloomberg Fiscal Year values
JOIN 
(	SELECT V.SecurityId, 
         CONVERT(varchar(12), MAX(CASE BloombergMnemonic WHEN 'EQY_FISCAL_YR_END' THEN V.Value ELSE '' END)) EQY_FISCAL_YR_END,
         CONVERT(varchar(12), MAX(CASE BloombergMnemonic WHEN 'LATEST_ANN_CIE_FILING' THEN V.Value ELSE '' END)) LATEST_ANN_CIE_FILING
	FROM vBloombergPricingLatest V
	JOIN Securities2 S ON S.SecurityId = V.SecurityId AND S.TickerType = 'STOCK'
	GROUP BY V.SecurityId
) V1 ON V1.SecurityId = RC.SecurityId
-- Last Rollover date by ticker
LEFT JOIN
(	SELECT FN.SecurityId, MAX(FN.EditDate) AS LastRolloverDate, MAX(FN.BaseYear) AS 'LastRolloverBaseYear'
	FROM FinancialNumbers FN
	WHERE Source = 'Rollover'
	GROUP BY FN.SecurityId
) V2 ON V2.SecurityId = RC.SecurityId

-- BaseYear differs from LAST FYE
--WHERE FCS.BaseYear <> SUBSTRING(V1.EQY_FISCAL_YR_END, 4, 4)

-- BaseYear differs from LATEST_ANN_CIE_FILING
WHERE FCS.BaseYear <> LATEST_ANN_CIE_FILING

--WHERE S.Ticker IN ('AAPL', 'NVDA', 'DLTR')
ORDER BY 6 DESC



PRINT '#Years Lag to rollover a company - Compare BaseYear to EQY_FISCAL_YR_END'
-- Analyze tickers where BaseYear <> FYE by greatest rollover lag

--FYA Analysis
SELECT
  S.Company,
  S.Ticker,
  FCS.BaseYear AS 'FCS.BASEYEAR',
  T.EQY_FISCAL_YR_END,
  T.LATEST_ANN_CIE_FILING,
  T.CURRENT_FULL_FISCAL_YEAR_END,
  V2.LastRolloverDate,
  --T.EXPECTED_REPORT_DT, T.EXPECTED_REPORT_PERIOD,
  -- #years difference between FYE and FYA
  CONVERT(int, SUBSTRING(T.EQY_FISCAL_YR_END, 4, 4)) - FCS.BaseYear as NumYearsLag
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
LEFT JOIN FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
LEFT JOIN (SELECT Ticker, 
                  MAX(CASE BloombergMnemonic WHEN 'EQY_FISCAL_YR_END' THEN Value ELSE '' END) EQY_FISCAL_YR_END,
                  MAX(CASE BloombergMnemonic WHEN 'EXPECTED_REPORT_DT' THEN Value ELSE '' END) EXPECTED_REPORT_DT,
                  MAX(CASE BloombergMnemonic WHEN 'EXPECTED_REPORT_PERIOD' THEN Value ELSE '' END) EXPECTED_REPORT_PERIOD,
                  MAX(CASE BloombergMnemonic WHEN 'LATEST_ANN_CIE_FILING' THEN Value ELSE '' END) LATEST_ANN_CIE_FILING,
                  MAX(CASE BloombergMnemonic WHEN 'CURRENT_FULL_FISCAL_YEAR_END' THEN Value ELSE '' END) CURRENT_FULL_FISCAL_YEAR_END
           FROM vBloombergPricingLatest GROUP BY Ticker) T on T.Ticker = S.Ticker
LEFT JOIN
(	SELECT FN.SecurityId, MAX(FN.BaseYear) AS 'LastRolloverBaseYear', MAX(CONVERT(date, FN.EditDate)) AS LastRolloverDate
	FROM dbo.FinancialNumbers FN
	WHERE Source = 'Rollover'
	AND BaseYear = (SELECT Max(FN2.BaseYear) FROM FinancialNumbers FN2 Where FN2.SecurityId = FN.SecurityId AND FN2.Source = 'Rollover')
	GROUP BY FN.SecurityId
) V2 ON RC.SecurityId = V2.SecurityId
-- exclude new launches
WHERE RC.DropDate IS NULL and RC.LaunchDate IS NOT NULL

-- BaseYear vs EQY_FISCAL_YR_END
--AND FCS.BaseYear = SUBSTRING(T.EQY_FISCAL_YR_END, 4, 4)  -- Tickers with BaseYear = FYE
AND FCS.BaseYear <> SUBSTRING(T.EQY_FISCAL_YR_END, 4, 4)   -- Tickers with BaseYear <> FYE Last
--AND FCS.BaseYear > SUBSTRING(T.EQY_FISCAL_YR_END, 4, 4)  -- Tickers with BaseYear > FYE Last (ticker does not report each year)
--AND FCS.BaseYear < SUBSTRING(T.EQY_FISCAL_YR_END, 4, 4)  -- Tickers with BaseYear < FYE Last
and S.ticker = 'NVDA'
ORDER BY CONVERT(int, SUBSTRING(T.EQY_FISCAL_YR_END, 4, 4)) - FCS.BaseYear, 
         CONVERT(int, SUBSTRING(T.EQY_FISCAL_YR_END, 4, 4)) ASC, CONVERT(int, SUBSTRING(T.EQY_FISCAL_YR_END, 1, 2)) ASC



PRINT '#Tickers by reporting month (EQY_FISCAL_YR_END)'
SELECT LEFT(V1.EQY_FISCAL_YR_END,2) AS FYE_Month, COUNT(*) AS NumTickers
FROM ResearchCoverage RC
-- exclude new launches
JOIN Securities2 S on S.SecurityId = RC.SecurityId AND RC.DropDate IS NULL AND RC.LaunchDate IS NOT NULL
-- Bloomberg Fiscal Year values
JOIN 
(	SELECT V.SecurityId, CONVERT(varchar(12), MAX(CASE BloombergMnemonic WHEN 'EQY_FISCAL_YR_END' THEN V.Value ELSE '' END)) EQY_FISCAL_YR_END
	FROM vBloombergPricingLatest V
	JOIN Securities2 S ON S.SecurityId = V.SecurityId AND S.TickerType = 'STOCK'
	GROUP BY V.SecurityId
) V1 ON V1.SecurityId = RC.SecurityId
GROUP BY LEFT(V1.EQY_FISCAL_YR_END,2)
ORDER BY LEFT(V1.EQY_FISCAL_YR_END,2)

/*
 *** Bloomberg Notes ***:
 Not all companies have REGULAR FISCAL YEAR ends that ends on December. Related to irregular fiscal years- Bloomberg's policy is:
 Any period end date between Jan 1 - Jan 14 will be the previous fiscal year.  (Example-Jan 9 2011 will be considered as the 2010 annual)
 Any period fiscal year falling after Jan 15 will be the the same as the calendar year. Jan 16, 2011 is the 2011 annual. The quarters match the rules of the annual. Jan 15 is cut off. 
 HD, DG US ends on Jan 31 so it moves up the following to 2017

-- EQY_FISCAL_YR_END (Fiscal Year End)
-- Returns the month/year of the last annual financial results announcement date. 
-- Companies can choose to report their annual financial results for a 12-month or 52/53 week 
-- For a period ending between the 1st and 15th days of the month, this field will return the prior calendar month.

-- LATEST_ANN_CIE_FILING (Latest Annual Company Filing)
-- Displays the latest year for which annual full financial statements have been processed in the Bloomberg fundamental database for a company.

-- CURRENT_FULL_FISCAL_YEAR_END (Current Full Fiscal Year End)
-- Returns the later of the date from a fundamental doc or the latumentest corporate action. 

-- The field "LATEST_ANN_CIE_FILING" is still the correct field and the best one for what you want exactly. 
-- The reason why for IBM it still returns 2016 is because they have only just reported their "preliminary" data, 
-- not the full report (10-K). You can see that on {IBM US Equity CF<GO>} if you filter for the 10-K form the 
-- latest one is the one for 2016. Preliminary data is NOT the 10-K.

-- This list would change each month, as and when the below occur:
-- 1. FY Rollovers done by franchise i.e.'Report FY As Actual' in Tickersheet. It would then fall off the list
-- 2. The new 'FYE last' data as received from Bloomberg for a ticker. Tickers will get added to the list
*/
