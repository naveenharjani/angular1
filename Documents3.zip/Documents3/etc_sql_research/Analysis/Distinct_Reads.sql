-- Distinct_Reads.sql
-- 06/11/2018

/* 
PRD : SLXPRDDB,16083 | Database=Compass | User ID=research_db_svc 
*/

USE SlxExternal
GO

-- [OLD] vwUniqueReaders
SELECT DISTINCT SWU.PUBNO, SWU.CONTACTID,  DATEADD(day, 0, DATEDIFF(day, 0, ACCESSDATE ))  AS READ_DATE, SOURCEID
FROM         WebUsage SWU with (NOLOCK)  INNER JOIN
                      --Compass.dbo.CONTACT C ON C.CONTACTID = SWU.CONTACTID AND SWU.FILEFOUND IN ('Y', 'T') INNER JOIN
                                SlxExternal.dbo.SV_Contact C with (NOLOCK) ON C.CONTACTID = SWU.CONTACTID AND SWU.FILEFOUND IN ('Y', 'T') INNER JOIN
                      Compass.dbo.ACCOUNT A with (NOLOCK) ON C.ACCOUNTID = a.SLXAccountID -- A.ACCOUNTID 
                  AND ISNULL(A.TYPE, '') NOT LIKE '%press%' AND ISNULL(A.TYPE, '') 
                              NOT LIKE '%Industry%' AND ISNULL(A.TYPE, '') NOT LIKE '%Internal%'
WHERE            DATEADD(day, 0, DATEDIFF(day, 0, ACCESSDATE )) BETWEEN '04/01/2018' and '06/10/2018'
--WHERE            DATEADD(day, 0, DATEDIFF(day, 0, ACCESSDATE )) BETWEEN '03/01/2018' and '06/10/2018'
--WHERE            DATEADD(day, 0, DATEDIFF(day, 0, ACCESSDATE )) BETWEEN '02/01/2018' and '06/10/2018'
order by pubno,contactid,read_date,sourceid  


-- [NEW] vwUniqueReaders
select pubno, slxcontactid, read_date, sourceid 
from vwUniqueReaders
where read_date between '04/01/2018' and '06/10/2018' 
--where read_date between '03/01/2018' and '06/10/2018' 
--where read_date between '02/01/2018' and '06/10/2018' 
order by pubno, contactid, read_date, sourceid  

/*

Date Range					Old	View		New View	Variance    %Variance
4/1/2018 - 6/11/2018		209,918			208,577		1,341	    0.63%
3/1/2018 - 6/11/2018		298,107         297,070     1,037       0.34%
2/1/2018 - 6/11/2018        387,334         387,044       290       0.74%   

*/
