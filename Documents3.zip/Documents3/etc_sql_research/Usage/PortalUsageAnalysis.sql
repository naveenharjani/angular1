-- PortalUsageAnalysis.sql
-- 10/23/2013

/*

These analysis queries can be run against PRD or DEV (staged) data, therefore not against RV

*/


USE Research
GO
-- === BEGIN QUARTERLY SCAN ===

DECLARE @StartDate datetime,
        @EndDate   datetime

set @StartDate = '08/01/2018'
set @EndDate   = '08/31/2018'

print '*** Period from ' + CONVERT(VARCHAR(10), @StartDate,101) + ' to ' + CONVERT(VARCHAR(10),@EndDate,101)

-- How many new reports in period?  Useful to compare reads vs. reports, i.e. pulling everything
select count(*) as [Num Reports] from Publications where Type = 'Research Call' and Date between @StartDate and @EndDate

-- How many readers in period?
select count(distinct ContactId) as [Num Readers] from PortalUsage where CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate

-- How many reads in period?
select count(*) as [Num Reads] from RVPortalUsage where CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate

print '*** Reads by Portal'
-- Site num reads
select ds.Site, count(*) as Reads
from RVPortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
where CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate
group by ds.Site
order by 2 desc

print '*** Top 10 Reads by Contact'
-- Who are biggest consumers?
select top(10)
  Reads = count(*),
  convert(varchar(10), ds.Site)   Site,
  convert(varchar(20), SubSite)  SubSite,
  convert(varchar(30), Account)   Account,
  convert(varchar(20), Contact)   Contact,
  convert(varchar(20), ContactId) ContactId,
  'FirstAccessDate' = (select CONVERT(varchar, MIN(ReadDate), 101) from PortalUsage where ContactId = pu.ContactId And Account = pu.Account),
  'LastAccessDate' = (select CONVERT(varchar, MAX(ReadDate), 101) from PortalUsage where ContactId = pu.ContactId And Account = pu.Account)
from PortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
where CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate
group by ds.Site, SubSite, AccountType, Account, Contact, ContactId
order by 1 desc

-- API reads

print '*** Top 10 API Reads by Contact'
-- Who are biggest consumers?
select top(10)
  Reads = count(*),
  convert(varchar(10), ds.Site)   Site,
  convert(varchar(20), SubSite)  SubSite,
  convert(varchar(30), Account)   Account,
  convert(varchar(20), Contact)   Contact,
  convert(varchar(20), ContactId) ContactId,
  convert(varchar(20), Email) Email,
  'FirstAccessDate' = (select CONVERT(varchar, MIN(ReadDate), 101) from PortalUsage where ContactId = pu.ContactId And Account = pu.Account),
  'LastAccessDate' = (select CONVERT(varchar, MAX(ReadDate), 101) from PortalUsage where ContactId = pu.ContactId And Account = pu.Account)
from PortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
where CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate
and SubSite like '%api%'
group by ds.Site, SubSite, AccountType, Account, Contact, ContactId, Email
order by 1 desc

print '*** Total API Reads by Account'
-- API Delivery by Account
select
  [API Reads] = count(*),
  convert(varchar(20), SubSite) SubSite,
  convert(varchar(40), Account)  Account
from PortalUsage 
where SubSite like '%api%'
and CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate
group by Account, SubSite
order by 1 desc

print '*** API Account History'
SELECT
  convert(varchar(40), Account) Account,
  convert(varchar(20), SubSite) SubSite,
  'FirstAccessDate' = convert(varchar,MIN(ReadDate),101),
  'LastAccessDate'  = convert(varchar,MAX(ReadDate), 101)
FROM PortalUsage 
where SubSite like '%api%'
GROUP By Account, SubSite
ORDER BY MIN(ReadDate), MAX(ReadDate), Account

-- === END QUARTERLY SCAN ===


SELECT 'BloombergAnonymousReads' = COUNT(*) 
FROM PortalUsage
WHERE Siteid = 3  AND ( [Email] = 'N/A' OR [Contact] ='N/A')
and CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate

select top 500 * from PortalUsage

select min(ReadDate) FirstAccessDate, max(ReadDate) LastAccessDate from PortalUsage

select * from RVPortalEntitlements

-- What data is missing?
select * from RVPortalUsage where PubNo     is null or len(PubNo)     = 0
select * from RVPortalUsage where ReadDate  is null or len(ReadDate)  = 0
select * from RVPortalUsage where Contact   is null or len(Contact)   = 0 -- Y
select * from RVPortalUsage where ContactId is null or len(ContactId) = 0
select * from RVPortalUsage where Account   is null or len(Account)   = 0
select * from RVPortalUsage where AccountId is null or len(AccountId) = 0
select * from RVPortalUsage where Email     is null or len(Email)     = 0 -- Y

print '*** Reads by FirmType'
-- FirmType num reads
select ds.Site, pu.FirmType, count(*) as Reads, count(distinct ContactId) as Users
from PortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
where CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate
group by ds.Site, pu.FirmType
order by 1, 2, 3 desc

print '*** Reads by SubSite'
-- Delivery num reads
-- Naveen
select ds.Site, SubSite, count(*) as Reads, count(distinct ContactId) as Users
from PortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
-- where CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate
group by ds.Site, SubSite
order by 1, 2

-- AlphaSense - Reads / Entitlements
select * from PortalUsage where SubSite = 'AlphaSense' order by ReadDate
select * from PortalEntitlements  where SubSite = 'AlphaSense' order by AsOfDate

-- API reads
select * from PortalUsage where SubSite like '%api%'
and CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate
order by Contact, ReadDate


--Usage vs Entitlements
select count(distinct Email) from RVPortalUsage
select count(distinct Email) from RVPortalEntitlements

SELECT * FROM RVPortalUsage WHERE Email NOT IN (SELECT Email FROM RVPortalEntitlements)
SELECT * FROM RVPortalEntitlements WHERE Email NOT IN (SELECT Email FROM RVPortalUsage)

SELECT * FROM RVPortalUsage   -- 1056855
MINUS
SELECT * FROM RVPortalUsage WHERE Email IN (SELECT Email FROM RVPortalEntitlements)  -- 674296

-- Q: Can disentitle just 1 delivery method?  Can we restrict API use?

/*

Disentitled on 11/18/2013
Reuters              TR API               Buyside         Two Sigma Inves ANNA GERMAN                    ANNA.GERMAN@27668
Reuters              TR API               Buyside         Two Sigma Inves Mauricio Plaza                 Mauricio.Plaza@27668

*/

-- **** API Entitlements

-- Review api entitlements and usage periodically to analyze Thomson Reuters leakage

-- By contact
select ds.Site, pe.Account, pe.Contact, pe.ContactId,  pe.Email, pe.Delivery
from PortalEntitlements pe
join DistributionSites ds on ds.SiteId = pe.SiteId
where pe.SiteId = 9                                  -- Reuters
  and pe.Delivery IN ('TR API', 'TR Desktop & API')  -- API
order by pe.Account

-- Have API reads but no active API entitlement

-- Have API entitlement but no API reads

-- By account (entitled current and reads)
select
  pe.Account,
  count(*) as NumContactsEntitled,
  'NumContactsRead' = (select count(distinct ContactId) from PortalUsage pu
                       where pu.SiteId = 9                                 -- Reuters
                         and pu.SubSite IN ('TR API', 'TR Desktop & API') -- API
                         and ReadDate between '04/01/2014' and '06/30/2014'
                         and pu.account = pe.account),
  'NumReads' = (select count(*) from PortalUsage pu
                       where pu.SiteId = 9                                 -- Reuters
                         and pu.SubSite IN ('TR API', 'TR Desktop & API') -- API
                         and ReadDate between '04/01/2014' and '06/30/2014'
                         and pu.account = pe.account),
  pe.Delivery
from PortalEntitlements pe
join DistributionSites ds on ds.SiteId = pe.SiteId
where pe.SiteId = 9                                  -- Reuters
and pe.Delivery IN ('TR API', 'TR Desktop & API')  -- API
group by ds.Site, pe.Account, pe.Delivery
order by pe.Account

select min(ReadDate) from PortalUsage

select * from PortalUsage where Account like 'Citadel%' and SubSite like '%api%' order by ReadDate

/*
API

As of 05/20/2013 TR identified the following 8 API accounts

Blackrock {Inv. Management} Count
D. E. Shaw Count
Fidelity Management & Research (Boston) Count
Invista Capital Management Count
Invista Capital Management/Principal Financial Group Count
Morgan Stanley Investment Management Count
RCM Capital Management, LLC. Count
Renaissance Technologies Corp. Count
Two Sigma Investments, LLC Count

As of 04/23/2014 Maria identified additional API accounts entitled by SCB

Ascend Capital, LLC
Putnam Investment Management, Inc
Sensato Capital Management LLC

2014 Q2 pass contained new API account use.  Maria confirmed entitled by SCB
Citadel Investment Group

2014 Q3 pass contained new API account use.
Fidelity Investments, London
Principal Global Investors

*/

-- Revised Analysis
-- 06/13/2017

DECLARE @StartDate datetime,
        @EndDate   datetime

set @StartDate = '02/01/2017'
set @EndDate   = '02/28/2017'

print '*** Period from ' + CONVERT(VARCHAR(10), @StartDate,101) + ' to ' + CONVERT(VARCHAR(10),@EndDate,101)

-- How many new reports in period?  Useful to compare reads vs. reports, i.e. pulling everything
select
  'Month'   = (select count(*) from Publications where Type in ('Research Call', 'External Flash', 'Primer') and MONTH(Date) = MONTH(DATEADD(month,  0, @StartDate)) AND YEAR(Date) = YEAR(DATEADD(month,  0, @StartDate)) ),
  'Month-1' = (select count(*) from Publications where Type in ('Research Call', 'External Flash', 'Primer') and MONTH(Date) = MONTH(DATEADD(month, -1, @StartDate)) AND YEAR(Date) = YEAR(DATEADD(month, -1, @StartDate)) ),
  'Month-2' = (select count(*) from Publications where Type in ('Research Call', 'External Flash', 'Primer') and MONTH(Date) = MONTH(DATEADD(month, -2, @StartDate)) AND YEAR(Date) = YEAR(DATEADD(month, -2, @StartDate)) ),
  'Month-3' = (select count(*) from Publications where Type in ('Research Call', 'External Flash', 'Primer') and MONTH(Date) = MONTH(DATEADD(month, -3, @StartDate)) AND YEAR(Date) = YEAR(DATEADD(month, -3, @StartDate)) )


print '*** Reads by Portal'
-- Site num reads
select distinct
  'Month'   = (select count(*) from RVPortalUsage where SiteId = pu.SiteId and MONTH(ReadDate) = MONTH(DATEADD(month,  0, @StartDate)) AND YEAR(ReadDate) = YEAR(DATEADD(month,  0, @StartDate)) ),
  'Month-1' = (select count(*) from RVPortalUsage where SiteId = pu.SiteId and MONTH(ReadDate) = MONTH(DATEADD(month, -1, @StartDate)) AND YEAR(ReadDate) = YEAR(DATEADD(month, -1, @StartDate)) ),
  'Month-2' = (select count(*) from RVPortalUsage where SiteId = pu.SiteId and MONTH(ReadDate) = MONTH(DATEADD(month, -2, @StartDate)) AND YEAR(ReadDate) = YEAR(DATEADD(month, -2, @StartDate)) ),
  'Month-3' = (select count(*) from RVPortalUsage where SiteId = pu.SiteId and MONTH(ReadDate) = MONTH(DATEADD(month, -3, @StartDate)) AND YEAR(ReadDate) = YEAR(DATEADD(month, -3, @StartDate)) ),
   ds.Site
from RVPortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
where CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate
--group by ds.Site
order by 1 desc

print '*** Top Reads by Contact - ' + CONVERT(varchar(3), @StartDate, 100) +  '-' + CONVERT(varchar, YEAR(@StartDate))
select top(50)
  'Month'   = count(*),
  'Month-1' = (SELECT COUNT(*) FROM PortalUsage WHERE Contact = pu.Contact AND
              MONTH(ReadDate) = MONTH(DATEADD(month, -1, @StartDate)) AND YEAR(ReadDate) = YEAR(DATEADD(month, -1, @StartDate)) ),
  'Month-2' = (SELECT COUNT(*) FROM PortalUsage WHERE Contact = pu.Contact AND
              MONTH(ReadDate) = MONTH(DATEADD(month, -2, @StartDate)) AND YEAR(ReadDate) = YEAR(DATEADD(month, -2, @StartDate)) ),
  'Month-3' = (SELECT COUNT(*) FROM PortalUsage WHERE Contact = pu.Contact AND
              MONTH(ReadDate) = MONTH(DATEADD(month, -3, @StartDate)) AND YEAR(ReadDate) = YEAR(DATEADD(month, -3, @StartDate)) ),
  convert(varchar(30), Account)   Account,
  convert(varchar(20), Contact)   Contact,
  convert(varchar(10), ds.Site)   Site,
  convert(varchar(20), SubSite)  SubSite,
  convert(varchar(20), ContactId) ContactId,
  'FirstAccessDate' = (select CONVERT(varchar, MIN(ReadDate), 101) from PortalUsage where ContactId = pu.ContactId And Account = pu.Account),
  'LastAccessDate' = (select CONVERT(varchar, MAX(ReadDate), 101) from PortalUsage where ContactId = pu.ContactId And Account = pu.Account)
from PortalUsage pu
join DistributionSites ds on ds.SiteId = pu.SiteId
where CONVERT(VARCHAR(10),ReadDate,101) between @StartDate and @EndDate
group by ds.Site, SubSite, FirmType, Account, Contact, ContactId
order by 1 desc


-- Reads in the last 3 fully attributed months by an API Contact
select Account, ContactId, Email, year(ReadDate) as Year, month(ReadDate) as Month, count(*) as Reads
from PortalUsage
where ContactId in ('yeetin.chau@2996', '4928', '151024') 
and YEAR(readdate) = 2017 and MONTH(ReadDate) IN (7,8,9)
and SubSite like '%api%'
group by Account, ContactId, Email, YEAR(ReadDate), MONTH(ReadDate)
order by Account, ContactId, Email, YEAR(ReadDate), MONTH(ReadDate)

PRINT '*** Blue Matrix Reads'
SELECT 'Account' = CONVERT(varchar(25), Account),
       'Reads' = COUNT(*),
       'FirstAccessDate' = CONVERT(date, MIN(ReadDate)),
       'LastAccessDate' = CONVERT(date, MAX(ReadDate))
FROM PortalUsage WHERE SiteId = 20 GROUP BY Account ORDER BY COUNT(*) DESC
