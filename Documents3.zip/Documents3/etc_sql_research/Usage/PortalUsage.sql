-- PortalUsage.sql

-- Used to populate Usage/Admin/ResearchReadership.xlsx

USE Research
GO

-- Portals reads by month per site (paste values into new YYYY detail sheet in PortalUsageYYYY.xlsx)
-- Portal Usage - Raw reads (Source: Research.PortalUsage)
SELECT
 'Year'             = YEAR(ReadDate),
 'Month'            = MONTH(ReadDate),
 'Total'            = COUNT(*),
 'ThomsonReuters'   = SUM(CASE WHEN SiteId = '9'  THEN 1 ELSE 0 END),
 'Bloomberg'        = SUM(CASE WHEN SiteId = '3'  THEN 1 ELSE 0 END),
 'FactSet'          = SUM(CASE WHEN SiteId = '12' THEN 1 ELSE 0 END),
 'CapitalIQ'        = SUM(CASE WHEN SiteId = '11' THEN 1 ELSE 0 END),
 --'TheMarkets.com'   = SUM(CASE WHEN SiteId = '13' THEN 1 ELSE 0 END),
 'BlueMatrix'       = SUM(CASE WHEN SiteId = '20' AND Email NOT LIKE '%BlueMatrix%' THEN 1 ELSE 0 END),
 'VisibleAlpha'     = SUM(CASE WHEN SiteId = '21' THEN 1 ELSE 0 END),
 'RSRCHX'           = SUM(CASE WHEN SiteId = '22' THEN 1 ELSE 0 END),
 'Red Deer'         = SUM(CASE WHEN SiteId = '23' THEN 1 ELSE 0 END)
FROM PortalUsage
WHERE YEAR(ReadDate) = 2018
  AND ExclusionId IS NULL
GROUP BY YEAR(ReadDate), MONTH(ReadDate)
ORDER BY 1, 2


--SELECT distinct SOURCE FROM Saleslogix.sysdba.vw_Readership where Type = 'PORTALUSAGE'       -- Portal Usage

-- Portal Usage - Filtered reads (Source: Saleslogix.vw_Readership)
select
  'Year'			= YEAR(ACCESSDATE),
  'Month'           = MONTH(ACCESSDATE),
  'Total'           = COUNT(*),
  'ThomsonReuters'  = SUM(case when SOURCE IN ('Reuters') then 1 else 0 end),
  'Bloomberg'       = SUM(case when SOURCE IN ('Bloomberg (SANB)') then 1 else 0 end),
  'FactSet'         = SUM(case when SOURCE IN ('FactSet') then 1 else 0 end),
  'CapitalIQ'       = SUM(case when SOURCE IN ('CapitalIQ') then 1 else 0 end),
  --'TheMarkets.com'  = SUM(case when SOURCE IN ('TheMarkets.com') then 1 else 0 end),
  'BlueMatrix'      = SUM(case when SOURCE IN ('BlueMatrix') then 1 else 0 end),
  'Visible Alpha'   = SUM(case when SOURCE IN ('Visible Alpha') then 1 else 0 end),
  'RSRCHXchange'    = SUM(case when SOURCE IN ('RSRCHXchange') then 1 else 0 end),
  'Red Deer'        = SUM(case when SOURCE IN ('Red Deer') then 1 else 0 end)
from Saleslogix.sysdba.vw_Readership VWR
inner join saleslogix.sysdba.account A on A.AccountID = VWR.AccountID
left outer join SLXExternal.dbo.ServicePointAccountType ActType on ActType.AccountType = A.Type
where year(ACCESSDATE) = 2016
and VWR.Type = 'PORTALUSAGE'           -- Portal Usage
and ActType.ClientFlag = 'Investor'    -- Investor
group by year(ACCESSDATE), month(ACCESSDATE)
order by YEAR(ACCESSDATE), MONTH(ACCESSDATE)

-- Portals reads by year per site (compare)
SELECT 
 'Year'             = YEAR(ReadDate),
 'Total'            = COUNT(*),
 'ThomsonReuters'   = SUM(CASE WHEN SiteId = '9'  THEN 1 ELSE 0 END),
 'Bloomberg'        = SUM(CASE WHEN SiteId = '3'  THEN 1 ELSE 0 END),
 'FactSet'          = SUM(CASE WHEN SiteId = '12' THEN 1 ELSE 0 END),
 'CapitalIQ'        = SUM(CASE WHEN SiteId = '11' THEN 1 ELSE 0 END),
 --'TheMarkets.com'   = SUM(CASE WHEN SiteId = '13' THEN 1 ELSE 0 END),
 'BlueMatrix'       = SUM(CASE WHEN SiteId = '20' THEN 1 ELSE 0 END),
 'VisibleAlpha'     = SUM(CASE WHEN SiteId = '21' THEN 1 ELSE 0 END),
 'RSRCHX'           = SUM(CASE WHEN SiteId = '22' THEN 1 ELSE 0 END),
 'Red Deer'         = SUM(CASE WHEN SiteId = '23' THEN 1 ELSE 0 END)
FROM PortalUsage
 WHERE ExclusionId IS NULL
GROUP BY YEAR(ReadDate)
ORDER BY 1

--READERSHIP VOLUME
-- Num New Reports - Bernstein
select year(Date), count(*) from Publications
where Type in ('Research Call', 'External Flash', 'Lighter Side', 'Black Book', 'White Book')
group by year(Date) order by 1 asc

-- Num New Reports - Portals
select year(Date), count(*) from Publications
where Type in ('Research Call') OR (Type in ('External Flash') AND Date >= '09/08/2014')
group by year(Date) order by 1 asc

--HISTORICAL READS
-- Get Total and Historical (> 30, 90, 360 days) Reads by Year
-- *** PASTE RESULTS INTO "Portal - Historical Reads"
SELECT 
'Year'          = YEAR(PU.ReadDate),
'Total'         = COUNT(*),
'Historical30'  = ( SELECT COUNT(*) FROM PortalUsage PU2
                     INNER JOIN Publications P ON P.PubNo = PU2.ContentId                 
                     WHERE DATEDIFF(day, P.Date, PU2.ReadDate) > 30
                       AND YEAR(PU2.ReadDate) = YEAR(PU.ReadDate) ),
'Historical90'  = ( SELECT COUNT(*) FROM PortalUsage PU2
                     INNER JOIN Publications P ON P.PubNo = PU2.ContentId                 
                     WHERE DATEDIFF(day, P.Date, PU2.ReadDate) > 90
                       AND YEAR(PU2.ReadDate) = YEAR(PU.ReadDate) ),
'Historical360'  = ( SELECT COUNT(*) FROM PortalUsage PU2
                     INNER JOIN Publications P ON P.PubNo = PU2.ContentId                 
                     WHERE DATEDIFF(day, P.Date, PU2.ReadDate) > 360
                       AND YEAR(PU2.ReadDate) = YEAR(PU.ReadDate) )                       
FROM PortalUsage PU
WHERE ExclusionId IS NULL
GROUP BY YEAR(PU.ReadDate)
ORDER BY 1

--Portal Reads by year and Region [US, UK, HK]
-- *** PASTE RESULTS INTO "Portal - Reads by Analyst Region"
SELECT
  'Year'  = year(PU.ReadDate),
  'Total' = ( SELECT Count(*) FROM PortalUsage PU2
              WHERE YEAR(PU2.ReadDate) = YEAR(PU.ReadDate)
              AND ExclusionId IS NULL
              GROUP BY Year(PU2.ReadDate)),
  'US'    = SUM(CASE WHEN A.RegionId = '1' THEN 1 ELSE 0 END),
  'UK'    = SUM(CASE WHEN A.RegionId = '2' THEN 1 ELSE 0 END),
  'HK'    = SUM(CASE WHEN A.RegionId = '3' THEN 1 ELSE 0 END),
  --Deleted Publications or DocId = 0
  'Unknown' = ( SELECT Count(*) FROM PortalUsage PU2 
                      WHERE ContentId NOT IN (SELECT DocId FROM RVDocuments) AND YEAR(PU2.ReadDate) = YEAR(PU.ReadDate)
                      AND ExclusionId IS NULL
                      GROUP BY Year(PU2.ReadDate)),
  'TotalByRegion' = COUNT(*)
FROM [dbo].[PortalUsage] PU
LEFT JOIN RVDocAnalysts RVDA       ON RVDA.DocId     = PU.ContentId 
                                  AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM RVDocAnalysts WHERE DocId = RVDA.DocId)
-- Note: To get RegionId, Use Authors instead of RVDocAnalystRegions
INNER JOIN Authors A ON A.AuthorID = RVDA.AnalystId
WHERE ExclusionId IS NULL
GROUP BY year(PU.ReadDate)
ORDER BY 1
-- Cannot use RVAnalysts - missing RegionId attribute
-- Do not use RVDOCAnalystRegions - returns all regions for a DocId

-- Get Total Analysts Count by Region
SELECT AR.Region, 'Total Analysts' = Count(*)
  FROM dbo.Authors A
  INNER JOIN AuthorRegions AR ON AR.RegionId = A.RegionId
 WHERE AuthorId IN ( SELECT DISTINCT AnalystId FROM ResearchCoverage WHERE DROPDATE IS NULL)
 GROUP By AR.Region

-- Call : Flash Ratio
SELECT
 'Year' = YEAR(Date),
  count(*) 'All',
  SUM(CASE WHEN Type = 'Research Call'  THEN 1 ELSE 0 END) 'Calls'
FROM Publications WHERE Type <> 'Research Summary'
GROUP BY YEAR(Date)
ORDER BY 1


/*
-- Portal Sites usage data in [PortalUsage] table with SiteId from [DistributionSites] table

-- SiteId = 9    - 'ThomsonReuters'
SELECT
  'PubNo'     =  ISNULL([Local DocID],0),
  'ReadDate'  = [Viewed Date],
  'SiteId'    = 9,  
  'Email'     = [User Email],
  'Contact'   = [User Name],
  'ContactId' = ISNULL([Unique ID],0),
  'Account'   = [Client Name],
  'AccountId' = ISNULL([Client Company ID],0)
FROM [dbo].[Tmp_ThomsonReutersReadership]
WHERE CAST(ISNULL([Local DocID],0) AS FLOAT) < 100000

-- SiteId = 3    - 'Bloomberg'
SELECT
  'PubNo'     =  ISNULL([Story ID],0),
  'ReadDate'  = [Read Date],
  'SiteId'    = 3,  
  'Email'     = [Business Email],
  'Contact'   = [User Name],
  'ContactId' = LTRIM(STR(ISNULL([UUID],50))),
  'Account'   = [Customer Name],
  'AccountId' = LTRIM(STR(ISNULL([Customer #],50)))
FROM [dbo].[Tmp_BloombergReadership]

-- SiteId = 12   - 'Factset'
SELECT
  'PubNo'     =  ISNULL([Doc ID (contributor)],0),
  'ReadDate'  = [Date/time read],
  'SiteId'    = 12,  
  'Email'     = [E-mail],
  'Contact'   = [Reader name],
  'ContactId' = LTRIM(STR(ISNULL([Reader ID (FactSet)],50))),
  'Account'   = [Firm name],
  'AccountId' = LTRIM(STR(ISNULL([Firm ID (FactSet)],50)))
FROM [dbo].[Tmp_FactsetReadership]

-- SiteId = 11   - 'CapitalIQ'
SELECT
  'PubNo'     = [Ctb Doc Id],
  'ReadDate'  = [Download Date],
  'SiteId'    = 11,  
  'Email'     = [Email],
  'Contact'   = [User Name],
  'ContactId' = LTRIM(STR(ISNULL([User],50))),
  'Account'   = [Company Name],
  'AccountId' = LTRIM(STR(ISNULL([Company],50)))
FROM [dbo].[Tmp_CapitalIQReadership]

*/

-- Portal by sub-sites e.g. AlphaSense (TR), AlphaSense (FactSet), Sentieo (TR), NASDAQ (TR)
select Site, year(ReadDate) as [Month], month(ReadDate) as [Year], SubSite, count(*) as Clicks
from PortalUsage PU
JOIN DistributionSites DS ON DS.SiteId = PU.SiteId
where year(ReadDate) = 2018 
--and month(ReadDate) IN (6,7,8)
and SubSite IN ('Alphasense', 'AlphaSense, Inc.', 'Sentieo', 'NASDAQ', 'Visible Alpha Inbox', 'POINT72 API', 'Restricted')
group by Site, SubSite, year(ReadDate), month(ReadDate)
order by 1, 4, 2, 3


select Site, year(ReadDate) as [Month], month(ReadDate) as [Year], LEFT(Account, 10), count(*) as Clicks
from RVPortalUsage
where year(ReadDate) = 2018
group by Site, LEFT(Account, 10), year(ReadDate), month(ReadDate)
order by 1, 2, 3

-- detailed portal reads on Blue Matrix by Fidelity
select DS.Site, PU.*
from portalusage PU
join distributionsites DS ON DS.SiteId = PU.SiteId
where PU.SiteId = 20 -- BlueMatrix
and account = 'Fidelity'
order by readDate desc

-- Portal #reads on Blue Matrix by account, year, report title
select DS.Site, PU.Account, year(PU.ReadDate) AS Year, PU.ContentId as PubNo, P.Title, COUNT(*) AS #Reads
from portalusage PU
join distributionsites DS ON DS.SiteId = PU.SiteId
join publications P ON P.PubNo = PU.ContentId
where PU.SiteId = 20 -- BlueMatrix
and account = 'Fidelity'
group by DS.Site, PU.Account, year(PU.ReadDate), PU.ContentId, P.Title
order by COUNT(*) DESC

