-- PortalUsageForensics.sql
-- 11/12/2013

use Research
go

-- Most reads by account
SELECT 'Reads' = Count(*), SiteId, AccountId,	Account
FROM PortalUsage
WHERE ReadDate between '1/1/2012' and '12/31/2012'
--WHERE ReadDate between '1/1/2011' and '12/31/2011'
GROUP BY SiteId, AccountId,	Account
ORDER BY 1 DESC

-- Spot check detail at account
SELECT 'ReadCount' = Count(*), Email
FROM PortalUsage
-- WHERE AccountId = '33415'
WHERE AccountId = '27668' -- Two Sigma Investments, LLC
-- WHERE AccountId = '28021' -- Renaissance Technologies Corp.
AND ReadDate between '1/1/2012' and '12/31/2012'
GROUP BY Email
ORDER BY 1 DESC

SELECT *
FROM PortalUsage
WHERE Email = 'sanda@zbi.com'
AND ReadDate between '1/1/2012' and '12/31/2012'
ORDER BY ReadDate DESC

-- *** Most reads by contact
SELECT 'Reads' = Count(*), SiteId, ContactId,	Contact
FROM PortalUsage
WHERE ReadDate between '1/1/2012' and '12/31/2012'
--WHERE ReadDate between '1/1/2011' and '12/31/2011'
GROUP BY SiteId, ContactId,	Contact
HAVING COUNT(*) > 250
ORDER BY 1 DESC

-- Per Robert 5/21/2013
-- Renaissance Technologies Corp.
SELECT 'ReadCount' = Count(*), Email
FROM PortalUsage
WHERE AccountId = '28021'
AND ReadDate between '1/1/2012' and '12/31/2012'
GROUP BY Email
ORDER BY 1 DESC

SELECT *
FROM PortalUsage
WHERE AccountId = '28021'
AND ReadDate between '1/1/2012' and '12/31/2012'
ORDER BY ReadDate DESC

SELECT
  convert(varchar(10), PU.READDATE, 102)                    AS 'Read Date',
  count(*)                                                  AS 'TotalReads',
  PU.Email
FROM PortalUsage PU
join Publications P on P.PubNo = PU.PubNo
WHERE AccountId = '28021'
AND ReadDate between '1/1/2012' and '12/31/2012'
group by PU.Email, convert(varchar(10), PU.READDATE, 102)
order by 2 desc

select * from PortalUsage where Account like '%columbia%'

select
  DS.Site,
  --PU.*
  PU.Contact,
  PU.Email,
  --PU.ContactId,
  PU.Account,
  PU.PubNo,
  PU.ReadDate
from PortalUsage PU
join DistributionSites DS on DS.SiteId = PU.SiteId
where ExclusionId is null
and Account like '%columbia%'
and ReadDate between '01/01/2011' and '12/31/2012'
-- and ReadDate >= '01/01/2012'
order by DS.Site, PU.Account, PU.Contact, PU.ReadDate


/*

Suspicious activity by roland.wunderlich.effective@27668

*/

-- Two Sigma
SELECT 'ReadCount' = Count(*), Email
FROM PortalUsage
WHERE AccountId = '27668'
AND ReadDate between '1/1/2012' and '12/31/2012'
GROUP BY Email
ORDER BY 1 DESC

-- roland.wunderlich.effective@27668
-- PubNo of 0 may indicate trying to download id that does not exist?
SELECT *
FROM PortalUsage
WHERE ContactId = 'roland.wunderlich.effective@27668'
AND ReadDate between '1/1/2012' and '12/31/2012'
ORDER BY ReadDate DESC

-- Examine pattern, passes, pub ranges, etc.
SELECT P.Date, PU.*
FROM PortalUsage PU
JOIN Publications P ON P.PubNo = PU.PubNo
WHERE ContactId = 'roland.wunderlich.effective@27668'
AND ReadDate between '1/1/2012' AND '12/31/2012'
ORDER BY ReadDate DESC

-- Max PubNo bulk reads ~ #47519 1/3/2000
SELECT TOP 50 *
FROM PortalUsage WHERE ContactId = 'roland.wunderlich.effective@27668'
AND ReadDate between '1/1/2012' and '12/31/2012'
ORDER BY PubNo DESC

-- Min PubNo bulk reads ~ #10173 3/28/2006
SELECT TOP 50 *
FROM PortalUsage WHERE ContactId = 'roland.wunderlich.effective@27668'
AND ReadDate between '1/1/2012' and '12/31/2012'
AND PubNo <> 0
ORDER BY PubNo ASC

-- How many unique reports downloaded
SELECT COUNT(DISTINCT PubNo) FROM PortalUsage WHERE ContactId = 'roland.wunderlich.effective@27668'
AND ReadDate between '1/1/2012' and '12/31/2012'
AND PubNo BETWEEN 10171 AND 47519

-- How many reports available on reuters in rage
SELECT COUNT(DISTINCT PubNo) FROM DistributionQueue
--SELECT * FROM DistributionQueue
WHERE SiteId IN (9,2) AND PubNo BETWEEN 10171 AND 47519
ORDER BY PubNo ASC

-- Every distributed Call?
--SELECT PubNo, Date FROM Publications
SELECT PubNo, Transferred FROM DistributionQueue
--WHERE Type = 'Research Call' AND PubNo BETWEEN 10173 AND 47519 AND PubNo NOT IN
WHERE SiteId = 9 AND Transferred IS NOT NULL AND PubNo BETWEEN 10171 AND 47519 AND PubNo NOT IN
(SELECT PubNo FROM PortalUsage WHERE ContactId = 'roland.wunderlich.effective@27668'
AND ReadDate between '1/1/2012' and '12/31/2012'
AND PubNo BETWEEN 10173 AND 47519)
ORDER BY PubNo ASC

select * from DistributionSites

-- 
-- -- -- -- -- -- --
-- 

--Reads per day
SELECT
  convert(varchar(10), PU.READDATE, 102)                    AS 'Read Date',
  count(*)                                                  AS 'TotalReads',
  PU.Email
FROM PortalUsage PU
join Publications P on P.PubNo = PU.PubNo
WHERE ContactId = 'roland.wunderlich.effective@27668'
AND ReadDate between '1/1/2012' and '12/31/2012'
group by PU.Email, convert(varchar(10), PU.READDATE, 102)
order by 1
--Notes: See 400-600 Reads per day from 2012.06.18 to 2012.09.06

-- Reads per Month
SELECT
  DATENAME(mm, READDATE) + ' ' + DATENAME(yy, READDATE) AS 'Read Month',
  count(*)                                              AS 'TotalReads',
  PU.Email
  --year(READDATE)  AS 'Year', 
  --month(READDATE) AS 'Month'
FROM PortalUsage PU
join Publications P on P.PubNo = PU.PubNo
WHERE ContactId = 'roland.wunderlich.effective@27668'
AND ReadDate between '1/1/2012' and '12/31/2012'
group by PU.Email, year(READDATE), month(READDATE), DATENAME(mm, READDATE) + ' ' + DATENAME(yy, READDATE)
ORDER BY year(READDATE), month(READDATE)
--Notes: See Reads per month from June-2012 until Sept-2012



-- Reuters account # 66461
-- Baruch College/CUNY - Investment Management Simulation
/*

No SLX info for account

5734 reads by 36 email addresses none of which are in SLX

*/

-- Detail reads
SELECT * FROM PortalUsage 
WHERE AccountId = '66461'
AND ReadDate between '1/1/2012' and '12/31/2012'
ORDER BY ReadDate

-- Summary reads
SELECT COUNT(*), Email FROM PortalUsage 
WHERE AccountId = '66461'
AND ReadDate between '1/1/2012' and '12/31/2012'
GROUP BY Email
ORDER BY 1 DESC

-- Examine pattern, passes, pub ranges, etc.
SELECT P.Date, PU.*
FROM PortalUsage PU
JOIN Publications P ON P.PubNo = PU.PubNo
WHERE AccountId = '66461'
AND ReadDate between '1/1/2012' AND '12/31/2012'
ORDER BY Date DESC

-- {Inv. Relations}
/*

15486 reads by accounts suffixed with {Inv. Relations}

*/

SELECT * FROM PortalUsage
WHERE ReadDate between '1/1/2012' and '12/31/2012' AND Account LIKE '%{Inv. Relations}%'
ORDER BY ReadDate DESC

SELECT COUNT(*), Account FROM PortalUsage
WHERE ReadDate between '1/1/2012' and '12/31/2012' AND Account LIKE '%{Inv. Relations}%'
GROUP BY Account
ORDER BY 1 DESC

-- GENERAL

/*

Invalid or no PubNo

Null or anonymous contacts or accounts

*/


-- Top Accounts by Reads
SELECT 'ReadCount' = Count(*), AccountId,	Account
FROM PortalUsage
WHERE ReadDate between '1/1/2012' and '12/31/2012'
GROUP BY AccountId,	Account
--HAVING COUNT(*) > 100
ORDER BY 1 DESC

-- SLX "Portal Account ID"
SELECT * FROM PortalUsage 
--WHERE AccountId = '27668'         --Two Sigma Investments, LLC
WHERE AccountId = '66461'         --Baruch College/CUNY - Investment Management Simulation
--WHERE Email = 'roland.wunderlich@twosigma.com'
AND ReadDate between '1/1/2012' and '12/31/2012'

-- Top Contacts by Reads
SELECT 'ReadCount' = Count(*), Email, ContactId,	Contact
FROM PortalUsage
WHERE ReadDate between '1/1/2012' and '12/31/2012'
GROUP BY Email, ContactId,	Contact
HAVING COUNT(*) > 100
ORDER BY 1 DESC

-- Questions:
-- * Can we Load PortalUsage data in SCB_WEB_USAGE table? 
--   ONE "Portal Account ID"[scb_entitlement] MAPS to MANY accountid[account].
--   This makes it difficult to get accurate mapping of Portal_account_id to AccountId[SLX]
--   SCB_Web_Usage   : Logs web usage by ContactId [-> AccountId -> Portal_Account_Id (scb_entitlement)]
--   SCB_Entitlement : Provides Portal_Account_Id -> AccountId relation

-- * What is the failure rate when moving data?
--   - Shows multiple AccountId linked to a "Portal Account ID"
--   Portal_Account_Id	AccountId	    Account	Type
--   73643	            A6UJ9A0004C4	Standard Life Investments Inc.
--   73643	            A6UJ9A00069W	Standard Life Investment
--   - Matching Account Name not found in SLX
--   Shows no data for certain Accounts e.g. 66461	Baruch College/CUNY - Investment Management Simulation [with 5734 portal reads]
--   - Show different Account Name in SLX e.g. '50' shows 'Ariel Investments LLC' [SLX] instead of N/A
--   - Very few Accounts have 1-1 relationship with AccountId e.g.
--   Portal_Account_Id	AccountId	      Account	Type
--   27668	            A6UJ9A0009XU	  Two Sigma Investments
--   27361	            A6UJ9A000AD7	  The Portland House Group Pty Ltd
--   18735	            A6UJ9A0005EP	  Beck, Mack & Oliver
--   -  Ideally we need a 1-to-1 mapping of Portal_Account_Id to AccountId to load accurately

--   - Identify if the Account or Contact was active before and now inactive or removed. How do we load such Portal Usage data?

-- How do we load data with PubNo of 0 or empty or NULL into SCB_WEB_USAGE table?

-- * Do we need a new table schema to store PortalUsage data? 
--   Yes, a new SLX Table e.g. SCB_PORTAL_USAGE [like PortalUsage table]

-- * Identify accounts that have high usage in Portal sites and low in SLX
--   What is the Tier rating of such accounts?



--Saleslogix   [PRODUCTION: SLXPRDDB\SALGX_PRD,16083]
USE Saleslogix
GO

-- Gets Account listing by "Portal Account ID"[PortalUsage]
SELECT DISTINCT SE.Portal_Account_Id, A.AccountId, A.Account, A.Type --, A.region, A.account_uc
FROM Saleslogix.sysdba.account A
inner join Saleslogix.sysdba.scb_entitlement SE ON SE.accountid = A.accountid
--WHERE  SE.portal_account_id IN ('27668','66461','33415','73643','50','28021','466717','629','27361','66111','112278195','3086','28119','3163','18735','3846')
where SE.portal_account_id = '27668'     -- shows 2 accounts for a portal_account_id
--where SE.portal_account_id = '73643'     -- shows 2 accounts for a portal_account_id
--where SE.portal_account_id = '66461'     -- Shows no data for 66461 [Baruch College/CUNY]
--where SE.portal_account_id = '50'          -- shows Ariel Investments LLC instead of N/A
--where account like '%Two Sigma Investments%'
ORDER BY SE.Portal_Account_Id DESC
-- Shows multiple AccountId linked to a "Portal Account ID"



--Get Total Reads by Account [AccountId vs "Portal Account ID"]
SELECT 'ReadCount' = Count(*), CN.AccountId, CN.Account
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
INNER JOIN Saleslogix.sysdba.contact CN ON CN.ContactId = UR.ContactId
WHERE UR.READ_DATE  BETWEEN '01/01/2012' AND '12/31/2012'
AND CN.AccountId IN ('A6UJ9A0009XU', 'A6UJ9A0004NM', 'A6UJ9A0007F7', 'A6UJ9A00047E', 'A6UJ9A0004AV','A6UJ9A000AD7','A6UJ9A0006E8', 'A6UJ9A000CRL',
                     'A6UJ9A0004LF', 'A6UJ9A0005EP', 'A6UJ9A0004MH')
--AND CN.Account LIKE '%Two Sigma%'
GROUP BY AccountId,	Account
ORDER BY 1 DESC
GO


--Verify the Portal Account Id from SLX  
SELECT DISTINCT Portal_Account_Id, AccountId --,  Portal_Name, Portal_Id 
FROM Saleslogix.sysdba.scb_entitlement
WHERE  portal_account_id IN ('27668','66461','33415','73643','50','28021','466717','629','27361','66111','112278195','3086','28119','3163','18735','3846')
--where AccountId IN ('A6UJ9A0009XU')
--where AccountId IN ('A6UJ9A0004NM')
ORDER BY Portal_Account_Id


-- DATA QUALITY

-- Evaluate if Portal Reads are UNIQUE or not
SELECT SiteId, PubNo, Email, convert(varchar, ReadDate, 101) AS ReadDate, COUNT(*) AS TotalReads
FROM [dbo].[PortalUsage] PU
WHERE PubNo > 0
--AND  year(ReadDate) = 2012 AND SiteId = 11
GROUP BY SiteId, PubNo, Email, Convert(varchar, ReadDate, 101)
HAVING COUNT(*) > 1
ORDER BY 5 DESC

-- Confirm the multiple reads for a PubNo on the same day by email, i.e. duplicate reads
SELECT * FROM [dbo].[PortalUsage] PU
WHERE SiteId = 13 AND PubNo = 80587 AND Email = 'bconte@coatue.com'

-- Portal Entitilements check
SELECT * FROM PortalUsage2 
WHERE SiteId = 9 AND ContactId NOT IN ( SELECT distinct [Unique ID] FROM PortalEntitlements)   -- [Client Company ID]= 21213
   --OR Email NOT IN ( SELECT distinct [Email] FROM PortalEntitlements)
--WHERE Email NOT IN ( SELECT distinct Email FROM PortalEntitlements)
ORDER BY [Account] ASC

SELECT count(*), ContactId FROM PortalUsage2
WHERE SiteId = 9 AND ContactId NOT IN ( SELECT distinct [Unique ID] FROM PortalEntitlements)   -- [Client Company ID]= 21213
   --OR Email NOT IN ( SELECT distinct [Email] FROM PortalEntitlements)
--WHERE Email NOT IN ( SELECT distinct Email FROM PortalEntitlements)
GROUP BY ContactId
ORDER BY 1 desc

SELECT * FROM PortalEntitlements 
WHERE Email IN ( SELECT Email FROM PortalUsage2)
ORDER BY [Client Name] ASC

-- 11/12/2013 - Analyze API use pattern
-- Usage appears to be in chronological publishing order
-- Comparing portal read datetimes with publishing info indicates continuous poll for new research
-- Presumably to aggregate on an internal platform

SELECT RVD.Date, RVD.RefreshDate, PU.*
FROM PortalUsage PU
join RVDocuments RVD on RVD.DocId = PU.PubNo
WHERE
--PU.AccountId = '27668' -- Two Sigma Investments, LLC
PU.AccountId = '28021' -- Renaissance Technologies Corp.
AND PU.ReadDate between '1/1/2013' and '06/30/2013'
ORDER BY 1

