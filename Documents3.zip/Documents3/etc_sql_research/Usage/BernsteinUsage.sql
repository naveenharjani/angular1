-- BernsteinUsage.sql

-- Used to populate Usage/Admin/ResearchReadership.xlsx

--SLX PRODUCTION: SLXPRDDB,16083

USE SlxExternal
GO

/*

Q: Why do read counts keep changing over time?

A: Accounts (referenced in vwUniqueReaders) are subsequently reclassified to/from Press, Industry or Internal

-- Note: vwUniqueReaders filters reads made by some Accounts based on Types (press, Industry, Internal)
----------------------------------------------------------    ------------------------------------------------------
-- CAUSE [Change in Account.Type]                             EFFECT [Change in Read Counts from vwUniqueReaders]
----------------------------------------------------------    ------------------------------------------------------
-- FROM: press, Industry, Internal                            See INCREASE in Read Counts
-- TO:   e.g. Prospect, Client, Private Equity

-- FROM: e.g. Prospect, Client, Private Equity                See DECREASE in Read Counts
-- TO:   press, Industry, Internal

*/

-- Bernstein Reads by month per source
-- Bernstein Usage - Filtered reads (Source: SlxExternal.vwUniqueReaders)
select
  year(READ_DATE)                                         AS 'Year',
  month(READ_DATE)                                        AS 'Month',
  count(*)                                                AS 'Total',
  sum(case when RVP.Product = 'Blast'                     then 1 else 0 end) AS 'Blast',
  sum(case when RVP.Product = 'Summary'                   then 1 else 0 end) AS 'Summary',
  sum(case when RVL.Source  IN ('Cart - Links', 'Cart - Highlights') then 1 else 0 end) AS 'Cart',
  sum(case when RVP.Product = 'BR.com'                    then 1 else 0 end) AS 'BR.com',
  sum(case when RVL.Source  = 'Embed Link'                then 1 else 0 end) AS 'Embed Link',
  sum(case when RVL.Source  = 'Sales Alert'               then 1 else 0 end) AS 'Sales Alert',
  sum(case when RVP.Product = 'Mobile App'                then 1 else 0 end) AS 'Mobile',
  sum(case when RVP.Product = 'Most Popular'              then 1 else 0 end) AS 'TopReads',
  sum(case when RVL.Source  = 'Sector Specialist'         then 1 else 0 end) AS 'Sector Specialist',
  --sum(case when RVP.Product = 'Models'					  then 1 else 0 end) AS 'Models',
  sum(case when RVP.Product NOT IN ('Blast','Summary','BR.com','Mobile App','Most Popular','Models') AND
                RVL.Source  NOT IN ('Cart - Links', 'Cart - Highlights','Embed Link','Sales Alert','Sector Specialist') then 1 else 0 end) AS 'Other'
from SlxExternal.dbo.vwUniqueReaders UR
join SlxExternal.dbo.RVLinkSources RVL ON RVL.Source = UR.Source
join SlxExternal.dbo.RVLinkProducts RVP ON RVL.ProductId = RVP.ProductId
where year(READ_DATE) = 2018
group by year(READ_DATE), month(READ_DATE)
order by 1, 2

-- Bernstein Usage - Filtered reads (Source: Saleslogix.vw_Readership)
select
  year(ACCESSDATE)                                         AS 'Year',
  month(ACCESSDATE)                                        AS 'Month',
  count(*)                                                 AS 'Total',
  sum(case when RVP.Product = 'Blast'                     then 1 else 0 end) AS 'Blast',
  sum(case when RVP.Product = 'Summary'                   then 1 else 0 end) AS 'Summary',
  sum(case when RVL.Source  IN ('Cart - Links', 'Cart - Highlights') then 1 else 0 end) AS 'Cart',
  sum(case when RVP.Product = 'BR.com'                    then 1 else 0 end) AS 'BR.com',
  sum(case when RVL.Source  = 'Embed Link'                then 1 else 0 end) AS 'Embed Link',
  sum(case when RVL.Source  = 'Sales Alert'               then 1 else 0 end) AS 'Sales Alert',
  sum(case when RVP.Product = 'Mobile App'                then 1 else 0 end) AS 'Mobile',
  sum(case when RVP.Product = 'Most Popular'              then 1 else 0 end) AS 'TopReads',
  sum(case when RVL.Source  = 'Sector Specialist'         then 1 else 0 end) AS 'Sector Specialist',
  --sum(case when RVP.Product = 'Models'					  then 1 else 0 end) AS 'Models',
  sum(case when RVP.Product NOT IN ('Blast','Summary','BR.com','Mobile App','Most Popular','Models') AND
                RVL.Source  NOT IN ('Cart - Links', 'Cart - Highlights',,'Embed Link','Sales Alert','Sector Specialist') then 1 else 0 end) AS 'Other'
from Saleslogix.sysdba.vw_Readership VWR
inner join SlxExternal.dbo.RVLinkSources RVL ON RVL.Source = VWR.Source
join SlxExternal.dbo.RVLinkProducts RVP ON RVL.ProductId = RVP.ProductId
inner join saleslogix.sysdba.account A on A.AccountID = VWR.AccountID
left outer join SLXExternal.dbo.ServicePointAccountType ActType on ActType.AccountType = A.Type
where year(ACCESSDATE) = 2018
and VWR.Type = 'RESEARCHUSAGE'         -- Bernstein Usage
and ActType.ClientFlag = 'Investor'    -- Investor
group by year(ACCESSDATE), month(ACCESSDATE)
order by 1, 2

-- Bernstein Reads by year per source
select
  year(READ_DATE)                                         AS 'Year',
  count(*)                                                AS 'Total',
  sum(case when RVP.Product = 'Blast'                     then 1 else 0 end) AS 'Blast',
  sum(case when RVP.Product = 'Summary'                   then 1 else 0 end) AS 'Summary',
  sum(case when RVL.Source  IN ('Cart - Links', 'Cart - Highlights') then 1 else 0 end) AS 'Cart',
  sum(case when RVP.Product = 'BR.com'                    then 1 else 0 end) AS 'BR.com',
  sum(case when RVL.Source  = 'Embed Link'                then 1 else 0 end) AS 'Embed Link',
  sum(case when RVL.Source  = 'Sales Alert'               then 1 else 0 end) AS 'Sales Alert',
  sum(case when RVP.Product = 'Mobile App'                then 1 else 0 end) AS 'Mobile',
  sum(case when RVP.Product = 'Most Popular'              then 1 else 0 end) AS 'TopReads',
  sum(case when RVL.Source  = 'Sector Specialist'         then 1 else 0 end) AS 'Sector Specialist',
  sum(case when RVP.Product NOT IN ('Blast','Summary','BR.com','Mobile App','Most Popular','Models') AND
                RVL.Source  NOT IN ('Cart - Links', 'Cart - Highlights',,'Embed Link','Sales Alert','Sector Specialist') then 1 else 0 end) AS 'Other'
from SlxExternal.dbo.vwUniqueReaders UR
join SlxExternal.dbo.RVLinkSources RVL ON RVL.Source = UR.Source
join SlxExternal.dbo.RVLinkProducts RVP ON RVL.ProductId = RVP.ProductId
where year(READ_DATE) = 2018
group by year(READ_DATE)
order by 1, 2


-- Get Total and Historical (30 days) Reads by Year
DECLARE @ReadDays   INT
SET @ReadDays = 30

SELECT 
'Year'        = YEAR(UR.READ_DATE),
'Total'       = (SELECT COUNT(*) FROM SlxExternal.dbo.vwUniqueReaders WHERE YEAR(READ_DATE) = YEAR(UR.READ_DATE)),
'Historical'  = COUNT(*)
FROM SlxExternal.dbo.vwUniqueReaders UR
INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = UR.PubNo
WHERE DATEDIFF(day, RVD.Date, UR.READ_DATE) > @ReadDays          -- > 30 days reads
GROUP BY YEAR(UR.READ_DATE)
ORDER BY 1

-- Get Total and Historical (> 30, 90, 360 days) Reads by Year
SELECT 
'Year'          = YEAR(UR.READ_DATE),
'Total'         = COUNT(*),
'Historical30'  = ( SELECT COUNT(*) FROM SlxExternal.dbo.vwUniqueReaders UR2
                     INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = UR2.PubNo                 
                     WHERE DATEDIFF(day, RVD.Date, UR2.READ_DATE) > 30
                       AND YEAR(UR2.READ_DATE) = YEAR(UR.READ_DATE) ),
'Historical90'  = ( SELECT COUNT(*) FROM SlxExternal.dbo.vwUniqueReaders UR2
                     INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = UR2.PubNo                 
                     WHERE DATEDIFF(day, RVD.Date, UR2.READ_DATE) > 90
                       AND YEAR(UR2.READ_DATE) = YEAR(UR.READ_DATE) ),
'Historical360'  = ( SELECT COUNT(*) FROM SlxExternal.dbo.vwUniqueReaders UR2
                     INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = UR2.PubNo                 
                     WHERE DATEDIFF(day, RVD.Date, UR2.READ_DATE) > 360
                       AND YEAR(UR2.READ_DATE) = YEAR(UR.READ_DATE) )                       
FROM SlxExternal.dbo.vwUniqueReaders UR
--WHERE YEAR(ReadDate) = 2012
GROUP BY YEAR(UR.READ_DATE)
ORDER BY 1


--Portal Reads by year and Region [US, UK, HK]
SELECT 
  'Year'  = YEAR(UR.READ_DATE),
  'Total' = COUNT(*),
  'US'    = SUM(CASE WHEN RVDAR.RegionId = '1' THEN 1 ELSE 0 END),
  'UK'    = SUM(CASE WHEN RVDAR.RegionId = '2' THEN 1 ELSE 0 END),
  'HK'    = SUM(CASE WHEN RVDAR.RegionId = '3' THEN 1 ELSE 0 END)
FROM SlxExternal.dbo.vwUniqueReaders UR
LEFT JOIN SlxExternal.dbo.RVDocAnalysts RVDA        ON RVDA.DocId    = UR.PUBNO AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
LEFT JOIN SlxExternal.dbo.RVDOCAnalystRegions RVDAR ON RVDAR.DocId   = RVDA.DocId
GROUP BY YEAR(UR.READ_DATE)
ORDER BY 1
-- Cannot use RVAnalysts - missing RegionId attribute
-- Do not use RVDOCAnalystRegions - returns all regions for a DocId