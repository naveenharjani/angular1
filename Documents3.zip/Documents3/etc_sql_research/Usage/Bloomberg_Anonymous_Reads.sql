-- Bloomberg_Anonymous_Reads.sql
-- 05/27/2015


-- Load pass 1 (ftp file)
-- SELECT * INTO [dbo].[Tmp_BloombergReadership_Pass1] FROM [dbo].[Tmp_BloombergReadership]
-- SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1] ORDER BY [Read Date]

-- Load pass 2 (email provided file)
-- SELECT * INTO [dbo].[Tmp_BloombergReadership_Pass2] FROM [dbo].[Tmp_BloombergReadership]
-- SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass2] ORDER BY [Read Date]



-- Check total counts 
SELECT COUNT(*) FROM [dbo].[Tmp_BloombergReadership_Pass1]
SELECT COUNT(*) FROM [dbo].[Tmp_BloombergReadership_Pass2]
--WHERE [Transaction ID] IS NOT NULL



-- Check anonymous counts
SELECT COUNT(*) FROM [dbo].[Tmp_BloombergReadership_Pass1]  WHERE [User Name] ='N/A' OR [Customer #] IS NULL
SELECT COUNT(*) FROM [dbo].[Tmp_BloombergReadership_Pass2]  WHERE [User Name] ='N/A' OR [Customer #] IS NULL


-- Is every Transaction Id in Pass 1 exists in Pass 2
--Missing
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass2]
EXCEPT
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass2]
WHERE [Transaction ID] IN (SELECT [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass1])
/*
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass2]
WHERE [Transaction ID] NOT IN (SELECT distinct [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass1])
*/

SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1]
EXCEPT
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1]
WHERE [Transaction ID] IN (SELECT [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass2])
/*
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1] 
WHERE [Transaction ID] NOT IN (SELECT distinct [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass2])
*/



-- Is every Transaction Id in Pass 1 (filter anonymous reads) exists in Pass 2
-- Exists[Matching]
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass2]
WHERE [Transaction ID] IN (SELECT [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass1] WHERE ( [User Name] ='N/A' OR [Customer #] IS NULL))

-- Missing
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1]
WHERE ( [User Name] ='N/A' OR [Customer #] IS NULL)
EXCEPT
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1]
WHERE ( [User Name] ='N/A' OR [Customer #] IS NULL)
AND [Transaction ID] IN (SELECT [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass2])



-- Duplicate reads by Transaction Id
SELECT [Transaction ID], COUNT(*) FROM [dbo].[Tmp_BloombergReadership_Pass1] 
GROUP BY [Transaction ID] 
HAVING COUNT(*) >= 2 ORDER BY 2 desc



-- Sample reads by Transaction Id
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1] WHERE [Transaction ID] = '992569ffe46e8da9'
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass2] WHERE [Transaction ID] = '992569ffe46e8da9'

SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1] WHERE [Transaction ID] = '9271da041aa1a996'
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass2] WHERE [Transaction ID] = '9271da041aa1a996'














/*

--SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1]
--WHERE ( [User Name] ='N/A' OR [Customer #] IS NULL)
--AND [Transaction ID] IN (SELECT [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass2])
--SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1]
--WHERE ( [User Name] ='N/A' OR [Customer #] IS NULL)
--AND [Transaction ID] NOT IN (SELECT [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass2])

--SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass2] 
--WHERE ( [User Name] ='N/A' OR [Customer #] IS NULL)
--AND [Transaction ID] NOT IN (SELECT [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass1])
--SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass2] 
--WHERE ( [User Name] ='N/A' OR [Customer #] IS NULL)
--AND [Transaction ID] IN (SELECT [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass1]


--SELECT * FROM [dbo].[Tmp_BloombergReadership] ORDER BY [Read Date]
-- --TRUNCATE TABLE [dbo].[Tmp_BloombergReadership] stop

SELECT distinct [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass1] -- 59831
SELECT distinct [Transaction ID] FROM [dbo].[Tmp_BloombergReadership_Pass2] -- 59455

SELECT [Transaction ID], COUNT(*) FROM [dbo].[Tmp_BloombergReadership_Pass1] 
GROUP BY [Transaction ID] 
HAVING COUNT(*) >= 2 ORDER BY 2 desc

SELECT [Transaction ID], COUNT(*) FROM [dbo].[Tmp_BloombergReadership_Pass2] 
GROUP BY [Transaction ID] 
HAVING COUNT(*) >= 2 ORDER BY 2 desc

SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass1] WHERE [Transaction ID] = '992569ffe46e8da9'
SELECT * FROM [dbo].[Tmp_BloombergReadership_Pass2] WHERE [Transaction ID] = '992569ffe46e8da9'

SELECT * FROM distributionsites
SELECT * FROM [dbo].[Tmp_BloombergReadership] ORDER BY [Read Date] ASC
*/