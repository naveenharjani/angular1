-- PortalUsageExclusions.sql
-- 05/29/2013

/*

High-volume automated consumption can be excluded
1)  Add an exlcusion decription to PortalUsageExclusions
2)  Update related rows for exlcusion in PortalUsage
=> These row will be excluded when replicating PortalUsage to RVPortalUsage

insert into PortalUsageExclusions values ('Two Sigma - API use by roland.wunderlich.effective@27668')
insert into PortalUsageExclusions values ('Baruch College/CUNY - Investment Management Simulation - Exclude use by ThomsonReuters portal account 66461')
insert into PortalUsageExclusions values ('TR API')

*/

use Research
go

select * from PortalUsageExclusions

select convert(varchar(75), Account) Account, convert(varchar(25), Contact) Contact, count(*) from PortalUsage
where ExclusionId is not null
group by convert(varchar(75), Account), convert(varchar(25), Contact)
order by 3 desc

-- select * from PortalUsage where ExclusionId is not null

-- Set exclusions

update PortalUsage set ExclusionId = 1 where ContactId = 'roland.wunderlich.effective@27668'
update PortalUsage set ExclusionId = 2 where AccountId = '66461'
update PortalUsage set ExclusionId = 3 where ContactId = 'aaa.ghermansson@28021'
update PortalUsage set ExclusionId = 3 where ContactId = 'philippe.roux@28021'
update PortalUsage set ExclusionId = 3 where ContactId = 'Mauricio.Plaza@27668'
update PortalUsage set ExclusionId = 3 where ContactId = 'ANNA.GERMAN@27668'
update PortalUsage set ExclusionId = 3 where ContactId = 'ernest.chow1@61559'

-- Review exclusions

select * from PortalUsage where ContactId = 'roland.wunderlich.effective@27668' order by ReadDate
SELECT * FROM PortalUsage WHERE AccountId = '66461' ORDER BY ReadDate
select * from PortalUsage where ContactId = 'Mauricio.Plaza@27668' order by ReadDate
select * from PortalUsage where ContactId = 'ANNA.GERMAN@27668' order by ReadDate

select * from PortalUsage where ContactId = 'aaa.ghermansson@28021' order by ReadDate
select * from PortalUsage where ContactId = 'philippe.roux@28021' order by ReadDate
select * from PortalUsage where ContactId = 'ernest.chow1@61559' order by ReadDate

-- Naveen
SELECT
  SiteId, 
--  AccountId,
  'Account'   = CONVERT(varchar(40), Account),
--  'ContactId',
   Contact = CONVERT(varchar(40), Contact),
--   Email,
   Delivery,
  'Reads' = COUNT(*),
  'FirstAccessDate' = CONVERT(varchar, MIN(ReadDate), 101),
  'LastAccessDate'  = CONVERT(varchar, MAX(ReadDate), 101)
FROM PortalUsage 
WHERE ExclusionId IS NOT NULL
GROUP BY SiteId, AccountId, Account, ContactId, Contact, Email, Delivery
ORDER BY COUNT(*) DESC

-- Contact Exclusions
SELECT
  PU.Account,
  PU.Contact,
  PU.ContactId,
  DS.Site,
  'Reads'     = COUNT(*),
  'FirstAccessDate' = CONVERT(varchar, MIN(PU.ReadDate), 101),
  'LastAccessDate'  = CONVERT(varchar, MAX(PU.ReadDate), 101)
FROM PortalUsage PU
JOIN DistributionSites DS ON PU.SiteId = DS.SiteId
WHERE PU.ExclusionId IS NOT NULL
  AND PU.AccountId NOT IN ('66461')
GROUP BY DS.Site, PU.Account, PU.Contact, PU.ContactId
UNION
-- Account Exclusions
SELECT
  PU.Account,
  'ALL',
  'ALL',
  DS.Site,
  'Reads'     = COUNT(*),
  'FirstAccessDate' = CONVERT(varchar, MIN(PU.ReadDate), 101),
  'LastAccessDate'  = CONVERT(varchar, MAX(PU.ReadDate), 101)
FROM PortalUsage PU
JOIN DistributionSites DS ON PU.SiteId = DS.SiteId
WHERE PU.ExclusionId IS NOT NULL
  AND PU.AccountId IN ('66461')
GROUP BY DS.Site, PU.Account
ORDER BY 7, COUNT(*) DESC


  'Account'   = CONVERT(varchar(40), PU.Account),
  'Contact'   = CONVERT(varchar(40), PU.Contact),

3919        TR API               Two Sigma Investments, LLC               Mauricio Plaza                           Mauricio.Plaza@27668
3888        TR API               Two Sigma Investments, LLC               ANNA GERMAN                              ANNA.GERMAN@27668
2155        TR API               Sensato Capital Management LLC           Ernest Chow                              ernest.chow1@61559
1940        TR API               Renaissance Technologies Corp.           Gudjon Hermansson                        aaa.ghermansson@28021
1865        TR API               Renaissance Technologies Corp.           Philippe Roux                            philippe.roux@28021
