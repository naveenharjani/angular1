-- Trending_Readership.sql
-- 06/04/2018

-- Trending readership by read period (not publishing period)
-- Fred Gilde

DECLARE
 @vSinceDate DATE,
 @vUntilDate DATE,
 @vRegion    VARCHAR(2),
 @SinceDays  INT

--SET @vUntilDate = '06/28/2018' --SET @vUntilDate = '07/06/2018' --SET @vUntilDate = '07/13/2018' 
--SET @vUntilDate = '08/01/2018' --SET @vUntilDate = '08/03/2018' --SET @vUntilDate = '08/10/2018' --SET @vUntilDate = '08/17/2018' --SET @vUntilDate = '08/31/2018'
--SET @vUntilDate = '09/07/2018' --SET @vUntilDate = '09/14/2018' --SET @vUntilDate = '09/21/2018' --SET @vUntilDate = '09/28/2018' 
--SET @vUntilDate = '10/05/2018' --SET @vUntilDate = '10/12/2018' --SET @vUntilDate = '10/19/2018' --SET @vUntilDate = '10/26/2018'
--SET @vUntilDate = '11/02/2018' --SET @vUntilDate = '11/09/2018' --SET @vUntilDate = '11/16/2018' --SET @vUntilDate = '11/23/2018' --SET @vUntilDate = '11/30/2018'
--SET @vUntilDate = '12/07/2018' --SET @vUntilDate = '12/14/2018' --SET @vUntilDate = '12/21/2018' --SET @vUntilDate = '12/28/2018'
--SET @vUntilDate = '01/04/2019' --SET @vUntilDate = '01/11/2019' --SET @vUntilDate = '01/18/2019' --SET @vUntilDate = '01/25/2019'
--SET @vUntilDate = '02/01/2019' --SET @vUntilDate = '02/08/2019' --SET @vUntilDate = '03/01/2019' --SET @vUntilDate = '03/08/2019'
--SET @vUntilDate = '03/15/2019' --SET @vUntilDate = '03/22/2019' --SET @vUntilDate = '03/29/2019' --SET @vUntilDate = '04/05/2019'
--SET @vUntilDate = '04/12/2019' --SET @vUntilDate = '04/19/2019' --SET @vUntilDate = '05/03/2019' --SET @vUntilDate = '05/10/2019'
--SET @vUntilDate = '05/17/2019' --SET @vUntilDate = '05/24/2019' --SET @vUntilDate = '05/31/2019' --SET @vUntilDate = '06/07/2019'
--SET @vUntilDate = '06/14/2019' --SET @vUntilDate = '06/21/2019' --SET @vUntilDate = '06/28/2019' --SET @vUntilDate = '07/05/2019'
--SET @vUntilDate = '07/12/2019' --SET @vUntilDate = '07/19/2019' --SET @vUntilDate = '07/26/2019' --SET @vUntilDate = '08/02/2019'
--SET @vUntilDate = '08/09/2019' --SET @vUntilDate = '08/16/2019' --SET @vUntilDate = '08/23/2019' --SET @vUntilDate = '08/30/2019'
--SET @vUntilDate = '09/06/2019' --SET @vUntilDate = '09/13/2019' --SET @vUntilDate = '09/20/2019' --SET @vUntilDate = '09/27/2019'
--SET @vUntilDate = '10/11/2019' --SET @vUntilDate = '10/18/2019' --SET @vUntilDate = '10/25/2019' --SET @vUntilDate = '11/01/2019'
--SET @vUntilDate = '11/08/2019' SET @vUntilDate = '11/15/2019'  --SET @vUntilDate = '11/22/2019'  SET @vUntilDate = '11/29/2019'
--SET @vUntilDate = '12/13/2019' --SET @vUntilDate = '12/20/2019'  
SET @vUntilDate = '01/03/2019'

SET @SinceDays = 7
SET @vSinceDate = DATEADD(d, -@SinceDays, @vUntilDate)

--SET @vSinceDate = getdate() - 7
--SET @vUntilDate = getdate()
--SET @vRegion = 'US'    -- US, UK, AP

PRINT 'Reports read FROM: ' + CONVERT(varchar, @vSinceDate, 106) + ' TO: ' + CONVERT(varchar, @vUntilDate, 106)
SELECT DISTINCT
  RVAR.Region,
  'Primary Analyst' = RVDA.Last,
  'Analyst(s)' = STUFF(( SELECT ', ' + RVDA.Last AS [text()] FROM SlxExternal.dbo.RVDocAnalysts RVDA
        WHERE RVDA.DocId = v1.PubNo ORDER BY RVDA.OrdinalId FOR XML PATH('')), 1, 1, '' ),
  'ID' = v1.PubNo,
  'Report Date' = CONVERT(varchar, RVD.Date, 106),
  -- Document Type Alias
  'Type' = CASE RVT.DocType
    WHEN 'Research Call'  THEN 'Call'
    WHEN 'External Flash' THEN 'QuickTake'
    WHEN 'Research Note'  THEN 'Note'
    WHEN 'Black Book'     THEN 'Blackbook'
    WHEN 'White Book'     THEN 'Whitebook'
    ELSE RVT.DocType
  END,
  RVD.Title,
  'Period Reads' = v1.Reads,
  'Total Reads' = v2.Reads
FROM (SELECT PubNo, 'Reads' = COUNT(*) FROM SlxExternal.dbo.Readership with (nolock)
       WHERE ReadDate BETWEEN @vSinceDate AND @vUntilDate 
         AND Type = 'ResearchUsage' AND AccountType = 'Investor'      -- Bernstein Investor reads
       GROUP BY PubNo) AS v1
INNER JOIN (SELECT PubNo, 'Reads' = COUNT(*) FROM SlxExternal.dbo.Readership with (nolock) 
            WHERE Type = 'ResearchUsage' AND AccountType = 'Investor' -- Bernstein Investor reads
            GROUP BY PubNo) AS v2 ON v2.PubNo = v1.PubNo
INNER JOIN SlxExternal.dbo.RVDocuments RVD with (nolock) ON RVD.DocId = v1.PubNo
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA with (nolock) on RVDA.DocId = v1.PubNo
AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts with (nolock) WHERE DocId = RVDA.DocId)  -- primary analyst filter

-- get all analysts for a research
INNER JOIN SlxExternal.dbo.RVDocAnalystRegions RVDAR with (nolock) on RVDAR.DocId = v1.PubNo
INNER JOIN SlxExternal.dbo.RVAnalystRegions RVAR with (nolock) on RVAR.RegionId = RVDAR.RegionId

-- Uncomment Filter where primary analyst = region
INNER JOIN SlxExternal.dbo.RVAnalysts RVA ON RVA.AnalystId = RVDA.AnalystId
INNER JOIN SlxExternal.dbo.RVAnalystRegions RVAR2 with (nolock) on RVAR2.RegionId = RVA.RegionId AND RVAR2.Region = RVAR.Region

INNER JOIN SlxExternal.dbo.RVResearchCoverage RVRC ON RVRC.AnalystId = RVDA.AnalystId AND RVRC.DropDate IS NULL -- analyst filter by active coverage
INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId
--WHERE RVAR.Region = @vRegion	-- reports containing analyst with this region
ORDER BY RVAR.Region, v1.Reads DESC
