--11/19/2019
--David Patafio
/*
Could I ask you to pull a quick query for a McKinsey inquiry? 
They�re trying to dimension how much we publish on a few metrics.
For active analysts, YTD, could I see in excel, the following:
How many unique pieces of research we�ve published 1) by sector (e.g. Consumer), 2) by Analyst, and 3) by company (any time company is tagged, not just single stock reports)?
Let me know if you have any questions, or if there�s someone else I should reach out to for this info.
*/
select S.Sector,count(distinct V.PubNo) from vFinancials V join Industries I on V.IndustryId = I.IndustryId
join Sectors S on I.SectorId = S.SectorID
--join ResearchCoverage RC on V.CoverageId = RC.CoverageID
where
V.Date >= '01/01/2019'
group by S.Sector
with rollup


select A.Name,count(distinct V.PubNo) from vFinancials V 
join Authors A on V.AnalystId = A.AuthorID
--join ResearchCoverage RC on V.CoverageId = RC.CoverageID
where
V.Date >= '01/01/2019'
group by A.Name
with rollup

select S.Ticker,S.Company, S.CompanyId,count(distinct V.PubNo) from vFinancials V 
join Securities2 S on V.SecurityId = S.SecurityID
--join ResearchCoverage RC on V.CoverageId = RC.CoverageID
where
S.TickerType = 'Stock' and
V.Date >= '01/01/2019'
group by S.Ticker,S.Company,S.CompanyId
order by Company


