
declare @enddate datetime
declare @startdate datetime
declare @securityid int
--set @enddate = '12/31/2005'
--set @startdate = '07/01/2004'
--set @enddate = '12/31/2007'
--set @startdate = '01/01/2006'
set @enddate = '11/13/2008'
set @startdate = '01/01/2008'

set @securityid = 0

  declare @rating char(1)
  declare @launchdate datetime
  declare @dropdate datetime
  declare @ticker varchar(30)
  declare @coverageid int
  
  declare @process_startdate datetime
  declare @process_enddate datetime
  
  set nocount on
  
  if @StartDate = ''
    set @startdate = dateadd(dd,-5,@EndDate)
  
  --Delete data for the last 5 days and repopulate
  --This is done, to accomodate any corrections in ratings(resubmits)
  delete from dbo.dailyratings where date between @StartDate and @EndDate

  --cursor for active coverage  
  if @SecurityId = 0
  begin
    declare cur_ticker cursor for
    select s.ticker,s.securityid,rc.launchdate,rc.dropdate,rc.coverageid from researchcoverage rc join Securities2 s on rc.securityid = s.securityid
    where 
    launchdate <= @EndDate AND (dropdate >= @StartDate or DropDate is null)
    order by ticker
  end
  else
  begin
    declare cur_ticker cursor for
    select s.ticker,s.securityid,rc.launchdate,rc.dropdate,rc.coverageid from researchcoverage rc join Securities2 s on rc.securityid = s.securityid
    where 
    launchdate <= @EndDate AND (dropdate >= @StartDate or DropDate is null) and
    s.SecurityId = @SecurityId
    order by ticker
  end
  
  open cur_ticker
  
  fetch next from cur_ticker into @ticker,@securityid,@launchdate,@dropdate,@coverageid
  while @@fetch_status = 0
  begin
    if @launchdate > @startdate 
      set @process_startdate = @launchdate 
    else 
      set @process_startdate = @startdate
    
    if (@dropdate is null) or (@dropdate > @enddate)
      set @process_enddate = @enddate 
    else      
      set @process_enddate = @dropdate 
    
      while @process_startdate <= @process_enddate
      begin
          --if a row exists for current ticker and specified date
          --get rating and targetprice from tickertablesecurities
          if exists (select * from tickertablesecurities tts join publications p on tts.pubno = p.pubno where ticker = @ticker and date = @process_startdate)
          begin
                select @rating = rating 
                from 
                  tickertablesecurities tts join publications p on tts.pubno = p.pubno 
                where 
                ticker = @ticker and 
                date = @process_startdate and
                p.pubno = (select max(p2.pubno) 
                          from tickertablesecurities tts2 join publications p2 on tts2.pubno = p2.pubno 
                          where date = @process_startdate and tts2.ticker = @ticker)
                
                insert into dbo.dailyratings(date,securityid,rating,coverageid)
                select @process_startdate,@securityid,@rating,@coverageid
          end
          --if no row exists for current ticker and specified date
          --carry the rating and targetprice values from previous day
          else
          begin
                insert into dbo.dailyratings(date,securityid,rating,coverageid)
                select @process_startdate,securityid,rating,coverageid
                from dbo.dailyratings
                where
                securityid = @securityid and 
                date = dateadd(dd,-1,@process_startdate)
          end
        set @process_startdate = dateadd(dd,1,@process_startdate)
      end
    fetch next from cur_ticker into @ticker,@securityid,@launchdate,@dropdate,@coverageid
  end
  close cur_ticker
  deallocate cur_ticker