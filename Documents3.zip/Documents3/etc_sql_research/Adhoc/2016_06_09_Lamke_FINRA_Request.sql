drop table #TmpAnalysts
drop table #TmpSecurities
go

select P.PubNo,P.Title,P.Date,P.Type,A.Name,Pr.PropNo AuthorOrderid  
into #TmpAnalysts
from Publications P join Properties Pr on P.Pubno = Pr.Pubno
join Authors A on Pr.PropValue = A.Name
where Date between '05/26/2016' and '05/26/2017'
and P.Type not in ('Video')
and Pr.PropId = (select PropId from PropertyNames where PropName = 'Author')
and A.IsAnalyst = -1 
and A.RegionId = 1
order by P.Pubno
go

select T.PubNo,T.Title,T.Date,T.Type,T.Name,T.AuthorOrderId,S.Ticker,S.Company, Pr.PropNo TickerOrderId,Rating,RatingPrior,RatingAction
into #TmpSecurities
from
#TmpAnalysts T join Authors A on T.Name = A.Name
join ResearchCoverage RC on A.AuthorId = RC.AnalystId
join Securities2 S on RC.SecurityId = S.SecurityId
join Properties Pr on T.Pubno = Pr.Pubno and Pr.PropValue = S.Ticker
left outer join PublicationFinancials PF on T.Pubno = PF.Pubno and S.Ticker = PF.Ticker
where
Pr.PropId = (select PropId from PropertyNames where PropName = 'Ticker')
order by PubNo,AuthorOrderId,TickerOrderId
go

select *
from #TmpSecurities 
where
RatingAction in ('Initiate','Upgrade','Downgrade')
order by PubNo,AuthorOrderId,TickerOrderId
go