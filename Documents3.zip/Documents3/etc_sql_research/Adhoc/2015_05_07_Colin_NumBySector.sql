-- 2015_05_07_Colin_NumByIndustry.sql
-- 05/07/2015

-- Colin McGrahan: 5/7/2015
-- shows the number of reports by type (Research Call, QT, Blackbook, Weekend Blast) for every sector globally in 2014. 
-- Would want the rows to be sector name, NOT analyst name

SELECT I.IndustryName,
       SUM(CASE WHEN P.Type = 'Research Call'  THEN 1 ELSE 0 END) AS 'Calls',
       SUM(CASE WHEN P.Type = 'External Flash' THEN 1 ELSE 0 END) AS 'Flashes',
       SUM(CASE WHEN P.Type = 'Black Book'     THEN 1 ELSE 0 END) AS 'Blackbooks',
       SUM(CASE WHEN P.Type = 'Research Call' AND P.Title LIKE '%Blast%'
                                               THEN 1 ELSE 0 END) AS 'Blasts'
FROM Publications P
INNER JOIN Properties Pr ON Pr.PubNo = P.PubNo AND Pr.PropId = 11    -- Industry
INNER JOIN Industries I ON I.IndustryName = Pr.PropValue
--INNER JOIN Sectors S ON S.SectorID = I.SectorId
WHERE YEAR(P.Date) = 2014
GROUP BY I.IndustryName
ORDER BY I.IndustryName ASC

select * from Publications where Title like '%Blast%' and YEAR(Date) = 2014
order by Title, Date


/*

SELECT * FROM PropertyNames WHERE PropName = 'Industry'
*/