-- SAC
-- 11/30/2012

select
--V.SecurityID,
V.Ticker,
V.Date,
--V.PubNo,
--V.CoverageAction,
V.Rating,
V.RatingPrior,
V.RatingAction,
V.TargetPrice,
V.TargetPricePrior,
'CUR' = S.CurrencyCode,
V.TargetPriceAction,
/*
V.TargetPriceOrig,
V.LastYear,
V.ThisYear,
V.NextYear,
V.EPSType,
V.EPSLastYear,
V.EPSThisYear,
V.EPSThisYearPrior,
V.EstimateAction,
V.EPSNextYear,
V.EPSNextYearPrior,
V.MetricType,
V.MetricLastYear,
V.MetricThisYear,
V.MetricNextYear,
V.Currency,
V.YTDRelPerf,
V.Yield,
V.LaunchDate,
V.DropDate,
V.FileName,
V.CoverageId,
V.IndustryId,
V.AnalystId,
*/
A.Last
from vFinancials V
JOIN Authors A ON A.AuthorID = V.AnalystID
JOIN Securities2 S ON S.SecurityId = V.SecurityId
where  V.Date >= '1/1/2012'
and V.Date <= '11/30/2012'
AND (RatingAction IN ('UPGRADE', 'DOWNGRADE') OR TargetPriceAction IN ('INCREASE', 'DECREASE'))
order by V.Date desc, Ticker, PubNo desc
