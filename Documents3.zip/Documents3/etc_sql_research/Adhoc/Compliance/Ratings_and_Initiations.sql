-- Ratings_and_Initiations.sql

-- Quarterly Compliance Ratings and Initiations Report (Ratings_and_Initiations.xls)
-- 03/17/2009 - (01/01/2009-03/17/2009)
-- 01/05/2010 - (01/01/2009-01/05/2010)
-- 04/14/2010 - (01/01/2009-present)
-- 07/20/2010 - (01/01/2010-present)
-- 10/14/2010 - (01/01/2010-present)
-- 10/11/2013 - (01/01/2013-present) per Coulter, Bertan

select
  'Date' = convert(char(10), V.Date, 101),
  V.Ticker,
  'CoverageAction' = isnull(V.CoverageAction, ''),
  V.Rating,
  'RatingPrior' = isnull(V.RatingPrior, ''),
  V.RatingAction,
  'LaunchDate' = convert(char(10), V.LaunchDate, 101),
  'DropDate' = isnull(convert(char(10), V.DropDate, 101), ''),
  'Analyst' = A.Last
from vFinancials V
join Authors A ON A.AuthorID = V.AnalystID
where  V.Date >= '1/1/2013' AND (CoverageAction IN ('INITIATE', 'DROP', 'RESUME', 'SUSPEND') OR RatingAction IN ('UPGRADE', 'DOWNGRADE', 'INITIATE', 'DROP'))
order by V.Date, Ticker
