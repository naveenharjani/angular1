-- Internal Audit.sql

select
  PubNo,
  'Report Date' = convert(varchar(10), Date, 101),
  CASE Type
    WHEN 'Research Call'    THEN 'Call'
    WHEN 'Research Note'    THEN 'Note'
    WHEN 'Black Book'       THEN 'Blackbook'
    WHEN 'White Book'       THEN 'Whitebook'
    WHEN 'Research Summary' THEN 'Summary'
    ELSE Type
  END 'Type',
--  'Approved Date' = ApprovedDate,
  'Published Date/Time' = PublishedDate,
  Approver,
  Title
from Publications where Date = '11/04/2008'
order by PubNo
