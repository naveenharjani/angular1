-- Compliance.sql

-- 12/01/2008 - LEH subpoena
select -- Revisions
  'copy \\researchfs.acml.com\research\pubs\' + FileName,
  '"\\nts0016\rsch1\compliance\LEH Revisions\' + convert(varchar(8), PubNo) + '_' + convert(varchar, DocNo) + '.pdf"'
from DocumentsLog
where PubNo in (53230,57573,58047,59363,60150,60948,61129,61221,61590,62398,62489,62531,62635,62644,62683,63069,63502,63531,63726,63992)
and DocType = 'PDF'
order by PubNo, DocNo

select -- Active
  'copy \\researchfs.acml.com\research\pubs\' + FileName,
  '"\\nts0016\rsch1\compliance\LEH Revisions\' + convert(varchar(8), PubNo) + '.pdf"'
from Documents
where PubNo in (53230,57573,58047,59363,60150,60948,61129,61221,61590,62398,62489,62531,62635,62644,62683,63069,63502,63531,63726,63992)
and DocType = 'PDF'
order by PubNo, DocNo

-- 12/09/2008 - LEH subpoena
select -- Revisions (original in \pubs folder)
  'copy \\researchfs.acml.com\research\pubs\' + DL.FileName,
  '"\\nts0016\rsch1\compliance\LEH Revisions\' + convert(varchar(8), DL.PubNo) + '_' + convert(varchar, DL.DocNo) + '.pdf"'
--from DocumentsLog
from DocumentsLog DL join AuditLog AL on AL.AuditNo = DL.AuditNo
where DL.PubNo in (56230)
and DL.DocType = 'PDF' and AL.Operation = 'R' -- 
order by PubNo, DocNo

select -- Revisions (original in \pubs\deleted folder)
  'copy \\researchfs.acml.com\research\pubs\deleted\D' + DL.FileName,
  '"\\nts0016\rsch1\compliance\LEH Revisions\' + convert(varchar(8), DL.PubNo) + '_' + convert(varchar, DL.DocNo) + '.pdf"'
from DocumentsLog DL join AuditLog AL on AL.AuditNo = DL.AuditNo
where DL.PubNo in (56230)
and DL.DocType = 'PDF' and AL.Operation = 'R' -- 
order by PubNo, DocNo

select -- Active
  'copy \\researchfs.acml.com\research\pubs\' + FileName,
  '"\\nts0016\rsch1\compliance\LEH Revisions\' + convert(varchar(8), PubNo) + '.pdf"'
from Documents
where PubNo in (56230)
and DocType = 'PDF'
order by PubNo, DocNo

select DL.*, AL.*
from DocumentsLog DL join AuditLog AL on AL.AuditNo = DL.AuditNo
where PubNo in (56230)
and DocType = 'PDF'
order by PubNo, DocNo

-- 04/08/2009 FINRA AUDIT
-- 04/13/2009 FINRA AUDIT
-- Research Reports
select
  'ID'     = PU.PubNo,
  'Date'   = convert(char(10), PU.Date, 111),
  'Type'   = PU.Type,
  'Title'  = PU.Title,
  'Author' = PR.PropValue
from Publications PU
join Properties PR on PR.PubNo = PU.PubNo and PR.PropID = 5 -- Author
and PropNo = (select min(PropNo) from Properties where PropID = 5 and PubNo = PU.PubNo) -- Primary Author
where Date >= '01/01/2007'
and Type <> 'Flash'
order by Date

-- Termination Reports
select
  'ID'     = PU.PubNo,
  'Date'   = convert(char(10), PU.Date, 111),
  'Type'   = PU.Type,
  'Title'  = PU.Title,
  'Author' = PR.PropValue
from Publications PU
join Properties PR on PR.PubNo = PU.PubNo and PR.PropID = 5 -- Author
and PropNo = (select min(PropNo) from Properties where PropID = 5 and PubNo = PU.PubNo) -- Primary Author
where Date >= '01/01/2007'
and PU.PubNo in (select PubNo  from vFin
ials where CoverageAction in ('Drop', 'Suspend'))
order by Date

-- 06/24/2009 - GS subpoena
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName,
  '"\\nts0016\rsch1\compliance\GS\External GS Research 060199 to 060103\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date >= '06/01/1999' and Date <= '06/01/2003' 
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue = 'GS'
order by P.PubNo

-- 06/24/2009 - GS subpoena
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName,
  '"\\nts0016\rsch1\compliance\GS\Internal and External GS Research 060199 to 060103\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date >= '06/01/1999' and Date <= '06/01/2003'
and pr.propid = 13
and pr.propvalue = 'GS'
order by P.PubNo

-- 08/25/2009 - MU inquiry
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName,
  '"\\nts0016\rsch1\compliance\MU 010101-123102\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date >= '01/01/2001' and Date <= '12/31/2002'
and pr.propid = 13
and pr.propvalue = 'MU'
order by P.PubNo

-- 10/16/2009 - Dell external research
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance\Dell 010102-123106\External Reports\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date >= '01/01/2002' and Date <= '12/31/2006' 
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue = 'DELL'
order by P.PubNo

-- 10/16/2009 - Dell all research
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance\Dell 010102-123106\Internal and External Reports\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date >= '01/01/2002' and Date <= '12/31/2006'
and pr.propid = 13
and pr.propvalue = 'DELL'
order by P.PubNo

-- 04/06/2010 - CFC external research
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\CFC 01_01_2005-12_31_2007\External Reports\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date >= '01/01/2005' and Date <= '12/31/2007' 
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue = 'CFC'
order by P.PubNo

-- 06/16/2010 - MDT
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\MDT 01012006-061610\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date >= '01/01/2006'
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue = 'MDT'
order by P.PubNo

-- 07/27/2010 - Sal - AuthorEmail.xls
select Last, First, ExtEmail, 'Analyst', EditDate from Authors where IsAnalyst = -1 and IsActive = -1
union
select Last, First, ExtEmail, 'Associate', EditDate from Authors where IsAnalyst <> -1 and IsActive = -1
order by 4, Last

-- 09/29/2010 - BA
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\BA-02_01_2009-07_31_2009\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '02/01/2009' and '07/31/2009'
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue = 'BA'
order by P.PubNo

--Unlaunched coverage For Leslie Stern - 10/15/2010
SELECT  
  Industry    = I.IndustryName,  
  Analyst     = A.Last + ', ' + A.First,  
  Ticker      = S.Ticker,  
  Company     = S.Company,  
  --MetaAnalyst = A.Name,  
  --CoverageID  = C.CoverageID,  
  c.EditDate
FROM ResearchCoverage C  
JOIN Industries I ON I.IndustryID = C.IndustryID  
JOIN Authors A ON A.AuthorID = C.AnalystID  
LEFT JOIN Securities2 S ON S.SecurityID = C.SecurityID -- SecurityID OPTIONAL, THEREFORE LEFT JOIN  
LEFT JOIN vFinancialsLatest FL ON FL.CoverageID = C.CoverageID   
WHERE C.LaunchDate IS NULL AND C.DropDate IS NULL
ORDER BY Industry,Analyst

-- 01/07/2011 - ING
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\ING\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2007' and '04/06/2009'
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue = 'INGA.NA'
order by P.PubNo

--05/06/2011 Sanofi-Aventis Securities Subpoena
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\Sanofi-Aventis-05_06_2011\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date >= '01/01/2005' 
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue in ('SAN.FP','SNY')
order by P.PubNo

--03/06/2012 Merck March 1, 1999 - December 31, 2004
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\MRK_(Merck)_1999_03_01_TO_2004_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '03/01/1999' and '12/31/2004'
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue in ('MRK')
order by P.PubNo

--01/13/2012 Dana Corp Jan 1, 2004 - March 31, 2006
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\DCN_(Dana Corp)_2004_01_01_TO_2006_03_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2004' and '03/31/2006'
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue in ('DCN')
order by P.PubNo

--03/26/2012 Lockheed Martin Corporation Jan 1, 2008 - Current
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\LMT_(Lockheed Martin)_2008_01_01_TO_Current\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date >= '01/01/2008' 
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue in ('LMT')
order by P.PubNo

--06/18/2012 Dell Jan 1, 2008 to Dec 31, 2008
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\DELL_(Dell Inc)_2008_01_01_TO_2008_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date >= '01/01/2008' 
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue in ('DELL')
order by P.PubNo

--07/23/2012 JPM April 1, 2011 to May 31, 2012
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\JPM_(JPMorgan)_2011_04_01_TO_2012_05_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '04/01/2011' and '05/31/2012'
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue in ('JPM')
order by P.PubNo

-- 08/15/2013 FINRA AUDIT
-- Research Reports
-- DG
select 
  'ID'     = PU.PubNo,
  'Author' = PR.PropValue,
  'Security' = S.Company,
  'Symbol' = S.Ticker,
  'Date'   = convert(char(10), PU.Date, 111),
  'Type'   = PU.Type,
  'Title'  = PU.Title,
  'Price Target' = TargetPrice,
  Rating
from Publications PU 
join Properties PR on PR.PubNo = PU.PubNo and PR.PropID = 5 -- Author
and PR.PropNo = (select min(PropNo) from Properties where PropID = 5 and PubNo = PU.PubNo) -- Primary Author
join Properties PR2 on PR2.PubNo = PU.PubNo and PR2.PropID = 13 -- Ticker
join Securities2 S on Pr2.PropValue = S.Ticker
left join TickerTableSecurities TTS on PU.Pubno = TTS.Pubno and TTS.Ticker = S.Ticker
where PU.Date between '09/01/2011' and '06/30/2013'
and S.Ticker = 'DG'
order by Date

-- PTLA
select 
  'ID'     = PU.PubNo,
  'Author' = PR.PropValue,
  'Security' = S.Company,
  'Symbol' = S.Ticker,
  'Date'   = convert(char(10), PU.Date, 111),
  'Type'   = PU.Type,
  'Title'  = PU.Title,
  'Price Target' = TargetPrice,
  Rating
from Publications PU 
join Properties PR on PR.PubNo = PU.PubNo and PR.PropID = 5 -- Author
and PR.PropNo = (select min(PropNo) from Properties where PropID = 5 and PubNo = PU.PubNo) -- Primary Author
join Properties PR2 on PR2.PubNo = PU.PubNo and PR2.PropID = 13 -- Ticker
join Securities2 S on Pr2.PropValue = S.Ticker
left join TickerTableSecurities TTS on PU.Pubno = TTS.Pubno and TTS.Ticker = S.Ticker
where PU.Date between '09/01/2011' and '06/30/2013'
and S.Ticker = 'PTLA'
order by Date

-- 09/16/2013
-- DELL 01/01/2007 to 12/31/2010
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\DELL_2007_01_01_TO_2010_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2007' and '12/31/2010'
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue in ('DELL')
order by P.PubNo

-- 03/05/2014 - Larry Bertan
-- SEC exam
select 
  'Date'   = convert(char(10), PU.Date, 111),
  'ID'     = PU.PubNo,
  'Type'   = PU.Type,
  'Title'  = PU.Title,
  'Ticker' = VF.Ticker,
  'Rating' = VF.Rating
from Publications PU 
join Properties PR on PR.PubNo = PU.PubNo and PR.PropId = 13 -- Ticker
join vFinancials VF on VF.PubNo = PU.PubNo and VF.Ticker = PR.PropValue
where PU.Date between '07/01/2013' and '09/30/2013'
order by PU.Date, PU.PubNo

-- 03/05/2014 - Jim Lamke
-- Multi-exchange companies
-- Attorney general settlement / no alpha capture
-- MultiTickerCompanyCoverage.xlsx
select S.Company, S.Ticker, EX.ExchangeCode, EX.Exchange, A.Name 
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join Authors A on A.AuthorId = RC.AnalystId
join Exchanges EX on EX.ExchangeCode = S.ExchangeCode
where RC.LaunchDate is not null and RC.DropDate is null
and S.Company in (select S2.Company from Securities2 S2 join ResearchCoverage RC2 on S2.SecurityId = RC2.SecurityId 
                  where RC2.LaunchDate is not null and RC2.DropDate is null
                  group by S2.Company 
                  having count(distinct S2.ExchangeCode) > 1)
order by 1, 2

-- 04/09/2014 - Chris Mahon
-- NY Attorney General
-- Reports published in 2012/2013 by US-based analysts
select distinct AU.Last + ', ' + AU.First, AR.Region
from Publications PU
join Properties PR on PR.PubNo = PU.PubNo and PR.PropId = 5 -- Author
join Authors AU on AU.Name = PR.PropValue and IsAnalyst = -1
join AuthorRegions AR on AR.RegionId = AU.RegionId
where PU.Date between '01/01/2012' and '12/31/2013'
order by 2, 1

select distinct P.PubNo,
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\NYAG_2012_01_01_TO_2013_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.PubNo = pr.PubNo and Pr.PropId = 5
join Authors AU on AU.Name = Pr.PropValue and IsAnalyst = -1
join AuthorRegions AR on AR.RegionId = AU.RegionId and AR.RegionId = 1
where P.Date between '01/01/2012' and '12/31/2013' 
and P.Type not in ('Video')
and Pr.PropValue not in ('Ann Marie Larson','Vadim Zlotnikov','Steve McBee')
union 
select distinct P.PubNo,
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\NYAG_2012_01_01_TO_2013_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.PubNo = pr.PubNo and Pr.PropId = 5
where P.Date between '01/01/2012' and '12/31/2013' 
and P.Type not in ('Video')
and Pr.PropValue in ('Andrew Wood', 'FinbarSheehy', 'Gianluca Gottoli')
order by P.PubNo


--10/07/2014 JPM Jan 1, 2011 to Dec 31, 2012
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\JPM_(JPMorgan)_2011_01_01_TO_2012_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2011' and '12/31/2012'
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue in ('JPM')
order by P.PubNo

--12/05/2014 FRE Jan 1, 2005 to June 29 2005
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\FRE_(FreddiMac)_2005_01_01_TO_2005_06_29\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2005' and '06/29/2005'
and Type <> 'Flash' 
and pr.propid = 13
and pr.propvalue in ('FRE')
order by P.PubNo

--02/04/2016 AGN Dec 1, 2013 to Feb 04 2016
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\AGN_2013_12_01_TO_2016_02_04\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '12/01/2013' and '02/04/2016'
--where Date > '12/01/2013' 
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('AGN')
order by P.PubNo

--07/29/2016 ALDR 06/11/2014 to 09/18/2015
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\ALDR_2014_11_06_TO_2015_18_09\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '06/11/2014' and '09/18/2015'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('ALDR')
order by P.PubNo

--07/29/2016 ALDR 01/01/2006 to 12/31/2014
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\DF_2006_01_01_TO_2014_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2006' and '12/31/2014'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('DF')
order by P.PubNo

--05/03/2017 Metlife 04/19/2002 to 03/08/2012
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\MET_2002_04_19_TO_2012_03_08\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '04/19/2002' and '03/08/2012'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('MET')
order by P.PubNo

--11/02/2017 - LEH 12/01/2007 to 09/15/2008
--Jim Lamke
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\LEH_2007_12_01_TO_2008_09_15\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '12/01/2007' and '09/15/2008'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('LEH')
order by P.PubNo

-- 01/23/2018
-- Jim Lamke
-- Produce a list of all published documents by the below individuals in Hong Kong.
-- We are undergoing an examination by the SFC and need to produce a list of the documents.
-- From January 1, 2017 through (and including) December 31, 2017.
-- We need the following data in the produced list:
-- Date issued, Time Issued, Type of Research Issued (Call, Flash, Quant, etc.), Title of Research Issued,
-- Company(ies) being written upon, Recommendation, Recipient List (if any)
SELECT
  P.PubNo ID,
   -- 'P.Date' stores Report Date date component without the time part (e.g. 2018-01-23 00:00:00) - never changes
  'Report Date' = Convert(Date, P.Date),         -- report date that never changes 
  --  'Time Issued' = Convert(Varchar, P.Date, 108), -- no time part
  -- 'P.PublishedDate' stores date and time part (e.g. 2018-01-23 14:17:00) - changes on resubmits
  --'Date Issued' = Convert(Date, P.PublishedDate),
  --'Time Issued' = Convert(Varchar, P.PublishedDate, 108),
  'Report Type' = (CASE P.Type
              WHEN 'Research Call'  THEN 'Call'
              WHEN 'External Flash' THEN 'Quick Take'
              WHEN 'Black Book'     THEN 'Blackbook'
              WHEN 'White Book'     THEN 'Whitebook'
            ELSE P.Type
            END),
  P.Title,
  'Analyst' = A.Last + ', ' + A.First,
  S.Company,
  S.Ticker,
  'Recommendation' = ISNULL(PF.Rating, '')
FROM Publications P
JOIN Properties Pr ON Pr.PropId = 5 AND Pr.PubNo = P.PubNo       -- Author
JOIN Authors A ON Pr.PropValue = A.Name
JOIN Properties Pr2 ON Pr2.PropId = 13 AND Pr2.PubNo = P.PubNo   -- Ticker[s]
JOIN Securities2 S ON S.Ticker =  Pr2.PropValue AND S.TickerType = 'Stock'
LEFT JOIN PublicationFinancials PF ON PF.PubNo = P.PubNo AND PF.Ticker = S.Ticker
WHERE P.Date BETWEEN '01/01/2017' AND '12/31/2017'
AND A.AuthorId IN (783, 609, 595, 756, 623, 768, 488, 487, 342, 431, 649, 703, 582, 653, 474)
ORDER BY P.PubNo, P.Date, A.Last, S.Company, S.OrdNo

--03/01/2018 - MDT 1/01/2013 to 4/10/2015
--Subpoena
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\MDT_2013_01_01_TO_2015_04_10\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2013' and '04/10/2015'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('MDT')
order by P.PubNo

--06/20/2018 - Micron (MU) 01/01/2015 to 12/31/2018
--subpoena
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\MU_2015_01_01_TO_2018_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2015' and '12/31/2018'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('MU')
order by P.PubNo

--06/20/2018 - Micron (MU) 01/01/2015 to 12/31/2018
--subpoena
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\MU_2015_01_01_TO_2018_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2015' and '12/31/2018'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('MU')
order by P.PubNo

--06/20/2018 - Samsung (005930.KS) 01/01/2015 to 12/31/2018
--subpoena
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\005930.KS_2015_01_01_TO_2018_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2015' and '12/31/2018'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('005930.KS')
order by P.PubNo

--06/20/2018 - Hynix (000660.KS) 01/01/2015 to 12/31/2018
--subpoena
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\compliance-inquiries\000660.KS_2015_01_01_TO_2018_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2015' and '12/31/2018'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('000660.KS')
order by P.PubNo

--12/18/2018 - Hynix (SHP.LN) 06/01/2014 to 11/30/2014
--subpoena
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\Compliance-Inquiries\SHP.LN_2014_06_01_TO_2014_11_30\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '06/01/2014' and '11/30/2014'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('SHP.LN')
order by P.PubNo

--02/20/2019 - Lamke - List of Canadian domiciled companies under research coverage
select
  S.Company + ' (' + S.Ticker + ')' as Company
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null
and S.ExchangeCode = 'CN'
order by 1

--07/02/2019 - Lexmark (LXK) 01/01/2014 - 12/31/2016
--subpoena
--Copy files from \\nts0016\rsch1\Compliance-Inquiries\LXK_2014_01_01_TO_2016_12_31\ to \\acntnyc043\alliance\legal\LXK folder
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\Compliance-Inquiries\LXK_2014_01_01_TO_2016_12_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2014' and '12/31/2016'
and Type <> 'Flash' and Type <> 'Video'
and pr.propid = 13
and pr.propvalue in ('LXK')
order by P.PubNo
go

--08/08/2019 - Bertan - Report list for 2019 FINRA Exam
--10/16/2019
select distinct
  'Date' = CAST(P.Date as DATE),
  'Type' =
    CASE P.Type
      WHEN 'Research Call'  THEN 'Call'
      WHEN 'External Flash' THEN 'Quick Take'
      WHEN 'Black Book'     THEN 'Blackbook'
      WHEN 'White Book'     THEN 'Whitebook'
      WHEN 'Research Note'  THEN 'Note'
      ELSE Type
    END,
  P.Title,
  'Language' = 'English',
  'Author Region' = AR.Region,
  P.Approver
-- *
from Publications P
join Properties Pr ON Pr.PubNo = P.PubNo AND Pr.PropId = 5 -- Author
join Authors A ON A.Name = Pr.PropValue
join AuthorRegions AR ON AR.RegionId = A.RegionId
where Date >= '07/29/2018' and Date <= '07/29/2019'
and Type not in ('Video')
and AR.Region <> 'US'
order by 1

--09/04/2019 - Gupta/Bertan - Coverage and Ratings Changes for 2019 FINRA Exam
select
  'Date' = convert(char(10), V.Date, 101),
  S.Company,
  V.Ticker,
  'Analyst' = A.Last + ', ' + A.First,
  'Rating Action' = V.RatingAction,
  V.Rating,
  'Rating Prior' = isnull(V.RatingPrior, '')
from vFinancials V
join Securities2 S on S.SecurityId = V.SecurityId
join Authors A ON A.AuthorId = V.AnalystId
where V.Date >= '07/29/2018'
and V.Date <= '07/29/2019'
and RatingAction in ('UPGRADE', 'DOWNGRADE', 'INITIATE', 'DROP')
order by V.Date, S.Company, S.OrdNo

-- 10/16/2019 - Bertan FINRA - Authorized authors (analysts and associates)
select distinct
  A.Last,
  A.First,
  'Analyst' as Author
from ResearchCoverage RC
join Authors A on A.AuthorId = RC.AnalystId
where RC.LaunchDate is not null and RC.DropDate is null

union

select
  x.Last,
  x.First,
  'Associate' as Author
from
(select
  LastLogon = (select max(EditDate) from SessionLog where UserId = U.UserId),
  A.*
from Authors A
join Users U on U.UserName = A.WindowsUserName
where isAnalyst = 0
and IsActive = -1) x
where datediff(d, x.LastLogon, getdate()) < 30
order by 3, 1, 2

--06/04/2020 - Johnson & Johnson (JNJ) 02/01/2012 - 06/04/2020
--subpoena
--Copy files from \\nts0016\rsch1\Compliance-Inquiries\JNJ_2012_02_01_TO_2020_06_04\ to \\acntnyc043\alliance\JNJ folder
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\Compliance-Inquiries\JNJ_2012_02_01_TO_2020_06_04\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '02/01/2012' and '06/04/2020'
and Type not in ('Flash','Video','Podcast')
and pr.propid = 13
and pr.propvalue in ('JNJ')
order by P.PubNo
go

--12/14/2020 - Tesla (JNJ) 07/31/2017 - 10/31/2018
--subpoena
--Copy files from \\nts0016\rsch1\Compliance-Inquiries\TSLA_2017_07_31_TO_2018_31_10\ to \\acntnyc043\alliance\tsla folder
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\Compliance-Inquiries\TSLA_2017_07_31_TO_2018_10_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '07/31/2017' and '10/31/2018'
and Type not in ('Flash','Video','Podcast')
and pr.propid = 13
and pr.propvalue in ('TSLA')
order by P.PubNo
go

--02/19/2021
--subpoena
--Copy files from \\nts0016\rsch1\Compliance-Inquiries\NVIDIA_2017_01_01_TO_2019_01_31\ to \\acntnyc043\alliance\nvidia folder
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\Compliance-Inquiries\NVIDIA_2017_01_01_TO_2019_01_31\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '01/01/2017' and '01/31/2019'
and Type not in ('Flash','Video','Podcast')
and pr.propid = 13
and pr.propvalue in ('NVDA')
order by P.PubNo
go

--06/23/2021
--subpoena
--Copy files from \\nts0016\rsch1\Compliance-Inquiries\UBER_2018_11_10_TO_2021_06_23\ to \\acntnyc043\alliance\uber folder
select
  'copy \\researchfs.acml.com\research\pubs\' + FileName + ' ' +
  '"\\nts0016\rsch1\Compliance-Inquiries\UBER_2018_11_10_TO_2021_06_23\' + convert(varchar(8), P.PubNo) + '.pdf"'
from Publications p join Properties pr on p.pubno = pr.pubno
where Date between '11/10/2018' and '06/23/2021'
and Type not in ('Flash','Video','Podcast')
and pr.propid = 13
and pr.propvalue in ('UBER')
order by P.PubNo
go