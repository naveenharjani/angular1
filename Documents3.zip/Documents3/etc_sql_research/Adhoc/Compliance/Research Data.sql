select A.Last,P.PubNo,Date,Type,Title
from Publications P join (select Pubno, min(PropNo) PropNo from Properties where PropId = 5 group by Pubno) pr on P.Pubno = Pr.Pubno
join Properties Pr2 on Pr.PropNo = Pr2.PropNo
join Authors A on A.Name = Pr2.PropValue and RegionId = 1
where
Date between '06/01/2012' and '08/31/2012'
order by A.Last,Pubno

