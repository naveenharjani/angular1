--------------------------------------------------------------------------------------------------
BEGIN
	DECLARE @AnalystId int
	SET @AnalystId = 226        --Get only the last 15 days data
	
	DECLARE @AnalystName varchar(50)

	DECLARE @EmailAddressId varchar(100)
	DECLARE @PubNo int
	DECLARE @ReadCount int

	DECLARE @PubNoRowCount int

	DECLARE @PubNo_1 int, @PubNo_2 int, @PubNo_3 int, @PubNo_4 int, @PubNo_5 int
	DECLARE @PubNo_6 int, @PubNo_7 int, @PubNo_8 int, @PubNo_9 int, @PubNo_10 int

	DECLARE @PubNo_1_Read int, @PubNo_2_Read int, @PubNo_3_Read int, @PubNo_4_Read int, @PubNo_5_Read int
	DECLARE @PubNo_6_Read int, @PubNo_7_Read int, @PubNo_8_Read int, @PubNo_9_Read int, @PubNo_10_Read int

	SELECT RSCH_ANALYSTID INTO #TmpSearch FROM sysdba.SCB_RSCH_ANALYSTS WHERE 1 = 2
	
	SELECT @AnalystName = RSCH_ANALYSTNAME from sysdba.SCB_RSCH_ANALYSTS WHERE RSCH_ANALYSTID = @AnalystId

	INSERT INTO #TmpSearch 
	SELECT @AnalystId 	
	
	--Select * from #TmpSearch

	-- Create saleslogix Load temp table and insert all valid data for the report needs
	CREATE TABLE ##SlxPubReadTemp
		( RSCH_ANALYSTID int, RSCH_ANALYSTNAME varchar(48), USER_EMAIL_ADDR varchar(100),
		  PUBNO_1 int, PUBNO_1_READ int,
		  PUBNO_2 int, PUBNO_2_READ int,
		  PUBNO_3 int, PUBNO_3_READ int,
		  PUBNO_4 int, PUBNO_4_READ int,
		  PUBNO_5 int, PUBNO_5_READ int,
		  PUBNO_6 int, PUBNO_6_READ int,
		  PUBNO_7 int, PUBNO_7_READ int,
		  PUBNO_8 int, PUBNO_8_READ int,
		  PUBNO_9 int, PUBNO_9_READ int,
		  PUBNO_10 int, PUBNO_10_READ int,
		  LoadDate datetime default getdate())

	--Declare a CURSOR for the Slx Email_Address Reads.
	DECLARE curSlxEmailRead CURSOR FOR
		SELECT  distinct v1.ACCESS_EMAIL_ADDR  --,v2.RSCH_PRIMARYANALYSTID, V1.PUBNO
		FROM
		(
			select PUBNO, ACCESS_EMAIL_ADDR
			from
			(
				select distinct SWU.PUBNO, SWU.ACCESS_EMAIL_ADDR
				  from sysdba.SCB_WEB_USAGE SWU 
				 inner join sysdba.CONTACT C on C.CONTACTID = SWU.CONTACTID
				 inner join sysdba.ACCOUNT A on C.ACCOUNTID = A.ACCOUNTID and ISNULL(A.TYPE, '') <> 'Industry/Press'
				 where SWU.STATUS = 'T' and not SWU.ACCESS_EMAIL_ADDR like '%@bernstein.com'
				   and SWU.FILEFOUND = 'Y'
				   and SWU.PUBNO <> '99999999'
			) as UNIQUE_READERS
			where  isnull(ACCESS_EMAIL_ADDR,'') <> ''
			group by PUBNO, ACCESS_EMAIL_ADDR		
		) as v1
		LEFT JOIN sysdba.scb_rsch_properties v2 ON v1.PUBNO = v2.PUBNO
		WHERE V1.PubNo in (SELECT top 10 PUBNO 
							 FROM sysdba.SCB_RSCH_ANALYSTS 
						    WHERE RSCH_ANALYSTID = @AnalystId --226 
						    ORDER BY PUBNO DESC)
		  AND v2.RSCH_PRIMARYANALYSTID = @AnalystId --226
		  AND isnull(V2.pubtype,'') NOT IN ('Research Summary')
		ORDER BY v1.ACCESS_EMAIL_ADDR --,v2.RSCH_PRIMARYANALYSTID
	---------------------------------------------------------------------------------

	--Declare a CURSOR for the Slx PubNo Reads.
	DECLARE curSlxPubnoRead CURSOR FOR
		SELECT top 10 PUBNO AS PUBNO
		FROM   sysdba.SCB_RSCH_ANALYSTS
		--WHERE RSCH_ANALYSTID in ( SELECT RSCH_ANALYSTID FROM #TmpSearch)
		WHERE RSCH_ANALYSTID = @AnalystId  --226
		ORDER BY PUBNO DESC
	---------------------------------------------------------------------------------

	--Open the Email_Addr Cursor
	OPEN curSlxEmailRead

	--Open the PubNo Cursor
	OPEN curSlxPubnoRead

	FETCH NEXT FROM curSlxEmailRead
	INTO @EmailAddressId

		-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
		WHILE @@FETCH_STATUS = 0
		BEGIN

			SET @PubNoRowCount = 0
			-- Perform the first fetch and store the values in variables.
			-- Note: The variables are in the same order as the columns in the SELECT statement. 
			FETCH NEXT FROM curSlxPubnoRead
			INTO @PubNo

			-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
			WHILE @@FETCH_STATUS = 0
			BEGIN

				SET @PubNoRowCount = @PubNoRowCount + 1
				---------------------------------------------------------------------------------

--				DECLARE @EmailAddressId varchar(50)
--				DECLARE @PubNo int
--				DECLARE @ReadCount int

				select distinct @PubNo = SWU.PUBNO, @EmailAddressId = SWU.ACCESS_EMAIL_ADDR, @ReadCount = count(*)
				from sysdba.SCB_WEB_USAGE SWU
				where SWU.STATUS = 'T'
				  and not SWU.ACCESS_EMAIL_ADDR like '%@bernstein.com'
				  and SWU.PUBNO = @PubNo  --61680
                  and SWU.ACCESS_EMAIL_ADDR = @EmailAddressId   --'acherwenka@templeton.com'
				group by SWU.PUBNO, SWU.ACCESS_EMAIL_ADDR

--				select  @PubNo, @EmailAddressId, @ReadCount

				---------------------------------------------------------------------------------
				
				IF @PubNoRowCount = 1 
				BEGIN
					SET @PubNo_1 = @PubNo
					SET @PubNo_1_Read = @ReadCount
				END
				ELSE IF @PubNoRowCount = 2 
				BEGIN
					SET @PubNo_2 = @PubNo
					SET @PubNo_2_Read = @ReadCount
				END
				ELSE IF @PubNoRowCount = 3 
				BEGIN
					SET @PubNo_3 = @PubNo
					SET @PubNo_3_Read = @ReadCount
				END
				ELSE IF @PubNoRowCount = 4 
				BEGIN
					SET @PubNo_4 = @PubNo
					SET @PubNo_4_Read = @ReadCount
				END
				ELSE IF @PubNoRowCount = 5
				BEGIN
					SET @PubNo_5 = @PubNo
					SET @PubNo_5_Read = @ReadCount
				END
				ELSE IF @PubNoRowCount = 6
				BEGIN
					SET @PubNo_6 = @PubNo
					SET @PubNo_6_Read = @ReadCount
				END
				ELSE IF @PubNoRowCount = 7
				BEGIN
					SET @PubNo_7 = @PubNo
					SET @PubNo_7_Read = @ReadCount
				END
				ELSE IF @PubNoRowCount = 8
				BEGIN
					SET @PubNo_8 = @PubNo
					SET @PubNo_8_Read = @ReadCount
				END
				ELSE IF @PubNoRowCount = 9
				BEGIN
					SET @PubNo_9 = @PubNo
					SET @PubNo_9_Read = @ReadCount
				END
				ELSE IF @PubNoRowCount = 10
				BEGIN
					SET @PubNo_10 = @PubNo
					SET @PubNo_10_Read = @ReadCount
				END


				FETCH NEXT FROM curSlxPubnoRead
				INTO @PubNo

			END

			---------------------------------------------------------------------------------
			INSERT INTO ##SlxPubReadTemp
				(RSCH_ANALYSTID, RSCH_ANALYSTNAME, USER_EMAIL_ADDR, 
				PUBNO_1, PUBNO_1_READ,
    			PUBNO_2, PUBNO_2_READ,
				PUBNO_3, PUBNO_3_READ,
				PUBNO_4, PUBNO_4_READ,
				PUBNO_5, PUBNO_5_READ,
				PUBNO_6, PUBNO_6_READ,
				PUBNO_7, PUBNO_7_READ,
				PUBNO_8, PUBNO_8_READ,
				PUBNO_9, PUBNO_9_READ,
				PUBNO_10, PUBNO_10_READ,
				LoadDate)
				VALUES(@AnalystId, @AnalystName, @EmailAddressId,
				 @PubNo_1, @PubNo_1_Read, @PubNo_2, @PubNo_2_Read, @PubNo_3, @PubNo_3_Read, @PubNo_4, @PubNo_4_Read, @PubNo_5,@PubNo_5_Read,
				 @PubNo_6, @PubNo_6_Read, @PubNo_7, @PubNo_7_Read, @PubNo_8, @PubNo_8_Read, @PubNo_9, @PubNo_9_Read, @PubNo_10, @PubNo_10_Read,
				 getdate())
			---------------------------------------------------------------------------------

			FETCH NEXT FROM curSlxEmailRead
			INTO @EmailAddressId			
		END

	CLOSE curSlxEmailRead
	DEALLOCATE curSlxEmailRead

	CLOSE curSlxPubnoRead
	DEALLOCATE curSlxPubnoRead


	PRINT 'Report to display Publications Reads for a Research Analyst. Analyst Id:'-- || @AnalystId
	PRINT '--------------------- ------------------------------------------------'

	SELECT distinct * FROM ##SlxPubReadTemp

	--Clean up, drop temp tables
	DROP TABLE ##SlxPubReadTemp
	DROP TABLE #TmpSearch


END

/*
--------------------------------------------------------------------------------------------------
--not used from below


SELECT    top 10 PUBNO, RSCH_ANALYSTID, RSCH_ANALYSTNAME, ISPRIMARY, SCB_RSCH_ANALYSTSID
FROM         sysdba.SCB_RSCH_ANALYSTS
WHERE RSCH_ANALYSTID = 226
ORDER BY PUBNO DESC

--------------------------------------------------------------------------------------------------

SELECT  distinct 
	    v2.RSCH_PRIMARYANALYSTID, v2.rsch_primaryanalystname AS AUTHOR, 
		v1.PUBNO, v1.ACCESS_EMAIL_ADDR,
		v1.read_count AS EMAIL_READER_COUNT
	    --v2.pubtitle AS Title, v2.pubdate AS PublicationDate, v2.pubtype AS PubType
		--v2.rsch_pubindustries AS INDUSTRIES, v2.rsch_pubtickers AS TICKERS,
FROM
(
	select PUBNO, ACCESS_EMAIL_ADDR, 'read_count' = count(*)
	from
	(
		select distinct SWU.PUBNO, SWU.ACCESS_EMAIL_ADDR, convert(varchar(10), ACCESSDATE, 101) as READ_DATE
		  from sysdba.SCB_WEB_USAGE SWU 
		 inner join sysdba.CONTACT C on C.CONTACTID = SWU.CONTACTID
		 inner join sysdba.ACCOUNT A on C.ACCOUNTID = A.ACCOUNTID and ISNULL(A.TYPE, '') <> 'Industry/Press'
		 where SWU.STATUS = 'T' and not SWU.ACCESS_EMAIL_ADDR like '%@bernstein.com'
		   and SWU.FILEFOUND = 'Y'
		   and SWU.PUBNO <> '99999999'
	) as UNIQUE_READERS
    where  isnull(ACCESS_EMAIL_ADDR,'') <> ''
	group by PUBNO, ACCESS_EMAIL_ADDR		
) as v1
LEFT JOIN sysdba.scb_rsch_properties v2 ON v1.PUBNO = v2.PUBNO
WHERE V1.PubNo in (SELECT top 10 PUBNO FROM  sysdba.SCB_RSCH_ANALYSTS WHERE RSCH_ANALYSTID = 226 ORDER BY PUBNO DESC)
  AND v2.RSCH_PRIMARYANALYSTID = 226
  AND V1.PubNo=	61679
  AND isnull(V2.pubtype,'') NOT IN ('Research Summary')
ORDER BY V1.PubNo DESC 

--------------------------------------------------------------------------------------------------
--SELECT distinct PUBNO 
SELECT  RSCH_PRIMARYANALYSTID, RSCH_PRIMARYANALYSTNAME, PUBNO, PUBTITLE, RSCH_PUBINDUSTRIES 
  FROM sysdba.scb_rsch_properties
WHERE RSCH_PRIMARYANALYSTID = 226
--WHERE RSCH_PRIMARYANALYSTNAME = 'Richard Keiser'
ORDER BY PUBNO DESC

--SELECT *
SELECT    top 10 PUBNO, RSCH_ANALYSTID, RSCH_ANALYSTNAME, ISPRIMARY, SCB_RSCH_ANALYSTSID
FROM         sysdba.SCB_RSCH_ANALYSTS
--WHERE RSCH_ANALYSTID = 226
WHERE SCB_RSCH_ANALYSTSID= 'Q6UJ9A0OGFKU'
ORDER BY PUBNO DESC

select ACCOUNTID, ACCOUNT, ISPRIMARY, LASTNAME, FIRSTNAME,EMAIL, TITLE
from sysdba.CONTACT

Select  ACCOUNTID, ACCOUNT, TYPE, ACCOUNT_UC 
from sysdba.ACCOUNT

	Select RI.CONTACTID, RI.SECTOR_ID, --INF_SECTORSID,
		   INF_INDUSTRYID, LTRIM(SECTOR_NAME) AS SECTOR_NAME, ANALYST, 
		   STATUS, RI.INF_CDV_RESEARCH_INTSID
		   --RI.VB_LISTS, RI.EMAIL_BLAST_LIST, 
--select *
	from sysdba.INF_CDV_RESEARCH_INTS RI 
	left join sysdba.Inf_sectors SE on (RI.sector_id = SE.INF_SECTORSID)
	--where RI.contactid =  @contactid 
    where ANALYST = 'Q6UJ9A0OHA4S' --226
    order by LTRIM(SECTOR_NAME)


select * from sysdba.SCB_WEB_USAGE SWU 
--------------------------------------------------------------------------------------------------

*/