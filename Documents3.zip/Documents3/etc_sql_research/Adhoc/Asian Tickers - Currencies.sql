select industryname,last,first,ticker,company,s.exchangecode,s.currencycode,epstype,metricstype
from
researchcoverage rc join authors a on rc.analystid = a.authorid
join securities2 s on rc.securityid = s.securityid
join industries i on rc.industryid = i.industryid
join analystsettings AST on rc.coverageid = AST.coverageid
join epstypes et on AST.epstypeid = et.epstypeid
join metricstypes mt on AST.metricstypeid = mt.metricstypeid
where
rc.launchdate is not null and
rc.dropdate is null and
(industryname like '%asia%' or industryname like '%chin%')
order by industryname,last,ticker 