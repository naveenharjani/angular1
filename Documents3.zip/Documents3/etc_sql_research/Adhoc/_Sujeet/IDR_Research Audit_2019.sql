--10/30/2019
--List of all Research Reports issued on Indian securities (by on-shore and off-shore analyst) during audit period (Apri 1 2018 to March 31 2019)
select V.PubNo,P.Title,A.Name, V.Date ReportDate,P.PublishedDate PublishedDate,V.Ticker, S.Company, V.Rating
from
vFinancials V join Publications P on V.PubNo = P.PubNo
join Authors A on V.AnalystId = A.AuthorID
join Securities2 S on V.Ticker = S.Ticker
where
V.Date between '04/01/2018' and '03/31/2019'
and V.Ticker like '%.IN%'
order by 6,1

--Issuance log for distribution of research reports done through all modes for sample month (April 2018)
select DQ.PubNo,P.Title,P.Date ReportDate,P.PublishedDate,S.Ticker,S.Company, DS.Site,DS.SiteType,Transferred 
from DistributionQueue DQ join DistributionSites DS on DQ.SiteID = DS.SiteID
join vFinancials V on DQ.PubNo = V.PubNo
join Publications P on V.PubNo = P.PubNo
join Authors A on V.AnalystId = A.AuthorID
join Securities2 S on V.Ticker = S.Ticker
where DQ.PubNo in
(
select PubNo
from
vFinancials 
where
Date between '02/01/2019' and '02/28/2019'
and Ticker like '%.IN%'
) and
S.Ticker like '%.IN%' and
Operation = 'C' and
Transferred is not null
and DQ.SiteID <> 17
order by 1,5


--07/14/2021
select V.PubNo,P.Title,A.Name, V.Date ReportDate,P.PublishedDate PublishedDate,V.Ticker, S.Company, V.Rating, A.Name, I.IndustryName
from
vFinancials V join Publications P on V.PubNo = P.PubNo
join Authors A on V.AnalystId = A.AuthorID
join Securities2 S on V.Ticker = S.Ticker
join Industries I on V.IndustryId = I.IndustryId
where
V.Date between '04/01/2020' and '03/31/2021'
and V.Ticker like '%.IN%'
order by 6,1

select S.Ticker, S.Company, A.Name, I.IndustryName, RC.LaunchDate
from 
Securities2 S join ResearchCoverage RC on S.SecurityID = RC.SecurityID
join Authors A on RC.AnalystID = A.AuthorID
join Industries I on I.IndustryId = RC.IndustryID 
where
S.Ticker like '%.IN%'
and RC.LaunchDate between '04/01/2020' and '03/31/2021'

--Issuance log for distribution of research reports done through all modes for period (April 2020 to March 2021)
--select DQ.PubNo,P.Title,P.Date ReportDate,P.PublishedDate,S.Ticker,S.Company, DS.Site,DS.SiteType,Transferred 
select distinct DQ.PubNo,P.Title,P.Date ReportDate,P.PublishedDate, DS.Site,Transferred 
from DistributionQueue DQ join DistributionSites DS on DQ.SiteID = DS.SiteID
join vFinancials V on DQ.PubNo = V.PubNo
join Publications P on V.PubNo = P.PubNo
join Authors A on V.AnalystId = A.AuthorID
join Securities2 S on V.Ticker = S.Ticker
where DQ.PubNo in
(
select PubNo
from
vFinancials 
where
Date between '04/01/2020' and '03/31/2021'
and Ticker like '%.IN%'
) and
S.Ticker like '%.IN%' and
Operation = 'C' and
Transferred is not null
and DQ.SiteID <> 17
order by 1,5


