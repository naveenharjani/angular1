--08/03/2020
--Like last year, this year too, SCB India is been audited for its Research activities.
--As part of audit queries, request you to kindly provide the following data for Indian securities for the audit period � 1st April 2019 till 31st March 2020:

--Query1 -1.	List of all Research Reports issued on Indian securities (by on-shore and off-shore analyst) during audit period 

select P.PubNo,P.Date ReportDate,P.PublishedDate IssuanceDate,P.Title,PF.Ticker,S.Company, Rating,A.Name Author,I.IndustryName Industry
from Publications P join PublicationFinancials PF on P.PubNo = PF.PubNo
join Securities2 S on PF.Ticker = S.Ticker
join ResearchCoverage RC on S.SecurityID = RC.SecurityID and PF.CoverageId = RC.CoverageID
join Authors A on RC.AnalystID = A.AuthorID
join Industries I on RC.IndustryID = I.IndustryId
where 
S.Ticker like '%.in%'
and P.Date between '04/01/2019' and '03/31/2020'
order by PubNo

--Query2 - List of all coverages for Indian securities initiated for securities during audit period
select A.Name Author,I.IndustryName Industry,S.Ticker,S.Company,LaunchDate
from ResearchCoverage RC 
join Securities2 S on RC.SecurityID = S.SecurityID
join Authors A on RC.AnalystID = A.AuthorID
join Industries I on RC.IndustryID = I.IndustryId
where 
S.Ticker like '%.in%'
and RC.LaunchDate between '04/01/2019' and '03/31/2020'

--Query3 - Details of modes of distribution of above research reports ( for Indian securities only) 
select DQ.PubNo, P.Date, P.Title, DS.Site,Transferred DistributionTime 
from DistributionQueue DQ join DistributionSites DS on DQ.SiteID = DS.SiteID
join Publications P on DQ.PubNo = P.PubNo
where Transferred is not null and Cancelled is null
and Transferred < dateadd(mi,7,P.PublishedDate)
and DQ.PubNo in (
select P.PubNo
from Publications P join PublicationFinancials PF on P.PubNo = PF.PubNo
join Securities2 S on PF.Ticker = S.Ticker
join ResearchCoverage RC on S.SecurityID = RC.SecurityID
join Authors A on RC.AnalystID = A.AuthorID
join Industries I on RC.IndustryID = I.IndustryId
where 
S.Ticker like '%.in%'
and P.Date between '04/01/2019' and '03/31/2020')
order by DQ.PubNo
