--This query returns coverage as-of @EndDate (parameterized)
--This is used to analyze historical coverage evolution

declare @EndDate datetime
set @EndDate = '07/22/2020'
select A.Name Analyst, I.IndustryName Industry, S.Company, S.Ticker, RC.LaunchDate,V4.Rating,RatingPrior,V4.Date
from 
ResearchCoverage RC join Authors A on RC.AnalystID = A.AuthorId 
join Securities2 S on RC.SecurityID = S.SecurityID
join Industries I on RC.IndustryID = I.IndustryId
left join 
(select V.SecurityId,ticker,V.Date,Rating,RatingPrior,RatingAction,LaunchDate
from vFinancials V join
(select securityid,max(Date) Date
from vFinancials
where
date < @EndDate
and ratingaction in ('Initiate','upgrade','downgrade')
group by SecurityId) V2 on V.SecurityId = V2.SecurityId and V.Date = V2.Date
and V.RatingAction in ('Initiate','upgrade','downgrade')) V4 on S.Ticker = V4.Ticker
where
(RC.DropDate is null or RC.DropDate > @EndDate) and
RC.LaunchDate < @EndDate
order by 1,2,3


