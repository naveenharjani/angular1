--Get the latest rating change data  (rating,rating prior, target price)
--for all the active tickers under coverage.
select S.SecurityId,S.Company, S.Ticker,A.Name ,V3.Pubno,V3.Date,V3.Rating,V3.RatingPrior,V3.LaunchDate,VM.CurCode,VM.Value ClosePrice, VFL.Value TargetPrice,RC.CoverageId
from ResearchCoverage RC join Securities2 S on RC.SecurityId = S.SecurityId
join Authors A on RC.AnalystId = A.AuthorId
join (select V1.SecurityId,V1.Ticker,V1.Pubno,V1.Date,V1.Rating,V1.RatingPrior,V1.LaunchDate from vFinancials V1 join 
	(select SecurityId,max(Pubno) Pubno from vfinancials 
	where RatingAction in ('initiate','upgrade','downgrade')
	group by SecurityId) V2 on V1.SecurityId = V2.SecurityId and V1.Pubno = V2.Pubno) V3 on RC.SecurityId = V3.SecurityId
join vMarketData VM on RC.SecurityId = VM.SecurityId
join vFinancialNumbersLatest VFL on RC.SecurityId = VFL.SecurityId	
where
RC.LaunchDate is not null and RC.DropDate is null and RC.SecurityId is not null
and VM.financialnumbertype='closeprice' 
and VFL.FinancialNumberTypeId = 2 and VFL.IsDraft = 0
order by s.ticker

--Get the latest rating change data  (rating,rating prior, target price) along with launch rating
--for all the active tickers under coverage.

select S.SecurityId,S.Company, S.Ticker,A.Name ,V3.Pubno,V3.Date,V3.Rating,V3.RatingPrior,PF.Rating LaunchRating,V3.LaunchDate,VM.CurCode,VM.Value ClosePrice, VFL.Value TargetPrice
from ResearchCoverage RC join Securities2 S on RC.SecurityId = S.SecurityId
join Authors A on RC.AnalystId = A.AuthorId
join (select V1.SecurityId,V1.Ticker,V1.Pubno,V1.Date,V1.Rating,V1.RatingPrior,V1.LaunchDate from vFinancials V1 join 
	(select SecurityId,max(Pubno) Pubno from vfinancials 
	where RatingAction in ('initiate','upgrade','downgrade')
	group by SecurityId) V2 on V1.SecurityId = V2.SecurityId and V1.Pubno = V2.Pubno) V3 on RC.SecurityId = V3.SecurityId
join vMarketData VM on RC.SecurityId = VM.SecurityId
join vFinancialNumbersLatest VFL on RC.SecurityId = VFL.SecurityId	
join (select coverageId, min(pubNo) PubNo from PublicationFinancials group by CoverageId) V4 on RC.CoverageId = V4.CoverageId
join PublicationFinancials PF on V4.PubNo = PF.PubNo and V4.CoverageId = PF.CoverageId
where
RC.LaunchDate is not null and RC.DropDate is null and RC.SecurityId is not null
and VM.financialnumbertype='closeprice' 
and VFL.FinancialNumberTypeId = 2 and VFL.IsDraft = 0
order by S.Ticker

--

select
  S.Company,
  S.Ticker,
  S.SEDOL,
  S.CountryCode,
  A.Last + ', ' + A.First as Analyst,
  CONVERT(varchar, V3.Date, 101) as Date,
  V3.Rating,
  V3.RatingPrior,
  PF.Rating LaunchRating,
  CONVERT(varchar, V3.LaunchDate, 101) as LaunchDate,
  VM.CurCode,
  VM.Value ClosePrice,
  VFL.Value TargetPrice
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join Authors A on RC.AnalystId = A.AuthorId
join (select V1.SecurityId,V1.Ticker,V1.Pubno,V1.Date,V1.Rating,V1.RatingPrior,V1.LaunchDate from vFinancials V1 join 
	(select SecurityId,max(Pubno) Pubno from vfinancials 
	where RatingAction in ('initiate','upgrade','downgrade')
	group by SecurityId) V2 on V1.SecurityId = V2.SecurityId and V1.Pubno = V2.Pubno) V3 on RC.SecurityId = V3.SecurityId
join vMarketData VM on RC.SecurityId = VM.SecurityId
join vFinancialNumbersLatest VFL on RC.SecurityId = VFL.SecurityId	
join (select coverageId, min(pubNo) PubNo from PublicationFinancials group by CoverageId) V4 on RC.CoverageId = V4.CoverageId
join PublicationFinancials PF on V4.PubNo = PF.PubNo and V4.CoverageId = PF.CoverageId
where
RC.LaunchDate is not null and RC.DropDate is null and RC.SecurityId is not null
and VM.financialnumbertype='closeprice' 
and VFL.FinancialNumberTypeId = 2 and VFL.IsDraft = 0
order by S.Ticker



-- 10/31/2017
-- GIC Ratings History

select
  S.Company,
  S.Ticker,
  S.SEDOL,
  S.CountryCode,
  A.Last + ', ' + A.First as Analyst,
  convert(varchar, VF.Date, 101) as RatingDate,
  VF.Rating
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join Authors A on RC.AnalystId = A.AuthorId
join vFinancials VF on VF.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null and RC.SecurityId is not null
and VF.RatingAction <> 'Reiterate'
and Date between getdate() - 14 and getdate()
--and Date >= '01/01/2016'
order by 1, 2

select
  S.Company,
  S.Ticker,
  S.SEDOL,
  S.CountryCode,
  A.Last + ', ' + A.First as Analyst,
  convert(varchar, VF.Date, 101) as TargetPriceDate,
  VF.TargetPrice,
  VF.Currency
--  VF.TargetPriceAction
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join Authors A on RC.AnalystId = A.AuthorId
join vFinancials VF on VF.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null and RC.SecurityId is not null
and (VF.TargetPriceAction in ('increase', 'decrease') or VF.RatingAction <> 'Reiterate')
and Date between getdate() - 14 and getdate()
-- and Date >= '01/01/2016'
order by 1, 2

