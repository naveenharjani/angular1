-- Unlaunched_Tickers.sql
-- 03/29/2018

-- can I have the following items for the stocks in the attachment please:
-- ISIN, Sedol, Domiciled Country [if you have it], Exchange [if you have it].

-- Jay Panwar: 03/13/2018
-- Jay Panwar: 03/29/2018

SELECT top 10
  S.Company,
  S.Ticker,
  S.ISIN,
  S.SEDOL,
  TS.SEDOL1_COUNTRY_ISO,
  TS.EXCH_CODE, S.EditDate
FROM Securities2 S
JOIN vTickerStatus TS ON TS.Ticker = S.Ticker
ORDER BY S.SecurityId desc
