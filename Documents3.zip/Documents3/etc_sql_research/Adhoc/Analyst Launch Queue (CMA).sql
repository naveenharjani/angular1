-- Analyst Launch Queue (CMA).sql

-- Listing of unlaunched analysts and CMA Content Key used for br.com Bio admin

select distinct
  'ID/Key' = RC.AnalystID,
  'Analyst' = A.Last,
  'Industry' = I.IndustryName
from ResearchCoverage RC
join Authors A on A.AuthorID = RC.AnalystID
join Industries I on I.IndustryID = RC.IndustryID
where RC.AnalystID in (select distinct AnalystID from ResearchCoverage where ISNULL(LaunchDate,'') = '' AND ISNULL(DropDate,'') = '')
and RC.AnalystID not in (select distinct AnalystID from ResearchCoverage where LaunchDate IS NOT NULL)
order by I.IndustryName
