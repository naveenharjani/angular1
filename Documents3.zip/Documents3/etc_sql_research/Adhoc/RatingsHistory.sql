-- RatingsHistory.sql
-- 12/11/2015

-- Colin Request: 
-- Can you send me a file with the ratings history and relevant index for each company in our coverage since initiation of that company?  Only need primary tickers. 

-- Rsting History
SELECT DISTINCT
       S.Company,
       S.Ticker,
       CONVERT(varchar, vf.Date, 101) as Date,
       vf.Rating, vf.RatingAction,
       S.BenchmarkIndex,
       --RC.LaunchDate,
       --vf.CoverageId, vf.SecurityId,
       vf.Date
FROM ResearchCoverage RC
INNER JOIN vFinancials vf ON vf.SecurityID = RC.SecurityId
INNER JOIN Securities2 S ON S.SecurityId = RC.SecurityId
WHERE RC.DropDate IS NULL
AND S.IsPrimary = 'Y'
AND vf.RatingAction IN ('Initiate', 'Upgrade', 'Downgrade')
ORDER BY S.Company, S.Ticker, vf.Date


-- DEBUG

/*
-- Daily Ratings
SELECT --S.Company, 
       S.Ticker,
       CONVERT(varchar, DR.Date, 101) as Date,
       DR.Rating, 
       S.BenchmarkIndex
       --RC.LaunchDate
       --RC.DropDate, S.IsPrimary, S.SecurityId, S.CompanyId
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN DailyRatings DR ON DR.CoverageId = RC.CoverageId AND DR.SecurityId = RC.SecurityId
WHERE RC.DropDate IS NULL
AND S.IsPrimary = 'Y'
AND S.Ticker = 'AAPL'
ORDER BY Ticker, DR.Date
*/








