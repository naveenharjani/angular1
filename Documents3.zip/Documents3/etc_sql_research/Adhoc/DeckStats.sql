-- DeckStats.sql
-- 03/18/2021

-- compassdb,16083;   Database=SlxExternal;Connect Timeout=10;User ID=research_db_svc;Password=

/*

Zhou, Yvonne - 3/11/2021
Subject: RE: Marketing deck and Analyst landing page stats

Get the download stats on the Auto/EV Market Sizing Reference Deck? Can we see where clients access the deck, e.g. through the landing page or through direct links in our published notes?

*/

/*
SELECT RVA.Name as Analyst, RVA.Title, CU.LoginId, CU.AccessDate, RVLS.Source, CU.ContentId, CU.SourceId
FROM SlxExternal.dbo.ContentUsage CU
JOIN SlxExternal.dbo.RVAssets RVA ON RVA.AssetId = CU.ContentId
JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = CU.SourceId
WHERE CU.ContentTypeId = 'A'
AND RVA.Title = 'Auto/Electric Vehicle Market Sizing Reference Deck'
ORDER BY AccessDate desc
*/

SELECT
-- RVA.Name as Analyst,
--  RVA.Title,
   RVLS.Source,
--   CU.SourceId,
    COUNT(*) as Downloads
FROM SlxExternal.dbo.ContentUsage CU
JOIN SlxExternal.dbo.RVAssets RVA ON RVA.AssetId = CU.ContentId
JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = CU.SourceId
WHERE CU.ContentTypeId = 'A'
AND RVA.Title = 'Auto/Electric Vehicle Market Sizing Reference Deck'
GROUP BY RVA.Name, RVA.Title, RVLS.Source, CU.SourceId
ORDER BY COUNT(*) desc

