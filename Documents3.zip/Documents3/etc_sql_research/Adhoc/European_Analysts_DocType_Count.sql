-- European_DocType_Count.sql
----------------------------------------------------------------------------------------------------
--Database: Research DEV [ACX3AMA0510\SCBIS_DEV6]
----------------------------------------------------------------------------------------------------
USE Research
GO

DECLARE @vStartDate		VARCHAR(12)
DECLARE @vEndDate		  VARCHAR(12)
DECLARE @vRegionCode	VARCHAR(12)

SET @vStartDate = '01/01/2009'
SET @vEndDate = '12/31/2010'
SET @vRegionCode = 'UK'

/*
Report Fields:
European Analyst Name
Region
MonthYear
DocType
Count
*/

SELECT    distinct 'Analyst' = V1.AnalystName, 
          --'PublishedMonth' = V1.PublishedMonthYear,
          'PublishedYear' = V1.PubYear,
          'PublishedMonth' = V1.PubMonth,
          'PublicationType' = max(V1.Type),
          'PublishedCount' = count(*),
          'Region' = V1.Region
FROM (          
      SELECT     Last, ar.Region, p.Type,
                 DATENAME(mm, p.date) + ' ' + DATENAME(yy, p.date) AS PublishedMonthYear,
                 PT.PublicationTypeID,
                 CONVERT(varchar, DATEPART(yy, p.date)) AS PubYear,
                 Right('00' + CONVERT(varchar(2), DATEPART(mm, p.date)), 2) AS PubMonth,
                 p.date AS PubDate,
                 Name AS AnalystName, At.Title,
                 ProductTitle = P.Title, ar.RegionId
      FROM Authors a
      INNER JOIN  AuthorRegions ar on ar.RegionId = a.RegionId AND ar.Region = @vRegionCode
      INNER JOIN  properties pr on a.name = pr.propvalue
      INNER JOIN  publications p on pr.pubno = p.pubno
      INNER JOIN  PublicationTypes PT on PT.PublicationType= p.type
      INNER JOIN  AuthorTitles AT ON AT.TitleId = A.TitleId AND  AT.Title IN ('Analyst', 'Senior Analyst')
      WHERE p.Date BETWEEN @vStartDate AND @vEndDate
) V1
GROUP BY V1.Region, V1.AnalystName, V1.PubYear, V1.PubMonth, V1.Type
ORDER by 1,2 desc, 3 asc


/*
select * from rvdocanalysts

select * from authors where regionid = 2 and titleid in (1,2)
select * from authorregions
select * from authortitles

select * from publications
select * from regions
select distinct regionid from authors
select * from PublicationTypes
*/