USE RESEARCH
GO

SET NOCOUNT ON

--CHG_PCT_YTD	Price Change Year To Date Percent
--Percentage price change for the calendar year to date. Calculated from the last close of the prior year to the last price. 
--The formula is:           (Change Year To Date Net/Closing Price Most Recent Year End) * 100.         
--Where:                    Change Year To Date Net = (PR078, CHG_NET_YTD)        
--Closing Price Most Recent Year End = (PR077, PX_CLOSE_YTD). 


--CHG_PCT_1YR	Price Change 1 Year Percent
--Percent change in price over the last year. 
--The formula is:     [(Last Trade - Closing Price One Year Ago) / Closing Price One Year  Ago]*100.         
--Where :             Last Trade is PR005 (PX_LAST)       Closing Price One Year Ago is PR068 (PX_CLOSE_1YR)         
--Currencies:         For currencies that are quoted FC/US$, the + or - signs shows the strengthening or weakening of the currency 
--against the base currency. For currencies that are quoted US$/FC(Foreign Currency/ US Dollar), the value will be the inverse.

---------------------------------------------------------------------------------------------------------------
-- Get the latest Bloomberg marketdata info
-- Compare "YTD Performance" with "Price Change 1 Year Percent"
---------------------------------------------------------------------------------------------------------------
DECLARE @SecPerfChange TABLE
(
  Ticker                VARCHAR(30),
  RunDate               datetime,
  --LoadDate              datetime,
  CloseDate             datetime,
  CHG_PCT_YTD           VARCHAR(80),
  CHG_PCT_1YR           VARCHAR(80)
)  


INSERT @SecPerfChange
SELECT distinct max(md.ticker) AS Ticker,  
       max(md.RunDate) AS RunDate,  
       --max(md.LoadDate) AS LoadDate,
       max(md.PX_CLOSE_DT) AS CloseDate,  
       max(CASE md.BloombergMnemonic WHEN 'CHG_PCT_YTD' THEN isnull(md.Value, 0) ELSE '' END)   AS CHG_PCT_YTD,
       max(CASE md.BloombergMnemonic WHEN 'CHG_PCT_1YR' THEN isnull(md.Value, 0) ELSE '' END)   AS CHG_PCT_1YR
FROM (
      SELECT
        bts.Ticker, 
        bf.Mnemonic AS BloombergMnemonic,
        bts.RunDate AS RunDate, 
        CASE bts.Value WHEN '' THEN '0.0000' ELSE isnull(bts.Value,0) END AS Value, 
        bts.LoadDate AS LoadDate,
        bts.PX_CLOSE_DT,
        s.SecurityId,
        bts.FieldId 
      FROM BloombergPivotPricing bts
      INNER JOIN ( SELECT ticker AS Ticker, max(rundate) AS RunDate --, max(loaddate) AS LoadDate
                   FROM BloombergPivotPricing
                   --where ticker = 'BUD'
                   GROUP BY ticker) ts_latest
                   ON bts.Ticker = ts_latest.Ticker AND bts.RunDate = ts_latest.RunDate --AND bts.LoadDate = ts_latest.LoadDate
      INNER JOIN dbo.BloombergFields bf ON bts.FieldId = bf.FieldId
      INNER JOIN dbo.Securities2 s ON bts.Ticker = s.Ticker

      WHERE bf.Mnemonic IN ('CHG_PCT_YTD', 
                            'CHG_PCT_1YR')
       ) md 
GROUP BY md.Ticker

--select * FROM @SecPerfChange

SELECT Ticker, RunDate, CloseDate, CHG_PCT_1YR, CHG_PCT_YTD, Perf_Variance--,
       --CASE CHG_PCT_1YR WHEN '0.0000' THEN '0.0000' ELSE (Perf_Variance/CHG_PCT_1YR * 100) END AS Perf_Variance_Percent

FROM
(
  SELECT Ticker, RunDate, CloseDate, CHG_PCT_1YR, CHG_PCT_YTD,
         CAST(CHG_PCT_1YR AS decimal(15,2)) - CAST(CHG_PCT_YTD AS decimal(15,2)) AS Perf_Variance
  FROM @SecPerfChange
  --where ticker = 'VZ'
) V
ORDER BY Perf_Variance  --Perf_Variance_Percent

-----------------------------------------------------------------------------------
--Get the closing price history data for comparison
-----------------------------------------------------------------------------------
SELECT ticker, rundate, closedate, PX_LAST, closedate2
FROM
(
  select ticker, rundate, closedate, PX_LAST, CONVERT(varchar(20), closedate, 101) AS closedate2
  from bloombergpricehistory
  --where ticker = 'VZ'
) V
WHERE closedate2 IN ('11/27/2009', '01/02/2009', '12/31/2008', '11/2/2008')
ORDER BY closedate DESC
-----------------------------------------------------------------------------------


-----------------------------------------------------------------------------------
--Summary: There are some 40 tickers with Variance of -20% and 40 tickers with variance of +20%
-----------------------------------------------------------------------------------

-----------------------------------------------------------------------------------
--Verification of Performance Change Percent
-----------------------------------------------------------------------------------
--SELECT 
--       (Change Year To Date Net/Closing Price Most Recent Year End) * 100 
--       AS Calc_CHG_PCT_YTD,
--       (Last Trade - Closing Price One Year Ago) / Closing Price One Year  Ago]*100  
--       AS Calc_CHG_PCT_1YR

/*
SELECT ((31.63-33.9)/31.63) * 100 AS VZ_Calc_CHG_PCT_YTD,
       ((31.63-32.65)/32.65) * 100 AS VZ_Calc_CHG_PCT_1YR
*/
-----------------------------------------------------------------------------------


/*
--WHERE ticker = 'BUD'
--and (isnull(CHG_PCT_YTD,0) IS NOT NULL OR isnull(CHG_PCT_1YR,0) IS NOT NULL)
*/
