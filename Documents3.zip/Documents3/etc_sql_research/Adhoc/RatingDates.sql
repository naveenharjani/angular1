-- RatingDates.sql
-- 07/24/2012
-- 03/18/2013
-- Chris Hogbin

SELECT DISTINCT
  TTS.Ticker,
  S.Company,
  TTS.Rating,
  TTS.RatingAction,
  'ReportDate'        = CONVERT(varchar, P.Date, 101),
  'CloseDate'         = CONVERT(varchar, TTS.CloseDate, 101),
  'ClosePrice'        = TTS.ClosePrice,
  TTS.Currency,
  'Rating Days'       = DATEDIFF(dd, P.Date,GETDATE()),
  'Index'             = S.BenchmarkIndex,
  'IndexDate'         = CONVERT(varchar, TTSI.CloseDate, 101), -- IndexCloseDt@RatingChange
  'IndexPrice'        = TTSI.ClosePrice,                       -- IndexClosePrice@RatingChange
  'CurrentCloseDate'  = V2.Value, -- CurrentShareCloseDate
  'CurrentClosePrice' = V1.Value, -- CurrentShareClosePrice
  --'AuthorRegion'      = AR.Region,
  'AuthorRegion'      = CASE AR.Region WHEN 'UK' THEN 'PE' ELSE AR.Region END, --Replace 'UK with 'PE'
  'Analyst'           = A.Last,
  TTS.PubNo
FROM TickerTableSecurities TTS 
JOIN (SELECT Ticker, MAX(PubNo) AS PubNo          --Get the latest PubNo for the last RatingAction by Ticker
        FROM TickerTableSecurities
       WHERE RatingAction in ('Initiate','Upgrade','Downgrade')   -- Filter by Rating Change Tags
    GROUP BY Ticker) V on TTS.Ticker = V.Ticker and TTS.PubNo = V.PubNo
JOIN Publications P on TTS.PubNo = P.PubNo  
JOIN ResearchCoverage RC on TTS.Coverageid = RC.Coverageid
JOIN Securities2 S ON S.Ticker = TTS.Ticker       -- Get Company Name
JOIN Authors A ON A.AuthorID = RC.AnalystID       -- Get Author Name
JOIN AuthorRegions AR ON AR.RegionID = A.RegionID -- Get Author Region
JOIN vBloombergPricingLatest V1 ON V1.BloombergMnemonic = 'PX_LAST'     AND V1.Ticker = TTS.Ticker --Get Current Share Close Price
JOIN vBloombergPricingLatest V2 ON V2.BloombergMnemonic = 'PX_CLOSE_DT' AND V2.Ticker = TTS.Ticker --Get Current Share Close Date
--Get Index Price @Rating change
JOIN TickerTableSecurities TTSI ON TTSI.PubNo = P.PubNo AND 
                                   TTSI.Ticker IN (SELECT BenchmarkIndex FROM Securities2 WHERE Ticker = TTS.Ticker)
WHERE RC.DropDate IS NULL                         -- Filter by Tickers under Active Coverage only
ORDER BY AuthorRegion, S.Company, TTS.Ticker

--DEBUG
/*
SELECT VF.Ticker,VF.Date,VF.PubNo,VF.Rating,VF.TargetPrice,TTS.CloseDate,TTS.ClosePrice 
FROM vFinancialsLatest VF 
JOIN TickerTableSecurities TTS ON VF.PubNo = TTS.PubNo AND VF.Ticker = TTS.Ticker
ORDER BY Ticker

SELECT top 100 * from vFinancials
SELECT top 100 * from vFinancialsLatest
SELECT TOP 100 * FROM TickerTableSecurities
SELECT TOP 100 * FROM Securities2
SELECT TOP 100 * FROM ResearchCoverage
SELECT TOP 100 * FROM Authors
SELECT         * FROM AuthorRegions

SELECT         Value FROM vBloombergPricingLatest WHERE BloombergMnemonic = 'PX_LAST' AND Ticker = 'AAPL'
SELECT         Value FROM vBloombergPricingLatest WHERE BloombergMnemonic = 'PX_CLOSE_DT' AND Ticker = 'AAPL'

--Get Index Price for a Ticker [from TTS] for the call published
SELECT PubNo, Ticker,  CloseDate, ClosePrice 
FROM TickerTableSecurities TTS 
WHERE TTS.PubNo IN (87909, 81970, 80437)
AND TTS.Ticker IN (SELECT BenchmarkIndex FROM Securities2 WHERE Ticker = TTS.Ticker)
ORDER BY PubNo 

SELECT TOP 100 SecurityID, Ticker, TickerType, Company, BenchmarkIndex FROM Securities2
*/