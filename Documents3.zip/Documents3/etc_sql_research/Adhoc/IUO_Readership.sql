-- IUO_Readership.sql
-- 05/15/2014

select top 500 * from Commentary order by CommentaryId desc

-- 06/23/2014 Declan Kearney
-- 06/28/2014 Declan Kearney
select 
  CL.CommentaryId as 'IUO ID',
  A.Last Analyst,
  C.Subject,
  case when patindex('%US%', ToList) > 0 then 'Y' else '-' end US,
  case when patindex('%EU%', ToList) > 0 then 'Y' else '-' end EU,
  case when patindex('%AP%', ToList) > 0 then 'Y' else '-' end AP,
  CreateDate,
  ReadDate,
  U.LastName + ', ' + U.FirstName ReadBy,
  case
    when patindex('%blackberry%', UserAgent) > 0 then 'BlackBerry'
    when patindex('%ipad%', UserAgent) > 0 then 'iPad'
    when patindex('%iphone%', UserAgent) > 0 then 'iPhone'
    else 'Desktop'
  end Location
from CommentaryReadLog CL
join Commentary C ON CL.CommentaryId = C.CommentaryId
join Authors A ON A.AuthorId = C.AnalystId
join Users U ON CL.UserId = U.UserId
where CreateDate >= '01/01/2013'
--and (UserAgent like '%ipad%' or UserAgent like '%iphone%' or UserAgent like '%blackberry%')
order by CreateDate, CL.CommentaryId, ReadDate

