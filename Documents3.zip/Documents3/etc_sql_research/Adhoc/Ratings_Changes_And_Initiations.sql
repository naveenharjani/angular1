-- Ratings_Changes_And_Initiations.sql

-- Database: SPSCBIS\SCBIS_PRD6,16102
--*********************************************************************************************
--Reports requested by Robert van Brugge [01/04/2010]:
--*********************************************************************************************

--*********************************************************************************************
--1>. Run a report for me with a data download of all ratings changes in 2009 and 2010
--    with ticker, company name, analyst name, date of change, and previous and new rating?
--*********************************************************************************************

--Ratings Changes
SELECT 'Ticker' = vF.Ticker,
       'Company' = S.Company,
       'Analyst' = A.name,
       'DateChange' = convert(varchar(10), Date, 110),
       'PrevRating' = isnull(RatingPrior, ''),
       'NewRating' = Rating,
       'RatingAction' = RatingAction
FROM vFinancials vF
join Authors A on A.AuthorID = vF.AnalystId
join Securities2 S ON S.Ticker = vF.Ticker
WHERE (vF.Date BETWEEN '01/01/2009' AND '12/31/2010')
AND RatingAction IN ('Downgrade', 'Upgrade')
ORDER BY vF.Date desc, Ticker


--*********************************************************************************************
--2>. Run a report for me with all new stock initiations in 2009 and 2010 
--    with ticker, company name, analyst name, date of initiation, and rating?
--*********************************************************************************************

-- New Stock Initiates
SELECT 'Ticker' = S.ticker,
       'Company' = S.Company,
       'Analyst' = A.name,
       'DateInitiation' = convert(varchar(10), vF.date, 110),
       'Rating' = vF.Rating,
       'RatingAction' = vF.RatingAction
FROM    vFinancials vF 
JOIN Securities2 s ON S.Ticker = vF.Ticker
join Authors A on A.AuthorID = vF.AnalystId
WHERE (vF.Date BETWEEN '01/01/2009' AND '12/31/2010')
AND RatingAction IN ('Initiate')
order by vF.date desc, Ticker


/*
sp_helptext vFinancials
select * from vfinancials

--, 'Initiate' 'Drop' , 'Reiterate'
--AND (RatingAction <> 'Reiterate' or TargetPriceAction <> 'Update')
--  Currency, PubNo,
--  TargetPrice, TargetPricePrior, TargetPriceAction, TargetPriceOrig
*/
