--12/20/2019
--Non-EU analysts that cover stocks with european model currencies.

select A.Name,S.Ticker,S.Company,FSS.CurCode 
from 
ResearchCoverage RC join Authors A on RC.AnalystId = A.AuthorID
join Securities2 S on RC.SecurityID = S.SecurityID
join FinancialSecuritySettings FSS on S.SecurityID = FSS.SecurityId
where
RC.LaunchDate is not null and RC.DropDate is null
and A.RegionID in (1,3)  and
CurCode in ('EUR','GBP','CHF','DKK','SEK','RUB','NOK')
order by Name





