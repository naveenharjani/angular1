drop table #tmpTickers
go
select launchdate,dropdate,securityid
into #tmpTickers
from researchcoverage
where LaunchDate is not null
order by launchdate asc
go
select S.SecurityId,S.Ticker,S.Company,LaunchDate,DropDate,
      case when launchdate < '12/31/2010' then 'Y' else 'N' end as '2010',
      case when launchdate < '12/31/2011' then 'Y' else 'N' end as '2011',
      case when launchdate < '12/31/2012' then 'Y' else 'N' end as '2012',
      case when launchdate < '12/31/2013' then 'Y' else 'N' end as '2013',
      case when launchdate < '12/31/2014' then 'Y' else 'N' end as '2014'
from
#tmpTickers T join Securities2 S on T.SecurityID = S.SecurityID
order by Ticker
