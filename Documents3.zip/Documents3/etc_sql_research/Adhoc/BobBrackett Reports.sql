
select P.PubNo, Date, Type, Title, Pr2.PropValue Pages,Pr.PropNo
into #tmpPropNo
from 
Publications P join Properties Pr on P.PubNo = Pr.PubNo
join Properties Pr2 on P.PubNo = Pr2.PubNo
where 
Pr.PropID = 5 and
Pr.PropValue like '%Brackett%' and
Pr2.PropID = 31 
order by P.PubNo

select T.PubNo,min(Pr.PropNo) PropNo
into #tmp2
from #tmpPropNo T join Properties Pr on T.PubNo = Pr.PubNo
where
Pr.PropId = 5
group by T.PubNo

select T1.PubNo, T1.Date, T1.Type, T1.Title,T1.Pages, case when T1.PropNo = T2.PropNo then 'Yes' else 'No' end IsPrimaryAuthor
from #tmpPropNo T1 join #tmp2 T2 on T1.PubNo = T2.PubNo 


