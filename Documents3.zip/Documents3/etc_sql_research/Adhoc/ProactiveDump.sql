-- ProactiveDump.sql

-- Prepared for Dave Barnard / Jordan Lorch 08/06/2010

/*

select * from Properties where PropID = 30 and PropValue = 'T'

select PU.*, PR.* from Properties PR
join Publications PU on PU.PubNo = PR.PubNo
where PropID = 30 and PropValue = 'T'

*/

-- De-normalized Proactivty temporary table
print 'Create de-normalized Proactivty temporary table'

select
  'Date' = PU.Date,
  PR.PubNo,
  RVD.Last,
  'Region' = convert(varchar(5), AR.Region),
  PU.Title
into #pass1
from Properties PR
join Publications PU on PU.PubNo = PR.PubNo
join RVDocAnalysts RVD on RVD.DocId = PR.PubNo
join Authors AU on AU.AuthorID = RVD.AnalystId
join AuthorRegions AR on AR.RegionId = AU.RegionId
where PropID = 30 and PropValue = 'T'

-- View associate exclusions
print 'Associate exclusions'

select * from #pass1
where
   (Last = 'Yin'    and Date < '1/12/2010')
or (Last = 'Werner' and Date < '1/21/2010')
order by 3, 2

-- View inclusions
print 'Associate inclusions'

select * from #pass1
where
   (Last = 'Yin'    and Date >= '1/12/2010')
or (Last = 'Werner' and Date >= '1/21/2010')
order by 3, 2

-- View data detail
select
  Date,
  PubNo,
  Last,
  Region,
  Title
  from #pass1
where
    not (Last = 'Yin'    and Date < '1/12/2010')
and not (Last = 'Werner' and Date < '1/21/2010')
order by 2, 3

-- View data summary
select
  'Region' = Region,
  'Year'   = year(Date),
  'Month'  = month(Date),
  'Count'  = count(*)
from #pass1
where
    not (Last = 'Yin'    and Date < '1/12/2010')
and not (Last = 'Werner' and Date < '1/21/2010')
group by Region, year(Date), month(Date)
order by 1, 2, 3

drop table #pass1
