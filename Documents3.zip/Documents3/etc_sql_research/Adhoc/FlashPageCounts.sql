-- FlashPageCounts.sql
-- 06/24/2011
-- Dan Dowd

select count(*) as '1-9'   from Publications where Type = 'External Flash' and PageCount between 1 and 9
select count(*) as '10-19' from Publications where Type = 'External Flash' and PageCount between 10 and 19
select count(*) as '20-29' from Publications where Type = 'External Flash' and PageCount between 20 and 29
select count(*) as '30-39' from Publications where Type = 'External Flash' and PageCount between 30 and 39

select PageCount, count(*) as Num
from Publications
where Type = 'External Flash'
group by PageCount
order by PageCount

select top 5000
  PageCount as Pages,
  PubNo,
  -- Date,
  convert(varchar, Date, 101),
  Title
from Publications
where Type = 'External Flash'
and PageCount >= 14
--and Date > '0/01/2010 '
order by PageCount desc

