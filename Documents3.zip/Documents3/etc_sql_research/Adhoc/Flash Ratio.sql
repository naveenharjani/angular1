select  Year=datepart(yy,date),
        Week=datepart(wk,date),
        Date = dateadd(dd,7-datepart(dw,dateadd(wk,datepart(wk,date)-1,'01-01-' + convert(varchar(4),datepart(yy,date)))),dateadd(wk,datepart(wk,date)-1,'01-01-' + convert(varchar(4),datepart(yy,date)))),
        DocType=case when type = 'external flash' then 'Flash' else type end,
        #Count=count(pubno) 
from    publications 
where
        type in ('research call','flash','external flash') and
        date >= '01/01/2007'
group by  datepart(yy,date),
          datepart(wk,date),
          dateadd(dd,7-datepart(dw,dateadd(wk,datepart(wk,date),'01-01-' + convert(varchar(4),datepart(yy,date)))),dateadd(wk,datepart(wk,date),'01-01-' + convert(varchar(4),datepart(yy,date)))),
          case when type = 'external flash' then 'Flash' else type end
order by datepart(yy,date),datepart(wk,date),DocType

