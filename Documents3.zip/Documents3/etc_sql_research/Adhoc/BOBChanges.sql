Drop Table #tmp1
Drop Table #tmp2
go
set nocount on

select distinct Bob.Pubno,P.Date,S.SecurityId,S.Ticker,LastYear,ThisYear,NextYear
into #tmp1
from BestOfBernstein Bob join Publications P on Bob.PubNo = P.PubNo
join TickerTables T on P.PubNo = T.PubNo
join Properties Pr on P.PubNo = Pr.PubNo and Pr.PropId = 13
join Securities2 S on Pr.PropValue = S.Ticker and S.TickerType = 'Stock'
join ResearchCoverage RC on RC.SecurityId = S.SecurityId and RC.LaunchDate is not null and RC.DropDate is null
where
P.Date >= '1/17/2014' and 
Bob.DeactivateDate is null

select * from #tmp1
select a.Name,Ticker,Date,PubNo,RatingPrior,Rating,RatingAction,TargetPricePrior,TargetPrice,TargetPriceAction,EPSThisYearPrior,EPSThisYear,EstimateAction,EPSNextYearPrior,EPSNextYear,LastYear T1,LastYear T2,' ' YearRollOver
into #tmp2
from
vfinancials V join Authors A on V.AnalystId = A.AuthorId
where 
1 = 2

Declare @PubNo      int
Declare @Date       datetime
Declare @Ticker     varchar(30)
Declare @SecurityId int
Declare @LastYear varchar(10)

select top 1 @Pubno = PubNo,@Date = Date,@Ticker = Ticker,@SecurityId = SecurityId,@LastYear = LastYear from #tmp1 order by pubno,securityid
while @@Rowcount = 1
begin
  
  Insert into #tmp2
  select a.Name,Ticker,Date,PubNo,RatingPrior,Rating,RatingAction,TargetPricePrior,TargetPrice,TargetPriceAction,EPSThisYearPrior,EPSThisYear,EstimateAction,EPSNextYearPrior,EPSNextYear,V.LastYear T1,@LastYear T2,case when convert(int,substring(V.LastYear,1,4)) > convert(int,substring(@LastYear,1,4)) then '*' else ' ' end as YearRollOver
  from
  vfinancials V join Authors A on V.AnalystId = A.AuthorId
  where 
  V.Date > @Date and
  V.Ticker = @Ticker and
  (ratingaction in ('initiate','upgrade','downgrade') or
  targetpriceaction in ('increase','decrease') or
  estimateaction in ('upgrade','downgrade') or
  epsnextyearprior <> epsnextyear) 

  Delete From #Tmp1 Where PubNo = @PubNo and Date = @Date and SecurityId = @SecurityId
  Select top 1 @Pubno = pubno,@Date = Date,@Ticker = Ticker,@SecurityId = SecurityId,@LastYear = LastYear from #tmp1 order by pubno,securityid
end

/*
select  Name,
        T.Ticker,
        Date,
        Pubno,
        RatingPrior,
        Rating,
        RatingAction,
        TargetPricePrior,
        TargetPrice,
        TargetPriceAction,
        EPSThisYearPrior,
        EPSThisYear,
        EstimateAction,
        EPSNextYearPrior,
        EPSNextYear 
from    #tmp2 T 
order by 
        T.Ticker,Date
*/

select  distinct 
        Name,
        T.Ticker,
        case when S.EffectiveDate is null then ' ' else '*' end TickerSplit ,
        S.EffectiveDate,
        YearRollOver,
        T1,
        T2,
        T.Date,
        Pubno,
        RatingPrior,
        Rating,
        RatingAction,
        TargetPricePrior,
        TargetPrice,
        TargetPriceAction,
        EPSThisYearPrior,
        EPSThisYear,
        EstimateAction,
        EPSNextYearPrior,
        EPSNextYear 
from    #tmp2 T join (select Ticker,min(Date) Date from #tmp2 group by Ticker) V on T.Ticker = V.Ticker
        left join SplitActions S on T.Ticker = S.Ticker and S.EffectiveDate > V.Date
order by 
        Name,T.Ticker,T.Date


--select * from #tmp1 where Ticker = '1072.HK'
--select * from vFinancials where pubno = 104359 and Ticker = '1072.HK'

