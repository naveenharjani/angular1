-- 2015_05_13_MichelePatron_AnalystCoveraageList.sql
-- 05/13/2015

/*

Michele Patron - Buy-Side Trading - Robert project

*/

select
  A.Last + ', ' + A.First as Analyst,
  S.Ticker,
  RS.LaunchDate,
  RS.DropDate
--  RS.*
from ResearchCoverage RS
join Authors A on A.AuthorId = RS.AnalystId
join Securities2 S on S.SecurityId = RS.SecurityId
where RS.LaunchDate is not null
order by 1, 2, 3, 4
