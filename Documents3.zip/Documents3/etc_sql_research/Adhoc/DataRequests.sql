-- DataRequests.sql

-- 06/22/2020 / Joy Vyas / MandG M&G Coverage Request

select
  'Bernstein' as 'Broker Name',
  S.Company as 'Company',
  R.RegionAlias as 'Region', -- (*use drop-down options*)
  S.CountryCode as 'Country',
  A.Last + ', ' + A.First as 'Analyst Name',
  S.Ticker as 'Ticker',
  S.ISIN as 'ISIN',
  S.SEDOL as 'Sedol',
  I.IndustryName as 'Sector'
--  *
from ResearchCoverage RC
join Industries I on I.IndustryId = RC.IndustryId
join Authors A on A.AuthorId = RC.AnalystId
left join Securities2 S on S.SecurityId = RC.SecurityId
left join Regions R on R.RegionId = S.RegionId
where RC.LaunchDate is not null and RC.DropDate is null
order by 5, 2, S.OrdNo

-- 09/08/2020
-- Ali Hansraj
-- Corporate Planning & Analysis � Bernstein Research Services
-- "allocation methodologies for the profit split regarding transfer pricing"
-- Quaterly Tax Transfer Pricing Process
-- 09/08/2020 - Date >= '01/01/2019' and Date <= '12/31/2019' / AnalystReportCount.xlsx
-- 10/29/2020 - Date >= '01/01/2020' and Date <= '09/30/2020' / AnalystReportCount.xlsx
-- 01/26/2021 - Date >= '01/01/2020' and Date <= '12/31/2020' / AnalystReportCount.xlsx
-- 04/08/2021 - Date >= '01/01/2021' and Date <= '03/31/2021' / AnalystReportCount.xlsx
-- 06/30/2021 - Date >= '01/01/2021' and Date <= '06/30/2021' / AnalystReportCount.xlsx
-- 09/28/2021 - Date >= '01/01/2021' and Date <= '09/30/2021' / AnalystReportCount.xlsx

-- File - AnalystReportCount_YYYY_MM_DD_YTD.xlsx
-- Heading - "Analyst Report Count - mm/dd/yyy - mm/dd/yyyy"

-- Tab - "Primary" xlsx tab
select
  'Analyst' = AU.Last + ', ' + AU.First,
  count(*) as 'Primary'
from Publications PU
join Properties AN on AN.PubNo = PU.PubNo and AN.PropId = 5 -- Document Authors
join Authors AU on AU.Name = AN.PropValue and AU.IsAnalyst = -1
where Date >= '01/01/2021' and Date <= '09/30/2021'
and AN.PropNo = (select min(PropNo) from Properties where PubNo = PU.PubNo and PropID = 5) -- Primary Author
and PU.Type in ('Research Call', 'Comment', 'External Flash', 'Black Book', 'White Book')
group by AU.Last + ', ' + AU.First
order by 1

-- Tab - "All" xlsx tab
select
  'Analyst' = AU.Last + ', ' + AU.First,
  count(*) as 'All'
from Publications PU
join Properties AN on AN.PubNo = PU.PubNo and AN.PropId = 5 -- Document Authors
join Authors AU on AU.Name = AN.PropValue and AU.IsAnalyst = -1
where Date >= '01/01/2021' and Date <= '09/30/2021'
and PU.Type in ('Research Call', 'Comment', 'External Flash', 'Black Book', 'White Book')
group by AU.Last + ', ' + AU.First
order by 1

