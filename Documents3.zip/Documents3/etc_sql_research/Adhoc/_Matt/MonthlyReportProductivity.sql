-- Monthly Report Productivity.sql
-- For Matt
-- 12/05/2013
-- 01/07/2014
-- 02/04/2014
-- 03/03/2014
-- 04/02/2014
-- 05/02/2014
-- 06/03/2014
-- 07/08/2014
-- 09/10/2014
-- 10/01/2014
-- 11/03/2014
-- 12/01/2014
-- 01/02/2015
-- 02/03/2015
-- 03/02/2015
-- 04/01/2015
-- 05/01/2015
-- 06/01/2015
-- 07/01/2015
-- 08/01/2015

use Research
go

-- Frank (active)
select
  AR.Region,
  A.Last,
  A.First,
  year(PU.Date) as Year,
  month(PU.Date) as Month,
  sum (case when PU.Type = 'Research Call'  then 1 else 0 end) as 'Calls',
  sum (case when PR2.PropValue = 'T'        then 1 else 0 end) as 'Proactive',
  sum (case when PU.Type = 'External Flash' then 1 else 0 end) as 'Flashes',
  sum (case when PU.Type = 'Black Book'     then 1 else 0 end) as 'Blackbooks',
  sum (case when PU.Type = 'White Book'     then 1 else 0 end) as 'Whitebooks',
  sum (case when PU.Type = 'Video'          then 1 else 0 end) as 'Videos'
from Publications PU
join Properties PR on PR.PubNo = PU.PubNo and PR.PropId = 5
join Authors A on A.Name = PR.PropValue and A.IsAnalyst = -1
join AuthorRegions AR on AR.RegionId = A.RegionId
left join Properties PR2 on PR2.PubNo = PU.PubNo and PR2.PropId = 30
where PU.Date > '1/1/2012'
group by AR.Region, A.Last, A.First, year(PU.Date), month(PU.Date)
order by 1, 2, 3, 4, 5

-- Naveen (inactive)
DECLARE
@vStartDate       VARCHAR(12),
@vEndDate         VARCHAR(12)

SET @vStartDate = '01/01/2012'
SET @vEndDate   = '11/30/2013'

SELECT distinct
  'LastName'   = RVDA.Last, 
  'FirstName'  = RVDA.First,
  'Year'       = year(RVD.date),
  'Month'      = month(RVD.date),
  'Calls'      = SUM(CASE WHEN RVD.DocTypeId = 1 THEN 1 ELSE 0 END),
  'Proactive'  = SUM(CASE WHEN ISNULL(Pp.PropValue, 'F') = 'T'  THEN 1 ELSE 0 END),
  'Flashes'    = SUM(CASE WHEN RVD.DocTypeId =  8 THEN 1 ELSE 0 END),
  'Blackbooks' = SUM(CASE WHEN RVD.DocTypeId =  3 THEN 1 ELSE 0 END),
  'Whitebooks' = SUM(CASE WHEN RVD.DocTypeId =  6 THEN 1 ELSE 0 END),
  'Videos'     = SUM(CASE WHEN RVD.DocTypeId = 10 THEN 1 ELSE 0 END)
FROM RVDocuments RVD
INNER JOIN RVDocAnalysts RVDA  ON RVDA.DocID = RVD.DocID
INNER JOIN Authors A           ON A.AuthorID  = RVDA.AnalystID
LEFT OUTER JOIN Properties Pp  ON Pp.PropId = 30 AND  Pp.PubNo = RVD.DocId
WHERE RVD.date BETWEEN @vStartDate AND @vEndDate      -- All Pub Dates for the specified date range  
  AND A.MetricsEligible = 'T'                         -- Filter by MetricsEligible flag
  AND A.IsAnalyst = -1                                -- Filter by Analysts only
GROUP BY
  year(RVD.date),
  month(RVD.date),
  RVDA.Last,
  RVDA.First
order by 3, 4, 1
