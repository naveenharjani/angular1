-- RatingsTargets-OnSpecifiedDate.sql
-- 04/08/2015
-- Ratings / Targets at historical point in time
-- Matt Richmond / Robert van Brugge

select * from vFinancials where Ticker = 'AAPL'

select Ticker, max(Date) from vFinancials where Date < '04/01/2014' group by Ticker

-- Ratings / Targets on 3/31/2014
select V.Ticker, V.Rating, V.TargetPrice, V.Currency, V.Date from vFinancials V
join (select Ticker, max(Date) Date from vFinancials where Date < '04/01/2014' group by Ticker) V2
on V.Ticker = V2.Ticker and V.Date = V2.Date
where V.LaunchDate < '04/01/2014' and (V.DropDate is null or V.DropDate > '04/01/2014')
order by V.Date

-- Ratings / Targets on 3/31/2015
select V.Ticker, V.Rating, V.TargetPrice, V.Currency, V.Date from vFinancials V
join (select Ticker, max(Date) Date from vFinancials where Date < '04/01/2015' group by Ticker) V2
on V.Ticker = V2.Ticker and V.Date = V2.Date
where V.LaunchDate < '04/01/2015' and (V.DropDate is null or V.DropDate > '04/01/2015')
order by V.Date

