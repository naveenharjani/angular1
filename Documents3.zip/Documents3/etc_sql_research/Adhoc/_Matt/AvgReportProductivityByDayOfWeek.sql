-- AvgReportProductivityByDayOfWeek.sql
-- 04/21/2017

-- 04/21/2017: Colin
-- Pull the research pubs by date and provide me the US analyst publishing by DAY over the week? 
-- In other words, average number of reports on M, T, W, Th, F.
-- trailing 3 months or trailing 6 months would work


DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)
DECLARE @WeeksBetween	INT

SET @vSinceDate = '01/01/2017'
SET @vUntilDate = '03/31/2017'
SET @WeeksBetween = DATEDIFF(ww, @vSinceDate, @vUntilDate)

-- List of Publications - Filtered by Primary author and Region
SELECT P.Pubno, P.Date, P.Title,
       'Day'   = DATENAME(dw,P.Date),
       'DayId' = DATEPART(dw,P.Date),
       PR.PropNo, A.Last, A.First, AR.Region
INTO #TmpPublications
FROM Publications P
INNER JOIN Properties PR ON PR.PubNo = P.PubNo AND PR.PropId = 5 -- Author
AND PropNo = (SELECT MIN(PropNo) FROM Properties WHERE PubNo = PR.PubNo AND PropId = 5) -- Primary Author
INNER JOIN Authors A ON A.Name = PR.PropValue
INNER JOIN AuthorRegions AR ON AR.RegionId = A.RegionId
WHERE P.Date >= @vSinceDate
  AND P.Date <= @vUntilDate
  AND AR.Region = 'US' -- Region
ORDER BY P.Pubno, PR.PropNo

-- SELECT * FROM #TmpPublications
-- SELECT @vSinceDate, @vUntilDate, 'WeeksBetween' = @WeeksBetween

PRINT 'Average Reports on M,T,W,Th,F for a Region'
SELECT Day,
--'Total' = COUNT(*),
--'AvgReports' = COUNT(*)/@WeeksBetween,
'AvgReports' = CONVERT(DECIMAL(10,1), COUNT(*)/CONVERT(DECIMAL(10,1), @WeeksBetween))
FROM #TmpPublications
GROUP BY DayId, Day
ORDER BY DayId ASC

DROP TABLE #TmpPublications






/*
-- DEBUG
Select * from AuthorRegions
Select * from Authors
select * from propertynames
SELECT * FROM Properties WHERE PubNo = 129367 And PropId = 5
SELECT * FROM RVDocAnalysts WHERE DocId = 126929

Select PubNo, COUNT(*)
From Properties 
Where PropId = 5
GROUP BY PubNo
ORDER BY PubNo DESC
--AND P.PubNo = 129337  -- 129358 -- 129365  (Multiple Authors for publication)

SELECT DATENAME(dw,GETDATE()) -- Friday
SELECT DATEPART(dw,GETDATE()) -- 6
*/