select V2.Company,V1.Ticker,V2.Name Analyst,V1.LaunchDate,V2.RatingChangeDate [Last RatingChange Date],V1.Rating,V1.RatingPrior,V3.TargetPrice 
from vFinancials V1 join 
(select S.SecurityId, S.Ticker,Company, A.Name, max(V.Date) RatingChangeDate 
from 
ResearchCoverage RC join Securities2 S on RC.SecurityID = S.SecurityID
join Authors A on RC.AnalystID = A.AuthorID
join vFinancials V on S.SecurityId = V.SecurityID
where
RC.LaunchDate is not null and RC.DropDate is null and
V.RatingAction in ('Initiate','Upgrade','Downgrade')  
group by S.SecurityId,S.Ticker,S.Company,A.Name) V2 on V1.SecurityId = V2.SecurityID and V1.Date = V2.RatingChangeDate
join vFinancialsLatest V3 on V1.Ticker = V3.Ticker
order by Company
