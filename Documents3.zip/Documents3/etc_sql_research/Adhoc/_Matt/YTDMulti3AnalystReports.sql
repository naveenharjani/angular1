-- YTDMulti3AnalystReports.sql
-- 11/28/2014 per Matt YTD from 2010

-- list of all reports (of any type (calls, blackbooks, flashes, etc) from 2010 to the present 
-- where 3 analysts or more were listed as authors
-- pull only proactive reports

USE Research
GO

DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)

SET @vSinceDate = '05/01/2003'
SET @vUntilDate = getdate()

SELECT
  'Date'          = CONVERT(varchar, RVD.Date, 101),
  'Type'          = RVT.DocType,
  'Title'         = RVD.Title,
  'PrimaryAuthor' = RVDA.Last,
  'NumAnalysts'   = v1.NumAnalysts,
   --ProactiveFlag = ISNULL(Pp.PropValue, 'F'),  
  'ID'            = RVD.DocId
FROM
  ( SELECT DocId, 'NumAnalysts' = COUNT(*) FROM RVDocAnalysts GROUP BY DocId ) AS v1
INNER JOIN RVDocuments RVD    ON RVD.DocId = v1.DocId
INNER JOIN RVTypes RVT        ON RVT.DocTypeId = RVD.DocTypeId
-- Primary analyst indicated by ordinal value
INNER JOIN RVDocAnalysts RVDA ON RVDA.DocId = v1.DocId
  AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM RVDocAnalysts WHERE DocId = RVDA.DocId)
INNER JOIN Properties Pp      ON Pp.PropId = 30 AND  Pp.PubNo = RVD.DocId    -- Proactivity
WHERE RVD.Date BETWEEN @vSinceDate AND @vUntilDate
  AND v1.NumAnalysts >= 3                    -- research with 3 or more analysts
  AND ISNULL(Pp.PropValue, 'F') = 'T'        -- proactive reports only
ORDER BY RVD.Date ASC, V1.DocId ASC

/*
SELECT * FROM PropertyNames WHERE PropName = 'Proactivity'
SELECT distinct PropValue FROM Properties WHERE PropId = 30
*/


