-- YTDAnalystEvals.sql
-- 12/02/2014

-- Can you run the number of long view pieces and stock launches (other than starting launch) for every analyst globally 
-- from 11/1/13 to 10/31/14?
-- analysts� year-end evaluations

DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)

SET @vSinceDate = '11/01/2013'
SET @vUntilDate = '10/31/2014'

SELECT V.Author,
   	 'LongViewCount' = SUM(CASE WHEN V.Flag = 'LongView' THEN 1 ELSE 0 END),
     'LaunchCount'   = SUM(CASE WHEN V.Flag = 'Launch'   THEN 1 ELSE 0 END)
FROM
(
SELECT 'Author' = RVDA.Last + ',' + RVDA.First,
       'Date'   = CONVERT(varchar, P.Date, 101),
       'Flag' = ( CASE
                    WHEN P.Title LIKE '%long view%' THEN 'LongView'
                    ELSE 'Launch'
                  END),
       P.Title, P.Type, P.PubNo
FROM Publications P WITH(NOLOCK)
INNER JOIN RVDocAnalysts RVDA on RVDA.DocId = P.PubNo
  --AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM RVDocAnalysts WHERE DocId = RVDA.DocId)
WHERE P.Date BETWEEN @vSinceDate AND @vUntilDate
AND ( P.Title LIKE '%long view%'
     OR
     P.PubNo IN (SELECT V.PubNo FROM vFinancials V WHERE ( CoverageAction IN ('INITIATE') OR RatingAction IN ('INITIATE'))) 
      )
-- ORDER BY P.Date DESC, P.PubNo DESC
) V
GROUP BY	V.Author
ORDER BY	V.Author
