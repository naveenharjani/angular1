-- HistoricalRatingsTargets.sql
-- HistoricalRatingsTargets.xlsx

-- Prepared for Quant Group (Yiling Chen) to analyze fundamental vs. quantitative analysis
-- 04/16/2012
-- 07/06/2012
-- 04/02/2014 Lin Lin
-- 04/09/2014 Lin Lin - Added SecurityId (Quant can track ticker changes at own risk)
-- 06/30/2014 Yiling Chen
-- 05/06/2020 Harjaspreet Mand - HistoricalRatingsTargets.xlsx
-- 06/29/2020 Harjaspreet Mand - HistoricalRatingsTargets.xlsx
-- 08/18/2020 Harjaspreet Mand - HistoricalRatingsTargets.xlsx

select
  'Date' = convert(char(10), V.Date, 101),
  V.Ticker,
  V.SecurityId,
  V.PubNo,
--  'CoverageAction' = isnull(V.CoverageAction, ''),
  V.Rating,
--  'RatingPrior' = isnull(V.RatingPrior, ''),
  V.RatingAction,
  V.TargetPrice,
  V.Currency,
  V.TargetPriceAction,
  'Analyst' = A.Last
from vFinancials V
join Authors A ON A.AuthorId = V.AnalystId
where  V.Date >= '5/1/2003'
and (RatingAction in ('UPGRADE', 'DOWNGRADE', 'INITIATE', 'DROP') or TargetPriceAction in ('INCREASE', 'DECREASE') )
order by V.Date desc, Ticker


-- 12/11/2018
-- Patrick Kelly / Dodge & Cox

select
  'Date' = convert(char(10), V.Date, 101),
  V.Ticker,
  S.Company,
  V.Rating,
  V.RatingAction,
  'Analyst' = A.Last
from vFinancials V
join Securities2 S on S.SecurityId = V.SecurityId
join Authors A ON A.AuthorId = V.AnalystId
where  V.Date >= '5/1/2003'
and RatingAction in ('INITIATE', 'UPGRADE', 'DOWNGRADE')
order by V.Date desc, S.Company, S.OrdNo

