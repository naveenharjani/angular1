-- Blackbooks.sql
-- 02/24/2020

/*

02/24/2020 - Colin Blackbook data request
09/16/2021 - Colin Blackbook data request

*/

SELECT
  'Date' = CAST(P.Date as DATE),
  'Year' = YEAR(P.Date),
  'Month' = MONTH(P.Date),
  P.PubNo,
  P.Title,
  A.Last + ', ' + A.First AS 'Primary Analyst',
  AR.Region as 'Primary Analyst Region',
  'Investor Theme'= ISNULL((SELECT STRING_AGG(PropValue, ', ') WITHIN GROUP(ORDER BY PropNo) FROM Properties WHERE PubNo = P.PubNo AND PropId = 32), ''),                                           -- InvestorTheme
  'Analyst Count'= (SELECT COUNT(*) FROM Properties JOIN Authors A ON A.Name = PropValue WHERE PubNo = P.PubNo AND PropId = 5 AND A.IsAnalyst = -1),                                                -- Author (analysts)
  'Analysts' = (SELECT STRING_AGG(PropValue, ', ') WITHIN GROUP (ORDER BY PropNo) FROM Properties JOIN Authors A ON A.Name = PropValue WHERE PubNo = P.PubNo AND PropId = 5  AND A.IsAnalyst = -1)  -- Author (analysts)
FROM Publications P
JOIN Properties Pr ON P.PubNo = Pr.PubNo AND Pr.PropId = 5 -- Author
JOIN Authors A ON Pr.PropValue = A.Name
JOIN AuthorRegions AR ON AR.RegionId = A.RegionId
WHERE P.Type = 'Black Book'
AND Pr.PropNo = (SELECT MIN(PropNo) FROM Properties WHERE PubNo = P.PubNo AND PropId = 5) -- Primary Author
AND P.Date >= '01/01/2010'
ORDER BY Date DESC, PubNo DESC
GO


select '01/01/2010' Date, count(distinct AnalystId) NumAnalysts from ResearchCoverage RC where LaunchDate <= '01/01/2010' and (DropDate is null or DropDate > '01/01/2010')
union
select '01/01/2011', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2011' and (DropDate is null or DropDate > '01/01/2011')
union
select '01/01/2012', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2012' and (DropDate is null or DropDate > '01/01/2012')
union
select '01/01/2013', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2013' and (DropDate is null or DropDate > '01/01/2013')
union
select '01/01/2014', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2014' and (DropDate is null or DropDate > '01/01/2014')
union
select '01/01/2015', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2015' and (DropDate is null or DropDate > '01/01/2015')
union
select '01/01/2016', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2016' and (DropDate is null or DropDate > '01/01/2016')
union
select '01/01/2017', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2017' and (DropDate is null or DropDate > '01/01/2017')
union
select '01/01/2018', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2018' and (DropDate is null or DropDate > '01/01/2018')
union
select '01/01/2019', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2019' and (DropDate is null or DropDate > '01/01/2019')
union
select '01/01/2020', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2020' and (DropDate is null or DropDate > '01/01/2020')
union
select '01/01/2021', count(distinct AnalystId) from ResearchCoverage RC where LaunchDate <= '01/01/2021' and (DropDate is null or DropDate > '01/01/2021')
GO
