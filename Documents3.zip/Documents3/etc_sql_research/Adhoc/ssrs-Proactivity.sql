--Proactivity Report
--SSRS Report -  http://acx3ama0509/ReportServer/Pages/ReportViewer.aspx?%2fReports%2fPRD%2fProactivity&rs%3aCommand=Render
--Filters - Since, Until, Analyst
--Report - ID, Date, Analyst (Last or Last, First), Title
--SQL - Dynamic (now), sp (future)
--provide click-through access to the report by clicking on the title

DECLARE @StartDate datetime
DECLARE @UntilDate datetime
DECLARE @Analyst   int

SET @StartDate = '01/01/2010'
SET @UntilDate = '09/03/2010'
SET @Analyst = 295  --Aspesi, Claudio

SELECT     PU.PubNo AS ID, PU.Date, RA.Last + ', ' + RA.First AS Analyst, PU.Title, D.FileName
FROM         Publications AS PU INNER JOIN
                      Documents AS D ON D.PubNo = PU.PubNo AND D.DocType = 'PDF' LEFT OUTER JOIN
                      Properties AS PR ON PR.PubNo = PU.PubNo AND PR.PropID = 30 LEFT OUTER JOIN
                      RVDocAnalysts AS RA ON RA.DocId = PU.PubNo
WHERE     (PU.Type IN ('Research Call')) AND (ISNULL(PR.PropValue, 'F') = 'T') AND (PU.Date >= @StartDate) AND (PU.Date <= @UntilDate) AND 
                      (RA.AnalystId = @Analyst)
ORDER BY PU.Date DESC, ID DESC, RA.OrdinalId DESC
