-- ResearchCallPDFCounts.sql

--Research Database : PROD

USE Research
GO

-- Publication - Research Call Count and Total PDF Page Count
SELECT
  YEAR(Date)        AS SortYear,
  COUNT(*)          AS TotalResearchCalls,
  SUM(ISNULL(PageCount,0))    AS TotalPDFPages
FROM [dbo].[Publications]
WHERE Type = 'Research Call'
--AND year(Date) = 2011
GROUP BY
  YEAR(Date)
ORDER BY 1 desc

SELECT
  YEAR(Date)        AS SortYear,
  --MONTH(Date)                                             AS 'Sort Month',
  --DATENAME(mm, Date) + ' ' + DATENAME(yy, Date)           AS 'Read Month',
  COUNT(*)          AS TotalResearchCalls,
  SUM(PageCount)    AS TotalPDFPages
FROM [dbo].[Publications]
WHERE Type = 'Research Call'
--AND year(Date) = 2011
GROUP BY
  YEAR(Date)
  --MONTH(Date),
  --DATENAME(mm, Date) + ' ' + DATENAME(yy, Date)
ORDER BY 1 desc


-- Publication - Research Call Count and Total PDF Page Count
SELECT
  YEAR(Date)                                              AS 'Sort Year',
  MONTH(Date)                                             AS 'Sort Month',
  DATENAME(mm, Date) + ' ' + DATENAME(yy, Date)       AS 'Read Month',
  PubNo, Date, Type, Title, FileSize, PageCount
FROM [dbo].[Publications]
--WHERE Type = 'Research Call'
--AND year(Date) = 2012
--and MONTH(Date) = 4
WHERE pagecount is null
ORDER BY 1, 2
