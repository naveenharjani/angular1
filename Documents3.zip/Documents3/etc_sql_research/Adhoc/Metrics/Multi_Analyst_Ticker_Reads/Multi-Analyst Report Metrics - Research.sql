-- Multi-Analyst Report Metrics - Research.sql

-- Bernstein Commodities and Power
-- Weekly Commodities and Power Blast

/*

select p.pubno,title,date,a.name,isanalyst from publications p join properties pr on p.pubno = pr.pubno 
join authors a on pr.propvalue = a.name 
where
a.isanalyst = -1 and 
p.pubno in 
        (select p.pubno from publications p join properties pr on p.pubno = pr.pubno
          join authors a on pr.propvalue = a.name
          where
              p.type = 'Research Call' and
              a.isanalyst = -1 and
              pr.propid = 5 and
              title not like '%media blast%' and
              title not like '%bernstein energy%' and
              date between '01/01/2007' and '12/31/2008' 
          group by
                p.pubno
          having count(*) > 1)
          order by p.pubno desc

*/

--
print 'Num Calls w/ more than one senior analyst including media and energy blasts'
select Year = datepart(yy,date),CallCount = count(pubno) 
from
  publications p 
where
  p.pubno in 
        (select p.pubno from publications p join properties pr on p.pubno = pr.pubno
          join authors a on pr.propvalue = a.name
          where
              p.type = 'Research Call' and
              a.isanalyst = -1 and
              pr.propid = 5 and
              date between '01/01/2007' and '12/31/2008' 
          group by
                p.pubno
          having count(*) > 1)
group by
  datepart(yy,date)
order by 1 desc

print 'Num Calls w/ more than one senior analyst excluding media and energy blasts'
select Year = datepart(yy,date),CallCount = count(pubno) 
from
  publications p 
where
  p.pubno in 
        (select p.pubno from publications p join properties pr on p.pubno = pr.pubno
          join authors a on pr.propvalue = a.name
          where
              p.type = 'Research Call' and
              a.isanalyst = -1 and
              pr.propid = 5 and
              title not like '%media blast%' and
              title not like '%Commodities and Power%' and
              date between '01/01/2007' and '12/31/2008' 
          group by
                p.pubno
          having count(*) > 1)
group by
  datepart(yy,date)
order by 1 desc
