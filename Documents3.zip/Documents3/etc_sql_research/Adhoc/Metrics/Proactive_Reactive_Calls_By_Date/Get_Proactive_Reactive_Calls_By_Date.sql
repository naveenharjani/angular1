DECLARE @RptStartDate varchar(12)
DECLARE @RptEndDate varchar(12)

SET @RptStartDate = '01/01/2009'
SET @RptEndDate = '07/12/2010'

SELECT V.Last, V.First,
       CONVERT(VARCHAR(10), V.PubDate, 101) AS [PublishedDate],
       SUM(CASE WHEN V.ProactiveFlag = 'T' 
	              THEN 1 ELSE 0 END)    AS [TotalProactiveCalls],
       SUM(CASE WHEN V.ProactiveFlag = 'F' 
	              THEN 1 ELSE 0 END)    AS [TotalReactiveCalls],
       COUNT(*) AS [TotalCalls]
       --V.AnalystId
FROM (
      SELECT distinct
             RVDA.AnalystId AS AnalystId, RVDA.Last AS Last, RVDA.First AS First,
             RVD.DocId, RVD.date, RVD.title, 
             RVD.DocTypeId, --RVT.DocType, 
             CAST ( CONVERT(VARCHAR(10), RVD.date, 101) AS datetime) AS PubDate,
             ProactiveFlag = ISNULL(Pp.PropValue, 'F'),
             ProactiveFlag2 = ISNULL(P.Proactivity, 'F'),
             ProactiveFlag_Eval =
             CASE
              WHEN ISNULL(Pp.PropValue, 'F') = 'T' THEN 'T'
              WHEN ISNULL(P.Proactivity, 'F') = 'T' THEN 'T'
              ELSE ISNULL(Pp.PropValue, 'F')
             END
      FROM RVDocuments RVD
      INNER JOIN RVTypes RVT           ON RVT.DocTypeId = RVD.DocTypeId
      INNER JOIN RVDocAnalysts RVDA    ON RVDA.DocID = RVD.DocID
       
      --Active Coverage - Consider Analysts with Active Ticker Coverage as of today from the ResearchCoverage Table
      --AND RVDA.AnalystId IN (SELECT DISTINCT ANALYSTID FROM RVResearchCoverage RVRC WHERE Dropdate IS NULL)
       
      LEFT OUTER JOIN Proactivity P ON P.PubNo = RVD.DocId    
      LEFT OUTER JOIN Properties Pp ON Pp.PropId = 30 AND  Pp.PubNo = RVD.DocId    --Use Properties for Proactivity - 07/07/2010

      WHERE RVD.date BETWEEN @RptStartDate AND @RptEndDate     -- All Pub Dates for the specified date range
      AND RVD.DocTypeId = 1 --Research Calls only
      )V
      GROUP BY V.AnalystId, V.Last, V.First, V.PubDate
      ORDER By V.Last asc, V.PubDate asc