-- ReportHistory.sql
-- 01/04/2019

-- Excel file with all research reports published from 1/1/2017 through 12/31/2018 with the following columns:
-- Publication date
-- Report type (e.g. call, blackbook)
-- Report title
-- Primary author
-- Number of pages

SELECT
  'Publication Date' = CONVERT(VARCHAR(12), PU.Date, 106),
  'ID' = PU.PubNo,
  'Report Type' = 
	CASE PU.Type
		WHEN 'Research Call'  THEN 'Call'
		WHEN 'Black Book'     THEN 'Blackbook'
		WHEN 'White Book'     THEN 'Whitebook'
		WHEN 'External Flash' THEN 'QuickTake'
		ELSE PU.Type
	END,
  'Report Title' = PU.Title,
  'Primary Author' = AU.Last + ', ' + AU.First,
  'Num Pages' = ISNULL(PU.PageCount, '')
FROM Publications PU
JOIN Properties AN ON AN.PubNo = PU.PubNo AND AN.PropID = 5 -- Document Authors
JOIN Authors AU ON AU.Name = AN.PropValue
WHERE Date >= '01/01/2017' and Date <= '12/31/2018'
and AN.PropNo = (select MIN(PropNo) from Properties where PubNo = PU.PubNo and PropID = 5) -- Primary Author
ORDER BY PU.Date, PU.PubNo


SELECT count(*) FROM Publications WHERE Date >= '01/01/2017' and Date <= '12/31/2018'

