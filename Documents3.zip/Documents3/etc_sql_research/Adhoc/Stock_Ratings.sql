
SELECT 'Coverage As Of Date' = CONVERT(varchar, Date,101),
       'Stocks Under Coverage' = Count(*),
    	 SUM(CASE WHEN Rating = 'O' THEN 1 ELSE 0 END) AS [OutPerform],
    	 SUM(CASE WHEN Rating = 'M' THEN 1 ELSE 0 END) AS [MarketPerform],
    	 SUM(CASE WHEN Rating = 'U' THEN 1 ELSE 0 END) AS [UnderPerform]
FROM DailyRatings    	 
where Date = '02/29/2012'
group by Date


/*
select * from TickerTableSecurities order by closedate desc

select * from dailyratings
where date = '01/31/2011'
order by securityid

--select securityid, ticker, rating, date from vfinancials vf
--WHERE vF.Date = '01/31/2011'
--order by vf.date desc, securityid


SELECT    SecurityId, Date, Rating
FROM      dbo.DailyRatings
WHERE     Date = '01/31/2011' AND 
          (SecurityId IN
                          (SELECT DISTINCT s.SecurityId
                            FROM          dbo.ResearchCoverage AS rc INNER JOIN
                                                   dbo.Securities2 AS s ON s.SecurityID = rc.SecurityID
                            WHERE      dropdate is null and launchdate is not null))
ORDER BY Date DESC

select securityid from researchcoverage
where dropdate is null and launchdate is not null

-- New Stock Initiates
SELECT 'Ticker' = S.ticker,
       'Company' = S.Company,
       'Analyst' = A.name,
       'DateInitiation' = convert(varchar(10), vF.date, 110),
       'Rating' = vF.Rating,
       'RatingAction' = vF.RatingAction
FROM    vFinancials vF 
JOIN Securities2 s ON S.Ticker = vF.Ticker
join Authors A on A.AuthorID = vF.AnalystId
WHERE vF.Date = '01/31/2011'
order by vF.date desc, Ticker
*/