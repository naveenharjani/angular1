-- SpecialCharsInBullets.sql

-- 1/15/2015 - Bullets
-- 6/15/2016 - Bullets and Titles

--http://www.ascii-code.com/

DECLARE @Counter int = 1
DECLARE @PropValue varchar(255) 
DECLARE @PropId int
DECLARE @PropNo int
DECLARE @SpecialCharFound int = 0
DECLARE @PubNo int


-- Check special characters in Bullets
SET NOCOUNT ON
SELECT PubNo,PropId,PropValue,' ' SplChar,0 AsciiCode INTO #Tmp_Output FROM Properties WHERE 1 = 2
SELECT TOP 1 @PubNo = PubNo, @PropNo = PropNo, @PropId = PropID, @PropValue = PropValue FROM Properties WHERE PropId in (24,25,26) ORDER BY PropNo

WHILE @@ROWCOUNT = 1
  BEGIN
    --SELECT @Pubno,@PropNo,@PropId
    WHILE @Counter <= DATALENGTH(@PropValue)
       BEGIN
        IF  (ASCII(SUBSTRING(@PropValue, @Counter, 1)) >= 123) or
            (ASCII(SUBSTRING(@PropValue, @Counter, 1)) between 33 and 47) or
            (ASCII(SUBSTRING(@PropValue, @Counter, 1)) between 58 and 64) or
            (ASCII(SUBSTRING(@PropValue, @Counter, 1)) between 91 and 96)
        BEGIN
          --SELECT SUBSTRING(@PropValue, @Counter, 1), ASCII(SUBSTRING(@PropValue, @Counter, 1))
          SELECT @SpecialCharFound = 1
          BREAK
        END
        SET @Counter = @Counter + 1
       END
    IF @SpecialCharFound = 1 
    BEGIN
      INSERT INTO #Tmp_Output SELECT @PubNo,@PropId,@PropValue,SUBSTRING(@PropValue, @Counter, 1),ASCII(SUBSTRING(@PropValue, @Counter, 1))
    END
    SET @Counter = 1
    SET @SpecialCharFound = 0
    SELECT TOP 1 @PubNo = PubNo, @PropNo = PropNo, @PropId = PropID, @PropValue = PropValue FROM Properties WHERE PropId in (24,25,26) AND PropNo > @PropNo ORDER BY PropNo
  END

-- Get last report with this special character in bullets
SELECT T2.SplChar,T2.AsciiCode,T2.PubNo,T2.PropID,T2.PropValue FROM #Tmp_Output T2 join
(SELECT T.splchar,T.pubno,max(T.PropId) PropId FROM #Tmp_Output T
join (SELECT splchar,max(pubno) PubNo FROM #Tmp_Output GROUP BY SplChar) V on T.SplChar = V.SplChar and T.PubNo = V.PubNo 
GROUP BY T.SplChar,T.PubNo) V2 on T2.SplChar = V2.SplChar and T2.PubNo = V2.PubNo and T2.PropID = V2.PropId
ORDER BY AsciiCode

-- Get list of special characters as one string
SELECT ISNULL(STUFF((SELECT distinct '' + convert(varchar(4),SplChar) FROM #Tmp_Output WITH(NOLOCK) FOR XML PATH('')), 1, 1, ''), '')
DROP TABLE #Tmp_Output



-- Check special characters in Titles
DECLARE @Title varchar(255)

SET NOCOUNT ON
SELECT PubNo, Title,' ' SplChar,0 AsciiCode INTO #Tmp_Title_Output FROM Publications WHERE 1 = 2
SELECT TOP 1 @PubNo = PubNo, @Title = Title FROM Publications ORDER BY PubNo

SET @Counter = 1

WHILE @@ROWCOUNT = 1
  BEGIN
    WHILE @Counter <= DATALENGTH(@Title)
       BEGIN
        IF  (ASCII(SUBSTRING(@Title, @Counter, 1)) >= 123) or
            (ASCII(SUBSTRING(@Title, @Counter, 1)) between 33 and 47) or
            (ASCII(SUBSTRING(@Title, @Counter, 1)) between 58 and 64) or
            (ASCII(SUBSTRING(@Title, @Counter, 1)) between 91 and 96)
        BEGIN
          SELECT @SpecialCharFound = 1
          BREAK
        END
        SET @Counter = @Counter + 1
       END
    IF @SpecialCharFound = 1 
    BEGIN
      INSERT INTO #Tmp_Title_Output SELECT @PubNo,@Title,SUBSTRING(@Title, @Counter, 1),ASCII(SUBSTRING(@Title, @Counter, 1))
    END
    SET @Counter = 1
    SET @SpecialCharFound = 0
    SELECT TOP 1 @PubNo = PubNo, @Title = Title FROM Publications WHERE PubNo > @PubNo ORDER BY PubNo
  END
GO

-- Get last report with this special character in title
SELECT T2.SplChar,T2.AsciiCode,T2.PubNo, T2.Title
FROM #Tmp_Title_Output T2 join
(SELECT T.splchar,max(T.pubno) pubno FROM #Tmp_Title_Output T
join (SELECT splchar,max(pubno) PubNo FROM #Tmp_Title_Output GROUP BY SplChar) V on T.SplChar = V.SplChar and T.PubNo = V.PubNo 
GROUP BY T.SplChar,T.PubNo) V2 on T2.SplChar = V2.SplChar and T2.PubNo = V2.PubNo
ORDER BY AsciiCode

-- Get list of special characters as one string
SELECT ISNULL(STUFF((SELECT distinct '' + convert(varchar(4),SplChar) FROM #Tmp_Title_Output WITH(NOLOCK) FOR XML PATH('')), 1, 1, ''), '')

DROP TABLE #Tmp_Title_Output





