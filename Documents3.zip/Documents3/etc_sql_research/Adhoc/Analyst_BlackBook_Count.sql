-- Analyst_BlackBook_Count.sql
-- 07/21/2020

SELECT distinct AU.Last, AU.First, AU.AuthorId, PU.Type, PU.PubNo, PU.Date, PU.Title
INTO #TmpAuthorList
FROM ResearchCoverage RC
LEFT JOIN Authors AU ON AU.AuthorId = RC.AnalystId
LEFT JOIN Properties Pr ON Pr.PropValue = AU.Name AND Pr.PropID = 5 -- Author
LEFT JOIN Publications PU ON PU.PubNo = Pr.PubNo
WHERE RC.DropDate IS NULL
AND PU.Type in ('Black Book', 'Video', 'Podcast')
AND PU.PubNo <> 154891 -- exclude SDC blackbook - it was the SDC video, not a black book

-- SELECT distinct last, AuthorId, Count(*) FROM #TmpAuthorList GROUP BY last, AuthorId

SELECT distinct V.Last, V.First,
       'BlackBookCount' = (SELECT COUNT(*) FROM #TmpAuthorList WHERE AuthorId = V.AuthorId AND Type = 'Black Book' AND Date >= getdate() - 365),
       'BlackBookLastPublished' = (SELECT MAX(Date) FROM #TmpAuthorList WHERE AuthorId = V.AuthorId AND Type = 'Black Book'),
       'VideoCount' = (SELECT COUNT(*) FROM #TmpAuthorList WHERE AuthorId = V.AuthorId AND Type = 'Video'AND Date >= getdate() - 365),
       'VideoLastPublished' = (SELECT MAX(Date) FROM #TmpAuthorList WHERE AuthorId = V.AuthorId AND Type = 'Video'),
       'PodcastCount' = (SELECT COUNT(*) FROM #TmpAuthorList WHERE AuthorId = V.AuthorId AND Type = 'Podcast'AND Date >= getdate() - 365),
       'PodcastLastPublished' = (SELECT MAX(Date) FROM #TmpAuthorList WHERE AuthorId = V.AuthorId AND Type = 'Podcast'),
	    V.AuthorId
FROM #TmpAuthorList V

DROP TABLE #TmpAuthorList
GO