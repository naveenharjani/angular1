-- Analyst Report Productivity

select distinct AnalystName=name,ProductType=type,DatePublished=date,ProductTitle=title 
from
authors a join researchcoverage rc on a.authorid = rc.analystid and rc.dropdate is null
join properties pr on a.name = pr.propvalue
join publications p on pr.pubno = p.pubno
where
p.type <> 'flash' and
p.date >= '01/01/2008'
order by 1,2,3

-- Analyst Company Launches

select AnalystName=name,InitiatingDate=launchdate,InitiatingTicker = ticker,ProductTitle = Title
from
authors a join researchcoverage rc on a.authorid = rc.analystid and rc.dropdate is null
join securities2 s on rc.securityid = s.securityid
join properties pr on a.name = pr.propvalue
join publications p on pr.pubno = p.pubno
where
p.type = 'research call' and
p.date = rc.launchdate and
p.date >= '01/01/2008'
order by 1,2,3

-- 02/02/2010 - Adam - Historical ratings and target prices

select
  Ticker,
  Currency,
  'Date' = convert(varchar(10), Date, 110),
  PubNo,
  Rating,
--  RatingPrior = isnull(RatingPrior, ''),
  RatingAction,
  TargetPrice,
--  TargetPricePrior,
  TargetPriceAction,
  'Analyst' = A.Last
--  TargetPriceOrig
from vFinancials vF
join Authors A on A.AuthorID = vF.AnalystId
where RatingAction <> 'Reiterate' or TargetPriceAction <> 'Update'
order by vF.Date desc, Ticker

-- 03/30/2011 - Robert 2011 Q1 Proactivity with primary analyst

exec spSearchProactivity 1, 'd', 1, 10000, null, 'Date >= ''01/01/2011'' and Date <= ''03/31/2011'''

select
  PU.PubNo,
  PU.Date,
  PU.Title,
  AU.Last,
  Proactivity = PR.PropValue
from Publications PU
join Properties AN on AN.PubNo = PU.PubNo and AN.PropID = 5 -- Author
join Authors AU on AU.Name = AN.PropValue and AU.IsAnalyst <> 0
left join Properties PR on PR.PubNo = PU.PubNo and PR.PropID = 30
where Type in ('Research Call')
and Date >= '01/01/2011' and Date <= '03/31/2011'
and AN.PropNo = (select MIN(PropNo) from Properties where PubNo = PU.PubNo and PropID = 5) -- Primary Author
order by 1, 2

-- 07/14/2011 - Caroline Hemmings - Rating change history

select
Ticker, Date, Rating, RatingPrior, RatingAction, PubNo
from vFinancials V
JOIN Authors A ON A.AuthorID = V.AnalystID
where  V.Date >= '1/1/2009'
and V.Date <= '7/14/2011'
AND (RatingAction IN ('UPGRADE', 'DOWNGRADE'))
order by V.Date desc, Ticker, PubNo desc

-- 07/15/2011 - Caroline Hemmings - Rating change history
-- 10/04/2011 - Caroline Hemmings - Rating change history

select
Ticker, Date, Rating, RatingPrior, RatingAction, PubNo
from vFinancials V
join Authors A on A.AuthorID = V.AnalystID
where
V.Date >= '5/1/2003' and
(RatingAction IN ('UPGRADE', 'DOWNGRADE'))
order by V.Date desc, Ticker, PubNo desc

-- 08/10/2011 - RVB - Coverage with rating and target price

select S.Company, VFL.Ticker, VFL.Rating, VFL.TargetPrice, VFL.Currency
from vFinancialsLatest VFL
join Securities2 S on S.SecurityId = VFL.SecurityId
order by 1, 2

-- 10/05/2011 - Caroline Hemmings - Rating & coverage change history

select
  Ticker,
  Date,
  Rating,
  'Rating Prior' = isnull(RatingPrior, ''),
  'Rating Action ' = isnull(RatingAction, ''),
  'Coverage Action' = isnull(CoverageAction,''),
  PubNo
from vFinancials V
join Authors A on A.AuthorID = V.AnalystID
where
V.Date >= '5/1/2003' and
( RatingAction IN ('UPGRADE', 'DOWNGRADE') or CoverageAction IN ('INITIATE', 'DROP') ) 
order by V.Date desc, Ticker, PubNo desc


-- 08/16/2016 - Robert van Brugge - Ticker list with CUSIP, SEDOL, ISIN

select distinct
  S.Company,
  S.Ticker,
  S.SEDOL,
  S.CUSIP,
  S.ISIN,
  S.OrdNo
  --S.*
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate >= '01/01/2004'
order by S.Company, S.OrdNo

-- 10/07/2016
-- Stanley Ho - Investor Theme metadata

select 'Active Theme' = InvestorTheme from InvestorThemes IT where IsLive = 'Y' order by SeqNo

select 'Inactive Theme' = InvestorTheme from InvestorThemes IT where IsLive = 'N' order by EditDate

select
  'Active Theme' = IT.IsLive,
  'Theme' = PR.PropValue,
  'Report Date' = PU.Date,
  'Report Title' = PU.Title
--  IT.EditDate, PR.PropValue, PU.*
from Properties PR
join Publications PU on PU.PubNo = PR.PubNo and PropId = 32
left join InvestorThemes IT on IT.InvestorTheme = PR.PropValue
order by IT.IsLive, IT.SeqNo, PR.PropValue, PU.Date

