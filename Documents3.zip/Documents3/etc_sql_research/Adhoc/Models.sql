--Models.sql

--04/22/2020
--Request to copy latest models for Ali Dibadj's coverage.
--As his coverage is dropped, links to these models will not resolve. 
select ModelId, FileName, 'copy \\researchfs\research\links\models\' + FileName + ' ' + '"\\nts0016\rsch1\HPC & Bevs\01a - Financial Model; Companies\Old Client Company Models\' + S.Ticker + '.' + substring(FileName,CHARINDEX('.',FileName) + 1,len(FileName) - CHARINDEX('.',FileName)) + '"' 
from Models M join Securities2 S on M.SecurityId = S.SecurityId 
where M.ModelId in
(select max(ModelId) ModelId
from Models
where SecurityId in 
(select Securityid from researchcoverage where analystid =
(select authorid from Authors where Name like '%dibadj%')
and LaunchDate is not null 
and DropDate = '2020-03-30 00:00:00.000')
group by SecurityId)

