drop table #tmp1
drop table #tmp_final
drop table #tmp_company
drop table #tmp_pubs
drop table #tmp_industry
go
select datepart(yy,date) year,datepart(mm,date) month,p.pubno,count(distinct company) companycount
into #tmp1
from 
publications p join properties pr on p.pubno = pr.pubno 
join securities2 s on pr.propvalue = s.ticker
where
pr.propid = 13 and
p.type in ('research call','external flash') and
s.tickertype = 'stock' and
date >= '01/01/2008'
group by datepart(yy,date),datepart(mm,date),p.pubno
order by datepart(yy,date),datepart(mm,date)

Create Table #tmp_final
(year int not null,
month int not null,
#pubs int not null,
#company int not null,
#industry int not null,
companypercent float,
industrypercent float
)

insert into #tmp_final(year,month,#pubs,#company,#industry)
select year,month,0 #Pubs,0 #Company,0 #Industry
from
#tmp1
group by year,month

--company
select year,month,count(pubno) company
into #tmp_company
from
#tmp1 
where companycount = 1
group by year,month

Update #tmp_final
Set #Company = company
From
#tmp_final tf join #tmp_company tc on tf.year = tc.year and tf.month = tc.month

--industry
select year,month,count(pubno) industry
into #tmp_industry
from
#tmp1 
where companycount > 1
group by year,month

Update #tmp_final
Set #Industry = Industry
From
#tmp_final tf join #tmp_Industry ti on tf.year = ti.year and tf.month = ti.month

--pubs
select year,month,count(pubno) Pubs
into #tmp_pubs
from
#tmp1 
group by year,month

Update #tmp_final
Set #Pubs = Pubs
From
#tmp_final tf join #tmp_pubs tp on tf.year = tp.year and tf.month = tp.month

--update percent
Update #tmp_final
Set CompanyPercent = round((cast(#Company as float) * 100)/cast(#Pubs as float),1), IndustryPercent = round((cast(#Industry as float) * 100)/cast(#Pubs as float),1)

select year,datename(mm,convert(varchar,month) + '/01/' + convert(varchar,year)),#pubs,#company,#Industry,CompanyPercent,IndustryPercent from #tmp_final
order by year,month
go


