-- QA Coverage Data.sql

-- br.com QA data

--Delete QA data if exists
delete from researchcoverage 
where 
industryid in (select industryid from industries where industryname like 'QA Industry%') OR
securityid in (select securityid from securities2 where company like '%QA%Security') OR
analystid in (select authorid from authors where name like 'QA Firstname%')
delete from sectors where sector like '%QA Sector%'
delete from Securities2 where company like '%QA%Security'
delete from industries where industryname like 'QA Industry%'
delete from authors where name like 'QA Firstname%'

--Insert Sectors Data
insert into sectors(sectorid,sector,sort) select 25,'QA Sector 1',25
insert into sectors(sectorid,sector,sort) select 26,'QA Sector 2',26
insert into sectors(sectorid,sector,sort) select 27,'QA Sector 3',27

--Insert Industries Data
insert into industries(industryname,sectorid,editorid,editdate)
select 'QA Industry A',25,1,getdate()
insert into industries(industryname,sectorid,editorid,editdate)
select 'QA Industry B',25,1,getdate()
insert into industries(industryname,sectorid,editorid,editdate)
select 'QA Industry C',26,1,getdate()
insert into industries(industryname,sectorid,editorid,editdate)
select 'QA Industry D',26,1,getdate()
insert into industries(industryname,sectorid,editorid,editdate)
select 'QA Industry DE',27,1,getdate()
insert into industries(industryname,sectorid,editorid,editdate)
select 'QA Industry CF',27,1,getdate()

--Tickers Data
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA01','QA01 Security','NYSE','USD','SPX','QA01',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA02','QA02 Security','NYSE','USD','SPX','QA02',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA03','QA03 Security','NYSE','USD','SPX','QA03',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA04','QA04 Security','NYSE','USD','SPX','QA04',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA05','QA05 Security','NYSE','USD','SPX','QA05',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA06','QA06 Security','NYSE','USD','SPX','QA06',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA07','QA07 Security','NYSE','USD','SPX','QA07',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA08','QA08 Security','NYSE','USD','SPX','QA08',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA09','QA09 Security','NYSE','USD','SPX','QA09',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA10','QA10 Security','NYSE','USD','SPX','QA10',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA11','QA11 Security','NYSE','USD','SPX','QA11',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA12','QA12 Security','NYSE','USD','SPX','QA12',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA13','QA13 Security','NYSE','USD','SPX','QA13',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA14','QA14 Security','NYSE','USD','SPX','QA14',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA15','QA15 Security','NYSE','USD','SPX','QA15',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA16','QA16 Security','NYSE','USD','SPX','QA16',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA17-1','QA17 Security','NYSE','USD','SPX','QA17',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA17-2','QA17 Security','NYSE','USD','SPX','QA17',-1
Insert into Securities2(ticker,company,cusip,sedol,cins,ric,isactive)
select 'QA17-3','QA17 Security','NYSE','USD','SPX','QA17',-1

--Insert Authors Data
insert into authors(name,last,first,phone,extemail,intemail,isanalyst,isactive,rdirectcode)
select 'QAFirstnameA QALastnameA','QALastnameA','QAFirstnameA','+1-212-969-1000','qaa@bernstein.com','cring',-1,-1,'BTA'
insert into authors(name,last,first,phone,extemail,intemail,isanalyst,isactive,rdirectcode)
select 'QAFirstnameB QALastnameB','QALastnameB','QAFirstnameB','+1-212-969-1000','qab@bernstein.com','cring',-1,-1,'BTA'
insert into authors(name,last,first,phone,extemail,intemail,isanalyst,isactive,rdirectcode)
select 'QAFirstnameC QALastnameC','QALastnameC','QAFirstnameC','+1-212-969-1000','qac@bernstein.com','cring',-1,-1,'BTA'
insert into authors(name,last,first,phone,extemail,intemail,isanalyst,isactive,rdirectcode)
select 'QAFirstnameD QALastnameD','QALastnameD','QAFirstnameD','+1-212-969-1000','qad@bernstein.com','cring',-1,-1,'BTA'
insert into authors(name,last,first,phone,extemail,intemail,isanalyst,isactive,rdirectcode)
select 'QAFirstnameE QALastnameE','QALastnameE','QAFirstnameE','+1-212-969-1000','qae@bernstein.com','cring',-1,-1,'BTA'
insert into authors(name,last,first,phone,extemail,intemail,isanalyst,isactive,rdirectcode)
select 'QAFirstnameF QALastnameF','QALastnameF','QAFirstnameF','+1-212-969-1000','qaf@bernstein.com','cring',-1,-1,'BTA'

--Insert Coverage Data
declare @industryid int
declare @analystid int
declare @securityid int

select @industryid = industryid from industries where industryname = 'QA Industry A'
select @analystid = authorid from authors where name like 'QAFirstnameA%'
select @securityid = securityid from securities2 where ticker = 'QA01'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry A'
select @analystid = authorid from authors where name like 'QAFirstnameA%'
select @securityid = securityid from securities2 where ticker = 'QA02'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry B'
select @analystid = authorid from authors where name like 'QAFirstnameB%'
select @securityid = securityid from securities2 where ticker = 'QA03'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry B'
select @analystid = authorid from authors where name like 'QAFirstnameB%'
select @securityid = securityid from securities2 where ticker = 'QA04'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry C'
select @analystid = authorid from authors where name like 'QAFirstnameC%'
select @securityid = securityid from securities2 where ticker = 'QA05'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry C'
select @analystid = authorid from authors where name like 'QAFirstnameC%'
select @securityid = securityid from securities2 where ticker = 'QA06'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry D'
select @analystid = authorid from authors where name like 'QAFirstnameD%'
select @securityid = securityid from securities2 where ticker = 'QA07'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry D'
select @analystid = authorid from authors where name like 'QAFirstnameD%'
select @securityid = securityid from securities2 where ticker = 'QA08'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry DE'
select @analystid = authorid from authors where name like 'QAFirstnameD%'
select @securityid = securityid from securities2 where ticker = 'QA09'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry DE'
select @analystid = authorid from authors where name like 'QAFirstnameD%'
select @securityid = securityid from securities2 where ticker = 'QA10'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry DE'
select @analystid = authorid from authors where name like 'QAFirstnameE%'
select @securityid = securityid from securities2 where ticker = 'QA11'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry DE'
select @analystid = authorid from authors where name like 'QAFirstnameE%'
select @securityid = securityid from securities2 where ticker = 'QA12'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry CF'
select @analystid = authorid from authors where name like 'QAFirstnameC%'
select @securityid = securityid from securities2 where ticker = 'QA13'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry CF'
select @analystid = authorid from authors where name like 'QAFirstnameC%'
select @securityid = securityid from securities2 where ticker = 'QA14'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry CF'
select @analystid = authorid from authors where name like 'QAFirstnameF%'
select @securityid = securityid from securities2 where ticker = 'QA15'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry CF'
select @analystid = authorid from authors where name like 'QAFirstnameF%'
select @securityid = securityid from securities2 where ticker = 'QA16'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry CF'
select @analystid = authorid from authors where name like 'QAFirstnameF%'
select @securityid = securityid from securities2 where ticker = 'QA17-1'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry CF'
select @analystid = authorid from authors where name like 'QAFirstnameF%'
select @securityid = securityid from securities2 where ticker = 'QA17-2'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()

select @industryid = industryid from industries where industryname = 'QA Industry CF'
select @analystid = authorid from authors where name like 'QAFirstnameF%'
select @securityid = securityid from securities2 where ticker = 'QA17-3'
insert into researchcoverage(industryid,analystid,securityid,launchdate,dropdate,active,editorid,editdate)
select @industryid,@analystid,@securityid,getdate(),null,0,1,getdate()
go
