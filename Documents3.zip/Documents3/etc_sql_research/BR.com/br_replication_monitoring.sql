
USE [Research]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--RVDummy Table to hold getdate() timestamp

/****** Object:  Table [dbo].[RVDummy]    Script Date: 01/23/2008 10:39:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RVDummy]') AND type in (N'U'))
DROP TABLE [dbo].[RVDummy]
GO
/****** Object:  Table [dbo].[RVDummy]    Script Date: 01/23/2008 10:39:40 ******/
CREATE TABLE [dbo].[RVDummy](
	[LastModified_Date] [datetime] NOT NULL,
	CONSTRAINT [PK_RVDummy] PRIMARY KEY CLUSTERED 
	(
		[LastModified_Date] ASC
	)
) 
GO

--spupdRVDummy Stored Procedure to update RVDummy table

/****** Object:  StoredProcedure [dbo].[spupdRVDummy]    Script Date: 01/23/2008 10:38:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spupdRVDummy]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spupdRVDummy]
GO
CREATE PROCEDURE [dbo].[spupdRVDummy]
as
Update dbo.RVDummy
Set	lastmodified_date = getdate()
GO

--vRowcount_sysarticles Database View

/****** Object:  View [dbo].[vRowcount_sysarticles]    Script Date: 01/23/2008 10:41:08 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vRowcount_sysarticles]'))
DROP VIEW [dbo].[vRowcount_sysarticles]
GO

Create View [dbo].[vRowcount_sysarticles]
AS
SELECT	o.name,
		rows, 
		getdate() as currentDateTime ,
		o.type
FROM 
		sysobjects o(nolock), 
		sysindexes i(nolock),
		sysarticles s (nolock)
WHERE 
		o.id=i.id AND 
		i.indid IN (0,1) AND
		s.objid = o.id
GO
EXEC sp_addlogin 'BRWEB', 'alliance1', 'RESEARCH'
GO

GRANT SELECT  on [dbo].[vRowcount_sysarticles] TO [BRWEB]
GO
