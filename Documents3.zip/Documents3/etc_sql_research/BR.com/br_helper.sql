-- br_helper.sql

select * from sysobjects where xtype = 'V' and name like 'RV%'

select 'select * into _' + name + ' from ' + name + ' where 1=2' 
from sysobjects where xtype = 'V' and name like 'RV%' order by name

-- br.com db table definitions are reverse engineered from RV views
/*
select * into _RVAnalysts from RVAnalysts where 1=2
select * into _RVDocAnalysts from RVDocAnalysts where 1=2
select * into _RVDocIndustries from RVDocIndustries where 1=2
select * into _RVDocKeywords from RVDocKeywords where 1=2
select * into _RVDocSecurities from RVDocSecurities where 1=2
select * into _RVDocuments from RVDocuments where 1=2
select * into _RVFinancials from RVFinancials where 1=2
select * into _RVIndustries from RVIndustries where 1=2
select * into _RVKeywords from RVKeywords where 1=2
select * into _RVProductGroupDocuments from RVProductGroupDocuments where 1=2
select * into _RVProductGroups from RVProductGroups where 1=2
select * into _RVResearchCoverage from RVResearchCoverage where 1=2
select * into _RVSectors from RVSectors where 1=2
select * into _RVSecurities from RVSecurities where 1=2
select * into _RVTypes from RVTypes where 1=2
*/

-- Home Page sample queries (11)
-- Morning Summary - Global
-- Morning Summary - Pan-Euro
-- Featured Reports - Best of Bernstein
-- Featured Reports - Blackbooks 
-- Featured Reports - Whitebooks
-- Featured Reports - Weekly Notes
-- Strategy / Quant - Quant Handbook
-- Strategy / Quant - Strat Monitor
-- Strategy / Quant - Applied Global Quantitative Strategy
-- Specialty Research - Big Thinking on Small Caps
-- Specialty Research - Long View

-- Landing Pages - Exclude compendium Blackbooks from appearing, i.e. The Best of Bernstein, The Long View
-- Industry Featured Reports - 
-- Analyst Featured Reports - 
-- Ticker Featured Reports - 

-- Product Types - No hard-coded references to values, only id's
select * from dbo.RVTypes      -- Static ID
select * from dbo.RVKeywords   -- Static ID  Keyword functions as Sub-Type
select * from dbo.RVIndustries -- Dynamic ID

-- Blackbooks - All
-- http://institutional.beehive.com/research/research.asp?type=Black%20Book&max=1000&pg=1&sz=1000
select *
from RVDocuments
where DocTypeId = 3
order by Date desc

-- Blackbooks - Bernstein Quantitative Handbook
-- http://institutional.beehive.com/research/research.asp?keywords=Bernstein%20Quantitative%20Handbook&max=1000&pg=1&sz=1000
select *
from RVDocuments RVD
join RVDocKeywords RVDK on RVDK.DocId = RVD.DocId
where RVD.DocTypeId = 3 and RVDK.KeywordId = 3 -- 'Bernstein Quantitative Handbook'
order by Date desc

-- Blackbooks - Bernstein Disciplined-Strategies Monitor
-- http://institutional.beehive.com/research/research.asp?keywords=Bernstein%20Disciplined-Strategies%20Monitor&max=1000&pg=1&sz=1000
select *
from RVDocuments RVD
join RVDocKeywords RVDK on RVDK.DocId = RVD.DocId
where RVD.DocTypeId = 3 and RVDK.KeywordId = 2 -- 'Bernstein Disciplined-Strategies Monitor'
order by Date desc

-- Blackbooks - Applied Global Quantitative Strategy
-- http://institutional.beehive.com/research/research.asp?keywords=Applied%20Global%20Quantitative%20Strategy&max=1000&pg=1&sz=1000
select *
from RVDocuments RVD
join RVDocKeywords RVDK on RVDK.DocId = RVD.DocId
where RVD.DocTypeId = 3 and RVDK.KeywordId = 8 -- 'Applied Global Quantitative Strategy%'
order by Date desc

-- Blackbooks - Best of Bernstein (Quarterly)
-- http://institutional.beehive.com/research/research.asp?keywords=The%20Best%20of%20Bernstein&max=1000&pg=1&sz=1000
select *
from RVDocuments RVD
join RVDocKeywords RVDK on RVDK.DocId = RVD.DocId
where RVD.DocTypeId = 3 and RVDK.KeywordId = 5 -- 'The Best of Bernstein'
order by Date desc

-- Whitebooks - All
-- http://institutional.beehive.com/research/research.asp?type=White%20Book&max=1000&pg=1&sz=1000
select *
from RVDocuments
where DocTypeId = 6
order by Date desc

-- Notes - All
-- http://institutional.beehive.com/research/research.asp?type=Research%20Note&max=1000&pg=1&sz=1000
select *
from RVDocuments
where DocTypeId = 2
order by Date desc

-- Notes - The Long View - All
-- http://institutional.beehive.com/research/research.asp?keywords=Long%20View&max=1000&pg=1&sz=1000
select *
from RVDocuments RVD
join RVDocKeywords RVDK on RVDK.DocId = RVD.DocId
where RVD.DocTypeId = 2 and RVDK.KeywordId = 1 -- 'Long View'
order by Date desc

-- 11/20/2008
select *
from RVDocuments RVD
join RVDocKeywords RVDK on RVDK.DocId = RVD.DocId
where RVDK.KeywordId = 1 -- 'Long View'
order by Date desc

-- Summary - Morning Summary: Global Edition - Current
-- http://institutional.beehive.com/research/research.asp?type=Research%20Summary&title=Morning%20Summary%3A%20Global%20Edition&max=1000&pg=1&sz=1000
select top 1 *
from RVDocuments RVD
join RVDocKeywords RVDK on RVDK.DocId = RVD.DocId
where RVD.DocTypeId = 5 and RVDK.KeywordId = 6 -- 'Morning Summary: Global Edition'
order by Date desc

-- Summary - Morning Summary: Pan-European Edition - Current
-- http://institutional.beehive.com/research/research.asp?type=Research%20Summary&title=Morning%20Summary%3A%20Pan-European%20Edition&max=1000&pg=1&sz=1000
select top 1 *
from RVDocuments RVD
join RVDocKeywords RVDK on RVDK.DocId = RVD.DocId
where RVD.DocTypeId = 5 and RVDK.KeywordId = 7 -- 'Morning Summary: Pan-European Edition'
order by Date desc

-- Call - Specialty Call: Big Thinking on Small Caps (Weekly - Call/Note)
-- http://institutional.beehive.com/research/research.asp?industry=Small-Cap%20Strategy&max=1000&pg=1&sz=1000
select *
from RVDocuments RVD
join RVDocIndustries RVDI on RVDI.DocId = RVD.DocId
where RVD.DocTypeId = 1 and RVDI.Industry = 'Small-Cap Strategy'
order by Date desc

-- Global Quantitative Strategy Services - Screens and Portfolios
-- http://institutional.beehive.com/research/research.asp?type=Research%20Call&title=Global%20Quantitative%20Strategy%20Services%20&max=1000&pg=1&sz=1000

-- Technology Sector Strategy
-- http://institutional.beehive.com/research/research.asp?industry=Global%20Technology%20Strategy&type=Research%20Call&title=Technology%20Sector%20Strategy&max=1000&pg=1&sz=1000

-- Financials
select * from RVFinancials where Currency = '' order by Date desc

-- Financials: All tickers and dates
select * from RVFinancials order by Ticker, Date, DocId

-- Financials: All tickers for latest dates
select
  RVF.*
from
  RVFinancials RVF
join
--  (SELECT Ticker, Date = MAX(Date), DocId = MAX(DocId) FROM RVFinancials GROUP BY Ticker) V ON V.Ticker = RVF.Ticker AND V.DocId = RVF.DocId
  (SELECT Ticker, DocId = MAX(DocId) FROM RVFinancials GROUP BY Ticker) V ON V.Ticker = RVF.Ticker AND V.DocId = RVF.DocId
order by RVF.Ticker

-- 08/15/2007 - Krishna correctly demonstrated that the MAX(Date) has no impact and should be removed

-- Verify number of tickers under coverage
-- select * from RVResearchCoverage where LaunchDate is not null and DropDate is null and SecurityID is not null
-- select * from ResearchCoverage where LaunchDate is not null and DropDate is null and SecurityID is not null

sp_helptext RVResearchCoverage -- Need to eliminate where clause on RVResearchCoverage
go

sp_helptext RVDocuments
go

--
SELECT k.propvalue keyword,p.pubno,date,title,count(distinct au.propvalue) author_count,count(distinct ind.propvalue) industry_count,count(distinct sec.propvalue) ticker_count
FROM 
publications p JOIN properties au on p.pubno = au.pubno and au.propid = 5
LEFT OUTER JOIN authors a on au.propvalue = a.name and a.isanalyst = -1
JOIN properties ind on p.pubno = ind.pubno and ind.propid = 11
LEFT OUTER JOIN properties sec on p.pubno = sec.pubno and sec.propid = 13
LEFT OUTER JOIN properties k on p.pubno = k.pubno and k.propid = 9
WHERE
p.type = 'Black book'
and date >= '01/01/2006'
GROUP BY k.propvalue,p.pubno,date,title
--ORDER BY date desc, p.pubno desc
ORDER BY k.propvalue,title,date desc

drop table #tmp

--
SELECT k.propvalue keyword,p.pubno,date,title,count(distinct au.propvalue) author_count,count(distinct ind.propvalue) industry_count,count(distinct sec.propvalue) ticker_count,min(au.propno) primary_author,min(ind.propno) primary_industry,min(sec.propno) primary_ticker
INTO #TMP
FROM 
publications p JOIN properties au on p.pubno = au.pubno and au.propid = 5
JOIN  authors a on au.propvalue = a.name 
LEFT OUTER JOIN  properties ind on p.pubno = ind.pubno and ind.propid = 11
LEFT OUTER JOIN  properties sec on p.pubno = sec.pubno and sec.propid = 13
LEFT OUTER JOIN  properties k on p.pubno = k.pubno and k.propid = 9
WHERE
 p.type = 'Black book' AND
 a.isanalyst = -1
and date >= '01/01/2006'
GROUP BY k.propvalue,p.pubno,date,title
ORDER BY k.propvalue,title,date desc
 

SELECT keyword,t.pubno,date,title,author_count, au.propvalue primary_author,industry_count,ind.propvalue primary_industyr,ticker_count,sec.propvalue primary_ticker
FROM
#tmp t LEFT OUTER JOIN properties au on t.primary_author = au.propno
LEFT OUTER JOIN properties ind on t.primary_industry = ind.propno
LEFT OUTER JOIN properties sec on t.primary_ticker = sec.propno
ORDER BY keyword,title,date desc

-- 11/20/2008 - Analysis of br.com after dropping Notes product and Small-Cap Strategy coverage.
select 
  P.PubNo,
  P.Date,
  P.Type,
  convert(varchar(40), Title),
  'Industry' = convert(varchar(40), PR.PropValue)
from Publications P
join Properties PR on PR.PubNo = P.PubNo and PR.PropID = 11 -- Industry
where Title like '%Big Think%'
order by P.Date desc
