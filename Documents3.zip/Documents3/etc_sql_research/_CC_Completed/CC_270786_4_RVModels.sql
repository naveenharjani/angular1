-- CC_RVModels.sql
-- 11/09/2017

/*

Research
========
RVModels
ProductGroupModels
RVProductGroupModels
ContentTypes
RVContentTypes
LinkStatus               
RVLinkStatus             
RVSecurities

BR.com - Database required
======
spValidateUser
spGetFileName

CRM - Database preferred
===
alter SVContacts - Add Tier
SVLinksContacts
ContentUsage
spCheckContentAccess
spLogContentUsage

*/

USE Research
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where name like '%RVModels%')
drop view dbo.RVModels
go

create view dbo.RVModels with schemabinding as
select
  ModelId,
  M.CoverageId,
  M.SecurityId,
  S.Ticker,
  Company,
  M.AnalystId,
  A.Last + ', ' + A.First Analyst,
  M.FileName,
  M.FileSize,
  M.ActionId,
  MA.Action,
  M.StateId,
  MS.State,
  M.PubNo,
  M.EditDate ModelDate
from dbo.Models M
join dbo.ResearchCoverage RC on M.CoverageId = RC.CoverageId
join dbo.Securities2 S on M.SecurityId = S.SecurityId
join dbo.Authors A on M.AnalystId = A.AuthorId
join dbo.ModelActions MA on M.ActionId = MA.ActionId
join dbo.ModelStates MS on M.StateId = MS.StateId
where RC.LaunchDate is not null and RC.DropDate is null
and RC.ModelDistribution = 'Y'
and M.StateId in (1, 2) -- Active, Archived
go

create unique clustered index [RVModels_ModelId] ON [dbo].[RVModels]
(
  [ModelId] ASC
)
go

if exists(select * from sys.objects where name like '%RVProductGroupModels%')
drop view dbo.RVProductGroupModels
go

if exists(select * from sys.objects where name = 'ProductGroupModels')
drop table dbo.ProductGroupModels
go

create table dbo.ProductGroupModels
(
  ProductGroupId int not null,
  SecurityId     int not null
)
go

create view dbo.RVProductGroupModels with schemabinding as
select
  PGM.ProductGroupId,
  PGM.SecurityId
from
  dbo.ProductGroupModels PGM join dbo.ResearchCoverage RC on PGM.SecurityId = RC.SecurityId
where
  RC.LaunchDate is not null and RC.DropDate is null
go

create unique clustered index [RVProductGroupModels_SecurityId] ON [dbo].[RVProductGroupModels]
(
  [SecurityId],[ProductGroupId]
)
go

/*
--Populate ProductGroupModels table based on ticker region only for primary tickers
delete from ProductGroupModels
go

insert into ProductGroupModels(SecurityId, ProductGroupId)
select S.SecurityId,PGF.ProductGroupId
from ProductGroupFields PGF join Industries I on PGF.FieldValue = I.IndustryId
join ResearchCoverage RC on I.IndustryId  = RC.IndustryId
join Securities2 S on RC.SecurityId = S.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null
and RC.ModelDistribution = 'Y'
and S.IsPrimary = 'Y'
union
select S.SecurityId,PGF.ProductGroupId
from ProductGroupFields PGF join Authors A on PGF.FieldValue = A.AuthorId
join ResearchCoverage RC on A.AuthorId = RC.AnalystId
join Securities2 S on RC.SecurityId = S.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null
and RC.ModelDistribution = 'Y'
and S.IsPrimary = 'Y'
union
select S.SecurityId,PGF.ProductGroupId
from ProductGroupFields PGF join Securities2 S on PGF.FieldValue = S.SecurityId
join ResearchCoverage RC on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null
and RC.ModelDistribution = 'Y'
and S.IsPrimary = 'Y'
go
*/

go

if exists(select * from sys.objects where name like '%RVContentTypes%')
drop view dbo.RVContentTypes
go

if exists(select * from sys.objects where name = 'ContentTypes')
drop table ContentTypes
go

create table dbo.ContentTypes
(
  ContentTypeId int         NOT NULL,
  ContentType   varchar(50) NOT NULL,
  EditorId      int         NOT NULL,
  EditDate      datetime    NOT NULL,
)

alter table [dbo].[ContentTypes] add constraint [PK_ContentTypes] primary key clustered([ContentTypeId] ASC)
go

/*

insert into dbo.ContentTypes(ContentTypeId,ContentType,EditorId,EditDate) select 1,'Research',1126,getdate()
insert into dbo.ContentTypes(ContentTypeId,ContentType,EditorId,EditDate) select 2,'Model',1126,getdate()

*/

create view dbo.RVContentTypes with schemabinding as
select
  ContentTypeId,
  ContentType
from
  dbo.ContentTypes
go

create unique clustered index [RVContentTypes_ContentTypeId] ON [dbo].[RVContentTypes]
(
  [ContentTypeId]
)
go

if exists(select * from sys.objects where name like '%RVLinkStatus%')
drop view dbo.RVLinkStatus
go
if exists(select * from sys.objects where name = 'LinkStatus')
drop table LinkStatus
go

create table dbo.LinkStatus
(
  StatusId int         NOT NULL,
  Status   varchar(50) NOT NULL,
  EditorId int         NOT NULL,
  EditDate datetime    NOT NULL,
)
alter table [dbo].[LinkStatus] add constraint [PK_LinkStatus] primary key clustered([StatusId] ASC)
go

create view dbo.RVLinkStatus with schemabinding as
select
  StatusId,
  Status
from
  dbo.LinkStatus
go


create unique clustered index [RVLinkStatus_StatusId] ON [dbo].[RVLinkStatus]
(
  [StatusId]
)
go
/*

insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 10, 'Site unavailable',1126,getdate()
insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 11, 'Invalid Login Id',1126,getdate()
insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 12, 'Invalid Password',1126,getdate()
insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 13, 'User in active in CRM',1126,getdate()

insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 21, 'User not entitled',1126,getdate()
insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 22, 'Quota exceeded',1126,getdate()

insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 31, 'No row in RVModels table',1126,getdate()
insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 32, 'File not available',1126,getdate()
insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 33, 'Error streaming file',1126,getdate()

insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 41,'Canceled login',1126,getdate()
insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 42,'Exceeded login attempts.  Account locked',1126,getdate()

insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 100, 'File streaming successful',1126,getdate()
insert into dbo.LinkStatus(StatusId,Status,EditorId,EditDate) select 101, 'File streaming successful with CRM down',1126,getdate()

*/

--RVSecurities altered to add CompanyId, IsPrimary, OrdNo columns
if exists(select * from sys.objects where name like '%RVSecurities%')
drop view dbo.RVSecurities
go

create view [dbo].[RVSecurities] WITH SCHEMABINDING AS
select
  SecurityId,
  Ticker,
  RIC,
  Company,
  CompanyId,
  IsPrimary,
  OrdNo,
  Cusip,
  Sedol,
  Isin,
  Status,                  -- iPad app Watch List - Picklist displays active coverage where Status is 1
  RefreshDate = EditDate,  -- iPad app Watch List - Refresh (additions, subtractions, modifications) when RefreshDate > WL RefreshDate
  GoUrl
from
  dbo.Securities2
where
  TickerType = 'STOCK'
go

create unique clustered index [RVSecurities_SecurityId] ON [dbo].[RVSecurities]
(
  [SecurityId] ASC
)
GO

-- *****
-- ***** BR.com
-- *****

/*

create proc dbo.spValidateUser @ContactId
as
begin
--step 1:
--check for user existence & active status(BRWebUsers/SVContacts table or BRLinkUsers/SVContacts table)
--if exists continue else return 10

--step 2:
--check for password, if correct return 0 else return 20

end


create proc dbo.spGetFileName @ContentType, @ContentId
as
begin
--step 1:
--Dereference filename from ContentId
--Check if file exists, if exists return filename with path
--If file does not exist return 50
end

*/

-- *****
-- ***** CRM
-- *****
/*
create table dbo.ContentUsage
(
  UsageId             int identity(1, 1),
  LogonId             varchar(100),
  ContentType         varchar(10), -- M, R
  ContentId           int,
  AuthenticationCheck int,
  EntitlementCheck    int,
  QuotaCheck          int,
  LinkSourceId        int,
  AccessDate          datetime,
  LogDate             datetime,
  Status              int,
  ContactId           varchar(20),
  EncryptedPayload    varchar(100),
  DecryptedPayload    varchar(100),
  SourceInternal      varchar(1),
  ContentSource       varchar(50),
  ServerName          varchar(20),
  UserHost            varchar(20),
  UserAgent           varchar(300)
)
go

create proc dbo.spCheckContentAccess
  @ContactId varchar(10),
  @ContentTypeId int,
  @ContentId int,
  @QuotaFlag char(1) -- Y or N
as
begin

/*

-- Checks both entitlements and quota
-- returns:
--  0 for access and non-zero for no access
--  rowset with quota info


if ContentTypeId = 1 -- Research
{

  -- Check product group access
  if exists
    select * from SVContactProductGroups where ContactId = @ContactId and ProductGroupId in
    (select ProductGroupId from ProductGroupDocuments where DocId = @ContentId)
  else return 30

  -- check quota
  if success (TBD)
    return 0
  else
    return 40

}

if ContentTypeId = 2 -- Models
{

  -- Check general model access
  if Tier = 6 then return 30

  -- Check product group access
  if exists
    select * from SVContactProductGroups where ContactId = @ContactId and ProductGroupId in
    (select ProductGroupId from RVProductGroupModels where SecurityId = @ContentId)
  else return 30

}


*/

end
go

create proc dbo.spLogContentUsage @payloadxml
as
begin

--step-1:
--insert every click along with status to new ContentUsage table

end
go


*/

/*

-- DEBUG

select * from ModelStates

select * from RVModels

select * from ContentUsage

select * from LinkStatus

select * from ProductGroupModels

select * from RVProductGroupModels

*/
*/