-- GICHistory_Rollback.sql
-- 10/31/2017

/*

spRptGICRatingsHistory
spRptGICTargetPriceHistory

*/

USE [Research]
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spRptGICRatingsHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spRptGICRatingsHistory]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spRptGICTargetPriceHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spRptGICTargetPriceHistory]
GO