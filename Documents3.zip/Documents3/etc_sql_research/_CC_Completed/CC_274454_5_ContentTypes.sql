-- CC_ContentTypes.sql
-- 02/26/2018

USE Research
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where name like '%RVContentTypes%')
drop view dbo.RVContentTypes
go

if exists(select * from sys.objects where name = 'ContentTypes')
drop table ContentTypes
go

create table dbo.ContentTypes
(
  ContentTypeId char(1)     NOT NULL,
  ContentType   varchar(50) NOT NULL,
  EditorId      int         NOT NULL,
  EditDate      datetime    NOT NULL,
)

alter table [dbo].[ContentTypes] add constraint [PK_ContentTypes] primary key clustered([ContentTypeId] ASC)
go

/*

insert into dbo.ContentTypes(ContentTypeId,ContentType,EditorId,EditDate) select 'R','Research',1126,getdate()
insert into dbo.ContentTypes(ContentTypeId,ContentType,EditorId,EditDate) select 'M','Model',1126,getdate()

*/

create view dbo.RVContentTypes with schemabinding as
select
  ContentTypeId,
  ContentType
from
  dbo.ContentTypes
go

create unique clustered index [RVContentTypes_ContentTypeId] ON [dbo].[RVContentTypes]
(
  [ContentTypeId]
)
go