-- CC_TickerTable_Rollback.sql
-- 04/23/2019

/*

alter spGetCompanySecurities

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spGetCompanySecurities]
  @Style int,
  @CompanyId int = NULL,
  @AnalystId int = NULL,
  @Ticker varchar(15) = NULL,
  @UserId int = NULL
AS

/*
Styles
1 - All securities - By specified company (Security Administration)
2 - Launched and unlaunched securities - By all companies or specified company (Estimate Set Administration)
3 -
4 - Launched and unlaunched securities - By all analysts (not practical) or specified analyst
5 - Launched and unlaunched securities - By Ticker (based on parent Company)
6 - Launched and unlaunched (visibility restrictions) securities - By all analysts (not practical) or specified analyst
*/

SET NOCOUNT ON

-- All securities - By specified company
IF @Style = 1
BEGIN

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo
FROM Securities2 S
JOIN Companies C ON C.CompanyId = S.CompanyId
WHERE S.CompanyId = @CompanyId
ORDER BY S.IsPrimary DESC, S.OrdNo

END

-- Launched and unlaunched securities - By all companies or specified company
ELSE IF @Style = 2
BEGIN

DECLARE @Companies TABLE (CompanyId int)
IF ISNULL(@CompanyId, '') = ''
BEGIN
  INSERT @Companies
    SELECT C.CompanyId
    FROM ResearchCoverage RC
    JOIN Securities2 S on S.SecurityId = RC.SecurityId
    JOIN Companies C on C.CompanyId = S.CompanyId
    WHERE RC.DropDate IS NULL
END
ELSE
  INSERT @Companies SELECT @CompanyId

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.AnalystId, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN Companies C ON C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL
AND S.CompanyId IN (SELECT CompanyId FROM @Companies)
ORDER BY C.Company, S.IsPrimary DESC, S.OrdNo

END

-- Launched and unlaunched securities - By all analysts (not practical) or specified analyst
ELSE IF @Style = 4
BEGIN

DECLARE @Analysts TABLE (AnalystId int)
IF ISNULL(@AnalystId, '') = ''
  INSERT @Analysts SELECT AuthorId FROM Authors WHERE IsAnalyst = -1 AND IsActive = -1
ELSE
  INSERT @Analysts SELECT @AnalystId

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
JOIN Companies C on C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)
ORDER BY C.Company, S.OrdNo

END

-- Launched and unlaunched securities - By Ticker (based on parent Company)
ELSE IF @Style = 5
BEGIN

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.AnalystId, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN Companies C ON C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL
AND S.CompanyId IN (SELECT CompanyId FROM Securities2 WHERE Ticker = @Ticker)
ORDER BY C.Company, S.IsPrimary DESC, S.OrdNo

END

-- Launched and unlaunched (visibility restrictions) securities - By all analysts (not practical) or specified analyst
ELSE IF @Style = 6
BEGIN

IF ISNULL(@AnalystId, '') = ''
  INSERT @Analysts SELECT AuthorId FROM Authors WHERE IsAnalyst = -1 AND IsActive = -1
ELSE
  INSERT @Analysts SELECT @AnalystId

DECLARE @ShowUnlaunched CHAR(1)

-- Admin or Manager role
IF EXISTS(SELECT * FROM UserRoles WHERE RoleId IN (1, 2) AND UserId = @UserId)
  SET @ShowUnlaunched = 'Y'

-- Launched tickers (visible to all)
SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
JOIN Companies C on C.CompanyId = S.CompanyId
WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)

UNION

-- Unlaunched tickers (visible to Team Members, Admins, Managers)
SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
JOIN Companies C on C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL AND RC.LaunchDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)
AND (
      RC.AnalystId = @UserId
      OR
      RC.AnalystId IN (SELECT AnalystId FROM AnalystTeamMembers WHERE UserId = @UserId)
      OR
      @ShowUnlaunched = 'Y' -- Authorized roles only
     )

ORDER BY C.Company, S.OrdNo

END

SET NOCOUNT OFF

GO
