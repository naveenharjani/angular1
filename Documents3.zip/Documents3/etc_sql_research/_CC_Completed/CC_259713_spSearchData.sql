USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- =================================================================================================
-- Author:       Sandarsh M S
-- Revisions:    08/04/2016 - Created
--         08/29/2017 - Added filter to remove unlaunched tickers which were not covered previously.
-- Description:  Get Typeahead data for a given @SearchText
-- =================================================================================================
alter procedure [dbo].[spSearchData]
  @Style int,
  @UserId int,
  @SearchText nvarchar(200),
  @SearchTextComp nvarchar(200)

as
begin
Set @SearchText = '%'+ @SearchText+'%'
Set @SearchTextComp = '%'+ @SearchText+'%'

declare @Analyst table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL,
  Header int NULL
 )

insert into @Analyst
select top 10
  Name as Label,
  Name as Ticker,
  'Analyst' as Groups,
  Row_Number() OVER (ORDER BY [Name]) +3  AS Header
from Authors where IsAnalyst = -1 and (First like @SearchText or Last like @SearchText or [Name] like @SearchText)
AND AuthorId in (select  Distinct AnalystID from ResearchCoverage) order by [Name]

declare @Ticker table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL
 )

insert into @Ticker
select distinct top (26 - (select Count(*) from @Analyst))
  Ticker + ' / ' + Company as Label,
  Ticker,
  'Research' as Groups
from Securities2 S
join ResearchCoverage RC on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null
and (Ticker like @SearchText or  Company like @SearchTextComp)
order by Ticker + ' / ' + Company

declare @Financials table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL
 )

insert into @Financials
select
  S.Ticker + ' / ' +  S.Company as Label,
  Ticker,
  'Financials' as Groups
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null AND RC.DropDate IS NULL and s.Ticker = (select top 1 Ticker from @Ticker)
and RC.AnalystId in (select AuthorId from Authors where IsAnalyst = -1 AND IsActive = -1)
order by S.Ticker + ' / ' + S.Company

--DECLARE @Charts TABLE
--(
--  Label  varchar(100) NULL,
--  Ticker varchar(50) NULL,
--  Groups varchar(50) NULL
-- )

-- INSERT INTO @Charts
-- Select
--  S.Ticker + ' / ' +  S.Company as Label,Ticker,'Charts' as Groups
--FROM ResearchCoverage RC
--JOIN Securities2 S on S.SecurityId = RC.SecurityId
--WHERE  S.Ticker = (Select top 1 Ticker from @Ticker) AND RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
--order by S.Ticker + ' / ' + S.Company

select *, ROW_NUMBER() over(partition by Ticker
order by Groups desc) AS Header
from (
select * from @Ticker
union
select * from @Financials
--union
--select * from @Charts
) as uni
union All
select * from @Analyst
End

