-- SaveAsLive.sql
-- 05/08/2017

--spSaveEstimatesAsLive

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE name = 'spSaveEstimatesAsLive' and TYPE = 'p')
DROP Procedure dbo.spSaveEstimatesAsLive
GO

CREATE PROCEDURE [dbo].[spSaveEstimatesAsLive]
  @FinancialNumberXml text,
  @Source             varchar(30)
AS
BEGIN
SET NOCOUNT ON

DECLARE @hDoc        int

DECLARE
  @SecurityId             int,
  @BaseYear               varchar(30),
  @UserName               varchar(30),
  @UserId                 int,
  @CoverageId             int,
  @ModelUnits             bigint,
  @AffectedValues         int,
  @EditDate               datetime,
  @FinancialNumberLogId   int,
  @IsBatchStart           int

SELECT @EditDate = GETDATE(), @AffectedValues = 0

EXEC sp_xml_preparedocument @hDoc OUTPUT, @FinancialNumberXml

SELECT
  @SecurityId = CONVERT(int,SecurityId),
  @BaseYear= BaseYear,
  @UserName = UserName,
  @CoverageId = CONVERT(int,CoverageId),
  @IsBatchStart = IsBatchStart
FROM OPENXML (@hDoc, '/Security', 1)
WITH(SecurityId varchar(10) '@id',
     BaseYear varchar(10) '@baseYear',
     UserName varchar(30) '@userName',
     CoverageId varchar(10) '@coverageId',
     IsBatchStart int      '@isBatchStart')

IF @IsBatchStart is null SET @IsBatchStart = 1
--Ticker model units
SELECT @ModelUnits = UnitMultiplier FROM FinancialSecuritySettings WHERE SecurityId = @SecurityId
SELECT top 1 @UserId = UserId FROM Users WHERE UserName like '%' + @UserName + '%'
SET @FinancialNumberLogId = 0

SELECT S.FinancialNumberTypeCat,S.FinancialNumberTypeId,S.FinancialPeriodId,FP.FinancialPeriod,S.PeriodYear,S.IsDraft,S.UnitValue,S.CurCode,FN.IsPerShare,FN.IsPercent,FN.Format,FN.UnitMultiplier
INTO #FinancialNumbersData
FROM OPENXML (@hDoc, '/Security/FinancialNumberType', 1)
WITH (FinancialNumberTypeCat    char(1)     '@type',
      FinancialNumberTypeId     varchar(30) '@id',
      FinancialPeriodId         varchar(30) '@periodId',
      PeriodYear                varchar(30) '@periodYear',
      IsDraft                   varchar(1)  '@isDraft',
      UnitValue                 varchar(30) '@value',
      CurCode                   varchar(3)  '@currency'
      ) S JOIN FinancialNumberTypes FN ON S.FinancialNumberTypeId = FN.FinancialNumberTypeId
      LEFT JOIN FinancialPeriods FP ON S.FinancialPeriodId = FP.FinancialPeriodId

--Business Rules
--#1: If unlaunched analyst, all the estimates including rating and target price are treated as draft values
IF (SELECT LaunchDate FROM ResearchCoverage WHERE CoverageId = @CoverageId) IS NULL
BEGIN
  UPDATE #FinancialNumbersData
  SET IsDraft = 1
END

--Proceed if launched analyst
IF EXISTS(SELECT * FROM ResearchCoverage WHERE CoverageId = @CoverageId AND LaunchDate IS NOT NULL)
BEGIN
  IF EXISTS(SELECT * FROM #FinancialNumbersData WHERE FinancialNumberTypeCat in ('E','A'))
  BEGIN
    INSERT INTO dbo.FinancialNumbersLog(SecurityId,EditorId,EditDate)
    SELECT @SecurityId,@UserId,@EditDate

    SELECT @FinancialNumberLogId = @@IDENTITY
  END

  INSERT INTO FinancialNumbers(
    SecurityId,
    FinancialNumberTypeId,
    FinancialPeriodId,
    BaseYear,
    PeriodYear,
    Date,
    Value,
    UnitValue,
    UnitMultiplier,
    CurCode,
    IsDraft,
    IsEstimate,
    CoverageId,
    Source,
    EditorId,
    EditDate)
  SELECT
    @SecurityId,
    FD.FinancialNumberTypeId,
    FD.FinancialPeriodId,
    @BaseYear,
    FD.PeriodYear,
    @EditDate,
    CASE WHEN IsNumeric(UnitValue) = 0 THEN UnitValue WHEN (IsNumeric(UnitValue) = 1 AND ((IsPerShare = 1) OR (IsPercent = 1))) THEN UnitValue ELSE CONVERT(varchar,CAST(UnitValue as numeric(18,2)) * @ModelUnits) END AS Value,
    UnitValue,
    CASE WHEN FD.IsPerShare = 1 or FD.IsPercent = 1 THEN 1 WHEN FD.IsPerShare = 0 THEN @ModelUnits ELSE null END,
    CurCode,
    IsDraft,
    CASE WHEN FinancialPeriod LIKE 'FY0%' THEN 0 ELSE 1 END,
    @CoverageId,
    @Source,
    @UserId,
    @EditDate
  FROM #FinancialNumbersData FD

  SET @AffectedValues = @AffectedValues + @@ROWCOUNT

  --insert data into log table
  INSERT INTO dbo.FinancialNumbersLogDetails(FinancialNumbersLogId,FinancialNumberId,SecurityId,FinancialNumberTypeId,FinancialPeriodId,PeriodYear,BaseYear,Date,Value,OldValue,Operation,CurCode,IsDraft,PubNo,CoverageId,Source,EditorId,EditDate)
  SELECT @FinancialNumberLogId,FinancialNumberId,@SecurityId,FN.FinancialNumberTypeId,FN.FinancialPeriodId,FN.PeriodYear,@BaseYear,@EditDate,FN.UnitValue,NULL,'I',FN.CurCode,FN.IsDraft,null,@CoverageId,FN.Source,@UserId,@EditDate
  FROM #FinancialNumbersData FD
  JOIN vFinancialNumbersLatest FN ON FN.FinancialNumberTypeId = FD.FinancialNumberTypeId AND ISNULL(FN.FinancialPeriodId,0) = ISNULL(FD.FinancialPeriodId,0) and FN.IsDraft = FD.IsDraft
  WHERE FN.SecurityId = @SecurityId

  UPDATE dbo.FinancialNumbersLog SET AffectedRows = @AffectedValues WHERE FinancialNumbersLogId = @FinancialNumberLogId
  SELECT @AffectedValues AS AffectedValues
END

SET NOCOUNT OFF
END
GO

GRANT EXECUTE ON dbo.spSaveEstimatesAsLive TO DE_IIS,PowerUsers
GO

/*
spSaveFinancialNumbersAsLive '<Security filePath="C:\Krishna\MultiRatingCompanies.xlsx" isBatchStart="1" coverageId="1197" userName="kjosyu" baseYear="2015" name="STAN.LN" id="927">
<FinancialNumberType id="1" currency="USD" value="O" isDraft="0" periodYear="2016" periodId="2" type="A"/>
<FinancialNumberType id="2" currency="USD" value="845.00" isDraft="0" periodYear="2016" periodId="2" type="A"/>
<FinancialNumberType id="4" currency="USD" value="0.2500" isDraft="0" periodYear="2016" periodId="2" type="E"/>
<FinancialNumberType id="4" currency="USD" value="1.2500" isDraft="0" periodYear="2017" periodId="3" type="E"/>
<FinancialNumberType id="4" currency="USD" value="1.0600" isDraft="0" periodYear="2018" periodId="4" type="E"/>
</Security>','Excel'

select * from FinancialNumbersLogDetails
where FinancialNumbersLogId in
  (select top 1 FinancialNumbersLogId from FinancialNumbersLog
  order by FinancialNumbersLogId desc)

*/



