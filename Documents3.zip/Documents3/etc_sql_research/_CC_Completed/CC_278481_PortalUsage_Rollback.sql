-- PortalUsage_Rollback.sql
-- 04/13/2017

/*

PortalUsageStaging_RSRCHX
spResetPortalUsageStaging_RSRCHX
spLoadPortalUsageFromStaging_RSRCHX

PortalUsageStaging_RedDeer
spResetPortalUsageStaging_RedDeer
spLoadPortalUsageFromStaging_RedDeer

spGetPortals -- used by UI

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_RSRCHX]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_RSRCHX]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_RedDeer]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_RedDeer]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_RSRCHX]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spResetPortalUsageStaging_RSRCHX]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_RedDeer]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spResetPortalUsageStaging_RedDeer]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_RSRCHX]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RSRCHX]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_RedDeer]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RedDeer]
GO

ALTER PROCEDURE [dbo].[spGetPortals]
AS

SELECT SiteId, Site FROM DistributionSites WHERE SiteId IN (3, 9, 11, 12, 20)

GO