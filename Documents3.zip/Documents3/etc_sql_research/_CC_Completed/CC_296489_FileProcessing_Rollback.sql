-- FileProcessing_Rollback.sql
-- 11/16/2018

/*

drop FileProcessingConfig
drop FileProcessingLog table
drop spGetFileProcessingConfig
drop spAddFileProcessingLog

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FileProcessingConfig]') AND type in (N'U'))
	DROP TABLE [dbo].[FileProcessingConfig]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FileProcessingLog]') AND type in (N'U'))
	DROP TABLE [dbo].[FileProcessingLog]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetFileProcessingConfig]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetFileProcessingConfig]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spAddFileProcessingLog]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spAddFileProcessingLog]
GO