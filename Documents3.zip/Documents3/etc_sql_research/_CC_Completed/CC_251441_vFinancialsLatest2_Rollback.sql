-- CC_vFinancials2_Rollback.sql
--05/15/2017

/*

alter vFinancialsLatest2

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO




ALTER VIEW [dbo].[vFinancialsLatest2]
AS
SELECT
  VF.SecurityID,
  VF.Ticker,
  VF.Date,
  VF.PubNo,
  VF.CoverageAction,
  -- Rating
  VF.Rating,
  VF.RatingAction,
  -- Target Price
  VF.TargetPrice,
  VF.TargetPriceAction,
  --
  VF.LastYear,
  VF.ThisYear,
  VF.NextYear,
  -- EPS
  VF.EPSType,
  VF.EPSLastYear,
  VF.EPSThisYear,
  VF.EstimateAction,
  VF.EPSNextYear,
  VF.EstimateNextYearAction,
  -- Metric
  VF.MetricType,
  'MetricLastYear' = (SELECT MAX(Value) FROM vValuationsLatest WHERE Securityid = S.SecurityId AND FinancialNumberTypeId = FCS.TickerTableValuationId AND IsDraft = 0 AND FinancialPeriodId = 1),
  'MetricThisYear' = (SELECT MAX(Value) FROM vValuationsLatest WHERE Securityid = S.SecurityId AND FinancialNumberTypeId = FCS.TickerTableValuationId AND IsDraft = 0 AND FinancialPeriodId = 2),
  'MetricNextYear' = (SELECT MAX(Value) FROM vValuationsLatest WHERE Securityid = S.SecurityId AND FinancialNumberTypeId = FCS.TickerTableValuationId AND IsDraft = 0 AND FinancialPeriodId = 3),
  -- Other Fields
  VF.Currency,
  VF.YTDRelPerf,
  VF.Yield,
  -- Coverage dates
  VF.LaunchDate,
  VF.FileName,
  VF.CoverageId,
  VF.IndustryId,
  VF.AnalystId,
  VF.CloseDate,
  VF.ClosePrice,
  VF.TickerOrder,
  VF.DisplayCloseDate,
  VF.RelPerfType
FROM vFinancials2 VF
JOIN (SELECT Ticker, MAX(PubNo) PubNo FROM PublicationFinancials GROUP BY Ticker) V ON V.Ticker = VF.Ticker AND V.PubNo = VF.PubNo
JOIN ResearchCoverage RC ON RC.SecurityID = VF.SecurityID AND RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId

GO


