-- 04/02/2019
-- ETL_Config_Rollback.sql

/*

alter FileProcessingConfig - drop EditorId, EditDate
alter FileLoadInstructions - drop EditorId, EditDate
alter PortalClientEmbargo  - drop ContactId
alter FileProcessingLog    - drop Type
drop  RVPortalClientEmbargo view
rollback RVPortalUsage view
drop RVPortalSubSites view

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'EditorId' AND Object_ID = Object_ID(N'FileProcessingConfig'))
  ALTER TABLE FileProcessingConfig DROP COLUMN EditorId
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'EditDate' AND Object_ID = Object_ID(N'FileProcessingConfig'))
  ALTER TABLE FileProcessingConfig DROP COLUMN EditDate
GO

-- alter FileLoadInstructions - add EditorId, EditDate
IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'EditorId' AND Object_ID = Object_ID(N'FileLoadInstructions'))
  ALTER TABLE FileLoadInstructions DROP COLUMN EditorId
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'EditDate' AND Object_ID = Object_ID(N'FileLoadInstructions'))
  ALTER TABLE FileLoadInstructions DROP COLUMN EditDate
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'ContactId' AND Object_ID = Object_ID(N'PortalClientEmbargo'))
  ALTER TABLE PortalClientEmbargo DROP COLUMN ContactId
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'Status' AND Object_ID = Object_ID(N'FileProcessingLog'))
  ALTER TABLE FileProcessingLog DROP COLUMN [Status]
GO


IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVPortalUsage]'))
DROP VIEW [dbo].[RVPortalUsage]
GO

-- stop replication, update RVPortalUsage to add 2 new columns from new PortalUsage table, start replication
CREATE VIEW [dbo].[RVPortalUsage] WITH SCHEMABINDING AS
SELECT
  UsageId,
  ContentId AS PubNo,
  --ContentType,
  --ContentId,
  ReadDate,
  PU.SiteId,
  Site,
  Email,
  Contact,
  ContactId,
  Account,
  AccountId,
  '' AS FirmType,
  '' AS Delivery
FROM
  dbo.PortalUsage PU
  JOIN dbo.DistributionSites DS ON PU.SiteId = DS.SiteId
WHERE
  ExclusionId IS NULL AND
  ContentType = 'R'

GO

CREATE UNIQUE CLUSTERED INDEX [RVPortalUsage_UsageId] ON [dbo].[RVPortalUsage]([UsageId] ASC)
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVPortalSubSites]'))
DROP VIEW [dbo].[RVPortalSubSites]
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVPortalClientEmbargo]'))
DROP VIEW [dbo].[RVPortalClientEmbargo]
GO