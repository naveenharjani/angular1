-- PortalUsage_Rollback.sql
-- 11/07/2018

/*

rollback PortalUsage
load old data from PortalUsageBak

stop replication
rollback RVPortalUsage from old PortalUsage

rollback PortalSubSites rename column Subsite to Delivery

drop PortalUsageStaging_VisibleAlpha
drop spLoadPortalUsageFromStaging_VisibleAlpha

rollback spLoadPortalUsageFromStaging_Factset

-- rollback existing stored procs
-- The old Portalusage has [PubNo], [Delivery] columns
rollback spLoadPortalUsageFromStaging_TR
rollback spLoadPortalUsageFromStaging_Bloomberg
rollback spLoadPortalUsageFromStaging_CIQ
rollback spLoadPortalUsageFromStaging_RedDeer
rollback spLoadPortalUsageFromStaging_ONEAccess
rollback spLoadPortalUsageFromStaging_RSRCHX
rollback spLoadPortalUsageFromStaging_BlueMatrix

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- Stop replication, drop RVPortalUsage
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RVPortalUsage]') AND type in (N'V'))
DROP VIEW [dbo].[RVPortalUsage]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsage]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsage]
GO

CREATE TABLE [dbo].[PortalUsage](
	[UsageId] [int] IDENTITY(1,1) NOT NULL,
	[PubNo] [int] NOT NULL,
	[ReadDate] [datetime] NOT NULL,
	[SiteId] [int] NOT NULL,
	[Email] [varchar](200) NULL,
	[Contact] [varchar](250) NULL,
	[ContactId] [varchar](50) NULL,
	[Account] [varchar](250) NULL,
	[AccountId] [varchar](50) NULL,
	[ExclusionId] [int] NULL,
	[FirmType] [varchar](50) NULL,
	[Delivery] [varchar](50) NULL,
 CONSTRAINT [PK_PortalUsage] PRIMARY KEY CLUSTERED ([UsageId] ASC) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[PortalUsage]  WITH CHECK ADD  CONSTRAINT [FK_PortalUsage_PortalUsageExclusions] FOREIGN KEY([ExclusionId])
REFERENCES [dbo].[PortalUsageExclusions] ([ExclusionId])
GO
ALTER TABLE [dbo].[PortalUsage] CHECK CONSTRAINT [FK_PortalUsage_PortalUsageExclusions]
GO

SET IDENTITY_INSERT [dbo].[PortalUsage] ON
GO
INSERT INTO [dbo].[PortalUsage]
(UsageId, PubNo, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, ExclusionId, FirmType, Delivery)
SELECT * FROM [dbo].[PortalUsageBak]
GO
SET IDENTITY_INSERT [dbo].[PortalUsage] OFF
GO

CREATE VIEW [dbo].[RVPortalUsage] WITH SCHEMABINDING AS
SELECT
  UsageId,
  PubNo,
  ReadDate,
  PU.SiteId,
  Site,
  Email,
  Contact,
  ContactId,
  Account,
  AccountId,
  FirmType,
  Delivery
FROM
  dbo.PortalUsage PU
  JOIN dbo.DistributionSites DS ON PU.SiteId = DS.SiteId
WHERE
  ExclusionId IS NULL
GO

-- Rollback column 'Delivery' - PortalSubSites
IF EXISTS(SELECT 1 FROM sys.columns WHERE [name] = N'SubSite' AND [object_id] = OBJECT_ID(N'PortalSubSites'))
BEGIN
    EXEC sp_rename 'PortalSubSites.SubSite', 'Delivery', 'COLUMN';
END

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_VisibleAlpha]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_VisibleAlpha]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_VisibleAlpha]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_VisibleAlpha]
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 12 -- Factset

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_FactSet) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_FactSet STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Date/time read])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Date/time read])
   AND DAY(PU.ReadDate) = DAY(STG.[Date/time read])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, Delivery)
SELECT
  [Doc ID (contributor)],
  [Date/time read],
  @SiteId,
  [E-mail],
  [Reader name],
  [Reader ID (FactSet)],
  [Firm name],
  [Firm ID (FactSet)],
  [Platform]
FROM [dbo].[PortalUsageStaging_FactSet]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Date/time read] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Date/time read] AS DATE) ), 101)
FROM PortalUsageStaging_FactSet
WHERE ISDATE([Date/time read]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for FactSet from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO


ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 9 -- Thomson Reuters

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_TR) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_TR STG
   WHERE YEAR(PU.ReadDate) = YEAR(STG.[Viewed Date])
   AND MONTH(PU.ReadDate)= MONTH(STG.[Viewed Date])
   AND DAY(PU.ReadDate)  = DAY(STG.[Viewed Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (PubNo, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, FirmType, Delivery)
SELECT
  CASE WHEN ISNUMERIC([Local DocID]) = 1 THEN [Local DocID] ELSE 0 END,
  CASE WHEN ISDATE([Viewed Date]) = 1 THEN [Viewed Date] ELSE NULL END,
  @SiteId,
  [User Email],
  [User Name],
  ISNULL([Unique ID],0),
  [Client Name],
  ISNULL([Client Company ID],0),
  [Client Type],
  [Delivery]
FROM [dbo].[PortalUsageStaging_TR]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Viewed Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Viewed Date] AS DATE) ), 101)
FROM PortalUsageStaging_TR
WHERE ISDATE([Viewed Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for TR from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 3 -- Bloomberg

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_Bloomberg) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_Bloomberg STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId)
SELECT
  CASE WHEN ISNUMERIC([Story Id]) = 1 THEN [Story ID] ELSE 0 END AS StoryId,
  [Read Date],
  @SiteId,
  [Business Email],
  [User Name],
  CASE WHEN ISNUMERIC([UUID]) = 1 THEN [UUID] ELSE NULL END AS UUID,
  [Customer Name],
  [Customer #]
FROM [dbo].[PortalUsageStaging_Bloomberg]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read Date] AS DATE) ), 101)
FROM PortalUsageStaging_Bloomberg
WHERE ISDATE([Read Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Bloomberg from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 11 -- Capital IQ

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_CIQ) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_CIQ STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Download Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Download Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Download Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, FirmType, Delivery)
SELECT
  [Ctb Doc Id],
  [Download Date],
  @SiteId,
  [Email],
  [User Name],
  [User],
  [Company Name],
  [Company],
  [Firm Type],
  [Activity Type]
FROM [dbo].[PortalUsageStaging_CIQ]
WHERE ISNUMERIC([Ctb Doc Id]) = 1

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Download Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Download Date] AS DATE) ), 101)
FROM PortalUsageStaging_CIQ
WHERE ISDATE([Download Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for CIQ from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RedDeer]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 23 -- RedDeer

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RedDeer) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_RedDeer STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read_Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read_Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read_Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, Delivery)
SELECT
  [Vendor_Doc_ID ****],
  [Read_Date],
  @SiteId,
  [User_Business_Email],
  [User_Name],
  [User_ID **],
  [Client_Name],
  [Client_ID *],
  NULL
FROM [dbo].[PortalUsageStaging_RedDeer]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read_Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read_Date] AS DATE) ), 101)
FROM [PortalUsageStaging_RedDeer]
WHERE ISDATE([Read_Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Red Deer from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_ONEaccess]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 21 -- ONEaccess

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_ONEaccess) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_ONEaccess STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[viewed_date_UTC])
   AND YEAR(PU.ReadDate) = YEAR(STG.[viewed_date_UTC])
   AND DAY(PU.ReadDate) = DAY(STG.[viewed_date_UTC])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, Delivery)
SELECT
  [broker_document_id],
  [viewed_date_UTC],
  @SiteId,
  [user_business_email],
  [user_name],
  [vendor_user_id],
  [client_name],
  [vendor_client_id],
  [Vendor Channel]
FROM [dbo].[PortalUsageStaging_ONEaccess]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([viewed_date_UTC] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([viewed_date_UTC] AS DATE) ), 101)
FROM [PortalUsageStaging_ONEaccess]
WHERE ISDATE([viewed_date_UTC]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for OneAccess from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT  @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RSRCHX]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 22 -- RSRCHXchange

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RSRCHX) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_RSRCHX STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Action Date (UTC)])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Action Date (UTC)])
   AND DAY(PU.ReadDate) = DAY(STG.[Action Date (UTC)])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, Delivery)
SELECT
  [Provider's Identifier],
  [Action Date (UTC)],   -- 'read time' component not needed
  @SiteId,
  [Email],
  [Surname] + ', ' + [Forename],
  [User UUID],
  [Client Org Firm Name],
  [Client UUID],
  NULL
FROM [dbo].[PortalUsageStaging_RSRCHX]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Action Date (UTC)] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Action Date (UTC)] AS DATE) ), 101)
FROM [PortalUsageStaging_RSRCHX]
WHERE ISDATE([Action Date (UTC)]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for RSRCHXchange from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END


GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_BlueMatrix]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 20 -- Blue Matrix

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_BlueMatrix) RETURN

-- Remove T Z from datetime
UPDATE PortalUsageStaging_BlueMatrix 
SET [Read Date/Time] = REPLACE(REPLACE([Read Date/Time],'T',''), 'Z', ''),
    [Document Date]  = REPLACE(REPLACE([Document Date],'T',''), 'Z', '')

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_BlueMatrix STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read Date/Time])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read Date/Time])
   AND DAY(PU.ReadDate) = DAY(STG.[Read Date/Time])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, Delivery)
SELECT
  [Product ID],
  [Read Date/Time],
  @SiteId,
  [Primary E-Mail],
  [User Name],
  [User ID],
  [Firm name],
  [Firm ID],
  [Channel]
FROM [dbo].[PortalUsageStaging_BlueMatrix]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date/Time] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read Date/Time] AS DATE) ), 101)
FROM [PortalUsageStaging_BlueMatrix]
WHERE ISDATE([Read Date/Time]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Blue Matrix from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate
--Changed by Anup Singh
SELECT @RowsLoaded,@PeriodStartDate,@PeriodEndDate

SET NOCOUNT OFF
END

GO

-- DEBUG
/*
SELECT top 10000 * FROM [dbo].[PortalUsage] ORDER BY ReadDate DESC
SELECT top 10000 * FROM [dbo].[PortalUsageBak] ORDER BY ReadDate DESC

SELECT COUNT(*) FROM [dbo].[PortalUsage]
SELECT COUNT(*) FROM [dbo].[PortalUsageBak]
GO
*/

