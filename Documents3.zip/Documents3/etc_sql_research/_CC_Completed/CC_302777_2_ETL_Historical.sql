-- CC_ETL_Historical.sql
-- 02/12/2019

/*
-- Table changes
-- alter table PortalUsageStaging_FactSet          : +20 columns from monthly file
-- alter table PortalUsageStaging_CIQ              : +8 columns from monthly file

-- Proc changes
-- alter proc spLoadPortalUsageFromStaging_CIQ     : load PortalUsage.Firm_Type from monthly file

-- New history file format for each portal.  Overload into existing staging table.  Process Tx id.
-- Load history for Bloomberg - Retrieve files from FTP server - 2 files - rpt2-PRE, rpt1-POST.  Download to watched folder.
-- Load history for TR, Factset, CIQ - Retrieve files in date range chunks from self-serve portals.  Manually assign file name.  Download to watched folder.
*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_CIQ]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_CIQ]
GO

CREATE TABLE [dbo].[PortalUsageStaging_CIQ](
  [Ctb Doc Id] [varchar](500) NULL,
  [Client] [varchar](500) NULL,
  [User] [varchar](500) NULL,
  [Client Name] [varchar](500) NULL,
  [User Name] [varchar](500) NULL,
  [Email] [varchar](500) NULL,
  [Activity Id] [varchar](500) NULL,
  [Activity Date] [varchar](500) NULL,
  [Headline] [varchar](500) NULL,
  [Type] [varchar](500) NULL,
  -- +columns in post-embargo yearly/monthly files
  [CIQ Doc Id] [varchar](500) NULL,
  [Firm Type] [varchar](500) NULL,
  [Doc Type] [varchar](500) NULL,
  [Industry] [varchar](500) NULL,
  [Analyst] [varchar](500) NULL,
  [Primary Company] [varchar](500) NULL,
  [Document Posted Date] [varchar](500) NULL,
  [Activity Type] [varchar](500) NULL
) ON [PRIMARY]
GO

-- alter proc to load Portal Usage data for CapitalIQ
ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table
DECLARE
  @SiteId           INT,
  @SubSite          VARCHAR(50),
  @ContentType      VARCHAR(50),
  @DataStore        NVARCHAR(200),
  @PreEmbargoedText VARCHAR(30),
  @LoadDate         DATETIME,
  @PeriodStartDate  VARCHAR(10),
  @PeriodEndDate    VARCHAR(10),
  @RowsLoaded       INT

SET @SiteId = 11                  -- CapitalIQ
SET @DataStore = 'CIQ'
SET @SubSite = 'CIQ'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'     -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_CIQ) RETURN

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_CIQ CIQ
WHERE CIQ.[Activity Id] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    -- Content Id
    CASE WHEN ISNUMERIC(CIQ.[Ctb Doc Id]) = 1 THEN CIQ.[Ctb Doc Id] ELSE 0 END,
    CIQ.[Activity Date],
    @SiteId,
    @SubSite,
    CIQ.[Email],
    CIQ.[User Name],
    CASE WHEN ISNUMERIC(CIQ.[User]) = 1 THEN CIQ.[User] ELSE NULL END AS UUID,
    CIQ.[Client Name],
    CIQ.[Client],
    CIQ.[Firm Type],
    CIQ.[Activity Id],
    -- Embargo Style
    CASE
      WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 90 THEN 'POST90'
      WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 30 THEN 'POST30'
      WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 1  THEN 'PRE'
      ELSE 'MIXED'
    END,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_CIQ CIQ
  WHERE CIQ.[Activity Id] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_CIQ CIQ ON PU.TransactionId = CIQ.[Activity Id] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
-- Update those rows that were previously embargoed
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage with post-embargo data from Staging table by Transaction Id
  UPDATE pu
  SET PU.Email = CIQ.[Email],
      PU.Contact = CIQ.[User Name],
      PU.ContactId = CASE WHEN ISNUMERIC(CIQ.[User]) = 1 THEN CIQ.[User] ELSE NULL END,
      PU.Account = CIQ.[Client Name],
      PU.AccountId = CIQ.[Client],
      PU.AccountType = CIQ.[Firm Type],
      PU.EmbargoStyle =
      CASE
          WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 90 THEN 'POST90'     -- reads in last -91 days
          WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 30 THEN 'POST30'     -- reads in last -31 days
          WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 1  THEN 'PRE'        -- reads in last -2 days
          ELSE ''
      END,
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_CIQ CIQ ON PU.TransactionId = CIQ.[Activity Id] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update only the Pre-embargo rows

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Populate [PortalClientEmbargo] table as per the file name e.g. ResearchActivity
-- only the daily files to be used to populate client embargoes
-- CapitalIQ daily file has -1, -31, -91 day read data

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct CIQ.[Client Name]) FROM PortalUsageStaging_CIQ CIQ
WHERE CIQ.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'MIXED'
BEGIN
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
      -- Identify accounts with 90 day embargo
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, CIQ.[Client Name], CIQ.[Client], 90
        FROM PortalUsageStaging_CIQ CIQ
    WHERE DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 90
    AND CIQ.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND LTRIM(RTRIM(CIQ.[Client Name])) != ''

    --Identify accounts with 30 day embargo
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, CIQ.[Client Name], CIQ.[Client], 30
        FROM PortalUsageStaging_CIQ CIQ
    WHERE DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 30 AND DATEDIFF(d, CIQ.[Activity Date], getdate()) < 90
    AND CIQ.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND LTRIM(RTRIM(CIQ.[Client Name])) != ''
  END
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST(CIQ.[Activity Date] AS DATE) ), 101),
       @PeriodEndDate   = CONVERT(VARCHAR, MAX(CAST(CIQ.[Activity Date] AS DATE) ), 101)
FROM PortalUsageStaging_CIQ CIQ
WHERE ISDATE(CIQ.[Activity Date]) = 1

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END
GO


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_FactSet]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_FactSet]
GO

CREATE TABLE [dbo].[PortalUsageStaging_FactSet](
  [Date/time read] [varchar](500) NULL,
  [Platform] [varchar](500) NULL,
  [Reader ID (FactSet)] [varchar](500) NULL,
  [Reader name] [varchar](500) NULL,
  [E-mail] [varchar](500) NULL,
  [Phone] [varchar](500) NULL,
  [Parent Firm ID (FactSet)] [varchar](500) NULL,
  [Parent Firm name] [varchar](500) NULL,
  [Firm ID (FactSet)] [varchar](500) NULL,
  [Firm name] [varchar](500) NULL,
  [Address] [varchar](500) NULL,
  [City] [varchar](500) NULL,
  [State] [varchar](500) NULL,
  [Country] [varchar](500) NULL,
  [Doc ID (contributor)] [varchar](500) NULL,
  [Readership Event ID (FactSet)] [varchar](500) NULL,
  [Date/time published] [varchar](500) NULL,
  [Report title] [varchar](500) NULL,
  -- +columns in post-embargo yearly/monthly files
  [Doc ID (FactSet)] [varchar](500) NULL,
  [Date/time received] [varchar](500) NULL,
  [Primary issuer Ticker]  [varchar](500) NULL,
  [Primary issuer name]  [varchar](500) NULL,
  [Primary analyst code (contributor)] [varchar](500) NULL,
  [Primary analyst code (FactSet)] [varchar](500) NULL,
  [Primary analyst name] [varchar](500) NULL,
  [Number of pages in report] [varchar](500) NULL,
  [Report Purpose] [varchar](500) NULL,
  [Report Focus] [varchar](500) NULL,
  [Asset Class] [varchar](500) NULL,
  [Asset Type] [varchar](500) NULL,
  [Primary Industry Code (FactSet)] [varchar](500) NULL,
  [Primary Industry Name (FactSet)]  [varchar](500) NULL,
  [Security Type] [varchar](500) NULL,
  [Discipline] [varchar](500) NULL,
  [Research Approach] [varchar](500) NULL,
  [Periodicity] [varchar](500) NULL,
  [Region] [varchar](500) NULL,
  [Compilation Indicator] [varchar](500) NULL
) ON [PRIMARY]
GO

-- Grant Permissions
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_CIQ]        TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_FactSet]    TO DE_IIS
GO