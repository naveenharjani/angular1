-- TickerTableFix.sql
-- 06/19/2019

/*
Handle missing market data gracefully on ticker table and company financials API / web page
Possible causes:
* IPO ticker not yet traded
* Ticker symbol change
* Company merger
Handle 'NA' value for marketdata e.g. Close date 
*/

/*
alter proc spGetCompanyMarketDataXml    @InXml TEXT

alter proc spGetTickerTableApiXml       @InXml TEXT

alter proc spGetTickerTableHeaderFooter @InXml TEXT
*/


ALTER PROCEDURE [dbo].[spGetCompanyMarketDataXml]
  @InXml TEXT
AS

SET NOCOUNT ON

DECLARE @CompanyId            INT,
        @Company              VARCHAR(60),
        @SelectedSecurityId   INT,
        @BenchmarkIndexId     INT,
        @BenchmarkIndex       VARCHAR(10),
        @Ticker               varchar(15),
        @TargetPrice          VARCHAR(30),
        @TargetPriceDesc      VARCHAR(50),
        @TargetPriceIsDraft   SMALLINT,
        @TargetPriceIsBold    CHAR,
        @TargetPriceCurCode   CHAR(3),
        @ClosePrice           VARCHAR(50),
        @UpsideDownsideRatio  VARCHAR(20),
        @TradeCurrency        VARCHAR(20),
        @FundCurrency         VARCHAR(20),
        @ClosePriceCurrency   VARCHAR(20),
        @hDoc                 INT,
        @Date                 DATETIME,
        @Type                 VARCHAR(31),
        @Title                VARCHAR(255),
        @RptPubNo             INT,
        @Version              INT,
        @SecurityId           INT,
        @IndicateChange       VARCHAR(10),
        @IsEstimatesScreen    VARCHAR(5),
        @FinancialsHeaderRow  VARCHAR(4000),
        @FinancialsXml        XML,
        @PublicationsXml      XML,
        @PublicationsLastChangeXml    XML,
        @CompanyFinancialXml  VARCHAR(MAX)

EXEC sp_xml_preparedocument @hDoc OUTPUT, @InXml

SELECT @Date = X.Date, @Type = X.Type, @Title = X.Title
FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
WITH (Date datetime '@pubDate', Type varchar(31) '@type', Title varchar(255) '@title' ) X

EXEC spCheckForResubmits @Date, @Type, @Title, @RptPubNo OUTPUT, @Version OUTPUT

SELECT
  ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo,
  S.SecurityId, X.Ticker, X.IndicateChange, S.Company, S.CompanyId,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'live', @RptPubNo) AS SourceLive,
  ISNULL(X.LastPubNo, '') AS LastChangePubNo,
  CASE WHEN X.CoverageId IS NULL OR X.CoverageId = '' OR X.CoverageId = '0' THEN RC.CoverageId
       ELSE X.CoverageId
  END AS CoverageId
INTO #TickerList
FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
WITH (SecurityId int '@id', Ticker varchar(30) '@ticker', IndicateChange  varchar(30) '@indicateChange', LastPubNo int '@optLastPubNo', CoverageId INT '@coverageId') X
INNER JOIN Securities2 S ON S.Ticker = X.Ticker
INNER JOIN ResearchCoverage RC ON RC.SecurityId = S.SecurityId AND RC.DropDate IS NULL

-- Get the Company of the first ticker in the list
SELECT TOP 1 @SecurityId = SecurityId, @CompanyId = CompanyId, @Company = Company, @Ticker = Ticker FROM #TickerList

IF NOT EXISTS(SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
BEGIN
  SELECT '<NotExist>' + 'Missing Company for provided Ticker. Security Id:' + CONVERT(VARCHAR, @SecurityId) + '</NotExist>' AS XML
  RETURN
END

SELECT @IsEstimatesScreen = X.IsEstimatesScreen
FROM OPENXML (@hDoc, 'DocumentInfo/Securities', 1)
WITH (IsEstimatesScreen varchar(5) '@isEstimatesScreen') X

IF @IsEstimatesScreen = 'yes'
  SELECT @SelectedSecurityId = @SecurityId
-- Get Primary Ticker for the Company
ELSE IF EXISTS(SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
  SELECT @SelectedSecurityId = SecurityId FROM Securities2 WHERE CompanyId = @CompanyId AND IsPrimary = 'Y'
ELSE
  SELECT @SelectedSecurityId = @SecurityId

-- Get Benchmark Index for the selected Ticker
SELECT @BenchmarkIndexId = SecurityId     FROM Securities2 WHERE Ticker = ( SELECT BenchmarkIndex FROM Securities2  WHERE SecurityId = @SelectedSecurityId)
SELECT @BenchmarkIndex   = BenchmarkIndex FROM Securities2 WHERE SecurityId = @SelectedSecurityId

-- Get Indicate Change for primary ticker
SELECT @IndicateChange = IndicateChange FROM #TickerList WHERE SecurityId = @SelectedSecurityId

-- Get Target Price value -  primary ticker [Calculate Upside/Downside]
SELECT
  @TargetPriceDesc = FNT.ShortName,
  -- target price value
  @TargetPrice = (CASE WHEN FN2.Value IS NOT NULL AND @IndicateChange = 'yes' THEN FN2.Value ELSE FN.Value END),
  -- target price flag - draft[1] or live[0]
  @TargetPriceIsDraft = (CASE WHEN FN2.Value IS NOT NULL AND @IndicateChange = 'yes' THEN 1 ELSE 0 END),
  @TargetPriceIsBold  = (CASE WHEN FN2.Value IS NOT NULL AND FN.Value IS NOT NULL AND @IndicateChange = 'yes' THEN 'Y' ELSE 'N' END),
  @TargetPriceCurCode = (CASE WHEN FN2.Value IS NOT NULL AND @IndicateChange = 'yes' THEN FN2.CurCode ELSE FN.CurCode END)
FROM #TickerList TL
INNER JOIN FinancialNumberTypes FNT ON  FNT.FinancialNumberType IN ('TARGETPRICE')
-- Only data for active ticker coverage (not dropped/suspended) using active CoverageId
LEFT JOIN vFinancialNumbersLatest FN ON FN.SecurityId = TL.SecurityId
                                    AND FN.CoverageId = TL.CoverageId
                                    AND FN.FinancialNumberTypeId = FNT.FinancialNumberTypeId
                                    AND FN.IsDraft = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                     AND FN2.CoverageId= TL.CoverageId
                                     AND FN2.FinancialNumberTypeId = FNT.FinancialNumberTypeId
                                     AND FN2.IsDraft = 1  -- Draft
WHERE TL.SecurityId = @SelectedSecurityId

-- Get data from the 3 sources and then set the Target Price
-- Get the PubXml for last report
SELECT @PublicationsXml = CompanyFinancialsXml FROM PublicationsXML  WHERE PubNo = @RptPubNo

-- Get the PubXml for last change report
SELECT @PublicationsLastChangeXml = CompanyFinancialsXml FROM PublicationsXML
WHERE PubNo = (SELECT LastChangePubNo FROM #TickerList WHERE SecurityId = @SelectedSecurityId)

-- Get Close Price - primary ticker [Calculate Upside/Downside]
SELECT @ClosePrice = VMD.Value
FROM FinancialNumberTypes FNT
INNER JOIN vMarketData VMD on FNT.FinancialNumberTypeId = VMD.FinancialNumberTypeId and FNT.FinancialNumberType  = 'CLOSEPRICE'
WHERE VMD.SecurityId = @SelectedSecurityId

-- Get Trade Currency [Market Cap]
SELECT @TradeCurrency = VMD.Value
FROM vMarketDataLatest VMD
INNER JOIN FinancialNumberTypes FNT ON FNT.FinancialNumberTypeId = VMD.FinancialNumberTypeId AND FNT.FinancialNumberType = 'CRNCY'
WHERE SecurityId = @SelectedSecurityId AND VMD.Type = 'B'

-- Get Fundamental Currency [EV]
SELECT @FundCurrency = Value
FROM vMarketDataLatest VMD
INNER JOIN FinancialNumberTypes FNT ON FNT.FinancialNumberTypeId = VMD.FinancialNumberTypeId AND FNT.FinancialNumberType = 'EQY_FUND_CRNCY'
WHERE SecurityId = @SelectedSecurityId AND VMD.Type = 'B'

-- Get Close Price Currency [Close Price] - handle exceptions for GBp
SELECT @ClosePriceCurrency = CurrencyCode FROM Securities2 WHERE SecurityId = @SelectedSecurityId

-- Calculate Upside/Downside - primary ticker
IF @ClosePrice = '' OR @ClosePrice = '0' OR ISNUMERIC(@ClosePrice) = 0
  SELECT @UpsideDownsideRatio = ''
ELSE IF ISNUMERIC(@TargetPrice) = 0
  SELECT @UpsideDownsideRatio = 'NM'
ELSE
  SELECT @UpsideDownsideRatio =  (CONVERT(FLOAT, @TargetPrice) - CONVERT(FLOAT, @ClosePrice) ) * 100 / CONVERT(FLOAT, @ClosePrice)

-- get DisplayUnits for certain marketdata fields
SELECT vmd.SecurityId, vmd.FinancialNumberType, vmd.Value, fnt.UnitMultiplier,
       dbo.fnCalculateDisplayUnits(vmd.Value, fnt.UnitMultiplier) AS DisplayUnits
INTO #TmpMarketdataStyles
FROM vMarketData vmd
INNER JOIN FinancialNumberTypes fnt on fnt.FinancialNumberTypeId = vmd.FinancialNumberTypeId
WHERE vmd.SecurityID = @SelectedSecurityId
AND fnt.FinancialNumberType IN ('CUR_MKT_CAP', 'EV')

-- Get Latest Financials data in a XML variable
SET @FinancialsXml =
(
SELECT * FROM
(
SELECT
  1                      AS tag,
  null                   AS parent,
  @Company               AS [MarketData!1!company],
  @CompanyId             AS [MarketData!1!companyId],
  @Ticker                AS [MarketData!1!ticker],
  @BenchmarkIndex        AS [MarketData!1!index],
  @SecurityId            AS [MarketData!1!paramSecurityId],
  NULL                   AS [MarketDataRow!2!ticker],
  NULL                   AS [MarketDataRow!2!financialNumberType],
  NULL                   AS [MarketDataRow!2!label],
  NULL                   AS [MarketDataRow!2!value],
  NULL                   AS [MarketDataRow!2!curCode],
  NULL                   AS [MarketDataRow!2!isDraft],
  NULL                   AS [MarketDataRow!2!isBold],
  ''                     AS [MarketDataRow!2!tickerType],
  NULL                   AS [MarketDataRow!2!units],
  NULL                   AS [MarketDataRow!2!format],
  NULL                   AS [MarketDataRow!2!dispOrder]

UNION ALL

SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [MarketData!1!company],
  NULL                    AS [MarketData!1!companyId],
  NULL                    AS [MarketData!1!ticker],
  NULL                    AS [MarketData!1!index],
  NULL                    AS [MarketData!1!paramSecurityId],
  MAX(S.Ticker)           AS [MarketDataRow!2!ticker],
  fnt.FinancialNumberType AS [MarketDataRow!2!financialNumberType],
  MAX(fnt.ShortName)      AS [MarketDataRow!2!label],
  CASE
     WHEN fnt.FinancialNumberType IN ('CUR_MKT_CAP','EV') AND MAX(ISNUMERIC(vmd.Value)) = 1
     THEN MAX(dbo.fnConvertDisplayUnits(vmd.Value, TS.DisplayUnits))
     ELSE MAX(vmd.Value)
  END                     AS [MarketDataRow!2!value],
  CASE
     WHEN fnt.FinancialNumberType = 'CLOSEPRICE'     THEN @ClosePriceCurrency
     WHEN fnt.FinancialNumberType = 'CUR_MKT_CAP'    THEN UPPER(@TradeCurrency)
     WHEN fnt.FinancialNumberType = 'EV'             THEN @FundCurrency
     ELSE ''
  END                     AS [MarketDataRow!2!curCode],
  NULL                    AS [MarketDataRow!2!isDraft],
  NULL                    AS [MarketDataRow!2!isBold],
  'STOCK'                 AS [MarketDataRow!2!tickerType],
  CASE
    -- Get Display Units Style for EV, Market Cap
    WHEN fnt.FinancialNumberType IN ('CUR_MKT_CAP','EV')
    THEN MAX([dbo].[fnCalculateDisplayUnitsStyle](TS.DisplayUnits))
    ELSE ''
  END                               AS [MarketDataRow!2!units],
  MAX(ISNULL(fnt.Format,''))        AS [MarketDataRow!2!format],
  CASE
    WHEN fnt.FinancialNumberType = 'CLOSEPRICE'        THEN 2
    WHEN fnt.FinancialNumberType = '52_WEEK_LOW'       THEN 6
    WHEN fnt.FinancialNumberType = '52_WEEK_HIGH'      THEN 7
    WHEN fnt.FinancialNumberType = 'EQY_DVD_YLD_IND'   THEN 10
    WHEN fnt.FinancialNumberType = 'CUR_MKT_CAP'       THEN 11
    WHEN fnt.FinancialNumberType = 'EV'                THEN 12
    ELSE 99999
  END                      AS [MarketDataRow!2!dispOrder]
FROM vMarketData vmd
INNER JOIN FinancialNumberTypes fnt on fnt.FinancialNumberTypeId = vmd.FinancialNumberTypeId
INNER JOIN Securities2 S ON S.SecurityId = vmd.SecurityId
LEFT JOIN #TmpMarketdataStyles TS ON TS.SecurityId = vmd.SecurityId AND TS.FinancialNumberType = vmd.FinancialNumberType
WHERE vmd.SecurityID = @SelectedSecurityId
  AND fnt.FinancialNumberType IN ('CLOSEPRICE', '52_WEEK_HIGH', '52_WEEK_LOW','EQY_DVD_YLD_IND', 'CUR_MKT_CAP', 'EV')
GROUP BY fnt.FinancialNumberType

UNION ALL

SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [MarketData!1!company],
  NULL                    AS [MarketData!1!companyId],
  NULL                    AS [MarketData!1!ticker],
  NULL                    AS [MarketData!1!index],
  NULL                    AS [MarketData!1!paramSecurityId],
  S.Ticker                AS [MarketDataRow!2!ticker],
  fnt.FinancialNumberType AS [MarketDataRow!2!financialNumberType],
  fnt.ShortName           AS [MarketDataRow!2!label],
  CASE 
    WHEN ISDATE(vmd.Value) = 0 THEN vmd.value
  	ELSE DATENAME(dd, vmd.Value) + '-' + LEFT(DATENAME(mm, vmd.Value),3) + '-' + DATENAME(yy, vmd.Value)
  END                     AS [MarketDataRow!2!value],
  NULL                    AS [MarketDataRow!2!curCode],
  NULL                    AS [MarketDataRow!2!isDraft],
  NULL                    AS [MarketDataRow!2!isBold],
  'STOCK'                 AS [MarketDataRow!2!tickerType],
  ''                      AS [MarketDataRow!2!units],
  ISNULL(fnt.Format,'')   AS [MarketDataRow!2!format],
  1                       AS [MarketDataRow!2!dispOrder]
FROM vMarketData vmd
INNER JOIN FinancialNumberTypes fnt on fnt.FinancialNumberTypeId = vmd.FinancialNumberTypeId
INNER JOIN Securities2 S ON S.SecurityId = vmd.SecurityId
WHERE vmd.SecurityID = @SelectedSecurityId
AND fnt.FinancialNumberType IN ('CLOSEDATE')

UNION ALL

-- FYE
SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [MarketData!1!company],
  NULL                    AS [MarketData!1!companyId],
  NULL                    AS [MarketData!1!ticker],
  NULL                    AS [MarketData!1!index],
  NULL                    AS [MarketData!1!paramSecurityId],
  S.Ticker                AS [MarketDataRow!2!ticker],
  fnt.FinancialNumberType AS [MarketDataRow!2!financialNumberType],
  fnt.ShortName           AS [MarketDataRow!2!label],
  CASE
    WHEN ISNULL(vmd.Value,'') != ''
    THEN CONVERT(Varchar(3), DATENAME(MONTH, Left(vmd.Value,3) + '01/' + SUBSTRING(vmd.Value, 4, 4)))
    ELSE ''
  END                     AS [MarketDataRow!2!value],
  NULL                    AS [MarketDataRow!2!curCode],
  NULL                    AS [MarketDataRow!2!isDraft],
  NULL                    AS [MarketDataRow!2!isBold],
  'STOCK'                 AS [MarketDataRow!2!tickerType],
  ''                      AS [MarketDataRow!2!units],
  ISNULL(fnt.Format,'')   AS [MarketDataRow!2!format],
  9                       AS [MarketDataRow!2!dispOrder]
FROM vMarketData vmd
INNER JOIN FinancialNumberTypes fnt on fnt.FinancialNumberTypeId = vmd.FinancialNumberTypeId
INNER JOIN Securities2 S ON S.SecurityId = vmd.SecurityId
WHERE vmd.SecurityID = @SelectedSecurityId
AND fnt.FinancialNumberType IN ('EQY_FISCAL_YR_END')

UNION ALL

-- Target Price - Ticker
SELECT
  2                          AS tag,
  1                          AS parent,
  NULL                       AS [MarketData!1!company],
  NULL                       AS [MarketData!1!companyId],
  NULL                       AS [MarketData!1!ticker],
  NULL                       AS [MarketData!1!index],
  NULL                       AS [MarketData!1!paramSecurityId],
  S.Ticker                   AS [MarketDataRow!2!ticker],
  'TARGETPRICE'              AS [MarketDataRow!2!financialNumberType],
  @TargetPriceDesc           AS [MarketDataRow!2!label],
  CASE WHEN ISNUMERIC(@TargetPrice) = 0 THEN @TargetPrice
       ELSE CAST(CAST(@TargetPrice AS DECIMAL(30,2)) AS VARCHAR(50))
  END
                             AS [MarketDataRow!2!value],
  @TargetPriceCurCode        AS [MarketDataRow!2!curCode],
  @TargetPriceIsDraft        AS [MarketDataRow!2!isDraft],
  @TargetPriceIsBold         AS [MarketDataRow!2!isBold],
  'STOCK'                    AS [MarketDataRow!2!tickerType],
  ''                         AS [MarketDataRow!2!units],
  ''                         AS [MarketDataRow!2!format],
  3                          AS [MarketDataRow!2!dispOrder]
FROM Securities2 S
WHERE S.SecurityId = @SelectedSecurityId

UNION ALL

-- Upside/(Downside) - Ticker
SELECT
  2                          AS tag,
  1                          AS parent,
  NULL                       AS [MarketData!1!company],
  NULL                       AS [MarketData!1!companyId],
  NULL                       AS [MarketData!1!ticker],
  NULL                       AS [MarketData!1!index],
  NULL                       AS [MarketData!1!paramSecurityId],
  S.Ticker                   AS [MarketDataRow!2!ticker],
  'UPSIDEDOWNSIDE'           AS [MarketDataRow!2!financialNumberType],
  'Upside/(Downside)'        AS [MarketDataRow!2!label],
  @UpsideDownsideRatio       AS [MarketDataRow!2!value],
  NULL                       AS [MarketDataRow!2!curCode],
  NULL                       AS [MarketDataRow!2!isDraft],
  NULL                       AS [MarketDataRow!2!isBold],
  'STOCK'                    AS [MarketDataRow!2!tickerType],
  ''                         AS [MarketDataRow!2!units],
  ''                         AS [MarketDataRow!2!format],
  5                          AS [MarketDataRow!2!dispOrder]
FROM Securities2 S
WHERE S.SecurityId = @SelectedSecurityId

UNION ALL

-- Close Price - Index
SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [MarketData!1!company],
  NULL                    AS [MarketData!1!companyId],
  NULL                    AS [MarketData!1!ticker],
  NULL                    AS [MarketData!1!index],
  NULL                    AS [MarketData!1!paramSecurityId],
  MAX(S.Ticker)           AS [MarketDataRow!2!ticker],
  FNT.FinancialNumberType AS [MarketDataRow!2!financialNumberType],
  MAX(FNT.ShortName)      AS [MarketDataRow!2!label],
  MAX(vmd.Value)          AS [MarketDataRow!2!value],
  NULL                    AS [MarketDataRow!2!curCode],
  NULL                    AS [MarketDataRow!2!isDraft],
  NULL                    AS [MarketDataRow!2!isBold],
  'INDEX'                 AS [MarketDataRow!2!tickerType],
  ''                            AS [MarketDataRow!2!units],
  MAX(ISNULL(fnt.Format,''))    AS [MarketDataRow!2!format],
  8                             AS [MarketDataRow!2!dispOrder]
FROM vMarketData vmd
inner join FinancialNumberTypes fnt on fnt.FinancialNumberTypeId = vmd.FinancialNumberTypeId and fnt.FinancialNumberType  = 'CLOSEPRICE'
INNER JOIN Securities2 S ON S.SecurityId = vmd.SecurityId
WHERE vmd.SecurityID = @BenchmarkIndexId
GROUP BY fnt.FinancialNumberType
) X

ORDER BY tag, [MarketDataRow!2!dispOrder] ASC
FOR XML Explicit
)

-- For v1(IndicateChange=no,yes), use the latest FinancialNumbers data
If @RptPubNo = 0 AND NOT EXISTS(SELECT * FROM #TickerList WHERE IndicateChange = 'last')
BEGIN
  SELECT @FinancialsXml
  RETURN
END

-- Get the PubXml for last report
SELECT @PublicationsXml = CompanyFinancialsXml FROM PublicationsXML  WHERE PubNo = @RptPubNo

-- Get the PubXml for last change report
SELECT @PublicationsLastChangeXml = CompanyFinancialsXml FROM PublicationsXML
WHERE PubNo = (SELECT LastChangePubNo FROM #TickerList WHERE SecurityId = @SelectedSecurityId)

-- Selectively fetch applicable rows (by ticker) from one of the 3 xml sources
-- Source: FinancialsXml
SELECT
  CONVERT(varchar(MAX),F.c.query('.')) AS result,
  F.c.value('./@dispOrder', 'INT')     AS dispOrder
INTO #CompanyFinancialXml
FROM #TickerList TL
JOIN @FinancialsXml.nodes('/MarketData/MarketDataRow') F(c)
     ON TL.SecurityId = CAST(F.c.value('../@paramSecurityId', 'INT') AS INT)
WHERE TL.SourceLive = 'FN'

UNION

-- Source: PublicationsXml for last Report
SELECT
  CONVERT(varchar(MAX),P.c.query('.')) AS result,
  P.c.value('./@dispOrder', 'INT')     AS dispOrder
FROM #TickerList TL
JOIN @PublicationsXml.nodes('/CompanyFinancials/MarketData/MarketDataRow') P(c)
     ON TL.SecurityId = CAST(P.c.value('../@paramSecurityId', 'INT') AS INT)
  WHERE TL.SourceLive = 'PX'

UNION

-- Source: PublicationsXml for last Change Report
SELECT
  CONVERT(varchar(MAX),PC.c.query('.')) AS result,
  PC.c.value('./@dispOrder', 'INT')     AS dispOrder
FROM #TickerList TL
JOIN @PublicationsLastChangeXml.nodes('/CompanyFinancials/MarketData/MarketDataRow') PC(c)
     ON TL.SecurityId = CAST(PC.c.value('../@paramSecurityId', 'INT') AS INT)
  WHERE TL.SourceLive = 'PXLAST'

ORDER BY 2

SET @FinancialsHeaderRow = '<MarketData company="' + [dbo].[fnCheckSpecialCharacters](@Company) + '"'
SET @FinancialsHeaderRow = @FinancialsHeaderRow + ' companyId="' + CONVERT(varchar, @CompanyId) + '"'
SET @FinancialsHeaderRow = @FinancialsHeaderRow + ' ticker="' + @Ticker + '"'
SET @FinancialsHeaderRow = @FinancialsHeaderRow + ' index="' + @BenchmarkIndex + '"'
SET @FinancialsHeaderRow = @FinancialsHeaderRow + ' paramSecurityId="' + CONVERT(varchar, @SecurityId) + '">'

-- Combine individual ticker rows as one string
SELECT @CompanyFinancialXml = STUFF(
                        (SELECT CHAR(13) + result
                           FROM #CompanyFinancialXml
                            FOR XML PATH(''),type).value('.','NVARCHAR(MAX)'),1,1,'')
SELECT @CompanyFinancialXml = @FinancialsHeaderRow + CHAR(13) + @CompanyFinancialXml + CHAR(13) + '</MarketData>'

SELECT CAST(@CompanyFinancialXml AS XML)


SET NOCOUNT OFF


GO

ALTER PROCEDURE [dbo].[spGetTickerTableApiXml]
  @InXml TEXT
AS
SET NOCOUNT ON

/*

@InXml contains the DocumentInfo.xml

*/

DECLARE
  @hDoc             INT,
  @Date             DATETIME,
  @Type             VARCHAR(31),
  @Title            VARCHAR(255),
  @RptPubNo         INT,
  @Version          INT,
  @FinancialsXml    XML,
  @PublicationsXml  XML,
  @TickerTableXml   VARCHAR(MAX),
  @TickerBaseYearMajority INT,
  @IndexBaseYearFirst     INT

EXEC sp_xml_preparedocument @hDoc OUTPUT, @InXML

SELECT @Date = X.Date, @Type = X.Type, @Title = X.Title
FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
WITH (Date datetime '@pubDate', Type varchar(31) '@type', Title varchar(255) '@title') X

EXEC spCheckForResubmits @Date, @Type, @Title, @RptPubNo OUTPUT, @Version OUTPUT

SELECT
  ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo,
  X.SecurityId, X.Ticker, X.IndicateChange,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'live', @RptPubNo) AS SourceLive,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'old',  @RptPubNo) AS SourceOld,
  ISNULL(X.LastPubNo, '') AS LastChangePubNo,
  S.Company, FCS.BaseYear, S.Alias,
  S.CurrencyCode,
  -- Model Currency for primary ticker - use for FX Cross Rate
  'PrimaryModelCur' = (SELECT FSS.CurCode FROM FinancialSecuritySettings FSS
                       JOIN Securities2 s ON S.SecurityId = FSS.SecurityId
                       WHERE S.CompanyId = FCS.CompanyId and s.isprimary = 'Y'),
  FCS.CompanyId,
  SI.SecurityID as PrimaryIndexId, SI.Ticker as PrimaryIndex,
  S.TickerType, FCS.TickerTableEpsId, FCS.TickerTableValuationId,
  CASE WHEN X.CoverageId IS NULL OR X.CoverageId = '' OR X.CoverageId = '0' THEN RC.CoverageId
       ELSE X.CoverageId
  END AS CoverageId
INTO #TickerList
FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
WITH (SecurityId int '@id', Ticker varchar(30) '@ticker', IndicateChange varchar(30) '@indicateChange', LastPubNo int '@optLastPubNo', CoverageId INT '@coverageId') X
INNER JOIN Securities2 S ON S.SecurityId = X.SecurityId AND S.TickerType = 'STOCK'
INNER JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
INNER JOIN Securities2 SI ON SI.Ticker = S.BenchmarkIndex
INNER JOIN ResearchCoverage RC ON RC.SecurityId = S.SecurityId AND RC.DropDate IS NULL

-- Include Indexes for the provided tickers
INSERT INTO #TickerList
SELECT
  100 + ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo,
  SecurityId, Ticker, 'no',
  [dbo].[fnGetEstimateSource](SecurityId, 'no', 'live', @RptPubNo)  AS SourceLive,
  [dbo].[fnGetEstimateSource](SecurityId, 'no', 'old',  @RptPubNo)  AS SourceOld,
  0  AS LastChangePubNo,
  Company, FCS.BaseYear, '' as Alias,
  S.CurrencyCode,
  '' AS PrimaryModelCur,
  S.CompanyId,
  '', '', TickerType,
  FCS.TickerTableEpsId, FCS.TickerTableValuationId,
  0 as CoverageId
FROM Securities2 S
INNER JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
WHERE Ticker in ( SELECT PrimaryIndex FROM #TickerList)

-- Tickers - Get BaseYear count
SELECT S.BaseYear,Count(S.BaseYear) BaseYearTickerCount
INTO #TmpBaseYearOptions
FROM (SELECT distinct Ticker, BaseYear FROM #TickerList WHERE TickerType = 'STOCK') S
GROUP BY BaseYear

-- Tickers - Get BaseYear majority
SELECT @TickerBaseYearMajority = MAX(BaseYear) FROM #TmpBaseYearOptions WHERE BaseYearTickerCount = (SELECT MAX(BaseYearTickerCount) FROM #TmpBaseYearOptions)

-- Indexes - Get BaseYear of first index
SELECT TOP 1 @IndexBaseYearFirst = BaseYear FROM #TickerList WHERE TickerType = 'INDEX'

-- Analyst data - Draft and Published value rowset
-- This query returns Tickers and Index data
-- Since there may not be Rating/Target Price for Index, Use Securities2 and left join with vFinancialNumbersLatest, FinancialNumberTypes
SELECT
  TL.Ticker,
  TL.SecurityId,
  VFT.FinancialNumberTypeId,
  VFT.FinancialNumberType,
  FN.CurCode,
  FN.FinancialPeriodId,
  CONVERT(varchar,FN.Value)  AS LiveValue,
  CONVERT(varchar,FN2.Value) AS DraftValue,
  TL.BaseYear,
  VFT.ShortName AS Description,
  TL.Company,
  ISNULL(TL.Alias, '') AS Alias,
  TL.IndicateChange,
  TL.DisplayNo
INTO #TmpAnalystDataDraftLive
FROM #TickerList TL
INNER JOIN FinancialNumberTypes VFT ON  VFT.FinancialNumberType IN ('RATING', 'TARGETPRICE')
-- Only data for active ticker coverage (not dropped/suspended) using active CoverageId
LEFT JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = TL.SecurityId
                                        AND FN.CoverageId = TL.CoverageId
                                        AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                        AND FN.IsDraft                = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                        AND FN2.CoverageId = TL.CoverageId
                                        AND FN2.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                        AND FN2.IsDraft               = 1  -- Draft

-- Marketdata fields - if override else bloomberg
SELECT
  vmd.SecurityId,
  MAX(CASE WHEN vmd.FinancialNumberType = 'CRNCY' AND TL.TickerType = 'STOCK'
           THEN vmd.Value ELSE '' END) AS Cur,
  MAX(CASE vmd.FinancialNumberType WHEN 'CLOSEDATE'       THEN vmd.Value ELSE '' END) AS CloseDate,
  MAX(CASE vmd.FinancialNumberType WHEN 'CLOSEPRICE'      THEN vmd.Value ELSE '' END) AS ClosePrice,

  MAX(CASE vmd.FinancialNumberType WHEN 'CHG_PCT_1YR'     THEN vmd.Value ELSE '' END) AS Perf1YrTicker,
  MAX(CASE md2.FinancialNumberType WHEN 'CHG_PCT_1YR'     THEN md2.Value ELSE '' END) AS Perf1YrIndex,
  MAX(CASE vmd.FinancialNumberType WHEN 'CHG_PCT_1YR'     THEN
                                                                    CASE
                                                                      WHEN TL.TickerType = 'INDEX'
                                                                      THEN ''
                                                                      WHEN IsNumeric(vmd.Value)= 0 OR IsNumeric(md2.Value)= 0
                                                                      THEN 'NA'
                                                                      ELSE CONVERT(VARCHAR,(CAST(vmd.value AS float) - CAST(md2.value AS float)))
                                                                    END
                                                                  END) AS Perf1Yr,

  MAX(CASE vmd.FinancialNumberType WHEN 'CHG_PCT_YTD'     THEN vmd.Value ELSE '' END) AS PerfYtdTicker,
  MAX(CASE md2.FinancialNumberType WHEN 'CHG_PCT_YTD'     THEN md2.Value ELSE '' END) AS PerfYtdIndex,
  MAX(CASE vmd.FinancialNumberType WHEN 'CHG_PCT_YTD'     THEN
                                                                    CASE
                                                                       WHEN TL.TickerType = 'INDEX'
                                                                       THEN ''
                                                                       WHEN IsNumeric(vmd.Value)= 0 OR IsNumeric(md2.Value)= 0
                                                                       THEN 'NA'
                                                                       ELSE CONVERT(VARCHAR,(CAST(vmd.value AS float) - CAST(md2.value AS float)))
                                                                    END
                                                                  END) AS PerfYtd,

  MAX(CASE vmd.FinancialNumberType WHEN 'EQY_DVD_YLD_IND' THEN vmd.Value ELSE '' END) AS DivYld,

  MAX(CASE vmd.FinancialNumberType WHEN 'FXRATE' THEN vmd.Value ELSE '' END) AS FxRate,
  MAX(CASE vmd.FinancialNumberType WHEN 'EV' THEN vmd.UnitValue ELSE '' END) AS EV

INTO #TmpMarketdata
FROM #TickerList TL
LEFT JOIN vMarketData vmd ON vmd.SecurityID = TL.SecurityId
                          AND vmd.FinancialNumberTypeId IN (SELECT FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType IN
                                   ('CLOSEDATE', 'CLOSEPRICE', 'CRNCY', 'CHG_PCT_1YR', 'CHG_PCT_YTD', 'EQY_DVD_YLD_IND', 'FXRATE' , 'EV'))
LEFT JOIN vMarketData md2 ON md2.SecurityID = TL.PrimaryIndexId AND vmd.FinancialNumberTypeId = md2.FinancialNumberTypeId
GROUP BY vmd.SecurityId

-- Estimates eps data - Draft and Published value rowset
-- Tickers - FY0, FY1, FY2
-- Indexes - If TickerBaseYearMajority > IndexBaseYearFirst then FY1, FY2, FY3 else FY0, FY1, FY2
SELECT
  TL.Ticker,
  TL.SecurityId,
  VFT.FinancialNumberTypeId,
  VFT.FinancialNumberType,
  CASE WHEN TL.TickerType = 'STOCK' THEN CONVERT(varchar, FSS.CurCode) ELSE '' END AS CurCode,
  TL.PrimaryModelCur,
  FP.FinancialPeriodId,
  CONVERT(varchar,FN.Value)  AS LiveValue,
  CONVERT(varchar,FN2.Value) AS DraftValue,
  TL.BaseYear,
  CASE WHEN TL.TickerType = 'STOCK' THEN VFT.ShortName ELSE '' END AS Description,
  TL.IndicateChange,
  TL.TickerType,
  FP.FinancialPeriod
INTO #TmpEpsEstimatesDraftLive
FROM #TickerList TL
INNER JOIN FinancialNumberTypes VFT ON VFT.FinancialNumberTypeId = TL.TickerTableEpsId
CROSS JOIN FinancialPeriods FP
-- Only data for active ticker coverage (not dropped/suspended) using active CoverageId
LEFT JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = TL.SecurityId
                                        AND ( FN.CoverageId = TL.CoverageId OR FN.CoverageId IS NULL)  -- NULL for Indexes
                                        AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                        AND FN.FinancialPeriodId = FP.FinancialPeriodId
                                        AND FN.IsDraft                = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                        AND ( FN.CoverageId = TL.CoverageId OR FN.CoverageId IS NULL)
                                        AND FN2.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                        AND FN2.FinancialPeriodId = FP.FinancialPeriodId
                                        AND FN2.IsDraft               = 1  -- Draft
LEFT JOIN FinancialSecuritySettings FSS ON FSS.SecurityId = TL.SecurityId
WHERE (TL.TickerType = 'STOCK' AND FP.FinancialPeriod IN ('FY0','FY1','FY2'))
       OR
      (Tl.TickerType = 'INDEX' AND FP.FinancialPeriod IN ('FY0','FY1','FY2','FY3'))


-- Calculate FX Cross Rate by Ticker
SELECT DISTINCT M.Securityid, M.Cur, M.FxRate, M.EV,
       E.CurCode, E.PrimaryModelCur,
       CONCAT(E.PrimaryModelCur, M.Cur) AS FXCrossTicker,
       'FXCrossRate' = ( CASE
                            WHEN M.Cur <> E.PrimaryModelCur
                            THEN (SELECT MAX(Value) FROM vBloombergFXLatest WHERE BloombergMnemonic = 'PRIOR_CLOSE_MID'
                                                                              AND Ticker = E.PrimaryModelCur + M.Cur COLLATE SQL_Latin1_General_CP1_CS_AS)
                            ELSE '1'
                          END  )
INTO #TmpFxRates
FROM #TmpMarketdata M
JOIN #TmpEpsEstimatesDraftLive E ON M.Securityid = E.Securityid

-- Valuations eps data - Draft and Published value rowset
-- Conditionally align indexes FY with tickers FY
-- Tickers - FY0, FY1, FY2
-- Indexes - If TickerBaseYearMajority > IndexBaseYearFirst then FY1, FY2, FY3 else FY0, FY1, FY2
SELECT
  TL.Ticker,
  TL.SecurityId,
  VFT.FinancialNumberTypeId,
  VFT.FinancialNumberType,
  CASE WHEN TL.TickerType = 'STOCK' THEN TL.CurrencyCode ELSE '' END AS CurCode,
  FP.FinancialPeriodId,
  CONVERT(varchar,FN.Value)  AS LiveValue,
  CONVERT(varchar,FN2.Value) AS DraftValue,
  TL.BaseYear,
  CASE WHEN TL.TickerType = 'STOCK' THEN VFT.ShortName ELSE '' END AS Description,
  FP.FinancialPeriod
INTO #TmpValuationsDraftLive
FROM #TickerList TL
INNER JOIN FinancialNumberTypes VFT ON VFT.FinancialNumberTypeId = TL.TickerTableValuationId
CROSS JOIN FinancialPeriods FP
LEFT JOIN vValuationsLatest FN  ON FN.SecurityId = TL.SecurityId
                                  AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                  AND FN.FinancialPeriodId = FP.FinancialPeriodId
                                  AND FN.IsDraft                = 0  -- Live
LEFT JOIN vValuationsLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                  AND FN2.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                  AND FN2.FinancialPeriodId = FP.FinancialPeriodId
                                  AND FN2.IsDraft               = 1  -- Draft
WHERE (TL.TickerType = 'STOCK' AND FP.FinancialPeriod IN ('FY0','FY1','FY2'))
       OR
      (Tl.TickerType = 'INDEX' AND FP.FinancialPeriod IN ('FY0','FY1','FY2','FY3'))

-- Get Latest Financials data in a XML variable
SET @FinancialsXml =
(
SELECT * FROM
(
SELECT
  1                      AS tag,
  null                   AS parent,
  NULL                   AS [TickerTableBody!1!TickerTableBody],

  NULL                   AS [TickerTableBodyRow!2!securityId],
  NULL                   AS [TickerTableBodyRow!2!ticker],
  NULL                   AS [TickerTableBodyRow!2!alias],

  -- Rating, target
  NULL                   AS [TickerTableBodyRow!2!baseYear],
  NULL                   AS [TickerTableBodyRow!2!rating],
  NULL                   AS [TickerTableBodyRow!2!isBoldRating],
  NULL                   AS [TickerTableBodyRow!2!targetPrice],
  NULL                   AS [TickerTableBodyRow!2!isBoldTargetPrice],

  -- Market data
  NULL                   AS [TickerTableBodyRow!2!tradeCurrency],
  NULL                   AS [TickerTableBodyRow!2!closeDate],
  NULL                   AS [TickerTableBodyRow!2!closePrice],
  NULL                   AS [TickerTableBodyRow!2!perfType],
  NULL                   AS [TickerTableBodyRow!2!perf],
  NULL                   AS [TickerTableBodyRow!2!divYld],
  NULL                   AS [TickerTableBodyRow!2!fxRate],
  NULL                   AS [TickerTableBodyRow!2!ev],

  -- EPS
  NULL                   AS [TickerTableBodyRow!2!epsType],
  NULL                   AS [TickerTableBodyRow!2!epsCurrency],
  NULL                   AS [TickerTableBodyRow!2!epsFY0],
  NULL                   AS [TickerTableBodyRow!2!isBoldEpsFY0],
  NULL                   AS [TickerTableBodyRow!2!epsFY1],
  NULL                   AS [TickerTableBodyRow!2!isBoldEpsFY1],
  NULL                   AS [TickerTableBodyRow!2!epsFY2],
  NULL                   AS [TickerTableBodyRow!2!isBoldEpsFY2],

  -- Valuations
  NULL                   AS [TickerTableBodyRow!2!valType],
  NULL                   AS [TickerTableBodyRow!2!valFY0],
  NULL                   AS [TickerTableBodyRow!2!isBoldValFY0],
  NULL                   AS [TickerTableBodyRow!2!valFY1],
  NULL                   AS [TickerTableBodyRow!2!isBoldValFY1],
  NULL                   AS [TickerTableBodyRow!2!valFY2],
  NULL                   AS [TickerTableBodyRow!2!isBoldValFY2],

  NULL                   AS [TickerTableBodyRow!2!company],
  NULL                   AS [TickerTableBodyRow!2!dispOrder],
  NULL                   AS [TickerTableBodyRow!2!displayNo]

UNION ALL

-- Ticker - 1st row - draft or live
SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [TickerTableBody!1!TickerTableBody],

  A.SecurityID           AS [TickerTableBodyRow!2!securityId],
  MAX(A.Ticker)          AS [TickerTableBodyRow!2!ticker],
  MAX(A.Alias)           AS [TickerTableBodyRow!2!alias],

  MAX(A.BaseYear)        AS [TickerTableBodyRow!2!baseYear],

  -- rating value
  MAX(CASE WHEN A.FinancialNumberType = 'RATING' AND A.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN A.DraftValue
           WHEN A.FinancialNumberType = 'RATING' AND A.LiveValue  IS NOT NULL THEN A.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!rating],
  -- isBold attribute
  MAX(CASE
    WHEN A.FinancialNumberType = 'RATING' AND A.DraftValue IS NOT NULL AND A.LiveValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
  END)                      AS [TickerTableBodyRow!2!isBoldRating],

  -- target price value
  MAX(CASE WHEN A.FinancialNumberType = 'TARGETPRICE' AND A.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN A.DraftValue
           WHEN A.FinancialNumberType = 'TARGETPRICE' AND A.LiveValue  IS NOT NULL THEN A.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!targetPrice],
  -- isBold attribute
  MAX(CASE
    WHEN A.FinancialNumberType = 'TARGETPRICE' AND A.DraftValue IS NOT NULL AND A.LiveValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
  END)                      AS [TickerTableBodyRow!2!isBoldTargetPrice],

  -- Market data fields
  MAX(M.Cur)                   AS [TickerTableBodyRow!2!tradeCurrency],
  MAX(CASE WHEN ISDATE(M.CloseDate) = 0 THEN ''
  	       ELSE DATENAME(dd, M.CloseDate) + ' ' + LEFT(DATENAME(mm, M.CloseDate),3) + ' ' + DATENAME(yy, M.CloseDate)
      END)                     AS [TickerTableBodyRow!2!closeDate],

  MAX(M.ClosePrice)            AS [TickerTableBodyRow!2!closePrice],
  'TTM'                        AS [TickerTableBodyRow!2!perfType],
  MAX(M.Perf1Yr)               AS [TickerTableBodyRow!2!perf],
  MAX(M.DivYld)                AS [TickerTableBodyRow!2!divYld],
  MAX(CASE WHEN ISNULL(F.FxRate, '') <>'' THEN F.FxRate
           WHEN ISNULL(F.FXCrossRate, '') <>'' THEN F.FXCrossRate
           ELSE ' '
           END)
                               AS [TickerTableBodyRow!2!fxRate],
  MAX(M.EV)                    AS [TickerTableBodyRow!2!ev],

  -- EPS
  -- Conditionally align indexes FY with tickers FY
  -- Tickers - FY0, FY1, FY2
  -- Indexes - If TickerBaseYearMajority > IndexBaseYearFirst then FY1, FY2, FY3 else FY0, FY1, FY2
  MAX(E.Description)           AS [TickerTableBodyRow!2!epsType],
  MAX(E.CurCode)               AS [TickerTableBodyRow!2!epsCurrency],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                  WHEN E.FinancialPeriodId = 2 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 2 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
              END
           ELSE
               CASE
                  WHEN E.FinancialPeriodId = 1 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 1 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
               END
      END) AS [TickerTableBodyRow!2!epsFY0],

  -- isBold attribute - when draft and live value exists
  MAX(CASE WHEN E.FinancialPeriodId = 1 AND E.LiveValue  IS NOT NULL AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldEpsFY0],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                  WHEN E.FinancialPeriodId = 3 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 3 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
              END
           ELSE
               CASE
                  WHEN E.FinancialPeriodId = 2 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 2 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
               END
      END) AS [TickerTableBodyRow!2!epsFY1],

  MAX(CASE WHEN E.FinancialPeriodId = 2 AND E.LiveValue  IS NOT NULL AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldEpsFY1],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                  WHEN E.FinancialPeriodId = 4 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 4 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
              END
           ELSE
               CASE
                  WHEN E.FinancialPeriodId = 3 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 3 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
               END
      END) AS [TickerTableBodyRow!2!epsFY2],

  MAX(CASE WHEN E.FinancialPeriodId = 3 AND E.LiveValue  IS NOT NULL AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldEpsFY2],

  -- Valuations
  -- Conditionally align indexes FY with tickers FY
  -- Tickers - FY0, FY1, FY2
  -- Indexes - If TickerBaseYearMajority > IndexBaseYearFirst then FY1, FY2, FY3 else FY0, FY1, FY2
  MAX(V.Description)   AS [TickerTableBodyRow!2!valType],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                 WHEN V.FinancialPeriodId = 2 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 2 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
              END
           ELSE
               CASE
                 WHEN V.FinancialPeriodId = 1 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 1 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
               END
      END) AS [TickerTableBodyRow!2!valFY0],
  -- isBold attribute - when draft and live value exists
  MAX(CASE WHEN V.FinancialPeriodId = 1 AND V.LiveValue  IS NOT NULL AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldValFY0],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                 WHEN V.FinancialPeriodId = 3 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 3 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
              END
           ELSE
               CASE
                 WHEN V.FinancialPeriodId = 2 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 2 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
               END
      END) AS [TickerTableBodyRow!2!valFY1],

  MAX(CASE WHEN V.FinancialPeriodId = 2 AND V.LiveValue  IS NOT NULL AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldValFY1],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                 WHEN V.FinancialPeriodId = 4 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 4 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
              END
           ELSE
               CASE
                 WHEN V.FinancialPeriodId = 3 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 3 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
               END
      END) AS [TickerTableBodyRow!2!valFY2],

  MAX(CASE WHEN V.FinancialPeriodId = 3 AND V.LiveValue  IS NOT NULL AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldvalFY2],

  MAX(A.Company)               AS [TickerTableBodyRow!2!company],
  1                            AS [TickerTableBodyRow!2!dispOrder],
  MAX(A.DisplayNo)             AS [TickerTableBodyRow!2!displayNo]

FROM #TmpAnalystDataDraftLive A
LEFT JOIN #TmpMarketdata M ON M.SecurityId = A.SecurityId
LEFT JOIN #TmpEpsEstimatesDraftLive E ON E.SecurityId = A.SecurityId
LEFT JOIN #TmpValuationsDraftLive V ON V.SecurityId = A.SecurityId
LEFT JOIN #TmpFxRates F ON F.SecurityId = A.SecurityId

GROUP BY A.SecurityId, E.SecurityId

UNION ALL

-- Ticker - 2nd row - live if draft exists
SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [TickerTableBody!1!TickerTableBody],

  A.SecurityID            AS [TickerTableBodyRow!2!securityId],
  'OLD'                   AS [TickerTableBodyRow!2!ticker],
  ''                      AS [TickerTableBodyRow!2!alias],

  ''                      AS [TickerTableBodyRow!2!baseYear],
  -- rating value
  MAX(CASE WHEN A.FinancialNumberType = 'RATING' AND A.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN A.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!rating],
  NULL AS [TickerTableBodyRow!2!isBoldRating],
  -- target price value
  MAX(CASE WHEN A.FinancialNumberType = 'TARGETPRICE' AND A.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN A.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!targetprice],
  NULL AS [TickerTableBodyRow!2!isBoldTargetPrice],

  -- Market data
  ''                     AS [TickerTableBodyRow!2!tradeCurrency],
  ''                     AS [TickerTableBodyRow!2!closeDate],
  ''                     AS [TickerTableBodyRow!2!closePrice],
  ''                     AS [TickerTableBodyRow!2!perfType],
  ''                     AS [TickerTableBodyRow!2!perf],
  ''                     AS [TickerTableBodyRow!2!divYld],
  MAX(CASE WHEN ISNULL(F.FxRate, '') <>'' THEN F.FxRate
           ELSE F.FXCrossRate
           END)
                         AS [TickerTableBodyRow!2!fxRate],
  ''                     AS [TickerTableBodyRow!2!ev],

  -- Estimates
  ''                     AS [TickerTableBodyRow!2!epsType],
  ''                     AS [TickerTableBodyRow!2!epsCurrency],

  MAX(CASE WHEN E.FinancialPeriodId = 1 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!epsFY0],
  ''                     AS [TickerTableBodyRow!2!isBoldEpsFY0],
  MAX(CASE WHEN E.FinancialPeriodId = 2 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!epsFY1],
  ''                     AS [TickerTableBodyRow!2!isBoldEpsFY1],
  MAX(CASE WHEN E.FinancialPeriodId = 3 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!epsFY2],
  ''                     AS [TickerTableBodyRow!2!isBoldEpsFY2],

  -- Valuations
  ''                     AS [TickerTableBodyRow!2!valType],
  ''                     AS [TickerTableBodyRow!2!valFY0],
  ''                     AS [TickerTableBodyRow!2!isBoldValFY0],
  ''                     AS [TickerTableBodyRow!2!valFY1],
  ''                     AS [TickerTableBodyRow!2!isBoldValFY1],
  ''                     AS [TickerTableBodyRow!2!valFY2],
  ''                     AS [TickerTableBodyRow!2!valFY0],

  -- isBold attribute - when draft and live value exists
  MAX(A.Company)               AS [TickerTableBodyRow!2!company],
  2                            AS [TickerTableBodyRow!2!dispOrder],
  MAX(A.DisplayNo)             AS [TickerTableBodyRow!2!displayNo]
FROM #TmpAnalystDataDraftLive A
LEFT JOIN #TmpEpsEstimatesDraftLive E ON E.SecurityId = A.SecurityId
LEFT JOIN #TmpValuationsDraftLive V ON V.SecurityId = A.SecurityId
LEFT JOIN #TmpFxRates F ON F.SecurityId = A.SecurityId
WHERE A.IndicateChange = 'yes'
-- Show old row only if draft and live row both exists - analyst rating/TP/estimate data
-- Launch call - will have draft and no live data
AND
(  (A.DraftValue IS NOT NULL AND A.LiveValue IS NOT NULL)
    OR
   (E.DraftValue IS NOT NULL AND E.LiveValue IS NOT NULL)
)

GROUP BY A.SecurityId, E.SecurityId

) X
ORDER BY [TickerTableBodyRow!2!displayNo], [TickerTableBodyRow!2!dispOrder]
FOR XML Explicit
)

-- For v1(IndicateChange=no,yes), use the latest FinancialNumbers data - applicable for ticker table UI screens or from word template
IF @RptPubNo = 0 AND NOT EXISTS(SELECT * FROM #TickerList WHERE IndicateChange = 'last')
BEGIN
  SELECT @FinancialsXml
  RETURN
END

-- Get the PublicationsXml - lastRpt PubNo
SELECT @PublicationsXml = TickerTableXml FROM PublicationsXML  WHERE PubNo = @RptPubNo

-- Add column to store the Ticker Table XML for tickers with indicateChange="last" [lastChangePubNo]
ALTER TABLE #TickerList ADD LastChangeTickerTableXml XML

-- Update Ticker Table XML for tickers with indicateChange="last"
UPDATE #TickerList
SET #TickerList.LastChangeTickerTableXml = PX2.TickerTableXml
FROM PublicationsXML PX2
WHERE PX2.PubNo = #TickerList.LastChangePubNo

-- Selectively fetch applicable rows (by ticker, old/new row) from one of the 3 xml sources
-- use displayNo from the provided ticker list, not from old PubXml
-- Source: @FinancialsXml
SELECT
  CONVERT(varchar(MAX),F.Loc.query('.')) AS result,
  TL.DisplayNo  AS displayNo,
  F.Loc.value('./@dispOrder',     'INT') AS dispOrder,
  F.Loc.value('./@ticker',        'VARCHAR(MAX)') AS ticker,
  F.Loc.value('./@securityId',    'INT') AS securityId,
  TL.SourceLive, TL.SourceOld
INTO #TickerTableXml
FROM #TickerList TL
JOIN @FinancialsXml.nodes('/TickerTableBody/TickerTableBodyRow') F(Loc)
     ON TL.SecurityId = CAST(F.Loc.value('@securityId', 'INT') AS INT)
WHERE (TL.SourceLive = 'FN' AND CAST(F.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) != 'OLD')
       OR
      (TL.SourceOld = 'FN'  AND
       CAST(F.Loc.value('@securityId', 'INT') AS INT) = TL.SecurityId AND
       CAST(F.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) = 'OLD')

UNION

-- Source: @PublicationsXml for last published report
SELECT
  CONVERT(varchar(MAX),P.Loc.query('.')) AS result,
  TL.DisplayNo  AS displayNo,
  P.Loc.value('./@dispOrder',     'INT') AS dispOrder,
  P.Loc.value('./@ticker',        'VARCHAR(MAX)') AS ticker,
  P.Loc.value('./@securityId',    'INT') AS securityId,
  TL.SourceLive, TL.SourceOld
FROM #TickerList TL
JOIN @PublicationsXml.nodes('/TickerTable/TickerTableBody/TickerTableBodyRow') P(Loc)
     ON TL.SecurityId = CAST(P.Loc.value('@securityId', 'INT') AS INT)
WHERE (TL.SourceLive = 'PX' AND CAST(P.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) != 'OLD')
       OR
      (TL.SourceOld = 'PX' AND
       CAST(P.Loc.value('@securityId', 'INT') AS INT) = TL.SecurityId AND
       CAST(P.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) = 'OLD')

UNION

-- Source: @PublicationsXml for last change report (last n days)
SELECT
  CONVERT(varchar(MAX),P2.Loc.query('.')) AS result,
  TL.DisplayNo  AS displayNo,
  P2.Loc.value('./@dispOrder',     'INT') AS dispOrder,
  P2.Loc.value('./@ticker',        'VARCHAR(MAX)') AS ticker,
  P2.Loc.value('./@securityId',    'INT') AS securityId,
  TL.SourceLive, TL.SourceOld
FROM #TickerList TL
CROSS APPLY TL.LastChangeTickerTableXml.nodes('/TickerTable/TickerTableBody/TickerTableBodyRow') AS P2(Loc)
WHERE TL.SecurityId = CAST(P2.Loc.value('@securityId', 'INT') AS INT)
AND (TL.SourceLive = 'PXLAST' AND CAST(P2.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) != 'OLD')
     OR
   (TL.SourceOld = 'PXLAST'  AND
    CAST(P2.Loc.value('@securityId', 'INT') AS INT) = TL.SecurityId AND
    CAST(P2.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) = 'OLD')
ORDER BY 2, 5, 3

-- Combine individual ticker rows as one string
SELECT @TickerTableXml = STUFF(
                        (SELECT CHAR(13) + result
                           FROM #TickerTableXml
                            FOR XML PATH(''),type).value('.','NVARCHAR(MAX)'),1,1,'')
SELECT @TickerTableXml = '<TickerTableBody>' + CHAR(13) + @TickerTableXml + CHAR(13) + '</TickerTableBody>'
SELECT CAST(@TickerTableXml AS XML)

DROP TABLE #TickerList

SET NOCOUNT OFF




GO

ALTER PROCEDURE [dbo].[spGetTickerTableHeaderFooter]
  @inXml xml
AS
BEGIN

DECLARE
  @BaseYear varchar(4),
  @EpsType varchar(30),
  @ValType varchar(30),
  @CloseDate varchar(30),
  @Value varchar(max),
  @hDoc int,
  @PerfType varchar(30),
  @DefaultBaseYear varchar(4),
  @DefaultEpsType varchar(30),
  @DefaultValType varchar(30),
  @DefaultPerfType varchar(30),
  @DefaultCloseDate varchar(30),
  @PubDate datetime,
  @Title varchar(255),
  @Type varchar(31),
  @PubNo int,
  @Version int,
  @TickerBaseYearMajority int,
  @IndexBaseYearFirst int

SET NOCOUNT ON

EXEC sp_xml_preparedocument @hDoc OUTPUT, @inXml

--Get report meta data
SELECT @PubDate = X.PubDate, @Title = X.Title, @Type = X.Type
FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
WITH (PubDate  datetime     '@pubDate',
      Title    varchar(255) '@title',
      Type     varchar(31)  '@type',
      Version  int          '@version'
      ) X

--Check for resubmit and retrieve pubno & version
EXEC spCheckForResubmits @PubDate, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

--If resubmit retrieve tickertable headers from previously published report
IF @PubNo > 0
BEGIN
  DECLARE @hDoc1 int,@TickerTableXml xml

  SELECT @TickerTableXml = TickerTableXml FROM PublicationsXml WHERE PubNo = @PubNo

  EXEC sp_xml_preparedocument @hDoc1 OUTPUT, @TickerTableXml

  SELECT @DefaultBaseYear = X.BaseYear, @DefaultEpsType = X.EpsType, @DefaultValType = X.ValType, @DefaultCloseDate = X.CloseDate
  FROM OPENXML (@hDoc1, 'TickerTable/TickerTableHeader', 1)
  WITH (BaseYear  int         '@baseYear',
        PerfType  varchar(30) '@perfType',
        EpsType   varchar(30) '@epsType',
        ValType   varchar(30) '@valType',
        CloseDate varchar(30) '@closeDate'
       ) X

  EXEC sp_xml_removedocument @hDoc1

END
ELSE
--else retrieve tickertable header from DocumentInfo xml
BEGIN
  SELECT @DefaultBaseYear = X.BaseYear, @DefaultEpsType = X.EpsType, @DefaultValType = X.ValType, @DefaultCloseDate = X.CloseDate
  FROM OPENXML (@hDoc, 'DocumentInfo/TickerTableHeader', 1)
  WITH (BaseYear  int         '@baseYear',
        PerfType  varchar(30) '@perfType',
        EpsType   varchar(30) '@epsType',
        ValType   varchar(30) '@valType',
        CloseDate varchar(30) '@closeDate'
       ) X
END

--Retrieve tickers from Securities collection of input xml and calculate option buttons (No,Yes,Last) settings for each ticker
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, X.SecurityId, X.Ticker, X.Analyst
INTO #TickerList
FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
WITH (securityId  int          '@id',
      ticker      varchar(30)  '@ticker',
      analyst     varchar(100) '@analyst'
     ) X

SELECT T.DisplayNo, T.SecurityId, T.Ticker, FCS.BaseYear, FNT.FullName EPSType, FNT2.FullName ValType,M.Value CloseDate,S.TickerType
INTO #TmpTickerTableHeaderData
FROM #TickerList T
JOIN Securities2 S ON T.SecurityId = S.SecurityId
JOIN FinancialCompanySettings FCS ON S.CompanyId = FCS.CompanyId
JOIN FinancialNumberTypes FNT ON FCS.TickerTableEpsId = FNT.FinancialNumberTypeId
JOIN FinancialNumberTypes FNT2 ON FCS.TickerTableValuationId = FNT2.FinancialNumberTypeId
JOIN vMarketData M ON S.SecurityId = M.SecurityId
WHERE M.FinancialNumberType = 'CloseDate' AND ISDATE(M.Value) != 0

SELECT BaseYear,Count(BaseYear) BaseYearCount INTO #TmpBaseYearOptions FROM #TmpTickerTableHeaderData WHERE TickerType = 'STOCK' GROUP BY BaseYear
SELECT DISTINCT EpsType INTO #TmpEpsTypeOptions FROM #TmpTickerTableHeaderData WHERE TickerType = 'STOCK'
SELECT DISTINCT ValType INTO #TmpValTypeOptions FROM #TmpTickerTableHeaderData WHERE TickerType = 'STOCK'

--If no user selected headers, apply default rules (majority for base year, eps type & val type)
IF (@DefaultBaseYear is null or @DefaultBaseYear = 0)
SELECT @DefaultBaseYear = max(BaseYear) FROM #TmpBaseYearOptions WHERE BaseYearCount = (SELECT MAX(BaseYearCount) FROM #TmpBaseYearOptions)
IF (@DefaultEpsType is null or @DefaultEpsType = '')
  SELECT TOP 1 @DefaultEpsType = EPSType FROM #TmpTickerTableHeaderData WHERE TickerType = 'STOCK' GROUP BY EPSType ORDER BY count(EPSType) DESC
IF (@DefaultValType is null or @DefaultValType = '')
  SELECT TOP 1 @DefaultValType = ValType FROM #TmpTickerTableHeaderData WHERE TickerType = 'STOCK' GROUP BY ValType ORDER BY count(ValType) DESC
IF (@DefaultCloseDate is null or @DefaultCloseDate = '')
 SELECT @DefaultCloseDate = convert(varchar(12),max(Convert(Datetime,CloseDate)),107) FROM #TmpTickerTableHeaderData WHERE isdate(CloseDate) = 1

-- Indexes - Get BaseYear of first index
SELECT TOP 1 @IndexBaseYearFirst = BaseYear FROM #TmpTickerTableHeaderData WHERE TickerType = 'INDEX'

-- Tickers - Get BaseYear majority
SELECT @TickerBaseYearMajority = @DefaultBaseYear

-- Indexes - If TickerBaseYearMajority > IndexBaseYearFirst then increase BaseYear by 1 consistent with spGetCompanyEpsXml and spGetTickerTableApiXml
IF @TickerBaseYearMajority > @IndexBaseYearFirst
BEGIN
  UPDATE #TmpTickerTableHeaderData
  SET BaseYear = BaseYear + 1
  WHERE TickerType = 'Index'
END

--If resubmit retrieve tickertable footer from previously published report
DECLARE
  @BaseYearFooter VARCHAR(max),
  @CloseDateFooter VARCHAR(max),
  @PerfTypeFooter VARCHAR(max),
  @EpsTypeFooter VARCHAR(max),
  @ValTypeFooter VARCHAR(max)

IF @PubNo > 0
BEGIN
  DECLARE @hDoc2 int,@TickerTableXml2 xml

  SELECT @TickerTableXml2 = TickerTableXml FROM PublicationsXml WHERE PubNo = @PubNo

  EXEC sp_xml_preparedocument @hDoc2 OUTPUT, @TickerTableXml2

  SELECT @BaseYearFooter = X.BaseYear, @EpsTypeFooter = X.EpsType, @ValTypeFooter = X.ValType, @CloseDateFooter = X.CloseDate
  FROM OPENXML (@hDoc2, 'TickerTable/TickerTableFooter', 1)
  WITH (BaseYear  varchar(30) '@baseYear',
        EpsType   varchar(30) '@epsType',
        ValType   varchar(30) '@valType',
        CloseDate varchar(30) '@closeDate'
       ) X

  EXEC sp_xml_removedocument @hDoc2
END
ELSE
BEGIN

  SELECT @BaseYearFooter = '', @EpsTypeFooter = '', @ValTypeFooter = '', @CloseDateFooter = ''
  --BaseYear Footer
  SELECT BaseYear, STUFF((SELECT ',' + Ticker FROM #TmpTickerTableHeaderData T1 WHERE T1.BaseYear = T2.BaseYear AND BaseYear <> @DefaultBaseYear ORDER BY DisplayNo FOR XML PATH(''),type).value('.','nvarchar(max)'),1,1,'') AS [Value]
  INTO #TmpBaseYears
  FROM #TmpTickerTableHeaderData T2
  WHERE BaseYear <> @DefaultBaseYear
  GROUP BY T2.BaseYear

  SELECT TOP 1 @BaseYear = BaseYear, @Value = Value FROM #TmpBaseYears ORDER BY BaseYear
  WHILE @@ROWCOUNT = 1
  BEGIN
    SELECT @BaseYearFooter = @BaseYearFooter + @Value + ' base year is ' + @BaseYear + ';'
    SELECT TOP 1 @BaseYear = BaseYear, @Value = Value FROM #TmpBaseYears WHERE BaseYear > @BaseYear ORDER BY BaseYear
  END

  --EPSType Footer
  SELECT EpsType, STUFF((SELECT ',' + Ticker FROM #TmpTickerTableHeaderData T1 WHERE T1.TickerType = 'STOCK' AND T1.EpsType = T2.EpsType AND EpsType <> @DefaultEpsType ORDER BY DisplayNo FOR XML PATH(''),type).value('.','nvarchar(max)'),1,1,'') AS [Value]

  INTO #TmpEpsTypes
  FROM #TmpTickerTableHeaderData T2
  WHERE EpsType <> @DefaultEpsType
  GROUP BY T2.EpsType

  SELECT TOP 1 @EpsType = EpsType, @Value = Value FROM #TmpEpsTypes ORDER BY EpsType
  WHILE @@ROWCOUNT = 1
  BEGIN
    SELECT @EpsTypeFooter = @EpsTypeFooter + @Value + ' eps type is ' + @EpsType + ';'
    SELECT TOP 1 @EpsType = EpsType, @Value = Value FROM #TmpEpsTypes WHERE EpsType > @EpsType ORDER BY EpsType
  END

  --ValType Footer
  SELECT ValType, STUFF((SELECT ',' + T1.Ticker FROM #TmpTickerTableHeaderData T1 WHERE T1.TickerType = 'STOCK' AND T1.ValType = T2.ValType AND ValType <> @DefaultValType ORDER BY DisplayNo FOR XML PATH(''),type).value('.','nvarchar(max)'),1,1,'') AS [Value]
  INTO #TmpValTypes
  FROM #TmpTickerTableHeaderData T2
  WHERE
  T2.TickerType = 'STOCK' AND
  ValType <> @DefaultValType
  GROUP BY T2.ValType

  SELECT TOP 1 @ValType = ValType, @Value = Value FROM #TmpValTypes ORDER BY ValType
  WHILE @@ROWCOUNT = 1
  BEGIN
    SELECT @ValTypeFooter = @ValTypeFooter + @Value + ' valuation type is ' + @ValType + ';'
    SELECT TOP 1 @ValType = ValType, @Value = Value FROM #TmpValTypes WHERE ValType > @ValType ORDER BY ValType
  END

  --select @DefaultCloseDate -- fix needed??
  --CloseDate Footer
  SELECT CloseDate, STUFF((SELECT ',' + Ticker FROM #TmpTickerTableHeaderData T1 WHERE T1.TickerType = 'STOCK' AND T1.CloseDate = T2.CloseDate AND CloseDate <> @DefaultCloseDate ORDER BY DisplayNo FOR XML PATH(''),type).value('.','nvarchar(max)'),1,1,'')
AS [Value]
  INTO #TmpCloseDates
  FROM #TmpTickerTableHeaderData T2
  WHERE CAST(CloseDate as datetime) <> Cast(@DefaultCloseDate as datetime)
  GROUP BY T2.CloseDate

  SELECT TOP 1 @CloseDate = CloseDate, @Value = Value FROM #TmpCloseDates ORDER BY CloseDate
  WHILE @@ROWCOUNT = 1
  BEGIN
    SELECT @CloseDateFooter = @CloseDateFooter + @Value + ' close date is ' + @CloseDate + ';'
    SELECT TOP 1 @CloseDate = CloseDate, @Value = Value FROM #TmpCloseDates WHERE CloseDate > @CloseDate ORDER BY CloseDate
  END
END

--Generate output securities collection xml from the calculated values
SELECT
  1                          AS tag,
  null                       AS parent,
  null                       AS [Root!1!!element],
  null                       AS [TickerTableHeader!2!baseYear],
  null                       AS [TickerTableHeader!2!epsType],
  null                       AS [TickerTableHeader!2!valType],
  null                       AS [TickerTableHeader!2!perfType],
  null                       AS [TickerTableHeader!2!closeDate],
  null                       AS [BaseYearOptions!3!!element],
  null                       AS [Option!4!value],
  null                       AS [EpsTypeOptions!5!!element],
  null                       AS [Option!6!value],
  null                       AS [ValTypeOptions!7!!element],
  null                       AS [Option!8!value],
  null                       AS [TickerTableFooter!9!baseYear],
  null                       AS [TickerTableFooter!9!epsType],
  null                       AS [TickerTableFooter!9!valType],
  null                       AS [TickerTableFooter!9!closeDate]

UNION ALL

SELECT
  2                          AS tag,
  1                          AS parent,
  null                       AS [Root!1!!element],
  @DefaultBaseYear           AS [TickerTableHeader!2!baseYear],
  @DefaultEpsType            AS [TickerTableHeader!2!epsType],
  @DefaultValType            AS [TickerTableHeader!2!valType],
  'TTM'                      AS [TickerTableHeader!2!perfType],
  @DefaultCloseDate          AS [TickerTableHeader!2!closeDate],
  null                       AS [BaseYearOptions!3!!element],
  null                       AS [Option!4!value],
  null                       AS [EpsTypeOptions!5!!element],
  null                       AS [Option!6!value],
  null                       AS [ValTypeOptions!7!!element],
  null                       AS [Option!8!value],
  null                       AS [TickerTableFooter!9!baseYear],
  null                       AS [TickerTableFooter!9!epsType],
  null                       AS [TickerTableFooter!9!valType],
  null                       AS [TickerTableFooter!9!closeDate]

UNION ALL

SELECT
  3                          AS tag,
  1                          AS parent,
  null                       AS [Root!1!!element],
  null                       AS [TickerTableHeader!2!baseYear],
  null                       AS [TickerTableHeader!2!epsType],
  null                       AS [TickerTableHeader!2!valType],
  null                       AS [TickerTableHeader!2!perfType],
  null                       AS [TickerTableHeader!2!closeDate],
  null                       AS [BaseYearOptions!3!!element],
  null                       AS [Option!4!value],
  null                       AS [EpsTypeOptions!5!!element],
  null                       AS [Option!6!value],
  null                       AS [ValTypeOptions!7!!element],
  null                       AS [Option!8!value],
  null                       AS [TickerTableFooter!9!baseYear],
  null                       AS [TickerTableFooter!9!epsType],
  null                       AS [TickerTableFooter!9!valType],
  null                       AS [TickerTableFooter!9!closeDate]

UNION ALL

SELECT
  4                          AS tag,
  3                          AS parent,
  null                       AS [Root!1!!element],
  null                       AS [TickerTableHeader!2!baseYear],
  null                       AS [TickerTableHeader!2!epsType],
  null                       AS [TickerTableHeader!2!valType],
  null                       AS [TickerTableHeader!2!perfType],
  null                       AS [TickerTableHeader!2!closeDate],
  null                       AS [BaseYearOptions!3!!element],
  BaseYear                   AS [Option!4!value],
  null                       AS [EpsTypeOptions!5!!element],
  null                       AS [Option!6!value],
  null                       AS [ValTypeOptions!7!!element],
  null                       AS [Option!8!value],
  null                       AS [TickerTableFooter!9!baseYear],
  null                       AS [TickerTableFooter!9!epsType],
  null                       AS [TickerTableFooter!9!valType],
  null                       AS [TickerTableFooter!9!closeDate]
FROM #TmpBaseYearOptions

UNION ALL

SELECT
  5                          AS tag,
  1                          AS parent,
  null                       AS [Root!1!!element],
  null                       AS [TickerTableHeader!2!baseYear],
  null                       AS [TickerTableHeader!2!epsType],
  null                       AS [TickerTableHeader!2!valType],
  null                       AS [TickerTableHeader!2!perfType],
  null                       AS [TickerTableHeader!2!closeDate],
  null                       AS [BaseYearOptions!3!!element],
  null                       AS [Option!4!value],
  null                       AS [EpsTypeOptions!5!!element],
  null                       AS [Option!6!value],
  null                       AS [ValTypeOptions!7!!element],
  null                       AS [Option!8!value],
  null                       AS [TickerTableFooter!9!baseYear],
  null                       AS [TickerTableFooter!9!epsType],
  null                       AS [TickerTableFooter!9!valType],
  null                       AS [TickerTableFooter!9!closeDate]

UNION ALL

SELECT
  6                          AS tag,
  5                          AS parent,
  null                       AS [Root!1!!element],
  null                       AS [TickerTableHeader!2!baseYear],
  null                       AS [TickerTableHeader!2!epsType],
  null                       AS [TickerTableHeader!2!valType],
  null                       AS [TickerTableHeader!2!perfType],
  null                       AS [TickerTableHeader!2!closeDate],
  null                       AS [BaseYearOptions!3!!element],
  null                       AS [Option!4!value],
  null                       AS [EpsTypeOptions!5!!element],
  EpsType                    AS [Option!6!value],
  null                       AS [ValTypeOptions!7!!element],
  null                       AS [Option!8!value],
  null                       AS [TickerTableFooter!9!baseYear],
  null                       AS [TickerTableFooter!9!epsType],
  null                       AS [TickerTableFooter!9!valType],
  null                       AS [TickerTableFooter!9!closeDate]
  FROM #TmpEpsTypeOptions

UNION ALL

SELECT
  7                          AS tag,
  1                          AS parent,
  null                       AS [Root!1!!element],
  null                       AS [TickerTableHeader!2!baseYear],
  null                       AS [TickerTableHeader!2!epsType],
  null                       AS [TickerTableHeader!2!valType],
  null                       AS [TickerTableHeader!2!perfType],
  null                       AS [TickerTableHeader!2!closeDate],
  null                       AS [BaseYearOptions!3!!element],
  null                       AS [Option!4!value],
  null                       AS [EpsTypeOptions!5!!element],
  null                       AS [Option!6!value],
  null                       AS [ValTypeOptions!7!!element],
  null                       AS [Option!8!value],
  null                       AS [TickerTableFooter!9!baseYear],
  null                       AS [TickerTableFooter!9!epsType],
  null                       AS [TickerTableFooter!9!valType],
  null                       AS [TickerTableFooter!9!closeDate]

UNION ALL

SELECT
  8                          AS tag,
  7                          AS parent,
  null                       AS [Root!1!!element],
  null                       AS [TickerTableHeader!2!baseYear],
 null                       AS [TickerTableHeader!2!epsType],
  null                       AS [TickerTableHeader!2!valType],
  null                       AS [TickerTableHeader!2!perfType],
  null                       AS [TickerTableHeader!2!closeDate],
  null                       AS [BaseYearOptions!3!!element],
  null                       AS [Option!4!value],
  null                       AS [EpsTypeOptions!5!!element],
  null                       AS [Option!6!value],
  null                       AS [ValTypeOptions!7!!element],
  ValType                    AS [Option!8!value],
  null                       AS [TickerTableFooter!9!baseYear],
  null                       AS [TickerTableFooter!9!epsType],
  null                       AS [TickerTableFooter!9!valType],
  null                       AS [TickerTableFooter!9!closeDate]
FROM #TmpValTypeOptions

UNION ALL

SELECT
  9                          AS tag,
  1                          AS parent,
  null                       AS [Root!1!!element],
  null                       AS [TickerTableHeader!2!baseYear],
  null                       AS [TickerTableHeader!2!epsType],
  null                       AS [TickerTableHeader!2!valType],
  null                       AS [TickerTableHeader!2!perfType],
  null                       AS [TickerTableHeader!2!closeDate],
  null                       AS [BaseYearOptions!3!!element],
  null                       AS [Option!4!value],
  null                       AS [EpsTypeOptions!5!!element],
  null                       AS [Option!6!value],
  null                       AS [ValTypeOptions!7!!element],
  null                       AS [Option!8!value],
  @BaseYearFooter            AS [TickerTableFooter!9!baseYear],
  @EpsTypeFooter             AS [TickerTableFooter!9!epsType],
  @ValTypeFooter             AS [TickerTableFooter!9!valType],
  @CloseDateFooter           AS [TickerTableFooter!9!closeDate]

FOR XML Explicit

EXEC sp_xml_removedocument @hDoc

END


GO


DECLARE  @xml varchar(MAX)
SET @xml =
'<DocumentInfo>
 <DocumentSection title="American Express: Competitive Dynamics Among Card Issuers222" perfType="TTM" valType="P/E Reported" epsType="EPS Reported" 
                  docFileName="AXP Blackbook Competition v3.docx" coverageInitiation="N" strategy="N" pubDate="16 Jun 2016" type="Research Call" documentType="Company Report"/>
  <Securities>
    <Security id= "1757" ticker="1347.HK" promoteDraft="N" />
    <Security id= "1288" ticker="2303.TT" promoteDraft="N" />
    <Security id= "493"  ticker="SMI"     promoteDraft="N" />
    <Security id= "1289" ticker="981.HK"  promoteDraft="N" />
 </Securities>
</DocumentInfo>'

EXEC [spGetCompanyMarketDataXml] @xml
EXEC [spGetTickerTableApiXml] @xml
EXEC [spGetTickerTableHeaderFooter] @xml
GO

/*
SELECT * FROM Securities2 Where Ticker = 'SMI'

<Security id= "1757" ticker="1347.HK" promoteDraft="N" />
<Security id= "1288" ticker="2303.TT" promoteDraft="N" />
<Security id= "1287" ticker="2330.TT" promoteDraft="N" />
<Security id= "1290" ticker="2454.TT" promoteDraft="N" />
<Security id= "1292" ticker="3034.TT" promoteDraft="N" />
<Security id= "2052" ticker="3711.TT" promoteDraft="N" />
<Security id= "1758" ticker="5347.TT" promoteDraft="N" />
<Security id= "1868" ticker="8035.JP" promoteDraft="N" />
<Security id= "1289" ticker="981.HK" promoteDraft="N" />
<Security id= "854"  ticker="ASML" promoteDraft="N" />
<Security id= "853"  ticker="ASML.NA" promoteDraft="N" />
<Security id= "55"   ticker="ASX" promoteDraft="N" />

<Security id= "854"  ticker="ASML" promoteDraft="N" />
<Security id= "1314" ticker="TSM" promoteDraft="N" />
<Security id= "1315" ticker="UMC" promoteDraft="N" />

http://institutional-dev.beehive.com/research/estimates.aspx?analystid=488&ticker=SMI#/
http://institutional-dev.beehive.com/research/tickertable.aspx?analystid=488&ticker=SMI#/
http://institutional-dev.beehive.com/research/companyfinancials.aspx?analystid=488&ticker=SMI
*/