--spGetAuthorHoldings_Rollback
--02/20/2019
USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE dbo.spGetAuthorHoldings(@DocXML xml)
AS
BEGIN

DECLARE  @hDoc int,
    @RowId float,
    @AuthorId int,
    @SecurityId int,
    @PrevAuthorId int,
    @PrevSecurityId int,
    @Author varchar(48),
    @Ticker varchar(15),
    @Company varchar(63),
    @Text varchar(5000),
    @DisclosureText varchar(max)

EXEC sp_xml_preparedocument @hDoc OUTPUT, @DocXML

SET NOCOUNT ON

  --Retrieve authors from document xml
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS AuthorRowNumber, AuthorId, Name
  INTO #TmpAuthorCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Authors/Author', 1)
  WITH (authorid        int         '@id',
        name            varchar(200) '@name'
        )

--Retrieve tickers from document xml
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS TickerRowNumber, X.SecurityId, X.Ticker
  INTO #TmpTickerCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
  WITH (securityId      int         '@id',
        ticker          varchar(30) '@ticker'
        ) X JOIN Securities2 S ON X.Ticker = S.Ticker
  WHERE S.TickerType = 'STOCK'

  --Cross product of Authors & Tickers.
  --This is needed to retrieve author holdings for each ticker on the report
  --Note that analyst holdings for all tickers on the report (covered & non-covered) need to be reported
SELECT convert(float,convert(varchar,AuthorRowNumber) + convert(varchar,TickerRowNumber)) RowId, AuthorId, SecurityId
INTO #TmpAuthorTickerCombinations
FROM
#TmpAuthorCollection TA,  #TmpTickerCollection TT

--Temp holdings table for analyst and tickers
SELECT RowId,Text
INTO #TmpHoldings
FROM
  #TmpAuthorTickerCombinations T JOIN vHoldings V ON T.AuthorId = V.AuthorId and T.SecurityId = V.SecurityId

--loop through temp holdings table to build output text
SELECT @DisclosureText = '', @Text = ''
SELECT TOP 1 @RowId = RowId, @Text = Text FROM #TmpHoldings ORDER BY RowId
WHILE @@ROWCOUNT = 1
BEGIN
  IF @Text <> ''
  BEGIN
    SET @DisclosureText = @DisclosureText + @Text + '.' + char(10)
  END
  SET @Text = ''
  SELECT TOP 1 @RowId = RowId, @Text = Text FROM #TmpHoldings WHERE RowId > @RowId ORDER BY RowId
END
SELECT @DisclosureText DisclosureText
DROP TABLE #TmpAuthorCollection
DROP TABLE #TmpTickerCollection
DROP TABLE #TmpAuthorTickerCombinations
DROP TABLE #TmpHoldings
END

GO