-- DropTables.sql
-- 01/09/2017

/*
Drop backup Tables:
FinancialNumberTypes_bak_20160222
FinancialScreensLog_Backup
FinancialSetExclusions_bak_20160222
LinkSources_bak
PortalUsage_tmp
PortalUsageOrig
TrefisModels_bak
*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FinancialNumberTypes_bak_20160222]') AND type in (N'U'))
DROP TABLE [dbo].[FinancialNumberTypes_bak_20160222]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FinancialScreensLog_Backup]') AND type in (N'U'))
DROP TABLE [dbo].[FinancialScreensLog_Backup]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FinancialSetExclusions_bak_20160222]') AND type in (N'U'))
DROP TABLE [dbo].[FinancialSetExclusions_bak_20160222]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LinkSources_bak]') AND type in (N'U'))
DROP TABLE [dbo].[LinkSources_bak]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsage_tmp]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsage_tmp]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageOrig]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageOrig]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TrefisModels_bak]') AND type in (N'U'))
DROP TABLE [dbo].[TrefisModels_bak]
GO