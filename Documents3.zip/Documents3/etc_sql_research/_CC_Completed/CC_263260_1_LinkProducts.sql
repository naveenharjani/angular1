-- CC_LinkProducts.sql
-- 09/19/2017

/*

LinkProducts
LinkSources
RVLinkProducts
RVLinkSources
spRenderGetLinkSources
spRenderSetLinkSources
spGetLinks

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- Backup LinkSources
--IF EXISTS(SELECT * FROM sys.objects where name = 'LinkSources_bak')
--DROP TABLE dbo.LinkSources_bak
--GO
SELECT * INTO dbo.LinkSources_bak FROM dbo.LinkSources
GO


IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'dbo.FK_LinkSources_LinkProducts') AND parent_object_id = OBJECT_ID(N'[dbo].[LinkSources]'))
ALTER TABLE dbo.LinkSources DROP CONSTRAINT FK_LinkSources_LinkProducts
GO

IF EXISTS(SELECT * FROM SYS.views WHERE name = 'RVLinkSources' AND type = 'V')
DROP VIEW [dbo].[RVLinkSources]
GO

IF EXISTS(SELECT * FROM SYS.views WHERE name = 'RVLinkProducts' AND type = 'V')
DROP VIEW [dbo].[RVLinkProducts]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.LinkProducts') AND type in (N'U'))
DROP TABLE dbo.LinkProducts
GO

CREATE TABLE dbo.LinkProducts
(
  ProductId         int         NOT NULL,
  Product           varchar(50) NOT NULL,
  SeqNo             int         NOT NULL,
  EditorId          int         NOT NULL,
  EditDate          datetime    NOT NULL,
 CONSTRAINT PK_LinkProducts PRIMARY KEY CLUSTERED (ProductId ASC)) ON [PRIMARY]
 GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.LinkSources') AND type in (N'U'))
DROP TABLE dbo.LinkSources
GO

CREATE TABLE dbo.LinkSources
(
  SourceId   int         NOT NULL,
  Source     varchar(50) NOT NULL,
  SeqNo      int         NOT NULL,
  ProductId  int         NOT NULL,
  EditorId   int         NOT NULL,
  EditDate   datetime    NOT NULL,
 CONSTRAINT PK_LinkSources PRIMARY KEY CLUSTERED (SourceId ASC)) ON [PRIMARY]
GO

ALTER TABLE dbo.LinkSources WITH CHECK ADD CONSTRAINT FK_LinkSources_LinkProducts FOREIGN KEY(ProductId)
REFERENCES dbo.LinkProducts (ProductId)
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spRenderGetLinkSources' and type = 'P')
DROP PROCEDURE dbo.spRenderGetLinkSources
GO

CREATE PROCEDURE dbo.spRenderGetLinkSources
AS
SELECT V.Value, V.Display
FROM
(
  SELECT
    'Display' = Product,
    'Value' = ISNULL(STUFF((SELECT ',' + CONVERT(VARCHAR(10),LS.SourceId)
              FROM LinkSources LS WITH(NOLOCK) WHERE LS.ProductId = LP.ProductId
              ORDER BY LS.SeqNo FOR XML PATH('')), 1, 1, ''), ''),
    'LPSeqNo' = LP.SeqNo, 'Level' = 1, 'LSSeqNo' = 0
  FROM LinkProducts LP
  UNION
  SELECT
    'Display' = '-- ' + LS.Source,
    'Value' =  CONVERT(varchar, LS.SourceId),
    'LPSeqNo' = LP.SeqNo, 'Level' = 2, 'LSSeqNo' = LS.SeqNo
  FROM LinkSources LS
  JOIN LinkProducts LP ON LP.ProductId = LS.ProductId
) V
ORDER BY V.LPSeqNo, V.Level, V.LSSeqNo
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spRenderSetLinkSources' and type = 'P')
DROP PROCEDURE dbo.spRenderSetLinkSources
GO

CREATE PROCEDURE dbo.spRenderSetLinkSources
AS
SELECT V.Value, V.Display
FROM
(
  SELECT
    'Display' = Product,
    'Value' = '',
    'LPSeqNo' = LP.SeqNo, 'Level' = 1, 'LSSeqNo' = 0
  FROM LinkProducts LP
  UNION
  SELECT
    'Display' = '-- ' + Source,
    'Value' =  CONVERT(varchar, SourceId),
    'LPSeqNo' = LP.SeqNo, 'Level' = 2, 'LSSeqNo' = LS.SeqNo
  FROM LinkSources LS
  JOIN LinkProducts LP ON LP.ProductId = LS.ProductId
) V
ORDER BY V.LPSeqNo, V.Level, V.LSSeqNo
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spGetLinks' and type = 'P')
DROP PROCEDURE dbo.spGetLinks
GO

CREATE PROCEDURE dbo.spGetLinks
@StartDate  varchar(10),
@EndDate    varchar(10),
@OrderBy    varchar(30)
AS

DECLARE @SQL VARCHAR(2000)

SET NOCOUNT ON
SET @SQL = 'SELECT DISTINCT P.PubNo, CONVERT(varchar, P.Date,101) AS Date, P.Type, P.Title, S.Sector
      FROM Publications P
      JOIN Properties Pr ON Pr.PubNo = P.PubNo AND Pr.PropId = 11  -- Industry
                        AND Pr.PropNo IN (select MIN(PropNo) from Properties where PubNo = P.PubNo and PropId = 11)
      JOIN Industries I ON I.IndustryName = Pr.PropValue
      JOIN Sectors S ON S.SectorId = I.SectorId
      WHERE P.Date BETWEEN ''' + @StartDate + ''' AND ''' + @EndDate + '''
      ORDER BY ' + @OrderBy

--PRINT(@sql)
EXEC (@SQL)
SET NOCOUNT OFF
GO

GRANT EXECUTE ON dbo.spRenderGetLinkSources to DE_IIS, PowerUsers
GRANT EXECUTE ON dbo.spRenderSetLinkSources to DE_IIS, PowerUsers
GRANT EXECUTE ON dbo.spGetLinks             to DE_IIS, PowerUsers
GO

-- DEBUG

/*

select * from LinkProducts order by SeqNo
select * from LinkSources order by ProductId, SeqNo
select * from dbo.LinkSources_bak

select
  SourceId,
  Source,
  SeqNo,
  ProductId,
  EditorId,
  EditDate
from
  LinkSources

select * from RVLinkProducts
select * from RVLinkSources

EXEC spRenderLinkSources
EXEC spRenderGetLinkSources
EXEC spRenderSetLinkSources
GO

SELECT * FROM dbo.LinkSources_bak
SELECT * FROM dbo.LinkSources

EXEC spGetLinks '08/01/2017', '08/31/2017', 'Sector ASC'
EXEC spGetLinks '08/01/2017', '08/31/2017', 'Date DESC'
EXEC spGetLinks '09/27/2017', '09/28/2017', 'Date DESC'
GO

*/