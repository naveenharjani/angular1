-- CC_vFinancials2.sql
-- 02/16/2017

/*

alter vFinancials2

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER VIEW [dbo].[vFinancials2]
AS

--Stocks
SELECT
  PF.SecurityId,
  S.Ticker,
  P.Date,
  PF.PubNo,
  PF.CoverageAction,
  PF.Rating,
  PF.RatingPrior,
  PF.RatingAction,
  PF.TargetPrice,
  PF.TargetPricePrior,
  PF.TargetPriceAction,
  PF.BaseYear AS LastYear,
  PF.BaseYear + 1 AS ThisYear,
  PF.BaseYear + 2 AS NextYear,
  PF.EpsType,
  CASE WHEN ISNUMERIC(PF.EpsFY0) = 1 THEN CAST(PF.EpsFY0 AS DECIMAL(18,2)) ELSE NULL END AS EPSLastYear,
  CASE WHEN ISNUMERIC(PF.EpsFY1) = 1 THEN CAST(PF.EpsFY1 AS DECIMAL(18,2)) ELSE NULL END AS EPSThisYear,
  CASE WHEN ISNUMERIC(PF.EpsFY1Prior) = 1 THEN CAST(PF.EpsFY1Prior AS DECIMAL(18,2)) ELSE NULL END AS EPSThisYearPrior,
  PF.EpsFY1Action AS EstimateAction,
  CASE WHEN ISNUMERIC(PF.EpsFY2) = 1 THEN CAST(PF.EpsFY2 AS DECIMAL(18,2)) ELSE NULL END AS EPSNextYear,
  CASE WHEN ISNUMERIC(PF.EpsFY2Prior) = 1 THEN CAST(PF.EpsFY2Prior AS DECIMAL(18,2)) ELSE NULL END AS EPSNextYearPrior,
  PF.EpsFY2Action AS EstimateNextYearAction,
  FNT.FinancialNumberType AS MetricType,
  '' AS MetricLastYear,
  '' AS MetricThisYear,
  '' AS MetricNextYear,
  PF.PriceCurrency AS Currency,
  '' AS YTDRelPerf,
  '' AS Yield,
  RC.LaunchDate,
  RC.DropDate,
  P.FileName,
  RC.CoverageId,
  RC.IndustryId,
  RC.AnalystId,
  PF.CloseDate,
  PF.ClosePrice,
  '' AS TickerOrder,
  '' AS DisplayCloseDate,
  '' AS RelPerfType
FROM ResearchCoverage RC
JOIN PublicationFinancials PF ON PF.CoverageId = RC.CoverageId
JOIN Securities2 S ON S.Ticker = PF.Ticker AND S.TickerType = 'Stock'
JOIN Publications P ON P.PubNo = PF.PubNo
LEFT JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
LEFT JOIN FinancialNumberTypes FNT ON FNT.FinancialNumberTypeId = FCS.TickerTableValuationId
WHERE RC.LaunchDate IS NOT NULL

UNION

--Indexes
SELECT
  PF.SecurityId,
  S.Ticker,
  P.Date,
  PF.PubNo,
  PF.CoverageAction,
  '' AS Rating,
  '' AS RatingPrior,
  '' AS RatingAction,
  '' AS TargetPrice,
  '' AS TargetPricePrior,
  '' AS TargetPriceAction,
  PF.BaseYear AS LastYear,
  PF.BaseYear + 1 AS ThisYear,
  PF.BaseYear + 2 AS NextYear,
  PF.EpsType,
  CASE WHEN ISNUMERIC(PF.EpsFY0) = 1 THEN CAST(PF.EpsFY0 AS DECIMAL(18,2)) ELSE NULL END AS EPSLastYear,
  CASE WHEN ISNUMERIC(PF.EpsFY1) = 1 THEN CAST(PF.EpsFY1 AS DECIMAL(18,2)) ELSE NULL END AS EPSThisYear,
  NULL AS EPSThisYearPrior,
  PF.EpsFY1Action AS EstimateAction,
  CASE WHEN ISNUMERIC(PF.EpsFY2) = 1 THEN CAST(PF.EpsFY2 AS DECIMAL(18,2)) ELSE NULL END AS EPSNextYear,
  NULL AS EPSNextYearPrior,
  PF.EpsFY2Action AS EstimateNextYearAction,
  '' AS MetricType,
  '' AS MetricLastYear,
  '' AS MetricThisYear,
  '' AS MetricNextYear,
  PF.PriceCurrency AS Currency,
  '' AS YTDRelPerf,
  '' AS Yield,
  NULL AS LaunchDate,
  NULL AS DropDate,
  P.FileName,
  NULL AS CoverageId,
  NULL AS IndustryId,
  NULL AS AnalystId,
  PF.CloseDate,
  PF.ClosePrice,
  '' AS TickerOrder,
  '' AS DisplayCloseDate,
  '' AS RelPerfType
FROM PublicationFinancials PF
JOIN Securities2 S ON S.Ticker = PF.Ticker AND S.TickerType = 'Index'
JOIN Publications P ON P.PubNo = PF.PubNo

GO



/*
-- DEBUG

SELECT COUNT(*) FROM [dbo].[vFinancials]  --where dropdate is null
SELECT COUNT(*) FROM [dbo].[vFinancials2] --where dropdate is null

SELECT COUNT(*) FROM [dbo].[vFinancialsLatest]
SELECT COUNT(*) FROM [dbo].[vFinancialsLatest2]

SELECT TOP 50000 * FROM vFinancials ORDER BY PubNo DESC
SELECT TOP 50000 * FROM vFinancials2 ORDER BY PubNo DESC

SELECT TOP 50000 * FROM vFinancialsLatest ORDER BY PubNo DESC
SELECT TOP 50000 * FROM vFinancialsLatest2 ORDER BY PubNo DESC

SELECT TOP 50000 * FROM RVFinancials ORDER BY DocId DESC

-- Compare Old vs New schemas
-- vFinancials
SELECT Ticker, PubNo, Date FROM vFinancials
EXCEPT
SELECT Ticker, PubNo, Date FROM vFinancials2

-- vFinancialsLatest
SELECT Ticker, PubNo, Date FROM vFinancialsLatest
EXCEPT
SELECT Ticker, PubNo, Date FROM vFinancialsLatest2

-- Data Issues
-- check special chars - ,(Comma)
SELECT * FROM PublicationFinancials PF WHERE PF.TargetPrice like '%,%'
SELECT * FROM PublicationFinancials PF WHERE PF.epsFY0 like '%,%'
SELECT * FROM PublicationFinancials PF WHERE PF.epsFY1 like '%,%'
SELECT * FROM PublicationFinancials PF WHERE PF.epsFY2 like '%,%'
SELECT * FROM PublicationFinancials PF WHERE PF.EpsFY1Prior like '%,%'
SELECT * FROM PublicationFinancials PF WHERE PF.EpsFY2Prior like '%,%'
SELECT * FROM  PublicationFinancials PF WHERE PF.Ticker = '005490.KS' AND PF.pubno = 112687

-- check special chars - $(dollar)
SELECT * FROM PublicationFinancials PF WHERE PF.TargetPrice like '$%'
SELECT * FROM PublicationFinancials PF WHERE PF.epsFY0 like '$%'
SELECT * FROM PublicationFinancials PF WHERE PF.epsFY1 like '$%'
SELECT * FROM PublicationFinancials PF WHERE PF.epsFY2 like '$%'
SELECT * FROM PublicationFinancials PF WHERE PF.EpsFY1Prior like '$%'
SELECT * FROM PublicationFinancials PF WHERE PF.EpsFY2Prior like '$%'
SELECT * FROM  PublicationFinancials PF WHERE PF.pubno = 126688  -- AND PF.Ticker = 'CELG'


-- No CoverageId
select * from PublicationFinancials where coverageid is  null and ticker not in ('SPX','MSPE','MSDLE15','MXAPJ','MXEF','MXJP')
order by pubno desc
select * from PublicationFinancials where pubno in (127041, 127099)
select * from tickertablesecurities where pubno in (127041, 127099)

select * from PublicationFinancials where ticker = '1918.hk'
SELECT * FROM vFinancials where ticker = '1918.HK'
SELECT * FROM vFinancials2 where ticker = '1918.HK'

*/