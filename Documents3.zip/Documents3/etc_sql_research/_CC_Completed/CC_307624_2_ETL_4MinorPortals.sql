-- CC_ETL_MinorP.sql
-- 02/12/2019

/*
alter table PortalUsageStaging_ONEaccess  : alter column - analyst_email    varchar(2000) NULL
alter table PortalUsageStaging_RedDeer    : column changes(6)

Proc changes: Load logic using Transaction Id, Store max(ContactId) in PortalClientEmbargo, handle no rows condition
alter proc spLoadPortalUsageFromStaging_ONEaccess
alter proc spLoadPortalUsageFromStaging_RedDeer
alter proc spLoadPortalUsageFromStaging_BlueMatrix
alter proc spLoadPortalUsageFromStaging_RSRCHX

Enable daily ftp files
ONEAccess   - (Bernstein_Readership*.csv) - ftp daily containing 90 days of pre and post embargoed data
Red Deer    - (Red Deer Readership Stats_*.csv) - ftp daily containing 90 days of post embargo data
Blue Matrix - (ABReadershipReport*.csv) - ftp daily containing 120 days of pre and post embargoed data

Enable manual file received monthly
RSRCHX      - via email monthly 30 days of post-embargo data
*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_ONEaccess]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_ONEaccess]
GO

CREATE TABLE [dbo].[PortalUsageStaging_ONEaccess](
  [file_date_UTC] [varchar](500) NULL,
  [read_id] [varchar](500) NULL,
  [vendor_document_id] [varchar](500) NULL,
  [broker_document_id] [varchar](500) NULL,
  [headline] [varchar](500) NULL,
  [ric_ticker] [varchar](500) NULL,
  [vendor_analyst_id] [varchar](500) NULL,
  [analyst_name] [varchar](500) NULL,
  [analyst_email] [varchar](2000) NULL,
  [published_date_UTC] [varchar](500) NULL,
  [viewed_date_UTC] [varchar](500) NULL,
  [vendor_client_id] [varchar](500) NULL,
  [client_name] [varchar](500) NULL,
  [client_address] [varchar](500) NULL,
  [client_city] [varchar](500) NULL,
  [client_state] [varchar](500) NULL,
  [client_country] [varchar](500) NULL,
  [client_type] [varchar](500) NULL,
  [Vendor Channel] [varchar](500) NULL,
  [Readership_type] [varchar](500) NULL,
  [vendor_user_id] [varchar](500) NULL,
  [user_name] [varchar](500) NULL,
  [user_business_email] [varchar](500) NULL,
  [user_alt_email] [varchar](500) NULL,
  [user_phone] [varchar](500) NULL,
  [user_address] [varchar](500) NULL,
  [user_city] [varchar](500) NULL,
  [user_state] [varchar](500) NULL,
  [user_country] [varchar](500) NULL,
  [user_role] [varchar](500) NULL
) ON [PRIMARY]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_RedDeer]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_RedDeer]
GO

CREATE TABLE [dbo].[PortalUsageStaging_RedDeer](
  [Client_ID] [varchar](500) NULL,
  [Client_Name] [varchar](500) NULL,
  [User_ID] [varchar](500) NULL,
  [User_Name] [varchar](500) NULL,
  [User_Business_Email] [varchar](500) NULL,
  [User_Status] [varchar](500) NULL,
  [Red Deer_Transaction_ID] [varchar](500) NULL,
  [Vendor_Doc_ID] [varchar](500) NULL,
  [Vendor_Doc_Title] [varchar](500) NULL,
  [Read_Date] [varchar](500) NULL,
  [User_Sub_Start_Date] [varchar](500) NULL,
  [User_Sub_End_Date] [varchar](500) NULL
) ON [PRIMARY]
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_ONEaccess]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@SubSite          VARCHAR(50),
@ContentType      VARCHAR(50),
@DataStore        NVARCHAR(200),
@PreEmbargoedText VARCHAR(30),
@LoadDate         DATETIME,
@PeriodStartDate  VARCHAR(10) = NULL,
@PeriodEndDate    VARCHAR(10) = NULL,
@RowsLoaded       INT = NULL

SET @SiteId = 21 -- ONEaccess
SET @DataStore = 'ONEaccess'
SET @SubSite = 'ONEaccess'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_ONEaccess)
BEGIN
  SELECT 0, NULL, NULL
  RETURN
END

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_ONEaccess OA
WHERE OA.[read_id] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    CASE
      WHEN ISNUMERIC([broker_document_id]) = 1 THEN [broker_document_id]
      ELSE 0
    END AS broker_document_id,
    [viewed_date_UTC],
    @SiteId,
    CASE
      WHEN [Vendor Channel] <> '' THEN [Vendor Channel]
      ELSE @SubSite
    END AS SubSite,
    [user_business_email],
    [user_name],
    [vendor_user_id],
    [client_name],
    [vendor_client_id],
    NULL,
    [read_id],
    CASE
      WHEN user_business_email = 'Anonymous' OR user_name = 'Anonymous' or ISNULL(user_business_email, '') = '' OR ISNULL(user_name, '') = ''
      THEN 'PRE'
      ELSE 'POST'
    END AS EmbargoStyle,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_ONEaccess OA
    WHERE OA.[read_id] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_ONEaccess OA ON PU.TransactionId = OA.[read_id] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage that were previously embargoed, with post-embargo data from Staging table by Transaction Id
  UPDATE PU
  SET PU.Email = OA.[user_business_email],
      PU.Contact = OA.[user_name],
      PU.ContactId = OA.[vendor_user_id],
      PU.Account = OA.[client_name],
      PU.AccountId = OA.[vendor_client_id],
      PU.EmbargoStyle = (CASE
                           WHEN user_business_email = 'Anonymous' OR user_name = 'Anonymous' or ISNULL(user_business_email, '') = '' OR ISNULL(user_name, '') = ''
                           THEN 'PRE'
                           ELSE 'POST'
                         END),
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_ONEaccess OA ON PU.TransactionId = OA.[read_id] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update rows marked as Pre-embargo (PRE)

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Delete prior Account listed with prior ContactId
DELETE FROM PortalClientEmbargo WHERE DataStore = @DataStore AND Account IN (SELECT distinct OA.[client_name] FROM [PortalUsageStaging_ONEaccess] OA)

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct OA.[client_name]) FROM PortalUsageStaging_ONEaccess OA
WHERE OA.[client_name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

IF @NumEmbargoRowstoInsert > 0
BEGIN
  --Identify accounts with 30 day embargo
  INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo, ContactId)
  SELECT DISTINCT @DataStore, OA.[client_name], OA.[vendor_client_id], 30, max(OA.[vendor_user_id])
    FROM PortalUsageStaging_ONEaccess OA
  WHERE DATEDIFF(d, OA.[viewed_date_UTC], getdate()) >= 30
  AND OA.[client_name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
  AND LTRIM(RTRIM(OA.[client_name])) != ''
  GROUP BY OA.[client_name], OA.[vendor_client_id]
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([viewed_date_UTC] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([viewed_date_UTC] AS DATE) ), 101)
FROM [PortalUsageStaging_ONEaccess]
WHERE ISDATE([viewed_date_UTC]) = 1

SELECT  @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END


GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RedDeer]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@SubSite          VARCHAR(50),
@ContentType      VARCHAR(50),
@DataStore        NVARCHAR(200),
@PreEmbargoedText VARCHAR(30),
@LoadDate         DATETIME,
@PeriodStartDate  VARCHAR(10) = NULL,
@PeriodEndDate    VARCHAR(10) = NULL,
@RowsLoaded       INT = NULL

SET @SiteId = 23 -- RedDeer
SET @DataStore = 'RedDeer'
SET @SubSite = 'RedDeer'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RedDeer)
BEGIN
  SELECT 0, NULL, NULL
  RETURN
END

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_RedDeer RD
WHERE RD.[Red Deer_Transaction_ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    CASE
      WHEN ISNUMERIC(RD.[Vendor_Doc_ID]) = 1 THEN [Vendor_Doc_ID]
      ELSE 0
    END AS broker_document_id,
    RD.[Read_Date],
    @SiteId,
    @SubSite,
    RD.[User_Business_Email],
    RD.[User_Name],
    RD.[User_ID],
    RD.[Client_Name],
    RD.[Client_ID],
    NULL,
    [Red Deer_Transaction_ID],
    'POST' AS EmbargoStyle,   -- no embargo on Red Deer reads
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_RedDeer RD
    WHERE RD.[Red Deer_Transaction_ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_RedDeer RD ON PU.TransactionId = RD.[Red Deer_Transaction_ID] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage that were previously embargoed, with post-embargo data from Staging table by Transaction Id
  UPDATE PU
  SET PU.Email = RD.[User_Business_Email],
      PU.Contact = RD.[User_Name],
      PU.ContactId = RD.[User_ID],
      PU.Account = RD.[Client_Name],
      PU.AccountId = RD.[Client_ID],
      PU.EmbargoStyle = 'POST',
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_RedDeer RD ON PU.TransactionId = RD.[Red Deer_Transaction_ID] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update rows marked as Pre-embargo (PRE)

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Delete prior Account listed with prior ContactId
DELETE FROM PortalClientEmbargo WHERE DataStore = @DataStore AND Account IN (SELECT distinct RD.[Client_Name] FROM PortalUsageStaging_RedDeer RD)

-- Red Deer has no clients on 30d or 90d embargoes
DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct RD.[Client_Name]) FROM PortalUsageStaging_RedDeer RD
WHERE RD.[Client_Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

IF @NumEmbargoRowstoInsert > 0
BEGIN
  --Identify accounts with 30 day embargo
  INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo, ContactId)
  SELECT DISTINCT @DataStore, RD.[Client_Name], RD.[Client_ID], 0, MAX(RD.[User_ID])
    FROM PortalUsageStaging_RedDeer RD
  WHERE RD.[Client_Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
  AND LTRIM(RTRIM(RD.[Client_Name])) != ''
    GROUP BY RD.[Client_Name], RD.[Client_ID]
END

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read_Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read_Date] AS DATE) ), 101)
FROM [PortalUsageStaging_RedDeer]
WHERE ISDATE([Read_Date]) = 1

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END
GO


ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_BlueMatrix]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@SubSite          VARCHAR(50),
@ContentType      VARCHAR(50),
@DataStore        NVARCHAR(200),
@PreEmbargoedText VARCHAR(30),
@LoadDate         DATETIME,
@PeriodStartDate  VARCHAR(10) = NULL,
@PeriodEndDate    VARCHAR(10) = NULL,
@RowsLoaded       INT = NULL

SET @SiteId = 20 -- Blue Matrix
SET @DataStore = 'BlueMatrix'
SET @SubSite = 'BlueMatrix'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_BlueMatrix)
BEGIN
  SELECT 0, NULL, NULL
  RETURN
END

-- Remove T Z from datetime
UPDATE PortalUsageStaging_BlueMatrix
SET [Read Date/Time] = REPLACE(REPLACE([Read Date/Time],'T',''), 'Z', ''),
    [Document Date]  = REPLACE(REPLACE([Document Date],'T',''), 'Z', '')

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_BlueMatrix BM
WHERE BM.[Transaction ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    CASE
      WHEN ISNUMERIC(BM.[Product ID]) = 1 THEN BM.[Product ID]
      ELSE 0
    END AS [Product ID],
    BM.[Read Date/Time],
    @SiteId,
    CASE
      WHEN BM.[Channel] <> '' THEN BM.[Channel]
      ELSE @SubSite
    END AS SubSite,
    BM.[Primary E-Mail],
    BM.[User Name],
    BM.[User ID],
    BM.[Firm name],
    BM.[Firm ID],
    NULL,
    BM.[Transaction ID],
    CASE
      WHEN BM.[Primary E-Mail] = 'ANONYMOUS' OR BM.[User Name] = 'ANONYMOUS' or ISNULL(BM.[Primary E-Mail], '') = '' OR ISNULL(BM.[User Name], '') = ''
      THEN 'PRE'
      ELSE 'POST'
    END AS EmbargoStyle,
    @FileName,
    @LoadDate
  FROM [PortalUsageStaging_BlueMatrix] BM
    WHERE BM.[Transaction ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_BlueMatrix BM ON PU.TransactionId = BM.[Transaction ID] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage that were previously embargoed, with post-embargo data from Staging table by Transaction Id
  UPDATE PU
  SET PU.Email = BM.[Primary E-Mail],
      PU.Contact = BM.[User Name],
      PU.ContactId = BM.[User ID],
      PU.Account = BM.[Firm name],
      PU.AccountId = BM.[Firm ID],
      PU.EmbargoStyle = (CASE
                           WHEN BM.[Primary E-Mail] = 'ANONYMOUS' OR BM.[User Name] = 'ANONYMOUS' or ISNULL(BM.[Primary E-Mail], '') = '' OR ISNULL(BM.[User Name], '') = ''
                           THEN 'PRE'
                           ELSE 'POST'
                         END),
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN [PortalUsageStaging_BlueMatrix] BM ON PU.TransactionId = BM.[Transaction ID] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update rows marked as Pre-embargo (PRE)

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

SET @RowsLoaded = @@ROWCOUNT

-- **Portal Client Embargo data loads**
-- Delete prior Account listed with prior ContactId
DELETE FROM PortalClientEmbargo WHERE DataStore = @DataStore AND Account IN (SELECT distinct BM.[Firm Name] FROM [PortalUsageStaging_BlueMatrix] BM)

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct BM.[Firm Name]) FROM [PortalUsageStaging_BlueMatrix] BM
WHERE BM.[Firm Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

IF @NumEmbargoRowstoInsert > 0
BEGIN
  --Identify accounts with 30 day embargo
  INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo, ContactId)
  SELECT DISTINCT @DataStore, BM.[Firm Name], BM.[Firm ID], 30, MAX(BM.[User ID])
    FROM [PortalUsageStaging_BlueMatrix] BM
  WHERE DATEDIFF(d, BM.[Read Date/Time], getdate()) >= 30
  AND BM.[Firm Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
  AND LTRIM(RTRIM(BM.[Firm Name])) != ''
  GROUP BY BM.[Firm Name], BM.[Firm ID]
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date/Time] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read Date/Time] AS DATE) ), 101)
FROM [PortalUsageStaging_BlueMatrix]
WHERE ISDATE([Read Date/Time]) = 1

SELECT @RowsLoaded,@PeriodStartDate,@PeriodEndDate

SET NOCOUNT OFF
END


GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RSRCHX]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@SubSite          VARCHAR(50),
@ContentType      VARCHAR(50),
@DataStore        NVARCHAR(200),
@PreEmbargoedText VARCHAR(30),
@LoadDate         DATETIME,
@PeriodStartDate  VARCHAR(10) = NULL,
@PeriodEndDate    VARCHAR(10) = NULL,
@RowsLoaded       INT = NULL

SET @SiteId = 22 -- RSRCHXchange
SET @DataStore = 'RSRCHX'
SET @SubSite = 'RSRCHX'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RSRCHX)
BEGIN
  SELECT 0, NULL, NULL
  RETURN
END

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_RSRCHX RS
WHERE RS.[Action ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    CASE
      WHEN ISNUMERIC(RS.[Provider's Identifier]) = 1 THEN RS.[Provider's Identifier]
      ELSE 0
    END AS [Provider's Identifier],
    RS.[Action Date (UTC)],
    @SiteId,
    @SubSite,
    RS.[Email],
    RS.[Surname] + ', ' + RS.[Forename],
    RS.[User UUID],
    RS.[Client Org Firm Name],
    RS.[Client UUID],
    NULL,
    RS.[Action ID],
    CASE
      WHEN RS.[Email] = 'Anonymous' OR [Surname] = 'Anonymous' or ISNULL(RS.[Email], '') = '' OR ISNULL([Surname], '') = ''
      THEN 'PRE'
      ELSE 'POST'
    END AS EmbargoStyle,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_RSRCHX RS
    WHERE RS.[Action ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_RSRCHX RS ON PU.TransactionId = RS.[Action ID] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage that were previously embargoed, with post-embargo data from Staging table by Transaction Id
  UPDATE PU
  SET PU.Email = RS.[Email],
      PU.Contact = RS.[Surname] + ', ' + RS.[Forename],
      PU.ContactId = RS.[User UUID],
      PU.Account = RS.[Client Org Firm Name],
      PU.AccountId = RS.[Client UUID],
      PU.EmbargoStyle = (CASE
                           WHEN RS.[Email] = 'Anonymous' OR [Surname] = 'Anonymous' or ISNULL(RS.[Email], '') = '' OR ISNULL([Surname], '') = ''
                           THEN 'PRE'
                           ELSE 'POST'
                         END),
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_RSRCHX RS ON PU.TransactionId = RS.[Action ID] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update rows marked as Pre-embargo (PRE)

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Delete prior Account listed with prior ContactId
DELETE FROM PortalClientEmbargo WHERE DataStore = @DataStore AND Account IN (SELECT distinct RS.[Client Org Firm Name] FROM PortalUsageStaging_RSRCHX RS)

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(RS.[Client Org Firm Name]) FROM PortalUsageStaging_RSRCHX RS
WHERE RS.[Client Org Firm Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

IF @NumEmbargoRowstoInsert > 0
BEGIN
  --Identify accounts with 0 day embargo
  INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo, ContactId)
  SELECT DISTINCT @DataStore, RS.[Client Org Firm Name], RS.[Client UUID], 0, MAX(RS.[User UUID])
    FROM PortalUsageStaging_RSRCHX RS
  WHERE DATEDIFF(d, RS.[Action Date (UTC)], getdate()) < 30  -- reads in first 30 days
  AND RS.[Client Org Firm Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
  AND LTRIM(RTRIM(RS.[Client Org Firm Name])) != ''
  GROUP BY RS.[Client Org Firm Name], RS.[Client UUID]

  --Identify accounts with 30 day embargo
  INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo, ContactId)
  SELECT DISTINCT @DataStore, RS.[Client Org Firm Name], RS.[Client UUID], 30, MAX(RS.[User UUID])
    FROM PortalUsageStaging_RSRCHX RS
  WHERE DATEDIFF(d, RS.[Action Date (UTC)], getdate()) >= 30  -- reads after 30 days
  AND RS.[Client Org Firm Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
  AND LTRIM(RTRIM(RS.[Client Org Firm Name])) != ''
  GROUP BY RS.[Client Org Firm Name], RS.[Client UUID]
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Action Date (UTC)] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Action Date (UTC)] AS DATE) ), 101)
FROM [PortalUsageStaging_RSRCHX]
WHERE ISDATE([Action Date (UTC)]) = 1

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END



GO

-- Grant Permissions
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_ONEaccess]  TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_RedDeer]    TO DE_IIS
GO

-- DEBUG

/*
-- ONEaccess
SELECT * FROM PortalUsageStaging_ONEaccess ORDER BY [viewed_date_UTC] desc
SELECT * FROM PortalUsage Where SiteId = 21 ORDER BY ReadDate DESC
SELECT * FROM PortalClientEmbargo WHERE DataStore = 'ONEACCESS'
SELECT * FROM FileProcessingLog WHERE DataStore = 'ONEACCESS' ORDER BY LoadDate DESC
EXEC [spLoadPortalUsageFromStaging_ONEaccess] 'Bernstein_Readership_20190403T100000Z.csv', 'DAILY', 'MIXED', 0

-- Red Deer
SELECT * FROM PortalUsageStaging_RedDeer ORDER BY [Read_Date] desc
SELECT * FROM PortalUsage Where SiteId = 23 ORDER BY ReadDate DESC
SELECT * FROM PortalClientEmbargo WHERE DataStore = 'RedDeer'
SELECT * FROM FileProcessingLog WHERE DataStore = 'RedDeer' ORDER BY LoadDate DESC
EXEC [spLoadPortalUsageFromStaging_RedDeer] 'Red Deer Readership Stats_Bernstein_20190402-sampledata.csv', 'DAILY', 'POST', 0

-- Blue Matrix
SELECT * FROM PortalUsageStaging_BlueMatrix
SELECT * FROM PortalUsage Where SiteId = 20 ORDER BY ReadDate DESC
SELECT * FROM PortalClientEmbargo WHERE DataStore = 'BlueMatrix'
SELECT * FROM FileProcessingLog WHERE DataStore = 'BLUEMATRIX' ORDER BY LoadDate DESC

-- RSRCHX
SELECT * FROM PortalUsageStaging_RSRCHX
SELECT * FROM PortalUsage Where SiteId = 22 ORDER BY ReadDate DESC
SELECT * FROM PortalClientEmbargo WHERE DataStore = 'RSRCHX'
SELECT * FROM FileProcessingLog WHERE DataStore = 'RSRCHX' ORDER BY LoadDate DESC
*/