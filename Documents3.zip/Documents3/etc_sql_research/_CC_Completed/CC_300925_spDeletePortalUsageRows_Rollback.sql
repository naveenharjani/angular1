-- spDeletePortalUsageRows_Rollback.sql
-- 02/04/2019

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spDeletePortalUsageRows]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spDeletePortalUsageRows]
GO