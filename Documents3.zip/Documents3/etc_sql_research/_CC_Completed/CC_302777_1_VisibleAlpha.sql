-- VisibleAlpha.sql
-- 02/06/2019

/*

alter table PortalUsageStaging_VisibleAlpha
alter proc spLoadPortalUsageFromStaging_VisibleAlpha

Revised - Load daily model downloads
VA-SanfordBernstein-VAI_Model_Download-T-120_20190227T060030Z.csv
File contains pre-embargoed and post-embargoed data.  Process both using Tx id.

New - Load daily model data usage
VA-SanfordBernstein-Model_Data_Usage-T-90_20190205T210016Z.csv
File contains pre-embargoed and post-embargoed data.  Process both using Tx id.

Both files overloaded into single staging table.

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_VisibleAlpha]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_VisibleAlpha]
GO

CREATE TABLE [dbo].[PortalUsageStaging_VisibleAlpha]
(
  [file_date_UTC]       [varchar](500) NULL,
  [read_id]             [varchar](500) NULL,
  [viewed_date_UTC]     [varchar](500) NULL,
  [channel_type]        [varchar](500) NULL,
  [vendor_user_id]      [varchar](500) NULL,
  [user_name]           [varchar](500) NULL,
  [user_business_email] [varchar](500) NULL,
  [vendor_client_id]    [varchar](500) NULL,
  [client_name]         [varchar](500) NULL,
  [client_type]         [varchar](500) NULL,
  [broker_model_id]     [varchar](500) NULL,
  [vendor_document_id]  [varchar](500) NULL,
  [published_date_UTC]  [varchar](500) NULL,
  [broker_ticker]       [varchar](500) NULL,
  [vendor_analyst_id]   [varchar](500) NULL,
  [analyst_name]        [varchar](500) NULL,
  [analyst_email]       [varchar](500) NULL,
  [company]             [varchar](500) NULL,
  [usage_class]         [varchar](500) NULL,
  [broker_name]         [varchar](500) NULL,
  [sector]              [varchar](500) NULL,
  [industry]            [varchar](500) NULL
) ON [PRIMARY]
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_VisibleAlpha]
 @FileName        varchar(100),
 @FileFrequency   varchar(50),
 @EmbargoStyle    varchar(50),
 @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
  @SiteId           INT,
  @EditDate         DATETIME,
  @ContentType      VARCHAR(50),
  @DataStore        NVARCHAR(200),
  @PreEmbargoedText VARCHAR(30),
  @LoadDate         DATETIME,
  @PeriodStartDate  VARCHAR(10),
  @PeriodEndDate    VARCHAR(10),
  @RowsLoaded       INT

SET @SiteId = 27    -- Visible Alpha
SET @DataStore = 'VisibleAlpha'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_VisibleAlpha)
BEGIN
  SELECT 0, '', ''
  RETURN
END

/*
- Load all rows from csv to Staging table

- Identify the insert rows - Rows in Staging table not found in PortalUsage table (not-matching TransactionId)
  Insert into PortalUsage table - for a client attributed read(valid email), set EmbargoStyle = 'POST', Else 'PRE'

- Identify the update rows - Rows in Staging table found in PortalUsage table (matching TransactionId)
  Update PortalUsage table - update PRE (EmbargoStyle) rows with attributed reads to 'POST'
*/

-- need a seperate value for ContentType - model downloads vs web clicks
IF CHARINDEX('VA-SanfordBernstein-VAI_Model_Download-T-120',@FileName) > 0
 SET @ContentType = 'M'
ELSE IF CHARINDEX('VA-SanfordBernstein-Model_Data_Usage-T-90',@FileName) > 0
 SET @ContentType = 'M2'
ELSE
  SET @ContentType = 'M'

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowsToInsert AS INT
SELECT @NumRowsToInsert = COUNT(*) FROM PortalUsageStaging_VisibleAlpha VA
WHERE VA.read_id NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null AND ContentType = @ContentType) OPTION(RECOMPILE)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowsToInsert > 0
BEGIN
  -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
   @ContentType,
   isnull(broker_model_id,1),
   CONVERT(DATETIME2,replace(viewed_date_UTC,'Z',':00'),127),
   @SiteId,
   channel_type,
   user_business_email,
   [user_name],
   vendor_user_id,
   client_name,
   vendor_client_id,
   client_type,
   read_id,
   -- Embargo Style
   CASE WHEN ltrim(rtrim(user_business_email)) IN ('Anonymous', '') THEN 'PRE' ELSE 'POST' END as EmbargoStyle,
   @FileName,
   @LoadDate
  FROM [dbo].[PortalUsageStaging_VisibleAlpha] VA
    WHERE VA.read_id NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null AND ContentType = @ContentType) OPTION(RECOMPILE)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_VisibleAlpha VA ON PU.TransactionId = VA.read_id AND PU.SiteId = @SiteId AND ContentType = @ContentType OPTION(RECOMPILE)

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage that were previously embargoed, with post-embargo data from Staging table by Transaction Id
  UPDATE PU
  SET PU.Email = VA.user_business_email,
      PU.Contact = VA.[user_name],
      PU.ContactId = CASE WHEN ISNUMERIC(VA.[vendor_user_id]) = 1 THEN VA.[vendor_user_id] ELSE NULL END,
      PU.Account = VA.[client_name],
      PU.AccountId = VA.[vendor_client_id],
      PU.EmbargoStyle = 'POST',
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_VisibleAlpha VA ON PU.TransactionId = VA.read_id AND PU.SiteId = @SiteId  AND ContentType = @ContentType
                                                AND ltrim(rtrim(VA.user_business_email)) NOT IN ('Anonymous', '')
  WHERE PU.EmbargoStyle = @PreEmbargoedText OPTION(RECOMPILE) -- Update rows marked as Pre-embargo (PRE)

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CONVERT(DATETIME2,replace(viewed_date_UTC,'Z',':00'),127)), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CONVERT(DATETIME2,replace(viewed_date_UTC,'Z',':00'),127)), 101)
FROM PortalUsageStaging_VisibleAlpha
WHERE isdate(CONVERT(DATETIME,replace(viewed_date_UTC,'Z',':00'),127))= 1

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_VisibleAlpha] TO  DE_IIS
GO


-- DEBUG

/*
EXEC spLoadPortalUsageFromStaging_VisibleAlpha 'VA-SanfordBernstein-VAI_Model_Download-T-120', '', '', 0
EXEC spLoadPortalUsageFromStaging_VisibleAlpha 'VA-SanfordBernstein-VAI_Model_Download-T-120_20190220T060025Z.csv', '', '', 0
*/
