-- CC_spGetEmailSubscriptions_Rollback.sql
-- 06/16/2019

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spGetEmailSubscriptions]
  @PubNo int
AS
DECLARE @ISPRODFLAG char(1)
DECLARE @SUFFIX     varchar(20)

-- EMAIL SAFEGUARD - In non-PRD database environment append text to email address to prevent accidental send
SET @ISPRODFLAG = 'N'
IF CHARINDEX('_PRD', @@SERVERNAME) > 0 SELECT @ISPRODFLAG = 'Y'
IF @ISPRODFLAG <> 'Y'  
  -- DEV/QA environment - Use invalid email
  SET @SUFFIX = '_TEST'  
ELSE  
  -- PRD environment - Use valid email
  SET @SUFFIX = ''

-- To
-- Approvers rowset
SELECT DISTINCT ISNULL(UA.Email,'') + @SUFFIX AS Approver
FROM Publications P
LEFT JOIN Users UA ON UA.ExchangeEmail = P.Approver
WHERE P.PubNo = @PubNo

-- To
-- Authors rowset
SELECT ISNULL(A.ExtEmail,'') + @SUFFIX AS Author
FROM Properties PV WITH(NOLOCK)
JOIN Authors A WITH(NOLOCK) ON A.Name = PV.PropValue AND PV.PropID = 5 -- Author
WHERE PV.PubNo = @PubNo
ORDER BY PV.PropNo

-- Bcc
-- Subscribers rowset
SELECT 'DESubscribers@alliancebernstein.com' + @SUFFIX AS Subscriber WHERE 1 = 2

UNION

-- Industry subscriptions
SELECT ISNULL(U.Email,'') + @SUFFIX
FROM Subscriptions SU
INNER JOIN Users U ON U.UserId = SU.UserId
INNER JOIN Industries I ON I.IndustryId = SU.SubscriptionTypeId
INNER JOIN Properties P ON P.PropId = 11 AND P.PropValue = I.IndustryName
WHERE SubscriptionType = 'I'
AND U.Email IS NOT NULL
AND P.PubNo = @PubNo

UNION

-- Author subscriptions
SELECT ISNULL(U.Email,'') + @SUFFIX
FROM Subscriptions SU
INNER JOIN Users U ON U.UserId = SU.UserId
INNER JOIN Authors A on A.AuthorID = SU.SubscriptionTypeId
INNER JOIN Properties P ON P.PropId = 5 AND P.PropValue = A.Name
WHERE SubscriptionType = 'A'
AND U.Email IS NOT NULL
AND P.PubNo = @PubNo

UNION

-- Security subscriptions
SELECT ISNULL(U.Email,'') + @SUFFIX
FROM Subscriptions SU
INNER JOIN Users U ON U.UserId = SU.UserId
INNER JOIN Securities2 S2 on S2.SecurityID = SU.SubscriptionTypeId 
INNER JOIN Properties P ON P.PropId = 13 AND P.PropValue = S2.Ticker
WHERE SubscriptionType = 'S'
AND U.Email IS NOT NULL
AND P.PubNo = @PubNo

GO
