USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO
IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spSearchData' and type = 'P')
DROP PROCEDURE dbo.spSearchData
GO
-- =================================================================================================
-- Author:      Sandarsh M S
-- Revised:     08/04/2016
-- Description:  Get Typeahead data for a given @SearchText
-- =================================================================================================
CREATE PROCEDURE [dbo].[spSearchData] 
  @Style int,
  @UserId int,
  @SearchText nvarchar(200),
  @SearchTextComp nvarchar(200)

AS
Begin
Set @SearchText = '%'+ @SearchText+'%'
Set @SearchTextComp = '%'+ @SearchText+'%'

DECLARE @Analyst TABLE
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL,
  Header int NULL
 )

 INSERT INTO @Analyst 
select top 10
-- Last + ', ' + First as Label
  [Name] as Label,[Name] as Ticker, 'Analyst' as Groups,Row_Number() OVER (ORDER BY [Name]) +3  AS Header
from Authors where IsAnalyst = -1 and (First like @SearchText or Last like @SearchText or [Name] like @SearchText) 
AND AuthorId in (select  Distinct AnalystID from ResearchCoverage) order by [Name]


DECLARE @Ticker TABLE
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL
 )

 INSERT INTO @Ticker
 select top (26 - (select Count(*) from @Analyst))  
 Ticker + ' / ' + Company as Label,Ticker,'Research' as Groups
from Securities2 where Ticker like @SearchText or  Company like @SearchTextComp order by Ticker + ' / ' + Company

DECLARE @Financials TABLE
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL
 )

  INSERT INTO @Financials
SELECT 
  S.Ticker + ' / ' +  S.Company as Label,Ticker,'Financials' as Groups
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
WHERE RC.DropDate IS NULL and s.Ticker = (Select top 1 Ticker from @Ticker)
AND RC.AnalystId IN (SELECT AuthorId FROM Authors WHERE IsAnalyst = -1 AND IsActive = -1) order by S.Ticker + ' / ' + S.Company

--DECLARE @Charts TABLE

--(

--  Label  varchar(100) NULL,

--  Ticker varchar(50) NULL,

--  Groups varchar(50) NULL

-- )

-- INSERT INTO @Charts

-- Select

--  S.Ticker + ' / ' +  S.Company as Label,Ticker,'Charts' as Groups

--FROM ResearchCoverage RC

--JOIN Securities2 S on S.SecurityId = RC.SecurityId
--WHERE  S.Ticker = (Select top 1 Ticker from @Ticker) AND RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
--order by S.Ticker + ' / ' + S.Company

select *, ROW_NUMBER() OVER(PARTITION BY Ticker 
ORDER BY Groups desc) AS Header
from (
select * from @Ticker
Union
SELECT * from @Financials
--Union

--SELECT * from @Charts

) as uni
Union All
select * from @Analyst
End

GO
GRANT EXECUTE ON dbo.spSearchData TO DE_IIS,PowerUsers
GO