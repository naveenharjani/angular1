-- spGetReportsForAuthor_Rollback.sql
-- 11/07/2017

/*

spGetReportsForAuthor

*/

USE [Research]
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where name = 'spGetReportsForAuthor' and type = 'P')
drop proc dbo.spGetReportsForAuthor
go