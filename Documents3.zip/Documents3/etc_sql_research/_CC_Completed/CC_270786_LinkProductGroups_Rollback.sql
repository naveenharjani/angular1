-- LinkProductGroups_Rollback.sql
-- 11/16/2017

/*
spSaveProperty
spSaveCoverage
spSaveProductGroupModels
spUpdateProductGroup
*/

USE [Research]
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- =======================================================================
-- Author:  Naveen Harjani
-- Create date:  1/4/2009
-- Description:  Save the Property information for the web edit form
--------------------------------------------------------------------------
-- Revision Dt  | Comments
--------------------------------------------------------------------------
-- mm/dd/yyyy   | NH - Text e.g. List the changes made to the stored procedure.
-- 05/21/2014   | Krishna - Call spInsProductGroupDocumentsByPubNo if Author/Industry/Tickers updated
--------------------------------------------------------------------------
-- =======================================================================
ALTER PROCEDURE [dbo].[spSaveProperty]
  @PubNo         int,
  @PropId        int,
  @PropValueList text, -- Delimeted list of values to be saved for property
  @EditorID      int
AS

DECLARE @EditDate       DATETIME
DECLARE @OperationFlag  CHAR(1)
DECLARE @PropertyOld    VARCHAR(2000)

SET @EditDate = GETDATE()

--Check if the data to be saved is MultiSelections
IF EXISTS (SELECT * FROM PropertyNames WHERE PropId = @PropId AND ControlTypeCode = 'MSLB')
  BEGIN
    SELECT * INTO #PropertiesTemp FROM Properties WHERE PubNo = @PubNo AND PropID = @PropId

    --Delete all values for this multiselect Property
    DELETE FROM Properties WHERE PubNo=@PubNo AND PropID = @PropId

    --Insert all assigned Properties
    --------------------------------------------------------------------------
    --start of parse a delimited string
    --------------------------------------------------------------------------
    declare @pos int
    declare @piece   VARCHAR(max)
    declare @string  VARCHAR(max)
    declare @delimiter varchar(2)

    SET @delimiter = '|'
    SET @string = @PropValueList

    SET @pos = charindex(@delimiter , @string)

    WHILE @pos <> 0
    BEGIN
      SET @piece = left(@string, @pos-1)

      IF ltrim(rtrim(@piece)) <> ''
      BEGIN
        INSERT INTO Properties(PubNo, PropID, PropValue) VALUES(@PubNo, @PropId, @piece)
      END

      SET @string = stuff(@string, 1, @pos, '')

      SET @pos = charindex(@delimiter, @string)
    END

    --------------------------------------------------------------------------
    --end of parse a delimited string
    --------------------------------------------------------------------------

    If ltrim(rtrim(@string)) <> ''
    BEGIN
      INSERT INTO Properties(PubNo, PropID, PropValue) VALUES(@PubNo, @PropId, @string)
    END

    -- Update product group when property is updated
    DECLARE @vPublishedDate DATETIME
    DECLARE @vType VARCHAR(31)
    SELECT @vPublishedDate = PublishedDate, @vType = Type FROM Publications WHERE Pubno = @PubNo
    EXEC spInsProductGroupDocsByPubNo @PubNo,@vPublishedDate ,@vType

    SET @OperationFlag  = 'A'

    -- Record add in PropertyLog table
    INSERT INTO PropertyLog (PubNo, PropId, Operation, PropertyNew, PropertyOld, EditorId, EditDate)
    SELECT PubNo, PropId, @OperationFlag, PropValue, '',  @EditorID, @EditDate
    FROM Properties p
    WHERE PubNo=@PubNo AND PropID=@PropId
    AND NOT EXISTS (SELECT PubNo, PropId, PropValue From #PropertiesTemp t where t.PubNo = p.PubNo AND t.PropId = p.PropId and t.PropValue = p.PropValue)

    SET @OperationFlag  = 'D'

    -- Record delete in PropertyLog table
    INSERT INTO PropertyLog (PubNo, PropId, Operation, PropertyNew, PropertyOld, EditorId, EditDate)
    SELECT PubNo, PropId, @OperationFlag, '', PropValue, @EditorID, @EditDate
    FROM #PropertiesTemp p
    WHERE PubNo=@PubNo AND PropID=@PropId
    AND NOT EXISTS (SELECT PubNo, PropId, PropValue From Properties t where t.PubNo = p.PubNo AND t.PropId = p.PropId and t.PropValue = p.PropValue)

    DROP TABLE #PropertiesTemp
  END

--Else it is a publication date save
ELSE IF @PropId = 1   --1  Publication Date  TXTB
  BEGIN
      DECLARE @PubDateOld     DATETIME
      DECLARE @PubDateNew     VARCHAR(20)

      IF EXISTS (SELECT * FROM Publications WHERE PubNo = @PubNo)
      BEGIN
        SET @OperationFlag = 'U'
        SET @PubDateNew = CONVERT(VARCHAR(10), @PropValueList, 101)

        SELECT @PubDateOld = Date FROM Publications WHERE PubNo = @PubNo

        UPDATE Publications SET Date = @PubDateNew WHERE PubNo = @PubNo

        IF @PubDateNew <> @PubDateOld
        BEGIN
          -- Record change in PropertyLog table
          INSERT INTO PropertyLog (PubNo, PropId, Operation, PropertyNew, PropertyOld, EditorId, EditDate)
          VALUES (@PubNo, @PropId, @OperationFlag, CONVERT(VARCHAR(10), @PubDateNew, 101), CONVERT(VARCHAR(10), @PubDateOld, 101),
                  @EditorID, @EditDate)
         END
      END
  END

--Else it is a publication title save
ELSE IF @PropId = 3   --3  Title  TXTB
  BEGIN
      DECLARE @TitleOld       VARCHAR(255)
      DECLARE @TitleNew       VARCHAR(255)

      IF EXISTS (SELECT * FROM Publications WHERE PubNo = @PubNo)
      BEGIN
        SET @OperationFlag = 'U'
        SET @TitleNew = CONVERT(varchar(255),@PropValueList)

        SELECT @TitleOld = Title FROM Publications WHERE PubNo = @PubNo

        UPDATE Publications SET Title = @TitleNew WHERE PubNo = @PubNo

        IF @TitleNew <> @TitleOld
        BEGIN
          -- Record change in PropertyLog table
          INSERT INTO PropertyLog (PubNo, PropId, Operation, PropertyNew, PropertyOld, EditorId, EditDate)
          VALUES (@PubNo, @PropId, @OperationFlag, @TitleNew, @TitleOld, @EditorID, @EditDate)
        END

      END
  END

--Else it is a single value
ELSE
  BEGIN

    --Check if Property value already exists
    IF EXISTS(SELECT * FROM Properties WHERE PubNo=@PubNo AND PropID = @PropId)
      BEGIN
        SET @OperationFlag = 'U'

        SELECT @PropertyOld = PropValue FROM Properties WHERE PubNo = @PubNo AND PropID = @PropId

        UPDATE Properties
           SET PropValue = @PropValueList
         WHERE PubNo = @PubNo
           AND PropId = @PropId
      END
    ELSE
      BEGIN
        SET @OperationFlag = 'A'
        SET @PropertyOld = null;

        INSERT INTO Properties(PubNo, PropID, PropValue)
        VALUES(@PubNo, @PropId, @PropValueList)
      END

   IF CONVERT(VARCHAR(2000), @PropValueList) <> @PropertyOld
   BEGIN
      -- Record change in PropertyLog table
      INSERT INTO PropertyLog (PubNo, PropId, Operation, PropertyNew, PropertyOld, EditorId, EditDate)
      VALUES (@PubNo, @PropId, @OperationFlag, @PropValueList, @PropertyOld, @EditorID, @EditDate)
   END

  END

GO

ALTER PROCEDURE [dbo].[spSaveCoverage]
  @CoverageId    int OUTPUT,
  @IndustryId    int,
  @AnalystId     int,
  @SecurityId    int,
  @LaunchDate    datetime,
  @LaunchInd     char(1),
  @DropDate      datetime,
  @DropInd       char(1),
  @EditorId      int
AS
DECLARE @EditDate datetime
DECLARE @CoverageAction varchar(10)
DECLARE @RatingAction varchar(10)
DECLARE @PubNo int
DECLARE @EstimatePeriodId int
DECLARE @MsgOld varchar(100)
DECLARE @MsgNew varchar(100)
DECLARE @CompanyId int

SELECT @EditDate = GETDATE()
BEGIN TRANSACTION
BEGIN TRY
--Before insert/update row in ResearchCoverage table
--perform the two checks below

--Company should only be covered by one active analyst
SELECT @CompanyId = CompanyId FROM Securities2 WHERE SecurityId = @SecurityId
IF (SELECT DISTINCT RC.AnalystId FROM ResearchCoverage RC JOIN Securities2 S ON RC.SecurityId = S.SecurityId
WHERE CompanyId = @CompanyId AND  LaunchDate IS NOT NULL AND DropDate IS NULL) <> @AnalystId
BEGIN
  ROLLBACK TRANSACTION
  RETURN -1
END

--Security should only be covered by one active analyst
IF (SELECT COUNT(*) FROM ResearchCoverage
WHERE SecurityId = @SecurityId AND AnalystId <> @AnalystId AND  LaunchDate IS NOT NULL AND DropDate IS NULL) > 0
BEGIN
  ROLLBACK TRANSACTION
  RETURN -2
END

IF @DropInd = '' SELECT @DropInd = null
IF EXISTS (SELECT CoverageId FROM ResearchCoverage WHERE CoverageId = @CoverageId)
  -- EXISTING COVERAGE
  BEGIN
    SELECT @MsgOld = I.IndustryName + ' | ' + A.Last + ' | ' + ISNULL(S.Ticker, '-')
    FROM ResearchCoverage RC
    JOIN Industries I ON I.IndustryId = RC.IndustryId
    JOIN Authors A ON A.AuthorId = RC.AnalystId
    LEFT JOIN Securities2 S ON S.SecurityId = RC.SecurityId
    WHERE RC.CoverageId = @CoverageId

    UPDATE ResearchCoverage SET
      IndustryId = @IndustryId,
      AnalystId  = @AnalystId,
      SecurityId = @SecurityId,
      LaunchDate = @LaunchDate,
      LaunchInd  = @LaunchInd,
      DropDate   = @DropDate,
      DropInd    = @DropInd,
      EditorId   = @EditorId,
      EditDate   = @EditDate
    WHERE CoverageId = @CoverageId

    SELECT @MsgNew = I.IndustryName + ' | ' + A.Last + ' | ' + ISNULL(S.Ticker, '-')
    FROM ResearchCoverage RC
    JOIN Industries I ON I.IndustryId = RC.IndustryId
    JOIN Authors A ON A.AuthorId = RC.AnalystId
    LEFT JOIN Securities2 S ON S.SecurityId = RC.SecurityId
    WHERE RC.CoverageId = @CoverageId

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Coverage', 'U', @MsgNew, @MsgOld, @CoverageId, @EditorId, @EditDate)

    -- Drop Date validation
    -- A Call report must exist for the specified coverage drop date (when previously launched):
    --  * When strategy coverage, i.e. no security, a Call must exist for analyst & industry & drop date combination
    --  * When company coverage, i.e. security, a Call must exist for analyst & security & drop date combination
    -- Optimally, the drop date of a Discontinuing Coverage Call should be specified
    -- (otherwise the date of the last published Call should be specified).
    IF ((@LaunchDate is not null) OR (@LaunchDate <> '')) AND ((@DropDate is not null) OR (@DropDate <> ''))
    BEGIN
      -- Update Industry, Analyst and Security tables to reflect active coverage status (iPad)
      UPDATE Securities2 SET Status = 0,EditDate = getdate() WHERE SecurityId = @SecurityId
      IF NOT EXISTS(SELECT * FROM ResearchCoverage WHERE IndustryId = @IndustryId AND LaunchDate IS NOT NULL AND DropDate IS NULL)
      BEGIN
        UPDATE Industries SET Status = 0,EditDate = getdate() WHERE IndustryId = @IndustryId
      END
      IF NOT EXISTS(SELECT * FROM ResearchCoverage WHERE AnalystId = @AnalystId AND LaunchDate IS NOT NULL AND DropDate IS NULL)
      BEGIN
        UPDATE Authors SET Status = 0,EditDate = getdate() WHERE AuthorId = @AnalystId
      END
      -- Strategy coverage: Get PubNo for specified Call & analyst & industry & drop date combination
      IF ((@SecurityId is null) OR (@SecurityId < 1))
      BEGIN
        SELECT @PubNo = max(P.PubNo)
        FROM Publications P
        JOIN Properties Pr ON P.PubNo = Pr.PubNo AND Pr.PropId = 5
        JOIN Authors A ON Pr.PropValue = A.Name
        JOIN Properties Pr2 ON P.Pubno = Pr2.PubNo AND Pr2.PropId = 11
        JOIN Industries I ON Pr2.PropValue = I.IndustryName
        WHERE
          P.Type = 'Research Call' AND
          A.AuthorId = @AnalystId AND
          I.IndustryId = @IndustryId AND
          P.Date = @DropDate
      END
      -- Company coverage: Get PubNo for specified Call & analyst & security & drop date combination
      ELSE
      BEGIN
        SELECT @PubNo = max(P.PubNo )
        FROM Publications P
        JOIN Properties Pr ON P.PubNo = Pr.PubNo AND Pr.PropId = 5
        JOIN Authors A ON Pr.PropValue = A.Name
        JOIN Properties Pr2 ON P.Pubno = Pr2.PubNo AND Pr2.PropId = 13
        JOIN Securities2 S ON Pr2.PropValue = S.Ticker
        WHERE
          P.Type = 'Research Call' AND
          A.AuthorId = @AnalystId AND
          S.SecurityId = @SecurityId AND
          P.Date = @DropDate
      END

      --If Call does not exist for drop date then rollback
      IF (@PubNo is null)
      BEGIN
          ROLLBACK TRANSACTION
          RETURN -1
      END

      --If Call exists for drop date
      --  * Set the Coverage Action to Drop or Suspend
      --  * Set the Rating Action to Drop
      IF ((@SecurityId is not null) AND (@SecurityId > 1))
      BEGIN
        IF @DropInd = 'S'
          SELECT @CoverageAction = 'Suspend', @RatingAction = 'Drop'
        ELSE
          SELECT @CoverageAction = 'Drop', @RatingAction = 'Drop'

        UPDATE PublicationFinancials
        SET CoverageAction = @CoverageAction, RatingAction = @RatingAction
        WHERE
          PubNo = @PubNo AND
          Ticker = (SELECT Ticker FROM Securities2 WHERE SecurityId = @SecurityId)
      END
    END
  END
ELSE
  -- NEW COVERAGE
  BEGIN
    INSERT INTO ResearchCoverage (IndustryId, AnalystId, SecurityId, LaunchDate, LaunchInd, DropDate, DropInd, EditorId, EditDate, ModelDistribution)
    VALUES (@IndustryId, @AnalystId, @SecurityId, @LaunchDate, @LaunchInd, @DropDate, @DropInd, @EditorId, @EditDate, 'Y')
    SELECT @CoverageId = @@IDENTITY

    SELECT @MsgNew = I.IndustryName + ' | ' + A.Last + ' | ' + ISNULL(S.Ticker, '-')
    FROM ResearchCoverage RC
    JOIN Industries I ON I.IndustryId = RC.IndustryId
    JOIN Authors A ON A.AuthorId = RC.AnalystId
    LEFT JOIN Securities2 S ON S.SecurityId = RC.SecurityId
    WHERE RC.CoverageId = @CoverageId

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Coverage', 'A', @MsgNew, null, @CoverageId, @EditorId, @EditDate)

    -- When new coverage is added:
    -- 1) Initialize FinancialCompanySettings (TickerTableEps, TickerTableValuation, BaseYear & BaseQuarter)
    -- 2) Initialize FinancialSecuritySettings (Model Currency, Model Units)
    -- 3) Exclude EPS Alternate from estimate set
    DECLARE @BaseYear char(4), @BaseQuarter char(2), @TickerTableEpsId int, @TickerTableValuationId int, @UnitMultiplier bigint,@EPSAltId int

    SELECT @BaseYear = convert(varchar,datepart(yy,@EditDate) - 1), @BaseQuarter = 'Q1', @UnitMultiPlier = 1000000
    SELECT @TickerTableEpsId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'EPSRPT'
    SELECT @TickerTableValuationId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'P/EPSRPT'
    SELECT @EPSAltId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'EPS_ALT'

    --While adding a secondary ticker to coverage do not insert row into FinancialCompanySettings table (as parent ticker setup added the required row)
    IF NOT EXISTS(SELECT * FROM FinancialCompanySettings FCS JOIN Securities2 S ON FCS.CompanyId = S.CompanyId WHERE S.SecurityId = @SecurityId)
    BEGIN
      INSERT INTO dbo.FinancialCompanySettings(CompanyId,TickerTableEpsId,TickerTableValuationId,BaseYear,BaseQuarter,EditorId,EditDate)
      SELECT S.CompanyId,@TickerTableEpsId,@TickerTableValuationId,@BaseYear,@BaseQuarter,@EditorId,@EditDate
      FROM Securities2 S
      WHERE S.SecurityId = @SecurityId
    END

    IF NOT EXISTS(SELECT * FROM FinancialSecuritySettings WHERE SecurityId = @SecurityId)
    BEGIN
      INSERT INTO dbo.FinancialSecuritySettings(SecurityId,CurCode,UnitMultiplier,EditorId,EditDate)
      SELECT @SecurityId,CurrencyCode,@UnitMultiPlier,@EditorId,@EditDate
      FROM Securities2 S
      WHERE S.SecurityId = @SecurityId
    END

    --While adding a secondary ticker to coverage do not insert eps_alt exclusion row into FinancialSetExclusions table (as parent ticker setup added the required row)
    IF NOT EXISTS(SELECT * FROM FinancialSetExclusions FCS JOIN Securities2 S ON FCS.CompanyId = S.CompanyId WHERE S.SecurityId = @SecurityId AND FinancialNumberTypeId = @EPSAltId)
    BEGIN
      INSERT INTO dbo.FinancialSetExclusions(CompanyId,FinancialNumberTypeId,EditorId,EditDate)
      SELECT S.CompanyId,@EPSAltId,@EditorId,@EditDate
      FROM Securities2 S
      WHERE S.SecurityId = @SecurityId
    END
  END
END TRY
BEGIN CATCH
  IF @@TRANCOUNT > 0
  ROLLBACK TRANSACTION
END CATCH
  IF @@TRANCOUNT > 0
  COMMIT TRANSACTION
RETURN 0
GO

-- ===================================================================================
-- Author:    Steven Chen
-- Create date: July 10, 2007
-- Description: Update an existing product group
-- ===================================================================================
ALTER PROCEDURE [dbo].[spUpdateProductGroup]
  @ProductGroupId INT,
  @Name VARCHAR(200),
  @Description VARCHAR(8000),
  @FieldsXml TEXT
AS
BEGIN
  SET NOCOUNT ON

  -- Update group name and description
  UPDATE ProductGroups
  SET ProductGroupName = @Name, ProductGroupDescription = @Description
  WHERE ProductGroupId = @ProductGroupId

  -- Delete all existing product group definitions
  DELETE FROM ProductGroupFields
  WHERE ProductGroupId = @ProductGroupId

  -- Create XML handle
  DECLARE @hFieldsXml INT
  EXEC sp_xml_preparedocument @hFieldsXml OUTPUT, @FieldsXml

  -- Recreate new product group definitions
  INSERT INTO [dbo].[ProductGroupFields] (ProductGroupID, FieldId, FieldValue)

  SELECT  @ProductGroupID,
      Field.ID,
      Field.Value
  FROM  OPENXML(@hFieldsXml, '/ProductGroupFields/Field')
    WITH( [ID] INT, [Value] VARCHAR(100) ) Field

  -- Populate product group documents
  EXEC spInsProductGroupDocsByProductGroup @ProductGroupId

  SET NOCOUNT OFF
END
GO

if exists(select * from sys.objects where name like '%spSaveProductGroupModelsByTicker%')
drop proc dbo.spSaveProductGroupModelsByTicker
go

if exists(select * from sys.objects where name like '%spSaveProductGroupModelsByProductGroup%')
drop proc dbo.spSaveProductGroupModelsByProductGroup
go

