-- spRenderLinkStatus.sql
-- 07/02/2018

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM sys.objects where name = 'spRenderLinkStatus')
DROP PROCEDURE [dbo].[spRenderLinkStatus]
GO

CREATE PROCEDURE [dbo].[spRenderLinkStatus]
AS
BEGIN

SELECT V.Value, V.Display
FROM
(

  -- Success
  SELECT
    'Value'   = ISNULL(STUFF((SELECT ',' + CONVERT(VARCHAR(10), StatusId)
      FROM LinkStatus WHERE StatusId >= 100 ORDER BY StatusId FOR XML PATH('')), 1, 1, ''), ''),
    'Display' = 'SUCCESS', 'Cat' = 1, 'SeqNo' = 0
  UNION
  SELECT
    'Value'   = CONVERT(varchar, StatusId),
    'Display' = '-- ' + Status, 'Cat' = 1, 'SeqNo' = StatusId
  FROM LinkStatus
  WHERE StatusId >= 100

  UNION

  -- Failure
  SELECT
    'Value'   = ISNULL(STUFF((SELECT ',' + CONVERT(VARCHAR(10), StatusId)
      FROM LinkStatus WHERE StatusId < 100 ORDER BY StatusId FOR XML PATH('')), 1, 1, ''), ''),
    'Display' = 'FAILURE', 'Cat' = 2, 'SeqNo' = 0
  UNION
  SELECT
    'Value'   = CONVERT(varchar, StatusId),
    'Display' = '-- ' + Status, 'Cat' = 2, 'SeqNo' = StatusId
  FROM LinkStatus
  WHERE StatusId < 100

) V
ORDER BY V.Cat, V.SeqNo

END
GO

GRANT EXECUTE ON [spRenderLinkStatus] TO DE_IIS, PowerUsers
GO

EXEC [spRenderLinkStatus]
GO