-- CC_RestrictedList_Rollback.sql
-- 04/26/2018

/*

alter DistributionSites
alter spGetDistributionSite
alter spSaveDistributionSite
create spGetAdapterRestrictedList

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spGetDistributionSite]
  @SiteID         int,
  @Site           varchar(32)  OUTPUT,
  @Model          char(4)      OUTPUT,
  @AdapterID      int          OUTPUT,
  @Codeset        varchar(16)  OUTPUT,
  @FtpType        varchar(10)  OUTPUT,
  @FtpLogon       varchar(64)  OUTPUT,
  @FtpPassword    varchar(16)  OUTPUT,
  @FtpPort        int          OUTPUT,
  @FtpFolder      varchar(48)  OUTPUT,
  @ScbFolder      varchar(48)  OUTPUT,
  @RixmlOrgIdType varchar(100) OUTPUT,
  @RixmlOrgId     varchar(100) OUTPUT,
  @WatermarkText  varchar(100) OUTPUT,
  @UseSchedule    int          OUTPUT,
  @Active         int          OUTPUT,
  @Editor         varchar(36)  OUTPUT,
  @EditDate       datetime     OUTPUT
AS
SELECT
  @Site           = SI.Site,
  @Model          = SI.Model,
  @AdapterID      = SI.AdapterID,
  @Codeset        = SI.Codeset,
  @FtpType        = SI.FtpType,
  @FtpLogon       = SI.FtpLogon,
  @FtpPassword    = SI.FtpPassword,
  @FtpPort        = SI.FtpPort,
  @FtpFolder      = SI.FtpFolder,
  @ScbFolder      = SI.ScbFolder,
  @RixmlOrgIdType = SI.RixmlOrgIdType,
  @RixmlOrgId     = SI.RixmlOrgId,
  @WatermarkText  = SI.WatermarkText,
  @UseSchedule    = SI.UseSchedule,
  @Active         = SI.Active,
  @Editor         = E.UserName,
  @EditDate       = SI.EditDate
FROM DistributionSites SI
LEFT JOIN Users E ON E.UserID = SI.EditorID
WHERE SI.SiteID = @SiteID
GO

ALTER PROCEDURE [dbo].[spSaveDistributionSite]
  @SiteID         int OUTPUT,
  @Site           varchar(32),
  @Model          char(4),
  @AdapterID      int,
  @Codeset        varchar(16),
  @FtpType        varchar(10),
  @FtpLogon       varchar(64),
  @FtpPassword    varchar(16),
  @FtpPort        int,
  @FtpFolder      varchar(48),
  @ScbFolder      varchar(48),
  @RixmlOrgIdType varchar(100),
  @RixmlOrgId     varchar(100),
  @WatermarkText  varchar(100),
  @UseSchedule    int,
  @Active         int,
  @EditorID       int
AS
DECLARE @EditDate datetime
SELECT  @EditDate = GETDATE()
BEGIN TRANSACTION
IF EXISTS (SELECT SiteID FROM DistributionSites WHERE SiteID = @SiteID)
  BEGIN
    UPDATE DistributionSites SET
      Site           = @Site,
      Model          = @Model,
      AdapterID      = @AdapterID,
      Codeset        = @Codeset,
      FtpType        = @FtpType,
      FtpLogon       = @FtpLogon,
      FtpPassword    = @FtpPassword,
      FtpPort        = @FtpPort,
      FtpFolder      = @FtpFolder,
      ScbFolder      = @ScbFolder,
      RixmlOrgIdType = @RixmlOrgIdType,
      RixmlOrgId     = @RixmlOrgId,
      WatermarkText  = @WatermarkText,
      UseSchedule    = @UseSchedule,
      Active         = @Active,
      EditorID       = @EditorID,
      EditDate       = @EditDate
    WHERE SiteID = @SiteID
  END
ELSE
  BEGIN
    INSERT INTO DistributionSites
      ( Site, Model, AdapterID, Codeset, FtpType, FtpLogon, FtpPassword, FtpPort, FtpFolder, ScbFolder, RixmlOrgIdType, RixmlOrgId, WatermarkText, UseSchedule, Active, EditorID, EditDate)
    VALUES
      (@Site, @Model, @AdapterID, @Codeset, @FtpType, @FtpLogon, @FtpPassword, @FtpPort, @FtpFolder, @ScbFolder, @RixmlOrgIdType, @RixmlOrgId, @WatermarkText, @UseSchedule, @Active, @EditorID, @EditDate)
    SELECT @SiteID = @@IDENTITY
  END
COMMIT TRANSACTION
RETURN 0
GO

IF EXISTS(SELECT * FROM sys.objects where name like '%spGetAdapterRestrictedList%')
DROP PROCEDURE dbo.spGetAdapterRestrictedList
GO
