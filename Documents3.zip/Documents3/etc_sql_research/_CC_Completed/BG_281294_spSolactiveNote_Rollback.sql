-- spSaveSolactiveNote.sql
-- 05/31/2018

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSaveSolactiveNote]
  @SecurityId    int,
  @Note          varchar(2048),
  @EditorId      int
AS

DECLARE
@EditDate datetime,
@Ticker varchar(15),
@OldNote varchar(2048)

SELECT @EditDate = GETDATE()

SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityID = @SecurityId
SELECT @OldNote = Note FROM SolactiveNotes WHERE SecurityId = @SecurityId

BEGIN TRY
  BEGIN TRANSACTION

    -- NO ROW IMPLIES NO NOTE
    IF (LTRIM(RTRIM(@Note)) <> '')
    BEGIN
      IF NOT EXISTS (SELECT SecurityId FROM SolactiveNotes WHERE SecurityId = @SecurityId)
        BEGIN
          INSERT INTO SolactiveNotes (SecurityId, Note, EditorId, EditDate) VALUES (@SecurityId, @Note, @EditorId, GETDATE())

          INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
          VALUES ('SolactiveNotes', 'A', @Ticker + ' | ' + @Note, NULL, @SecurityId, @EditorId, @EditDate)
        END
      ELSE
        BEGIN
          UPDATE SolactiveNotes SET Note = @Note, EditorId = @EditorId, EditDate = GETDATE() WHERE SecurityId = @SecurityId

          INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
          VALUES ('SolactiveNotes', 'U', @Ticker + ' | ' + @Note, @Ticker + ' | ' + @OldNote, @SecurityId, @EditorId, @EditDate)
        END
    END
    ELSE
    BEGIN
      DELETE FROM SolactiveNotes WHERE SecurityId = @SecurityId

      INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
      VALUES ('SolactiveNotes', 'D', '', @Ticker + ' | ' + @OldNote, @SecurityId, @EditorId, @EditDate)
    --    VALUES ('SolactiveNotes', 'D', @Ticker + ' | ', @Ticker + ' | ' + @OldNote, @SecurityId, @EditorId, @EditDate)
    END

    SELECT 0
  COMMIT TRANSACTION
END TRY
BEGIN CATCH
  ROLLBACK TRANSACTION
  SELECT ERROR_NUMBER() AS ErrorNumber, ERROR_MESSAGE() AS ErrorMessage
END CATCH


GO


