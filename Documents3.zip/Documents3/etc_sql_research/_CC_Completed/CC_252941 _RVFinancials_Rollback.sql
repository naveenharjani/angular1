-- CC_RVFinancials_Rollback.sql
-- 02/14/2017

/*

DROP VIEW RVFinancials
DROP TABLE TickerTableValuations
CREATE VIEW RVFinancials
ALTER PROC spRevaluate

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF

GO

IF EXISTS(SELECT * FROM SYS.views WHERE name = 'RVFinancials' AND type = 'V')
DROP VIEW [dbo].[RVFinancials]
GO

IF EXISTS(SELECT * FROM SYS.objects WHERE name = 'TickerTableValuations' AND type = 'U')
DROP TABLE dbo.[TickerTableValuations]
GO

alter view dbo.vFinancialNumbersLatest as

select
  FN.FinancialNumberId,
  FN.SecurityId,
  FN.FinancialNumberTypeId,
  FN.BaseYear,
  FN.FinancialPeriodId,
  FN.PeriodYear,
  FN.Value,
  FN.UnitValue,
  FN.UnitMultiplier,
  FN.CurCode,
  FN.IsDraft,
  FN.IsEstimate,
  FN.Date,
  FN.PubNo,
  FN.CoverageId,
  FN.Source,
  FN.EditorId,
  FN.EditDate
from FinancialNumbers FN
join (select FN2.SecurityId, FinancialNumberTypeId, FinancialPeriodId, IsDraft, max(FN2.Date) Date
      from FinancialNumbers FN2 join Securities2 S on FN2.SecurityId = S.SecurityId
      join FinancialCompanySettings FCS on S.CompanyId = FCS.CompanyId and FN2.BaseYear = FCS.BaseYear
      group by FN2.SecurityId, FinancialNumberTypeId, FinancialPeriodId, IsDraft) V
  on FN.SecurityId = V.SecurityId and FN.FinancialNumberTypeId = V.FinancialNumberTypeId and isnull(FN.FinancialPeriodId,0) = isnull(V.FinancialPeriodId,0) and FN.IsDraft = V.IsDraft and FN.Date = V.Date
go

CREATE VIEW [dbo].[RVFinancials]  WITH SCHEMABINDING AS
SELECT
  S.SecurityId,
  S.Ticker,
  P.Date,
  DocId = TTS.PubNo,
  TTS.CoverageAction,
  TTS.Rating,
  TTS.RatingAction,
  TTS.TargetPrice,
  TTS.TargetPriceAction,
  TTS.ClosePrice,
  TTS.CloseDate,
  TT.LastYear,
  TT.ThisYear,
  TT.NextYear,
  -- EPS
  TT.EPSType,
  TTS.EPSLastYear,
  TTS.EPSThisYear,
  TTS.EPSNextYear,
  TTS.EstimateAction,
  -- Metric
  TT.MetricType,
  TTS.MetricLastYear,
  TTS.MetricThisYear,
  TTS.MetricNextYear,
  -- Other TTS fields
  TTS.Currency,
  TTS.YTDRelPerf,
  TTS.Yield
FROM
  dbo.ResearchCoverage C
JOIN
  dbo.Securities2 S ON C.SecurityId = S.SecurityId
JOIN
  dbo.TickerTableSecurities TTS ON S.Ticker = TTS.Ticker
JOIN
  dbo.TickerTables TT ON TTS.PubNo = TT.PubNo
JOIN
  dbo.Publications P ON P.PubNo = TTS.PubNo
WHERE
  C.LaunchDate is not null and C.DropDate is null

GO

CREATE UNIQUE CLUSTERED INDEX [RVFinancials_Ticker] ON [dbo].[RVFinancials]
(
	[DocId] ASC,
	[Ticker] ASC,
	[Date] ASC
)
GO

ALTER PROCEDURE [dbo].[spRevaluate] @SecurityId int = 0
AS
SET NOCOUNT ON

DECLARE @Type                     char(1),
        @FinancialNumberTypeCat   char(1),
        @EditorId                 int,
        @EditDate                 datetime

SET @Type                   = 'S'  -- Source = Standard formula for valuation
SET @FinancialNumberTypeCat = 'V'  -- Type   = Valuation Field
SET @EditorId               = 0    -- System
SET @EditDate               = getdate()

-- Cleanup Valuations each time
IF @SecurityId = 0
  DELETE FROM Valuations
ELSE
  DELETE FROM Valuations WHERE SecurityId = @SecurityId

-- Hold valuations rowset - Draft and Live
SELECT FNT.*,isDraft = 0 INTO #FNTP FROM vEstimateSetsPeriods FNT WHERE 1 = 2
IF @SecurityId = 0
BEGIN
  INSERT INTO #FNTP
  SELECT FNT.*, isDraft = 0
  FROM vEstimateSetsPeriods FNT WHERE FNT.FinancialNumberTypeCat = 'V'  AND FNT.FinancialPeriodCat = 'Y'
  UNION
  SELECT FNT.*, isDraft = 1
  FROM vEstimateSetsPeriods FNT WHERE FNT.FinancialNumberTypeCat = 'V'  AND FNT.FinancialPeriodCat = 'Y'
END
ELSE
BEGIN
  INSERT INTO #FNTP
  SELECT FNT.*, isDraft = 0
  FROM vEstimateSetsPeriods FNT WHERE FNT.FinancialNumberTypeCat = 'V' AND SecurityId = @SecurityId AND FNT.FinancialPeriodCat = 'Y'
  UNION
  SELECT FNT.*, isDraft = 1
  FROM vEstimateSetsPeriods FNT WHERE FNT.FinancialNumberTypeCat = 'V' AND SecurityId = @SecurityId AND FNT.FinancialPeriodCat = 'Y'
END
--select * from #FNTP

SELECT ROW_NUMBER() OVER(ORDER BY FormulaPassNo,FinancialNumberTypeId) as Row, FinancialNumberTypeId,FormulaPassNo,Formula,IsPercent,Numerator = substring(Formula,2,charindex(']',Formula)-2),Denominator=replace(substring(Formula,charindex('/[',Formula) + 2,len(Formula)-charindex('/[',Formula) + 1),']','')
INTO #ValuationFormulae
FROM FinancialNumberTypes  WHERE FinancialNumberTypeCat = 'V' --AND FinancialNumberTypeId not in (31,32)

DECLARE @Numerator varchar(30), @Denominator varchar(30),@Formula varchar(100),@Row int,@IsPercent int,@FinancialNumberTypeId int
DECLARE @NumeratorTypeId varchar(30), @DenominatorTypeId varchar(30), @NumeratorType char(1), @DenominatorType char(1),@NumeratorTickerType varchar(10),@DenominatorTickerType varchar(10)
DECLARE @FXRateId int

SELECT top 1 @FinancialNumberTypeId=FinancialNumberTypeId,@Numerator = Numerator,@Denominator = Denominator,@Formula = Formula, @Row = Row,@IsPercent = IsPercent FROM #ValuationFormulae  ORDER BY Row
SELECT @FXRateId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'FXRATE'
WHILE @@ROWCOUNT = 1
BEGIN
  --SELECT @FinancialNumberTypeId,@Numerator ,@Denominator ,@Formula , @Row ,@IsPercent
  --Initialize for every valuation row
  SELECT @NumeratorTypeId = null,@DenominatorTypeId = null,@NumeratorType = null,@DenominatorType = null,@NumeratorTickerType = null,@DenominatorTickerType = null

  --Check if numerator or denominator are index valuations
  IF @Numerator like '%IDX!%'
  SELECT @NumeratorTickerType = 'Index',@Numerator = REPLACE(@Numerator,'IDX!','')
  ELSE
  SELECT @NumeratorTickerType = 'Ticker'

  IF @Denominator like '%IDX!%'
  SELECT @DenominatorTickerType = 'Index',@Denominator = REPLACE(@Numerator,'IDX!','')
  ELSE
  SELECT @DenominatorTickerType = 'Ticker'

  SELECT @NumeratorTypeId = FinancialNumberTypeId, @NumeratorType = FinancialNumberTypeCat FROM FinancialNumberTypes WHERE FinancialNumberType = @Numerator
  SELECT @DenominatorTypeId = FinancialNumberTypeId, @DenominatorType = FinancialNumberTypeCat FROM FinancialNumberTypes WHERE FinancialNumberType = @Denominator

  --SELECT @FinancialNumberTypeId,@NumeratorTypeId,@NumeratorType,@Numerator,@NumeratorTickerType,@DenominatorTypeId,@DenominatorType,@Denominator,@DenominatorTickerType,@Formula,@IsPercent

  --CASE 1: If Numerator is market data field, denominator is estimate data field and both are for a ticker
  IF @NumeratorType = 'M' AND @DenominatorType = 'E' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Ticker'
  BEGIN
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VE.PeriodYear,''),
      ISNULL(VE.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VMD.Value) = 1 AND ISNUMERIC(VE.Value)  = 1
          THEN CASE
               WHEN CAST(VE.Value AS FLOAT)  = 0 THEN NULL
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 1 AND VMDL.Value IS NOT NULL THEN CONVERT(varchar,CAST(((CAST(VMD.Value AS FLOAT) * 100) / (CAST(VE.Value AS FLOAT) * CAST(VMDL.Value AS FLOAT))) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 1 THEN CONVERT(varchar,CAST(((CAST(VMD.Value AS FLOAT) * 100) / (CAST(VE.Value AS FLOAT) * ISNULL(VBF.Value,1))) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 0 AND VMDL.Value IS NOT NULL THEN CONVERT(varchar, CAST((CAST(VMD.Value AS FLOAT) / (CAST(VE.Value AS FLOAT) * CAST(VMDL.Value AS FLOAT))) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VMD.Value AS FLOAT) / (CAST(VE.Value AS FLOAT) * ISNULL(VBF.Value,1))) AS DECIMAL(18,2)))
               WHEN VMD.CurCode = VE.CurCode  AND @IsPercent = 1 THEN CONVERT(varchar,CAST(((CAST(VMD.Value AS FLOAT) * 100) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
               WHEN VMD.CurCode = VE.CurCode  AND @IsPercent = 0 THEN CONVERT(varchar,CAST((CAST(VMD.Value AS FLOAT) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
               ELSE                                                   CONVERT(varchar,CAST(CAST(VMD.Value AS FLOAT) / CAST(VE.Value AS FLOAT) AS DECIMAL(18,2)))
               END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vFinancialNumbersLatest VE ON VE.SecurityId = FNT.SecurityId AND ISNULL(VE.CoverageId,'') = ISNULL(FNT.CoverageId,'')
    AND VE.FinancialNumberTypeId = @DenominatorTypeId
    --AND VE.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = FNT.IsDraft

    LEFT JOIN vMarketData VMD ON VMD.SecurityId = FNT.SecurityId
    --AND VMD.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VMD.FinancialNumberTypeId = @NumeratorTypeId
    LEFT JOIN vBloombergFXLatest VBF ON VBF.Ticker = VE.CurCode + VMD.CurCode COLLATE SQL_Latin1_General_CP1_CS_AS AND VBF.BloombergMnemonic = 'PX_LAST'
    LEFT JOIN vMarketDataLatest VMDL ON VMDL.SecurityId = FNT.SecurityId AND VMDL.FinancialNumberTypeId = @FXRateId AND VMDL.Type = 'O'
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FNT.FinancialNumberTypeId = @FinancialNumberTypeId
  END

  --CASE 2 If Numerator is estimate data field, denominator is market data field and both are for a ticker
  IF @NumeratorType = 'E' AND @DenominatorType = 'M' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Ticker'
  BEGIN
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VE.PeriodYear,''),
      ISNULL(VE.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VMD.Value) = 1 AND ISNUMERIC(VE.Value)  = 1
          THEN CASE
               WHEN CAST(VMD.Value AS FLOAT)  = 0 THEN NULL
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 1 AND VMDL.Value IS NOT NULL THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * 100 * CAST(VMDL.Value AS FLOAT)) / CAST(VMD.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * 100 * ISNULL(VBF.Value,1)) / CAST(VMD.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 0 AND VMDL.Value IS NOT NULL THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * CAST(VMDL.Value AS FLOAT)) / CAST(VMD.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 0 THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * ISNULL(VBF.Value,1)) / CAST(VMD.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VMD.CurCode = VE.CurCode  AND @IsPercent = 1 THEN CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) * 100 / CAST(VMD.Value AS FLOAT)) AS DECIMAL(18,2)))
               WHEN VMD.CurCode = VE.CurCode  AND @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) / CAST(VMD.Value AS FLOAT)) AS DECIMAL(18,2)))
               ELSE                                                   CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) / CAST(VMD.Value AS FLOAT)) AS DECIMAL(18,2)))
               END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vFinancialNumbersLatest VE ON VE.SecurityId = FNT.SecurityId AND ISNULL(VE.CoverageId,'') = ISNULL(FNT.CoverageId,'') 
    AND VE.FinancialNumberTypeId = @NumeratorTypeId
    --AND VE.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = FNT.IsDraft
    LEFT JOIN vMarketData VMD ON VMD.SecurityId = FNT.SecurityId
    --AND VMD.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VMD.FinancialNumberTypeId = @DenominatorTypeId
    LEFT JOIN vBloombergFXLatest VBF ON VBF.Ticker = VE.CurCode + VMD.CurCode COLLATE SQL_Latin1_General_CP1_CS_AS AND VBF.BloombergMnemonic = 'PX_LAST'
    LEFT JOIN vMarketDataLatest VMDL ON VMDL.SecurityId = FNT.SecurityId AND VMDL.FinancialNumberTypeId = @FXRateId AND VMDL.Type = 'O'
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FNT.FinancialNumberTypeId = @FinancialNumberTypeId
  END

  --CASE 3 If Numerator is estimate data field, denominator is estimate data field and both are for a ticker
  IF @NumeratorType = 'E' AND @DenominatorType = 'E' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Ticker'
  BEGIN
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VE.PeriodYear,''),
      ISNULL(VE.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VE2.Value) = 1 AND ISNUMERIC(VE.Value) = 1
          THEN CASE
               WHEN CAST(VE2.Value AS FLOAT)  = 0 THEN NULL
               WHEN VE2.CurCode <> VE.CurCode AND @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * 100 * ISNULL(VBF.Value,1)) / CAST(VE2.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VE2.CurCode <> VE.CurCode AND @IsPercent = 0 THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * ISNULL(VBF.Value,1)) / CAST(VE2.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VE2.CurCode = VE.CurCode  AND @IsPercent = 1 THEN CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) * 100 / CAST(VE2.Value AS FLOAT)) AS DECIMAL(18,2)))
               WHEN VE2.CurCode = VE.CurCode  AND @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) / CAST(VE2.Value AS FLOAT)) AS DECIMAL(18,2)))
               ELSE                                           CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) / CAST(VE2.Value AS FLOAT)) AS DECIMAL(18,2)))
               END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vFinancialNumbersLatest VE ON VE.SecurityId = FNT.SecurityId AND ISNULL(VE.CoverageId,'') = ISNULL(FNT.CoverageId,'')
    AND VE.FinancialNumberTypeId = @NumeratorTypeId
    --AND VE.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = FNT.IsDraft
    LEFT JOIN vFinancialNumbersLatest VE2 ON VE2.SecurityId = FNT.SecurityId AND ISNULL(VE2.CoverageId,'') = ISNULL(FNT.CoverageId,'') 
    --AND VE2.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VE2.FinancialNumberTypeId = @DenominatorTypeId
    AND VE2.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE2.IsDraft = FNT.IsDraft
    LEFT JOIN vBloombergFXLatest VBF ON VBF.Ticker = VE.CurCode + VE2.CurCode COLLATE SQL_Latin1_General_CP1_CS_AS AND VBF.BloombergMnemonic = 'PX_LAST'
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FNT.FinancialNumberTypeId = @FinancialNumberTypeId
  END

  --CASE 4 If Numerator is valuation data field, denominator is estimate data field and both are for a ticker
  IF @NumeratorType = 'V' AND @DenominatorType = 'E' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Ticker'
  BEGIN
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VE.PeriodYear,''),
      ISNULL(VE.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VV.Value) = 1 AND ISNUMERIC(VE.Value)  = 1
          THEN
            CASE
              WHEN CAST(VE.Value AS FLOAT)  = 0 THEN NULL
              WHEN @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VV.Value AS FLOAT) * 100) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
              WHEN @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VV.Value AS FLOAT) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
            END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vValuationsLatest VV ON VV.SecurityId = FNT.SecurityId
    AND VV.FinancialNumberTypeId = @NumeratorTypeId
    AND VV.FinancialPeriodId = FNT.FinancialPeriodId
    AND VV.IsDraft = FNT.IsDraft
    LEFT JOIN vFinancialNumbersLatest VE ON VE.SecurityId = FNT.SecurityId AND ISNULL(VE.CoverageId,'') = ISNULL(FNT.CoverageId,'') 
    AND VE.FinancialNumberTypeId = @DenominatorTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = FNT.IsDraft
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FNT.FinancialNumberTypeId     = @FinancialNumberTypeId
  END

  --CASE 5 If Numerator is valuation data field, denominator is valuation data field and both are for a ticker
  IF @NumeratorType = 'V' AND @DenominatorType = 'V' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Ticker'
  BEGIN
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VE.PeriodYear,''),
      ISNULL(VE.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VV.Value) = 1 AND ISNUMERIC(VE.Value) = 1
          THEN
            CASE
              WHEN CAST(VE.Value AS FLOAT)  = 0 THEN NULL
              WHEN @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VV.Value AS FLOAT) * 100) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
              WHEN @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VV.Value AS FLOAT) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
            END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vValuationsLatest VV ON VV.SecurityId = FNT.SecurityId
    AND VV.FinancialNumberTypeId = @NumeratorTypeId
    AND VV.FinancialPeriodId = FNT.FinancialPeriodId
    AND VV.IsDraft = FNT.IsDraft
    LEFT JOIN vValuationsLatest VE ON VE.SecurityId = FNT.SecurityId
    AND VE.FinancialNumberTypeId = @DenominatorTypeId
    AND VV.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = FNT.IsDraft
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FNT.FinancialNumberTypeId     = @FinancialNumberTypeId
  END

    --CASE 6 If Numerator is valuation data field for a ticker and denominator is valuation data field for corresponding index
  IF @NumeratorType = 'V' AND @DenominatorType = 'V' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Index'
  BEGIN
    --For Tickers with base year = index base year
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VV.PeriodYear,''),
      ISNULL(VV.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VV.Value) = 1 AND ISNUMERIC(VE.Value)  = 1
          THEN
            CASE
              WHEN CAST(VE.Value AS FLOAT)  = 0 THEN NULL
              WHEN @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VV.Value AS FLOAT) * 100) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
              WHEN @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VV.Value AS FLOAT) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
            END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vValuationsLatest VV ON VV.SecurityId = FNT.SecurityId
    AND VV.FinancialNumberTypeId = @NumeratorTypeId
    AND VV.FinancialPeriodId = FNT.FinancialPeriodId
    AND VV.IsDraft = FNT.IsDraft
    LEFT JOIN Securities2 S ON FNT.SecurityId = S.SecurityId
    LEFT JOIN FinancialCompanySettings FCS1 ON S.CompanyId = FCS1.CompanyId
    LEFT JOIN Securities2 S2 ON S.BenchmarkIndex = S2.Ticker
    LEFT JOIN FinancialCompanySettings FCS2 ON S2.CompanyId = FCS2.CompanyId
    LEFT JOIN vValuationsLatest VE ON VE.SecurityId = S2.SecurityId
    AND VE.FinancialNumberTypeId = @DenominatorTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = 0 --For index valuations only live values exist.
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FCS1.BaseYear = FCS2.BaseYear
    AND FNT.FinancialNumberTypeId     = @FinancialNumberTypeId

    --For Tickers with base year = index base year + 1
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VV.PeriodYear,''),
      ISNULL(VV.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VV.Value) = 1 AND ISNUMERIC(VE.Value) = 1
          THEN
            CASE
              WHEN CAST(VE.Value AS FLOAT)  = 0 THEN NULL
              WHEN @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VV.Value AS FLOAT) * 100) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
              WHEN @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VV.Value AS FLOAT) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
            END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vValuationsLatest VV ON VV.SecurityId = FNT.SecurityId
    AND VV.FinancialNumberTypeId = @NumeratorTypeId
    AND VV.FinancialPeriodId = FNT.FinancialPeriodId
    AND VV.IsDraft = FNT.IsDraft
    LEFT JOIN Securities2 S ON FNT.SecurityId = S.SecurityId
    LEFT JOIN FinancialCompanySettings FCS1 ON S.CompanyId = FCS1.CompanyId
    LEFT JOIN Securities2 S2 ON S.BenchmarkIndex = S2.Ticker
    LEFT JOIN FinancialCompanySettings FCS2 ON S2.CompanyId = FCS2.CompanyId
    LEFT JOIN vValuationsLatest VE ON VE.SecurityId = S2.SecurityId
    AND VE.FinancialNumberTypeId = @DenominatorTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId + 1 -- Shift base year for index by 1 as ticker base year is > index base year
    AND VE.IsDraft = 0 --For index valuations only live values exist.
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FCS1.BaseYear = FCS2.BaseYear + 1 --Ticker base year = index base year + 1
    AND FNT.FinancialNumberTypeId     = @FinancialNumberTypeId

  END

  SELECT top 1 @FinancialNumberTypeId=FinancialNumberTypeId,@Numerator = Numerator,@Denominator = Denominator,@Formula = Formula, @Row = Row,@IsPercent = IsPercent FROM #ValuationFormulae WHERE Row > @Row ORDER BY Row
END

--Dividend/Share is received from Quant group (source: msci) for msdle15 on a monthly basis
--Revalue msdle15 dividend yeild as we do not get that value from Bloomberg
DECLARE @Divpersh float, @ClosePrice float, @MSDLE15Id int
SELECT @MSDLE15Id = SecurityId FROM Securities2 WHERE Ticker = 'MSDLE15'
SELECT @Divpersh = Convert(float,UnitValue) FROM vMarketDataLatest WHERE SecurityId = @MSDLE15Id AND Type = 'O' AND FinancialNumberTypeId = (SELECT FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'DIVPERSH' AND FinancialNumberTypeCat = 'M')
SELECT @ClosePrice = Convert(float,UnitValue) FROM vMarketDataLatest WHERE SecurityId = @MSDLE15Id AND Type = 'B' AND FinancialNumberTypeId = (SELECT FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'CLOSEPRICE' AND FinancialNumberTypeCat = 'M')
IF ISNUMERIC(@Divpersh) = 1 AND ISNUMERIC(@ClosePrice) = 1
BEGIN
  UPDATE vMarketDataLatest SET UnitValue = convert(decimal(10,2),@Divpersh/@ClosePrice),Value = convert(decimal(10,2),@Divpersh/@ClosePrice)
  WHERE SecurityId = @MSDLE15Id AND Type = 'B' AND FinancialNumberTypeId = (SELECT FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'EQY_DVD_YLD_IND')
END
  SET NOCOUNT OFF
GO