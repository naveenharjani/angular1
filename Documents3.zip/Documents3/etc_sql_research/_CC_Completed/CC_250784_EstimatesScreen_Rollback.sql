-- EstimatesScreen_Rollback.sql
-- 04/06/2017


/*

spGetEstimatesSetEps
spGetEstimatesSetFinancials
spGetEstimatesSetValuations

*/

-- Changes to show Indicates Changes - Yes/No

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO




ALTER PROCEDURE [dbo].[spGetEstimatesSetEps]
    @Ticker       VARCHAR(10)
AS
SET NOCOUNT ON

DECLARE @SecurityId           INT,
        @Company              VARCHAR(60),
        @CompanyId            INT,
        @BaseYear             INT,
        @PivotSQL             NVARCHAR(MAX),
        @PeriodYearList       NVARCHAR(MAX)


IF NOT EXISTS(SELECT * FROM Securities2 WHERE Ticker = @Ticker)
BEGIN
  SELECT 'Ticker:' + CONVERT(varchar, @Ticker) + ' not found.'
  RETURN
END

-- Get SecurityId, Company, BaseYear
SELECT @SecurityId = SecurityId, @Company = Company, @CompanyId = CompanyId
FROM Securities2
WHERE Ticker = @Ticker

SELECT @BaseYear = BaseYear FROM FinancialCompanySettings WHERE CompanyId = @CompanyId

-- primary ticker - get live value set
SELECT
  S.Ticker,
  VFT.FinancialNumberType,
  VFT.FullName,
  VFT.ShortName,
  VFT.Definition,
  '' AS Statement,    -- VFT.Statment  -- add to vEstimateSetsPeriods
  @BaseYear AS BaseYear,
  CASE WHEN VFT.FinancialPeriodId = 1
       THEN 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'A'
       ELSE 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'E' END AS periodYear,
  VFT.CurCode AS Cur,
  FN.Value,
  VFT.SecurityId,
  VFT.FinancialNumberTypeId,
  S.OrdNo,
  VFT.UnitMultiplier,
  ISNULL(VFT.Format,'') AS Format,
  VFT.FinancialNumberTypeCatOrd,
  ISNULL(VFT.Formula,'') AS Formula
INTO #TmpEpsSet
FROM vEstimateSetsPeriods VFT
INNER JOIN Securities2 S ON VFT.SecurityId = S.SecurityId
LEFT JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = VFT.SecurityId
                                     AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                     AND FN.FinancialPeriodId = VFT.FinancialPeriodId
                                     AND FN.IsDraft                = 0  -- Live
WHERE VFT.SecurityId = @SecurityId
AND VFT.FinancialNumberTypeCat = 'E'
AND VFT.FinancialPeriodCat = 'Y'
AND VFT.FinancialNumberType IN ('EPSADJ', 'EPSRPT')

-- Get TimeSeriesMaxValue at FinancialNumberType level
SELECT Ticker, FinancialNumberType,
       MAX(UnitMultiplier) AS UnitMultiplier,
        CASE
          WHEN MAX(ISNUMERIC(Value)) = 0 THEN 0
          --ELSE MAX(CAST(Value AS FLOAT))
          ELSE MAX(ABS(Value))
        END AS TimeSeriesMaxValue
INTO #TmpEpsMax
FROM #TmpEpsSet
WHERE ISNUMERIC(VALUE) = 1
GROUP BY Ticker, FinancialNumberType

-- Get Style at FinancialNumberType level
SELECT Ticker, FinancialNumberType, UnitMultiplier,
       dbo.fnCalculateDisplayUnits(TimeSeriesMaxValue, UnitMultiplier) AS DisplayUnits
INTO #TmpEstimatesStyles
FROM #TmpEpsMax

-- Get Period list for the PIVOT Column list
SELECT @PeriodYearList = ISNULL(@PeriodYearList + ',','') + QUOTENAME(periodYear)
FROM (
       SELECT distinct periodYear FROM #TmpEpsSet
     ) AS Periods


 SELECT TE.FinancialNumberType, TE.FullName, TE.ShortName, TE.Definition, TE.Statement, TE.Cur, TE.periodYear, TE.FinancialNumberTypeId, TE.Format,
       dbo.fnConvertDisplayUnits(TE.Value, TS.DisplayUnits) AS Value,  --Converted value
       -- TE.Value, -- raw number
       dbo.fnCalculateDisplayUnitsStyle(TS.DisplayUnits)   AS DisplayUnit,
       dbo.fnCalculateDisplayUnitsStyle(TE.UnitMultiplier) AS ModelUnit,
       TE.FinancialNumberTypeCatOrd, 
       TE.Formula
INTO #TmpEpsEstimates
FROM #TmpEpsSet TE
INNER JOIN #TmpEstimatesStyles TS ON TE.Ticker = TS.Ticker AND TE.FinancialNumberType = TS.FinancialNumberType

-- Prepare the dynamic PIVOT query
SELECT @PivotSQL =
  N'SELECT FinancialNumberType, FullName, ShortName, Definition, Statement, Cur, Format, ModelUnit, DisplayUnit, Formula, ' + @PeriodYearList + '
    FROM #TmpEpsEstimates
    PIVOT(MAX([Value])
          FOR periodYear IN (' + @PeriodYearList + ')) AS PVTTable
          ORDER BY FinancialNumberTypeCatOrd asc'

--Execute the dynamic Pivot query
EXEC sp_executesql @PivotSQL

SET NOCOUNT OFF



GO



ALTER PROCEDURE [dbo].[spGetEstimatesSetFinancials]
  @Ticker       VARCHAR(10),
  @IsPerShare   SMALLINT = NULL   -- Per Share(1) or Non Per Share(0) or both(NULL)
AS
SET NOCOUNT ON

DECLARE @SecurityId           INT,
        @Company              VARCHAR(60),
        @CompanyId            INT,
        @BaseYear             INT,
        @PivotSQL             NVARCHAR(MAX),
        @PeriodYearList       NVARCHAR(MAX)

IF NOT EXISTS(SELECT * FROM Securities2 WHERE Ticker = @Ticker)
BEGIN
  SELECT 'Ticker:' + CONVERT(varchar, @Ticker) + ' not found.'
  RETURN
END

-- Get SecurityId, Company, BaseYear
SELECT @SecurityId = SecurityId, @Company = Company, @CompanyId = CompanyId
FROM Securities2
WHERE Ticker = @Ticker

SELECT @BaseYear = BaseYear FROM FinancialCompanySettings WHERE CompanyId = @CompanyId

DECLARE @ModelCurCode          VARCHAR(3)
DECLARE @ModelUnitMultiplier   CHAR(1)

SELECT @ModelUnitMultiplier =
        CASE
          WHEN FSS.UnitMultiplier IS NULL THEN  dbo.fnCalculateDisplayUnitsStyle(1)
          ELSE dbo.fnCalculateDisplayUnitsStyle(FSS.UnitMultiplier)
        END,
       @ModelCurCode = case when FSS.CurCode is not null then FSS.CurCode else S.CurrencyCode end
from Securities2 S
left join FinancialSecuritySettings FSS on FSS.SecurityId = S.SecurityId
where S.SecurityId = @SecurityId

-- Get live value set for primary ticker
SELECT
  S.Ticker,
  VFT.FinancialNumberType,
  VFT.FullName,
  VFT.ShortName,
  VFT.Definition,
  '' AS Statement,    -- VFT.Statment  -- add to vEstimateSetsPeriods
  @BaseYear AS BaseYear,
  CASE WHEN VFT.FinancialPeriodId = 1
       THEN 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'A'
       ELSE 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'E' END AS periodYear,
  VFT.CurCode AS Cur,
  FN.Value,
  VFT.SecurityId,
  VFT.FinancialNumberTypeId,
  S.OrdNo,
  VFT.UnitMultiplier,
  ISNULL(VFT.Format,'') AS Format,
  VFT.IsPerShare,
  VFT.FinancialNumberTypeCatOrd,
  ISNULL(VFT.Formula,'') AS Formula
INTO #TmpFinancialsSet
FROM vEstimateSetsPeriods VFT
INNER JOIN Securities2 S ON VFT.SecurityId = S.SecurityId
LEFT JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = VFT.SecurityId
                                        AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                        AND FN.FinancialPeriodId = VFT.FinancialPeriodId
                                        AND FN.IsDraft                = 0  -- Live
WHERE  VFT.SecurityId = @SecurityId
AND VFT.FinancialNumberTypeCat = 'E'
AND VFT.FinancialPeriodCat = 'Y'
AND VFT.FinancialNumberType NOT IN ('EPSADJ', 'EPSRPT')

-- Get Style at FinancialNumberType level
SELECT Ticker, FinancialNumberType,
       MAX(UnitMultiplier) AS UnitMultiplier,
        CASE
          WHEN MAX(ISNUMERIC(Value)) = 0 THEN 0
          --ELSE MAX(CAST(Value AS FLOAT))
          ELSE MAX(ABS(Value))
        END AS TimeSeriesMaxValue
INTO #TmpFinancialsMax
FROM #TmpFinancialsSet
WHERE ISNUMERIC(VALUE) = 1
GROUP BY Ticker, FinancialNumberType

SELECT Ticker, FinancialNumberType, UnitMultiplier,
       dbo.fnCalculateDisplayUnits(TimeSeriesMaxValue, UnitMultiplier) AS DisplayUnits
INTO #TmpFinancialsStyles
FROM #TmpFinancialsMax

-- Get FinancialPeriod list as PIVOT Column
SELECT @PeriodYearList= ISNULL(@PeriodYearList + ',','') + QUOTENAME(periodYear)
FROM (
  SELECT distinct periodYear FROM #TmpFinancialsSet
) AS Periods

SELECT TE.FinancialNumberType, TE.FullName, TE.ShortName, TE.Definition, TE.Statement, TE.Cur, TE.periodYear, TE.FinancialNumberTypeId, TE.Format,
       dbo.fnConvertDisplayUnits(TE.Value, TS.DisplayUnits) AS Value,  --Converted value
       -- TE.Value, -- raw number
       dbo.fnCalculateDisplayUnitsStyle(TS.DisplayUnits) AS DisplayUnit,
       TE.IsPerShare,
       dbo.fnCalculateDisplayUnitsStyle(TE.UnitMultiplier) AS ModelUnit,
       TE.FinancialNumberTypeCatOrd, 
       TE.Formula
INTO #TmpFinancials
FROM #TmpFinancialsSet TE
INNER JOIN #TmpFinancialsStyles TS ON TE.Ticker = TS.Ticker AND TE.FinancialNumberType = TS.FinancialNumberType

-- Prepare the dynamic PIVOT query
SET @PivotSQL =
  N'SELECT FinancialNumberType, FullName, ShortName, Definition, Statement, Cur, Format, ''' + @ModelUnitMultiplier + + ''' AS ModelUnit, DisplayUnit, Formula, ' + @PeriodYearList + '
    FROM #TmpFinancials
    PIVOT(MAX([Value])
          FOR periodYear IN (' + @PeriodYearList + ')) AS PVTTable'

--SELECT @PivotSQL 

-- If Per Share or Non Per Share
IF @IsPerShare IN (0, 1)
  SET @PivotSQL = @PivotSQL + ' WHERE IsPerShare = ' + CONVERT(varchar, @IsPerShare) + ''

SET @PivotSQL = @PivotSQL + ' ORDER BY FinancialNumberTypeCatOrd asc'

--Execute the Dynamic Pivot Query
EXEC sp_executesql @PivotSQL


SET NOCOUNT OFF



GO



ALTER PROCEDURE [dbo].[spGetEstimatesSetValuations]
    @Ticker       VARCHAR(10)
AS
SET NOCOUNT ON

DECLARE @SecurityId           INT,
        @Company              VARCHAR(60),
        @CompanyId            INT,
        @BaseYear             INT,
        @PivotSQL             NVARCHAR(MAX),
        @PeriodYearList       NVARCHAR(MAX)

IF NOT EXISTS(SELECT * FROM Securities2 WHERE Ticker = @Ticker)
BEGIN
  SELECT 'Ticker:' + CONVERT(varchar, @Ticker) + ' not found.'
  RETURN
END

-- Get SecurityId, Company, BaseYear
SELECT @SecurityId = SecurityId, 
       @Company = Company, @CompanyId = CompanyId
FROM Securities2
WHERE Ticker = @Ticker

SELECT @BaseYear = BaseYear FROM FinancialCompanySettings WHERE CompanyId = @CompanyId

-- Get live value set for primary ticker
SELECT
  S.Ticker,
  VFT.FinancialNumberType,
  VFT.FullName,
  VFT.ShortName,
  VFT.Definition,
  '' AS Statement,    -- VFT.Statment  -- add to vEstimateSetsPeriods
  @BaseYear AS BaseYear,
  CASE WHEN VFT.FinancialPeriodId = 1
       THEN 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'A'
       ELSE 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'E' END AS periodYear,
  VFT.CurCode AS Cur,
  CONVERT(varchar,ISNULL(FN.Value,''))  AS Value,
  VFT.SecurityId,
  VFT.FinancialNumberTypeId,
  S.OrdNo,
  ISNULL(VFT.Format,'') AS Format,
  '' AS ModelUnit,
  '' AS DisplayUnit,
  VFT.FinancialNumberTypeCatOrd,
  ISNULL(VFT.Formula,'') AS Formula
INTO #TmpValuationsSet
FROM vEstimateSetsPeriods VFT
INNER JOIN Securities2 S ON VFT.SecurityId = S.SecurityId
INNER JOIN vValuationsLatest FN       ON FN.SecurityId = VFT.SecurityId
                                        AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                        AND FN.FinancialPeriodId = VFT.FinancialPeriodId
                                        AND FN.IsDraft                = 0  -- Live
WHERE  VFT.SecurityId = @SecurityId
AND VFT.FinancialNumberTypeCat = 'V'
AND VFT.FinancialPeriodCat = 'Y'

-- Get FinancialPeriod list as PIVOT Column
SELECT @PeriodYearList= ISNULL(@PeriodYearList + ',','') + QUOTENAME(periodYear)
FROM (
    -- SELECT distinct FinancialPeriod FROM vEstimateSetsPeriods WHERE SecurityId = @SecurityId AND FinancialPeriodCat = 'Y'
    SELECT distinct periodYear FROM #TmpValuationsSet
) AS Periods

-- Prepare the dynamic PIVOT query
SET @PivotSQL =
  N'SELECT FinancialNumberType, FullName, ShortName, Definition, Statement, Cur, Format, ModelUnit, DisplayUnit, Formula, ' + @PeriodYearList + '
    FROM #TmpValuationsSet
    PIVOT(MAX([Value])
          FOR periodYear IN (' + @PeriodYearList + ')) AS PVTTable
          ORDER BY FinancialNumberTypeCatOrd asc'

--Execute the Dynamic Pivot Query
EXEC sp_executesql @PivotSQL

SET NOCOUNT OFF



GO