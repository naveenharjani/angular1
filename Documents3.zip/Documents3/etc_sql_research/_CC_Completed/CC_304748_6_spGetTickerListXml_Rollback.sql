--CC_spGetTickerListXml_Rollback
--02/19/2019
USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spGetTickerListXml]
AS
BEGIN
--Securities XML
--To preorder the list of securities for document infomation dialog box
--This is because rptools.xml has different structure (by analysts)

  select
    1                          AS tag,
    null                       AS parent,
    null                       AS [Root!1!!element],
    null                       AS [Securities!2!!element],
    null                       AS [Security!3!displayNo!hide],
    null                       AS [Security!3!companyId],
    null                       AS [Security!3!company],
    null                       AS [Security!3!securityId],
    null                       AS [Security!3!ticker],
    null                       AS [Security!3!benchmarkIndex],
    null                       AS [Security!3!launchDate],
    null                       AS [Security!3!isPrimary],
    null                       AS [Security!3!authorId],
    null                       AS [Security!3!industryId],
    null                       AS [Security!3!coverageId],
    null                       AS [Indexes!4!!element],
    null                       AS [Index!5!securityId],
    null                       AS [Index!5!ticker],
    null                       AS [Index!5!company]

  union all

  select
    2                          AS tag,
    1                          AS parent,
    null                       AS [Root!1!!element],
    null                       AS [Securities!2!!element],
    1                          AS [Security!3!displayNo!hide],
    null                       AS [Security!3!companyId],
    null                       AS [Security!3!company],
    null                       AS [Security!3!securityId],
    null                       AS [Security!3!ticker],
    null                       AS [Security!3!benchmarkIndex],
    null                       AS [Security!3!launchDate],
    null                       AS [Security!3!isPrimary],
    null                       AS [Security!3!authorId],
    null                       AS [Security!3!industryId],
    null                       AS [Security!3!coverageId],
    null                       AS [Indexes!4!!element],
    null                       AS [Index!5!securityId],
    null                       AS [Index!5!ticker],
    null                       AS [Index!5!company]

  union all

  select
    3                          AS tag,
    2                          AS parent,
    null                       AS [Root!1!!element],
    null                       AS [Securities!2!!element],
    2                          AS [Security!3!displayNo!hide],
    s.CompanyId                AS [Security!3!companyId],
    s.Company                  AS [Security!3!company],
    s.SecurityId               AS [Security!3!securityId],
    s.Ticker                   AS [Security!3!ticker],
    s.BenchmarkIndex           AS [Security!3!benchmarkIndex],
    rc.LaunchDate              AS [Security!3!launchDate],
    s.IsPrimary                AS [Security!3!isPrimary],
    A.AuthorId                 AS [Security!3!authorId],
    I.IndustryId               AS [Security!3!industryId],
    RC.CoverageId              AS [Security!3!coverageId],
    null                       AS [Indexes!4!!element],
    null                       AS [Index!5!securityId],
    null                       AS [Index!5!ticker],
    null                       AS [Index!5!company]
  from securities2 S
  join ResearchCoverage RC on S.SecurityId = RC.SecurityId
  join Authors A on RC.AnalystId = A.AuthorId
  join Industries I on RC.IndustryId = I.IndustryId
  where RC.DropDate is null

  union all

  select
    4                           AS tag,
    1                           AS parent,
    null                        AS [Root!1!!element],
    null                        AS [Securities!2!!element],
    3                           AS [Security!3!displayNo!hide],
    null                        AS [Security!3!companyId],
    null                        AS [Security!3!company],
    null                        AS [Security!3!securityId],
    null                        AS [Security!3!ticker],
    null                        AS [Security!3!benchmarkIndex],
    null                        AS [Security!3!launchDate],
    null                        AS [Security!3!isPrimary],
    null                        AS [Security!3!authorId],
    null                        AS [Security!3!industryId],
    null                        AS [Security!3!coverageId],
    null                        AS [Indexes!4!!element],
    null                        AS [Index!5!securityId],
    null                        AS [Index!5!ticker],
    null                        AS [Index!5!company]

  union all

  select distinct
    5                           AS tag,
    4                           AS parent,
    null                        AS [Root!1!!element],
    null                        AS [Securities!2!!element],
    4                           AS [Security!3!displayNo!hide],
    null                        AS [Security!3!companyId],
    null                        AS [Security!3!company],
    null                        AS [Security!3!securityId],
    null                        AS [Security!3!ticker],
    null                        AS [Security!3!benchmarkIndex],
    null                        AS [Security!3!launchDate],
    null                        AS [Security!3!isPrimary],
    null                        AS [Security!3!authorId],
    null                        AS [Security!3!industryId],
    null                        AS [Security!3!coverageId],
    null                        AS [Indexes!4!!element],
    S.SecurityId                AS [Index!5!securityId],
    S.Ticker                    AS [Index!5!ticker],
    S.Company                   AS [Index!5!company]
  from Securities2 S
  join Securities2 S2 on S.Ticker = S2.BenchmarkIndex
  join ResearchCoverage RC on S2.SecurityId = RC.SecurityId
  where S.TickerType = 'Index'
  and S2.TickerType = 'Stock'
  and RC.DropDate is null

  order by [Security!3!displayNo!hide] asc,[Security!3!company],[Security!3!isPrimary] desc,[Security!3!ticker]
  -- TO DO sort by Company, OrdNo
  for xml explicit
END

GO