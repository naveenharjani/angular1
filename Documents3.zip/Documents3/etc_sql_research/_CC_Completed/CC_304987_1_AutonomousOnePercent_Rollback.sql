-- AutonomousOnePercent_Rollback.sql
-- 03/25/2019

/*
alter spRptGetSecurityCheckboxDisclosures
alter spRptSetSecurityCheckboxDisclosures
*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spRptGetSecurityCheckboxDisclosures]
@DisclosureId int
AS
BEGIN
SET NOCOUNT ON

SELECT
  'SecurityId'         = S.SecurityId,
  'Ticker'             = S.Ticker,
  'ISIN'               = isnull(S.ISIN, ''),
  'Company'            = S.Company,
  'CheckboxDisclosure' = CASE SC.DisclosureId WHEN @DisclosureId THEN 'Yes' ELSE 'No' END
FROM ResearchCoverage V
JOIN Securities2 S ON S.SecurityID = V.SecurityID
LEFT JOIN SecurityCheckboxDisclosures SC ON SC.SecurityId = S.SecurityId AND SC.DisclosureId = @DisclosureId
WHERE DropDate IS NULL
ORDER BY 4, 2

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spRptSetSecurityCheckboxDisclosures]
@DisclosureId       int,
@SecurityInsertList varchar(max),
@SecurityDeleteList varchar(max),
@Source             varchar(10),
@EditUser           varchar(50)
AS
BEGIN
SET NOCOUNT ON
DECLARE @UserId VARCHAR(8)
  SELECT TOP 1 @UserId = CONVERT(VARCHAR(8),isnull(UserId,0)) FROM Users WHERE UserName like '%' + @EditUser + '%'
  IF EXISTS(SELECT * FROM UserRoles WHERE RoleId in (5,1) and UserId = @UserId)
  BEGIN TRY
    BEGIN TRANSACTION
    IF (@SecurityInsertList <> '' OR  @SecurityDeleteList <> '')
    BEGIN
      IF (@SecurityInsertList <> '')
      BEGIN
        CREATE TABLE #Tmp_Insert_Securities(SecurityId int)

        EXEC('INSERT INTO #Tmp_Insert_Securities(SecurityId)
        SELECT SecurityId FROM Securities2 WHERE SecurityId in (' + @SecurityInsertList + ')')

        INSERT INTO SecurityCheckboxDisclosures(SecurityId,DisclosureId,EditorID,EditDate)
        SELECT SecurityId,@DisclosureId,@UserId,getdate() FROM #Tmp_Insert_Securities

        DROP TABLE #Tmp_Insert_Securities
      END

      IF (@SecurityDeleteList <> '')
      BEGIN
        CREATE TABLE #Tmp_Delete_Securities(SecurityId int)

        EXEC('INSERT INTO #Tmp_Delete_Securities(SecurityId)
        SELECT SecurityId FROM Securities2 WHERE SecurityId in (' + @SecurityDeleteList + ')')

        DELETE FROM SecurityCheckboxDisclosures
        WHERE SecurityId in (SELECT SecurityId FROM #Tmp_Delete_Securities) AND DisclosureId = @DisclosureId

        DROP TABLE #Tmp_Delete_Securities
      END
      INSERT INTO SecurityCheckboxDisclosuresLog(DisclosureId,SecurityIdAddList,SecurityIdDropList,Source,EditorId,EditDate)
      SELECT @DisclosureId,@SecurityInsertList,@SecurityDeleteList,@Source,@UserId,getdate()
    END
    SELECT 1 Return_Value
    COMMIT
  END TRY
  BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK
    DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
    SELECT @ErrMsg = ERROR_MESSAGE(), @ErrSeverity = ERROR_SEVERITY()

    RAISERROR(@ErrMsg, @ErrSeverity, 1)
  END CATCH
  ELSE
    SELECT 0 Return_Value
SET NOCOUNT OFF
END

GO
alter proc dbo.spExportHoldings
as
begin

  select
    1             as  tag,
    null          as  parent,
    null          as [Holdings!1!],
    null          as [Holding!2!name],
    null          as [Holding!2!email],
    null          as [Holding!2!company],
    null          as [Holding!2!ticker],
    null          as [Holding!2!isin]

  union

  select
    2             as  tag,
    1             as  parent,
    null          as [Holdings!1!],
    Name          as [Holding!2!name],
    Email         as [Holding!2!email],
    Company       as [Holding!2!company],
    Ticker        as [Holding!2!ticker],
    ISIN          as [Holding!2!isin]
  from vHoldings H

  order by 4, 5
  for xml explicit

end
go