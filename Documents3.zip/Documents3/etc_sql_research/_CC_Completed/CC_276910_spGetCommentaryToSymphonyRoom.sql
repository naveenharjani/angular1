--03/23/2018
--CC_spGetCommentaryToSymphonyRoom.sql

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM sys.objects where name like '%spGetCommentaryToSymphonyRoom%')
DROP PROCEDURE dbo.spGetCommentaryToSymphonyRoom
GO

--- ====================================================================================
-- Author: Sandarsh M S
-- Create date: 02/13/2018
-- Description: Gets commentary details to post to Symphony chat room
-- ====================================================================================

create procedure [dbo].[spGetCommentaryToSymphonyRoom]
  @CommentaryId int
as
begin
select
  C.CommentaryId,
  A.First + A.Last Analyst,
  A.ExtEmail as Email,
  C.Subject
from Commentary C
left outer join Authors A on C.AnalystId = A.AuthorId
left outer join Users U on C.CreatorId = U.userid
where C.CommentaryId= @CommentaryId
end
go

GRANT EXECUTE ON dbo.spGetCommentaryToSymphonyRoom TO DE_IIS, PowerUsers
GO
