-- CC_Models Rollback.sql
-- 09/28/2017

/*

ModelActions
ModelStates
Models
vModels
vModelsLatest
spDeletePublication
spSaveModel
spDeleteModel
spGetModels
spGetModelChangeToolTip
spCheckForCorrections
spGetModelFilePath
spSearchData

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if not exists(select * from sys.columns where name = 'ModelDistribution' and object_id = object_id('ResearchCoverage'))
alter table dbo.ResearchCoverage
drop ModelDistribution
go

if not exists(select * from sys.columns where name = 'ActionId' and object_id = object_id('Models'))
begin
  drop table dbo.Models

  create table dbo.Models(
    ModelId    int         NOT NULL,
    SecurityId int         NOT NULL,
    AnalystId  int         NOT NULL,
    FileName   varchar(30) NOT NULL,
    PubNo      int             NULL,
    Status     varchar(30) NOT NULL,
    EditorId   int         NOT NULL,
    EditDate   datetime    NOT NULL
  )

end
go

if exists(select * from sys.objects where name = 'ModelStates')
begin
  drop table ModelStates
end
go

if exists(select * from sys.objects where name = 'ModelActions')
begin
  drop table ModelActions
end
go

alter proc dbo.spSaveModel (@ModelId int, @SecurityId int, @CoverageId int, @PubNo int, @FileName varchar(30), @EditorId int, @UploadType varchar(30))
as
begin

  begin transaction

  declare @PrimarySecurityId int
  declare @AnalystId int
  select @PrimarySecurityId = SecurityId from Securities2
  where CompanyId = (select CompanyId from Securities2 where SecurityId = @SecurityId) and
  IsPrimary = 'Y'

  select @AnalystId = AnalystId from ResearchCoverage
  where CoverageId = @CoverageId

  update Models
  set Status = 'Replaced'
  from Models M
  where SecurityId  = @PrimarySecurityId AND Status = 'Active'

  insert into Models(ModelId,AnalystId,SecurityId,PubNo,FileName,Status,Source,EditorId,EditDate)
  select  @ModelId,
      @AnalystId,
          @PrimarySecurityId,
          @PubNo,
          @FileName,
          'Active',
          @UploadType,
          @EditorId,
          getdate()

  commit transaction
end
go

alter procedure [dbo].[spDeleteModel]
  @ModelId        int,
  @EditorId       int
AS
begin
  update Models set Status = 'Deleted' where ModelId = @ModelId
end
go

create procedure [dbo].[spGetModels]
  @Type           int,  --0 - Latest, 1 - All
  @OrderBy        varchar(100),
  @OrderType      varchar(4),
  @SearchCriteria varchar(1000)
as
begin
  declare @sql VARCHAR(8000)

  if @OrderType = '' set @OrderType = 'desc'

  if @OrderBy = ''
  begin
    set @OrderBy = 'RegionId,Analyst,Ticker,SortId,ModelId desc'
  end
  else
  begin
    if @OrderBy = 'Analyst'      set @OrderBy = @OrderBy + ' ' + @OrderType + ', Ticker,SortId,ModelId desc'
    if @OrderBy = 'Ticker'       set @OrderBy = @OrderBy + ' ' + @OrderType + ', SortId,ModelId desc'
    if @OrderBy = 'Company'      set @OrderBy = @OrderBy + ' ' + @OrderType + ', SortId,ModelId desc'
    if @OrderBy = 'EditDate'     set @OrderBy = @OrderBy + ' ' + @OrderType + ', RegionId,Analyst,Ticker,SortId,ModelId desc'
    if @OrderBy = 'Report'       set @OrderBy = @OrderBy + ' ' + @OrderType + ', RegionId,Analyst,Ticker,SortId,ModelId desc'
    if @OrderBy = 'FileName'     set @OrderBy = @OrderBy + ' ' + @OrderType + ', RegionId,Analyst,Ticker,SortId,ModelId desc'
    if @OrderBy = 'PubNo'        set @OrderBy = @OrderBy + ' ' + @OrderType + ', RegionId,Analyst,Ticker,SortId,ModelId desc'
    if @OrderBy = 'Status'       set @OrderBy = @OrderBy + ' ' + @OrderType + ', RegionId,Analyst,Ticker,SortId,ModelId desc'
  end

  set @sql = 'set nocount on '  +
              'declare @Counter int select @Counter = Value from Counters where Name = ''ModelNo'' ' +
              'select AR.RegionId,' +
              'AR.Region,' +
              'A.Last + '', '' + A.First Analyst,' +
              'A.AuthorId,' +
              'S.Ticker,' +
              'S.SecurityId,' +
              'S.Company,' +
              'AM.ModelId,' +
              'RC.CoverageId,' +
              'CONVERT(Varchar,AM.ModelId) + ''.'' + REVERSE(SUBSTRING(REVERSE(AM.FileName),0,CHARINDEX(''.'',REVERSE(AM.FileName)))) ModelFileName,' +
              'AM.PubNo,' +
              'P.FileName ReportFileName,' +
              'P.Title,' +
              'AM.FileName,' +
              'AM.Status,' +
              'AM.EditDate, ' +
              '1 SortId '
  if @Type = 0
  set @sql =  @sql +
              'from ResearchCoverage RC left outer join Authors A on RC.AnalystId = A.AuthorId ' +
              'join Securities2 S on RC.SecurityId = S.SecurityId and S.IsPrimary = ''Y'' ' +
              'left outer join AuthorRegions AR on A.RegionId = AR.RegionId ' +
              'left outer join (select AM1.* from Models AM1 join (select AnalystId,SecurityId,max(ModelId) ModelId from Models group by AnalystId,SecurityId) v on AM1.ModelId = v.ModelId) AM on S.SecurityId = AM.SecurityId and A.AuthorId = AM.AnalystId '
 +
              'left outer join Publications P on AM.PubNo = P.PubNo ' +
              'where RC.Launchdate is not null and RC.DropDate is null ' +
              'and (AM.Status is null or AM.Status = ''Active'') '
  else
  set @sql =  @sql +
              'from ResearchCoverage RC left outer join Authors A on RC.AnalystId = A.AuthorId ' +
              'join Securities2 S on RC.SecurityId = S.SecurityId and S.IsPrimary = ''Y'' ' +
              'left outer join AuthorRegions AR on A.RegionId = AR.RegionId ' +
              'left outer join Models AM on S.SecurityId = AM.SecurityId and A.AuthorId = AM.AnalystId ' +
              'left outer join Publications P on AM.PubNo = P.PubNo ' +
              'where RC.Launchdate is not null and RC.DropDate is null '

  if @SearchCriteria <> '' set @sql = @sql + 'and ' + @SearchCriteria + ' '

  --Populate rows for dropped analysts with previously uploaded models
  set @sql =  @sql + ' Union All ' +
              'select AR.RegionId,' +
              'AR.Region,' +
              'A.Last + '', '' + A.First Analyst,' +
              'A.AuthorId,' +
              'S.Ticker,' +
              'S.SecurityId,' +
              'S.Company,' +
              'AM.ModelId,' +
              'RC.CoverageId,' +
              'CONVERT(Varchar,AM.ModelId) + ''.'' + REVERSE(SUBSTRING(REVERSE(AM.FileName),0,CHARINDEX(''.'',REVERSE(AM.FileName)))) ModelFileName,' +
              'AM.PubNo,' +
              'P.FileName ReportFileName,' +
              'P.Title,' +
              'AM.FileName,' +
        'AM.Status,' +
              'AM.EditDate, ' +
              '1 SortId '
  if @Type = 0
  set @sql =  @sql +
              'from ResearchCoverage RC join Authors A on RC.AnalystId = A.AuthorId ' +
              'join Securities2 S on RC.SecurityId = S.SecurityId and S.IsPrimary = ''Y'' ' +
              'join AuthorRegions AR on A.RegionId = AR.RegionId ' +
              'join (select AM1.* from Models AM1 join (select AnalystId,SecurityId,max(ModelId) ModelId from Models group by AnalystId,SecurityId) v on AM1.ModelId = v.ModelId) AM on S.SecurityId = AM.SecurityId and A.AuthorId = AM.AnalystId ' +
              'join Publications P on AM.PubNo = P.PubNo ' +
              'where RC.Launchdate is not null and RC.DropDate is not null ' +
              'and (AM.Status is null or AM.Status = ''Active'') '
  else
  set @sql =  @sql +
              'from ResearchCoverage RC join Authors A on RC.AnalystId = A.AuthorId ' +
              'join Securities2 S on RC.SecurityId = S.SecurityId and S.IsPrimary = ''Y'' ' +
              'join AuthorRegions AR on A.RegionId = AR.RegionId ' +
              'join Models AM on S.SecurityId = AM.SecurityId and A.AuthorId = AM.AnalystId ' +
              'join Publications P on AM.PubNo = P.PubNo ' +
              'where RC.Launchdate is not null and RC.DropDate is not null '

  if @SearchCriteria <> '' set @sql = @sql + 'and ' + @SearchCriteria + ' '

  --Populate a dummy empty row if the latest for analyst/ticker is in 'Deleted' status.
  set @sql =  @sql + ' Union All ' +
              'select AR.RegionId,' +
              'AR.Region,' +
             'A.Last + '', '' + A.First Analyst,' +
              'A.AuthorId,' +
              'S.Ticker,' +
              'S.SecurityId,' +
              'S.Company,' +
              'null ModelId,' +
              'null CoverageId,' +
              'null ModelFileName,' +
              'null PubNo,' +
              'null ReportFileName,' +
              'null Title,' +
              'null FileName,' +
              'null Status,' +
              'null Date,' +
              '0 SortId ' +
              'from ResearchCoverage RC join Authors A on RC.AnalystId = A.AuthorId ' +
              'join Securities2 S on RC.SecurityId = S.SecurityId and S.IsPrimary = ''Y'' ' +
              'join AuthorRegions AR on A.RegionId = AR.RegionId ' +
              'join (select AM1.* from Models AM1 join (select AnalystId,SecurityId,max(ModelId) ModelId from Models group by AnalystId,SecurityId) v on AM1.ModelId = v.ModelId where AM1.Status = ''Deleted'') AM on S.SecurityId = AM.SecurityId and A.AuthorId = AM.AnalystId ' +
              'where RC.Launchdate is not null and RC.DropDate is null '

  if @SearchCriteria <> '' set @sql = @sql + 'and ' + @SearchCriteria + ' '

  set @sql = @sql + ' order by ' + @OrderBy
  print(@sql)
  exec(@sql)
end
go

alter view dbo.vModels
as
  select
    ModelId,
    S2.SecurityId,
    S2.Ticker,
    S2.CompanyId,
    S2.OrdNo,
    Rating,
    RatingPrior,
    RatingAction,
    TargetPrice,
    TargetPricePrior,
    TargetPriceAction,
    EPSFY1,
    EPSFY1Prior,
    EPSFY1Action,
    EPSFY2,
    EPSFY2Prior,
    EPSFY2Action,
    AnalystId,
    M.PubNo,
    M.FileName,
    M.Status,
    M.Source,
    M.EditorId,
    M.EditDate
  from
    Models M
    join Securities2 S on M.SecurityId = S.SecurityId
    join Securities2 S2 on S.CompanyId = S2.CompanyId
    join PublicationFinancials PF on M.PubNo = PF.PubNo and S2.SecurityId = PF.SecurityId
go

alter view dbo.vModelsLatest
as
  select
    ModelId,
    S2.SecurityId,
    S2.Ticker,
    S2.CompanyId,
    S2.OrdNo,
    Rating,
    RatingPrior,
    RatingAction,
    TargetPrice,
    TargetPricePrior,
    TargetPriceAction,
    EPSFY1,
    EPSFY1Prior,
    EPSFY1Action,
    EPSFY2,
    EPSFY2Prior,
    EPSFY2Action,
    AnalystId,
    M.PubNo,
    M.FileName,
    M.Status,
    M.Source,
    M.EditorId,
    M.EditDate
  from
    Models M
    join Securities2 S on M.SecurityId = S.SecurityId
    join Securities2 S2 on S.CompanyId = S2.CompanyId
    join PublicationFinancials PF on M.PubNo = PF.PubNo and S2.SecurityId = PF.SecurityId
  where ModelId in (select Max(ModelId) from Models group by SecurityId)
go

CREATE procedure [dbo].[spDeletePublication]
  @PubNo         int,
  @Operation     char(1),
  @EditorId      int,
  @Numdeleted    int OUTPUT
AS
declare @AuditNo int

-- PREVENT PHANTOM deleteS (from STALE BROWSER) BY ONLY PROCESSING FIRST delete REQUEST
if NOT EXISTS(select * from Publications where PubNo = @PubNo)
  begin
    select @Numdeleted = 0 -- return OUTPUT PARAMETERS
    return
  end

-- return ROWset
select FileName from Documents where PubNo = @PubNo

delete from ProductGroupDocuments       where PubNo = @PubNo
delete from RelatedPublications         where PubNo = @PubNo
if @Operation = 'D' --delete from FinancialNumbers only if "delete" invoked from research dashboard and not report resubmits
begin
  delete from PublicationFinancialNumbers where PubNo = @PubNo
  delete from PublicationFinancials       where PubNo = @PubNo
  delete from FinancialNumbers            where PubNo = @PubNo
  --update model status to deleted if this publication promoted any models to live
  if EXISTS(select * from Models where PubNo = @PubNo)
  begin
  update Models set Status = 'Deleted' where PubNo = @PubNo AND Status = 'Active'
  end
end

-- RVdeletedDocuments replicated view uses the logs below for pdf cache control on BR.com
insert into AuditLog (Operation, EditorId, EditDate) VALUES (@Operation, @EditorId, GETDATE())
select @AuditNo = @@IDENTITY

insert into PublicationsLog (AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate)
select @AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate from Publications where PubNo = @PubNo

insert into DocumentsLog (AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig)
select @AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig from Documents where PubNo = @PubNo

insert into PropertiesLog (AuditNo, PubNo, PropNo, PropId, PropValue)
select @AuditNo, PubNo, PropNo, PropId, PropValue from Properties where PubNo = @PubNo

delete from Properties   where PubNo = @PubNo
delete from Documents    where PubNo = @PubNo
delete from Publications where PubNo = @PubNo

select @Numdeleted = @@ROWCOUNT -- return OUTPUT PARAMETERS
go

alter procedure [dbo].[spRollbackEstimates]
  @PubNo int,
  @SecurityId int,
  @EditorId int
as
begin try
  begin transaction
    --only one set of reports(with same source pubno) can be in correction mode at any time
    --reject if the prior set is not completed/cancelled
    if exists(select * from CorrectionQueue where status in ('Required','Optional') and SourcePubNo <> @PubNo)
    begin
        select -3 returnValue
        commit
        return
    end

    --if a report is already scheduled to be published for this ticker
    --prevent from doing a rollback
    declare @Qid int, @DXml xml, @hDoc int
    select top 1 @Qid = QueueId,@DXml = DocumentXml from PublicationQueue where ProcessStatus = 'Scheduled' order by QueueId

    while @@ROWCOUNT = 1
    begin
      exec sp_xml_preparedocument @hDoc output, @DXml

      if exists
      (select X.SecurityId,X.Ticker,X.IndicateChange
      from openxml (@hDoc, 'DocumentInfo/Securities/Security', 1)
      with (securityId      int         '@id',
            ticker          varchar(30) '@ticker',
            indicateChange  varchar(10) '@indicateChange'
            ) X
      where X.SecurityId = @SecurityId)
      begin
        select -2 returnValue
        commit
        return
      end

      exec sp_xml_removedocument @hDoc
      select top 1 @Qid = QueueId,@DXml = DocumentXml from PublicationQueue where ProcessStatus = 'Scheduled' AND QueueId > @Qid order by QueueId
    end
    --check to see if report exists in publicationxml table (new system)
    if exists(select PubNo from PublicationsXml where PubNo = @PubNo)
    begin

      declare @CurrentDate datetime
      declare @Ticker varchar(30)
      declare @UserName varchar(36)

      set @CurrentDate = GETDATE()
      select @Ticker = Ticker from Securities2 where SecurityId = @SecurityId
      select @UserName = UserName from Users where UserId = @EditorId

      --delete any pending drafts
      delete from FinancialNumbers where SecurityId = @SecurityId and IsDraft = 1

      --revert the latest live numbers to draft state
      delete PublicationFinancialNumbers
      from PublicationFinancialNumbers PFN
      join FinancialNumbers FN on PFN.FinancialNumberId = FN.FinancialNumberId
      where FN.SecurityId = @SecurityId
      and FN.PubNo = @PubNo
      and FN.IsDraft = 0

      update FinancialNumbers
      set IsDraft = 1, PubNo = null, Date = @currentdate
      where SecurityId = @SecurityId
      and PubNo = @PubNo
      and IsDraft = 0

      --update model status to deleted if this publication promoted any models to live
	  if exists(select * from Models where PubNo = @PubNo)
	  begin
		update Models set Status = 'Deleted' where PubNo = @PubNo and Status = 'Active'
      end

      --Determine the covering analyst for the rollback ticker
      declare @AnalystId int
      select @AnalystId = AnalystId from ResearchCoverage where SecurityId  = @SecurityId and LaunchDate is not null and DropDate is null

      --insert into CorrectionQueue table for source report
      insert into CorrectionQueue(PubNo,SecurityId,AnalystId,SourcePubNo,IsSource,CorrectionMode,Queued,QueuedBy,Status,EditorId,EditDate)
      select @PubNo,@SecurityId,@AnalystId,@PubNo,1,0,@CurrentDate,@EditorId,'Required',@EditorId,@CurrentDate

      --Retrieve dependent publication numbers
      select PubNo
      into #TmpDependentPublications
      from Properties PR
      join PropertyNames PN on PR.PropId = PN.PropId
      where PN.PropName = 'Ticker'
      and PR.PropValue = (select Ticker from Securities2 where SecurityId = @SecurityId)
      and PR.PubNo > @PubNo

      --insert into CorrectionQueue table for all dependent publications
      insert into CorrectionQueue(PubNo,SecurityId,AnalystId,SourcePubNo,IsSource,CorrectionMode,Queued,QueuedBy,Status,EditorId,EditDate)
      select PubNo,@SecurityId,@AnalystId,@PubNo,0,0,@CurrentDate,@EditorId,'Optional',@EditorId,@CurrentDate
      from #TmpDependentPublications


      exec spRestoreMarketData @PubNo, @SecurityId, @EditorId

    end
  select 0 returnValue
 commit
end try
begin catch
  if @@trancount > 0
    rollback
    --raise an error with the details of the exception
    declare @errmsg nvarchar(4000), @errseverity int
    select @errmsg = ERROR_MESSAGE(),
            @errseverity = ERROR_SEVERITY()
    select -1 returnValue
    Raiserror(@errmsg,@errseverity,1)
end catch
go

if exists(select * from sys.objects where name = 'spGetModelChangeToolTip' and type = 'P')
drop proc dbo.spGetModelChangeToolTip
go

if exists(select * from sys.objects where name = 'spCheckforCorrections' and type = 'P')
drop proc dbo.spCheckforCorrections
go

if exists(select * from sys.objects where name = 'spGetModelFilePath' and type = 'P')
drop proc dbo.spGetModelFilePath
go

-- =================================================================================================
-- Author:       Sandarsh M S
-- Revisions:    08/04/2016 - Created
-- 08/29/2017 - Added filter to remove unlaunched tickers which were not covered previously.
-- Description:  Get Typeahead data for a given @SearchText
-- =================================================================================================
alter procedure [dbo].[spSearchData]
  @Style int,
  @UserId int,
  @SearchText nvarchar(200),
  @SearchTextComp nvarchar(200)

as
begin
Set @SearchText = '%'+ @SearchText+'%'
Set @SearchTextComp = '%'+ @SearchText+'%'

declare @Analyst table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL,
  Header int NULL
 )

insert into @Analyst
select top 10
  Name as Label,
  Name as Ticker,
  'Analyst' as Groups,
  Row_Number() OVER (ORDER BY [Name]) +3  AS Header
from Authors where IsAnalyst = -1 and (First like @SearchText or Last like @SearchText or [Name] like @SearchText)
AND AuthorId in (select  Distinct AnalystID from ResearchCoverage) order by [Name]

declare @Ticker table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL
 )

insert into @Ticker
select distinct top (26 - (select Count(*) from @Analyst))
  Ticker + ' / ' + Company as Label,
  Ticker,
  'Research' as Groups
from Securities2 S
join ResearchCoverage RC on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null
and (Ticker like @SearchText or  Company like @SearchTextComp)
order by Ticker + ' / ' + Company

declare @Financials table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL
 )

insert into @Financials
select
  S.Ticker + ' / ' +  S.Company as Label,
  Ticker,
  'Financials' as Groups
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null AND RC.DropDate IS NULL and s.Ticker = (select top 1 Ticker from @Ticker)
and RC.AnalystId in (select AuthorId from Authors where IsAnalyst = -1 AND IsActive = -1)
order by S.Ticker + ' / ' + S.Company

--DECLARE @Charts TABLE
--(
--  Label  varchar(100) NULL,
--  Ticker varchar(50) NULL,
--  Groups varchar(50) NULL
-- )

-- INSERT INTO @Charts
-- Select
--  S.Ticker + ' / ' +  S.Company as Label,Ticker,'Charts' as Groups
--FROM ResearchCoverage RC
--JOIN Securities2 S on S.SecurityId = RC.SecurityId
--WHERE  S.Ticker = (Select top 1 Ticker from @Ticker) AND RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
--order by S.Ticker + ' / ' + S.Company

select *, ROW_NUMBER() over(partition by Ticker
order by Groups desc) AS Header
from (
select * from @Ticker
union
select * from @Financials
--union
--select * from @Charts
) as uni
union All
select * from @Analyst
End
go

/*
select * from Models order by ModelId desc
select Max(ModelId) from Models group by SecurityId
select * from researchcoverage where launchdate is not null and dropdate is null and securityid is not null and DistributionEligible = 1
spGetModels 1,'EditDate','desc','ticker=''2883.hk'''
spGetModels 1,'EditDate','desc','authorid=506'
select * from vModelsLatest  where ticker = '2883.hk'
select * from authors where last like '%anderson%'

select * from vModelsLatest
where filesize is not null
spGetModels 0,'EditDate','desc','authorid=431'
spGetModels 0,'EditDate','desc','ticker=''2883.hk'''

*/

sp_helptext spSearchData