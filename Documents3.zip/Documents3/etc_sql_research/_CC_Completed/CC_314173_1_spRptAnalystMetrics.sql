--CC_spRptAnalystMetrics.sql
--07/18/2019

/*
alter spRptAnalystMetrics
*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

--------------------------------------------------------------------------
-- Author: Naveen Harjani
-- Create date: 6/1/2009
-- Description: Retrieves the analyst metrics data.
--              Filter Calls with publication between start and end date within a region, by analyst
--              Signature: [spRptAnalystMetrics](dtStartDate, dtEndDate, vRegionCode)
--              @vRegionCode is optional parameter, defaults to ALL
--------------------------------------------------------------------------
--Revision Dt  | Comments
--------------------------------------------------------------------------
--7/1/2010       Pull in Proactivity info call from Properties table
--7/2/2010       If Author is not a Senior Analyst, then account only first author calls
--               If Author is a Senior Analyst, then account all documents/reads
--3/29/2011      Report NumFlashes for the "External Flash" research instead of "Flash" research
--7/12/2011      For a Senior analyst where he/she is the primary author, get the Count of calls,
--               Avg Calls per month and count of Proactive calls, Count of joint calls for more than 2 senior analysts
--12/4/2014      Add new fields: TotalVideos and TotalJointVideos for a Sr. Analyst
--------------------------------------------------------------------------
ALTER PROCEDURE [dbo].[spRptAnalystMetrics]
  @vStartDate       VARCHAR(12),
  @vEndDate         VARCHAR(12),
  @vRegionCode      VARCHAR(12) = 'ALL'
AS
BEGIN
  SET NOCOUNT ON

  ----------------------------------------------------------------------------------------------------
  --Get the Average Days in a Month
  ----------------------------------------------------------------------------------------------------
  DECLARE @vAvgDaysInaMonth  VARCHAR(12)

  --Get the Avg Days in a Month (365/12)
  SET @vAvgDaysInaMonth = CONVERT( DECIMAL(10,2),
                                   CONVERT( DECIMAL(10,4), (365))/CONVERT( DECIMAL(10,4), (12))
                                  )
  ----------------------------------------------------------------------------------------------------

  ----------------------------------------------------------------------------------------------------
  --Get the Periodicals title list - filter by Title string
  ----------------------------------------------------------------------------------------------------
  DECLARE @Periodicals TABLE
    (
      DocId           INT,
      DocTypeId       INT,
      DocTitle        VARCHAR(250),
      PeriodicalTitle VARCHAR(250)
    )

  INSERT @Periodicals  --(DocId, DocTypeId, DocTitle, PeriodicalTitle)
    SELECT RVD.DocId, RVD.DocTypeId, RVD.Title, P.TitleFilter
    FROM RVDocuments RVD
    LEFT OUTER JOIN Periodicals P ON P.PublicationTypeId = RVD.DocTypeId
                                 AND P.Active = 'T'   --Get only Active Periodicals
    WHERE RVD.Title LIKE P.TitleFilter
      AND P.TitleFilter IS NOT NULL
    ORDER By DoctypeId
  ----------------------------------------------------------------------------------------------------

  ----------------------------------------------------------------------------------------------------
  --Get the Regions list - filter by region code
  ----------------------------------------------------------------------------------------------------
  DECLARE @Regions TABLE
    (
      RegionId           INT,
      Region             VARCHAR(250)
    )

  If @vRegionCode = 'ALL'
    BEGIN
      INSERT @Regions (RegionId, Region)
      SELECT RegionId, Region
      FROM AuthorRegions
    END
  ELSE
    BEGIN
      INSERT @Regions (RegionId, Region)
      SELECT RegionId, Region
      FROM AuthorRegions
      WHERE Region = @vRegionCode
    END
  ----------------------------------------------------------------------------------------------------

  ----------------------------------------------------------------------------------------------------
  -- Get the Analyst Calls info, for all coverage analysts, active or not.
  ----------------------------------------------------------------------------------------------------
  DECLARE @Analysts TABLE
    (
     --Analysts info
     AnalystId                INT,
     FullName                 VARCHAR(60),
     LastName                 VARCHAR(50),
     FirstName                VARCHAR(50),
     Phone                    VARCHAR(50),
     Email                    VARCHAR(50),
     --Analyst Launch date
     TotalCoverageCount       INT,
     ActiveCoverageCount      INT,
     FirstLaunchDate          DATETIME,
     LastDropDate             DATETIME,
     AnalystRptStartDate      DATETIME,
     AnalystRptEndDate        DATETIME,
     AnalystRptMonths         NUMERIC(5,2),
     --Title/Region
     WindowsID                VARCHAR(50),
     AuthorTitle              VARCHAR(60),
     AuthorRegion             VARCHAR(60),
     UserID                   INT
     )

  --Get the Filtered Analyst list as per the parameters specified
  INSERT @Analysts
      SELECT distinct
             RVDA.AnalystId, RVDA.Name, RVDA.Last, RVDA.First, RVDA.Phone, RVDA.Email,
             --Total Coverage count ever for an analyst
             'TotalCoverageCount'  = (Select COUNT(*)
                                      From RVResearchCoverage
                                      Where AnalystId = RVDA.AnalystId),
             --Total Active Coverage count today for an analyst
             'ActiveCoverageCount' = (Select SUM(CASE WHEN dropdate is null THEN 1 ELSE 0 END)
                                      From RVResearchCoverage
                                      Where AnalystId = RVDA.AnalystId),
             --Analyst Launch Date
             'FirstLaunchDate'     = (Select MIN(LaunchDate)
                                      From RVResearchCoverage
                                      Where AnalystId = RVDA.AnalystId),
             --Last Coverage dropdate for an analyst
             'LastDropDate'        = (Select MAX(dropdate)
                                      From RVResearchCoverage
                                      Where AnalystId = RVDA.AnalystId),
             NULL AS AnalystRptStartDate,
             NULL AS AnalystRptEndDate,
             NULL AS AnalystRptMonths,
             WindowsId =
              (CASE
                  WHEN A.UserID IS NULL THEN ''
                  ELSE (Select ISNULL(UserName,'') From Users Where UserId = A.UserId)
               END),
             CASE WHEN A.IsAnalyst = -1 AND A.MetricsEligible = 'T' AND LTRIM(RTRIM(AT.Title)) NOT IN ('', 'Analyst')
                  THEN 'Senior Analyst'
                  ELSE AT.Title
             END AS Title,
             AR.Region, A.UserID
      FROM RVDocAnalysts RVDA
      INNER JOIN Authors A           ON A.AuthorID  = RVDA.AnalystID
      INNER JOIN AuthorTitles AT     ON AT.TitleID  = A.TitleID
      INNER JOIN AuthorRegions AR    ON AR.RegionID = A.RegionID

      --Active Coverage - Consider Analysts with Active Ticker Coverage as of today from the ResearchCoverage Table
      --This line was commented as we need to get the metrics info retroactively for previous analyst coverages as per the report date range.
      --AND RVDA.AnalystId IN (SELECT DISTINCT ANALYSTID FROM RVResearchCoverage RVRC WHERE DROPDATE IS NULL)

       --Filter by MetricsEligible flag
       AND A.MetricsEligible = 'T'
       --Filter by Analysts only
       AND A.IsAnalyst = -1

/*
       --Selected analyst is primary author[Primary analyst indicated by ordinal value]
       --All authors on Call, i.e. primary and non-primary authors
       --AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM RVDocAnalysts WHERE DocId = RVDA.DocId)
*/

  ----------------------------------------------------------------------------------------------------
  --Update the Analyst Rpt Actual Start Date for the Analyst.
  --Check Conditions for some new launched analysts and as per the Report start/end date ranges.
  --The conditions below need to be checked in the specified order.
  ----------------------------------------------------------------------------------------------------
  UPDATE  @Analysts
  SET
     AnalystRptStartDate =
        (CASE
            --If the analyst launched between the report start/end dates, then select the First Launch date.
            WHEN FirstLaunchDate BETWEEN  @vStartDate AND @vEndDate
                  THEN CONVERT(varchar, FirstLaunchDate, 101)

            --Else select the Report Start Date
            ELSE
                  CONVERT(varchar, @vStartDate, 101)
         END)
  ----------------------------------------------------------------------------------------------------

  ----------------------------------------------------------------------------------------------------
  --Update the Analyst Rpt Actual End Date for the Analyst, for analysts with no active coverage today.
  --The conditions below need to be checked in the specified order.
  ----------------------------------------------------------------------------------------------------
  UPDATE  @Analysts
  SET
     AnalystRptEndDate =
        (CASE
            --No current ticker coverage and last drop occurred during report period
            WHEN ActiveCoverageCount = 0 AND LastDropDate BETWEEN @vStartDate AND @vEndDate
                  THEN CONVERT(varchar, LastDropDate, 101)

            --No current ticker coverage and last drop occurred prior to report report period
            WHEN ActiveCoverageCount = 0
                  THEN CONVERT(varchar, @vStartDate, 101)

            --Ticker coverage started after report period
            WHEN FirstLaunchDate > @vEndDate
                  THEN CONVERT(varchar, @vStartDate, 101)

            --Else select the Report Start Date
            ELSE
                  CONVERT(varchar, @vEndDate, 101)
         END)
  ----------------------------------------------------------------------------------------------------

  ----------------------------------------------------------------------------------------------------
  --Update the Number of Months in use compared to the date range, as per the Analyst.
  ----------------------------------------------------------------------------------------------------
  UPDATE  @Analysts
  SET
      --Get the Analyst Report Months between the Analyst Report Launch Date from above and the end date, as used to calculate Avg call count
     AnalystRptMonths =
         CONVERT( DECIMAL(10,2),
                      CONVERT( DECIMAL(10,4), datediff(day, AnalystRptStartDate, AnalystRptEndDate))/ @vAvgDaysInaMonth
                 )

  --SELECT * FROM @Analysts
  ----------------------------------------------------------------------------------------------------

  ----------------------------------------------------------------------------------------------------
  -- Get the Document Call info.
  ----------------------------------------------------------------------------------------------------
  DECLARE @Documents TABLE
    (
     --Documents info
     DocId                    INT,
     PubDate                  DATETIME,
     Title                    VARCHAR(255),
     --Types info
     DocTypeId                INT,
     DocType                  VARCHAR(50),
     Proactiveflag            CHAR(1),
     Periodicalflag           CHAR(1),
     AnalystId                INT,
     AuthorTitle              VARCHAR(50),
   AuthorOrdinalId          INT,
     AuthorOrdinalRowNum      INT
     )

  --Get the Filtered Analyst list as per the parameters specified
  INSERT @Documents
      SELECT distinct
             RVD.DocId, RVD.date AS PubDate, RVD.title,
             RVD.DocTypeId, RVT.DocType,
             --ProactiveFlag = ISNULL(P.Proactivity, 'F'),
             ProactiveFlag = ISNULL(Pp.PropValue, 'F'),
             PeriodicalFlag =
                   CASE ISNULL(STR(PR.DocId), 'F')
                      WHEN 'F' THEN 'F'
                      ELSE 'T'
                   END,
             RVDA.AnalystId, TA.AuthorTitle, RVDA.OrdinalId,
             AuthorOrdinalRowNum =
          ROW_NUMBER() OVER(PARTITION BY RVD.DocId ORDER BY RVD.DocId, RVDA.OrdinalId asc)
      FROM RVDocuments RVD
      INNER JOIN RVTypes RVT           ON RVT.DocTypeId = RVD.DocTypeId
      INNER JOIN RVDocAnalysts RVDA    ON RVDA.DocID = RVD.DocID
      INNER JOIN @Analysts TA          ON TA.AnalystId = RVDA.AnalystId

      --Active Coverage - Consider Analysts with Active Ticker Coverage as of today from the ResearchCoverage Table
      --This line was commented as we need to get the metrics info retroactively for previous analyst coverages as per the report date range.
      --AND RVDA.AnalystId IN (SELECT DISTINCT ANALYSTID FROM RVResearchCoverage RVRC WHERE Dropdate IS NULL)

--/*
      --Selected analyst is primary author[Primary analyst indicated by ordinal value]
      --All authors on Call, i.e. primary and non-primary authors
      --AND (TA.AuthorTitle <> 'Senior Analyst' AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM RVDocAnalysts WHERE DocId = RVDA.DocId) )
--*/

      AND --If Author is not a Senior Analyst, then account only first author calls
         (TA.AuthorTitle <> 'Senior Analyst' AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM RVDocAnalysts WHERE DocId = RVDA.DocId)
          OR
          --If Author is a Senior Analyst, then account all documents/reads
          TA.AuthorTitle = 'Senior Analyst' )

      --LEFT OUTER JOIN Proactivity P ON P.PubNo = RVD.DocId
      LEFT OUTER JOIN Properties Pp ON Pp.PropId = 30 AND  Pp.PubNo = RVD.DocId    --Use Properties for Proactivity
      LEFT OUTER JOIN @Periodicals PR ON PR.DocId = RVD.DocId

      WHERE RVD.date BETWEEN @vStartDate AND @vEndDate     -- All Pub Dates for the specified date range

--   SELECT * FROM @Documents
--   Order by DocId desc, AuthorOrdinalId asc
  ----------------------------------------------------------------------------------------------------

  ----------------------------------------------------------------------------------------------------
  --Get the Documents with Joint Calls
  --Define joint calls as those where there are two or more senior analysts, i.e. do not include calls with Ali and Steve P, or Doug and Finbar as joint calls.
  ----------------------------------------------------------------------------------------------------
  DECLARE @DocumentJointCalls TABLE
    (DocId                    INT,
     SrAuthorCount            INT,
     JointCallFlag         CHAR(1))

  INSERT @DocumentJointCalls
   SELECT DocId, ISNULL(Count(*),0),
    'JointCallFlag' = CASE WHEN ISNULL(Count(*),0) = 0 THEN 'N' ELSE 'Y' END
   FROM @Documents
   WHERE AuthorTitle = 'Senior Analyst'
   GROUP BY DocId
   HAVING Count(*) > 1
   ORDER BY DocId desc

--   SELECT * FROM @DocumentJointCalls
--   Order by DocId desc
  ----------------------------------------------------------------------------------------------------

  ----------------------------------------------------------------------------------------------------
  PRINT '----------------------------------------------------------------------------------------'
  PRINT 'REPORT 1: Display the Analyst Visibility Quarterly Report [ALL ACTIVE COVERAGE ANALYSTS]'
  PRINT 'PARAMETERS: Since: ' +  @vStartDate + ' Until: ' + @vEndDate + ' Region: ' + @vRegionCode
  PRINT '----------------------------------------------------------------------------------------'
  PRINT ' '
  PRINT ' '

  --All Active Coverage Analysts
  SELECT distinct
         'LastName' = V1.LastName,
         'FirstName' = V1.FirstName,

         'NumReports' = V2.TotalResearch,
         'NumPeriodicals' = V2.TotalPeriodicalCalls,
         'NumNetReports' = V2.TotalResearch - V2.TotalPeriodicalCalls,

         'NumCalls' = V2.TotalResearchCalls,
         'NumNetCalls' = TotalNetResearchCalls,
         'NumNetCalls2' = TotalNetResearchCalls2,
     'NumJointCalls' = TotalNetJointResearchCalls,

         'NumProactiveCalls' = V2.TotalProactiveCalls,
         'NumProactiveCalls2' = V2.TotalProactiveCalls2,

         'AvgCallsMonth' =
            (CASE
              WHEN V1.AnalystRptMonths = 0 THEN 0
              ELSE
                   CONVERT( DECIMAL(10,4),
                            CONVERT( DECIMAL(10,4), V2.TotalResearchCalls)/CONVERT( DECIMAL(10,4), V1.AnalystRptMonths)
                          )
            END),

         'AvgNetCallsMonth' =
            (CASE
              WHEN V1.AnalystRptMonths = 0 THEN 0
              ELSE
                   CONVERT( DECIMAL(10,4),
                            CONVERT( DECIMAL(10,4), V2.TotalNetResearchCalls)/CONVERT( DECIMAL(10,4), V1.AnalystRptMonths)
                          )
            END),

         'AvgNetCallsMonth2' =
            (CASE
              WHEN V1.AnalystRptMonths = 0 THEN 0
              ELSE
                   CONVERT( DECIMAL(10,4),
                            CONVERT( DECIMAL(10,4), V2.TotalNetResearchCalls2)/CONVERT( DECIMAL(10,4), V1.AnalystRptMonths)
                          )
            END),

         'NumFlashes' = V2.TotalFlashes,
         'NumBlackbooks' = V2.TotalBlackbooks,
         'NumNetBlackbooks' = V2.TotalNetBlackbooks,

         'NumWhiteBooks' = V2.TotalWhitebooks,
         'NumNetWhiteBooks' = V2.TotalNetWhitebooks,

         'LaunchDate' = CONVERT(varchar, V1.FirstLaunchDate,101),

          --Get the Number of Months that have elapsed since the Launch date to end date
         'LaunchMonths' =
                         CONVERT( DECIMAL(10,2),
                                  CONVERT( DECIMAL(10,4), datediff(day, V1.FirstLaunchDate,@vEndDate))/ @vAvgDaysInaMonth
                                ),

         'RptStartDate'   = CONVERT(VARCHAR, V1.AnalystRptStartDate,101),
         'RptEndDate'     = CONVERT(VARCHAR, V1.AnalystRptEndDate,101),
         'RptMonths'      = V1.AnalystRptMonths,

         'SeqNo' = ROW_NUMBER() OVER(ORDER BY V1.LastName),
         'AnalystId' = V1.AnalystId,
         'FullName' = V1.FullName,
         'Email' = V1.Email,
         'Telephone' = V1.Phone,
         'AnalystTitle' = V1.AuthorTitle,
         'AnalystRegion' = V1.AuthorRegion,
         'WindowsID' = V1.WindowsID,
         V2.TotalVideos,
         V2.TotalJointVideos

  FROM   @Analysts V1
  INNER JOIN
         (
            SELECT   'AnalystId' = D.AnalystId,
                     --Calls count
                    COUNT(*)                                              AS [TotalResearch],
                    SUM(CASE WHEN D.ProactiveFlag = 'T'
                             THEN 1 ELSE 0 END)                           AS [TotalProactiveCalls],
                    SUM(CASE WHEN D.ProactiveFlag = 'T'   And D.AuthorTitle = 'Senior Analyst' And D.AuthorOrdinalRowNum = 1
                             THEN 1 ELSE 0 END)                           AS [TotalProactiveCalls2],
                    SUM(CASE WHEN D.PeriodicalFlag = 'T'
                             THEN 1 ELSE 0 END)                           AS [TotalPeriodicalCalls],
                    SUM(CASE WHEN D.DocTypeId = 1
                             THEN 1 ELSE 0 END)                           AS [TotalResearchCalls],
                    SUM(CASE WHEN D.DocTypeId = 1 AND D.PeriodicalFlag = 'F'
                             THEN 1 ELSE 0 END)                           AS [TotalNetResearchCalls],
                    SUM(CASE WHEN D.DocTypeId = 1 AND D.PeriodicalFlag = 'F'  And D.AuthorTitle = 'Senior Analyst' And D.AuthorOrdinalRowNum = 1
                             THEN 1 ELSE 0 END)                           AS [TotalNetResearchCalls2],
                    SUM(CASE WHEN D.DocTypeId = 1 AND D.PeriodicalFlag = 'F'  And ISNULL(D2.JointCallFlag,'N') = 'Y'
                             THEN 1 ELSE 0 END)                           AS [TotalNetJointResearchCalls],
                    SUM(CASE WHEN D.DocTypeId = 3
                             THEN 1 ELSE 0 END)                           AS [TotalBlackbooks],
                    SUM(CASE WHEN D.DocTypeId = 3 AND D.PeriodicalFlag = 'F'
                             THEN 1 ELSE 0 END)                           AS [TotalNetBlackbooks],
                    SUM(CASE WHEN D.DocTypeId = 8
                             THEN 1 ELSE 0 END)                           AS [TotalFlashes],
                    SUM(CASE WHEN D.DocTypeId = 6
                             THEN 1 ELSE 0 END)                           AS [TotalWhitebooks],
                    SUM(CASE WHEN D.DocTypeId = 6 AND D.PeriodicalFlag = 'F'
                             THEN 1 ELSE 0 END)                           AS [TotalNetWhitebooks],
                    SUM(CASE WHEN D.DocTypeId = 10 And D.AuthorTitle = 'Senior Analyst' And D.AuthorOrdinalRowNum = 1
                             THEN 1 ELSE 0 END)                           AS [TotalVideos],
                    SUM(CASE WHEN D.DocTypeId = 10 And D.AuthorTitle = 'Senior Analyst' And ISNULL(D2.JointCallFlag,'N') = 'Y'
                             THEN 1 ELSE 0 END)                           AS [TotalJointVideos]
            FROM    @Documents D
            LEFT OUTER JOIN @DocumentJointCalls D2 ON D.DocId = D2.DocId
            GROUP BY D.AnalystId
          ) V2 ON V1.AnalystId = V2.AnalystId
    WHERE V1.AuthorRegion IN (Select Region From @Regions)
  Order By V1.LastName
  ----------------------------------------------------------------------------------------------------

  RETURN 0
END



GO

/*
EXEC [spRptAnalystMetrics] '01/01/2019', '06/30/2019', 'ALL'
GO

select * from Authors where name like '%Carlsson%'
*/