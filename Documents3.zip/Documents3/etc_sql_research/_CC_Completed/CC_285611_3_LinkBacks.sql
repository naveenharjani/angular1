-- CC_LinkBacks.sql
-- 05/22/2018

/*

alter DistributionQueue    - LinkBack column added to save the link back state of file transfer
alter spGetScheduledItems  - Get scheduled items from DistributionQueue & ModelDistributionQueue
alter spGetAdapterRixml    - Altered to add entitlement context & pagecount
create spGetHighlightsXml  - New proc to retrieve highlights xml which is added to rixml metadata

Save 1 page pdf file to ScbFolder from spGetFtpLogin

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if not exists(select * from sys.columns where object_id = object_id('DistributionQueue') and name = 'LinkBack')
begin
  alter table DistributionQueue
  add LinkBack int
end
go

-- ====================================================================================
 -- Author: Krishna Josyula
 -- Description: Get Scheduled Items
 -- Modified On : 1/16/2018
 -- Modified by : Sandarsh Suresh
 -- ====================================================================================
ALTER PROCEDURE dbo.spGetScheduledItems
AS

  -- Research distribution queue
  SELECT DQ.DistributionId, DQ.SiteId, DQ.PubNo, DQ.Operation, DQ.Received, DQ.Scheduled, ISNULL(CONVERT(VARCHAR, RetryCount), '') RetryCount, DS.LinkBack, DS.LinkSourceId, DS.SiteType
  FROM DistributionQueue DQ (NOLOCK)
  INNER JOIN DistributionSites DS ON DQ.SiteId = DS.SiteId
  WHERE (DQ.Scheduled IS NOT NULL) AND (DQ.Cancelled IS NULL AND DQ.Transferred IS NULL)

  UNION ALL

  -- Model distribution queue
  SELECT DQ.DistributionId, DQ.SiteId, DQ.ModelId, DQ.Operation, DQ.Queued, DQ.Scheduled, ISNULL(CONVERT(VARCHAR, RetryCount), '') RetryCount, DS.LinkBack, DS.LinkSourceId, DS.SiteType
  FROM ModelDistributionQueue DQ (NOLOCK)
  INNER JOIN DistributionSites DS ON DQ.SiteId = DS.SiteId
  WHERE (DQ.Scheduled IS NOT NULL) AND (DQ.Cancelled IS NULL AND DQ.Completed IS NULL)

  ORDER BY Scheduled ASC, DistributionId DESC
GO

if exists(select * from sys.objects where object_id = object_id('spGetAdapterRixml') and type = 'p')
drop proc dbo.spGetAdapterRixml
go

-- ====================================================================================
 -- Author: Krishna Josyula
 -- Description: Get Scheduled Items
 -- Modified On : 1/28/2018
 -- Modified by : Sandarsh Suresh
-- ====================================================================================
CREATE PROCEDURE [dbo].[spGetAdapterRixml]
  @PubNo int,
  @SiteId int
AS
DECLARE @Codeset varchar(10)
DECLARE @PublicationTypeId int

SELECT @Codeset = Codeset FROM DistributionSites WHERE SiteId = @SiteId

IF NOT EXISTS (SELECT * FROM Publications WHERE PubNo = @PubNo)
  BEGIN
    SELECT @PublicationTypeId = PublicationTypeId FROM PublicationsLog P JOIN PublicationTypes PT ON P.Type = PT.PublicationType WHERE P.Pubno = @Pubno

    SET NOCOUNT ON
    SELECT
      1                          AS tag,
      null                       AS parent,
      P.pubNo                    AS [Publication!1!pubNo],
      CONVERT(varchar, P.Date, 101) AS [Publication!1!date],
      P.Type                     AS [Publication!1!type],
      PT.PublicationTypeId       AS [Publication!1!typeId],
      P.Title                    AS [Publication!1!title],
      P.FileName                 AS [Publication!1!fileName],
      D.FileName                 AS [Publication!1!fileNameDoc],
      P.Approver                 AS [Publication!1!approver],
      CONVERT(varchar, P.ApprovedDate,101)  + ' ' + CONVERT(varchar, P.ApprovedDate,108)  AS [Publication!1!approvedDate],
      CONVERT(varchar, P.PublishedDate,101) + ' ' + CONVERT(varchar, P.PublishedDate,108) AS [Publication!1!publishedDate],
      P.Version                  AS [Publication!1!version],
      ISNULL(P.Instructions,0)   AS [Publication!1!instructions],
      null                       AS [Properties!2!!element],
      null                       AS [Property!3!name],
      null                       AS [Property!3!value],
      null                       AS [Property!3!!hide],
      null                       AS [Property!3!!hide]
    FROM PublicationsLog P WITH(NOLOCK) JOIN PublicationTypes PT WITH(NOLOCK) ON PT.PublicationType = P.Type
    JOIN DocumentsLog D WITH(NOLOCK) ON P.Pubno = D.Pubno AND (D.DocType = 'DOC' OR D.DocType = 'DOCX')
    WHERE P.PubNo = @PubNo

    UNION ALL

    SELECT
      2                          AS tag,
      null                       AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Organization',
      isnull(RixmlOrgIdType,'') + ';' + isnull(RixmlOrgId,''),
      -5,
      -5
    FROM DistributionSites
    WHERE SiteId = @SiteId

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Entitlement',
      isnull(RixmlEntitlement,''),
     -3,
     -3
    FROM DistributionEntitlements
    WHERE SiteId = @SiteId
    AND ProductGroupId IS NULL

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Entitlement',
      isnull(RixmlEntitlement,''),
     -3,
     -3
    FROM DistributionEntitlements
    WHERE SiteId = @SiteId
    AND ProductGroupId in (SELECT ProductGroupId FROM ProductGroupDocuments WHERE PubNo = @Pubno)

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
null,
      null,
      null,
      null,
      null,
      null,
      'Keyword',
      isnull(RixmlKeyword,''),
      -2,
      -2
    FROM DistributionSubscriptions
    WHERE SiteId = @SiteId
    AND PublicationTypeId = @PublicationTypeId
    AND Active = -1

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'WatermarkText',
      isnull(WaterMarkText,''),
      -1,
      -1
    FROM DistributionSites
    WHERE SiteId = @SiteId

   UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'EntitlementContext',
      isnull([Site],''),
      -4,
      -4
    FROM DistributionSites
    WHERE SiteId = @SiteId

   UNION ALL

   SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'PageCount',
      isnull(CAST([PageCount] as varchar(10)),''),
      -1,
      -1
     FROM Publications
    WHERE PubNo=@PubNo


    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'FileVersion',
      ISNULL(CONVERT(varchar,MAX(ISNULL(DF.FileVersion,0))),'0'),
      0,
      0
    FROM   DistributionFiles DF WITH (NOLOCK)
    JOIN   DistributionQueue DQ WITH (NOLOCK) ON DQ.DistributionId = DF.DistributionId
    WHERE  DQ.PubNo = @PubNo AND DQ.SiteId = @SiteId
    AND SUBSTRING(DF.FileName, charindex('.',DF.FileName) + 1, len(DF.FileName) - charindex('.',DF.FileName)  ) = 'xml'

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      CASE PN.PropName
        WHEN 'Keywords' THEN 'ResearchKeywords'
        ELSE PN.PropName
      END,
      CASE PN.PropName
        WHEN 'Industry' THEN ISNULL(CONVERT(varchar,I.IndustryId),'') + ';' + I.IndustryName
        WHEN 'Author'   THEN ISNULL(CONVERT(varchar,A.AuthorId),'') + ';' + A.Name + ';' + A.First + ';' + A.Last + ';' + A.Phone + ';' + A.ExtEmail  + ';' + Convert(Varchar,A.IsAnalyst)
        WHEN 'Ticker'   THEN ISNULL(CONVERT(varchar,S2.SecurityId),'') + ';' + S2.RIC + ';RIC;' + S2.Company + ';' + S2.CountryCode + ';' + C.Country + ';' + S2.Ticker
        WHEN 'Keywords' THEN ISNULL(PV.PropValue, '')
        ELSE ''
      END,
      PV.PropNo,
      PS.SeqNo
    FROM PropertySets PS     WITH(NOLOCK)
    LEFT JOIN PropertiesLog PV  WITH(NOLOCK) ON PV.PropId = PS.PropId AND PV.PubNo = @PubNo
    LEFT JOIN Industries I   WITH(NOLOCK) ON I.IndustryName = PV.PropValue
    LEFT JOIN Authors A      WITH(NOLOCK) ON A.Name = PV.PropValue
    LEFT JOIN Securities2 S2 WITH(NOLOCK) ON S2.Ticker = PV.PropValue
    LEFT JOIN Countries C    WITH(NOLOCK) ON S2.CountryCode = C.CountryCode
    JOIN PropertyNames PN    WITH(NOLOCK) ON PN.PropId = PS.PropId
    WHERE PS.PublicationTypeId IN (SELECT PT.PublicationTypeId FROM PublicationsLog P WITH(NOLOCK) JOIN PublicationTypes PT WITH(NOLOCK) ON PT.PublicationType = P.Type WHERE P.PubNo = @PubNo)
    AND PN.PropId IN (5, 9, 11,13)  AND PV.PropValue NOT IN (SELECT TICKER FROM Securities2 WHERE TickerType = 'Index')

    ORDER BY 1, 19, 18, 17
    FOR XML Explicit

END

IF EXISTS (SELECT * FROM Publications WHERE PubNo = @PubNo)
  BEGIN
SET NOCOUNT ON

    SELECT @PublicationTypeId = PublicationTypeId FROM Publications P JOIN PublicationTypes PT ON P.Type = PT.PublicationType WHERE P.Pubno = @Pubno

    SELECT
      1                          AS tag,
      null                       AS parent,
      P.pubNo                    AS [Publication!1!pubNo],
      CONVERT(varchar, P.Date, 101) AS [Publication!1!date],
      P.Type                     AS [Publication!1!type],
      PT.PublicationTypeId       AS [Publication!1!typeId],
      P.Title         AS [Publication!1!title],
      P.FileName                 AS [Publication!1!fileName],
      D.FileName                 AS [Publication!1!fileNameDoc],
      P.Approver                 AS [Publication!1!approver],
      CONVERT(varchar, P.ApprovedDate,101)  + ' ' + CONVERT(varchar, P.ApprovedDate,108)  AS [Publication!1!approvedDate],
      CONVERT(varchar, P.PublishedDate,101) + ' ' + CONVERT(varchar, P.PublishedDate,108) AS [Publication!1!publishedDate],
      P.Version                  AS [Publication!1!version],
      ISNULL(P.Instructions,0)   AS [Publication!1!instructions],
      null                       AS [Properties!2!!element],
      null                       AS [Property!3!name],
      null                       AS [Property!3!value],
      null                       AS [Property!3!!hide],
      null                       AS [Property!3!!hide]
    FROM Publications P WITH(NOLOCK) JOIN PublicationTypes PT WITH(NOLOCK) ON PT.PublicationType = P.Type
    JOIN Documents D WITH(NOLOCK) ON P.Pubno = D.Pubno AND (D.DocType = 'DOC' OR D.DocType = 'DOCX')
    WHERE P.PubNo = @PubNo

    UNION ALL

    SELECT
      2                          AS tag,
      null                       AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Organization',
      isnull(RixmlOrgIdType,'') + ';' + isnull(RixmlOrgId,''),
      -5,
      -5
    FROM DistributionSites
    WHERE SiteId = @SiteId

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Entitlement',
      isnull(RixmlEntitlement,''),
     -3,
     -3
    FROM DistributionEntitlements
    WHERE SiteId = @SiteId AND
    ProductGroupId IS NULL

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Entitlement',
      isnull(RixmlEntitlement,''),
     -3,
     -3
    FROM DistributionEntitlements
    WHERE SiteId = @SiteId
    AND ProductGroupId in (SELECT ProductGroupId FROM ProductGroupDocuments WHERE PubNo = @Pubno)

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'WatermarkText',
      isnull(WaterMarkText,''),
      -1,
      -1
    FROM DistributionSites
    WHERE SiteId = @SiteId

   UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'EntitlementContext',
      isnull([Site],''),
      -4,
      -4
    FROM DistributionSites
    WHERE SiteId = @SiteId

  UNION ALL

   SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'PageCount',
      isnull(CAST([PageCount] as varchar(10)),''),
      -1,
      -1
     FROM Publications
    WHERE PubNo=@PubNo

    UNION ALL

    SELECT DISTINCT
      3         AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'PDFLock',
      isnull(PDFLock,''),
      -1,
      -1
    FROM DistributionSites
    WHERE SiteId = @SiteId

    UNION ALL
    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'FileVersion',
      ISNULL(CONVERT(varchar,MAX(ISNULL(DF.FileVersion,0))),'0'),
      0,
      0
    FROM   DistributionFiles DF WITH (NOLOCK)
    JOIN   DistributionQueue DQ WITH (NOLOCK) ON DQ.DistributionId = DF.DistributionId
    WHERE  DQ.PubNo = @PubNo AND DQ.SiteId = @SiteId
    AND SUBSTRING(DF.FileName, charindex('.',DF.FileName) + 1, len(DF.FileName) - charindex('.',DF.FileName)  ) = 'xml'

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      CASE PN.PropName
        WHEN 'Keywords' THEN 'ResearchKeywords'
        ELSE PN.PropName
      END,
      CASE PN.PropName
        WHEN 'Industry' THEN ISNULL(CONVERT(varchar,I.IndustryId),'') + ';' + I.IndustryName
        WHEN 'Author'   THEN ISNULL(CONVERT(varchar,A.AuthorId),'') + ';' + A.Name + ';' + A.First + ';' + A.Last + ';' + A.Phone + ';' + A.ExtEmail  + ';' + Convert(Varchar,A.IsAnalyst)
        WHEN 'Ticker'   THEN ISNULL(CONVERT(varchar,S2.SecurityId),'') + ';' + S2.RIC + ';RIC;' + S2.Company + ';' + S2.CountryCode + ';' + C.Country + ';' + S2.Ticker
        WHEN 'Keywords'  THEN ISNULL(PV.PropValue, '')
        ELSE ''
      END,
      PV.PropNo,
      PS.SeqNo
    FROM PropertySets PS     WITH(NOLOCK)
    LEFT JOIN Properties PV  WITH(NOLOCK) ON PV.PropId = PS.PropId AND PV.PubNo = @PubNo
    LEFT JOIN Industries I   WITH(NOLOCK) ON I.IndustryName = PV.PropValue
    LEFT JOIN Authors A      WITH(NOLOCK) ON A.Name = PV.PropValue
    LEFT JOIN Securities2 S2 WITH(NOLOCK) ON S2.Ticker = PV.PropValue
    LEFT JOIN Countries C    WITH(NOLOCK) ON S2.CountryCode = C.CountryCode
    JOIN PropertyNames PN    WITH(NOLOCK) ON PN.PropId = PS.PropId
    WHERE PS.PublicationTypeId IN (SELECT PT.PublicationTypeId FROM Publications P WITH(NOLOCK) JOIN PublicationTypes PT WITH(NOLOCK) ON PT.PublicationType = P.Type WHERE P.PubNo = @PubNo)
    AND PN.PropId IN (5, 9, 11,13)  AND PV.PropValue NOT IN (SELECT TICKER FROM Securities2 WHERE TickerType = 'Index')

    ORDER BY 1, 19, 18, 17
    FOR XML Explicit
  END
GO

if exists(select * from sys.objects where object_id = object_id('spGetHighlightsXml') and type = 'p')
drop proc dbo.spGetHighlightsXml
go

-- =================================================================================================
-- Author:      Sandarsh M S
-- Revised:     06/08/2017
-- Description: Get HighlightsXml for a given publication
-- =================================================================================================
create proc dbo.spGetHighlightsXml
@PubNo int
AS
begin
  select HighlightsXml from PublicationsXml where PubNo = @PubNo
end
go

grant execute on dbo.spGetAdapterRixml  to DE_IIS, PowerUsers
grant execute on dbo.spGetHighlightsXml to DE_IIS, PowerUsers
go

/*
--DEBUG

select * from DistributionQueue
where Scheduled > getdate() -30

*/
