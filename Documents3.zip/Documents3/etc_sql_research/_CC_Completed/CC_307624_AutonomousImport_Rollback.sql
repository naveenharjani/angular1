-- AutonomousImport_Rollback.sql
-- 03/25/2019

/*

Alter table FileProcessingLog
Alter spLoadAutonomousAuthors
Alter spLoadAutonomousTickers
alter spAddFileProcessingLog

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.columns where name = N'Type' and object_id = object_id(N'FileProcessingLog'))
  alter table FileProcessingLog drop [Type]
go
-- =================================================================================================
-- Author:       Anup Singh
-- Revisions:    10/23/2018 - Created
-- Description:  Log entries for file processing - Readership, Holdings, Models usage, Autonomous in/out files
-- =================================================================================================
ALTER PROC [dbo].[spAddFileProcessingLog]
(
 @DataStore as nvarchar(250),
 @filename as nvarchar(250),
 @ServerName as nvarchar(100),
 @EditorId as int,
 @Comment as nvarchar(max) = null,
 @DataFlow as nvarchar(10) = 'INBOUND'
)
AS
BEGIN

    IF @DataStore  = 'Holdings'
    BEGIN
        INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,LastExecution))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,LastExecution))), 101)
           ,count(*)
           ,@EditorId
           ,'Holdings ' + Convert(varchar(10),count(*)) + ' / vHoldings ' + Convert(Varchar(10),(select count(*) from vHoldings))
       ,@DataFlow
           from Holdings
    END
    ELSE IF @DataStore  = 'OneAccess'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,file_date_UTC))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,file_date_UTC))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
       ,@DataFlow
           from PortalUsageStaging_ONEaccess
    END
    ELSE IF @DataStore  = 'Bloomberg'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,'Bloomberg'
               ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Read Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Read Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
       ,@DataFlow
           from PortalUsageStaging_Bloomberg
    END

    ELSE IF @DataStore  = 'BlueMatrix'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,'BlueMatrix'
              ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Read Date/Time]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Read Date/Time]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
       ,@DataFlow
           from PortalUsageStaging_BlueMatrix
    END
    ELSE IF @DataStore  = 'FactSet'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,'FactSet'
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Date/time read]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Date/time read]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
       ,@DataFlow
           from PortalUsageStaging_FactSet
    END
    ELSE IF @DataStore  = 'TR' or @DataStore = 'THOMSONREUTERS'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,@DataStore
              ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Viewed Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Viewed Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
       ,@DataFlow
           from PortalUsageStaging_TR
    END
    ELSE IF @DataStore  = 'CIQ'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Activity Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Activity Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
       ,@DataFlow
           from PortalUsageStaging_CIQ
    END

    ELSE IF @DataStore  = 'RSRCHX'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Action Date (UTC)]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Action Date (UTC)]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
       ,@DataFlow
           from PortalUsageStaging_RSRCHX
    END

    ELSE IF @DataStore  = 'REDDEER'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Read_Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Read_Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
       ,@DataFlow
           from PortalUsageStaging_RedDeer
    END
    ELSE IF @DataStore  = 'VisibleAlpha'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,'VisibleAlpha'
              ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(CONVERT(date,replace(file_date_UTC,'Z',':00'),127))), 101)
           ,convert(varchar, Convert(date,Max(CONVERT(date,replace(file_date_UTC,'Z',':00'),127))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
       ,@DataFlow
           from PortalUsageStaging_VisibleAlpha
    END

   IF @DataStore  = 'BlueCurve'
    BEGIN
        INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
          ,DataFlow
                     )
        select GETDATE()
               ,'BlueCurve'
              ,@ServerName
               ,@filename
              ,null
              ,null
              ,null
              ,@EditorId
             ,null
       ,@DataFlow

    END
END

GO


-- =================================================================================================
-- Author:       Anup Singh
-- Revisions:    02/27/2019 - Created
-- Description:  Loads data from AutonomousStagingAuthors staging table to Authors table
-- =================================================================================================
Alter PROCEDURE [dbo].[spLoadAutonomousAuthors]
 AS
begin

  --- Update with latest data if the Autonomous author already exists in live table with TypeId = 2
       update A set
     A.Name = staging.name,
     A.First = case when charindex(' ',ltrim(rtrim(Staging.Name)))> 0 then  substring(ltrim(rtrim(Staging.Name)), 1, charindex(' ',ltrim(rtrim(Staging.Name)))-1) else Staging.Name end,
     A.Last =  case when charindex(' ',ltrim(rtrim(Staging.Name)))> 0 then  substring(ltrim(rtrim(Staging.Name)),charindex(' ',ltrim(rtrim(Staging.Name)))+1,len(ltrim(rtrim(Staging.Name)))) else null end,
     A.Phone = case when charindex('/',ltrim(rtrim(Staging.Phone)))> 0 then  substring(ltrim(rtrim(Staging.Phone)), 1, charindex('/',ltrim(rtrim(Staging.Phone)))-1) else ltrim(rtrim(Staging.Phone)) end,
     A.ExtEmail = Staging.Email,
     A.WindowsUserName = Staging.scb_login,
     A.TypeId = 2,
     A.IsActive = -1,
     A.RegionID = case Staging.office when  'London' then 2 when 'New York' then 1 when 'Hong Kong' then 3 else 1 end,
     A.EditorId = 0,
     A.EditDate = GETDATE()
     from Authors A
     inner join AutonomousStagingAuthors as Staging
     on A.AltId = staging.id
     where A.TypeId = 2
     and (Staging.active ='true' or staging.active = 'false')

  --Insert if Autonmous author does not exist in live table
       insert into authors(Name, First, Last,Phone,Fax,IsAnalyst,IsActive,TitleID,RegionID,ExtEmail,MetricsEligible,WindowsUserName,AltId,TypeId,EditorId,EditDate)
    select staging.name
    ,case when charindex(' ',ltrim(rtrim(Staging.Name)))> 0 then  substring(ltrim(rtrim(Staging.Name)), 1, charindex(' ',ltrim(rtrim(Staging.Name)))-1) else Staging.Name end
    ,case when charindex(' ',ltrim(rtrim(Staging.Name)))> 0 then  substring(ltrim(rtrim(Staging.Name)),charindex(' ',ltrim(rtrim(Staging.Name)))+1,len(ltrim(rtrim(Staging.Name)))) else null end
    ,case when charindex('/',ltrim(rtrim(Staging.Phone)))> 0 then  substring(ltrim(rtrim(Staging.Phone)), 1, charindex('/',ltrim(rtrim(Staging.Phone)))-1) else ltrim(rtrim(Staging.Phone)) end
    ,null
    ,-1
    ,-1
    ,2
    ,case Staging.office when  'London' then 2 when 'New York' then 1 when 'Hong Kong' then 3 else 1 end
    ,email
    ,'F'
    ,Staging.scb_login
    ,Staging.ID
    ,2
    ,0
    ,GETDATE()
    from AutonomousStagingAuthors  as Staging
     Left outer join Authors  as  A
     on A.Name = Staging.name
     where A.AuthorID is null  and (Staging.active ='true' or Staging.active = 'false')

       --If the author exists in live table with TypeId = 1, not actively covered (unlaunched or dropped) then update existing row with TypeId = 2
       update A set
    A.Name = staging.name,
    A.First = case when charindex(' ',ltrim(rtrim(Staging.Name)))> 0 then  substring(ltrim(rtrim(Staging.Name)), 1, charindex(' ',ltrim(rtrim(Staging.Name)))-1) else Staging.Name end,
    A.Last =  case when charindex(' ',ltrim(rtrim(Staging.Name)))> 0 then  substring(ltrim(rtrim(Staging.Name)),charindex(' ',ltrim(rtrim(Staging.Name)))+1,len(ltrim(rtrim(Staging.Name)))) else null end,
    A.Phone = case when charindex('/',ltrim(rtrim(Staging.Phone)))> 0 then  substring(ltrim(rtrim(Staging.Phone)), 1, charindex('/',ltrim(rtrim(Staging.Phone)))-1) else ltrim(rtrim(Staging.Phone)) end,
    A.ExtEmail = Staging.Email,
    A.WindowsUserName = Staging.scb_login,
    A.TypeId = 2,
    A.IsActive = -1,
    A.AltId = Staging.id,
    A.EditorId = 0,
    A.EditDate = GETDATE()
    from Authors as A
    inner join AutonomousStagingAuthors as Staging
    on A.Name = Staging.name
    where A.TypeId = 1

     --Drop Autonomous author (mark isActive =0 ) if the person does not exist in staging table
     update A set
     A.IsActive = 0,
     A.EditorId =0,
     A.EditDate = GETDATE()
     from Authors A
     left outer join AutonomousStagingAuthors as Staging
     on A.AltId = staging.id
     where A.TypeId = 2 and Staging.name is null
end


go


-- =================================================================================================
-- Author:       Anup Singh
-- Revisions:    02/27/2019 - Created
-- Description:  Loads data from AutonomousStagingTickers staging table to Securites2 table
-- =================================================================================================
Alter procedure [dbo].[spLoadAutonomousTickers]
 as
begin

begin try
    begin transaction
    CREATE TABLE #Staging(
         RowNumber int
         ,Instrument_Id  int
         ,Ticker varchar(15) null
         ,Name varchar(63) null
         ,ISIN varchar(100) null
         ,TickerType varchar(10) null
         ,IsActive int null
         ,Instrument_Currency  char(3)
         ,Region varchar(10) null
         ,IsPrimary char(1)
         ,OrdNo int
         ,Country varchar(100) null
         ,TypeId int
      );

    CREATE TABLE #Security(
    [RowNumber]  int ,
    [Ticker] [varchar](15) NULL,
    [TickerSource] [smallint] NULL,
    [TickerType] [varchar](10) NULL,
    [Company] [varchar](63) NOT NULL,
    [CUSIP] [varchar](10) NULL,
    [SEDOL] [varchar](10) NULL,
    [CINS] [varchar](10) NULL,
    [ISIN] [varchar](12) NULL,
    [VALOREN] [varchar](20) NULL,
    [RIC] [varchar](15) NULL,
    [IsActive] [smallint] NULL,
    [ExchangeCode] [varchar](10) NULL,
    [CurrencyCode] [char](3) NULL,
    [BenchmarkIndex] [varchar](10) NULL,
    [CountryCode] [char](2) NULL,
    [RegionId] [int] NOT NULL,
    [EditorId] [int] NULL,
    [EditDate] [datetime] NULL,
    [GICS_ID] [int] NULL,
    [Alias] [varchar](50) NULL,
    [Status] [int] NULL,
    [GoUrl] [varchar](100) NULL,
    [CompanyId] [int] NOT NULL,
    [IsPrimary] [char](1) NOT NULL,
    [OrdNo] [int] NOT NULL,
    [LockMode] [int] NULL,
    [TypeId] [int] NULL,
    [AltId] [int] NULL
    )

    --Update with latest data if the ticker already exists in live table with TypeId = 2
        update S set
      S.Company = Staging.name,
      S.CurrencyCode = Staging.Instrument_Currency,
      S.EditorId = 0,
      S.EditDate = GETDATE(),
      S.TypeId = 2,
      S.IsActive =-1,
      S.ISIN = ltrim(rtrim(Staging.ISIN)),
      S.RegionId = (select RegionID from Regions where Region = Staging.Region or RegionAlias = Staging.Region or Region like '%' + Staging.Region + '%')
    from Securities2 S
    inner join AutonomousStagingTickers as Staging
    on S.AltId = Staging.instrument_id
    where S.TypeID = 2 and (Staging.active ='true' or Staging.active = 'false')

    --If the ticker does not exist in live table, then insert a row into Company table and Securities2 table with TypeId = 2
    insert into #Staging

    select ROW_NUMBER() OVER (ORDER BY replace(Ltrim(rtrim(Replace(Ticker,' US',''))),' ','.')) AS RowNumber
    ,instrument_id
    ,Ticker
    ,name
    ,ISIN
    ,TickerType
    ,IsActive
    ,instrument_currency
    ,Region
    ,IsPrimary
    ,OrdNo
    ,Country
    ,Typeid
    from
    (
    Select ROW_NUMBER() OVER (PARTITION BY replace(Ltrim(rtrim(Replace(Staging.Ticker,' US',''))),' ','.')  ORDER BY replace(Ltrim(rtrim(Replace(Staging.Ticker,' US',''))),' ','.'),active DESC)  AS RowNumber
    ,Staging.instrument_id
    ,replace(Ltrim(rtrim(Replace(Staging.Ticker,' US',''))),' ','.') as Ticker
    ,Staging.name
    ,ltrim(rtrim(Staging.ISIN)) as ISIN
    ,'STOCK' as TickerType
    ,-1 as IsActive
    ,Staging.instrument_currency
    ,Staging.Region
    ,'Y' as IsPrimary
    ,1 as OrdNo
    ,Staging.Country
    ,2 as Typeid
    from AutonomousStagingTickers as Staging
    Left outer join Securities2 as S on replace(Ltrim(rtrim(Replace(Staging.ticker,' US',''))),' ','.') = S.Ticker
    where S.Ticker is null and (Staging.active ='true' or Staging.active = 'false')
    ) as v where RowNumber = 1


    declare @count as int
    declare @pointer as int
    declare @companyid as int

    set @pointer = 1
    select @count = Count(RowNumber) from #Staging

    while @pointer <= @count
    begin

      if not Exists (select Company from Companies where Company = (select ltrim(rtrim(Name)) from #Staging where RowNumber = @pointer))
      begin
        insert into Companies(Company,EditorId,EditDate)
        select ltrim(rtrim(Name)),0,GETDATE() from #Staging where RowNumber = @pointer
        set @companyid = @@IDENTITY
      end
      else
      begin
        select @companyid = CompanyId from Companies where Company = (select ltrim(rtrim(Name)) from #Staging where RowNumber = @pointer)
      end

      insert into Securities2(Ticker,Company,ISIN,TickerType,IsActive,CurrencyCode,RegionId,CompanyId,IsPrimary,OrdNo,CountryCode,EditorId,EditDate,TypeId,AltId)
      Select Staging.ticker
        ,Staging.Name
        ,ltrim(rtrim(Staging.ISIN))
        ,'STOCK'
        ,Staging.IsActive
        ,Staging.Instrument_Currency
        ,(select RegionID from Regions where Region = Staging.Region or RegionAlias = Staging.Region or Region like '%' + Staging.Region + '%')
        ,@companyid
        ,'Y'
        ,1
        ,(select CountryCode from Countries where Country = Staging.Country)
        ,0
        ,GETDATE()
        ,2
        ,Staging.Instrument_Id
      from #staging  as Staging where RowNumber = @pointer

      set @pointer = @pointer+ 1
    end

    --If the ticker exists in live table with TypeId = 1, not actively covered (unlaunched or dropped) then update existing row with TypeId = 2
    update S set
    S.TypeId = 2,
    S.Company = Staging.name,
    S.AltId = Staging.instrument_id,
    S.EditorId =0,
    S.EditDate = GETDATE(),
    S.IsActive =-1,
    S.ISIN = ltrim(rtrim(Staging.ISIN)),
    S.RegionId = (select RegionID from Regions where Region = Staging.Region or RegionAlias = Staging.Region or Region like '%' + Staging.Region + '%')
    from Securities2 as S
    inner join AutonomousStagingTickers as Staging
    on S.Ticker =replace(Ltrim(rtrim(Replace(Staging.Ticker,' US',''))),' ','.')
    Left outer join (select ROW_NUMBER()OVER(Partition By SecurityID Order By CoverageID DESC) as RowNumber,* from ResearchCoverage ) as R
    on S.SecurityID = R.SecurityID
    where ((R.LaunchDate is null) or (R.LaunchDate is not null and  R.DropDate is not null))
    and S.TypeID = 1
    and (R.RowNumber = 1 or R.RowNumber is null)
    and (Staging.active ='true' or Staging.active = 'false')

     --Drop Autonomous ticker (mark isActive =0 ) if the ticker does not exist in staging table
    update S set IsActive = 0,S.EditorId =0,S.EditDate = GETDATE()
    from Securities2 as S
    left outer join AutonomousStagingTickers as Staging
    on S.Ticker =replace(Ltrim(rtrim(Replace(Staging.Ticker,' US',''))),' ','.')
    where S.TypeId = 2 and Staging.ticker is null


    drop table #Staging
    drop table #Security
commit transaction
end try
begin catch
    rollback transaction
    DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    -- Use RAISERROR inside the CATCH block to return error
    -- information about the original error that caused
    -- execution to jump to the CATCH block.
    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );

end catch

end
go


