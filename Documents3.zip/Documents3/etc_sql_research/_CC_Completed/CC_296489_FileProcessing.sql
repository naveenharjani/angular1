-- FileProcessing.sql
-- 09/25/2018

/*

create FileProcessingConfig
create FileProcessingLog table
create spGetFileProcessingConfig
create spAddFileProcessingLog

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FileProcessingConfig]') AND type in (N'U'))
   DROP TABLE [dbo].[FileProcessingConfig]
GO

CREATE TABLE [dbo].[FileProcessingConfig]
(
	[ConfigId]       [int]           NOT NULL IDENTITY(1,1),
	[DataStore]      [nvarchar](100) NOT NULL,
	[SourceFilePath] [nvarchar](max) NOT NULL,
	[BackupFilePath] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_ReadershipFileConfig] PRIMARY KEY CLUSTERED ( [ConfigId] ASC ) ON [PRIMARY]
) ON [PRIMARY]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FileProcessingLog]') AND type in (N'U'))
   DROP TABLE [dbo].[FileProcessingLog]
GO

CREATE TABLE [dbo].[FileProcessingLog]
(
	[LogId]       [int]          NOT NULL IDENTITY(1,1),
	[LoadDate]    [datetime]     NOT NULL,
	[DataStore]   [varchar](100) NOT NULL,
	[Server]      [varchar](100) NOT NULL,
	[FileName]    [varchar](500) NOT NULL,
	[PeriodStart] [varchar](10)      NULL,
	[PeriodEnd]   [varchar](10)      NULL,
	[RowsLoaded]  [int]          NOT NULL,
	[EditorId]    [int]          NOT NULL,
	[Comment]     [varchar](MAX)     NULL,
 CONSTRAINT [PK_ReadershipFileLog] PRIMARY KEY CLUSTERED ( [LogId] ASC ) ON [PRIMARY]
) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetFileProcessingConfig]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetFileProcessingConfig]
GO

-- =================================================================================================
-- Author:       Anup Singh
-- Revisions:    10/08/2018 - Created
-- Description:  It will fetch config details of File Procesing i.e. SourceFilePath, BackupFilePath, ProjectName
-- =================================================================================================
CREATE PROC [dbo].[spGetFileProcessingConfig]
AS
BEGIN
  SELECT * FROM FileProcessingConfig
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spAddFileProcessingLog]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spAddFileProcessingLog]
GO

-- =================================================================================================
-- Author:       Anup Singh
-- Revisions:    10/23/2018 - Created
-- Description:  To enter log for file processing project like Holdings, Readership,Model
-- =================================================================================================
Create PROC [dbo].[spAddFileProcessingLog]
(
 @DataStore as nvarchar(250),
 @filename as nvarchar(250),
 @ServerName as nvarchar(100),
 @EditorId as int,
 @Comment as nvarchar(max) = null
)
AS
BEGIN
			
		IF @DataStore  = 'Holdings'
		BEGIN
		    INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,LastExecution))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,LastExecution))), 101)
					 ,count(*)
					 ,@EditorId
					 ,'Holdings ' + Convert(varchar(10),count(*)) + ' / vHoldings ' + Convert(Varchar(10),(select count(*) from vHoldings)) 
					 from Holdings
		END
		ELSE IF @DataStore  = 'ONEaccess'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,file_date_UTC))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,file_date_UTC))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment 
					 from PortalUsageStaging_ONEaccess
		END
		ELSE IF @DataStore  = 'Bloomberg'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Read Date]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Read Date]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_Bloomberg
		END

		ELSE IF @DataStore  = 'BlueMatrix'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Read Date/Time]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Read Date/Time]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_BlueMatrix
		END
		ELSE IF @DataStore  = 'FactSet'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Date/time read]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Date/time read]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_FactSet
		END
		ELSE IF @DataStore  = 'TR'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Viewed Date]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Viewed Date]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_TR
		END
		ELSE IF @DataStore  = 'CIQ'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Download Date]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Download Date]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_CIQ
		END

		ELSE IF @DataStore  = 'RSRCHX'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Action Date (UTC)]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Action Date (UTC)]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_RSRCHX
		END

		ELSE IF @DataStore  = 'REDDEER'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Read_Date]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Read_Date]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_RedDeer
		END
		ELSE IF @DataStore  = 'VISIBLEALPHA'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(CONVERT(date,replace(file_date_UTC,'Z',':00'),127))), 101)
					 ,convert(varchar, Convert(date,Max(CONVERT(date,replace(file_date_UTC,'Z',':00'),127))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_VisibleAlpha
		END
END
GO

GRANT EXECUTE ON dbo.[spGetFileProcessingConfig] TO DE_IIS,PowerUsers
GRANT EXECUTE ON dbo.[spAddFileProcessingLog]    TO DE_IIS,PowerUsers
GO

-- DEBUG

TRUNCATE TABLE FileProcessingConfig

-- Phase I - Holdings/VisibleAlpha
INSERT INTO [FileProcessingConfig] VALUES ('Holdings', '\PRDCTL\in\Holdings\', '\PRDCTL\in\Holdings\Processed')
INSERT INTO [FileProcessingConfig] VALUES ('VisibleAlpha','\PRDCTL\in\VisibleAlpha\Readership\',' \PRDCTL\in\VisibleAlpha\Readership\Processed')
GO

/*
-- Phase II
INSERT INTO [FileProcessingConfig] values ('ONEaccess','\PRDCTL\in\ONEaccess\Readership\','\PRDCTL\in\ONEaccess\Readership\Processed')
INSERT INTO [FileProcessingConfig] values ('Bloomberg','\PRDCTL\in\Bloomberg\Readership\','\PRDCTL\in\Bloomberg\Readership\Processed')
INSERT INTO [FileProcessingConfig] values ('BlueMatrix','\PRDCTL\in\BlueMatrix\Readership\','\PRDCTL\in\BlueMatrix\Readership\Processed')
INSERT INTO [FileProcessingConfig] values ('CIQ','\PRDCTL\in\CIQ\Readership\','\PRDCTL\in\CIQ\Readership\Processed')
INSERT INTO [FileProcessingConfig] values ('FactSet','\PRDCTL\in\FactSet\Readership\','\PRDCTL\in\FactSet\Readership\Processed')
INSERT INTO [FileProcessingConfig] values ('RedDeer','\PRDCTL\in\RedDeer\Readership\','\PRDCTL\in\RedDeer\Readership\Processed')
INSERT INTO [FileProcessingConfig] values ('RSRCHX','\PRDCTL\in\RSRCHX\Readership\','\PRDCTL\in\RSRCHX\Readership\Processed')
INSERT INTO [FileProcessingConfig] values ('TR','\PRDCTL\in\TR\Readership\','\PRDCTL\in\TR\Readership\Processed')
GO
*/

/*
SELECT * FROM FileProcessingConfig

SELECT * FROM FileProcessingLog
*/