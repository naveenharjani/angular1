-- CC_ElasticSearch.sql
-- 06/06/2019

/*

BERNSTEIN Elastic Index Service

create ElasticQueue                    - Table which holds documents to be indexed
create vwElasticQueue                  - View on top of ElasticQueue table with document title etc.,
create spIndexResearch                 - Add to Index Queue
create spGetScheduledElasticQueueItems - Retrieve items from Index Queue to be indexed
create spUpdateElasticQueueItem        - Update Index Queue item with completed date
create spGetResearchMetadata           - Get research meta data for elastic index service

alter spSavePublicationsXML            - "Publishing Engine", "Research Form"
alter spSaveProperty                   - Property edit proc altered to populate elastic queue
alter spDeletePublication              - Altered to populate elastic queue for delete
create spGetSearchResults              - Hybrid elastic and SQL getSearchResults API return json (not getElasticSearchResults)

http://institutional-dev.beehive.com/edit/editpublication.aspx?pubno=146612&field=pubdate
http://institutional-dev.beehive.com/edit/editpublication.aspx?pubno=146612&field=pubtitle

http://institutional-dev.beehive.com/edit/editproperties.aspx?pubno=146612&propid=11 -- Industry
http://institutional-dev.beehive.com/edit/editproperties.aspx?pubno=146612&propid=5  -- Author
http://institutional-dev.beehive.com/edit/editproperties.aspx?pubno=146612&propid=13 -- Ticker
http://institutional-dev.beehive.com/edit/editproperties.aspx?pubno=146612&propid=32 -- InvestorTheme

Investor Themes - /edit/editproperties.aspx?pubno=146597&propid=32

/edit/edit.aspx?pubno=146617
/research/investorthemedocs.asp?sortcol=1&sortdir=d&pg=1&sz=5000#/

*/

use Research
go

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists (select * from sys.objects where name = 'ElasticQueue' and type = 'U')
drop table ElasticQueue
go

create table dbo.ElasticQueue
(
  QueueId   int          not null identity(1,1),
  PubNo     int          not null,
  Operation char(1)      not null,
  Queued    datetime     not null,
  QueuedBy  varchar(100) not null,
  Completed datetime         null
)
go

if exists (select * from sys.objects where name = 'vElasticQueue' and type = 'V')
drop view vElasticQueue
go

create view dbo.vElasticQueue
as
select
  QueueId,
  P.Date ReportDate,
  P.Type ReportType,
  P.Title ReportTitle
from ElasticQueue EQ
join Publications P on EQ.PubNo = P.PubNo
go

if exists (select * from sys.objects where name = 'spIndexResearch' and type = 'P')
drop procedure dbo.spIndexResearch
go

create procedure dbo.spIndexResearch(@PubNo int, @Operation char(1), @QueuedBy varchar(100))
as
begin
  insert into ElasticQueue(PubNo, Operation, Queued, QueuedBy)
  select @PubNo, @Operation, getdate(), @QueuedBy
end
go

if exists (select * from sys.objects where name = 'spGetScheduledElasticQueueItems' and type = 'P')
drop procedure dbo.spGetScheduledElasticQueueItems
go

create procedure dbo.spGetScheduledElasticQueueItems
as
select QueueId, PubNo, Operation, Queued
from ElasticQueue
where Queued is not null and Completed is null
order by QueueId desc
go

if exists (select * from sys.objects where name = 'spUpdateElasticQueueItem' and type = 'P')
drop procedure dbo.spUpdateElasticQueueItem
go

create procedure dbo.spUpdateElasticQueueItem @QueueId int
as
begin
  update ElasticQueue
  set Completed = getdate()
  where QueueId = @QueueId
end
go

if exists (select * from sys.objects where object_id = OBJECT_ID(N'[dbo].[spGetResearchMetadata]'))
drop proc [dbo].[spGetResearchMetadata]
go

create procedure dbo.spGetResearchMetadata @PubNo int
as
begin
  --Get thematic tag id & name for the publication (if exists)
  declare @ThematicTagId int, @ThematicTag varchar(100)
  select @ThematicTagId = ThematicTagId, @ThematicTag = T.ThematicTag
  from Properties Pr join ThematicTags T on Pr.PropValue = T.ThematicTag and Pr.PubNo = @PubNo
  where PropId = 41 and PropValue <> ''

  --Rowset 1 - Report metadata
  select PubNo, PublishedDate, Date, Title, Type, PT.PublicationTypeId TypeId, P.FileName, P.FileSize,P.Version, P.PageCount, P.SubType, @ThematicTagId ThematicTagId,@ThematicTag ThematicTag
  from Publications P join PublicationTypes PT on P.Type = PT.PublicationType
  where P.PubNo = @PubNo

  --Rowset 2 - Report authors
  select AuthorId, Name
  from Authors A join Properties Pr on A.Name = Pr.PropValue
  where Pr.PropId = 5 and Pr.PubNo = @PubNo
  order by Pr.PropNo

  --Rowset 3 - Report tickers
  select S.SecurityId, S.Ticker, EpsFY1Action 'EstimateAction' , TargetPriceAction, RatingAction, CoverageAction
  from PublicationFinancials PF join Securities2 S on PF.SecurityId = S.SecurityId
  join Properties Pr on PF.Ticker = Pr.PropValue and PF.PubNo = Pr.PubNo
  where PF.PubNo = @PubNo and S.TickerType = 'stock' and Pr.PropId = 13
  order by Pr.PropNo

  --Rowset 4 - Report industries
  select IndustryId, IndustryName
  from Industries I join Properties Pr on I.IndustryName = Pr.PropValue
  where  Pr.PropId = 11 and Pr.PubNo = @PubNo
  order by Pr.PropNo

  --Rowset 5 - Report investor themes
  select InvestorThemeId, InvestorTheme
  from InvestorThemes I join Properties Pr on I.InvestorTheme = Pr.PropValue
  where  Pr.PropId = 32 and Pr.PubNo = @PubNo
  order by Pr.PropNo

  --Rowset 6 - Report keywords
  select K.KeywordId, K.Keyword
  from Keywords K join Properties Pr on K.Keyword = Pr.PropValue
  where  Pr.PropId = 9 and Pr.PubNo = @PubNo
  order by Pr.PropNo

end
go

ALTER PROCEDURE [dbo].[spSavePublicationsXml]
  @PropertiesXml xml,
  @CompanyFinancialsXml xml,
  @TickerTableXml xml,
  @HighlightsXml xml,
  @EditorId int = 0
AS
BEGIN TRY
  BEGIN TRANSACTION

  DECLARE
  @Date         DATETIME,
  @Type         VARCHAR(30),
  @SubType      VARCHAR(30),
  @Title        VARCHAR(300),
  @PubNo        INT,
  @Version      INT,
  @hDoc         INT,
  @hDoc2        INT,
  @hDoc3        INT,
  @CurrentDate  DATETIME,
  @FileName     VARCHAR(63),
  @FileSize     BIGINT,
  @PageCount    INT,
  @Approver     VARCHAR(50),
  @ApprovedDate DATETIME,
  @AuditNo      INT

  SELECT @CurrentDate = getdate()

  EXEC sp_xml_preparedocument @hDoc OUTPUT, @PropertiesXml

    --Retrieve approver & approved date(UTC format) from document info node
  SELECT @Approver = U.ExchangeEmail, @ApprovedDate = ApprovedDate
  FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
  WITH (Approver  varchar(31)  '@approver',
        ApprovedDate datetime  '@approvedDate'
        ) X JOIN Users U on X.Approver = replace(replace(UserName, 'ac/',''),'ac\','')

  --convert approved date from UTC to EST(db server time zone)
  SET @ApprovedDate = dateadd(hh,datediff(hh,getutcdate(),getdate()),@ApprovedDate)

  --If no approver info, default to Cheryl
  IF (@Approver = '' or @Approver is null)
  BEGIN
    SELECT @Approver = ExchangeEmail, @ApprovedDate = @CurrentDate
    FROM Users
    WHERE
    replace(replace(UserName, 'ac/',''),'ac\','') = 'cdekre'
  END

  --Retrieve date,type,title from document info node
  SELECT @Date = X.Date, @Type = X.Type, @SubType = X.SubType, @Title = X.Title, @PubNo = X.PubNo, @Version = X.Version
  FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
  WITH (Date      datetime     '@pubDate',
        Type      varchar(31)  '@type',
        SubType   varchar(30)  '@subType',
        Title     varchar(255) '@title',
        PubNo     int          '@pubNo',
        Version   int          '@version'
        ) X

  SELECT @FileName = X.FileName, @FileSize =  X.FileSize, @PageCount = X.PageCount
  FROM OPENXML (@hDoc, 'DocumentInfo/Documents/Document', 1)
  WITH (DocType       varchar(4)  '@docType',
        FileName      varchar(30) '@fileName',
        FileSize      bigint      '@fileSize',
        PageCount     int         '@pageCount'
        ) X
  WHERE
    X.DocType = 'PDF'

  --Incase of resubmits delete the previous vesion
  IF @Version > 1
  BEGIN
    DELETE FROM ProductGroupDocuments       WHERE PubNo = @PubNo
    DELETE FROM RelatedPublications         WHERE PubNo = @PubNo

    INSERT INTO AuditLog (Operation, EditorId, EditDate) VALUES ('R', @EditorId, @CurrentDate)
    SELECT @AuditNo = @@IDENTITY

    INSERT INTO PublicationsLog (AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate)
    SELECT @AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate FROM Publications WHERE PubNo = @PubNo

    INSERT INTO DocumentsLog (AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig)
    SELECT @AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig FROM Documents WHERE PubNo = @PubNo

    INSERT INTO PropertiesLog (AuditNo, PubNo, PropNo, PropId, PropValue)
    SELECT @AuditNo, PubNo, PropNo, PropId, PropValue FROM Properties WHERE PubNo = @PubNo

    --Delete if exists in PublicationFinancialNumbers (for resubmit)
    DELETE FROM PublicationFinancialNumbers WHERE PubNo = @PubNo
    DELETE FROM PublicationFinancials       WHERE PubNo = @PubNo
    DELETE FROM Properties                  WHERE PubNo = @PubNo
    DELETE FROM Documents                   WHERE PubNo = @PubNo
    DELETE FROM Publications                WHERE PubNo = @PubNo
  END

  --insert into Publications table
  INSERT INTO Publications (PubNo, Date, Type, SubType, Title, FileName, FileSize, Approver, ApprovedDate, PublishedDate, Version, Instructions, PageCount, EditorId, EditDate)
  SELECT @PubNo, @Date, @Type, @SubType, @Title, @FileName, @FileSize,@Approver, @ApprovedDate, @CurrentDate, @Version, 4, @PageCount, 0, @CurrentDate

  INSERT INTO Documents (PubNo, DocNo, DocType, FileName, FileNameOrig)
  SELECT @PubNo, X.DocNo, X.DocType, X.FileName, X.FileNameOrig
  FROM OPENXML (@hDoc, 'DocumentInfo/Documents/Document', 1)
  WITH (DocNo         int         '@docNo',
        DocType       varchar(4)  '@docType',
        FileName      varchar(30) '@fileName',
        FileNameOrig  varchar(63) '@fileNameOrig'
        ) X


  --insert into properties table with report meta data
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, Value, Name
  INTO #TmpPropertyCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Properties/Property', 1)
  WITH (value           varchar(200) '@value',
        name            varchar(30)  '@name'
        )
  WHERE Name <> ''

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Value
  FROM #TmpPropertyCollection T JOIN PropertyNames PN ON PN.PropName = T.Name
  WHERE T.Value <> ''

  --Retrieve Authors
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, AuthorId, Name
  INTO #TmpAuthorCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Authors/Author', 1)
  WITH (authorid        int         '@id',
        name            varchar(200) '@name'
        )

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Name
  FROM #TmpAuthorCollection T CROSS JOIN PropertyNames PN
  WHERE PropName = 'Author'
  AND T.Name <> ''

  --Retrieve Industries
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, IndustryId, Name
  INTO #TmpIndustryCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Industries/Industry', 1)
  WITH (industryid      int         '@id',
        name            varchar(200) '@name'
        )

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Name
  FROM #TmpIndustryCollection T CROSS JOIN PropertyNames PN
  WHERE PropName = 'Industry'
  AND T.Name <> ''

  --Retrieve Bernstein tickers from Securities collection of document properties xml
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, X.SecurityId, X.Ticker, X.IndicateChange, X.TickerSheetId
  INTO #TmpTickerCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
  WITH (securityId      int         '@id',
        ticker          varchar(30) '@ticker',
        indicateChange  varchar(10) '@indicateChange',
        tickerSheetId   bigint      '@tickerSheetId'
        ) X --JOIN Securities2 S ON X.Ticker = S.Ticker
  --WHERE S.TickerType = 'STOCK'

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Ticker
  FROM #TmpTickerCollection T CROSS JOIN PropertyNames PN
  WHERE PropName = 'Ticker'
  AND T.Ticker <> ''

--Retrieve Autonomous tickers from AutoSecurities collection of document properties xml
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, X.SecurityId, X.Ticker
  INTO #TmpAutoTickerCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/AutonomousSecurities/AutonomousSecurity', 1)
  WITH (securityId      int         '@id',
        ticker          varchar(30) '@ticker',
        indicateChange  varchar(10) '@indicateChange',
        tickerSheetId   bigint      '@tickerSheetId'
        ) X --JOIN Securities2 S ON X.Ticker = S.Ticker
  --WHERE S.TickerType = 'STOCK'

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Ticker
  FROM #TmpAutoTickerCollection T CROSS JOIN PropertyNames PN
  WHERE PropName = 'Ticker'
  AND T.Ticker <> ''

  --Retrieve Investor Themes
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, ThemeId, Name
  INTO #TmpInvestorThemeCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/InvestorThemes/Theme', 1)
  WITH (ThemeId         int           '@id',
        Name            varchar(200)  '@name'
        )

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Name
  FROM #TmpInvestorThemeCollection T CROSS JOIN PropertyNames PN
  WHERE PropName = 'InvestorTheme'
  AND T.Name <> ''

  --Retrieve Auto Blast Lists
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, BlastListId, Name
  INTO #TmpBlastListCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Blastlists/Blastlist', 1)
  WITH (BlastListId     varchar(100)  '@blastListId',
        Name            varchar(200)  '@name'
        )

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, B.BlastListId
  FROM #TmpBlastListCollection B CROSS JOIN PropertyNames PN
  WHERE PropName = 'BlastList'

  --Temp table to store indicatechange='Yes' tickers (subset of securities collection)
  SELECT DisplayNo, SecurityId, Ticker, IndicateChange, TickerSheetId
  INTO #Tmp_ChangeTickers
  FROM #TmpTickerCollection
  WHERE IndicateChange = 'Yes'

  --First version of the report
  IF @Version = 1
  BEGIN
    --Promote drafts to live if change report (Rating/TP/Estimates)
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = @PubNo, Date = @CurrentDate
    FROM FinancialNumbers FN
    JOIN #Tmp_ChangeTickers T ON FN.SecurityId = T.SecurityId
    WHERE FN.IsDraft = 1

    --update PubNo in TickesheetData table for change tickers
    UPDATE TickerSheetData
    SET PubNo = @PubNo
    FROM TickerSheetData TS JOIN #Tmp_ChangeTickers T ON TS.SecurityId = T.SecurityId AND TS.TickerSheetId = T.TickerSheetId

    --Save document xml's into PublicationXml table
    INSERT INTO PublicationsXml(PubNo, PropertiesXml, CompanyFinancialsXml, TickerTableXml, HighlightsXml,EditorId,EditDate)
    SELECT @PubNo, @PropertiesXml, @CompanyFinancialsXml, @TickerTableXml, @HighlightsXml,@EditorId,@CurrentDate
  END
  ELSE
  --if Version > 1 (Resubmit)
  BEGIN

    DECLARE @DocPropertiesXml XML
    SELECT @DocPropertiesXml = PropertiesXml FROM PublicationsXml WHERE PubNo = @PubNo

    --If correction exists for this report
    IF (SELECT max(CorrectionMode) FROM CorrectionQueue WHERE PubNo = @PubNo AND Status in ('Required','Optional')) = 1
    BEGIN
      --Get the list of by pass tickers

      SELECT C.SecurityId, S.Ticker
      INTO #TmpBypassTickers
      FROM CorrectionQueue C JOIN Securities2 S ON C.SecurityId = S.SecurityId
      WHERE PubNo = @PubNo
      AND C.Status in ('Required','Optional')
    AND CorrectionMode = 1

      --For the correction tickers promote draft to live (corrected value)
      UPDATE FinancialNumbers
      SET IsDraft = 0, PubNo = @PubNo, Date = @CurrentDate
      FROM FinancialNumbers FN
      JOIN #TmpBypassTickers T ON FN.SecurityId = T.SecurityId
      WHERE FN.IsDraft = 1

      --Release marketdata override for correction tickers
      UPDATE CorrectionQueue
      SET CorrectionMode = 0,Completed = @CurrentDate,Status = 'Completed'
      WHERE PubNo = @PubNo
      AND SecurityId IN (SELECT SecurityId FROM #TmpBypassTickers)

      --Delete marketdata overrides of the corrected report
      DELETE FROM MarketData
      WHERE SecurityId IN (SELECT SecurityId FROM #TmpBypassTickers)
      AND Type = 'O'

      DECLARE @NextDependentPub INT
      --Check if current report is a source report
      IF (SELECT max(IsSource) FROM CorrectionQueue WHERE PubNo = @PubNo) = 1
      BEGIN
        SELECT @NextDependentPub = min(PubNo) FROM CorrectionQueue
        WHERE SourcePubNo = @PubNo
        AND PubNo > @PubNo
        AND Status = 'Optional'
      END
      ELSE
      BEGIN
        SELECT @NextDependentPub = min(PubNo) FROM CorrectionQueue
        WHERE SourcePubNo = (SELECT max(SourcePubNo) FROM CorrectionQueue WHERE PubNo = @PubNo)
        AND PubNo > @PubNo
        AND Status = 'Optional'
      END

      --Populate marketdata overrides for each of the correction tickers
      --Loop through all tickers in #TmpTickerCollection to see if they are bypassed
      --on the dependent report and perform RestoreMarketData in loop
      SELECT @DocPropertiesXml = PropertiesXml FROM PublicationsXml WHERE PubNo = @NextDependentPub

      DECLARE @hDependentPubNo int, @SecurityId int

      --EXEC sp_xml_preparedocument @hDependentPubNo OUTPUT, @BypassXml

      SELECT C.SecurityId, S.Ticker
      INTO #TmpDependentPubNoBypassTickers
      FROM CorrectionQueue C JOIN Securities2 S ON C.SecurityId = S.SecurityId WHERE PubNo = @NextDependentPub
      AND C.Status in ('Required', 'Optional')
      --AND CorrectionMode = 1

      SELECT TOP 1 @SecurityId = SecurityId FROM #TmpDependentPubNoBypassTickers ORDER BY SecurityId
      WHILE @@ROWCOUNT = 1
      BEGIN
        EXEC spRestoreMarketData @NextDependentPub, @SecurityId, @EditorId
        EXEC spRevaluate @SecurityId
        SELECT TOP 1 @SecurityId = SecurityId FROM #TmpDependentPubNoBypassTickers WHERE SecurityId > @SecurityId ORDER BY SecurityId
      END

      --EXEC sp_xml_removedocument @hDependentPubNo
    END

    --Get Tickers with IndicateChange = 'Yes' in this version and not in previous version
    EXEC sp_xml_preparedocument @hDoc2 OUTPUT, @DocPropertiesXml

    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, X.SecurityId, X.Ticker, X.IndicateChange
    INTO #TmpPreviusTickerList
    FROM OPENXML (@hDoc2, 'DocumentInfo/Securities/Security', 1)
    WITH (securityId     int         '@id',
          ticker         varchar(30) '@ticker',
          indicateChange varchar(10) '@indicateChange'
         ) X JOIN Securities2 S ON X.Ticker = S.Ticker
    WHERE S.TickerType = 'STOCK'
    AND X.IndicateChange = 'Yes'

    --Update FinancialNumbers to promote draft for ticker additions where indicate change='Yes'
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = @PubNo, Date = @CurrentDate
    FROM FinancialNumbers FN
    JOIN #Tmp_ChangeTickers T ON FN.SecurityId = T.SecurityId
    WHERE FN.IsDraft = 1
    AND T.SecurityId NOT IN (SELECT SecurityId FROM #TmpPreviusTickerList)

    --update TickerSheetData table with PubNo for ticker additions where indicate change='Yes'
    UPDATE TickerSheetData
    SET PubNo = @PubNo
    FROM TickerSheetData TS JOIN #Tmp_ChangeTickers T ON TS.TickerSheetId = T.TickerSheetId AND TS.SecurityId = T.SecurityId
    WHERE T.SecurityId NOT IN (SELECT SecurityId FROM #TmpPreviusTickerList)

    --Update publications xml
    UPDATE PublicationsXml
    SET PropertiesXml = @PropertiesXml,
        TickerTableXml = @TickerTableXml,
        CompanyFinancialsXml = @CompanyFinancialsXml,
        HighlightsXml = @HighlightsXml,
        EditDate = @CurrentDate,
        EditorId = @EditorId
        --,BypassXml = null
    WHERE PubNo = @PubNo

  END

    --Call Revaluate for indicate change = 'Yes' tickers
    DECLARE @ChangeTickerCount int,@ChangeSecurityId int
    SELECT Top 1 @ChangeSecurityId = SecurityId FROM #Tmp_ChangeTickers ORDER BY SecurityId
    WHILE @@ROWCOUNT = 1
    BEGIN
      EXEC spRevaluate @ChangeSecurityId
      SELECT Top 1 @ChangeSecurityId = SecurityId FROM #Tmp_ChangeTickers WHERE SecurityId > @ChangeSecurityId ORDER BY SecurityId
    END

    --Insert into PublicationsFinancialNumbers
    INSERT INTO PublicationFinancialNumbers(PubNo, FinancialNumberId, CoverageId, EditorId, EditDate)
    SELECT @PubNo, FinancialNumberId, CoverageId, 1, @CurrentDate
    FROM vFinancialNumbersLatest
    WHERE SecurityId IN (SELECT SecurityId FROM #TmpTickerCollection)
    AND IsDraft = 0

    --Populate PublicationActionTags flat structured table (denormalized)
    IF @TickerTableXml.exist('/TickerTable') = 1
    BEGIN
      --print 'test'
      EXEC spSavePublicationFinancials @PubNo, @TickerTableXml, @EditorId
    END

    --Call to populate rows into ProductGroupDocuments table
    EXEC spInsProductGroupDocsByPubNo @PubNo,@Date ,@Type

    --Call to populate rows into distribution queue
    EXEC spAddDistributionItem @PubNo, 0, 'C'

    --Call to populate row into analyst blast queue
    EXEC spAddBlastItem @PubNo

    --Call to populate row into elastic index queue
    EXEC spIndexResearch @PubNo, 'I', @Approver

    EXEC sp_xml_removedocument @hDoc

    COMMIT
END TRY
BEGIN CATCH
  IF @@TRANCOUNT > 0
     ROLLBACK

  -- Raise an error with the details of the exception
  DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
  SELECT @ErrMsg = ERROR_MESSAGE(),
         @ErrSeverity = ERROR_SEVERITY()

  RAISERROR(@ErrMsg, @ErrSeverity, 1)
END CATCH

go

-- =======================================================================
-- Author:  Naveen Harjani
-- Create date:  1/4/2009
-- Description:  Save the Property information for the web edit form
--------------------------------------------------------------------------
-- Revision Dt  | Comments
--------------------------------------------------------------------------
-- mm/dd/yyyy | NH - Text e.g. List the changes made to the stored procedure.
-- 05/21/2014 | Krishna - Call spInsProductGroupDocumentsByPubNo if Author/Industry/Tickers updated
-- 01/09/2018 | Krishna - Call to populate rows into distribution queue if Author/Industry/Tickers updated
--------------------------------------------------------------------------
-- =======================================================================
ALTER PROCEDURE [dbo].[spSaveProperty]
  @PubNo         int,
  @PropId        int,
  @PropValueList text, -- Delimeted list of values to be saved for property
  @EditorId      int
AS

DECLARE @EditDate       DATETIME
DECLARE @OperationFlag  CHAR(1)
DECLARE @PropertyOld    VARCHAR(2000)

SET @EditDate = GETDATE()

--Check if the data to be saved is MultiSelections
IF EXISTS (SELECT * FROM PropertyNames WHERE PropId = @PropId AND ControlTypeCode = 'MSLB')
  BEGIN
    SELECT * INTO #PropertiesTemp FROM Properties WHERE PubNo = @PubNo AND PropId = @PropId

    --Delete all values for this multiselect Property
    DELETE FROM Properties WHERE PubNo=@PubNo AND PropId = @PropId

    --Insert all assigned Properties
    --------------------------------------------------------------------------
    --start of parse a delimited string
    --------------------------------------------------------------------------
    declare @pos int
    declare @piece   VARCHAR(max)
    declare @string  VARCHAR(max)
    declare @delimiter varchar(2)

    SET @delimiter = '|'
    SET @string = @PropValueList

    SET @pos = charindex(@delimiter , @string)

    WHILE @pos <> 0
    BEGIN
      SET @piece = left(@string, @pos-1)

      IF ltrim(rtrim(@piece)) <> ''
      BEGIN
        INSERT INTO Properties(PubNo, PropId, PropValue) VALUES(@PubNo, @PropId, @piece)
      END

      SET @string = stuff(@string, 1, @pos, '')

      SET @pos = charindex(@delimiter, @string)
    END

    --------------------------------------------------------------------------
    --end of parse a delimited string
    --------------------------------------------------------------------------

    If ltrim(rtrim(@string)) <> ''
    BEGIN
      INSERT INTO Properties(PubNo, PropId, PropValue) VALUES(@PubNo, @PropId, @string)
    END

    -- Update product group when property is updated
    DECLARE @vPublishedDate DATETIME
    DECLARE @vType VARCHAR(31)
    SELECT @vPublishedDate = PublishedDate, @vType = Type FROM Publications WHERE PubNo = @PubNo
    EXEC spInsProductGroupDocsByPubNo @PubNo,@vPublishedDate ,@vType

    --Call to populate rows into distribution queue
    EXEC spAddDistributionItem @PubNo, 0, 'C'

    SET @OperationFlag  = 'A'

    -- Record add in PropertyLog table
    INSERT INTO PropertyLog (PubNo, PropId, Operation, PropertyNew, PropertyOld, EditorId, EditDate)
    SELECT PubNo, PropId, @OperationFlag, PropValue, '',  @EditorId, @EditDate
    FROM Properties p
    WHERE PubNo=@PubNo AND PropId=@PropId
    AND NOT EXISTS (SELECT PubNo, PropId, PropValue From #PropertiesTemp t where t.PubNo = p.PubNo AND t.PropId = p.PropId and t.PropValue = p.PropValue)

    SET @OperationFlag  = 'D'

    -- Record delete in PropertyLog table
    INSERT INTO PropertyLog (PubNo, PropId, Operation, PropertyNew, PropertyOld, EditorId, EditDate)
    SELECT PubNo, PropId, @OperationFlag, '', PropValue, @EditorId, @EditDate
    FROM #PropertiesTemp p
    WHERE PubNo=@PubNo AND PropId=@PropId
    AND NOT EXISTS (SELECT PubNo, PropId, PropValue From Properties t where t.PubNo = p.PubNo AND t.PropId = p.PropId and t.PropValue = p.PropValue)

    DROP TABLE #PropertiesTemp
  END

--Else it is a publication date save
ELSE IF @PropId = 1   --1  Publication Date  TXTB
  BEGIN
      DECLARE @PubDateOld     DATETIME
      DECLARE @PubDateNew     VARCHAR(20)

      IF EXISTS (SELECT * FROM Publications WHERE PubNo = @PubNo)
      BEGIN
        SET @OperationFlag = 'U'
        SET @PubDateNew = CONVERT(VARCHAR(10), @PropValueList, 101)

        SELECT @PubDateOld = Date FROM Publications WHERE PubNo = @PubNo

        UPDATE Publications SET Date = @PubDateNew WHERE PubNo = @PubNo

        IF @PubDateNew <> @PubDateOld
        BEGIN
          -- Record change in PropertyLog table
          INSERT INTO PropertyLog (PubNo, PropId, Operation, PropertyNew, PropertyOld, EditorId, EditDate)
          VALUES (@PubNo, @PropId, @OperationFlag, CONVERT(VARCHAR(10), @PubDateNew, 101), CONVERT(VARCHAR(10), @PubDateOld, 101),
                  @EditorId, @EditDate)
         END
      END
  END

--Else it is a publication title save
ELSE IF @PropId = 3   --3  Title  TXTB
  BEGIN
      DECLARE @TitleOld       VARCHAR(255)
      DECLARE @TitleNew       VARCHAR(255)

      IF EXISTS (SELECT * FROM Publications WHERE PubNo = @PubNo)
      BEGIN
        SET @OperationFlag = 'U'
        SET @TitleNew = CONVERT(varchar(255),@PropValueList)

        SELECT @TitleOld = Title FROM Publications WHERE PubNo = @PubNo

        UPDATE Publications SET Title = @TitleNew WHERE PubNo = @PubNo

        IF @TitleNew <> @TitleOld
        BEGIN
          -- Record change in PropertyLog table
          INSERT INTO PropertyLog (PubNo, PropId, Operation, PropertyNew, PropertyOld, EditorId, EditDate)
          VALUES (@PubNo, @PropId, @OperationFlag, @TitleNew, @TitleOld, @EditorId, @EditDate)
        END

      END
  END

--Else it is a single value
ELSE
  BEGIN

    --Check if Property value already exists
    IF EXISTS(SELECT * FROM Properties WHERE PubNo=@PubNo AND PropId = @PropId)
      BEGIN
        SET @OperationFlag = 'U'

        SELECT @PropertyOld = PropValue FROM Properties WHERE PubNo = @PubNo AND PropId = @PropId

        UPDATE Properties
           SET PropValue = @PropValueList
         WHERE PubNo = @PubNo
           AND PropId = @PropId
      END
    ELSE
      BEGIN
        SET @OperationFlag = 'A'
        SET @PropertyOld = null;

        INSERT INTO Properties(PubNo, PropId, PropValue)
        VALUES(@PubNo, @PropId, @PropValueList)
      END

   IF CONVERT(VARCHAR(2000), @PropValueList) <> @PropertyOld
   BEGIN
      -- Record change in PropertyLog table
      INSERT INTO PropertyLog (PubNo, PropId, Operation, PropertyNew, PropertyOld, EditorId, EditDate)
      VALUES (@PubNo, @PropId, @OperationFlag, @PropValueList, @PropertyOld, @EditorId, @EditDate)
   END

  END

  --Call to populate row into elastic index queue
  DECLARE @UserName varchar(50)
  SELECT @UserName = UserName FROM Users WHERE UserId = @EditorId
  EXEC spIndexResearch @PubNo, 'I', @UserName

go

alter procedure [dbo].[spDeletePublication]
  @PubNo         int,
  @Operation     char(1),
  @EditorId      int,
  @Numdeleted    int OUTPUT
AS
declare @AuditNo int

-- PREVENT PHANTOM deleteS (from STALE BROWSER) BY ONLY PROCESSING FIRST delete REQUEST
if NOT EXISTS(select * from Publications where PubNo = @PubNo)
  begin
    select @Numdeleted = 0 -- return OUTPUT PARAMETERS
    return
  end

-- return ROWset
select FileName from Documents where PubNo = @PubNo

delete from ProductGroupDocuments       where PubNo = @PubNo
delete from RelatedPublications         where PubNo = @PubNo
if @Operation = 'D' --delete from FinancialNumbers only if "delete" invoked from research dashboard and not report resubmits
begin
  delete from PublicationFinancialNumbers where PubNo = @PubNo
  delete from PublicationFinancials       where PubNo = @PubNo
  delete from FinancialNumbers            where PubNo = @PubNo
  --update model status to deleted if this publication promoted any models to live
  if EXISTS(select * from Models where PubNo = @PubNo)
  begin
    insert into ModelDeletions(ModelId,EditorId,EditDate)
    select ModelId, 0, getdate() from Models
    where PubNO = @PubNo
    and StateId = 1

    update Models set StateId = 3 where PubNo = @PubNo AND StateId = 1
  end

  --Call to populate row into elastic index queue
  declare @UserName varchar(50)
  select @UserName = UserName from Users where UserId = @EditorId
  exec spIndexResearch @PubNo, 'D', @UserName
end

-- RVdeletedDocuments replicated view uses the logs below for pdf cache control on BR.com
insert into AuditLog (Operation, EditorId, EditDate) VALUES (@Operation, @EditorId, GETDATE())
select @AuditNo = @@IDENTITY

insert into PublicationsLog (AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate)
select @AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate from Publications where PubNo = @PubNo

insert into DocumentsLog (AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig)
select @AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig from Documents where PubNo = @PubNo

insert into PropertiesLog (AuditNo, PubNo, PropNo, PropId, PropValue)
select @AuditNo, PubNo, PropNo, PropId, PropValue from Properties where PubNo = @PubNo

delete from Properties   where PubNo = @PubNo
delete from Documents    where PubNo = @PubNo
delete from Publications where PubNo = @PubNo

select @Numdeleted = @@ROWCOUNT -- return OUTPUT PARAMETERS

go

if exists (select * from sys.objects where object_id = OBJECT_ID(N'[dbo].[spGetSearchResults]'))
drop proc [dbo].[spGetSearchResults]
go

create proc [dbo].[spGetSearchResults] @Size int, @PubNo varchar(max) = null
 as
  set nocount on
  --create temp table
  create table #tmpPubs
  (
    PubNo int
  )

  --Populate PubNo data into temp table
  set rowcount @Size
  if @PubNo is null
  begin

    insert into #tmpPubs
    select P.PubNo
    from Publications P
    order by P.Date desc, P.PubNo desc
  end
  else
  begin

    insert into #tmpPubs
    exec('select P.PubNo
    from Publications P
    where P.PubNo in (' + @PubNo + ')')
  end
  set rowcount 0

  --Output rowset (initial columns from Publications table)
  --author, industry, ticker, investorTheme & keyword are json columns
   select V.PubNo as pubId, V.PubNo Id, V.Date as reportDate, V.Title as title, V.Type as type, PT.PublicationTypeId as typeId, V.SubType as subType, V.Version as version, V.FileName as fileName, V.FileSize as fileSize, V.PageCount as pageCount,

    (
     select A.AuthorId as id, A.Name as name, A.Last as last,
     case
       when A.IsActive = -1 then 'true'
       else 'false'
     end as isActive,
     case
       when A.IsAnalyst = -1 then 'true'
       else 'false'
     end as isAnalyst
     from Publications P
     join Properties Pr on P.PubNo = Pr.PubNo
     join Authors A on Pr.PropValue = A.Name
     where P.PubNo = V.PubNo and Pr.PropId = 5 and A.IsAnalyst = -1
     order by Pr.PropNo
     for json path
    ) AS [author],

    (
     select I.IndustryId as id, I.IndustryName as name
     from Publications P
     join Properties Pr on P.PubNo = Pr.PubNo
     join Industries I on Pr.PropValue = I.IndustryName
     where P.PubNo = V.PubNo and Pr.PropId = 11
     order by Pr.PropNo
     for json path
    ) AS [industry],

    (
     select S.SecurityId as id, Pr.PropValue as name, PF.RatingAction as ratingAction, PF.CoverageAction as coverageAction, PF.TargetPriceAction as targetPriceAction, PF.EpsFY1Action as estimateAction
     From Publications P
     join Properties Pr on P.PubNo = Pr.PubNo
     join Securities2 S on Pr.PropValue = S.Ticker
     join PublicationFinancials PF on P.PubNo = PF.PubNo and S.SecurityId = PF.SecurityId
     where P.PubNo = V.PubNo and Pr.PropId = 13 and S.TickerType = 'STOCK'
     order by Pr.PropNo
     for json path
    ) AS ticker,

    (
     select I.InvestorThemeId as id, I.InvestorTheme as name
     From Publications P
     join Properties Pr on P.PubNo = Pr.PubNo
     join InvestorThemes I on Pr.PropValue = I.InvestorTheme
     where P.PubNo = V.PubNo and Pr.PropId = 32 and Pr.PropValue <> ''
     order by Pr.PropNo
     for json path
    ) AS investorTheme,

    (
     select K.KeywordId as id, K.Keyword as name
     From Publications P
     join Properties Pr on P.PubNo = Pr.PubNo
     join Keywords K on Pr.PropValue = K.Keyword
     where P.PubNo = V.PubNo and Pr.PropId = 9 and Pr.PropValue <> ''
     order by Pr.PropNo
     for json path
    ) AS keyword,

    TT.ThematicTagId as thematicTagId,
    TT.ThematicTag as thematicTag
    from Publications V
      join #tmpPubs T on V.PubNo = T.PubNo
      left outer join (select * from Properties where PropId = 41 and PropValue <> '') Pr on V.PubNo = Pr.PubNo
      left outer join PublicationTypes PT on V.Type = PT.PublicationType
      left outer join ThematicTags TT on Pr.PropValue = TT.ThematicTag
    order by V.Date desc, V.PubNo desc
    for
    json path
go

grant execute on dbo.spIndexResearch          to DE_IIS, PowerUsers
grant execute on dbo.spUpdateElasticQueueItem to DE_IIS, PowerUsers
grant execute on dbo.spGetResearchMetadata    to DE_IIS, PowerUsers
grant execute on dbo.spGetSearchResults       to DE_IIS, PowerUsers
grant execute on dbo.spSearchAutocomplete     to DE_IIS, PowerUsers
grant execute on dbo.spGetScheduledElasticQueueItems to DE_IIS, PowerUsers
go

/*

DEBUG

select * from ElasticQueue

spIndexResearch 146617,'I','syu'

spGetResearchMetadata 146627

select * from Properties where PubNo = 134910

spGetDocumentsForElasticIndex 10000
spGetDocumentMetadataForElasticIndex 140247,'Research Call'
spGetDocumentActionTagsForElasticIndex 140247
spGetSearchResults 1000
spGetSearchResults 1,146628
spSearchData 'aa'

*/
