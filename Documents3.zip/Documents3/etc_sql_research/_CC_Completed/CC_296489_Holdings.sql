-- Holdings.sql
-- 09/25/2018

/*

create Holdings
create vHoldings
create spDeleteHoldings

*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Holdings]') AND type in (N'U'))
	DROP TABLE [dbo].[Holdings]
GO

CREATE TABLE [dbo].[Holdings](
	[EmployeeID]        [nvarchar](50)  NULL,
	[EmployeeUserName]  [nvarchar](max) NULL,
	[EmployeeLastName]  [nvarchar](max) NULL,
	[EmployeeFirstName] [nvarchar](max) NULL,
	[Description]       [nvarchar](max) NULL,
	[Cusip]             [nvarchar](50)  NULL,
	[BloombergTicker]   [nvarchar](50)  NULL,
	[ISIN]              [nvarchar](50)  NULL,
	[SEDOL]             [nvarchar](50)  NULL,
	[SecurityType]      [nvarchar](max) NULL,
	[HoldingQuantity]   [nvarchar](50)  NULL,
	[UserAccountStatus] [nvarchar](50)  NULL,
	[LastExecution]     [nvarchar](max) NULL,
	[ReportRunDate]     [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE name = 'vHoldings' AND type = 'V')
	DROP VIEW  [dbo].[vHoldings]
GO

CREATE VIEW [dbo].[vHoldings]
as
select distinct
  A.Last + ', ' + A.First as Author
 ,S.Ticker
 ,S.Company
 ,A.Name + ' maintains a long position in ' + S.Company + ' (' + S.Ticker + ')' as [Text]
 ,A.AuthorId
 ,S.SecurityId
 ,'' as LoadDate -- EffectiveDate
 ,H.EmployeeID
 ,H.EmployeeUserName
 ,H.EmployeeLastName
 ,H.EmployeeFirstName
 ,H.Description
 ,H.Cusip
 ,H.BloombergTicker
 ,H.ISIN
 ,H.SEDOL
 ,H.SecurityType
 ,H.HoldingQuantity
 ,H.UserAccountStatus
 ,H.LastExecution
 ,H.ReportRunDate
from Holdings H
inner join Authors A on ltrim(rtrim(A.WindowsUserName)) = 'ac\' + ltrim(rtrim(H.EmployeeUserName))
inner join ResearchCoverage as RC on RC.DropDate is null
inner join Securities2 as S on RC.SecurityId = S.SecurityId and ltrim(rtrim(S.ISIN)) = ltrim(rtrim(H.ISIN))
where H.EmployeeUserName is not null and ltrim(rtrim(H.EmployeeUserName)) <> ''
and H.ISIN is not null and ltrim(rtrim(H.ISIN)) <> ''
go

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spDeleteHoldings]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spDeleteHoldings] 
GO

-- =================================================================================================
-- Author:       Anup Singh
-- Revisions:    10/08/2018 - Created
-- Description:  It will fetch config details of File Procesing i.e. SourceFilePath, BackupFilePath, ProjectName
-- =================================================================================================
CREATE PROC [dbo].[spDeleteHoldings]
AS
BEGIN
  delete from Holdings
END
GO

GRANT EXECUTE ON dbo.[spDeleteHoldings] TO DE_IIS,PowerUsers
GO

GRANT INSERT, DELETE, UPDATE ON [dbo].[Holdings]   TO  DE_IIS
GO

-- DEBUG

/*
SELECT * FROM Holdings
SELECT * FROM vHoldings
*/