-- spSavePublicationFinancials.sql
-- 08/31/2017

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

alter procedure [dbo].[spSavePublicationFinancials]
  @PubNo int,
  @TickerTableXml xml,
  @EditorId int
as
begin
  set nocount on
  declare @hDoc           int,
          @DisplayNo      int,
          @MaxDisplayNo   int,
          @Ticker         varchar(30),
          @TickerPrev     varchar(30),
          @SecurityId     varchar(30),
          @SecurityIdPrev varchar(30),
          @Rating         varchar(30),
          @RatingOld      varchar(30),
          @TargetPrice    varchar(30),
          @TargetPriceOld varchar(30),
          @EPSType        varchar(30),
          @EPSCurrency    varchar(30),
          @EPSFY0         varchar(30),
          @EPSFY1         varchar(30),
          @EPSFY1Old      varchar(30),
          @EPSFY2         varchar(30),
          @EPSFY2Old      varchar(30),
          @CloseDate      varchar(30),
          @ClosePrice     varchar(30),
          @TradeCurrency  varchar(30),
          @PerfType       varchar(30),
          @Perf           varchar(30),
          @BaseYear       varchar(30),
          @DivYield       varchar(30),
          @PubDate        datetime,
          @CurrentDate    datetime,
          @Counter        int,
          @CoverageId     int,
          @CoverageAction varchar(30),
          @RatingAction   varchar(30),
          @RatingValue    int,
          @RatingValueOld int,
          @TargetPriceAction varchar(30),
          @EpsFY1Action varchar(30),
          @EpsFY2Action varchar(30)

  select @CurrentDate = GETDATE()

  delete from PublicationFinancials where Pubno = @PubNo
  select @PubDate = Date from Publications where PubNo = @PubNo
    
  exec sp_xml_preparedocument @hDoc output, @TickerTableXml

  --Parse tickers with metadata from tickertable xml
  select ROW_NUMBER() over (ORDER BY (select 1)) AS DisplayNo, SecurityId, Ticker, CloseDate, ClosePrice, TradeCurrency, Rating, TargetPrice, EPSType, EPSCurrency, EPSFY0, EPSFY1, EPSFY2, PerfType, Perf,BaseYear, DivYld
  into #TmpTickers
  from openxml (@hDoc, 'TickerTable/TickerTableBody/TickerTableBodyRow', 1)
  with (securityId     int         '@securityId',
        ticker         varchar(30) '@ticker',
        closeDate      varchar(30) '@closeDate',
        closePrice     varchar(30) '@closePrice',
        tradeCurrency  varchar(30) '@tradeCurrency',
        rating         varchar(30) '@rating',
        targetPrice    varchar(30) '@targetPrice',
        epsType        varchar(30) '@epsType',
        epsCurrency    varchar(30) '@epsCurrency',
        epsFY0         varchar(30) '@epsFY0',
        epsFY1         varchar(30) '@epsFY1',
        epsFY2         varchar(30) '@epsFY2',
        divYld         varchar(30) '@divYld',
        perfType       varchar(30) '@perfType',
        perf           varchar(30) '@perf',
        baseYear       varchar(30) '@baseYear'
       ) X
  --Retrieve first ticker in the list
  select top 1 @DisplayNo = DisplayNo, @SecurityId = SecurityId, @Ticker = Ticker, @CloseDate = CloseDate, @ClosePrice = ClosePrice, @TradeCurrency = TradeCurrency, @BaseYear = BaseYear, @Rating = Rating, @RatingOld = null, @TargetPrice = TargetPrice, @TargetPriceOld = null, @EPSType = EpsType, @EpsCurrency = EpsCurrency, @EPSFY0 = EPSFY0, @EPSFY1 = EPSFY1, @EPSFY1Old = null, @EPSFY2 = EPSFY2, @EPSFY2Old = null
  from #TmpTickers order by DisplayNo

  select @Counter = 1, @MaxDisplayNo = max(DisplayNo) from #TmpTickers where Ticker <> 'OLD'

  --begin loop
  while @Counter <= @MaxDisplayNo
  begin
    --Insert ticker row into PublicationFinancials table
    insert into PublicationFinancials(PubNo, SecurityId, Ticker, CloseDate, ClosePrice, PriceCurrency, BaseYear, Rating, TargetPrice, EpsType, EpsCurrency, EpsFY0, EpsFY1, EpsFY2, EditorId, EditDate)
    select @PubNo, @SecurityId, @Ticker, @CloseDate, @ClosePrice, @TradeCurrency, @BaseYear, @Rating, dbo.fnStripCharacters(@TargetPrice, '^-.0-9'), @EPSType, @EPSCurrency, dbo.fnStripCharacters(@EPSFY0, '^-.0-9'), dbo.fnStripCharacters(@EPSFY1, '^-.0-9'), dbo.fnStripCharacters(@EPSFY2, '^-.0-9'), @EditorId, @CurrentDate

-- RIXML action enumerators and values
-- Coverage Action:            Initiate, Drop, Suspend, Resume
-- Rating Action:              Upgrade, Downgrade, Reiterate, Initiate, Drop
-- Target Price Action:        Increase, Decrease, update
-- Estimate Action:            Upgrade, Downgrade, Reiterate
-- Estimate Next Year Action:  Upgrade, Downgrade, Reiterate

-- Rules for assigning action values
-- * Assign 1 value for each of the actions per Call per ticker
-- * A value that indicates a change should only be applied to the first Call/day/ticker that establishes change
--   e.g. multiple Calls per day per ticker cannnot indicate change

-- Auto-administer launch date only if coverage can be uniquely identified,
-- i.e. expect one analyst (active) to drop and another (awaiting) to launch on same ticker (both have no drop date)
	if (select count(*) from ResearchCoverage where SecurityId = @SecurityId and DropDate is null) = 1
	begin
	  if exists (select * from ResearchCoverage where SecurityId = @SecurityId and isnull(LaunchDate,0) = 0 and isnull(DropDate,0) = 0)
		begin
		  update ResearchCoverage set LaunchDate = @PubDate, EditorId = 0, Editdate = getdate() where SecurityId = @SecurityId and DropDate is null
		  -- update Industry, Analyst and Security tables to reflect active coverage status (iPad)
		  update Industries set Status = 1,EditDate = getdate() from Industries I JOIN ResearchCoverage RC on I.IndustryId = RC.IndustryId where SecurityId = @SecurityId and DropDate is null
		  update Authors set Status = 1,EditDate = getdate() from Authors A JOIN ResearchCoverage RC on A.AuthorId = RC.AnalystId where SecurityId = @SecurityId and DropDate is null
		  update Securities2 set Status = 1,EditDate = getdate() from Securities2 S where SecurityId = @SecurityId
		end
	end
    
    -- set default coverage/rating/targetprice/epsfy1action/epsfy2 action tags
    if (select TickerType from Securities2 where Ticker = @Ticker) = 'STOCK'
    begin
      select @CoverageAction = null, @RatingAction = 'Reiterate', @TargetPriceAction = 'Update', @EpsFY1Action = 'Reiterate', @EpsFY2Action = 'Reiterate' 
    end
    else
    begin
      select @CoverageAction = null, @RatingAction = null, @TargetPriceAction = null, @EpsFY1Action = null, @EpsFY2Action = null 
    end

    -- Record the CoverageId based on coverage at time of publication date
    set @CoverageId =
      (select max(CoverageId) from ResearchCoverage
      where SecurityId = @SecurityId and @PubDate between LaunchDate and isnull(DropDate, dateadd(d,100,getdate())))
      update PublicationFinancials set CoverageId = @CoverageId where PubNo = @PubNo and Ticker = @Ticker

    -- CoverageAction: Initiate, Resume (Note, Drop, Suspend are handled in spSaveCoverage)
    -- RatingAction: Initiate (Note, Drop is handled in spSaveCoverage)
    -- Detect launch Call (either first submit or re-submit)
    if (select min(PubNo) from PublicationFinancials where CoverageId = @CoverageId) = @PubNo
    begin
      if (select upper(LaunchInd) from ResearchCoverage where CoverageId = @CoverageId) = 'I'
        select @CoverageAction = 'Initiate', @RatingAction = 'Initiate' 
        --update PublicationFinancials set CoverageAction = 'Initiate', RatingAction = 'Initiate' where Ticker = @Ticker and PubNo = @PubNo
      else
        select @CoverageAction = 'Resume', @RatingAction = 'Initiate' 
        --update PublicationFinancials set CoverageAction = 'Resume', RatingAction = 'Initiate' where Ticker = @Ticker and PubNo = @PubNo
    end

    select @SecurityIdPrev = @SecurityId, @TickerPrev = @Ticker

    --Check to see if next ticker is 'OLD' 
    select top 1 @DisplayNo = DisplayNo, @SecurityId = SecurityId, @Ticker = Ticker
    from #TmpTickers where DisplayNo > @DisplayNo
    order by DisplayNo

    --if the next row is for tiker='OLD" then it's a change row.
    if (@Ticker = 'OLD' and @SecurityId = @SecurityIdPrev)
    begin

      --Retrieve the old row values
      select top 1 @DisplayNo = DisplayNo, @SecurityId = SecurityId, @Ticker = Ticker, @RatingOld = Rating, @TargetPriceOld = TargetPrice, @EPSFY1Old = EPSFY1, @EPSFY2Old = EPSFY2
      from #TmpTickers where DisplayNo = @DisplayNo

      -- RatingAction: Upgrade, Downgrade, Reiterate
      --if @RatingOld is not null check for Upgrade/Downgrade
      if (@RatingOld is not null and @RatingOld <> '')
      begin
        -- Only one publication per ticker per day can record rating change
        if not exists(select PF.* from PublicationFinancials PF
            JOIN Publications P on PF.PubNo = P.PubNo and Ticker = @TickerPrev and Date = @PubDate
            where RatingAction in ('Upgrade','Downgrade'))
          begin
            -- Conditionally over-ride the default rating action if change detected
            -- Use the Ratings integer value for relative evaluation
            set @RatingValue    = (select RatingValue from dbo.Ratings where Rating = @Rating)
            set @RatingValueOld = (select RatingValue from dbo.Ratings where Rating = @RatingOld)
            select @RatingAction =
              case
                when @RatingValue > @RatingValueOld then 'Upgrade'
                when @RatingValue < @RatingValueOld then 'Downgrade'
              end
          end
      end
      -- TargetPriceAction: Increase, Decrease & update
      --if @TargetPriceOld is not null check for Increase/Decrease
      if (@TargetPriceOld is not null and @TargetPriceOld <> '')
      begin
        if isnumeric(@TargetPrice)    = 0 set @TargetPrice    = -1.0 -- Alias non-numeric value, e.g. NM or NA, with numeric value
        if isnumeric(@TargetPriceOld) = 0 set @TargetPriceOld = -1.0
        -- Only one publication per ticker per day can record target price change
        if not exists(select PF.* from PublicationFinancials PF
            JOIN Publications P on PF.PubNo = P.PubNo and Ticker = @TickerPrev and Date = @PubDate
            where TargetPriceAction in ('Increase','Decrease'))
          begin
            -- Conditionally over-ride the default target price action if change detected
            select @TargetPriceAction =
              case
                when convert(float, @TargetPrice) > convert(float, @TargetPriceOld) then 'Increase'
                when convert(float, @TargetPrice) < convert(float, @TargetPriceOld) then 'Decrease'
              end
          end
       end

      --EpsFY1Action: Upgrade, Downgrade and Reiterate
      --if @EPSFY1Old is not null check for Upgrade/Downgrade
      if (@EPSFY1Old is not null and @EPSFY1Old <> '')
      begin
        if isnumeric(@EPSFY1)    = 0 set @EPSFY1    = -1.0 -- Alias non-numeric value, e.g. NM or NA, with numeric value
        if isnumeric(@EPSFY1Old) = 0 set @EPSFY1Old = -1.0
        -- Only one publication per ticker per day can record estimate change
        if not exists(select PF.* from PublicationFinancials PF
            JOIN Publications P on PF.PubNo = P.PubNo and Ticker = @TickerPrev and Date = @PubDate
            where EpsFY1Action in ('Upgrade','Downgrade'))
          begin
            -- Conditionally over-ride the default EpsFY1Action if change detected
            select @EpsFY1Action =
              case
                when convert(float, @EPSFY1) > convert(float, @EPSFY1Old) then 'Upgrade'
                when convert(float, @EPSFY1) < convert(float, @EPSFY1Old) then 'Downgrade'
              end
          end
      end

      --EpsFY2Action: Upgrade, Downgrade and Reiterate
      --if @EPSFY2Old is not null check for Upgrade/Downgrade
      if (@EPSFY2Old is not null and @EPSFY2Old <> '')
      begin
        if isnumeric(@EPSFY2)    = 0 set @EPSFY2    = -1.0 -- Alias non-numeric value, e.g. NM or NA, with numeric value
        if isnumeric(@EPSFY2Old) = 0 set @EPSFY2Old = -1.0
        -- Only one publication per ticker per day can record estimate change
        if not exists(select PF.* from PublicationFinancials PF
            JOIN Publications P on PF.PubNo = P.PubNo and Ticker = @TickerPrev and Date = @PubDate
            where EpsFY2Action in ('Upgrade','Downgrade'))
          begin
            -- Conditionally over-ride the default EPSFY2Action if change detected
            select @EpsFY2Action =
              case
                when convert(float, @EPSFY2) > convert(float, @EPSFY2Old) then 'Upgrade'
                when convert(float, @EPSFY2) < convert(float, @EPSFY2Old) then 'Downgrade'
              end
          end
      end

      select top 1 @DisplayNo = DisplayNo, @SecurityId = SecurityId, @Ticker = Ticker, @CloseDate = CloseDate, @ClosePrice = ClosePrice, @TradeCurrency = TradeCurrency, @Rating = Rating, @TargetPrice = TargetPrice, @EPSType = EpsType, @EpsCurrency = EpsCurrency, @EPSFY0 = EPSFY0, @EPSFY1 = EPSFY1, @EPSFY2 = EPSFY2
      from #TmpTickers where DisplayNo > @DisplayNo
      order by DisplayNo

      set @Counter = @Counter + 1
    end

    -- Record the rating action
    update PublicationFinancials set CoverageAction = @CoverageAction, RatingAction = @RatingAction, TargetPriceAction = @TargetPriceAction, EpsFY1Action = @EpsFY1Action, EpsFY2Action = @EpsFY2Action, RatingPrior = @RatingOld, TargetPricePrior = @TargetPriceOld, EpsFY1Prior = @EPSFY1Old, EpsFY2Prior = @EPSFY2Old
    where Ticker = @TickerPrev and PubNo = @PubNo 

    --Get next row
    select top 1 @DisplayNo = DisplayNo, @SecurityId = SecurityId, @Ticker = Ticker, @CloseDate = CloseDate, @ClosePrice = ClosePrice, @TradeCurrency = TradeCurrency, @BaseYear = BaseYear, @Rating = Rating, @RatingOld = null, @TargetPrice = TargetPrice, @TargetpriceOld = null, @EPSType = EpsType, @EpsCurrency = EpsCurrency, @EPSFY0 = EPSFY0, @EPSFY1 = EPSFY1, @EPSFY1Old = null, @EPSFY2 = EPSFY2, @EPSFY2Old = null
    from #TmpTickers where DisplayNo = @DisplayNo
    order by DisplayNo

    select @Counter = @Counter + 1
  end

end
go

