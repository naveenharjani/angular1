-- CC_spDeletePublication.sql
-- 03/02/2018

/*
alter spDeletePublication
*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER procedure [dbo].[spDeletePublication]
  @PubNo         int,
  @Operation     char(1),
  @EditorId      int,
  @Numdeleted    int OUTPUT
AS
declare @AuditNo int

-- PREVENT PHANTOM deleteS (from STALE BROWSER) BY ONLY PROCESSING FIRST delete REQUEST
if NOT EXISTS(select * from Publications where PubNo = @PubNo)
  begin
    select @Numdeleted = 0 -- return OUTPUT PARAMETERS
    return
  end

-- return ROWset
select FileName from Documents where PubNo = @PubNo

delete from ProductGroupDocuments       where PubNo = @PubNo
delete from RelatedPublications         where PubNo = @PubNo
if @Operation = 'D' --delete from FinancialNumbers only if "delete" invoked from research dashboard and not report resubmits
begin
  delete from PublicationFinancialNumbers where PubNo = @PubNo
  delete from PublicationFinancials       where PubNo = @PubNo
  delete from FinancialNumbers            where PubNo = @PubNo
  --update model status to deleted if this publication promoted any models to live
  if EXISTS(select * from Models where PubNo = @PubNo)
  begin
    insert into ModelDeletions(ModelId,EditorId,EditDate) 
    select ModelId, 0, getdate() from Models
    where PubNO = @PubNo
    and StateId = 1

    update Models set StateId = 3 where PubNo = @PubNo AND StateId = 1
  end
end

-- RVdeletedDocuments replicated view uses the logs below for pdf cache control on BR.com
insert into AuditLog (Operation, EditorId, EditDate) VALUES (@Operation, @EditorId, GETDATE())
select @AuditNo = @@IDENTITY

insert into PublicationsLog (AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate)
select @AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate from Publications where PubNo = @PubNo

insert into DocumentsLog (AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig)
select @AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig from Documents where PubNo = @PubNo

insert into PropertiesLog (AuditNo, PubNo, PropNo, PropId, PropValue)
select @AuditNo, PubNo, PropNo, PropId, PropValue from Properties where PubNo = @PubNo

delete from Properties   where PubNo = @PubNo
delete from Documents    where PubNo = @PubNo
delete from Publications where PubNo = @PubNo

select @Numdeleted = @@ROWCOUNT -- return OUTPUT PARAMETERS

