-- CC_spSearchAutoComplete.sql
--06/28/2019

/*
create spSearchAutocomplete            - Altered to add authorid, securityid in the output rowset. Filter drop coverage items.
*/

use Research
go

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
go

if exists (select * from sys.objects where object_id = OBJECT_ID(N'[dbo].[spSearchAutoComplete]'))
drop proc [dbo].[spSearchAutoComplete]
go

--=================================================================================================
 --Author:      Sandarsh M S
 --Revisions:
 --08/04/2016 - Created
 --08/29/2017 - Added filter to remove unlaunched tickers which were not covered previously.
 --10/25/2017 - Added search in Models feature
 --11/20/2017 - Change Display Priority based on Ticker Symbol Starts With
 --02/14/2018 - Removed extra params
 --02/22/2018 - Redesign
 --07/02/2019 - Added SecurityId/AuthorId to the resultset (needed for br.com)

 --Description: Get Typeahead data for a given @SearchText
 --=================================================================================================
create procedure dbo.[spSearchAutoComplete]
  @SearchText nvarchar(200)
as
begin

declare @SearchTextComp nvarchar(200)

set @SearchTextComp = @SearchText + '%'
set @SearchText = '%' + @SearchText + '%'

declare @FirstTicker nvarchar(10)
declare @Match nvarchar(10)
declare @MatchOrd int

--Temp table to hold output rowset
declare @SearchData table
(
  Display    varchar(100) NULL,
  Value      varchar(50) NULL,
  Id         int,
  Section    varchar(20) NULL,
  SectionOrd int,
  Match      varchar(20) NULL,
  MatchOrd   int,
  Content    varchar(20) NULL,
  ContentOrd int,
  ActiveFlag bit NULL,
  HeadOrd    int
)

--List of top 10 authors(active/inactive) whose last name or first name matches(contains) with search text 
insert into @SearchData
select Display, Value, AuthorId,
  'Analyst' as Section, 2 as SectionOrd,
  'Contains' as Match, 2 as MatchOrd,
  'Research' as Content, 1 as ContentOrd,
  max(ActiveFlag) ActiveFlag,
  Row_Number() OVER (ORDER BY Display) + 1 as HeadOrd
from
(select distinct top 10
  Last + ', ' + First as Display,
  Name as Value, A.AuthorId,
  case when RC.DropDate is null then 1 else 0 end ActiveFlag
from Authors A join ResearchCoverage RC on A.AuthorId = RC.AnalystId
where RC.LaunchDate is not null
and (First like @SearchText or Last like @SearchText)
order by Last +', '+ First) a
group by Display, Value, AuthorId

--List of top (15 - author match count) tickers(active/inactive)  whose ticker symbol matches(starts with) with search text 
insert into @SearchData
select Display, Value, SecurityId,
  'Securities' as Section, 1 as SectionOrd,
  'Starts' as Match, 1 as MatchOrd,
  'Research' as Content,1 as ContentOrd,
  max(ActiveFlag) ActiveFlag,
  Row_Number() OVER (ORDER BY Display) + 1 as HeadOrd
from
(select distinct top (15 - (select count(*) from @SearchData))
  Ticker + ' / ' + Company as Display,
  Ticker as Value, S.SecurityId,
  case when RC.DropDate is null then 1 else 0 end ActiveFlag
from Securities2 S
join ResearchCoverage RC on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null
and (Ticker like @SearchTextComp)
order by Ticker + ' / ' + Company) a
group by Display, Value, SecurityId

--List of top (24-ticker match count - author match count) companies(active/inactive) whose company name matches(contains) with search text 
insert into @SearchData
select Display, Value, SecurityId,
  'Securities' as Section, 1 as SectionOrd,
  'Contains' as Match, 2 as MatchOrd,
  'Research' as Content, 1 as ContentOrd,
  max(ActiveFlag) ActiveFlag,
  (select count(*) from @SearchData where SectionOrd=1) + Row_Number() OVER (ORDER BY Display) + 1 as HeadOrd
from
(select distinct top (24 - (select count(*) from @SearchData))
  Ticker + ' / ' + Company  as Display,
  Ticker as Value, S.SecurityId,
  case when DropDate is null then 1 else 0 end ActiveFlag
from Securities2 S
join ResearchCoverage RC on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null
and Ticker not in (select distinct Value from @SearchData)
and (Ticker like @SearchText or Company like @SearchText)
order by Ticker + ' / ' + Company) a
group by Display, Value, SecurityId


-- Get the first/top ticker in the securities section
select top 1 @FirstTicker = value,@Match=Match,@MatchOrd=MatchOrd from @SearchData
where Section='Securities' order by SectionOrd, MatchOrd, ContentOrd, Display

-- For the first/top ticker in the Securities section optionally display content for ticker "in Financials" when exists
insert into @SearchData
select
  Ticker + ' / ' + Company  as Display,
  Ticker as Value, S.SecurityId,
  'Securities' as Section, 1 as SectionOrd,
  @Match as Match,@MatchOrd as MatchOrd,
  'Financials' as Content, 2 as ContentOrd,
  1 AS ActiveFlag,
  1 as HeadOrd
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null
and s.Ticker = @FirstTicker

-- For the first/top ticker in the Securities section optionally display content for ticker "in Models" when exists
insert into @SearchData
select
  Ticker + ' / ' + Company  as Display,
  Ticker as Value,
  S.SecurityId,
  'Securities' as Section, 1 as SectionOrd,
  @Match as Match, @MatchOrd as MatchOrd,
  'Models' as Content, 3 as ContentOrd,
  1 AS ActiveFlag,
  1 as HeadOrd
from ResearchCoverage RC
join Securities2 S on RC.SecurityId = S.SecurityId
join Models M on S.SecurityId = M.SecurityId
join ModelStates MS on M.StateId = MS.StateId
where RC.LaunchDate is not null and RC.DropDate is null
and S.Ticker = @FirstTicker
and MS.State = 'Active'


--return output rowset (active authors and tickers only)
select * from @SearchData where ActiveFlag = 1 order by SectionOrd, MatchOrd, Display, ContentOrd

end

go

grant execute on spSearchAutoComplete to DE_IIS, PowerUsers
go
