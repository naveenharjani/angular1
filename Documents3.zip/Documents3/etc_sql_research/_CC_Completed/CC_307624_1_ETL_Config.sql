-- 04/02/2019
-- ETL_Config.sql

/*

alter FileProcessingConfig   - add EditorId, EditDate
alter FileLoadInstructions   - add EditorId, EditDate
alter PortalClientEmbargo    - add ContactId
alter FileProcessingLog      - add Type
create RVPortalUsage         - add 2 columns ContentType, SubSite
create RVPortalSubSites      - new view
create RVPortalClientEmbargo - new view

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'EditorId' AND Object_ID = Object_ID(N'FileProcessingConfig'))
  ALTER TABLE FileProcessingConfig DROP COLUMN EditorId
GO
IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'EditDate' AND Object_ID = Object_ID(N'FileProcessingConfig'))
  ALTER TABLE FileProcessingConfig DROP COLUMN EditDate
GO
ALTER TABLE FileProcessingConfig ADD EditorId INT, EditDate DATETIME
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'EditorId' AND Object_ID = Object_ID(N'FileLoadInstructions'))
  ALTER TABLE FileLoadInstructions DROP COLUMN EditorId
GO
IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'EditDate' AND Object_ID = Object_ID(N'FileLoadInstructions'))
  ALTER TABLE FileLoadInstructions DROP COLUMN EditDate
GO
ALTER TABLE FileLoadInstructions ADD EditorId INT, EditDate DATETIME
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'ContactId' AND Object_ID = Object_ID(N'PortalClientEmbargo'))
  ALTER TABLE PortalClientEmbargo DROP COLUMN ContactId
GO
ALTER TABLE PortalClientEmbargo ADD ContactId VARCHAR(50)
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'Status' AND Object_ID = Object_ID(N'FileProcessingLog'))
  ALTER TABLE FileProcessingLog DROP COLUMN [Status]
GO
ALTER TABLE FileProcessingLog ADD [Status] CHAR(1)  -- I, E
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVPortalUsage]'))
DROP VIEW [dbo].[RVPortalUsage]
GO

CREATE VIEW [dbo].[RVPortalUsage] WITH SCHEMABINDING AS
SELECT
  UsageId,
  ContentId AS PubNo,
  ContentType,
  ReadDate,
  PU.SiteId,
  Site,
  PU.SubSite,
  Email,
  Contact,
  ContactId,
  Account,
  AccountId,
  '' AS FirmType,
  '' AS Delivery
FROM
  dbo.PortalUsage PU
  JOIN dbo.DistributionSites DS ON PU.SiteId = DS.SiteId
WHERE
  ExclusionId IS NULL AND
  ContentType = 'R'

GO

CREATE UNIQUE CLUSTERED INDEX [RVPortalUsage_UsageId] ON [dbo].[RVPortalUsage]([UsageId] ASC)
GO


IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVPortalSubSites]'))
DROP VIEW [dbo].[RVPortalSubSites]
GO

CREATE VIEW [dbo].[RVPortalSubSites] WITH SCHEMABINDING AS
SELECT
  PortalSubSiteId,
  SiteId,
  SubSite,
  Alias
FROM
  dbo.PortalSubSites
GO

CREATE UNIQUE CLUSTERED INDEX [RVPortalSubSites_PortalSubSiteId] ON [dbo].[RVPortalSubSites] ([PortalSubSiteId] ASC)
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVPortalClientEmbargo]'))
DROP VIEW [dbo].[RVPortalClientEmbargo]
GO

CREATE VIEW [dbo].[RVPortalClientEmbargo] WITH SCHEMABINDING AS
SELECT
  ClientEmbargoId,
  DataStore,
  Account,
  AccountId,
  NumDaysEmbargo,
  ContactId
FROM
  dbo.PortalClientEmbargo
GO

CREATE UNIQUE CLUSTERED INDEX [RVPortalUsage_ClientEmbargoId] ON [dbo].[RVPortalClientEmbargo] ([ClientEmbargoId] ASC)
GO

-- DEBUG
/*
SELECT * FROM FileProcessingConfig ORDER BY ConfigId asc
SELECT * FROM FileLoadInstructions ORDER BY FileLoadInstructionId asc
SELECT * FROM PortalClientEmbargo
SELECT TOP 100 * FROM FileProcessingLog ORDER BY LoadDate desc

SELECT * FROM RVPortalClientEmbargo
SELECT * FROM RVPortalUsage
SELECT * FROM RVPortalSubSites
*/