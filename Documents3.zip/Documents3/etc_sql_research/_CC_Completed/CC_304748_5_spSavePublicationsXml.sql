--03/15/2019
/*
spSavePublicationsXml - Updated to parse Autonomous tickers from properties xml
*/
USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSavePublicationsXml]
  @PropertiesXml xml,
  @CompanyFinancialsXml xml,
  @TickerTableXml xml,
  @HighlightsXml xml,
  @EditorId int = 0
AS
BEGIN TRY
  BEGIN TRANSACTION

  DECLARE
  @Date         DATETIME,
  @Type         VARCHAR(30),
  @SubType      VARCHAR(30),
  @Title        VARCHAR(300),
  @PubNo        INT,
  @Version      INT,
  @hDoc         INT,
  @hDoc2        INT,
  @hDoc3        INT,
  @CurrentDate  DATETIME,
  @FileName     VARCHAR(63),
  @FileSize     BIGINT,
  @PageCount    INT,
  @Approver     VARCHAR(50),
  @ApprovedDate DATETIME,
  @AuditNo      INT

  SELECT @CurrentDate = getdate()

  EXEC sp_xml_preparedocument @hDoc OUTPUT, @PropertiesXml

    --Retrieve approver & approved date(UTC format) from document info node
  SELECT @Approver = U.ExchangeEmail, @ApprovedDate = ApprovedDate
  FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
  WITH (Approver  varchar(31)  '@approver',
        ApprovedDate datetime  '@approvedDate'
        ) X JOIN Users U on X.Approver = replace(replace(UserName, 'ac/',''),'ac\','')

  --convert approved date from UTC to EST(db server time zone)
  SET @ApprovedDate = dateadd(hh,datediff(hh,getutcdate(),getdate()),@ApprovedDate)

  --If no approver info, default to Cheryl
  IF (@Approver = '' or @Approver is null)
  BEGIN
    SELECT @Approver = ExchangeEmail, @ApprovedDate = @CurrentDate
    FROM Users
    WHERE
    replace(replace(UserName, 'ac/',''),'ac\','') = 'cdekre'
  END

  --Retrieve date,type,title from document info node
  SELECT @Date = X.Date, @Type = X.Type, @SubType = X.SubType, @Title = X.Title, @PubNo = X.PubNo, @Version = X.Version
  FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
  WITH (Date      datetime     '@pubDate',
        Type      varchar(31)  '@type',
        SubType   varchar(30)  '@subType',
        Title     varchar(255) '@title',
        PubNo     int          '@pubNo',
        Version   int          '@version'
        ) X

  SELECT @FileName = X.FileName, @FileSize =  X.FileSize, @PageCount = X.PageCount
  FROM OPENXML (@hDoc, 'DocumentInfo/Documents/Document', 1)
  WITH (DocType       varchar(4)  '@docType',
        FileName      varchar(30) '@fileName',
        FileSize      bigint      '@fileSize',
        PageCount     int         '@pageCount'
        ) X
  WHERE
    X.DocType = 'PDF'

  --Incase of resubmits delete the previous vesion
  IF @Version > 1
  BEGIN
    DELETE FROM ProductGroupDocuments       WHERE PubNo = @PubNo
    DELETE FROM RelatedPublications         WHERE PubNo = @PubNo

    INSERT INTO AuditLog (Operation, EditorId, EditDate) VALUES ('R', @EditorId, @CurrentDate)
    SELECT @AuditNo = @@IDENTITY

    INSERT INTO PublicationsLog (AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate)
    SELECT @AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate FROM Publications WHERE PubNo = @PubNo

    INSERT INTO DocumentsLog (AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig)
    SELECT @AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig FROM Documents WHERE PubNo = @PubNo

    INSERT INTO PropertiesLog (AuditNo, PubNo, PropNo, PropId, PropValue)
    SELECT @AuditNo, PubNo, PropNo, PropId, PropValue FROM Properties WHERE PubNo = @PubNo

    --Delete if exists in PublicationFinancialNumbers (for resubmit)
    DELETE FROM PublicationFinancialNumbers WHERE PubNo = @PubNo
    DELETE FROM PublicationFinancials       WHERE PubNo = @PubNo
    DELETE FROM Properties                  WHERE PubNo = @PubNo
    DELETE FROM Documents                   WHERE PubNo = @PubNo
    DELETE FROM Publications                WHERE PubNo = @PubNo
  END

  --insert into Publications table
  INSERT INTO Publications (PubNo, Date, Type, SubType, Title, FileName, FileSize, Approver, ApprovedDate, PublishedDate, Version, Instructions, PageCount, EditorId, EditDate)
  SELECT @PubNo, @Date, @Type, @SubType, @Title, @FileName, @FileSize,@Approver, @ApprovedDate, @CurrentDate, @Version, 4, @PageCount, 0, @CurrentDate

  INSERT INTO Documents (PubNo, DocNo, DocType, FileName, FileNameOrig)
  SELECT @PubNo, X.DocNo, X.DocType, X.FileName, X.FileNameOrig
  FROM OPENXML (@hDoc, 'DocumentInfo/Documents/Document', 1)
  WITH (DocNo         int         '@docNo',
        DocType       varchar(4)  '@docType',
        FileName      varchar(30) '@fileName',
        FileNameOrig  varchar(63) '@fileNameOrig'
        ) X


  --insert into properties table with report meta data
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, Value, Name
  INTO #TmpPropertyCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Properties/Property', 1)
  WITH (value           varchar(200) '@value',
        name            varchar(30)  '@name'
        )
  WHERE Name <> ''

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Value
  FROM #TmpPropertyCollection T JOIN PropertyNames PN ON PN.PropName = T.Name

  --Retrieve Authors
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, AuthorId, Name
  INTO #TmpAuthorCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Authors/Author', 1)
  WITH (authorid        int         '@id',
        name            varchar(200) '@name'
        )

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Name
  FROM #TmpAuthorCollection T CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'Author'

  --Retrieve Industries
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, IndustryId, Name
  INTO #TmpIndustryCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Industries/Industry', 1)
  WITH (industryid      int         '@id',
        name            varchar(200) '@name'
        )

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Name
  FROM #TmpIndustryCollection T CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'Industry'

  --Retrieve Bernstein tickers from Securities collection of document properties xml
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, X.SecurityId, X.Ticker, X.IndicateChange, X.TickerSheetId
  INTO #TmpTickerCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
  WITH (securityId      int         '@id',
        ticker          varchar(30) '@ticker',
        indicateChange  varchar(10) '@indicateChange',
        tickerSheetId   bigint      '@tickerSheetId'
        ) X --JOIN Securities2 S ON X.Ticker = S.Ticker
  --WHERE S.TickerType = 'STOCK'

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Ticker
  FROM #TmpTickerCollection T CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'Ticker'

--Retrieve Autonomous tickers from AutoSecurities collection of document properties xml
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, X.SecurityId, X.Ticker
  INTO #TmpAutoTickerCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/AutonomousSecurities/AutonomousSecurity', 1)
  WITH (securityId      int         '@id',
        ticker          varchar(30) '@ticker',
        indicateChange  varchar(10) '@indicateChange',
        tickerSheetId   bigint      '@tickerSheetId'
        ) X --JOIN Securities2 S ON X.Ticker = S.Ticker
  --WHERE S.TickerType = 'STOCK'

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Ticker
  FROM #TmpAutoTickerCollection T CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'Ticker'

  --Retrieve Investor Themes
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, ThemeId, Name
  INTO #TmpInvestorThemeCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/InvestorThemes/Theme', 1)
  WITH (ThemeId         int           '@id',
        Name            varchar(200)  '@name'
        )

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Name
  FROM #TmpInvestorThemeCollection T CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'InvestorTheme'

  --Retrieve Auto Blast Lists
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, BlastListId, Name
  INTO #TmpBlastListCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Blastlists/Blastlist', 1)
  WITH (BlastListId     varchar(100)  '@blastListId',
        Name            varchar(200)  '@name'
        )


  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, B.BlastListId
  FROM #TmpBlastListCollection B CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'BlastList'

  --Temp table to store indicatechange='Yes' tickers (subset of securities collection)
  SELECT DisplayNo, SecurityId, Ticker, IndicateChange, TickerSheetId
  INTO #Tmp_ChangeTickers
  FROM #TmpTickerCollection
  WHERE IndicateChange = 'Yes'

  --First version of the report
  IF @Version = 1
  BEGIN
    --Promote drafts to live if change report (Rating/TP/Estimates)
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = @PubNo, Date = @CurrentDate
    FROM FinancialNumbers FN
    JOIN #Tmp_ChangeTickers T ON FN.SecurityId = T.SecurityId
    WHERE FN.IsDraft = 1

    --update PubNo in TickesheetData table for change tickers
    UPDATE TickerSheetData
    SET PubNo = @PubNo
    FROM TickerSheetData TS JOIN #Tmp_ChangeTickers T ON TS.SecurityId = T.SecurityId AND TS.TickerSheetId = T.TickerSheetId

    --Save document xml's into PublicationXml table
    INSERT INTO PublicationsXml(PubNo, PropertiesXml, CompanyFinancialsXml, TickerTableXml, HighlightsXml,EditorId,EditDate)
    SELECT @PubNo, @PropertiesXml, @CompanyFinancialsXml, @TickerTableXml, @HighlightsXml,@EditorId,@CurrentDate
  END
  ELSE
  --if Version > 1 (Resubmit)
  BEGIN

    DECLARE @DocPropertiesXml XML
    SELECT @DocPropertiesXml = PropertiesXml FROM PublicationsXml WHERE PubNo = @PubNo

    --If correction exists for this report
    IF (SELECT max(CorrectionMode) FROM CorrectionQueue WHERE PubNo = @PubNo AND Status in ('Required','Optional')) = 1
    BEGIN
      --Get the list of by pass tickers

      SELECT C.SecurityId, S.Ticker
      INTO #TmpBypassTickers
      FROM CorrectionQueue C JOIN Securities2 S ON C.SecurityId = S.SecurityID
      WHERE PubNo = @PubNo
      AND C.Status in ('Required','Optional') AND
      CorrectionMode = 1

      --For the correction tickers promote draft to live (corrected value)
      UPDATE FinancialNumbers
      SET IsDraft = 0, PubNo = @PubNo, Date = @CurrentDate
      FROM FinancialNumbers FN
      JOIN #TmpBypassTickers T ON FN.SecurityId = T.SecurityId
      WHERE FN.IsDraft = 1

      --Release marketdata override for correction tickers
      UPDATE CorrectionQueue
      SET CorrectionMode = 0,Completed = @CurrentDate,Status = 'Completed'
      WHERE Pubno = @PubNo
      AND SecurityId IN (SELECT SecurityId FROM #TmpBypassTickers)

      --Delete marketdata overrides of the corrected report
      DELETE FROM MarketData
      WHERE SecurityId IN (SELECT SecurityId FROM #TmpBypassTickers)
      AND Type = 'O'

      DECLARE @NextDependentPub INT
      --Check if current report is a source report
      IF (SELECT max(IsSource) FROM CorrectionQueue WHERE PubNo = @PubNo) = 1
      BEGIN
        SELECT @NextDependentPub = min(PubNo) FROM CorrectionQueue
        WHERE SourcePubNo = @PubNo
        AND PubNo > @PubNo
        AND Status = 'Optional'
      END
      ELSE
      BEGIN
        SELECT @NextDependentPub = min(PubNo) FROM CorrectionQueue
        WHERE SourcePubNo = (SELECT max(SourcePubNo) FROM CorrectionQueue WHERE Pubno = @PubNo)
        AND PubNo > @PubNo
        AND Status = 'Optional'
      END

      --Populate marketdata overrides for each of the correction tickers
      --Loop through all tickers in #TmpTickerCollection to see if they are bypassed
      --on the dependent report and perform RestoreMarketData in loop
        SELECT @DocPropertiesXml = PropertiesXml FROM PublicationsXml WHERE PubNo = @NextDependentPub

        DECLARE @hDependentPubNo int, @SecurityId int

        --EXEC sp_xml_preparedocument @hDependentPubNo OUTPUT, @BypassXml

        SELECT C.SecurityId, S.Ticker
        INTO #TmpDependentPubNoBypassTickers
        FROM CorrectionQueue C JOIN Securities2 S ON C.SecurityId = S.SecurityID WHERE PubNo = @NextDependentPub
        AND C.Status in ('Required','Optional')
        --AND CorrectionMode = 1

        SELECT TOP 1 @SecurityId = SecurityId FROM #TmpDependentPubNoBypassTickers ORDER BY SecurityId
        WHILE @@ROWCOUNT = 1
        BEGIN
      EXEC spRestoreMarketData @NextDependentPub, @SecurityId, @EditorId
          EXEC spRevaluate @SecurityId
          SELECT TOP 1 @SecurityId = SecurityId FROM #TmpDependentPubNoBypassTickers WHERE SecurityId > @SecurityId ORDER BY SecurityId
        END

      --EXEC sp_xml_removedocument @hDependentPubNo
    END

    --Get Tickers with IndicateChange = 'Yes' in this version and not in previous version
    EXEC sp_xml_preparedocument @hDoc2 OUTPUT, @DocPropertiesXml

    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, X.SecurityId, X.Ticker, X.IndicateChange
    INTO #TmpPreviusTickerList
    FROM OPENXML (@hDoc2, 'DocumentInfo/Securities/Security', 1)
    WITH (securityId     int         '@id',
          ticker         varchar(30) '@ticker',
          indicateChange varchar(10) '@indicateChange'
         ) X JOIN Securities2 S ON X.Ticker = S.Ticker
    WHERE S.TickerType = 'STOCK'
    AND X.IndicateChange = 'Yes'

    --update FinancialNumbers to promote draft for ticker additions where indicate change='Yes'
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = @PubNo, Date = @CurrentDate
    FROM FinancialNumbers FN
    JOIN #Tmp_ChangeTickers T ON FN.SecurityId = T.SecurityId
    WHERE FN.IsDraft = 1
    AND T.SecurityId NOT IN (SELECT SecurityId FROM #TmpPreviusTickerList)

    --update TickerSheetData table with PubNo for ticker additions where indicate change='Yes'
    UPDATE TickerSheetData
    SET PubNo = @PubNo
    FROM TickerSheetData TS JOIN #Tmp_ChangeTickers T ON TS.TickerSheetId = T.TickerSheetId AND TS.SecurityId = T.SecurityId
    WHERE T.SecurityId NOT IN (SELECT SecurityId FROM #TmpPreviusTickerList)

    --Update publications xml
    UPDATE PublicationsXml
    SET PropertiesXml = @PropertiesXml,
        TickerTableXml = @TickerTableXml,
        CompanyFinancialsXml = @CompanyFinancialsXml,
        HighlightsXml = @HighlightsXml,
        EditDate = @CurrentDate,
        EditorId = @EditorId
        --,BypassXml = null
    WHERE PubNo = @PubNo

  END

    --Call Revaluate for indicate change = 'Yes' tickers
    DECLARE @ChangeTickerCount int,@ChangeSecurityId int
    SELECT Top 1 @ChangeSecurityId = SecurityId FROM #Tmp_ChangeTickers ORDER BY SecurityId
    WHILE @@ROWCOUNT = 1
    BEGIN
      EXEC spRevaluate @ChangeSecurityId
      SELECT Top 1 @ChangeSecurityId = SecurityId FROM #Tmp_ChangeTickers WHERE SecurityId > @ChangeSecurityId ORDER BY SecurityId
    END

    --Insert into PublicationsFinancialNumbers
    INSERT INTO PublicationFinancialNumbers(PubNo, FinancialNumberId, CoverageId, EditorId, EditDate)
    SELECT @PubNo, FinancialNumberId, CoverageId, 1, @CurrentDate
    FROM vFinancialNumbersLatest
    WHERE SecurityId IN (SELECT SecurityId FROM #TmpTickerCollection)
    AND IsDraft = 0

    --Populate PublicationActionTags flat structured table (denormalized)
    IF @TickerTableXml.exist('/TickerTable') = 1
    BEGIN
      --print 'test'
      EXEC spSavePublicationFinancials @PubNo, @TickerTableXml, @EditorId
    END
    
    --Call to populate rows into ProductGroupDocuments table
    EXEC spInsProductGroupDocsByPubNo @PubNo,@Date ,@Type

    --Call to populate rows into distribution queue
    EXEC spAddDistributionItem @PubNo, 0, 'C'

    --Call to populate row into analyst blast queue
    EXEC spAddBlastItem @PubNo

    EXEC sp_xml_removedocument @hDoc

    COMMIT
END TRY
BEGIN CATCH
  IF @@TRANCOUNT > 0
     ROLLBACK

  -- Raise an error with the details of the exception
  DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
  SELECT @ErrMsg = ERROR_MESSAGE(),
         @ErrSeverity = ERROR_SEVERITY()

  RAISERROR(@ErrMsg, @ErrSeverity, 1)
END CATCH
GO