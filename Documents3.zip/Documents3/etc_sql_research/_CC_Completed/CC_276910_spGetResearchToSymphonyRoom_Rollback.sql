--03/23/2018
--CC_spGetResearchToSymphonyRoom_Rollback.sql 

USE Research
GO
-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO
IF EXISTS(SELECT * FROM sys.objects where name like '%spGetResearchToSymphonyRoom%')
DROP PROCEDURE dbo.spGetResearchToSymphonyRoom
GO
