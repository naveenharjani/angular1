-- CC_RVModels.sql
-- 11/09/2017

/*

Research
========
RVModels
LinkStatus
ContentUsage
ProductGroupModels
RVProductGroupModels
RVSecurities

BR.com - Database required
======
spValidateUser
spGetFileName

CRM - Database preferred
===
spCheckEntitlementandQuota -- spCheckAccess.  Return quota balance?
spLogUsage

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where name like '%RVModels%')
drop view dbo.RVModels
go

if exists(select * from sys.objects where name = 'ContentTypes')
drop table ContentTypes
go

if exists(select * from sys.objects where name like '%RVContentTypes%')
drop view dbo.RVContentTypes
go

if exists(select * from sys.objects where name = 'LinkStatus')
drop table LinkStatus
go

if exists(select * from sys.objects where name = 'ProductGroupModels')
drop table dbo.ProductGroupModels
go

if exists(select * from sys.objects where name like '%RVProductGroupModels%')
drop view dbo.RVProductGroupModels
go

--RVSecurities altered to add CompanyId, IsPrimary, OrdNo columns
if exists(select * from sys.objects where name like '%RVSecurities%')
drop view dbo.RVSecurities
go

create view [dbo].[RVSecurities] WITH SCHEMABINDING AS
select
  SecurityId,
  Ticker,
  RIC,
  Company,
  Cusip,
  Sedol,
  Isin,
  Status,                  -- iPad app Watch List - Picklist displays active coverage where Status is 1
  RefreshDate = EditDate,  -- iPad app Watch List - Refresh (additions, subtractions, modifications) when RefreshDate > WL RefreshDate
  GoUrl
from
  dbo.Securities2
where
  TickerType = 'STOCK'
go

create unique clustered index [RVSecurities_SecurityId] ON [dbo].[RVSecurities]
(
  [SecurityId] ASC
)
go

/*

##, "Site unavailable"
10, "Invalid Login Id"
11, "Invalid Password"
12, "User in active in CRM"

21, "User not part of Tier6"
22, "User not entitled to product group"
23, "Quota exceeded"

31, "No row in RVModels table"
32, "File not available"
33, "Error streaming file

100, "File streaming successful"
101, "File streaming successful with CRM down"

Canceled login
Exceeded login attempts.  Account locked

*/
