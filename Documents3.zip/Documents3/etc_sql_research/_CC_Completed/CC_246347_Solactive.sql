-- Solactive.sql
-- 03/13/2017

/*

spSearchSolactiveIndexTickers

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSearchSolactiveIndexTickers]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON

IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'

-- Company has secondary sort column of OrdNo
DECLARE @SortCol2 varchar(100)
SET @SortCol2 = ''

IF @SortCol = '2' SET @SortCol2 = ', 3, 4, OrdNo' -- Sort by Region then Analyst, Company, OrdNo
IF @SortCol = '3' SET @SortCol2 = ', 4, OrdNo'    -- Sort by Analyst then Company, OrdNo
IF @SortCol = '4' SET @SortCol2 = ', OrdNo'       -- Sort by Company then OrdNo
IF @SortCol = '7' SET @SortCol2 = ', 3, 4, OrdNo' -- Sort by Launch then Analyst, Company, OrdNo

DECLARE
  @SelectQuery AS NVARCHAR(MAX)

SET @SelectQuery =
N'
SELECT *
FROM (
  SELECT
  RC.SecurityId,
  AR.Region,
  A.Last + '', '' + A.First AS Analyst,
  S.Company,
  S.Ticker,
  S.OrdNo,
  RC.LaunchDate,
  SI.IndexCode
  FROM ResearchCoverage RC
  JOIN Securities2 S ON S.SecurityId = RC.SecurityId
  JOIN Authors A ON A.AuthorId = RC.AnalystId
  JOIN AuthorRegions AR ON AR.RegionId = A.RegionId
  LEFT JOIN SolactiveIndexTickers SIT ON SIT.SecurityId = RC.SecurityId
  LEFT JOIN SolactiveIndexes SI ON SI.IndexId = SIT.IndexId
  WHERE RC.DropDate IS NULL
) as p
PIVOT
(
  count(IndexCode)
  for IndexCode in ([BERNUS], [BERNINTL], [BERNGLBL], [BERNAPAC], [BERNEURO], [ACK])
) piv
order by ' + @SortCol + @SortDir + @SortCol2

-- print @SelectQuery

EXEC sp_executesql @SelectQuery

SET @Ct = @@ROWCOUNT

GO
