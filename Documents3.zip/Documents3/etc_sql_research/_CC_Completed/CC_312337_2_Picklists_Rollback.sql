-- Picklists_Rollback.sql
-- 06/19/2019

/*

Procs used by REST api getPicklist(list, style)

spPickTickers
spPickIndustries
spPickAuthors
spPickTypes
spPickSubTypes
spPickKeywords
spPickInvestorThemes
spPickThematicTags
spPickCoverageActions
spPickRatingActions
spPickTargetPriceActions
spPickEstimateActions

*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTifIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where type = 'P' and name = 'spPickTickers')
drop proc dbo.spPickTickers
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickIndustries')
drop proc dbo.spPickIndustries
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickAuthors')
drop proc dbo.spPickAuthors
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickTypes')
drop proc dbo.spPickTypes
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickSubTypes')
drop proc dbo.spPickSubTypes
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickKeywords')
drop proc dbo.spPickKeywords
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickInvestorThemes')
drop proc dbo.spPickInvestorThemes
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickThematicTags')
drop proc dbo.spPickThematicTags
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickCoverageActions')
drop proc dbo.spPickCoverageActions
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickRatingActions')
drop proc dbo.spPickRatingActions
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickTargetPriceActions')
drop proc dbo.spPickTargetPriceActions
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickEstimateActions')
drop proc dbo.spPickEstimateActions
go


/*

DEBUG

-- LEGACY

sp_helptext spRenderTypes

sp_helptext spRenderTickers

sp_helptext spRenderInvestorThemes

spRenderTypes

spRenderSubTypes

spRenderInvestorThemes 3

spRenderTickers 1

select * from InvestorThemes where Active = -1 order by SeqNo

-- NEW

spPickTypes
go

spPickSubTypes
go

spPickKeywords
go

spPickInvestorThemes 3
go

spPickThematicTags 1
go

spPickCoverageActions
go

spPickRatingActions
go

spPickTargetPriceActions
go

spPickEstimateActions
go

*/
