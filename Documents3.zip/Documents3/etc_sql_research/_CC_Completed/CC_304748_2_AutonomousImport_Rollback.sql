-- AutonomousImport_Rollback.sql
-- 02/22/2019
/*
alter FileProcessingConfig
Drop AutonomousStagingAuthors - Entities
Drop AutonomousStagingTickers - Analysts
Drop spLoadAutonomousAuthors
Drop spLoadAutonomousTickers
alter spAddFileProcessingLog
*/


USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO


if exists(select * from sys.columns where name = 'DataFlow' and object_id = OBJECT_ID('FileProcessingLog'))
alter table dbo.FileProcessingLog
drop column DataFlow
go

if exists (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AutonomousStagingAuthors]') AND type in (N'U'))
drop table [dbo].[AutonomousStagingAuthors]
go

if exists (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AutonomousStagingTickers]') AND type in (N'U'))
drop table [dbo].[AutonomousStagingTickers]
go

if exists(select * from sys.objects where type = 'P' and name = 'spLoadAutonomousAuthors')
drop proc dbo.spLoadAutonomousAuthors
go

if exists(select * from sys.objects where type = 'P' and name = 'spLoadAutonomousTickers')
drop proc dbo.spLoadAutonomousTickers
go

-- =================================================================================================
-- Author:       Anup Singh
-- Revisions:    10/23/2018 - Created
-- Description:  Log entries for file processing - Readership, Holdings, Models usage, Autonomous in/out files
-- =================================================================================================
Alter PROC [dbo].[spAddFileProcessingLog]
(
 @DataStore as nvarchar(250),
 @filename as nvarchar(250),
 @ServerName as nvarchar(100),
 @EditorId as int,
 @Comment as nvarchar(max) = null
)
AS
BEGIN

    IF @DataStore  = 'Holdings'
    BEGIN
        INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,LastExecution))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,LastExecution))), 101)
           ,count(*)
           ,@EditorId
           ,'Holdings ' + Convert(varchar(10),count(*)) + ' / vHoldings ' + Convert(Varchar(10),(select count(*) from vHoldings))
           from Holdings
    END
    ELSE IF @DataStore  = 'OneAccess'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,file_date_UTC))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,file_date_UTC))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_ONEaccess
    END
    ELSE IF @DataStore  = 'Bloomberg'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,'Bloomberg'
               ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Read Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Read Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_Bloomberg
    END

    ELSE IF @DataStore  = 'BlueMatrix'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,'BlueMatrix'
              ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Read Date/Time]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Read Date/Time]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_BlueMatrix
    END
    ELSE IF @DataStore  = 'FactSet'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,'FactSet'
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Date/time read]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Date/time read]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_FactSet
    END
    ELSE IF @DataStore  = 'TR' or @DataStore = 'THOMSONREUTERS'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
              ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Viewed Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Viewed Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_TR
    END
    ELSE IF @DataStore  = 'CIQ'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Activity Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Activity Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_CIQ
    END

    ELSE IF @DataStore  = 'RSRCHX'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Action Date (UTC)]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Action Date (UTC)]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_RSRCHX
    END

    ELSE IF @DataStore  = 'REDDEER'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Read_Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Read_Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_RedDeer
    END
    ELSE IF @DataStore  = 'VisibleAlpha'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
					
                     )
        select GETDATE()
               ,'VisibleAlpha'
              ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(CONVERT(date,replace(file_date_UTC,'Z',':00'),127))), 101)
           ,convert(varchar, Convert(date,Max(CONVERT(date,replace(file_date_UTC,'Z',':00'),127))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
		  
           from PortalUsageStaging_VisibleAlpha
    END

END
GO

delete from FileProcessingConfig where DataStore ='BlueCurve'
go
delete from FileLoadInstructions where DataStore ='BlueCurve'
go
delete from Jobs where Description ='BlueCurve'
go

update Securities2 set TypeId = 1 where SecurityID in (
select SecurityID from FinancialSecuritySettings where securityid in (select SecurityId from Securities2 where typeid =2))
go

update Securities2 set TypeId = 1 where SecurityID in (
select SecurityID from ResearchCoverage where securityid in (select SecurityId from Securities2 where typeid =2))
go

delete from Securities2 where typeid =2
go

delete from Companies where CompanyId in (select companyid from Securities2 where TypeId = 2)
go




