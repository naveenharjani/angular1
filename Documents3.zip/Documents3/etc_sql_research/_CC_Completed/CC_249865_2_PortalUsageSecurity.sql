-- PortalUsageSecurity.sql
-- 04/28/2017

/*

User 'DE_IIS' - Grant bulk inserts from SSIS packages

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- User 'DE_IIS' - Grant bulk inserts from SSIS packages
GRANT INSERT, DELETE, UPDATE ON PortalUsageStaging_Bloomberg TO  DE_IIS
GRANT INSERT, DELETE, UPDATE ON PortalUsageStaging_TR        TO  DE_IIS
GRANT INSERT, DELETE, UPDATE ON PortalUsageStaging_CIQ       TO  DE_IIS
GRANT INSERT, DELETE, UPDATE ON PortalUsageStaging_FactSet   TO  DE_IIS
GO


/*
-- DE_IIS inherits role to bulk inserts from SSIS
CREATE ROLE [Role_SSIS_user]
GO
GRANT INSERT, DELETE, UPDATE ON PortalUsageStaging_Bloomberg TO  [Role_SSIS_user]
GRANT INSERT, DELETE, UPDATE ON PortalUsageStaging_TR        TO  [Role_SSIS_user]
GRANT INSERT, DELETE, UPDATE ON PortalUsageStaging_CIQ       TO  [Role_SSIS_user]
GRANT INSERT, DELETE, UPDATE ON PortalUsageStaging_FactSet   TO  [Role_SSIS_user]
GO
exec sp_addrolemember N'Role_SSIS_user', N'DE_IIS '
GO

*/
