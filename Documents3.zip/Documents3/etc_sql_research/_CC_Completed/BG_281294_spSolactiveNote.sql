-- spSaveSolactiveNote.sql
-- 05/31/2018
-- Solactive Note Bug Fix - Save/Insert fails silently when Note is > 90+ characters

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSaveSolactiveNote]
  @SecurityId    int,
  @Note          varchar(2048),
  @EditorId      int
AS

DECLARE
@EditDate datetime,
@Ticker varchar(15),
@OldNote varchar(2048),
@New varchar(100),
@Old varchar(100)

SELECT @EditDate = GETDATE()

SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityID = @SecurityId
SELECT @OldNote = Note FROM SolactiveNotes WHERE SecurityId = @SecurityId

-- In case of long Note text, limit to 97 characters text to fit into AdminLog
IF (LEN(@Ticker + ' | ' + @Note) > 100)
SELECT @New = LEFT(@Ticker + ' | ' + @Note, 97) + '...'
ELSE
SELECT @New = @Ticker + ' | ' + @Note

IF (LEN(@Ticker + ' | ' + @OldNote) > 100)
SELECT @Old = LEFT(@Ticker + ' | ' + @OldNote, 97) + '...'
ELSE
SELECT @Old = @Ticker + ' | ' + @OldNote

BEGIN TRY
  BEGIN TRANSACTION

    -- NO ROW IMPLIES NO NOTE
    IF (LTRIM(RTRIM(@Note)) <> '')
    BEGIN
      IF NOT EXISTS (SELECT SecurityId FROM SolactiveNotes WHERE SecurityId = @SecurityId)
        BEGIN
          INSERT INTO SolactiveNotes (SecurityId, Note, EditorId, EditDate) VALUES (@SecurityId, @Note, @EditorId, GETDATE())

          INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
          VALUES ('SolactiveNotes', 'A', @New, NULL, @SecurityId, @EditorId, @EditDate)
        END
      ELSE
        BEGIN
          UPDATE SolactiveNotes SET Note = @Note, EditorId = @EditorId, EditDate = GETDATE() WHERE SecurityId = @SecurityId

          INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
          VALUES ('SolactiveNotes', 'U', @New, @Old, @SecurityId, @EditorId, @EditDate)
        END
    END
    ELSE
    BEGIN
      DELETE FROM SolactiveNotes WHERE SecurityId = @SecurityId

      INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
      VALUES ('SolactiveNotes', 'D', '', @Old, @SecurityId, @EditorId, @EditDate)
    --    VALUES ('SolactiveNotes', 'D', @Ticker + ' | ', @Ticker + ' | ' + @OldNote, @SecurityId, @EditorId, @EditDate)
    END

    SELECT 0
  COMMIT TRANSACTION
END TRY
BEGIN CATCH
  ROLLBACK TRANSACTION
  SELECT ERROR_NUMBER() AS ErrorNumber, ERROR_MESSAGE() AS ErrorMessage
END CATCH


GO

/*
EXEC [dbo].[spSaveSolactiveNote] 2053,   'Westlake Chemical Corp is included in the index since it is the operating company instead of 1222333444',  1229

SELECT * FROM SolactiveNotes ORDER BY EditDate DESC
SELECT * FROM AdminLog WHERE [Table] = 'SolactiveNotes' ORDER BY EditDate DESC
*/


