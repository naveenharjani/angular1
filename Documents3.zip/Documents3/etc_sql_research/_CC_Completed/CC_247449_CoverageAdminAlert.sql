-- CoverageAdminAlert.sql
-- 03/29/2017

/*

spSendCoverageAlert

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSendCoverageAlert]
AS
BEGIN
SET NOCOUNT ON

DECLARE
@Email_body    NVARCHAR(MAX),
@NumChanges    INT

SELECT
  CONVERT(date, RC.EditDate, 101) AS EditDate,
  A.Last + ', ' + A.First AS Analyst,
  S.Company,
  S.Ticker,
  S.IsPrimary
INTO #RecentChanges
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN Authors A ON A.AuthorId = RC.AnalystId
WHERE RC.LaunchDate is null and RC.DropDate is null
AND RC.EditDate BETWEEN CAST(CONVERT(VARCHAR, getdate()-1, 101) AS DATETIME) AND getdate() -- Coverage updates since yesterday
--AND RC.EditDate BETWEEN getdate() - 90 AND getdate()    -- Coverage updates in last n days
ORDER BY CONVERT(date, RC.EditDate, 101), S.Company, S.IsPrimary DESC

SELECT @NumChanges = COUNT(*) FROM #RecentChanges

-- Notify Send email - for any coverage changes
IF @NumChanges > 0
BEGIN

  SELECT @Email_body =
    ISNULL(STUFF((SELECT '' + CHAR(10) + CONVERT(varchar, EditDate) + '    ' + Analyst + '    ' + Company + ' / ' + Ticker
  FROM #RecentChanges
  ORDER BY EditDate, Company, IsPrimary DESC
  FOR XML PATH('')), 1, 1, ''), '')

  print @Email_body

  EXEC msdb.dbo.sp_send_dbmail
    @recipients = 'IndexTeam@bernstein.com',
    @copy_recipients = 'ISTG-Research@abglobal.com',
    @subject = 'Recent Coverage Administration Changes',
    @body = @Email_body

--    @from_address = 'Bernstein Research Data<data@bernstein.com>', -- Override default MSSQL MailAC <mssqlmailac@acml.com>
--    @reply_to = 'Bernstein Research Data<data@bernstein.com>', -- Override default mssqlmailac@acml.com

END

SET NOCOUNT OFF
END

GO

/*

EXEC spSendCoverageAlert
GO

*/
