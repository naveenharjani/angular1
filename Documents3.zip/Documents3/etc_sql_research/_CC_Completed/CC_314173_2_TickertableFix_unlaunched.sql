-- TickerTable_UnlaunchedTickers.sql
-- 07/18/2019

/*
Ticker table page - Show unlaunched tickers only for analyst, team member or admins

alter proc spGetCompanySecurities
*/

ALTER PROCEDURE [dbo].[spGetCompanySecurities]
  @Style int,
  @CompanyId int = NULL,
  @AnalystId int = NULL,
  @Ticker varchar(15) = NULL,
  @UserId int = NULL
AS

/*
Styles
1 - All securities - By specified company (Security Administration)
2 - Launched and unlaunched securities - By all companies or specified company (Estimate Set Administration)
3 -
4 - Launched and unlaunched securities - By all analysts (not practical) or specified analyst
5 - Launched and unlaunched securities - By Ticker (based on parent Company)
6 - Launched and unlaunched (visibility restrictions) securities - By all analysts (not practical) or specified analyst
*/

SET NOCOUNT ON

-- All securities - By specified company
IF @Style = 1
BEGIN

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo
FROM Securities2 S
JOIN Companies C ON C.CompanyId = S.CompanyId
WHERE S.CompanyId = @CompanyId
ORDER BY S.IsPrimary DESC, S.OrdNo

END

-- Launched and unlaunched securities - By all companies or specified company
ELSE IF @Style = 2
BEGIN

DECLARE @Companies TABLE (CompanyId int)
IF ISNULL(@CompanyId, '') = ''
BEGIN
  INSERT @Companies
    SELECT C.CompanyId
    FROM ResearchCoverage RC
    JOIN Securities2 S on S.SecurityId = RC.SecurityId
    JOIN Companies C on C.CompanyId = S.CompanyId
    WHERE RC.DropDate IS NULL
END
ELSE
  INSERT @Companies SELECT @CompanyId

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.AnalystId, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN Companies C ON C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL
AND S.CompanyId IN (SELECT CompanyId FROM @Companies)
ORDER BY C.Company, S.IsPrimary DESC, S.OrdNo

END

-- Launched and unlaunched securities - By all analysts (not practical) or specified analyst
ELSE IF @Style = 4
BEGIN

DECLARE @Analysts TABLE (AnalystId int)
IF ISNULL(@AnalystId, '') = ''
  INSERT @Analysts SELECT AuthorId FROM Authors WHERE IsAnalyst = -1 AND IsActive = -1
ELSE
  INSERT @Analysts SELECT @AnalystId

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
JOIN Companies C on C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)
ORDER BY C.Company, S.OrdNo

END

-- Launched and unlaunched securities - By Ticker (based on parent Company)
ELSE IF @Style = 5
BEGIN

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.AnalystId, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN Companies C ON C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL
AND S.CompanyId IN (SELECT CompanyId FROM Securities2 WHERE Ticker = @Ticker)
ORDER BY C.Company, S.IsPrimary DESC, S.OrdNo

END

-- Launched and unlaunched (visibility restrictions) securities - By all analysts (not practical) or specified analyst
ELSE IF @Style = 6
BEGIN

IF ISNULL(@AnalystId, '') = ''
  INSERT @Analysts SELECT AuthorId FROM Authors WHERE IsAnalyst = -1 AND IsActive = -1
ELSE
  INSERT @Analysts SELECT @AnalystId

DECLARE @ShowUnlaunched CHAR(1)

-- Admin or Manager role
IF EXISTS(SELECT * FROM UserRoles WHERE RoleId IN (1, 2) AND UserId = @UserId)
  SET @ShowUnlaunched = 'Y'

-- Launched tickers (visible to all)
SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
JOIN Companies C on C.CompanyId = S.CompanyId
WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)

UNION

-- Unlaunched tickers (visible to Team Members, Admins, Managers)
SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
JOIN Companies C on C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL AND RC.LaunchDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)
AND (
      RC.AnalystId = @UserId
      OR
      RC.AnalystId IN (SELECT AnalystId FROM AnalystTeamMembers WHERE UserId = @UserId)
      OR
      @ShowUnlaunched = 'Y' -- Authorized roles only
     )

ORDER BY C.Company, S.OrdNo

END

SET NOCOUNT OFF


GO


-- DEBUG

/*
Unlaunched tickers (DEV)
Shan He        - 6160.HK, 600276.CH, 4502.JP, 2269.HK
Kevin Kwek     - ACB.VN, BBNI.IJ, MBB.VN, CTG.VN
(PRD)
Shmulik        - LYFT, AMZN, GOOG, FB, TWTR
Sherman        - KGF.LN, NXT.LN, ASC.LN, HMB.SS

select * from authors where last = 'He'  -- Shan He / 9 unlaunched tickers (DEV)
select * from authors where last = 'Kwek'  -- Kevin Kwek / 6 unlaunched tickers (DEV)

-- Ticker table page
-- spGetCompanySecurities 6, null, " + sAnalystId + ", null, " + iUserId;
-- Shan He
spGetCompanySecurities 6, null, 856, null, 2867  -- beehive user
spGetCompanySecurities 6, null, 856, null, 1229 -- admin

-- Kevin Kwek
spGetCompanySecurities 6, null, 532, null, 2867  -- beehive user
spGetCompanySecurities 6, null, 532, null, 1229 -- admin

Beehive pages : Ticker Table page http://institutional.beehive.com/research/tickertable.aspx
*/