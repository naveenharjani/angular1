-- vFinancials_Flip_Rollback.sql
-- 06/01/2017

/*
-- drop old views
drop vFinancials_Old (TTS)
drop vFinancialsLatest_Old (TTS)

-- rollback views
drop and create vFinancials (TTS)
drop and create vFinancialsLatest (TTS & vFinancials)

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vFinancials_Old]') AND type in (N'V'))
DROP VIEW [dbo].[vFinancials_Old]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vFinancialsLatest_Old]') AND type in (N'V'))
DROP VIEW [dbo].[vFinancialsLatest_Old]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vFinancials]') AND type in (N'V'))
DROP VIEW [dbo].[vFinancials]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vFinancialsLatest]') AND type in (N'V'))
DROP VIEW [dbo].[vFinancialsLatest]
GO

CREATE VIEW [dbo].[vFinancials]
AS
SELECT
  S.SecurityID,
  S.Ticker,
  P.Date,
  TT.PubNo,
  TTS.CoverageAction,
  -- Rating
  TTS.Rating,
  'RatingPrior' = TTSO.Rating,
  TTS.RatingAction,
  -- Target Price
  TTS.TargetPrice,
  'TargetPricePrior' = TTSO.TargetPrice,
  TTS.TargetPriceAction,
  TTS.TargetPriceOrig,
  --
  TT.LastYear,
  TT.ThisYear,
  TT.NextYear,
  -- EPS
  TT.EPSType,
  TTS.EPSLastYear,
  TTS.EPSThisYear,
  'EPSThisYearPrior' = TTSO.EPSThisYear,
  TTS.EstimateAction,
  TTS.EPSNextYear,
  'EPSNextYearPrior' = TTSO.EPSNextYear,
  TTS.EstimateNextYearAction,
  -- Metric
  TT.MetricType,
  TTS.MetricLastYear,
  TTS.MetricThisYear,
  TTS.MetricNextYear,
  -- Other TTS fields
  TTS.Currency,
  TTS.YTDRelPerf,
  TTS.Yield,
  -- Coverage dates
  RC.LaunchDate,
  RC.DropDate,
  P.FileName,
  RC.CoverageId,
  RC.IndustryId,
  RC.AnalystId,
  TTS.CloseDate,
  TTS.ClosePrice,
  TTS.TickerOrder,
  TT.DisplayCloseDate,
  TT.RelPerfType
FROM
  TickerTables TT
  JOIN TickerTableSecurities TTS ON TTS.PubNo = TT.PubNo
  JOIN Publications P ON P.PubNo = TT.PubNo
  JOIN Securities2 S ON S.Ticker = TTS.Ticker AND S.TickerType = 'Stock'
  JOIN ResearchCoverage RC ON TTS.CoverageId = RC.CoverageId
  LEFT OUTER JOIN TickerTableSecuritiesOld TTSO ON TTSO.Ticker = TTS.Ticker AND TTSO.PubNo = TTS.PubNo
WHERE
  RC.LaunchDate is not null

UNION

SELECT
  S.SecurityID,
  S.Ticker,
  P.Date,
  TT.PubNo,
  TTS.CoverageAction,
  -- Rating
  '' AS Rating,
  '' AS RatingPrior,
  '' AS RatingAction,
  -- Target Price
  '' AS TargetPrice,
  '' AS TargetPricePrior,
  '' AS TargetPriceAction,
  '' AS TargetPriceOrig,
  --
  TT.LastYear,
  TT.ThisYear,
  TT.NextYear,
  -- EPS
  TT.EPSType,
  TTS.EPSLastYear,
  TTS.EPSThisYear,
  '' AS EPSThisYearPrior,
  TTS.EstimateAction,
  TTS.EPSNextYear,
  '' AS EPSNextYearPrior,
  TTS.EstimateNextYearAction,
  -- Metric
  TT.MetricType,
  TTS.MetricLastYear,
  TTS.MetricThisYear,
  TTS.MetricNextYear,
  -- Other TTS fields
  TTS.Currency,
  TTS.YTDRelPerf,
  TTS.Yield,
  -- Coverage dates
  NULL AS LaunchDate,
  NULL AS DropDate,
  P.FileName,
  NULL AS CoverageId,
  NULL AS IndustryId,
  NULL AS AnalystId,
  TTS.CloseDate,
  TTS.ClosePrice,
  TTS.TickerOrder,
  TT.DisplayCloseDate,
  TT.RelPerfType
FROM
  TickerTables TT
  JOIN TickerTableSecurities TTS ON TTS.PubNo = TT.PubNo
  JOIN Publications P ON P.PubNo = TT.PubNo
  JOIN Securities2 S ON S.Ticker = TTS.Ticker AND S.TickerType = 'Index'

GO

CREATE VIEW [dbo].[vFinancialsLatest]
AS
SELECT
  VF.SecurityID,
  VF.Ticker,
  VF.Date,
  VF.PubNo,
  VF.CoverageAction,
  -- Rating
  VF.Rating,
  VF.RatingAction,
  -- Target Price
  VF.TargetPrice,
  VF.TargetPriceAction,
  --
  VF.LastYear,
  VF.ThisYear,
  VF.NextYear,
  -- EPS
  VF.EPSType,
  VF.EPSLastYear,
  VF.EPSThisYear,
  VF.EstimateAction,
  VF.EPSNextYear,
  VF.EstimateNextYearAction,
  -- Metric
  VF.MetricType,
  VF.MetricLastYear,
  VF.MetricThisYear,
  VF.MetricNextYear,
  -- Other Fields
  VF.Currency,
  VF.YTDRelPerf,
  VF.Yield,
  -- Coverage dates
  VF.LaunchDate,
  VF.FileName,
  VF.CoverageId,
  VF.IndustryId,
  VF.AnalystId,
  VF.CloseDate,
  VF.ClosePrice,
  VF.TickerOrder,
  VF.DisplayCloseDate,
  VF.RelPerfType
FROM vFinancials VF
JOIN (SELECT Ticker, MAX(PubNo) PubNo FROM TickerTableSecurities GROUP BY Ticker) V ON V.Ticker = VF.Ticker AND V.PubNo = VF.PubNo
JOIN ResearchCoverage RC ON RC.SecurityID = VF.SecurityID AND RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL


GO


/*

sp_helptext vFinancials_Old
sp_helptext vFinancials
sp_helptext vFinancials2

sp_helptext vFinancialsLatest_Old
sp_helptext vFinancialsLatest
sp_helptext vFinancialsLatest2


*/