-- ETL_PortalUsageBak.sql
-- 02/27/2019

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*   backup PortalUsage table   */

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageBak]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageBak]
GO
SELECT * INTO [dbo].[PortalUsageBak] FROM [dbo].[PortalUsage]
GO


/*
SELECT COUNT(*) FROM [dbo].[PortalUsage] 
SELECT COUNT(*) FROM [dbo].[PortalUsageBak] 
*/