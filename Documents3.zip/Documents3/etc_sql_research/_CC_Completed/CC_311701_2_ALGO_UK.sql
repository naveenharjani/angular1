-- CC_ALGO-UK.sql
-- 06/26/2019

/*

SCBIS_ALGO_UK

SCBIS_ALGO_UK retrieved data (spGetLatestResearchForALGO)

alter spGetLatestResearchForALGO

*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

USE Master
GO

CREATE LOGIN SCBIS_ALGO_UK WITH PASSWORD = 'Research!01';
GO

USE Research
GO

CREATE USER SCBIS_ALGO_UK FOR LOGIN SCBIS_ALGO_UK; 
GO

USE [Research]
GO

ALTER PROCEDURE [dbo].[spGetLatestResearchForALGO]
AS

-- 03/13/2014
-- Added PublishedDate which includes version 1 publish time
-- Per Paul Ponomarev T-1 16:00 delta processing

--08/26/2014
-- Added encrypted link column "ExtLink"

SET NOCOUNT ON

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'ALGO', CURRENT_USER + ' retrieved data (spGetLatestResearchForALGO)')

select
  VFL.Date as ReportDate,
  P.PublishedDate,
  VFL.PubNo,
  VFL.Ticker,
  S.Company,
  X.Sector,
  I.IndustryName as Industry,
  A.Last as Analyst,
  P.Title,
  VFL.CoverageAction,
  VFL.Rating,
  VFL.RatingAction,
  VFL.TargetPrice,
  VFL.Currency,
  VFL.TargetPriceAction,
  VFL.LaunchDate,
  'ExtLink' = (select Max(AlgoLink) from EncryptedLinks where PubNo = P.PubNo)
from vFinancialsLatest VFL
join Publications P on P.PubNo = VFL.PubNo
join Securities2 S on S.SecurityId = VFL.SecurityId
join Industries I on I.IndustryId = VFL.IndustryId
join Sectors X on X.SectorId = I.SectorId
join Authors A on A.AuthorId = VFL.AnalystId
where P.Version = 1

union

select
  VFL.Date as ReportDate,
  PL.PublishedDate,
  VFL.PubNo,
  VFL.Ticker,
  S.Company,
  X.Sector,
  I.IndustryName as Industry,
  A.Last as Analyst,
  P.Title,
  VFL.CoverageAction,
  VFL.Rating,
  VFL.RatingAction,
  VFL.TargetPrice,
  VFL.Currency,
  VFL.TargetPriceAction,
  VFL.LaunchDate,
  'ExtLink' = (select max(AlgoLink) from EncryptedLinks where PubNo = P.PubNo)
from vFinancialsLatest VFL
join PublicationsLog PL on PL.PubNo = VFL.PubNo
join Publications P on P.Pubno = VFL.PubNo
join Securities2 S on S.SecurityId = VFL.SecurityId
join Industries I on I.IndustryId = VFL.IndustryId
join Sectors X on X.SectorId = I.SectorId
join Authors A on A.AuthorId = VFL.AnalystId
where PL.Version = 1

order by 2 desc, 5, 4


GO

GRANT EXECUTE ON spGetLatestResearchForALGO to SCBIS_ALGO_UK
GO

/*
USE Research
GO
EXEC [spGetLatestResearchForALGO]
GO

SELECT * FROM EventLog WHERE Source = 'ALGO' ORDER BY TimeStamp Desc
GO

Database logins:
SCBIS_Admin
SCBIS_Admin2
SCBIS_ALGO
SCBIS_APP
SCBIS_APP2
SCBIS_ARGUS
SCBIS_NEO
SCBIS_Guest
SCBIS_QUANT
SCBIS_Reports

SCBIS_BG

DE_Admin
DE_IIS
DE_MTS
PortfolioTrading

*/