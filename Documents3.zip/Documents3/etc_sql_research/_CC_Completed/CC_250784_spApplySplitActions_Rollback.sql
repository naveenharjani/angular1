USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROC [dbo].[spApplySplitActions] @SecurityId int = 0
AS
 -- ====================================================================================
 -- Author: Krishna Josyula
 -- Create date: 03/26/2008
 -- Description: Updates TargetPrice in TickerTableSecurities & TickerTablesecuritiesold
 --    Tables based on the split adjustment factor.
 -- Revised: 06/12/2013
 -- Apply splits only when the effective date of the split less than or equal to current date.
 -- ====================================================================================

BEGIN
DECLARE @AdjustmentFactor decimal(10,6)
DECLARE @EffectiveDate datetime
DECLARE @SplitActionId int
DECLARE @Ticker varchar(10)
DECLARE @FinancialNumberTypeId INT

SET NOCOUNT ON
IF @SecurityId = 0
 SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId
ELSE
 SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE SecurityId = @SecurityId and AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId

 WHILE (@@rowcount > 0)
 BEGIN

 --STEP 1: Update TargetPriceOrig to original value in TickerTableSecurities, TickerTableSecuritiesOld, FinancialNumbers & PublicationFinancials 
  --This is only done once for every qualified record

  Update TickerTableSecurities
  Set TargetPriceOrig = TargetPrice
  Where
   TargetPriceOrig is null and
   CloseDate <= @EffectiveDate and
   Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  Update TickerTableSecuritiesOld
  Set TargetPriceOrig = TTSO.TargetPrice
  From
   TickerTableSecurities TTS JOIN TickerTableSecuritiesOld TTSO ON TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
  Where
   TTSO.TargetPrice is not null and
   TTSO.TargetPrice <> '' and
   TTSO.TargetPriceOrig is null and
   TTS.CloseDate <= @EffectiveDate and
   TTSO.Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  SELECT @FinancialNumberTypeId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'TARGETPRICE'

  Update FinancialNumbers
  Set ValueOrig = Value
  Where SecurityId = @SecurityId
    and FinancialNumberTypeId = @FinancialNumberTypeId
    and IsDraft = 0
    and ValueOrig is null
    and Date <= @EffectiveDate
    and Date >= '2003-03-20'

  Update PublicationFinancials
  Set TargetPriceOrig = TargetPrice
  Where
   TargetPriceOrig is null and
   CloseDate <= @EffectiveDate and
   SecurityId = @SecurityId and
   CloseDate >= '2003-03-20'
  
  --STEP 2:
  --Update TargetPrice column with the adjustment factor for all the records in TickerTableSecurities, TickerTableSecuritiesOld, FinancialNumbers & PublicationFinancials 
  --prior to the split date
  Update TickerTableSecurities
  Set TargetPrice  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TargetPrice) / @adjustmentfactor)))
  Where
   CloseDate <= @EffectiveDate and
   Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  Update FinancialNumbers
  SET Value  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),Value) / @adjustmentfactor))),
      UnitValue  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),UnitValue) / @adjustmentfactor)))
  Where SecurityId = @SecurityId
    and FinancialNumberTypeId = @FinancialNumberTypeId
    and IsDraft = 0
    and Date <= @EffectiveDate
    and Date >= '2003-03-20'

  Update PublicationFinancials
  Set TargetPrice  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TargetPrice) / @adjustmentfactor)))
  Where
   CloseDate <= @EffectiveDate and
   SecurityId = @SecurityId and
   CloseDate >= '2003-03-20'

  
  Update TickerTableSecuritiesOld
  Set TargetPrice  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TTSO.TargetPrice) / @adjustmentfactor)))
  From
   TickerTableSecurities TTS JOIN TickerTableSecuritiesOld TTSO ON TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
  Where
   TTSO.TargetPrice is not null and
   TTSO.TargetPrice <> '' and
   TTS.CloseDate <= @EffectiveDate and
   TTSO.Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  --STEP 3:
  --Update Status to 'Applied'
  Update SplitActions
  Set AppliedStatus = 'Y' ,AppliedDate = getdate()
  Where
   SplitActionId = @SplitActionId

  IF @SecurityId = 0
   SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE SplitActionId > @SplitActionId AND AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId
  ELSE
   SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE SecurityId = @SecurityId AND SplitActionId > @SplitActionId and AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId
 END
END


