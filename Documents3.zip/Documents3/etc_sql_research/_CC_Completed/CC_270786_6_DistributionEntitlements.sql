--DistributionEntitlements.sql
--12/08/2017

/*

- Move RIXML entitlement from DistributionSubscriptions to DistributionEntitlements
- RIXML entitlements are no longer publication type specific

DistributionEntitlements  - Drop column PublicationTypeId
DistributionSubscriptions - Drop column RixmlEntitlement
spGetPropertiesXML_RX2
spGetDistributionSubscription
spSaveDistributionSubscription
spSearchDistributionSubscriptions

*/

USE Research
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

--drop unique index key
if exists(select * from sys.indexes where name = 'PK_DistributionEntitlements')
begin
drop index PK_DistributionEntitlements on DistributionEntitlements
end
go

--drop foreign key constraint to ProductGroups table
if exists(select * from sys.foreign_keys where name = 'FK_DistributionEntitlements_ProductGroups')
begin
  alter table DistributionEntitlements
  drop constraint FK_DistributionEntitlements_ProductGroups
end
go

--drop foreign key constraint to PublicationTypes table
if exists(select * from sys.foreign_keys where name = 'FK_DistributionEntitlements_PublicationTypes')
begin
  alter table DistributionEntitlements
  drop constraint FK_DistributionEntitlements_PublicationTypes
end
go

--drop PublicationTypeId column from DistributionEntitlements table
if exists(select * from sys.columns where name = 'PublicationTypeId' and object_id = object_id('DistributionEntitlements'))
begin
  alter table DistributionEntitlements
  drop column PublicationTypeId
end
go

--Make ProductGroupId column nullable
alter table DistributionEntitlements alter column ProductGroupId int null
go

--drop RixmlEntitlement column from DistributionSubscriptions table
if exists(select * from sys.columns where name = 'RixmlEntitlement' and object_id = object_id('DistributionSubscriptions'))
begin
  alter table DistributionSubscriptions
  drop column RixmlEntitlement
end
go
/*
--Thomson Reuters
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 9,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 9,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 9,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 9,15,'QUANT'
go

--Blue Matrix
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 20,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 20,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 20,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 20,15,'QUANT'
go

-- Visible Alpha
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 21,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 21,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 21,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 21,15,'QUANT'
go

-- RSRCHXchange
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 22,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 22,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 22,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 22,15,'QUANT'
go

-- Red Deer
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 23,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 23,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 23,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 23,15,'QUANT'
go

-- American Century
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 24,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 24,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 24,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 24,15,'QUANT'
go



--Poulate "All Research" rows for all portals
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 3,null,'BLOOMBERG_CLASS=0051'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 9,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 11,null,'CIQ1'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 12,null,'FACTSET1'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 13,null,'TMC1'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 15,null,'BLOOMBERG_CLASS=0051'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 20,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 21,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 22,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 23,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement)
select 24,null,'ALL'
go
*/
ALTER PROCEDURE [dbo].[spGetPropertiesXML_RX2]
  @PubNo int,
  @SiteId int
AS
DECLARE @Codeset varchar(10)
DECLARE @PublicationTypeId int

SELECT @Codeset = Codeset FROM DistributionSites WHERE SiteId = @SiteId

IF NOT EXISTS (SELECT * FROM Publications WHERE PubNo = @PubNo)
  BEGIN
    SELECT @PublicationTypeId = PublicationTypeId FROM PublicationsLog P JOIN PublicationTypes PT ON P.Type = PT.PublicationType WHERE P.Pubno = @Pubno

    SET NOCOUNT ON
    SELECT
      1                          AS tag,
      null                       AS parent,
      P.pubNo                    AS [Publication!1!pubNo],
      CONVERT(varchar, P.Date, 101) AS [Publication!1!date],
      P.Type                     AS [Publication!1!type],
      PT.PublicationTypeId       AS [Publication!1!typeId],
      P.Title                    AS [Publication!1!title],
      P.FileName                 AS [Publication!1!fileName],
      D.FileName                 AS [Publication!1!fileNameDoc],
      P.Approver                 AS [Publication!1!approver],
      CONVERT(varchar, P.ApprovedDate,101)  + ' ' + CONVERT(varchar, P.ApprovedDate,108)  AS [Publication!1!approvedDate],
      CONVERT(varchar, P.PublishedDate,101) + ' ' + CONVERT(varchar, P.PublishedDate,108) AS [Publication!1!publishedDate],
      P.Version                  AS [Publication!1!version],
      ISNULL(P.Instructions,0)   AS [Publication!1!instructions],
      null                       AS [Properties!2!!element],
      null                       AS [Property!3!name],
      null                       AS [Property!3!value],
      null                       AS [Property!3!!hide],
      null                       AS [Property!3!!hide]
    FROM PublicationsLog P WITH(NOLOCK) JOIN PublicationTypes PT WITH(NOLOCK) ON PT.PublicationType = P.Type
    JOIN DocumentsLog D WITH(NOLOCK) ON P.Pubno = D.Pubno AND (D.DocType = 'DOC' OR D.DocType = 'DOCX')
    WHERE P.PubNo = @PubNo

    UNION ALL

    SELECT
      2                          AS tag,
      null                       AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Organization',
      isnull(RixmlOrgIdType,'') + ';' + isnull(RixmlOrgId,''),
      -4,
      -4
    FROM DistributionSites
    WHERE SiteId = @SiteId

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Entitlement',
      isnull(RixmlEntitlement,''),
     -3,
     -3
    FROM DistributionEntitlements
    WHERE SiteId = @SiteId
    AND ProductGroupId IS NULL

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Entitlement',
      isnull(RixmlEntitlement,''),
     -3,
     -3
    FROM DistributionEntitlements
    WHERE SiteId = @SiteId
    AND ProductGroupId in (SELECT ProductGroupId FROM ProductGroupDocuments WHERE PubNo = @Pubno)

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Keyword',
      isnull(RixmlKeyword,''),
      -2,
      -2
    FROM DistributionSubscriptions
    WHERE SiteId = @SiteId
    AND PublicationTypeId = @PublicationTypeId
    AND Active = -1

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'WatermarkText',
      isnull(WaterMarkText,''),
      -1,
      -1
    FROM DistributionSites
    WHERE SiteId = @SiteId

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'FileVersion',
      ISNULL(CONVERT(varchar,MAX(ISNULL(DF.FileVersion,0))),'0'),
      0,
      0
    FROM   DistributionFiles DF WITH (NOLOCK)
    JOIN   DistributionQueue DQ WITH (NOLOCK) ON DQ.DistributionId = DF.DistributionId
    WHERE  DQ.PubNo = @PubNo AND DQ.SiteId = @SiteId
    AND SUBSTRING(DF.FileName, charindex('.',DF.FileName) + 1, len(DF.FileName) - charindex('.',DF.FileName)  ) = 'xml'

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      CASE PN.PropName
        WHEN 'Keywords' THEN 'ResearchKeywords'
        ELSE PN.PropName
      END,
      CASE PN.PropName
        WHEN 'Industry' THEN ISNULL(CONVERT(varchar,I.IndustryId),'') + ';' + I.IndustryName
        WHEN 'Author'   THEN ISNULL(CONVERT(varchar,A.AuthorId),'') + ';' + A.Name + ';' + A.First + ';' + A.Last + ';' + A.Phone + ';' + A.ExtEmail  + ';' + Convert(Varchar,A.IsAnalyst)
        WHEN 'Ticker'   THEN ISNULL(CONVERT(varchar,S2.SecurityId),'') + ';' + S2.RIC + ';RIC;' + S2.Company + ';' + S2.CountryCode + ';' + C.Country + ';' +   CASE WHEN CHARINDEX('.',S2.Ticker,1) > 0 THEN S2.Ticker ELSE S2.Ticker + '.US' END
        WHEN 'Keywords' THEN ISNULL(PV.PropValue, '')
        ELSE ''
      END,
      PV.PropNo,
      PS.SeqNo
    FROM PropertySets PS     WITH(NOLOCK)
    LEFT JOIN PropertiesLog PV  WITH(NOLOCK) ON PV.PropId = PS.PropId AND PV.PubNo = @PubNo
    LEFT JOIN Industries I   WITH(NOLOCK) ON I.IndustryName = PV.PropValue
    LEFT JOIN Authors A      WITH(NOLOCK) ON A.Name = PV.PropValue
    LEFT JOIN Securities2 S2 WITH(NOLOCK) ON S2.Ticker = PV.PropValue
    LEFT JOIN Countries C    WITH(NOLOCK) ON S2.CountryCode = C.CountryCode
    JOIN PropertyNames PN    WITH(NOLOCK) ON PN.PropId = PS.PropId
    WHERE PS.PublicationTypeId IN (SELECT PT.PublicationTypeId FROM PublicationsLog P WITH(NOLOCK) JOIN PublicationTypes PT WITH(NOLOCK) ON PT.PublicationType = P.Type WHERE P.PubNo = @PubNo)
    AND PN.PropId IN (5, 9, 11,13)  AND PV.PropValue NOT IN (SELECT TICKER FROM Securities2 WHERE TickerType = 'Index')

    ORDER BY 1, 19, 18, 17
    FOR XML Explicit

END

IF EXISTS (SELECT * FROM Publications WHERE PubNo = @PubNo)
  BEGIN
SET NOCOUNT ON

    SELECT @PublicationTypeId = PublicationTypeId FROM Publications P JOIN PublicationTypes PT ON P.Type = PT.PublicationType WHERE P.Pubno = @Pubno

    SELECT
      1                          AS tag,
      null                       AS parent,
      P.pubNo                    AS [Publication!1!pubNo],
      CONVERT(varchar, P.Date, 101) AS [Publication!1!date],
      P.Type                     AS [Publication!1!type],
      PT.PublicationTypeId       AS [Publication!1!typeId],
      P.Title         AS [Publication!1!title],
      P.FileName                 AS [Publication!1!fileName],
      D.FileName                 AS [Publication!1!fileNameDoc],
      P.Approver                 AS [Publication!1!approver],
      CONVERT(varchar, P.ApprovedDate,101)  + ' ' + CONVERT(varchar, P.ApprovedDate,108)  AS [Publication!1!approvedDate],
      CONVERT(varchar, P.PublishedDate,101) + ' ' + CONVERT(varchar, P.PublishedDate,108) AS [Publication!1!publishedDate],
      P.Version                  AS [Publication!1!version],
      ISNULL(P.Instructions,0)   AS [Publication!1!instructions],
      null                       AS [Properties!2!!element],
      null                       AS [Property!3!name],
      null                       AS [Property!3!value],
      null                       AS [Property!3!!hide],
      null                       AS [Property!3!!hide]
    FROM Publications P WITH(NOLOCK) JOIN PublicationTypes PT WITH(NOLOCK) ON PT.PublicationType = P.Type
    JOIN Documents D WITH(NOLOCK) ON P.Pubno = D.Pubno AND (D.DocType = 'DOC' OR D.DocType = 'DOCX')
    WHERE P.PubNo = @PubNo

    UNION ALL

    SELECT
      2                          AS tag,
      null                       AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Organization',
      isnull(RixmlOrgIdType,'') + ';' + isnull(RixmlOrgId,''),
      -4,
      -4
    FROM DistributionSites
    WHERE SiteId = @SiteId

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Entitlement',
      isnull(RixmlEntitlement,''),
     -3,
     -3
    FROM DistributionEntitlements
    WHERE SiteId = @SiteId AND
    ProductGroupId IS NULL

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'Entitlement',
      isnull(RixmlEntitlement,''),
     -3,
     -3
    FROM DistributionEntitlements
    WHERE SiteId = @SiteId
    AND ProductGroupId in (SELECT ProductGroupId FROM ProductGroupDocuments WHERE PubNo = @Pubno)

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'WatermarkText',
      isnull(WaterMarkText,''),
      -1,
      -1
    FROM DistributionSites
    WHERE SiteId = @SiteId

    UNION ALL

    SELECT DISTINCT
      3         AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'PDFLock',
      isnull(PDFLock,''),
      -1,
      -1
    FROM DistributionSites
    WHERE SiteId = @SiteId

    UNION ALL
    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      'FileVersion',
      ISNULL(CONVERT(varchar,MAX(ISNULL(DF.FileVersion,0))),'0'),
      0,
      0
    FROM   DistributionFiles DF WITH (NOLOCK)
    JOIN   DistributionQueue DQ WITH (NOLOCK) ON DQ.DistributionId = DF.DistributionId
    WHERE  DQ.PubNo = @PubNo AND DQ.SiteId = @SiteId
    AND SUBSTRING(DF.FileName, charindex('.',DF.FileName) + 1, len(DF.FileName) - charindex('.',DF.FileName)  ) = 'xml'

    UNION ALL

    SELECT DISTINCT
      3                          AS tag,
      2                          AS parent,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      CASE PN.PropName
        WHEN 'Keywords' THEN 'ResearchKeywords'
        ELSE PN.PropName
      END,
      CASE PN.PropName
        WHEN 'Industry' THEN ISNULL(CONVERT(varchar,I.IndustryId),'') + ';' + I.IndustryName
        WHEN 'Author'   THEN ISNULL(CONVERT(varchar,A.AuthorId),'') + ';' + A.Name + ';' + A.First + ';' + A.Last + ';' + A.Phone + ';' + A.ExtEmail  + ';' + Convert(Varchar,A.IsAnalyst)
        WHEN 'Ticker'   THEN ISNULL(CONVERT(varchar,S2.SecurityId),'') + ';' + S2.RIC + ';RIC;' + S2.Company + ';' + S2.CountryCode + ';' + C.Country + ';' +   CASE WHEN CHARINDEX('.',S2.Ticker,1) > 0 THEN S2.Ticker ELSE S2.Ticker + '.US' END
        WHEN 'Keywords'  THEN ISNULL(PV.PropValue, '')
        ELSE ''
      END,
      PV.PropNo,
      PS.SeqNo
    FROM PropertySets PS     WITH(NOLOCK)
    LEFT JOIN Properties PV  WITH(NOLOCK) ON PV.PropId = PS.PropId AND PV.PubNo = @PubNo
    LEFT JOIN Industries I   WITH(NOLOCK) ON I.IndustryName = PV.PropValue
    LEFT JOIN Authors A      WITH(NOLOCK) ON A.Name = PV.PropValue
    LEFT JOIN Securities2 S2 WITH(NOLOCK) ON S2.Ticker = PV.PropValue
    LEFT JOIN Countries C    WITH(NOLOCK) ON S2.CountryCode = C.CountryCode
    JOIN PropertyNames PN    WITH(NOLOCK) ON PN.PropId = PS.PropId
    WHERE PS.PublicationTypeId IN (SELECT PT.PublicationTypeId FROM Publications P WITH(NOLOCK) JOIN PublicationTypes PT WITH(NOLOCK) ON PT.PublicationType = P.Type WHERE P.PubNo = @PubNo)
    AND PN.PropId IN (5, 9, 11,13)  AND PV.PropValue NOT IN (SELECT TICKER FROM Securities2 WHERE TickerType = 'Index')

    ORDER BY 1, 19, 18, 17
    FOR XML Explicit
  END

go

ALTER PROCEDURE [dbo].[spGetDistributionSubscription]
  @SubscriptionId    int,
  @SiteId            int          OUTPUT,
  @PublicationTypeId int          OUTPUT,
  @DelayMinutes      int          OUTPUT,
  @EmbargoMinutes    int          OUTPUT,
  @RixmlKeyword      varchar(100) OUTPUT,
  @Active            int          OUTPUT,
  @Editor            varchar(36)  OUTPUT,
  @EditDate          datetime     OUTPUT
AS
SELECT
  @SiteId            = SU.SiteId,
  @PublicationTypeId = SU.PublicationTypeId,
  @DelayMinutes      = (SELECT Value FROM Configuration WHERE Name = 'DistributionDelayMinutes'),
  @EmbargoMinutes    = SU.EmbargoMinutes,
  @RixmlKeyword      = SU.RixmlKeyword,
  @Active            = SU.Active,
  @Editor            = E.UserName,
  @EditDate          = SU.EditDate
FROM DistributionSubscriptions SU
LEFT JOIN Users E ON E.UserId = SU.EditorId
WHERE SU.SubscriptionId = @SubscriptionId
GO

ALTER PROCEDURE [dbo].[spSaveDistributionSubscription]
  @SubscriptionId    int OUTPUT,
  @SiteId            int,
  @PublicationTypeId int,
  @EmbargoMinutes    int,
  @RixmlKeyword      varchar(100),
  @Active            int,
  @EditorId          int
AS
DECLARE @EditDate datetime
SELECT  @EditDate = GETDATE()
BEGIN TRANSACTION
IF EXISTS (SELECT SubscriptionId FROM DistributionSubscriptions WHERE SubscriptionId = @SubscriptionId)
  BEGIN
    UPDATE DistributionSubscriptions SET
      SiteId            = @SiteId,
      PublicationTypeId = @PublicationTypeId,
      EmbargoMinutes    = @EmbargoMinutes,
      RixmlKeyword      = @RixmlKeyword,
      Active            = @Active,
      EditorId          = @EditorId,
      EditDate          = @EditDate
    WHERE SubscriptionId = @SubscriptionId
  END
ELSE
  BEGIN
    INSERT INTO DistributionSubscriptions
      (SiteId,  PublicationTypeId,  EmbargoMinutes,  RixmlKeyword,  Active,  EditorId,  EditDate)
    VALUES
      (@SiteId, @PublicationTypeId, @EmbargoMinutes, @RixmlKeyword, @Active, @EditorId, @EditDate)
    SELECT @SubscriptionId = @@IDENTITY
  END
COMMIT TRANSACTION
RETURN 0
GO

ALTER PROCEDURE [dbo].[spSearchDistributionSubscriptions]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
DECLARE @StandardDelay int
SELECT @StandardDelay = Value FROM Configuration WHERE Name = 'DistributionDelayMinutes'
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'
CREATE TABLE #TmpSearch
(
  ID                int IDENTITY,
  SubscriptionId    int,
  Site              varchar(32),
  PublicationType   varchar(31),
  EmbargoMinutes    int,
  NumExceptions     int,
  RixmlKeyword      varchar(100),
  Active            int,
  Editor            varchar(36) NULL,
  EditDate          datetime    NULL
)
INSERT INTO #TmpSearch (SubscriptionId, Site, PublicationType, EmbargoMinutes, NumExceptions,  RixmlKeyword, Active, Editor, EditDate)
EXEC
('
SELECT
  SU.SubscriptionId,
  SI.Site,
  PT.PublicationType,
  EmbargoMinutes = ISNULL(SU.EmbargoMinutes, ' + @StandardDelay + '),
  NumExceptions  = (SELECT COUNT(*) FROM DistributionExceptions WHERE SubscriptionId = SU.SubscriptionId),
  SU.RixmlKeyword,
  SU.Active,
  E.UserName,
  SU.EditDate
FROM DistributionSubscriptions SU
JOIN DistributionSites SI ON SI.SiteId = SU.SiteId
JOIN PublicationTypes PT ON PT.PublicationTypeId = SU.PublicationTypeId
LEFT JOIN Users E ON E.UserId = SU.EditorId
ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT SubscriptionId, Site, PublicationType, EmbargoMinutes, NumExceptions,  RixmlKeyword, Active, Editor, EditDate
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF
GO

/*

select * from DistributionSites

select * from DistributionEntitlements order by SiteId, ProductGroupId

select * from DistributionSubscriptions

*/
