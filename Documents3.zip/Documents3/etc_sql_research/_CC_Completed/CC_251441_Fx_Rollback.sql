-- Fx_Rollback.sql
-- 03/10/2017

/*

spGetBloombergSecurities
vBloombergFXLatest
vFxLatest

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO


-- =======================================================================
-- Author:	Naveen Harjani
-- Create date:	5/19/2008
-- Description:	Get the list of security tickers and index for the request
--------------------------------------------------------------------------
-- Revision Dt  | Comments
--------------------------------------------------------------------------
-- 02/26/10      Get Currency TickerCodes as required for the FX Rates Ticker list needs.
--------------------------------------------------------------------------
-- =======================================================================

ALTER PROCEDURE [dbo].[spGetBloombergSecurities] 
  @RequestTypeCode	VARCHAR(6)
AS
BEGIN
SET NOCOUNT ON

IF @RequestTypeCode = 'ALLSEC'			--All Securities
BEGIN
  SELECT SecurityId, Ticker
    FROM dbo.Securities2
   ORDER BY Ticker

/*  
    SELECT 'Identifier' =  Ticker,  'Market Sector' = 'Equity'
    FROM dbo.Securities2
    ORDER BY Identifier
*/    
   
END

ELSE IF @RequestTypeCode = 'COVSEC'		--Covered Securities
BEGIN
  SELECT S.SecurityId, Ticker
    FROM ResearchCoverage R, Securities2 S
   WHERE R.SecurityID = S.SecurityID
     AND DropDate is NULL
   ORDER BY Ticker

/*
  SELECT 'Identifier' =  Ticker,  'Market Sector' = 'Equity'
    FROM ResearchCoverage R, Securities2 S
   WHERE R.SecurityID = S.SecurityID
     AND DropDate is NULL
   ORDER BY Identifier
*/   
   
END

ELSE IF @RequestTypeCode = 'FXSEC'		--Currency Codes
BEGIN
  SELECT BloombergSecurityID AS SecurityId, Identifier AS Ticker, 'Curncy' AS TickerExtension
    FROM BloombergSecurities
    WHERE SecurityTypeCode = 'FXSEC'
   ORDER BY Ticker

/*
  SELECT 'Identifier' =  Identifier,  'Market Sector' = 'Curncy'
    FROM BloombergSecurities
    WHERE SecurityTypeCode = 'FXSEC'
   ORDER BY Identifier
*/
END

-- Get indexes
/*
SELECT SecurityId, Ticker, TickerType, Company
  FROM dbo.Securities2
  WHERE TickerType = 'INDEX'
ORDER BY Ticker
*/

IF @RequestTypeCode = 'ALLSEC' OR @RequestTypeCode = 'COVSEC'
BEGIN
  SELECT DISTINCT BenchmarkIndex as Ticker
    FROM dbo.Securities2 
   WHERE BenchmarkIndex is not null

/*
  SELECT DISTINCT BenchmarkIndex as 'Identifier',  'Market Sector' = 'Index'
    FROM dbo.Securities2 
   WHERE BenchmarkIndex is not null
   ORDER BY Identifier
*/   
   
END

SET NOCOUNT OFF
END

GO



-- =======================================================================
-- Author:  Naveen Harjani
-- Create date:  8/4/2008
-- Description:  Get the latest marketdata pricing data.
-- 11/23/2015 : Includes FX Rate for minor currency tickers - USDGBp
-- =======================================================================
ALTER VIEW [dbo].[vBloombergFXLatest]
AS
SELECT TOP 100 PERCENT
       md.Ticker,
       bf.Mnemonic AS BloombergMnemonic,
       md.RunDate AS DateAsOf,
       md.Value,
       md.LoadDate AS DateCreated,
       ps.BloombergSecurityID AS SecurityId,
       bf.FieldId, ps.securitytypecode
FROM   dbo.BloombergPivotFX md
INNER JOIN (SELECT     MAX(md2.Ticker) AS Ticker, MAX(md2.RunDate) AS LatestRunDate
      FROM  dbo.BloombergPivotFX md2
      WHERE FieldId in (SELECT FieldId FROM BloombergFields WHERE RequestTypeID IN (SELECT RequestTypeID FROM BloombergRequestTypes WHERE RequestTypeCode = 'FXP'))
      GROUP BY md2.Ticker) md_latest
      ON md.Ticker = md_latest.Ticker AND md.RunDate = md_latest.LatestRunDate
INNER JOIN dbo.BloombergFields bf ON md.FieldId = bf.FieldId
INNER JOIN dbo.BloombergSecurities ps ON md.Ticker = ps.Identifier

UNION

SELECT TOP 100 PERCENT
       CASE WHEN md.Ticker = 'USDGBP' THEN 'USDGBp' COLLATE SQL_Latin1_General_CP1_CS_AS
            ELSE md.Ticker
       END as Ticker,
       bf.Mnemonic AS BloombergMnemonic,
       md.RunDate AS DateAsOf,
       CASE WHEN bf.Mnemonic IN ('PRIOR_CLOSE_MID','PX_LAST')
            THEN CONVERT(varchar, CAST(md.Value as FLOAT) * 100)
            ELSE md.Value
       END as Value,
       md.LoadDate AS DateCreated,
       ps.BloombergSecurityID AS SecurityId,
       bf.FieldId, ps.securitytypecode
FROM   dbo.BloombergPivotFX md
INNER JOIN (SELECT     MAX(md2.Ticker) AS Ticker, MAX(md2.RunDate) AS LatestRunDate
      FROM  dbo.BloombergPivotFX md2
      WHERE FieldId in (SELECT FieldId FROM BloombergFields WHERE RequestTypeID IN (SELECT RequestTypeID FROM BloombergRequestTypes WHERE RequestTypeCode = 'FXP'))
      AND Ticker IN ('USDGBP')
      GROUP BY md2.Ticker) md_latest
      ON md.Ticker = md_latest.Ticker AND md.RunDate = md_latest.LatestRunDate
INNER JOIN dbo.BloombergFields bf ON md.FieldId = bf.FieldId
INNER JOIN dbo.BloombergSecurities ps ON md.Ticker = ps.Identifier

ORDER BY md.Ticker, bf.Mnemonic


GO




IF EXISTS(SELECT * FROM SYS.views WHERE name = 'vFXLatest' AND type = 'V')
DROP VIEW [dbo].[vFXLatest]
GO





-- =======================================================================
-- Author:	Naveen Harjani
-- Create date:	02/26/2010
-- Description:	Retrieves the latest available marketdata formatted for fx.xml generation (pivotted)
-- 11/23/2015 : Includes FX Rate for minor currency tickers - USDGBp
-- =======================================================================
ALTER PROCEDURE [dbo].[spGetBloombergFXRatesForXml] AS
BEGIN
	SET NOCOUNT ON

	DECLARE @cFXRequestTypeCode varchar(4)

	--Set the Request Id for the 'EOD FX' request for generating the FX xml
	SET @cFXRequestTypeCode = 'FXP'
	
	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	-- create hash for MarketdataFields table
	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	--select Mnemonic AS BloombergMnemonic, XmlAttribute, dataType 
	SELECT Mnemonic AS BloombergMnemonic, dataType 
	  INTO #tmp_MarketdataFields
    FROM BloombergFields
    WHERE RequestTypeID IN (SELECT RequestTypeID FROM BloombergRequestTypes WHERE RequestTypeCode = @cFXRequestTypeCode)

	--Check if the global temporary table "##tmpFXLatestFormattedData" exists, then drop the table.
	if exists (select  * from tempdb.dbo.sysobjects o where o.xtype in ('U') and o.id = object_id( N'tempdb..##tmpFXLatestFormattedData'))
	begin
		drop table ##tmpFXLatestFormattedData
	end

	--Check if the global temporary table "##tmpFXLatestXML" exists, then drop the table.
	if exists (select  * from tempdb.dbo.sysobjects o where o.xtype in ('U') and o.id = object_id( N'tempdb..##tmpFXLatestXML'))
	begin
		drop table ##tmpFXLatestXML
	end

	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	-- declare local variables
	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	declare @pivot_query varchar(8000)
	declare @BloombergMnemonic varchar(32)
	--declare @XmlAttribute varchar(64)
	declare @index int
	set @pivot_query = 'SELECT max(md.DateAsOf) AS dateAsOf,  max(CASE WHEN bs.Identifier IS NOT NULL THEN bs.Identifier COLLATE Latin1_General_CS_AS ELSE md.ticker END) AS ticker,  max(md.securitytypecode) AS securitytypecode, '

	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	-- construct pivot query string
	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	select @index=count(*) from #tmp_MarketdataFields
	--
	while (@index>0) 
	begin
	set rowcount 1	
		--select @BloombergMnemonic = BloombergMnemonic, @XmlAttribute = XmlAttribute  
		select @BloombergMnemonic = BloombergMnemonic
		from #tmp_MarketdataFields order by BloombergMnemonic		
		set @pivot_query = 	@pivot_query + 'max(CASE md.BloombergMnemonic WHEN ''' + @BloombergMnemonic + ''' THEN [Value] ELSE '''' END) AS ' + @BloombergMnemonic + ', '		
		set @index = @index-1
		delete from #tmp_MarketdataFields where BloombergMnemonic = @BloombergMnemonic
	end
	set rowcount 0
	-- trim the last comma and space (2 characters)
	set @pivot_query = substring(@pivot_query, 0, len(@pivot_query))

    --append into temp table
	set @pivot_query = @pivot_query + ' INTO ##tmpFXLatestFormattedData '

	-- append from statement
	set @pivot_query = @pivot_query + ' FROM BloombergSecurities BS '
	set @pivot_query = @pivot_query + ' FULL OUTER JOIN [vBloombergFXLatest] md  ON BS.Identifier = md.Ticker COLLATE SQL_Latin1_General_CP1_CS_AS '

	--set @pivot_query = @pivot_query + ' INNER JOIN BloombergSecurities s ON md.Ticker = s.Identifier'
	set @pivot_query = @pivot_query + ' GROUP BY md.ticker  ORDER BY MAX(md.Ticker)'
	
	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	-- execute pivot query
	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	exec (@pivot_query)
	--select(@pivot_query) -- debug
	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -

	--Apply column formatting to various xml fields as required for the marketdata.xml file
	SELECT *
  INTO    ##tmpFXLatestXML
  FROM	##tmpFXLatestFormattedData

  SELECT  * FROM ##tmpFXLatestXML

  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	-- clean up
	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	drop table ##tmpFXLatestFormattedData
	drop table ##tmpFXLatestXML
	drop table #tmp_MarketdataFields
	-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -

	SET NOCOUNT OFF
END


GO
