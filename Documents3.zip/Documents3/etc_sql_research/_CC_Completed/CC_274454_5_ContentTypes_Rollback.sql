-- CC_ContentTypes_Rollback.sql
-- 02/26/2018

USE Research
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where name like '%RVContentTypes%')
drop view dbo.RVContentTypes
go

if exists(select * from sys.objects where name = 'ContentTypes')
drop table ContentTypes
go

