-- Fx_Rollback.sql
-- 05/23/2017

/*


*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO



-- =======================================================================
-- Author:  Naveen Harjani
-- Create date:  5/19/2008
-- Description:  Get the list of security tickers and index for the request
--------------------------------------------------------------------------
-- Revision Dt   Comments
--------------------------------------------------------------------------
-- 02/26/10      Get Currency TickerCodes as required for the FX Rates Ticker list needs.
-- 03/02/17      Get FX Securities list dynamically. Alias value as START_OF_DATA
--------------------------------------------------------------------------
-- =======================================================================

ALTER PROCEDURE [dbo].[spGetBloombergSecurities]
  @RequestTypeCode VARCHAR(6)
AS
BEGIN
SET NOCOUNT ON

-- Populate START-OF-DATA Bloomberg .req file section
-- Ticker - AAPL US Equity
-- Index  - SPX Index
-- FX     - USDGBP Curncy

IF @RequestTypeCode = 'ALLSEC' --All Securities
BEGIN
  SELECT
    CASE
      WHEN CHARINDEX('.', Ticker) > 0
      THEN REPLACE(Ticker, '.', ' ') + ' Equity'
      ELSE Ticker + ' US Equity'
    END AS 'START-OF-DATA', 'T' AS Type
  FROM dbo.Securities2
  UNION
  SELECT DISTINCT BenchmarkIndex + ' Index' AS 'START-OF-DATA', 'I' AS Type
  FROM dbo.Securities2
  WHERE BenchmarkIndex IS NOT NULL
  ORDER BY 2 DESC, 1
END

ELSE IF @RequestTypeCode = 'COVSEC' --Covered Securities
BEGIN
  SELECT
    CASE
      WHEN CHARINDEX('.', Ticker) > 0
      THEN REPLACE(Ticker, '.', ' ') + ' Equity'
      ELSE Ticker + ' US Equity'
    END AS 'START-OF-DATA', 'T' AS Type
  FROM ResearchCoverage RC
  JOIN Securities2 S ON S.SecurityId = RC.SecurityId
  WHERE RC.DropDate IS NULL
  UNION
  SELECT DISTINCT BenchmarkIndex + ' Index' AS 'START-OF-DATA', 'I' AS Type
  FROM ResearchCoverage RC
  JOIN Securities2 S on S.SecurityId = RC.SecurityId
  WHERE RC.DropDate is NULL
  ORDER BY 2 DESC, 1
END

ELSE IF @RequestTypeCode = 'FXSEC' --FX Currency Codes
BEGIN

  -- Model cur : Pricing cur (when currencies are different)
  -- Sample use:  Convert E in P/E to currency of P
  select distinct FSS.CurCode + S.CurrencyCode + ' Curncy' AS 'START-OF-DATA'
  from ResearchCoverage RC
  join Securities2 S on S.SecurityId = RC.SecurityId
  join FinancialSecuritySettings FSS on FSS.SecurityId = RC.SecurityId
  where RC.DropDate is null
  and S.CurrencyCode <> FSS.CurCode

  -- Model cur : Pricing cur (when currencies are same)
  -- Do not request cross rate when both currencies are the same, i.e. value of 1
  -- Bloomberg ignores and will not return a value of 1.
  -- Synthesize value of 1 in view vBloombergFXLatest

union

  -- Pricing cur : USD
  -- Sample use:  Convert non-USD market cap to USD market cap for comparison, e.g. small cap coverage
  select distinct S.CurrencyCode + 'USD' + ' Curncy' AS 'START-OF-DATA'
  from ResearchCoverage RC
  join Securities2 S on S.SecurityId = RC.SecurityId
  where RC.DropDate is null
  and S.CurrencyCode <> 'USD'

  order by 1
END

SET NOCOUNT OFF
END


GO




/*

EXEC spGetBloombergSecurities 'FXSEC'
GO

*/