-- CC_spSearchResearchCoverage.sql
-- 07/17/2018

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSearchResearchCoverage]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT,
  @Style         int
AS
SET NOCOUNT ON

DECLARE @FirstRow int
DECLARE @LastRow  int
DECLARE @WHERE    varchar(2048)

IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'

IF @Style = 1 SET @WHERE = 'WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL' -- Launched, not dropped
IF @Style = 2 SET @WHERE = 'WHERE RC.DropDate IS NULL'                               -- Launched/unlaunched, not dropped
IF @Style = 3 SET @WHERE = ''                                                        -- Launched/unlaunched, dropped/not dropped
IF @Style = 4 SET @WHERE = 'WHERE RC.LaunchDate IS NOT NULL'                         -- Launched, dropped/not dropped

CREATE TABLE #TmpSearch
(
  ID           int IDENTITY,
  Industry     varchar(50)   NULL,
  Analyst      varchar(50)   NULL,
  Ticker       varchar(15)   NULL,
  Company      varchar(63)   NULL,
  LaunchDate   datetime      NULL,
  DropDate     datetime      NULL,
  Rating       char(1)       NULL,
  Target       varchar(10)   NULL, -- decimal(9, 2)
  Cur          varchar(3)    NULL,
  MetaAnalyst  varchar(48)   NULL,
  CoverageId   int           NULL,
  CUSIP        varchar(10)   NULL,
  SEDOL        varchar(10)   NULL,
  ISIN         varchar(12)   NULL
)
INSERT INTO #TmpSearch (Industry, Analyst, Ticker, Company, LaunchDate, DropDate, Rating, Target, Cur, MetaAnalyst, CoverageId, CUSIP, SEDOL, ISIN)
EXEC
(
'SELECT
  Industry    = I.IndustryName,
  Analyst     = A.Last + '', '' + A.First,
  Ticker      = S.Ticker,
  Company     = S.Company,
  LaunchDate  = RC.LaunchDate,
  DropDate    = RC.DropDate,
  Rating      = FL.Rating,
  Target      = CONVERT(varchar, FL.TargetPrice),
  Cur         = FL.Currency,
  MetaAnalyst = A.Name,
  CoverageId  = RC.CoverageId,
  CUSIP       = ISNULL(S.CUSIP, ''''),
  SEDOL       = ISNULL(S.SEDOL, ''''),
  ISIN        = ISNULL(S.ISIN, '''')
FROM ResearchCoverage RC
JOIN Industries I ON I.IndustryId = RC.IndustryId
JOIN Authors A ON A.AuthorId = RC.AnalystId
LEFT JOIN Securities2 S ON S.SecurityId = RC.SecurityId -- SecurityId OPTIONAL, THEREFORE LEFT JOIN
LEFT JOIN vFinancialsLatest FL ON FL.CoverageId = RC.CoverageId '
+ @WHERE
+ ' ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT Industry, Analyst, Ticker, Company, LaunchDate, DropDate, Rating, Target, Cur, MetaAnalyst, CoverageId, CUSIP, SEDOL, ISIN
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO

/*

-- DEBUG

sp_helptext spSearchResearchCoverage
go
spSearchResearchCoverage 1, 'a', 1, 5000, null, 1
go
spSearchResearchCoverage 1, 'a', 1, 5000, null, 2
go
spSearchResearchCoverage 1, 'a', 1, 5000, null, 3
go
spSearchResearchCoverage 8, 'a', 1, 5000, null, 4
go

*/

