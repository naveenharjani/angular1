-- 08/04/2019
-- vHoldings.sql

/*

alter vHoldings
alter Holdings - Add column Autonomous

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

--alter table Holdings
if not exists(select * from sys.columns where name = 'Autonomous' and object_id = object_id('Holdings'))
alter table dbo.Holdings
  add Autonomous varchar(10)
go

alter view [dbo].[vHoldings]
as

/*

The vHoldings view cross-references Star Compliance holdings with Bernstein/Autonomous coverage
to produce a filtered set of holdings in active covered securities by active authors.

Persons are translated from windows login to AuthorId.

Tickers are translated from ISIN to SecurityId.

*/

select distinct
 A.AuthorId
 ,V.SecurityId
 ,A.TypeId as Authors_TypeId
 ,V.TypeId as Securities_TypeId
 ,A.Last + ', ' + A.First as Author
 ,A.Name
 ,A.ExtEmail as Email
 ,V.Ticker
 ,V.Company
 ,A.Name + ' maintains a long position in ' + V.Company + ' (' + V.Ticker + ')' as [Text]
 -- Star Compliance columns
 ,H.EmployeeID
 ,H.EmployeeUserName
 ,H.EmployeeLastName
 ,H.EmployeeFirstName
 ,H.Description
 ,H.Cusip
 ,H.BloombergTicker
 ,H.ISIN
 ,H.SEDOL
 ,H.SecurityType
 ,H.HoldingQuantity
 ,H.UserAccountStatus
 ,H.LastExecution
 ,H.ReportRunDate
from Holdings H
-- Bernstein/Autonomous author coverage by windows login
join Authors A on  replace(ltrim(rtrim(A.WindowsUserName)),'ac\','') = ltrim(rtrim(H.EmployeeUserName)) and A.IsActive = -1
join
(
-- Active Bernstein ticker coverage by ISIN
select S.SecurityId, ISIN, Ticker, Company, TypeId from Securities2 S
join ResearchCoverage RC on RC.SecurityId = S.SecurityId and RC.DropDate is null
union
-- Active Autonomous ticker coverage by ISIN
select SecurityId, ISIN, Ticker, Company, TypeId from Securities2 S where TypeId = 2 and S.IsActive = -1
) V on ltrim(rtrim(V.ISIN)) = ltrim(rtrim(H.ISIN))
where H.EmployeeUserName is not null and ltrim(rtrim(H.EmployeeUserName)) <> ''
and H.ISIN is not null and ltrim(rtrim(H.ISIN)) <> ''

go
