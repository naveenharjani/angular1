-- Models.sql
-- 12/12/2017

/*
alter vModels                  - Add PriceCurrency, EpsCurrency
alter spGetModelChangeToolTip  - Add PriceCurrency, EpsCurrency

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

alter view dbo.vModels
as
  select
    M.ModelId,
    RC.CoverageId,
    RC.SecurityId,
    S.Ticker,
    S.CompanyId,
    S.Company,
    RC.AnalystId,
    A.Last + ', ' + A.First Analyst,
    AR.RegionId,
    AR.Region,
    M.FileName,
    substring(M.FileName,charindex('.',M.FileName) + 1,10) FileType,
    M.FileSize,
    M.ActionId,
    case when PF.RatingAction = 'Initiate' then 'Coverage Initiation' else MA.Action end Action,
    case when RC.ModelDistribution = 'Y' then M.StateId else 0 end StateId,
    case when RC.ModelDistribution = 'N' then 'Excluded' when M.StateId = 3 then 'Deleted' else MS.State end State,

    -- Model details when promoted by change report
    M.PubNo,
    P.Title,
    P.FileName ReportFileName,
    PF.Rating,
    PF.RatingPrior,
    PF.RatingAction,
    PF.TargetPrice,
    PF.TargetPricePrior,
    PF.TargetPriceAction,
    PF.BaseYear,
    PF.EPSFY1,
    PF.EPSFY1Prior,
    PF.EPSFY1Action,
    PF.EPSFY2,
    PF.EPSFY2Prior,
    PF.EPSFY2Action,
    M.EditorId,
    M.EditDate,
    U.UserName DeletedByUser,
    MD.EditDate DeletedDate,
    PF.PriceCurrency,
    PF.EpsCurrency
  from ResearchCoverage RC
  join Securities2 S on S.SecurityId = RC.SecurityId and S.IsPrimary = 'Y'
  join Authors A on A.AuthorId = RC.AnalystId
  left outer join AuthorRegions AR on AR.RegionId = A.RegionId
  left outer join Models M on M.SecurityId = RC.SecurityId and M.AnalystId = RC.AnalystId
  left outer join ModelStates MS on MS.StateId = M.StateId
  left outer join ModelActions MA on MA.ActionId = M.Actionid
  left outer join PublicationFinancials PF on M.PubNo = PF.PubNo and M.SecurityId = PF.SecurityId
  left outer join Publications P on M.PubNo = P.Pubno
  left outer join ModelDeletions MD on M.ModelId = MD.ModelId
  left outer join Users U on MD.EditorId = U.UserId
  where  RC.LaunchDate is not null and RC.DropDate is null
go

alter procedure dbo.spGetModelChangeToolTip
@ModelId int
as
begin
select top 1
    Rating,
    RatingPrior,
    RatingAction,
    PriceCurrency,
    EpsCurrency,
    format(cast(TargetPrice AS money), '#,###0.#0;(#,###0.#0)')TargetPrice,
    format(cast(TargetPricePrior AS money), '#,###0.#0;(#,###0.#0)')TargetPricePrior,
    TargetPriceAction,
    format(cast(cast(TargetPrice as  float) - cast(TargetPricePrior as  float) AS money), '#,###0.#0;(#,###0.#0)') TargetPriceDelta,
    format(cast(EPSFY1 AS money), '#,###0.#0;(#,###0.#0)')EPSFY1,
    format(cast(EPSFY1Prior AS money), '#,###0.#0;(#,###0.#0)') EPSFY1Prior,
    EPSFY1Action,
    format(cast(cast(EPSFY1 as  float) - cast(EPSFY1Prior as  float) AS money), '#,###0.#0;(#,###0.#0)') EPSFY1Delta,
    format(cast(EPSFY2 AS money), '#,###0.#0;(#,###0.#0)')EPSFY2,
    format(cast(EPSFY2Prior AS money), '#,###0.#0;(#,###0.#0)')EPSFY2Prior,
    EPSFY2Action,
    format(cast(cast(EPSFY2 as  float) - cast(EPSFY2Prior as  float) AS money), '#,###0.#0;(#,###0.#0)') EPSFY2Delta,
    BaseYear+1 as EPSFY1Label,
    BaseYear+2 as EPSFY2Label
from vModels
where ModelId = @ModelId
end
go
