-- RVAnalysts_Rollback.sql
-- 06/14/2018

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- RVAnalysts - add RegionId attribute that identifies the region of an analyst. 

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVAnalysts]'))
DROP VIEW [dbo].[RVAnalysts]
GO

CREATE VIEW [dbo].[RVAnalysts] WITH SCHEMABINDING AS
SELECT
  AnalystId = isnull(convert(int, AuthorId),0),
  Name,
  Last,
  First,
  Phone,
  Email = ExtEmail,
  WindowsUserName,
  Status,                  -- iPad app Watch List - Picklist displays active coverage where Status is 1
  RefreshDate = EditDate,  -- iPad app Watch List - Refresh (additions, subtractions, modifications) when RefreshDate > WL RefreshDate
  RegionId,
  GoUrl
FROM
  dbo.Authors
WHERE
  IsAnalyst = -1 and
  IsResearch in ('Y','*')


GO

CREATE UNIQUE CLUSTERED INDEX RVAnalysts_AnalystId ON [dbo].[RVAnalysts](AnalystId ASC)
GO


