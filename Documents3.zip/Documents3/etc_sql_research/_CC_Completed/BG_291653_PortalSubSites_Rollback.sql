-- PortalSubSites_Rollback.sql
-- 09/18/2018

/*

create table PortalSubSites        - New table which holds sub sites for portals

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalSubSites]') AND type in (N'U'))
DROP TABLE [dbo].[PortalSubSites]
GO