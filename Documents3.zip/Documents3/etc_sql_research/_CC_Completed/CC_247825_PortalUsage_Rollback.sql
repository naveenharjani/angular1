-- PortalUsage_Rollback.sql
-- 09/22/2016

/*

Tables:  (Staging table to store csv columns as varchar(500) for SSIS loads)
PortalUsageStaging_TR
PortalUsageStaging_CIQ
PortalUsageStaging_FactSet
PortalUsageStaging_Bloomberg

Procedures: (Called by SSIS package)
spResetPortalUsageStaging_TR
spResetPortalUsageStaging_CIQ
spResetPortalUsageStaging_FactSet
spResetPortalUsageStaging_Bloomberg

spLoadPortalUsageFromStaging_TR
spLoadPortalUsageFromStaging_CIQ
spLoadPortalUsageFromStaging_FactSet
spLoadPortalUsageFromStaging_Bloomberg

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- Tables - Portals staging
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_TR]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_TR]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_CIQ]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_CIQ]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_FactSet]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_FactSet]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_Bloomberg]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_Bloomberg]
GO

-- Procedures - Reset/Cleanup data
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_TR]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spResetPortalUsageStaging_TR]
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_CIQ]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spResetPortalUsageStaging_CIQ]
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_FactSet]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spResetPortalUsageStaging_FactSet]
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_Bloomberg]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spResetPortalUsageStaging_Bloomberg]
GO

-- Procedures - Load data
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_TR]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_CIQ]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_FactSet]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_Bloomberg]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
GO