-- AutonomousExport.sql
-- 01/03/2019

/*

alter vHoldings

-- Coverage.xml
create spExportCoverageAuthors
create spExportCoverageSecurities

- Disclosures.xml
create spExportAuthorTextDisclosures
create spExportSecurityTextDisclosures
create spExportFirmDisclosures
create spExportHoldings

*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER VIEW [dbo].[vHoldings]
as

/*

The vHoldings view cross-references Star Compliance holdings with Bernstein/Autonomous coverage
to produce a filtered set of holdings in active covered securities by active authors.

Persons are translated from windows login to AuthorId.

Tickers are translated from ISIN to SecurityId.

*/

select distinct
 A.AuthorId
 ,V.SecurityId
 , A.Last + ', ' + A.First as Author
 ,A.Name
 ,A.ExtEmail as Email
 ,V.Ticker
 ,V.Company
 ,A.Name + ' maintains a long position in ' + V.Company + ' (' + V.Ticker + ')' as [Text]
 -- Star Compliance columns
 ,H.EmployeeID
 ,H.EmployeeUserName
 ,H.EmployeeLastName
 ,H.EmployeeFirstName
 ,H.Description
 ,H.Cusip
 ,H.BloombergTicker
 ,H.ISIN
 ,H.SEDOL
 ,H.SecurityType
 ,H.HoldingQuantity
 ,H.UserAccountStatus
 ,H.LastExecution
 ,H.ReportRunDate
from Holdings H
-- Bernstein/Autonomous author coverage by windows login
join Authors A on ltrim(rtrim(A.WindowsUserName)) = 'ac\' + ltrim(rtrim(H.EmployeeUserName)) and A.IsActive = -1
join
(
-- Active Bernstein ticker coverage by ISIN
select S.SecurityId, ISIN, Ticker, Company, TypeId from Securities2 S
join ResearchCoverage RC on RC.SecurityId = S.SecurityId and RC.DropDate is null
union
-- Active Autonomous ticker coverage by ISIN
select SecurityId, ISIN, Ticker, Company, TypeId from Securities2 S where TypeId = 2 and S.IsActive = -1
) V on ltrim(rtrim(V.ISIN)) = ltrim(rtrim(H.ISIN))
where H.EmployeeUserName is not null and ltrim(rtrim(H.EmployeeUserName)) <> ''
and H.ISIN is not null and ltrim(rtrim(H.ISIN)) <> ''
go

-- ***
-- *** COVERAGE EXPORT
-- ***

if exists(select * from sys.objects where type = 'P' and name = 'spExportCoverageAuthors')
drop proc dbo.spExportCoverageAuthors
go

create proc dbo.spExportCoverageAuthors
as
begin
  select
  1               as Tag,
  null            as Parent,
  null            as [Authors!1!],
  null            as [Author!2!authorId],
  null            as [Author!2!name],
  null            as [Author!2!first],
  null            as [Author!2!last],
  null            as [Author!2!email],
  null            as [Author!2!phone],
  null            as [Author!2!username],
  null            as [Author!2!isAnalyst],
  null            as [Author!2!isAnalystAlt!hide]

  union

  select distinct
  2               as Tag,
  1               as Parent,
  null            as [Authors!1!],
  A.AuthorId      as [Author!2!authorId],
  A.Name          as [Author!2!name],
  A.First         as [Author!2!first],
  A.Last          as [Author!2!last],
  A.ExtEmail      as [Author!2!email],
  A.Phone         as [Author!2!phone],
  replace(A.WindowsUserName,'ac\','') as [Author!2!usename],
  case A.IsAnalyst
  when -1 then 'T'
  else 'F'
  end             as [Author!2!isAnalyst],
  A.IsAnalyst     as [Author!2!isAnalystAlt!hide]
  from ResearchCoverage RC
  join Authors A on RC.AnalystId = A.AuthorId
  where RC.LaunchDate is not null and RC.DropDate is null

  union

  select distinct
  2               as Tag,
  1               as Parent,
  null            as [Authors!1!],
  A2.AuthorId     as [Author!2!authorId],
  A2.Name         as [Author!2!name],
  A2.First        as [Author!2!first],
  A2.Last         as [Author!2!last],
  A2.ExtEmail     as [Author!2!email],
  A2.Phone        as [Author!2!phone],
  replace(A2.WindowsUserName,'ac\','') as [Author!2!usename],
  case A2.IsAnalyst
  when -1 then 'T'
  else 'F'
  end             as [Author!2!isAnalyst],
  A2.IsAnalyst    as [Author!2!isAnalystAlt!hide]
  from ResearchCoverage RC
  join Authors A on RC.AnalystId = A.AuthorId
  join AnalystTeamMembers ATM on A.AuthorId = ATM.AnalystId
  join Users U on ATM.UserId = U.UserId
  join Authors A2 on Replace(U.UserName,'ac\','') = Replace(A2.WindowsUserName,'ac\','')
  where RC.LaunchDate is not null and RC.DropDate is null

  order by 12,4
  for xml explicit
end
go

if exists(select * from sys.objects where type = 'P' and name = 'spExportCoverageSecurities')
drop proc dbo.spExportCoverageSecurities
go

create proc dbo.spExportCoverageSecurities
as
begin
  select
  1               as Tag,
  null            as Parent,
  null            as [Securities!1!],
  null            as [Security!2!securityId],
  null            as [Security!2!company],
  null            as [Security!2!ordno!hide],
  null            as [Security!2!ticker],
  null            as [Security!2!isin],
  null            as [Security!2!authorId],
  null            as [Security!2!analyst],
  null            as [Security!2!email],
  null            as [Security!2!industry],
  null            as [Security!2!sector]

  union

  select
  2               as Tag,
  1               as Parent,
  null            as [Securities!1!],
  S.SecurityId    as [Security!2!securityId],
  S.Company       as [Security!2!company],
  S.OrdNo         as [Security!2!ordno!hide],
  case
  when CHARINDEX('.',S.Ticker) > 0 then replace(S.Ticker,'.',' ')
  else S.Ticker + ' US'
  end             as [Security!2!ticker],
  S.ISIN          as [Security!2!isin],
  A.AuthorId      as [Security!2!authorId],
  A.Name          as [Security!2!analyst],
  A.ExtEmail      as [Security!2!email],
  I.IndustryName  as [Security!2!industry],
  S2.Sector       as [Security!2!sector]
  from ResearchCoverage RC
  join Securities2 S on RC.SecurityId = S.SecurityId
  join Authors A on RC.AnalystId = A.AuthorId
  join Industries I on RC.IndustryId = I.IndustryId
  join Sectors S2 on I.SectorId = S2.SectorId
  where RC.LaunchDate is not null and RC.DropDate is null

  order by 5
  for xml explicit
end
go

-- ***
-- *** DISCLOSURE EXPORT
-- ***

if exists(select * from sys.objects where type = 'P' and name = 'spExportAuthorTextDisclosures')
drop proc dbo.spExportAuthorTextDisclosures
go

create proc dbo.spExportAuthorTextDisclosures
as
begin
  select
    1             as Tag,
    NULL          as Parent,
    null          as [AuthorTextDisclosures!1!],
    --null        as [Author!2!id],
    null          as [Author!2!name],
    null          as [Author!2!email],
    NULL          as [Text!3!!cdata]

  union

  select
    2,
    1,
    null,
    --Author.AuthorId,
    A.Name,
    A.ExtEmail,
    null
  from Authors A
  join AuthorTitles AT on A.TitleId = AT.TitleId
  join AuthorTextDisclosures Disclosure on Disclosure.AuthorId = A.AuthorId
  where A.IsActive = -1

  union

  select
    3,
    2,
    null,
    --Author.AuthorId,
    A.Name,
    A.ExtEmail,
    Disclosure.Disclosure
  from Authors A
  join AuthorTextDisclosures Disclosure ON Disclosure.AuthorId = A.AuthorId
  where A.IsActive = -1

  order by 4, 1
  for xml explicit
end
go

if exists(select * from sys.objects where type = 'P' and name = 'spExportSecurityTextDisclosures')
drop proc dbo.spExportSecurityTextDisclosures
go

create proc dbo.spExportSecurityTextDisclosures
as
begin
  select
    1             as Tag,
    null          as Parent,
    null          as [SecurityTextDisclosures!1!],
    --null        as [Security!2!id],
    null          as [Security!2!company],
    null          as [Security!2!ticker],
    null          as [Security!2!ordno!hide],
    null          as [Text!3!!cdata]

  union

  select
    2,
    1,
    null,
    --S.SecurityId,
    Company,
    case
    when charindex('.', S.Ticker) > 0 then replace(S.Ticker, '.', ' ')
    else S.Ticker + ' US'
    end,
     S.OrdNo,
    null
  from Securities2 S
  join SecurityTextDisclosures SD on SD.SecurityId = S.SecurityId
  where S.IsActive = -1

  union

  select
    3,
    2,
    null,
    --S.SecurityId,
    Company,
    case
    when charindex('.', S.Ticker) > 0 then replace(S.Ticker, '.', ' ')
    else S.Ticker + ' US'
    end,
    S.OrdNo,
    SD.Disclosure
  from Securities2 S
  JOIN SecurityTextDisclosures SD ON SD.SecurityId = S.SecurityId
  where S.IsActive = -1

  order by 4, 6, 1
  for xml explicit
end
go

if exists(select * from sys.objects where type = 'P' and name = 'spExportFirmDisclosures')
drop proc dbo.spExportFirmDisclosures
go

create proc dbo.spExportFirmDisclosures
as
begin
  select
    1             as  tag,
    null          as  parent,
    null          as  [FirmDisclosures!1!],
    null          as [FirmDisclosure!2!id],
    null          as [FirmDisclosure!2!text],
    --null        as [Security!3!securityId],
    null          as [Security!3!company],
    null          as [Security!3!ticker],
    null          as [Security!3!ordno!hide]

  union

  select
    2             as  tag,
    1             as  parent,
    null          as  [FirmDisclosures!1!],
    DisclosureId  as [FirmDisclosure!2!id],
    Disclosure    as [FirmDisclosure!2!text],
    --null        as [Security!3!securityId],
    null          as [Security!3!Company],
    null          as [Security!3!ticker],
    null          as [Security!3!ordno!hide]
  from SecurityCheckboxTypes

  union

  select
    3             as  tag,
    2             as  parent,
    null          as  [FirmDisclosures!1!],
    SCD.DisclosureId  as [FirmDisclosure!2!id],
    null          as [FirmDisclosure!2!text],
    --SCD.SecurityId    as [Security!3!securityId],
    Company       as [Security!3!company],
    case
    when charindex('.', S.Ticker) > 0 then Replace(S.Ticker, '.', ' ')
    else S.Ticker + ' US'
    end           as [Security!3!ticker],
    S.OrdNo
  from SecurityCheckboxDisclosures SCD
  join Securities2 S on SCD.SecurityId = S.SecurityId
  join ResearchCoverage RC on S.SecurityId = RC.SecurityId
  where RC.LaunchDate is not null and RC.DropDate is null

  union

  select
    3             as  tag,
    2             as  parent,
    null          as  [FirmDisclosures!1!],
    SCD.DisclosureId  as [FirmDisclosure!2!id],
    null          as [FirmDisclosure!2!text],
    --SCD.SecurityId    as [Security!3!securityId],
    Company       as [Security!3!company],
    case
    when charindex('.', S.Ticker) > 0 then replace(S.Ticker, '.', ' ')
    else S.Ticker + ' US'
    end           as [Security!3!ticker],
    S.OrdNo
  from SecurityCheckboxDisclosures SCD
  join Securities2 S on SCD.SecurityId = S.SecurityId
  where S.TypeId = 2 and IsActive = -1

  order by 4,6,8
  for xml explicit
end
go

if exists(select * from sys.objects where type = 'P' and name = 'spExportHoldings')
drop proc dbo.spExportHoldings
go

create proc dbo.spExportHoldings
as
begin

  select
    1             as  tag,
    null          as  parent,
    null          as [Holdings!1!],
    null          as [Holding!2!name],
    null          as [Holding!2!email],
    null          as [Holding!2!company],
    null          as [Holding!2!ticker],
    null          as [Holding!2!isin]

  union

  select
    2             as  tag,
    1             as  parent,
    null          as [Holdings!1!],
    Name          as [Holding!2!name],
    Email         as [Holding!2!email],
    Company       as [Holding!2!company],
    Ticker        as [Holding!2!ticker],
    ISIN          as [Holding!2!isin]
  from vHoldings H

  order by 4, 5
  for xml explicit

end
go

grant execute on dbo.spExportCoverageAuthors         to DE_IIS, PowerUsers
grant execute on dbo.spExportCoverageSecurities      to DE_IIS, PowerUsers
grant execute on dbo.spExportAuthorTextDisclosures   to DE_IIS, PowerUsers
grant execute on dbo.spExportSecurityTextDisclosures to DE_IIS, PowerUsers
grant execute on dbo.spExportFirmDisclosures         to DE_IIS, PowerUsers
grant execute on dbo.spExportHoldings                to DE_IIS, PowerUsers
go

/*

-- DEBUG

sp_helptext vHoldings

select * from vHoldings

spExportCoverageAuthors
go

spExportCoverageSecurities
go

spExportAuthorTextDisclosures
go

spExportSecurityTextDisclosures
go

spExportFirmDisclosures
go

spExportHoldings
go

*/
