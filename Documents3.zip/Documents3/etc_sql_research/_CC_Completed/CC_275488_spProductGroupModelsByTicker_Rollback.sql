--03/15/2018
--CC_spSaveProductGroupModelsByTicker_Rollback.sql 

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

alter procedure [dbo].[spSaveProductGroupModelsByTicker] @SecurityId int
as
begin
  DELETE FROM ProductGroupModels WHERE SecurityId = @SecurityId
  
  INSERT INTO ProductGroupModels(ProductGroupId, SecurityId)

  SELECT PGF.ProductGroupId, S.SecurityId
  FROM ProductGroupFields PGF
  JOIN Industries I ON PGF.FieldValue = I.IndustryId
  JOIN ResearchCoverage RC ON I.IndustryId = RC.IndustryId
  JOIN Securities2 S ON RC.SecurityId = S.SecurityId
  WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
  AND RC.ModelDistribution = 'Y'
  AND S.SecurityId = @SecurityId
  AND S.IsPrimary = 'Y'
  
  UNION
  
  SELECT PGF.ProductGroupId, S.SecurityId
  FROM ProductGroupFields PGF
  JOIN Authors A ON PGF.FieldValue = A.AuthorId
  JOIN ResearchCoverage RC ON A.AuthorId = RC.AnalystId
  JOIN Securities2 S ON RC.SecurityId = S.SecurityId
  WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
  AND RC.ModelDistribution = 'Y'
  AND S.SecurityId = @SecurityId
  AND S.IsPrimary = 'Y'
  
  UNION
  
  SELECT PGF.ProductGroupId, S.SecurityId
  FROM ProductGroupFields PGF
  JOIN Securities2 S ON PGF.FieldValue = S.SecurityId
  JOIN ResearchCoverage RC ON S.SecurityId = RC.SecurityId
  WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
  AND RC.ModelDistribution = 'Y'
  AND S.SecurityId = @SecurityId
  AND S.IsPrimary = 'Y'
end

