-- CC_spRollbackEstimates
-- 10/02/2018
-- Modified to prevent Videos from populating into the correction queue as dependent publications druing rollback of estimates

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER procedure [dbo].[spRollbackEstimates]
  @PubNo int,
  @SecurityId int,
  @EditorId int
as
begin try
  begin transaction
    --only one set of reports(with same source pubno) can be in correction mode at any time
    --reject if the prior set is not completed/cancelled
    if exists(select * from CorrectionQueue where status in ('Required','Optional') and SourcePubNo <> @PubNo)
    begin
        select -3 returnValue
        commit
        return
    end

    --if a report is already scheduled to be published for this ticker
    --prevent from doing a rollback
    declare @Qid int, @DXml xml, @hDoc int
    select top 1 @Qid = QueueId,@DXml = DocumentXml from PublicationQueue where ProcessStatus = 'Scheduled' order by QueueId

    while @@ROWCOUNT = 1
    begin
      exec sp_xml_preparedocument @hDoc output, @DXml

      if exists
      (select X.SecurityId,X.Ticker,X.IndicateChange
      from openxml (@hDoc, 'DocumentInfo/Securities/Security', 1)
      with (securityId      int         '@id',
            ticker          varchar(30) '@ticker',
            indicateChange  varchar(10) '@indicateChange'
            ) X
      where X.SecurityId = @SecurityId)
      begin
        select -2 returnValue
        commit
        return
      end

      exec sp_xml_removedocument @hDoc
      select top 1 @Qid = QueueId,@DXml = DocumentXml from PublicationQueue where ProcessStatus = 'Scheduled' AND QueueId > @Qid order by QueueId
    end
    --check to see if report exists in publicationxml table (new system)
    if exists(select PubNo from PublicationsXml where PubNo = @PubNo)
    begin

      declare @CurrentDate datetime
      declare @Ticker varchar(30)
      declare @UserName varchar(36)

      set @CurrentDate = GETDATE()
      select @Ticker = Ticker from Securities2 where SecurityId = @SecurityId
      select @UserName = UserName from Users where UserId = @EditorId

      --delete any pending drafts
      delete from FinancialNumbers where SecurityId = @SecurityId and IsDraft = 1

      --revert the latest live numbers to draft state
      delete PublicationFinancialNumbers
      from PublicationFinancialNumbers PFN
      join FinancialNumbers FN on PFN.FinancialNumberId = FN.FinancialNumberId
      where FN.SecurityId = @SecurityId
      and FN.PubNo = @PubNo
      and FN.IsDraft = 0

      update FinancialNumbers
      set IsDraft = 1, PubNo = null, Date = @currentdate
      where SecurityId = @SecurityId
      and PubNo = @PubNo
      and IsDraft = 0

      --update model status to deleted if this publication promoted any models to live
      if exists(select * from Models where PubNo = @PubNo)
      begin
        insert into ModelDeletions(ModelId,EditorId,EditDate) 
        select ModelId, 0, getdate() from Models
        where SecurityId = @SecurityId
        and StateId = 1

        update Models set StateId = 3 where PubNo = @PubNo and SecurityId = @SecurityId and StateId = 1
      end

      --Determine the covering analyst for the rollback ticker
      declare @AnalystId int
      select @AnalystId = AnalystId from ResearchCoverage where SecurityId  = @SecurityId and LaunchDate is not null and DropDate is null

      --insert into CorrectionQueue table for source report
      insert into CorrectionQueue(PubNo,SecurityId,AnalystId,SourcePubNo,IsSource,CorrectionMode,Queued,QueuedBy,Status,EditorId,EditDate)
      select @PubNo,@SecurityId,@AnalystId,@PubNo,1,0,@CurrentDate,@EditorId,'Required',@EditorId,@CurrentDate

      --Retrieve dependent publication numbers
      select PR.PubNo
      into #TmpDependentPublications
      from Properties PR
      join PropertyNames PN on PR.PropId = PN.PropId
      join Publications P on PR.PubNo = P.PubNo
      where PN.PropName = 'Ticker'
      and PR.PropValue = (select Ticker from Securities2 where SecurityId = @SecurityId)
      and P.Type <> 'Video'
      and PR.PubNo > @PubNo

      --insert into CorrectionQueue table for all dependent publications
      insert into CorrectionQueue(PubNo,SecurityId,AnalystId,SourcePubNo,IsSource,CorrectionMode,Queued,QueuedBy,Status,EditorId,EditDate)
      select PubNo,@SecurityId,@AnalystId,@PubNo,0,0,@CurrentDate,@EditorId,'Optional',@EditorId,@CurrentDate
      from #TmpDependentPublications


      exec spRestoreMarketData @PubNo, @SecurityId, @EditorId

    end
  select 0 returnValue
 commit
end try
begin catch
  if @@trancount > 0
    rollback
    --raise an error with the details of the exception
    declare @errmsg nvarchar(4000), @errseverity int
    select @errmsg = ERROR_MESSAGE(),
            @errseverity = ERROR_SEVERITY()
    select -1 returnValue
    Raiserror(@errmsg,@errseverity,1)
end catch

go
