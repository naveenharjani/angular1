-- DWS_Rollback.sql
-- 06/10/2019

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*

drop proc spRptDwsCoverageData

*/

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spRptDwsCoverageData]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spRptDwsCoverageData]
GO
