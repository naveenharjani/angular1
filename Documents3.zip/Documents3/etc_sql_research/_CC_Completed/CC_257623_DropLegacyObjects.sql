-- DropLegacyObjects.sql
-- 06/09/2017

/*

After the Flip Database Views to Estimates db is successful,
Drop Legacy Objects that were used by old Publishing engine in TTS schema

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*

-- Drop procs/views used by old UI or legacy publishing engine

-- PROCS - DROP
Proc Name                       Dependency - Old                       Old source
spSaveAnalystSettings           AnalystSettings                        Remove legacy table references
spSavePublication               None                                   Old Publishing engine
spGetBenchmarkEstimates         EstimatePeriods, BenchmarkEstimates    Old UI
spSaveBenchmarkEstimates        BenchmarkEstimates                     Old UI
spGetDefaultBenchmarkEstimates  EstimatePeriods, BenchmarkEstimates    Old UI
spRenderEstimatePeriods         EstimatePeriods, BenchmarkEstimates    Old UI
spMirrorFinancialNumbers        TickerTableSecurities                  Old Publishing engine
spMirrorTickerTableSecurities   TickerTableSecurities, Footnotes       Old Publishing engine
spSaveTickerTable               TickerTableSecurities, Footnotes       Old Publishing engine
spUpdateActionTags              TickerTableSecurities                  Old Publishing engine
spRenderEpsTypes                EpsTypes                               Old Publishing engine
spRenderMetricsTypes            MetricsTypes                           Old Publishing engine
spRevaluateTickerTableXML       MigratedAnalysts, vTickerSheetsLatest  Old Publishing engine - old sync process
spRenderEstimatePeriods         EstimatedPeriods                       Old Publishing engine
spSaveTickerSheets

-- PROCS - DO NOT DELETE
spDeletePublication        TickerTableSecurities, Footnotes    Remove legacy table references

-- PROCS - DROP - NOT used anymore by new publishing engine
spMigrateAnalyst

-- PROCS - DROP - Company Financials(OLD) 6 procs
spGetEstimatesCompanyXml
spGetEstimatesMarketdataXml
spGetEstimatesPerformanceXml
spGetEstimatesEpsXml
spGetEstimatesFinancialsXml
spGetEstimatesValuationsXml

-- VIEWS
vTickerSheetsLatest        TickerTableSecurities          Old Publishing engine
-- Drop backup Flip views
vFinancials_Old
vFinancialsLatest_Old
vFinancials2
vFinancialsLatest2

*/


IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spSaveAnalystSettings' AND type = 'P')
DROP PROCEDURE spSaveAnalystSettings
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spSavePublication' AND type = 'P')
DROP PROCEDURE spSavePublication
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spGetBenchmarkEstimates' AND type = 'P')
DROP PROCEDURE spGetBenchmarkEstimates
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spSaveBenchmarkEstimates' AND type = 'P')
DROP PROCEDURE spSaveBenchmarkEstimates
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spGetDefaultBenchmarkEstimates' AND type = 'P')
DROP PROCEDURE spGetDefaultBenchmarkEstimates
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spRenderEstimatePeriods' AND type = 'P')
DROP PROCEDURE spRenderEstimatePeriods
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spMirrorFinancialNumbers' AND type = 'P')
DROP PROCEDURE spMirrorFinancialNumbers
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spMirrorTickerTableSecurities' AND type = 'P')
DROP PROCEDURE spMirrorTickerTableSecurities
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spSaveTickerTable' AND type = 'P')
DROP PROCEDURE spSaveTickerTable
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spUpdateActionTags' AND type = 'P')
DROP PROCEDURE spUpdateActionTags
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spRenderEpsTypes' AND type = 'P')
DROP PROCEDURE spRenderEpsTypes
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spRenderMetricsTypes' AND type = 'P')
DROP PROCEDURE spRenderMetricsTypes
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spRevaluateTickerTableXML' AND type = 'P')
DROP PROCEDURE spRevaluateTickerTableXML
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spRenderEstimatePeriods' AND type = 'P')
DROP PROCEDURE spRenderEstimatePeriods
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spSaveTickerSheets' AND type = 'P')
DROP PROCEDURE spSaveTickerSheets
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spMigrateAnalyst' AND type = 'P')
DROP PROCEDURE spMigrateAnalyst
GO

-- PROCS - Company Financials (6)
IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spGetEstimatesCompanyXml' AND type = 'P')
DROP PROCEDURE spGetEstimatesCompanyXml
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spGetEstimatesMarketdataXml' AND type = 'P')
DROP PROCEDURE spGetEstimatesMarketdataXml
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spGetEstimatesPerformanceXml' AND type = 'P')
DROP PROCEDURE spGetEstimatesPerformanceXml
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spGetEstimatesEpsXml' AND type = 'P')
DROP PROCEDURE spGetEstimatesEpsXml
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spGetEstimatesFinancialsXml' AND type = 'P')
DROP PROCEDURE spGetEstimatesFinancialsXml
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spGetEstimatesValuationsXml' AND type = 'P')
DROP PROCEDURE spGetEstimatesValuationsXml
GO


-- VIEWS
-- Drop backup Flip views
IF EXISTS(SELECT * FROM sys.objects WHERE name = 'vTickerSheetsLatest' AND type = 'V')
DROP VIEW vTickerSheetsLatest
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'vFinancials_Old' AND type = 'V')
DROP VIEW vFinancials_Old
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'vFinancialsLatest_Old' AND type = 'V')
DROP VIEW vFinancialsLatest_Old
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'vFinancials2' AND type = 'V')
DROP VIEW vFinancials2
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'vFinancialsLatest2' AND type = 'V')
DROP VIEW vFinancialsLatest2
GO


/*
-- Objects dependent on these tables
SELECT * FROM sys.objects where object_id in (SELECT referencing_id FROM sys.sql_expression_dependencies
WHERE referenced_id = OBJECT_ID(N'TickerTableSecurities') OR
      referenced_id = OBJECT_ID(N'TickerTableSecuritiesOld') OR
      referenced_id = OBJECT_ID(N'TickerTables') OR
      referenced_id = OBJECT_ID(N'TickerSheetSecurities') OR
      referenced_id = OBJECT_ID(N'TickerSheets') OR
      referenced_id = OBJECT_ID(N'Footnotes') OR
      referenced_id = OBJECT_ID(N'FootnotesRef') OR
      referenced_id = OBJECT_ID(N'AnalystSettings') OR
      referenced_id = OBJECT_ID(N'AnalystSettingsLog') OR
      referenced_id = OBJECT_ID(N'BenchmarkEstimates') OR
      referenced_id = OBJECT_ID(N'BenchmarkEstimatesLog') OR
      referenced_id = OBJECT_ID(N'EpsTypes') OR
      referenced_id = OBJECT_ID(N'MetricsTypes') OR
      referenced_id = OBJECT_ID(N'EstimatesPeriods') OR
      referenced_id = OBJECT_ID(N'MigratedAnalysts')
) ORDER BY 1

select * from BenchmarkEstimates order by editdate desc

spGetChartTickers    -- uses TickerTableSecurities in DEV
spresearchcoverage   -- uses MigratedAnalysts in DEV, does not exist in PROD

sp_helptext spGetChartTickers
sp_helptext spresearchcoverage
sp_helptext spSaveSecurity

*** To be Done
--  Scan sqlxml files for using any tables above

sp_helptext spResearchCoverage

*/


-- DEBUG