-- RVDocuments_Rollback.sql
-- 03/27/2019

/*

alter RVDocuments - "Podcast" type support

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVDocuments]'))
DROP VIEW [dbo].[RVDocuments]
GO

CREATE VIEW [dbo].[RVDocuments] WITH SCHEMABINDING AS
SELECT
  DocId = PubNo,
  Date,
  DocTypeId = PublicationTypeId,
  Title,
  Filename = CASE PublicationTypeId WHEN 10 THEN FileName ELSE convert(varchar,pubno) + '.pdf' END,
  RefreshDate = PublishedDate,
  Version,
  FileSize,
  PageCount
FROM
  dbo.Publications P
  JOIN dbo.PublicationTypes PT ON P.Type = PT.PublicationType
WHERE
  P.Date >= convert(datetime,'05/01/2003',110) and
  PT.IsRepl = 'Y' and
  PT.IsResearch in ('Y','*')
GO

CREATE UNIQUE CLUSTERED INDEX [RVDocuments_DocId] ON [dbo].[RVDocuments]
(
  [DocId] ASC
)
GO
