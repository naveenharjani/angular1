-- CC_vFinancialsLatest2.sql
-- 02/16/2017

/*

alter vFinancialsLatest2

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER VIEW [dbo].[vFinancialsLatest2]
AS

SELECT
  VF.SecurityId,
  VF.Ticker,
  VF.Date,
  VF.PubNo,
  VF.CoverageAction,
  VF.Rating,
  VF.RatingAction,
  VF.TargetPrice,
  VF.TargetPriceAction,
  VF.LastYear,
  VF.ThisYear,
  VF.NextYear,
  VF.EPSType,
  VF.EPSLastYear,
  VF.EPSThisYear,
  VF.EstimateAction,
  VF.EPSNextYear,
  VF.EstimateNextYearAction,
  VF.MetricType,
  'MetricLastYear' = (SELECT MAX(Value) FROM vValuationsLatest WHERE Securityid = S.SecurityId AND FinancialNumberTypeId = FCS.TickerTableValuationId AND IsDraft = 0 AND FinancialPeriodId = 1),
  'MetricThisYear' = (SELECT MAX(Value) FROM vValuationsLatest WHERE Securityid = S.SecurityId AND FinancialNumberTypeId = FCS.TickerTableValuationId AND IsDraft = 0 AND FinancialPeriodId = 2),
  'MetricNextYear' = (SELECT MAX(Value) FROM vValuationsLatest WHERE Securityid = S.SecurityId AND FinancialNumberTypeId = FCS.TickerTableValuationId AND IsDraft = 0 AND FinancialPeriodId = 3),
  VF.Currency,
  VF.YTDRelPerf,
  VF.Yield,
  VF.LaunchDate,
  VF.FileName,
  VF.CoverageId,
  VF.IndustryId,
  VF.AnalystId,
  VF.CloseDate,
  VF.ClosePrice,
  VF.TickerOrder,
  VF.DisplayCloseDate,
  VF.RelPerfType
FROM vFinancials2 VF
JOIN (SELECT Ticker, MAX(PubNo) PubNo FROM PublicationFinancials GROUP BY Ticker) V ON V.Ticker = VF.Ticker AND V.PubNo = VF.PubNo -- Latest
JOIN ResearchCoverage RC ON RC.SecurityId = VF.SecurityId AND RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId

GO


/*
-- DEBUG

SELECT COUNT(*) FROM [dbo].[vFinancials]  --where dropdate is null
SELECT COUNT(*) FROM [dbo].[vFinancials2] --where dropdate is null

SELECT COUNT(*) FROM [dbo].[vFinancialsLatest]
SELECT COUNT(*) FROM [dbo].[vFinancialsLatest2]

SELECT TOP 50000 * FROM vFinancials ORDER BY PubNo DESC
SELECT TOP 50000 * FROM vFinancials2 ORDER BY PubNo DESC

SELECT TOP 50000 * FROM vFinancialsLatest ORDER BY PubNo DESC
SELECT TOP 50000 * FROM vFinancialsLatest2 ORDER BY PubNo DESC

SELECT TOP 50000 * FROM RVFinancials ORDER BY DocId DESC

-- Compare Old vs New schemas
-- vFinancials
SELECT Ticker, PubNo, Date FROM vFinancials
EXCEPT
SELECT Ticker, PubNo, Date FROM vFinancials2

-- vFinancialsLatest
SELECT Ticker, PubNo, Date FROM vFinancialsLatest
EXCEPT
SELECT Ticker, PubNo, Date FROM vFinancialsLatest2

-- Data Issues
-- commas sign
SELECT * FROM  PublicationFinancials PF WHERE PF.Ticker = '005490.KS' AND PF.pubno = 112687

-- dollar sign
SELECT * FROM  PublicationFinancials PF WHERE PF.pubno = 126688  -- AND PF.Ticker = 'CELG'

-- No CoverageId
select * from PublicationFinancials where coverageid is  null and ticker not in ('SPX','MSPE','MSDLE15','MXAPJ','MXEF','MXJP')
order by pubno desc
select * from PublicationFinancials where pubno in (127041, 127099)
select * from tickertablesecurities where pubno in (127041, 127099)

select * from PublicationFinancials where ticker = '1918.hk'
SELECT * FROM vFinancials where ticker = '1918.HK'
SELECT * FROM vFinancials2 where ticker = '1918.HK'

*/