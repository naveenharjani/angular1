--03/23/2018
--CC_spGetResearchToSymphonyRoom.sql

USE Research
GO
-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM sys.objects where name like '%spGetResearchToSymphonyRoom%')
DROP PROCEDURE dbo.spGetResearchToSymphonyRoom
GO

-- ====================================================================================
 -- Author: Sandarsh M S
 -- Create date: 03/23/2018
 -- Description: Gets report Data to post to Symphony Room
 -- ====================================================================================

create procedure [dbo].[spGetResearchToSymphonyRoom]
  @PubNo int
as
begin
select
  PU.Title,
  PU.FileName,
  AU.AuthorId,
  AU.First + AU.Last as Analyst,
  AU.ExtEmail as Email,
  PX.PropertiesXml,
  PX.TickerTableXml,
  PX.HighlightsXml
from Publications PU
join Properties PR on PU.PubNo = PR.PubNo and PR.PropId = 5
join Authors AU on PR.PropValue = AU.Name and IsAnalyst=-1
join PublicationsXml PX  on PU.PubNo = PX.PubNo
where  PU.PubNo = @PubNo
order by PR.PropNo
end
go

GRANT EXECUTE ON dbo.spGetResearchToSymphonyRoom TO DE_IIS, PowerUsers
GO
