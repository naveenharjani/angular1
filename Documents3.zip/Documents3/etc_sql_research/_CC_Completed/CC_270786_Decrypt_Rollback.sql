-- Decrypt_Rollback.sql
-- 01/02/2018

/*

spRenderContentIds - Called by decrypteid.aspx

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spRenderContentIds]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spRenderContentIds]
GO