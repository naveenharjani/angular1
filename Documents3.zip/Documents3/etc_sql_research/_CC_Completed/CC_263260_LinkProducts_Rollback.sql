-- CC_LinkProducts_Rollback.sql
-- 10/04/2017

/*

drop LinkProducts
alter LinkSources
drop spRenderGetLinkSources
drop spRenderSetLinkSources
drop spGetLinks

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM SYS.views WHERE name = 'RVLinkSources' AND type = 'V')
DROP VIEW [dbo].[RVLinkSources]
GO

IF EXISTS(SELECT * FROM SYS.views WHERE name = 'RVLinkProducts' AND type = 'V')
DROP VIEW [dbo].[RVLinkProducts]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'dbo.FK_LinkSources_LinkProducts') AND parent_object_id = OBJECT_ID(N'[dbo].[LinkSources]'))
ALTER TABLE dbo.LinkSources DROP CONSTRAINT FK_LinkSources_LinkProducts
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.LinkProducts') AND type in (N'U'))
DROP TABLE dbo.LinkProducts
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.LinkSources') AND type in (N'U'))
DROP TABLE dbo.LinkSources
GO

CREATE TABLE dbo.LinkSources
(
  SourceId			int			NOT NULL,
  Source  		    varchar(50) NOT NULL,
  SourceLaunchDate  datetime    NOT NULL,
  EditorId			int			NOT NULL,
  EditDate			datetime	NOT NULL,
 CONSTRAINT [PK_LinkSources] PRIMARY KEY CLUSTERED (SourceId ASC)) ON [PRIMARY]
GO

-- Restore LinkSources from backup
INSERT INTO LinkSources(SourceId, Source, SourceLaunchDate, EditorId, EditDate)
SELECT SourceId, Source, SourceLaunchDate, EditorId, EditDate
FROM LinkSources_bak
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spRenderGetLinkSources' and type = 'P')
DROP PROCEDURE dbo.spRenderGetLinkSources
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spRenderSetLinkSources' and type = 'P')
DROP PROCEDURE dbo.spRenderSetLinkSources
GO

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'spGetLinks' and type = 'P')
DROP PROCEDURE dbo.spGetLinks
GO

/*
IF EXISTS(SELECT * FROM SYS.views WHERE name = 'RVLinkSources' AND type = 'V')
DROP VIEW [dbo].[RVLinkSources]
GO

CREATE VIEW [dbo].[RVLinkSources] WITH SCHEMABINDING AS
SELECT
  SourceId,
  Source,
  SourceLaunchDate,
  EditorId,
  EditDate
FROM
  dbo.LinkSources
GO

IF EXISTS(SELECT * FROM SYS.views WHERE name = 'RVLinkProducts' AND type = 'V')
DROP VIEW [dbo].[RVLinkProducts]
GO

SELECT * FROM LinkSources

*/