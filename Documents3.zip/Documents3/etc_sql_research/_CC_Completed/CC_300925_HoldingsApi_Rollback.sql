-- CC_HoldingsApi_Rollback.sql
-- 02/04/2018

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' and name = 'spGetAuthorHoldings')
DROP PROC dbo.spGetAuthorHoldings
GO