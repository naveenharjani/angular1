-- ThematicTags.sql
-- 08/01/2017

/*

ThematicTags
spSaveThematicTag

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
set ARITHABORT ON
set CONCAT_NULL_YIELDS_NULL ON
set QUOTED_IDENTIFIER ON
set ANSI_NULLS ON
set ANSI_PADDING ON
set ANSI_WARNINGS ON
set NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where name = 'ThematicTags' and type = 'u')
drop table [dbo].[ThematicTags]
go

create table [dbo].[ThematicTags]
(
  ThematicTagId int           NOT NULL identity(1,1),
  ThematicTag   varchar(100)  NOT NULL,
  Active        smallint      NOT NULL,
  EditorId      int           NOT NULL,
  EditDate      datetime      NOT NULL,
  constraint [PK_ThematicTags] primary key clustered (ThematicTagId asc)
)
go

alter table[dbo].[ThematicTags] add constraint [IX_ThematicTags_ThematicTag] unique nonclustered ([ThematicTag] ASC)

if exists(select * from sys.objects where name = 'spSaveThematicTag' and type = 'P')
drop procedure spSaveThematicTag
go

create procedure [dbo].[spSaveThematicTag]
  @ThematicTagId int OUTPUT,
  @ThematicTag   varchar(100),
  @Active        int,
  @EditorId      int
as

declare @EditDate datetime
select @EditDate = GETDATE()

begin try
  begin transaction
    if exists (select ThematicTagId from ThematicTags where ThematicTagId = @ThematicTagId)
      begin
      declare @@ThematicTagOld varchar(100)
      select @@ThematicTagOld = @ThematicTag from ThematicTags where ThematicTagId = @ThematicTagId
      if @ThematicTag <> @@ThematicTagOld
        begin
        insert into AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        values ('ThematicTags', 'U', @ThematicTag, @@ThematicTagOld, @ThematicTagId, @EditorId, @EditDate)

        --UPDATE Properties SET PropValue = @InvestorTheme WHERE PropId = 32 AND PropValue = @ValueOld
        end
      update ThematicTags set
        ThematicTag = @ThematicTag,
        Active      = @Active,
        EditorId    = @EditorId,
        EditDate    = @EditDate
      where ThematicTagId = @ThematicTagId
      end
    else
      begin
      insert into Thematictags (ThematicTag, Active, EditorId, EditDate)
      values (@Thematictag, @Active, @EditorId, @EditDate)
      select @ThematicTagId = @@IDENTITY
      insert into AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
      values ('ThematicTags', 'A', @ThematicTag, NULL, @ThematicTagId, @EditorId, @EditDate)
      end
    select 0
  commit transaction
end try
begin catch
  rollback transaction
  select ERROR_NUMBER() AS ErrorNumber, ERROR_MESSAGE() AS ErrorMessage
end catch

GO

grant execute on dbo.spSaveThematicTag to DE_IIS, PowerUsers
GO

-- DEBUG

/*

select * from ThematicTags

declare @ThematicTagId int
exec spSaveThematicTag @ThematicTagId output, 'Artificial Intelligence', 1, 1126
go
-- Test IX for dupes
declare @ThematicTagId int
exec spSaveThematicTag @ThematicTagId output, 'Artificial Intelligence', 1, 1126
go
--Populate test data
declare @ThematicTagId int
exec spSaveThematicTag @ThematicTagId output, 'Test Tag-1', 1, 1126
go
declare @ThematicTagId int
exec spSaveThematicTag @ThematicTagId output, 'Test Tag-2', 1, 1126
go
declare @ThematicTagId int
exec spSaveThematicTag @ThematicTagId output, 'Test Tag-3', 1, 1126
go

*/
