--03/15/2018
--CC_spSaveProductGroupModelsByProductGroup_Rollback.sql

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

alter procedure [dbo].[spSaveProductGroupModelsByProductGroup] @ProductGroupId int
as
begin
  delete from ProductGroupModels where ProductGroupId = @ProductGroupId

  insert into ProductGroupModels(SecurityId, ProductGroupId)

  --Populate ProductGroupModels table based on industries within the product group
  --only for primary tickers
  select S.SecurityId,PGF.ProductGroupId
  from ProductGroupFields PGF
  join Industries I on PGF.FieldValue = I.IndustryId
  join ResearchCoverage RC on I.IndustryId  = RC.IndustryId
  join Securities2 S on RC.SecurityId = S.SecurityId
  where RC.LaunchDate is not null and RC.DropDate is null
  and RC.ModelDistribution = 'Y'
  and S.IsPrimary = 'Y'
  and PGF.ProductGroupId = @ProductGroupId
  and PGF.FieldId = 1

  union

  --Populate ProductGroupModels table based on authors within the product group
  --only for primary tickers
  select S.SecurityId,PGF.ProductGroupId
  from ProductGroupFields PGF
  join Authors A on PGF.FieldValue = A.AuthorId
  join ResearchCoverage RC on A.AuthorId = RC.AnalystId
  join Securities2 S on RC.SecurityId = S.SecurityId
  where RC.LaunchDate is not null and RC.DropDate is null
  and RC.ModelDistribution = 'Y'
  and S.IsPrimary = 'Y'
  and PGF.ProductGroupId = @ProductGroupId
  and PGF.FieldId = 3

  union

  --Populate ProductGroupModels table based on tickers within the product group
  --only for primary tickers
  select S.SecurityId,PGF.ProductGroupId
  from ProductGroupFields PGF
  join Securities2 S on PGF.FieldValue = S.SecurityId
  join ResearchCoverage RC on S.SecurityId = RC.SecurityId
  where RC.LaunchDate is not null and RC.DropDate is null
  and RC.ModelDistribution = 'Y'
  and S.IsPrimary = 'Y'
  and PGF.ProductGroupId = @ProductGroupId
  and PGF.FieldId = 2

end


