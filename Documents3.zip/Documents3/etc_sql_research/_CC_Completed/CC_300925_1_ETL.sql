-- ETL.sql
-- 12/18/2018

/*
alter table PortalUsage - add TransactionId, EmbargoStyle, FileName, LoadDate
create index (SiteId, TransactionId) on PortalUsage
create table FileLoadInstructions
create table PortalClientEmbargo - Based on the daily files - set [NumDaysEmbargo] = 30 or 90
create proc spGetFileLoadInstruction   -- used by file loader assembly

-- Bloomberg
drop/create table PortalUsageStaging_Bloomberg
alter proc spLoadPortalUsageFromStaging_Bloomberg

--Factset
drop/create table PortalUsageStaging_FactSet
alter proc spLoadPortalUsageFromStaging_FactSet

--ThomsonReuters
drop/create table PortalUsageStaging_TR
alter proc spLoadPortalUsageFromStaging_TR

--CapitalIQ
drop/create table PortalUsageStaging_CIQ
alter proc spLoadPortalUsageFromStaging_CIQ

alter proc spAddFileProcessingLog  -- after staging tables

copy data from PortalLoadLog to FileProcessingLog
copy data from PortalUsage(Current) to temp to PortalUsage(Proposed)
** Currently PRD data has no TransactionId, so delete last 3 months data and re-load last 3 months data that has TransactionId

NOTES:
- PortalUsage.[SubSite] column: Factset: [Platform], TR [Delivery]
- PortalUsage.[AccountType] column: TR [ClientType], CIQ (Missing [Firm Type])
- CapitalIQ provides a single day that has 3 days data - 1d most recent (pre-embargo), 31d (post-embargo), 91d (post-embargo)
- 31d and 91d readership data files have certain accounts (Factset, TR) that shows up in both files, need field that shows both indicators
- Factset monthly has 10 more columns - need seperate staging table
- Bloomberg monthly has lot more columns - need seperate staging table
- Duplicate Account found for certain account reads with different Account Id
  SELECT * FROM PortalClientEmbargo WHERE DataStore = 'Bloomberg' and NumDaysEmbargo = 30 AND Account = 'ABU DHABI INVESTMENT AUTHORITY'

Load logic:
-- PortalUsage - If transaction id exists in Portal Usage table then update, i.e. update embargo state
                 If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
-- PortalClientEmbargo - When accounts shows up in 30d and 90d files, mark it as min(date) i.e. 30d

Next Steps (Tentative):
1.0 - Dec 2018 - Holdings and Visible alpha
1.1 - Feb 2019 - CC - daily files load for Bloomberg, Factset, TR, CIQ
                 load 2018-YTD daily files for bloomberg
1.2 - Mar 2019 - daily files load for BlueMatrix, Red Deer, ONEAccess, RSRCHX
1.3 - Apr 2019 - File Load UI
1.4 - May 2019 - Monthly files load for Bloomberg, Factset, TR, CIQ
1.5 - Jun 2019 - Monthly files load for BlueMatrix, Red Deer, ONEAccess, RSRCHX

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM sys.indexes WHERE Name = N'IX_PortalUsage_SiteIdTransactionId' AND Object_ID = Object_ID(N'[dbo].[PortalUsage]'))
   DROP INDEX IX_PortalUsage_SiteIdTransactionId ON [dbo].[PortalUsage]
GO

-- alter PortalUsage, add columns
IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'TransactionId' AND Object_ID = Object_ID(N'[dbo].[PortalUsage]'))
  ALTER TABLE [dbo].[PortalUsage] DROP COLUMN TransactionId
GO
ALTER TABLE PortalUsage ADD TransactionId VARCHAR(500)
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'EmbargoStyle' AND Object_ID = Object_ID(N'[dbo].[PortalUsage]'))
  ALTER TABLE [dbo].[PortalUsage] DROP COLUMN EmbargoStyle
GO
ALTER TABLE PortalUsage ADD EmbargoStyle VARCHAR(50)
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'FileName' AND Object_ID = Object_ID(N'[dbo].[PortalUsage]'))
  ALTER TABLE [dbo].[PortalUsage] DROP COLUMN [FileName]
GO
ALTER TABLE PortalUsage ADD FileName VARCHAR(100)
GO

IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'LoadDate' AND Object_ID = Object_ID(N'[dbo].[PortalUsage]'))
  ALTER TABLE [dbo].[PortalUsage] DROP COLUMN LoadDate
GO
ALTER TABLE PortalUsage ADD LoadDate DATETIME
GO

-- Index to speed up joins between PortalUsage and Staging tables
CREATE NONCLUSTERED INDEX [IX_PortalUsage_SiteIdTransactionId] ON [dbo].[PortalUsage]
  ([SiteId] ASC, [TransactionId] ASC) ON [PRIMARY]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FileLoadInstructions]') AND type in (N'U'))
DROP TABLE [dbo].[FileLoadInstructions]
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalClientEmbargo]') AND type in (N'U'))
DROP TABLE [dbo].[PortalClientEmbargo]
GO

-- create FileProcessingConfig
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FileProcessingConfig]') AND type in (N'U'))
   DROP TABLE [dbo].[FileProcessingConfig]
GO
CREATE TABLE [dbo].[FileProcessingConfig]
(
  [ConfigId]       [int]           NOT NULL IDENTITY(1,1),
  [DataStore]      [varchar](30)   NOT NULL,
  [SourceFilePath] [nvarchar](max) NOT NULL,
  [BackupFilePath] [nvarchar](max) NOT NULL,
  CONSTRAINT [PK_FileProcessingConfig] PRIMARY KEY CLUSTERED ( [DataStore] ASC ) ON [PRIMARY]
) ON [PRIMARY]
GO
-- create unique constraint on [ConfigId]
ALTER TABLE [dbo].[FileProcessingConfig] ADD CONSTRAINT IX_FileProcessingConfig_ConfigId UNIQUE (ConfigId)
GO

-- create FileLoadInstructions
CREATE TABLE [dbo].[FileLoadInstructions](
  [FileLoadInstructionId] [int]         NOT NULL IDENTITY(1,1),
  [DataStore]             [varchar](30) NOT NULL,
  [FileFragment]          [varchar](50) NOT NULL,
  [FileType]              [varchar](50)     NULL,
  [FileFrequency]         [varchar](50)     NULL,
  [EmbargoStyle]          [varchar](50)     NULL,
  CONSTRAINT [PK_FileLoadInstructions] PRIMARY KEY CLUSTERED ([FileLoadInstructionId] ASC)
) ON [PRIMARY]
GO

-- create unique constraint on [FileFragment]
ALTER TABLE [dbo].[FileLoadInstructions] ADD CONSTRAINT IX_FileLoadInstructions_FileFragment UNIQUE (DataStore, FileFragment);
GO

ALTER TABLE [dbo].[FileLoadInstructions]  WITH CHECK ADD  CONSTRAINT [FK_FileLoadInstructions_DataStore] FOREIGN KEY([DataStore])
REFERENCES [dbo].[FileProcessingConfig] ([DataStore])
GO

-- create PortalClientEmbargo
CREATE TABLE [dbo].[PortalClientEmbargo](
    [ClientEmbargoId]   [int]           NOT NULL IDENTITY(1,1),
    [DataStore]         [varchar](30)   NOT NULL,
    [Account]           [varchar](250)  NOT NULL,
    [AccountId]         [varchar](50)       NULL,
    [NumDaysEmbargo]    [int]               NULL,
    CONSTRAINT [PK_PortalClientEmbargo] PRIMARY KEY CLUSTERED ([ClientEmbargoId] ASC)
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PortalClientEmbargo]  WITH CHECK ADD  CONSTRAINT [FK_PortalClientEmbargo_DataStore] FOREIGN KEY([DataStore])
REFERENCES [dbo].[FileProcessingConfig] ([DataStore])
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetFileLoadInstruction]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spGetFileLoadInstruction]
GO

-- =================================================================================================
-- Author:       Anup Singh
-- Revisions:    27/12/2018 - Created
-- Description:  It will fetch file load Instruction details
-- =================================================================================================
CREATE PROC [dbo].[spGetFileLoadInstruction]
  @datastore as nvarchar(100)
AS
BEGIN
SET NOCOUNT ON
  SELECT * FROM FileLoadInstructions WHERE DataStore = @datastore
END
GO

-- alter Bloomberg staging table
-- Pre-embargo file - dlyN2SCB_ddmmyyyy.csv - 7 user columns missing
-- [UUID], [User Name], [Business Email], [Alternate Email], [User Country], [User State], [User City]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_Bloomberg]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_Bloomberg]
GO

CREATE TABLE [dbo].[PortalUsageStaging_Bloomberg](
  [Story ID]        [varchar](500)  NULL,
  [Wire]            [varchar](500)  NULL,
  [Class]           [varchar](500)  NULL,
  [Customer #]      [varchar](500)  NULL,
  [Customer Name]   [varchar](500)  NULL,
  [Firm #]          [varchar](500)  NULL,
  [UUID]            [varchar](500)  NULL,
  [User Name]       [varchar](500)  NULL,
  [Business Email]  [varchar](500)  NULL,
  [Alternate Email] [varchar](500)  NULL,
  [User Country]    [varchar](500)  NULL,
  [User State]      [varchar](500)  NULL,
  [User City]       [varchar](500)  NULL,
  [Transaction ID]  [varchar](500)  NULL,
  [Story Headline]  [varchar](500)  NULL,
  [Post Date]       [varchar](500)  NULL,
  [Read Date]       [varchar](500)  NULL
) ON [PRIMARY]
GO

-- alter proc to load Portal Usage data for Bloomberg
ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table
DECLARE
  @SiteId           INT,
  @SubSite          VARCHAR(50),
  @ContentType      VARCHAR(50),
  @DataStore        NVARCHAR(200),
  @PreEmbargoedText VARCHAR(30),
  @LoadDate         DATETIME,
  @PeriodStartDate  VARCHAR(10),
  @PeriodEndDate    VARCHAR(10),
  @RowsLoaded       INT

SET @SiteId = 3                       -- Bloomberg
SET @DataStore = 'Bloomberg'
SET @SubSite = 'Bloomberg'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_Bloomberg) RETURN

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_Bloomberg BB
WHERE BB.[Transaction ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    CASE WHEN ISNUMERIC([Story Id]) = 1 THEN [Story ID] ELSE 0 END AS StoryId,
    [Read Date],
    @SiteId,
    @SubSite,
    [Business Email],
    [User Name],
    CASE WHEN ISNUMERIC([UUID]) = 1 THEN [UUID] ELSE NULL END AS UUID,
    [Customer Name],
    [Customer #],
    NULL,
    [Transaction ID],
    @EmbargoStyle,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_Bloomberg BB
    WHERE BB.[Transaction ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_Bloomberg BB ON PU.TransactionId = BB.[Transaction ID] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage that were previously embargoed, with post-embargo data from Staging table by Transaction Id
  UPDATE PU
  SET PU.Email = BB.[Business Email],
      PU.Contact = BB.[User Name],
      PU.ContactId = CASE WHEN ISNUMERIC(BB.[UUID]) = 1 THEN [UUID] ELSE NULL END,
      PU.Account = BB.[Customer Name],
      PU.AccountId = BB.[Customer #],
      PU.EmbargoStyle = @EmbargoStyle,
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_Bloomberg BB ON PU.TransactionId = BB.[Transaction ID] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update rows marked as Pre-embargo (PRE)

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Populate [PortalClientEmbargo] table by accounts and file name e.g. 30d, 90d etc.
-- only the daily files to be used to populate client embargoes
-- monthly files should not be used to populate client embargoes

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct BB.[Customer Name]) FROM PortalUsageStaging_Bloomberg BB
WHERE BB.[Customer Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

DECLARE @NumEmbargoRowstoUpdate AS INT
SELECT @NumEmbargoRowstoUpdate = COUNT(*) FROM PortalClientEmbargo PCE
JOIN PortalUsageStaging_Bloomberg BB ON PCE.Account = BB.[Customer Name] AND PCE.DataStore = @DataStore

IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST30'
BEGIN
  -- Insert 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
    INSERT INTO PortalClientEmbargo (DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, BB.[Customer Name], BB.[Customer #], 30
    FROM PortalUsageStaging_Bloomberg BB
    WHERE BB.[Customer Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
      AND BB.[Customer Name] != 'N/A'
  END

  -- Update 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoUpdate > 0
  BEGIN
    UPDATE pce
    SET pce.NumDaysEmbargo = 30
    FROM [PortalClientEmbargo] AS pce
    INNER JOIN PortalUsageStaging_Bloomberg BB ON BB.[Customer #] = pce.[AccountId] AND BB.[Customer Name] = pce.[Account]
    WHERE pce.DataStore = @DataStore
  END
END
ELSE IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST90'
BEGIN
  -- Insert 90d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
    INSERT INTO PortalClientEmbargo (DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, BB.[Customer Name], BB.[Customer #], 90
    FROM PortalUsageStaging_Bloomberg BB
    WHERE BB.[Customer Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND BB.[Customer Name] != 'N/A'
  END
  /* if an account was mapped as 30 day embargo, do not re-map as 90 day, if reads also found in POST90 file */
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date] AS DATE) ), 101),
       @PeriodEndDate   = CONVERT(VARCHAR, MAX(CAST([Read Date] AS DATE) ), 101)
FROM PortalUsageStaging_Bloomberg
WHERE ISDATE([Read Date]) = 1

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END
GO

-- alter Factset staging table
-- Remove 2 columns - daily files - L_1_DAYS, L_31_DAYS, L_91_DAYS - 2 user columns missing
-- [Doc ID (FactSet)], [Date/time received]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_FactSet]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_FactSet]
GO

CREATE TABLE [dbo].[PortalUsageStaging_FactSet](
  [Date/time read]                [varchar](500) NULL,
  [Platform]                      [varchar](500) NULL,
  [Reader ID (FactSet)]           [varchar](500) NULL,
  [Reader name]                   [varchar](500) NULL,
  [E-mail]                        [varchar](500) NULL,
  [Phone]                         [varchar](500) NULL,
  [Parent Firm ID (FactSet)]      [varchar](500) NULL,
  [Parent Firm name]              [varchar](500) NULL,
  [Firm ID (FactSet)]             [varchar](500) NULL,
  [Firm name]                     [varchar](500) NULL,
  [Address]                       [varchar](500) NULL,
  [City]                          [varchar](500) NULL,
  [State]                         [varchar](500) NULL,
  [Country]                       [varchar](500) NULL,
  [Doc ID (contributor)]          [varchar](500) NULL,
  [Readership Event ID (FactSet)] [varchar](500) NULL,
  [Date/time published]           [varchar](500) NULL,
  [Report title]                  [varchar](500) NULL
) ON [PRIMARY]
GO

-- alter proc to load Portal Usage data for Factset
ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table
DECLARE
  @SiteId           INT,
  @SubSite          VARCHAR(50),
  @ContentType      VARCHAR(50),
  @DataStore        NVARCHAR(200),
  @PreEmbargoedText VARCHAR(30),
  @LoadDate         DATETIME,
  @PeriodStartDate  VARCHAR(10),
  @PeriodEndDate    VARCHAR(10),
  @RowsLoaded       INT

SET @SiteId = 12        -- Factset
SET @DataStore = 'Factset'
SET @SubSite = 'Factset'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_FactSet) RETURN

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_FactSet FS
WHERE FS.[Readership Event ID (FactSet)] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    CASE WHEN ISNUMERIC([Doc ID (contributor)]) = 1 THEN [Doc ID (contributor)] ELSE 0 END AS StoryId,
    [Date/time read],
    @SiteId,
    [Platform],
    [E-mail],
    [Reader name],
    CASE WHEN ISNUMERIC([Reader ID (FactSet)]) = 1 THEN [Reader ID (FactSet)] ELSE NULL END AS UUID,
    [Firm name],
    [Firm ID (FactSet)],
    NULL,
    [Readership Event ID (FactSet)],
    @EmbargoStyle,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_Factset FS
    WHERE FS.[Readership Event ID (FactSet)] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_FactSet FS ON PU.TransactionId = FS.[Readership Event ID (FactSet)] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage with post-embargo data from Staging table by Transaction Id
  UPDATE PU
  SET PU.Email = FS.[E-mail],
      PU.Contact = FS.[Reader name],
      PU.ContactId = CASE WHEN ISNUMERIC(FS.[Reader ID (FactSet)]) = 1 THEN [Reader ID (FactSet)] ELSE NULL END,
      PU.Account = FS.[Firm name],
      PU.AccountId = FS.[Firm ID (FactSet)],
      PU.EmbargoStyle = @EmbargoStyle,
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_Factset FS ON PU.TransactionId = FS.[Readership Event ID (FactSet)] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update rows marked as Pre-embargo (PRE)

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Populate [PortalClientEmbargo] table as per the file name e.g. 30d, 90d etc.
-- only the daily files to be used to populate client embargoes
-- monthly files should not be used to populate client embargoes

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct FS.[Firm name]) FROM PortalUsageStaging_FactSet FS
WHERE FS.[Firm name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

DECLARE @NumEmbargoRowstoUpdate AS INT
SELECT @NumEmbargoRowstoUpdate = COUNT(*) FROM PortalClientEmbargo PCE
JOIN PortalUsageStaging_FactSet FS ON PCE.Account = FS.[Firm name] AND PCE.DataStore = @DataStore

IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST30'
BEGIN
  -- Insert 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, FS.[Firm name], FS.[Firm ID (FactSet)], 30
    FROM PortalUsageStaging_Factset FS
    WHERE FS.[Firm name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND FS.[Firm name] != '***'
  END

  -- Update 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoUpdate > 0
  BEGIN
    UPDATE pce
    SET pce.NumDaysEmbargo = 30
    FROM PortalClientEmbargo AS pce
    INNER JOIN PortalUsageStaging_Factset FS ON FS.[Firm ID (FactSet)] = pce.[AccountId] AND FS.[Firm name] = pce.[Account]
    WHERE pce.DataStore = @DataStore
  END
END
ELSE IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST90'
BEGIN
  -- Insert 90d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, FS.[Firm name], FS.[Firm ID (FactSet)], 90
    FROM PortalUsageStaging_Factset FS
    WHERE FS.[Firm name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND FS.[Firm name] != '***'
  END

  /* if an account was mapped as 30 day embargo, do not re-map as 90 day, if reads also found in POST90 file */
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Date/time read] AS DATE) ), 101),
       @PeriodEndDate   = CONVERT(VARCHAR, MAX(CAST([Date/time read] AS DATE) ), 101)
FROM PortalUsageStaging_Factset
WHERE ISDATE([Date/time read]) = 1

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END
GO

--   [Transaction ID]    [varchar](500)  NULL    -- new column added for ftp files
GO

-- Thomson Reuters staging table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_TR]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_TR]
GO

CREATE TABLE [dbo].[PortalUsageStaging_TR](
  [TR DocID]          [varchar](500)  NULL,
  [Local DocID]       [varchar](500)  NULL,
  [Headline]          [varchar](500)  NULL,
  [# Pages]           [varchar](500)  NULL,
  [Ticker]            [varchar](500)  NULL,
  [Industry]          [varchar](500)  NULL,
  [Country]           [varchar](500)  NULL,
  [Analyst]           [varchar](500)  NULL,
  [TR Analyst ID]     [varchar](500)  NULL,
  [Local Analyst ID]  [varchar](500)  NULL,
  [Published Date]    [varchar](500)  NULL,
  [Viewed Date]       [varchar](500)  NULL,
  [Client Name]       [varchar](500)  NULL,
  [Client Company ID] [varchar](500)  NULL,
  [User Name]         [varchar](500)  NULL,
  [Unique ID]         [varchar](500)  NULL,
  [User Job Role]     [varchar](500)  NULL,
  [User Division]     [varchar](500)  NULL,
  [User Email]        [varchar](500)  NULL,
  [User Phone]        [varchar](500)  NULL,
  [User Address]      [varchar](500)  NULL,
  [User City]         [varchar](500)  NULL,
  [User State]        [varchar](500)  NULL,
  [User Country]      [varchar](500)  NULL,
  [Client Address]    [varchar](500)  NULL,
  [Client City]       [varchar](500)  NULL,
  [Client State]      [varchar](500)  NULL,
  [Client Country]    [varchar](500)  NULL,
  [Client Type]       [varchar](500)  NULL,
  [Delivery]          [varchar](500)  NULL,
  [Transaction ID]    [varchar](500)  NULL
) ON [PRIMARY]
GO

-- alter proc to load Portal Usage data for Factset
ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table
DECLARE
  @SiteId           INT,
  @SubSite          VARCHAR(50),
  @ContentType      VARCHAR(50),
  @DataStore        NVARCHAR(200),
  @PreEmbargoedText VARCHAR(30),
  @LoadDate         DATETIME,
  @PeriodStartDate  VARCHAR(10),
  @PeriodEndDate    VARCHAR(10),
  @RowsLoaded       INT

SET @SiteId = 9      -- Thomson Reuters
SET @DataStore = 'TR'
SET @SubSite = 'TR'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_TR) RETURN

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_TR TR
WHERE TR.[Transaction ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    CASE WHEN ISNUMERIC(TR.[Local DocID]) = 1 THEN TR.[Local DocID] ELSE 0 END AS StoryId,
    TR.[Viewed Date],
    @SiteId,
    [Delivery],
    TR.[User Email],
    TR.[User Name],
    CASE WHEN ISNUMERIC(TR.[Unique ID]) = 1 THEN TR.[Unique ID] ELSE NULL END AS UUID,
    TR.[Client Name],
    TR.[Client Company ID],
    TR.[Client Type],
    TR.[Transaction ID],
    @EmbargoStyle,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_TR TR
    WHERE TR.[Transaction ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_TR TR ON PU.TransactionId = TR.[Transaction ID] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
-- Update those rows that were previously embargoed
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage with post-embargo data from Staging table by Transaction Id
  UPDATE pu
  SET PU.Email = TR.[User Email],
      PU.Contact = TR.[User Name],
      PU.ContactId = CASE WHEN ISNUMERIC(TR.[Unique ID]) = 1 THEN TR.[Unique ID] ELSE NULL END,
      PU.Account = TR.[Client Name],
      PU.AccountId = TR.[Client Company ID],
      PU.EmbargoStyle = @EmbargoStyle,
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_TR TR ON PU.TransactionId = TR.[Transaction ID] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update only the Pre-embargo rows

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Populate [PortalClientEmbargo] table as per the file name e.g. 30d, 90d etc.
-- only the daily files to be used to populate client embargoes
-- monthly files should not be used to populate client embargoes

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct TR.[Client Name]) FROM PortalUsageStaging_TR TR
WHERE TR.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

DECLARE @NumEmbargoRowstoUpdate AS INT
SELECT @NumEmbargoRowstoUpdate = COUNT(*) FROM PortalClientEmbargo PCE
JOIN PortalUsageStaging_TR TR  ON PCE.Account = TR.[Client Name] AND PCE.DataStore = @DataStore

IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST30'
BEGIN

  -- Insert 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, TR.[Client Name], TR.[Client Company ID], 30
    FROM PortalUsageStaging_TR TR
    WHERE TR.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
  END

  -- Update 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoUpdate > 0
  BEGIN
     UPDATE pce
     SET pce.NumDaysEmbargo = 30
     FROM PortalClientEmbargo AS pce
     INNER JOIN PortalUsageStaging_TR TR ON TR.[Client Company ID] = pce.[AccountId] AND TR.[Client Name] = pce.[Account]
     WHERE pce.DataStore = @DataStore
  END
END
ELSE IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST90'
BEGIN
  -- Insert 90d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
     INSERT INTO [PortalClientEmbargo] (DataStore, Account, AccountId, NumDaysEmbargo)
     SELECT DISTINCT @DataStore, TR.[Client Name], TR.[Client Company ID], 90
     FROM PortalUsageStaging_TR TR
     WHERE TR.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
  END
  /* if an account was mapped as 30 day embargo, do not re-map as 90 day, if reads also found in POST90 file */
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST(TR.[Viewed Date] AS DATE) ), 101),
       @PeriodEndDate   = CONVERT(VARCHAR, MAX(CAST(TR.[Viewed Date] AS DATE) ), 101)
FROM PortalUsageStaging_TR TR
WHERE ISDATE(TR.[Viewed Date]) = 1

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_CIQ]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_CIQ]
GO

/* New file format from CIQ  - ResearchActivity.txt */
GO
CREATE TABLE [dbo].[PortalUsageStaging_CIQ](
  [Ctb Doc Id]    [varchar](500)  NULL,
  [Client]        [varchar](500)  NULL,
  [User]          [varchar](500)  NULL,
  [Client Name]   [varchar](500)  NULL,
  [User Name]     [varchar](500)  NULL,
  [Email]         [varchar](500)  NULL,
  [Activity Id]   [varchar](500)  NULL,
  [Activity Date] [varchar](500)  NULL,
  [Headline]      [varchar](500)  NULL,
  [Type]          [varchar](500)  NULL
) ON [PRIMARY]
GO

-- alter proc to load Portal Usage data for CapitalIQ
ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table
DECLARE
  @SiteId           INT,
  @SubSite          VARCHAR(50),
  @ContentType      VARCHAR(50),
  @DataStore        NVARCHAR(200),
  @PreEmbargoedText VARCHAR(30),
  @LoadDate         DATETIME,
  @PeriodStartDate  VARCHAR(10),
  @PeriodEndDate    VARCHAR(10),
  @RowsLoaded       INT

SET @SiteId = 11                  -- CapitalIQ
SET @DataStore = 'CIQ'
SET @SubSite = 'CIQ'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'     -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_CIQ) RETURN

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_CIQ CIQ
WHERE CIQ.[Activity Id] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    -- Content Id
    CASE WHEN ISNUMERIC(CIQ.[Ctb Doc Id]) = 1 THEN CIQ.[Ctb Doc Id] ELSE 0 END,
    CIQ.[Activity Date],
    @SiteId,
    @SubSite,
    CIQ.[Email],
    CIQ.[User Name],
    CASE WHEN ISNUMERIC(CIQ.[User]) = 1 THEN CIQ.[User] ELSE NULL END AS UUID,
    CIQ.[Client Name],
    CIQ.[Client],
    NULL,
    CIQ.[Activity Id],
    -- Embargo Style
    CASE
      WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 90 THEN 'POST90'
      WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 30 THEN 'POST30'
      WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 1  THEN 'PRE'
      ELSE 'MIXED'
    END,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_CIQ CIQ
  WHERE CIQ.[Activity Id] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_CIQ CIQ ON PU.TransactionId = CIQ.[Activity Id] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
-- Update those rows that were previously embargoed
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage with post-embargo data from Staging table by Transaction Id
  UPDATE pu
  SET PU.Email = CIQ.[Email],
      PU.Contact = CIQ.[User Name],
      PU.ContactId = CASE WHEN ISNUMERIC(CIQ.[User]) = 1 THEN CIQ.[User] ELSE NULL END,
      PU.Account = CIQ.[Client Name],
      PU.AccountId = CIQ.[Client],
      PU.EmbargoStyle =
      CASE
          WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 90 THEN 'POST90'     -- reads in last -91 days
          WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 30 THEN 'POST30'     -- reads in last -31 days
          WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 1  THEN 'PRE'        -- reads in last -2 days
          ELSE ''
      END,
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_CIQ CIQ ON PU.TransactionId = CIQ.[Activity Id] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update only the Pre-embargo rows

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Populate [PortalClientEmbargo] table as per the file name e.g. ResearchActivity
-- only the daily files to be used to populate client embargoes
-- CapitalIQ daily file has -1, -31, -91 day read data

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct CIQ.[Client Name]) FROM PortalUsageStaging_CIQ CIQ
WHERE CIQ.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'MIXED'
BEGIN
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
      -- Identify accounts with 90 day embargo
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, CIQ.[Client Name], CIQ.[Client], 90
        FROM PortalUsageStaging_CIQ CIQ
    WHERE DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 90
    AND CIQ.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND LTRIM(RTRIM(CIQ.[Client Name])) != ''

    --Identify accounts with 30 day embargo
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, CIQ.[Client Name], CIQ.[Client], 30
        FROM PortalUsageStaging_CIQ CIQ
    WHERE DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 30 AND DATEDIFF(d, CIQ.[Activity Date], getdate()) < 90
    AND CIQ.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND LTRIM(RTRIM(CIQ.[Client Name])) != ''
  END
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST(CIQ.[Activity Date] AS DATE) ), 101),
       @PeriodEndDate   = CONVERT(VARCHAR, MAX(CAST(CIQ.[Activity Date] AS DATE) ), 101)
FROM PortalUsageStaging_CIQ CIQ
WHERE ISDATE(CIQ.[Activity Date]) = 1

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END
GO

-- =================================================================================================
-- Author:       Anup Singh
-- Revisions:    10/23/2018 - Created
-- Description:  To enter log for file processing project like Holdings, Readership,Model
-- =================================================================================================
ALTER PROC [dbo].[spAddFileProcessingLog]
(
 @DataStore as nvarchar(250),
 @filename as nvarchar(250),
 @ServerName as nvarchar(100),
 @EditorId as int,
 @Comment as nvarchar(max) = null
)
AS
BEGIN

    IF @DataStore  = 'Holdings'
    BEGIN
        INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,LastExecution))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,LastExecution))), 101)
           ,count(*)
           ,@EditorId
           ,'Holdings ' + Convert(varchar(10),count(*)) + ' / vHoldings ' + Convert(Varchar(10),(select count(*) from vHoldings))
           from Holdings
    END
    ELSE IF @DataStore  = 'ONEaccess'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,file_date_UTC))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,file_date_UTC))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_ONEaccess
    END
    ELSE IF @DataStore  = 'Bloomberg'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Read Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Read Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_Bloomberg
    END

    ELSE IF @DataStore  = 'BlueMatrix'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Read Date/Time]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Read Date/Time]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_BlueMatrix
    END
    ELSE IF @DataStore  = 'FactSet'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Date/time read]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Date/time read]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_FactSet
    END
    ELSE IF @DataStore  = 'TR' or @DataStore = 'THOMSONREUTERS'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Viewed Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Viewed Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_TR
    END
    ELSE IF @DataStore  = 'CIQ'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Activity Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Activity Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_CIQ
    END

    ELSE IF @DataStore  = 'RSRCHX'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Action Date (UTC)]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Action Date (UTC)]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_RSRCHX
    END

    ELSE IF @DataStore  = 'REDDEER'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(Convert(Date,[Read_Date]))), 101)
           ,convert(varchar, Convert(date,Max(Convert(Date,[Read_Date]))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_RedDeer
    END
    ELSE IF @DataStore  = 'VISIBLEALPHA'
    BEGIN
         INSERT INTO FileProcessingLog
                                   (
                     LoadDate
                    ,DataStore
                    ,[Server]
                    ,[FileName]
                    ,PeriodStart
                    ,PeriodEnd
                    ,RowsLoaded
                    ,EditorId
                    ,Comment
                     )
        select GETDATE()
               ,@DataStore
           ,@ServerName
               ,@filename
           ,convert(varchar, Convert(date,Min(CONVERT(date,replace(file_date_UTC,'Z',':00'),127))), 101)
           ,convert(varchar, Convert(date,Max(CONVERT(date,replace(file_date_UTC,'Z',':00'),127))), 101)
           ,count(*)
           ,@EditorId
           ,@Comment
           from PortalUsageStaging_VisibleAlpha
    END
END
GO

-- Grant Permissions
GRANT EXECUTE                ON [dbo].[spAddFileProcessingLog]        TO DE_IIS, PowerUsers
GRANT EXECUTE                ON [dbo].[spGetFileLoadInstruction]      TO DE_IIS, PowerUsers
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_Bloomberg]  TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_FactSet]    TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_TR]         TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_CIQ]        TO DE_IIS
GO

-- DEBUG
/*
SELECT * FROM FileProcessingConfig ORDER BY ConfigId
SELECT * FROM FileLoadInstructions
SELECT * FROM PortalClientEmbargo
SELECT * FROM FileProcessingLog ORDER BY LogId desc
GO

-- Bloomberg
-- Compare PRD vs DEV month by month for 2018
SELECT 'Year' = Year(ReadDate), 'Month' = Month(ReadDate), 'Reads' = COUNT(*)
FROM PortalUsage
WHERE SiteId = 3 -- Bloomberg
AND Year(ReadDate) IN (2018, 2019)
GROUP BY Year(ReadDate), Month(ReadDate)
ORDER BY Year(ReadDate), Month(ReadDate)
*/
