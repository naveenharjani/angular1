-- spGetReportsForAuthor.sql
-- 11/07/2017

/*

spGetReportsForAuthor

*/

USE [Research]
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where name = 'spGetReportsForAuthor' and type = 'P')
drop proc dbo.spGetReportsForAuthor
go

create procedure dbo.spGetReportsForAuthor @AnalystId int, @iShowMore int
as
begin
	select P.PubNo,convert(varchar(10),Date,110) PubDate,Title
	from Publications P join Properties Pr on P.PubNo = Pr.PubNo and Pr.PropId = 5
	join Authors A on Pr.PropValue = A.Name
	where A.AuthorId = @AnalystId and P.Type not in ('Video','Black Book') and  P.Date >= dateadd(mm,-6,getdate())
	union
	select P.PubNo,convert(varchar(10),Date,110) PubDate,Title
	from Publications P join Properties Pr on P.PubNo = Pr.PubNo and Pr.PropId = 5
	join Authors A on Pr.PropValue = A.Name
	where A.AuthorId = @AnalystId and P.Type in ('Black Book') and P.Date >= dateadd(yy,-1,getdate())
	order by P.PubNo desc
end
go

grant execute on dbo.spGetReportsForAuthor to DE_IIS, PowerUsers
go

/*

spGetReportsForAuthor 421, 0 -- Warburton
spGetReportsForAuthor 421, 1 -- Warburton

*/
