-- GIC.sql
-- 11/16/2017

/*

spRptGICRatingsHistory       -- Added RatingPrior
spRptGICTargetPriceHistory   -- Added TargetPricePrior

*/

USE [Research]
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spRptGICRatingsHistory]
  @SinceDate  varchar(20),
  @UntilDate  varchar(20)
AS
select
  S.Company,
  S.Ticker,
  S.SEDOL,
  S.CountryCode,
  A.Last + ', ' + A.First as Analyst,
  convert(varchar, VF.Date, 101) as RatingDate,
  VF.Rating,
  isnull(VF.RatingPrior, '') AS RatingPrior
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join Authors A on RC.AnalystId = A.AuthorId
join vFinancials VF on VF.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null and RC.SecurityId is not null
and VF.RatingAction <> 'Reiterate'
and Date between @SinceDate AND @UntilDate
order by 1, 2

GO

ALTER PROCEDURE [dbo].[spRptGICTargetPriceHistory]
  @SinceDate  varchar(20),
  @UntilDate  varchar(20)
AS
select
  S.Company,
  S.Ticker,
  S.SEDOL,
  S.CountryCode,
  A.Last + ', ' + A.First as Analyst,
  convert(varchar, VF.Date, 101) as TargetPriceDate,
  VF.TargetPrice,
  isnull(VF.TargetPricePrior, '') AS TargetPricePrior,
  VF.Currency
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join Authors A on RC.AnalystId = A.AuthorId
join vFinancials VF on VF.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null and RC.SecurityId is not null
and (VF.TargetPriceAction in ('increase', 'decrease') or VF.RatingAction <> 'Reiterate')
and Date between @SinceDate AND @UntilDate
order by 1, 2

GO

/*

EXEC [spRptGICRatingsHistory] '01/01/2017', '10/31/2017'

EXEC [spRptGICTargetPriceHistory] '01/01/2017', '10/31/2017'

*/
