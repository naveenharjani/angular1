-- SolactiveNotes.sql
-- 06/29/2017

/*

solactive.asp      - Add Note column
solactivenotes.asp - Model after solactive.asp
solactivenote.asp  - Model after valrisksanalyst.asp

SolactiveNotes

alter spSearchSolactiveIndexTickers - Add Note column
create spSearchSolactiveNotes - Model after spSearchSolactiveIndexTickers
create spGetSolactiveNote - Model after spGetRisksAnalyst
create spSaveSolactiveNote - Model after [spSaveRisksAnalyst]

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
set ARITHABORT ON
set CONCAT_NULL_YIELDS_NULL ON
set QUOTED_IDENTIFIER ON
set ANSI_NULLS ON
set ANSI_PADDING ON
set ANSI_WARNINGS ON
set NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where name = 'SolactiveNotes' and type = 'u')
drop table [dbo].[SolactiveNotes]
go

create table [dbo].[SolactiveNotes]
(
  SecurityId int           NOT NULL,
  Note       varchar(2048) NOT NULL,
  EditorId   int           NOT NULL,
  EditDate   datetime      NOT NULL
)
go

ALTER TABLE [dbo].[SolactiveNotes] WITH CHECK ADD CONSTRAINT IX_SolactiveNotes UNIQUE CLUSTERED (SecurityId)
GO

ALTER TABLE [dbo].[SolactiveNotes] WITH CHECK ADD CONSTRAINT FK_SolactiveNotes_Securities2 FOREIGN KEY (SecurityId)
REFERENCES [dbo].[Securities2] (SecurityId)
GO

ALTER PROCEDURE [dbo].[spRenderAdminLogTables]
AS
SELECT DISTINCT
  'Value'   = [Table],
  'Display' =
    CASE [Table]
      WHEN 'AnalystTeamMembers'    THEN 'Analyst Team Members'
      WHEN 'UserRoles'             THEN 'User Roles'
      WHEN 'UserSettings'          THEN 'User Settings'
      WHEN 'SolactiveIndexTickers' THEN 'Solactive Index Tickers'
      WHEN 'SolactiveNotes'        THEN 'Solactive Notes'
      ELSE [Table]
    END
FROM AdminLog ORDER BY Display
GO

ALTER PROCEDURE [dbo].[spSearchSolactiveIndexTickers]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS

-- 07/13/2017 - Added Note field
-- spSearchSolactiveIndexTickers and spSearchSolactiveNotes are identical sister procs
-- spSearchSolactiveIndexTickers - Uses left join to include all covered tickers
-- spSearchSolactiveNotes - Uses inner join to filter only covered tickers with Note

SET NOCOUNT ON

IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'

-- Company has secondary sort column of OrdNo
DECLARE @SortCol2 varchar(100)
SET @SortCol2 = ''

IF @SortCol = '2' SET @SortCol2 = ', 3, 4, OrdNo' -- Sort by Region then Analyst, Company, OrdNo
IF @SortCol = '3' SET @SortCol2 = ', 4, OrdNo'    -- Sort by Analyst then Company, OrdNo
IF @SortCol = '4' SET @SortCol2 = ', OrdNo'       -- Sort by Company then OrdNo
IF @SortCol = '7' SET @SortCol2 = ', 3, 4, OrdNo' -- Sort by Launch then Analyst, Company, OrdNo

DECLARE
  @SelectQuery AS NVARCHAR(MAX)

SET @SelectQuery =
N'
SELECT *
FROM
(
  SELECT
  RC.SecurityId,
  AR.Region,
  A.Last + '', '' + A.First AS Analyst,
  S.Company,
  S.Ticker,
  S.OrdNo,
  RC.LaunchDate,
  SN.Note,
  SI.IndexCode
  FROM ResearchCoverage RC
  JOIN Securities2 S ON S.SecurityId = RC.SecurityId
  JOIN Authors A ON A.AuthorId = RC.AnalystId
  JOIN AuthorRegions AR ON AR.RegionId = A.RegionId
  LEFT JOIN SolactiveNotes SN ON SN.SecurityId = RC.SecurityId
  LEFT JOIN SolactiveIndexTickers SIT ON SIT.SecurityId = RC.SecurityId
  LEFT JOIN SolactiveIndexes SI ON SI.IndexId = SIT.IndexId
  WHERE RC.DropDate IS NULL
) as p
PIVOT
(
  count(IndexCode)
  for IndexCode in ([BERNUS], [BERNINTL], [BERNGLBL], [BERNAPAC], [BERNEURO], [ACK])
) piv
order by ' + @SortCol + @SortDir + @SortCol2

-- print @SelectQuery

EXEC sp_executesql @SelectQuery

SET @Ct = @@ROWCOUNT

GO

if exists(select * from sys.objects where name = 'spSearchSolactiveNotes' and type = 'P')
drop procedure spSearchSolactiveNotes
go

CREATE PROCEDURE [dbo].[spSearchSolactiveNotes]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS

-- 07/13/2017
-- spSearchSolactiveIndexTickers and spSearchSolactiveNotes are identical sister procs
-- spSearchSolactiveIndexTickers - Uses left join to include all covered tickers
-- spSearchSolactiveNotes - Uses inner join to filter only covered tickers with Note

SET NOCOUNT ON

IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'

-- Company has secondary sort column of OrdNo
DECLARE @SortCol2 varchar(100)
SET @SortCol2 = ''

IF @SortCol = '2' SET @SortCol2 = ', 3, 4, OrdNo' -- Sort by Region then Analyst, Company, OrdNo
IF @SortCol = '3' SET @SortCol2 = ', 4, OrdNo'    -- Sort by Analyst then Company, OrdNo
IF @SortCol = '4' SET @SortCol2 = ', OrdNo'       -- Sort by Company then OrdNo
IF @SortCol = '7' SET @SortCol2 = ', 3, 4, OrdNo' -- Sort by Launch then Analyst, Company, OrdNo

DECLARE
  @SelectQuery AS NVARCHAR(MAX)

SET @SelectQuery =
N'
SELECT *
FROM
(
  SELECT
  RC.SecurityId,
  AR.Region,
  A.Last + '', '' + A.First AS Analyst,
  S.Company,
  S.Ticker,
  S.OrdNo,
  RC.LaunchDate,
  SN.Note,
  SI.IndexCode
  FROM ResearchCoverage RC
  JOIN Securities2 S ON S.SecurityId = RC.SecurityId
  JOIN Authors A ON A.AuthorId = RC.AnalystId
  JOIN AuthorRegions AR ON AR.RegionId = A.RegionId
  JOIN SolactiveNotes SN ON SN.SecurityId = RC.SecurityId
  LEFT JOIN SolactiveIndexTickers SIT ON SIT.SecurityId = RC.SecurityId
  LEFT JOIN SolactiveIndexes SI ON SI.IndexId = SIT.IndexId
  WHERE RC.DropDate IS NULL
) as p
PIVOT
(
  count(IndexCode)
  for IndexCode in ([BERNUS], [BERNINTL], [BERNGLBL], [BERNAPAC], [BERNEURO], [ACK])
) piv
order by ' + @SortCol + @SortDir + @SortCol2

-- print @SelectQuery

EXEC sp_executesql @SelectQuery

SET @Ct = @@ROWCOUNT

GO

if exists(select * from sys.objects where name = 'spGetSolactiveNote' and type = 'P')
drop procedure spGetSolactiveNote
go

CREATE PROCEDURE [dbo].[spGetSolactiveNote]
  @SecurityId int
AS
select SN.SecurityId, S.Ticker, SN.Note, SN.EditDate, U.UserName
from SolactiveNotes SN
join Securities2 S on S.SecurityId = SN.SecurityId
left outer join Users U on U.UserId = SN.EditorId
where SN.SecurityId = @SecurityId
GO

if exists(select * from sys.objects where name = 'spSaveSolactiveNote' and type = 'P')
drop procedure spSaveSolactiveNote
go

CREATE PROCEDURE [dbo].[spSaveSolactiveNote]
  @SecurityId    int,
  @Note          varchar(2048),
  @EditorId      int
AS

DECLARE
@EditDate datetime,
@Ticker varchar(15),
@OldNote varchar(2048)

SELECT @EditDate = GETDATE()

SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityID = @SecurityId
SELECT @OldNote = Note FROM SolactiveNotes WHERE SecurityId = @SecurityId

BEGIN TRY
  BEGIN TRANSACTION

    -- NO ROW IMPLIES NO NOTE
    IF (LTRIM(RTRIM(@Note)) <> '')
    BEGIN
      IF NOT EXISTS (SELECT SecurityId FROM SolactiveNotes WHERE SecurityId = @SecurityId)
        BEGIN
          INSERT INTO SolactiveNotes (SecurityId, Note, EditorId, EditDate) VALUES (@SecurityId, @Note, @EditorId, GETDATE())

          INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
          VALUES ('SolactiveNotes', 'A', @Ticker + ' | ' + @Note, NULL, @SecurityId, @EditorId, @EditDate)
        END
      ELSE
        BEGIN
          UPDATE SolactiveNotes SET Note = @Note, EditorId = @EditorId, EditDate = GETDATE() WHERE SecurityId = @SecurityId

          INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
          VALUES ('SolactiveNotes', 'U', @Ticker + ' | ' + @Note, @Ticker + ' | ' + @OldNote, @SecurityId, @EditorId, @EditDate)
        END
    END
    ELSE
    BEGIN
      DELETE FROM SolactiveNotes WHERE SecurityId = @SecurityId

      INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
      VALUES ('SolactiveNotes', 'D', '', @Ticker + ' | ' + @OldNote, @SecurityId, @EditorId, @EditDate)
    --    VALUES ('SolactiveNotes', 'D', @Ticker + ' | ', @Ticker + ' | ' + @OldNote, @SecurityId, @EditorId, @EditDate)
    END

    SELECT 0
  COMMIT TRANSACTION
END TRY
BEGIN CATCH
  ROLLBACK TRANSACTION
  SELECT ERROR_NUMBER() AS ErrorNumber, ERROR_MESSAGE() AS ErrorMessage
END CATCH

GO

grant execute on dbo.spSearchSolactiveNotes to DE_IIS, PowerUsers
grant execute on dbo.spGetSolactiveNote     to DE_IIS, PowerUsers
grant execute on dbo.spSaveSolactiveNote    to DE_IIS, PowerUsers
GO

/*

Debug

select * from Securities2 where Ticker like 'AAPL%'

spSaveSolactiveNote 6, 'Some text note', 1

spSaveSolactiveNote 6, 'Some text note', 1 -- Test IX for dupes.  No error message

spSaveSolactiveNote 1000000, 'Some text note', 1 -- Test FK for invalid SecurityId

-- TEST CASES
- Tick each index individually for a specified ticker and test round-trip and excel export
- Test A, U, D data and admin log accuracy
- Restricted to EtfCommittee role
- IX for unqiueness, i.e. no dupe AAPLs



select * from SolactiveNotes

Model after Security Text Disclosures

http://institutional-dev.beehive.com/disclosures/securitytextdisclosures.asp
http://institutional-dev.beehive.com/disclosures/authortextdisclosures.asp

http://institutional-dev.beehive.com/research/valrisksanalyst.asp?typeid=1&analystid=506
spGetValuationsAnalyst
spGetRisksAnalyst
save.aspx?op=svra

select * from SecurityTextDisclosures
select * from AuthorTextDisclosures

sp_helptext spGetSecurityTextDisclosures
go

sp_helptext spSaveSecurityTextDisclosure
go

exec sp_helptext spSearchSolactiveIndexTickers
go

exec spSearchSolactiveIndexTickers 1, 'a', 1, 5000, null
go

exec spSearchSolactiveNotes 1, 'd', 1, 5000, null
go

Exec spSaveSolactiveNote 1620,'',1229 
GO

*/
