-- PortalUsageLog_Rollback.sql
-- 04/11/2017

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*

new Table PortalUsageLog

new Proc spGetPortals - to get Portal list (Consumer: UI - dropdown list)
new Proc spGetPortalLogs - to get Portal logs

GRANT EXECUTE TO DE_IIS for running spLoad procs and dtsx

alter load procs to get write to PortalUsageLog table

*/
GO

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE name = 'PortalUsageLog' and TYPE = 'U')
DROP TABLE dbo.PortalUsageLog
GO

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE name = 'spGetPortals' and TYPE = 'P')
DROP PROCEDURE dbo.spGetPortals
GO

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE name = 'spGetPortalLogs' and TYPE = 'P')
DROP PROCEDURE dbo.spGetPortalLogs
GO


ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId       INT,
@MinReadDate  VARCHAR(10),
@MaxReadDate  VARCHAR(10),
@RowsLoaded   INT

SET @SiteId = 9 -- Thomson Reuters

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_TR) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_TR STG
   WHERE YEAR(PU.ReadDate) = YEAR(STG.[Viewed Date])
   AND MONTH(PU.ReadDate)= MONTH(STG.[Viewed Date])
   AND DAY(PU.ReadDate)  = DAY(STG.[Viewed Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (PubNo, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, FirmType, Delivery)
SELECT
  CASE WHEN ISNUMERIC([Local DocID]) = 1 THEN [Local DocID] ELSE 0 END,
  CASE WHEN ISDATE([Viewed Date]) = 1 THEN [Viewed Date] ELSE NULL END,
  @SiteId,
  [User Email],
  [User Name],
  ISNULL([Unique ID],0),
  [Client Name],
  ISNULL([Client Company ID],0),
  [Client Type],
  [Delivery]
FROM [dbo].[PortalUsageStaging_TR]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @MinReadDate = CONVERT(VARCHAR, MIN(CAST([Viewed Date] AS DATE) ), 101),
       @MaxReadDate = CONVERT(VARCHAR, MAX(CAST([Viewed Date] AS DATE) ), 101)
FROM PortalUsageStaging_TR
WHERE ISDATE([Viewed Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for TR from ' + @MinReadDate + ' to ' + @MaxReadDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO



ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId       INT,
@MinReadDate  VARCHAR(10),
@MaxReadDate  VARCHAR(10),
@RowsLoaded   INT

SET @SiteId = 11 -- Capital IQ

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_CIQ) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_CIQ STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Download Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Download Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Download Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, FirmType, Delivery)
SELECT
  [Ctb Doc Id],
  [Download Date],
  @SiteId,
  [Email],
  [User Name],
  [User],
  [Company Name],
  [Company],
  [Firm Type],
  [Activity Type]
FROM [dbo].[PortalUsageStaging_CIQ]
WHERE ISNUMERIC([Ctb Doc Id]) = 1

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @MinReadDate = CONVERT(VARCHAR, MIN(CAST([Download Date] AS DATE) ), 101),
       @MaxReadDate = CONVERT(VARCHAR, MAX(CAST([Download Date] AS DATE) ), 101)
FROM PortalUsageStaging_CIQ
WHERE ISDATE([Download Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for CIQ from ' + @MinReadDate + ' to ' + @MaxReadDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO




ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId       INT,
@MinReadDate  VARCHAR(10),
@MaxReadDate  VARCHAR(10),
@RowsLoaded   INT

SET @SiteId = 12 -- Factset

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_FactSet) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_FactSet STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Date/time read])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Date/time read])
   AND DAY(PU.ReadDate) = DAY(STG.[Date/time read])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId)
SELECT
  [Doc ID (contributor)],
  [Date/time read],
  @SiteId,
  [E-mail],
  [Reader name],
  [Reader ID (FactSet)],
  [Firm name],
  [Firm ID (FactSet)]
FROM [dbo].[PortalUsageStaging_FactSet]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @MinReadDate = CONVERT(VARCHAR, MIN(CAST([Date/time read] AS DATE) ), 101),
       @MaxReadDate = CONVERT(VARCHAR, MAX(CAST([Date/time read] AS DATE) ), 101)
FROM PortalUsageStaging_FactSet
WHERE ISDATE([Date/time read]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for FactSet from ' + @MinReadDate + ' to ' + @MaxReadDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO



ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId       INT,
@MinReadDate  VARCHAR(10),
@MaxReadDate  VARCHAR(10),
@RowsLoaded   INT

SET @SiteId = 3 -- Bloomberg

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_Bloomberg) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_Bloomberg STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId)
SELECT
  CASE WHEN ISNUMERIC([Story Id]) = 1 THEN [Story ID] ELSE 0 END AS StoryId,
  [Read Date],
  @SiteId,
  [Business Email],
  [User Name],
  CASE WHEN ISNUMERIC([UUID]) = 1 THEN [UUID] ELSE NULL END AS UUID,
  [Customer Name],
  [Customer #]
FROM [dbo].[PortalUsageStaging_Bloomberg]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @MinReadDate = CONVERT(VARCHAR, MIN(CAST([Read Date] AS DATE) ), 101),
       @MaxReadDate = CONVERT(VARCHAR, MAX(CAST([Read Date] AS DATE) ), 101)
FROM PortalUsageStaging_Bloomberg
WHERE ISDATE([Read Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Bloomberg from ' + @MinReadDate + ' to ' + @MaxReadDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO


