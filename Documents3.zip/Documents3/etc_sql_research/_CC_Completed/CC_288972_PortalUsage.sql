-- PortalUsage.sql
-- 05/18/2018

/*

Create PortalUsageStaging_ONEaccess
Create spResetPortalUsageStaging_ONEaccess
Create spLoadPortalUsageFromStaging_ONEaccess

Alter spGetPortals -- used by UI

Alter PortalUsageStaging_RSRCHX
Alter spLoadPortalUsageFromStaging_RSRCHX

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_ONEaccess]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_ONEaccess]
GO

CREATE TABLE [dbo].[PortalUsageStaging_ONEaccess]
(
  [file_date_UTC] [varchar](500) NULL,
  [read_id] [varchar](500) NULL,
  [vendor_document_id] [varchar](500) NULL,
  [broker_document_id] [varchar](500) NULL,
  [headline] [varchar](500) NULL,
  [ric_ticker] [varchar](500) NULL,
  [vendor_analyst_id] [varchar](500) NULL,
  [analyst_name] [varchar](500) NULL,
  [analyst_email] [varchar](500) NULL,
  [published_date_UTC] [varchar](500) NULL,
  [viewed_date_UTC] [varchar](500) NULL,
  [vendor_client_id] [varchar](500) NULL,
  [client_name] [varchar](500) NULL,
  [client_address] [varchar](500) NULL,
  [client_city] [varchar](500) NULL,
  [client_state] [varchar](500) NULL,
  [client_country] [varchar](500) NULL,
  [client_type] [varchar](500) NULL,
  [Vendor Channel] [varchar](500) NULL,
  [Readership_type] [varchar](500) NULL,
  [vendor_user_id] [varchar](500) NULL,
  [user_name] [varchar](500) NULL,
  [user_business_email] [varchar](500) NULL,
  [user_alt_email] [varchar](500) NULL,
  [user_phone] [varchar](500) NULL,
  [user_address] [varchar](500) NULL,
  [user_city] [varchar](500) NULL,
  [user_state] [varchar](500) NULL,
  [user_country] [varchar](500) NULL,
  [user_role] [varchar](500) NULL
) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_ONEaccess]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spResetPortalUsageStaging_ONEaccess]
GO

CREATE PROCEDURE [dbo].[spResetPortalUsageStaging_ONEaccess]
AS
BEGIN
SET NOCOUNT ON

DECLARE @RowsDeleted INT

DELETE FROM [dbo].[PortalUsageStaging_ONEaccess]
SET @RowsDeleted = @@ROWCOUNT
SELECT @RowsDeleted

SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_ONEaccess]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_ONEaccess]
GO

CREATE PROCEDURE [dbo].[spLoadPortalUsageFromStaging_ONEaccess]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 21 -- Visible alpha

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_ONEaccess) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_ONEaccess STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[viewed_date_UTC])
   AND YEAR(PU.ReadDate) = YEAR(STG.[viewed_date_UTC])
   AND DAY(PU.ReadDate) = DAY(STG.[viewed_date_UTC])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, Delivery)
SELECT
  [broker_document_id],
  [viewed_date_UTC],
  @SiteId,
  [user_business_email],
  [user_name],
  [vendor_user_id],
  [client_name],
  [vendor_client_id],
  [Vendor Channel]
FROM [dbo].[PortalUsageStaging_ONEaccess]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([viewed_date_UTC] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([viewed_date_UTC] AS DATE) ), 101)
FROM [PortalUsageStaging_ONEaccess]
WHERE ISDATE([viewed_date_UTC]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for OneAccess from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO


ALTER PROCEDURE [dbo].[spGetPortals]
AS

SELECT SiteId, Site FROM DistributionSites WHERE SiteId IN (3, 9, 11, 12, 20, 22, 23, 21)

GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_RSRCHX]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_RSRCHX]
GO

CREATE TABLE [dbo].[PortalUsageStaging_RSRCHX](
	[Client UUID] [varchar](500) NULL,
	[Client Org Firm Name] [varchar](500) NULL,
	[Client Org Country] [varchar](500) NULL,
	[Department] [varchar](500) NULL,
	[User UUID] [varchar](500) NULL,
	[Forename] [varchar](500) NULL,
	[Surname] [varchar](500) NULL,
	[Email] [varchar](500) NULL,
	[Country] [varchar](500) NULL,
	[Provider Name] [varchar](500) NULL,
	[Provider Country] [varchar](500) NULL,
	[Action Type] [varchar](500) NULL,
	[Action ID] [varchar](500) NULL,
	[Action Date (UTC)] [varchar](500) NULL,
	[Action Time (UTC)] [varchar](500) NULL,
	[Scrollage (%)] [varchar](500) NULL,
	[Total read time (secs)] [varchar](500) NULL,
	[Provider's Identifier] [varchar](500) NULL,
	[Report Title] [varchar](500) NULL,
	[Num of pages] [varchar](500) NULL,
	[Published Date] [varchar](500) NULL,
	[Authors] [varchar](500) NULL,
	[Regions] [varchar](500) NULL,
	[Countries] [varchar](500) NULL,
	[Specialities] [varchar](500) NULL,
	[Disciplines] [varchar](500) NULL,
	[Research Approach] [varchar](500) NULL,
	[Asset Classes] [varchar](500) NULL,
	[Asset Types] [varchar](500) NULL,
	[Sectors] [varchar](500) NULL,
	[Issuers] [varchar](500) NULL
) ON [PRIMARY]
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RSRCHX]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 22 -- RSRCHXchange

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RSRCHX) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_RSRCHX STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Action Date (UTC)])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Action Date (UTC)])
   AND DAY(PU.ReadDate) = DAY(STG.[Action Date (UTC)])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, Delivery)
SELECT
  [Provider's Identifier],
  [Action Date (UTC)],   -- 'read time' component not needed
  @SiteId,
  [Email],
  [Surname] + ', ' + [Forename],
  [User UUID],
  [Client Org Firm Name],
  [Client UUID],
  NULL
FROM [dbo].[PortalUsageStaging_RSRCHX]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Action Date (UTC)] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Action Date (UTC)] AS DATE) ), 101)
FROM [PortalUsageStaging_RSRCHX]
WHERE ISDATE([Action Date (UTC)]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for RSRCHXchange from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO


-- User 'DE_IIS' - Grant bulk inserts from SSIS packages
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_ONEaccess]   TO  DE_IIS
GO

GRANT EXECUTE ON [dbo].[spResetPortalUsageStaging_ONEaccess]      TO  DE_IIS, PowerUsers
GRANT EXECUTE ON [dbo].[spLoadPortalUsageFromStaging_ONEaccess]   TO  DE_IIS, PowerUsers
GO

GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_RSRCHX]   TO  DE_IIS
GO

/*
-- ONEaccess [21]
EXEC [spResetPortalUsageStaging_ONEaccess]
EXEC [spLoadPortalUsageFromStaging_ONEaccess]

SELECT * FROM [PortalUsageStaging_ONEaccess] ORDER BY CAST([viewed_date_UTC] AS DATETIME) desc
SELECT * FROM PortalUsage WHERE SiteId = 22 ORDER BY UsageId DESC
-- DELETE FROM PortalUsage WHERE SiteId = 22

-- RSRCHX [22]
SELECT * FROM [PortalUsageStaging_RSRCHX]
EXEC [spLoadPortalUsageFromStaging_RSRCHX]

SELECT * FROM [PortalUsageStaging_RSRCHX] ORDER BY CAST([Action Date (UTC)] AS DATETIME) desc
SELECT * FROM PortalUsage WHERE SiteId = 21 ORDER BY UsageId DESC
-- DELETE FROM PortalUsage WHERE SiteId = 21


EXEC [spGetPortals]
EXEC [spGetPortalUsageLoadHistory] 21  -- ONEaccess

SELECT * FROM DistributionSites -- 21	ONEaccess
*/
