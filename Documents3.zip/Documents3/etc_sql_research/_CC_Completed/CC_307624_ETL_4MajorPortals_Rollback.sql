-- CC_ETL_4MajorPortals_Rollback.sql
-- 04/11/2019

/*
Proc changes:
rollback proc spLoadPortalUsageFromStaging_Bloomberg
rollback proc spLoadPortalUsageFromStaging_Factset
rollback proc spLoadPortalUsageFromStaging_TR
rollback proc spLoadPortalUsageFromStaging_CIQ
*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO


-- alter proc to load Portal Usage data for Bloomberg
ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table
DECLARE
  @SiteId           INT,
  @SubSite          VARCHAR(50),
  @ContentType      VARCHAR(50),
  @DataStore        NVARCHAR(200),
  @PreEmbargoedText VARCHAR(30),
  @LoadDate         DATETIME,
  @PeriodStartDate  VARCHAR(10),
  @PeriodEndDate    VARCHAR(10),
  @RowsLoaded       INT

SET @SiteId = 3                       -- Bloomberg
SET @DataStore = 'Bloomberg'
SET @SubSite = 'Bloomberg'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_Bloomberg) RETURN

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_Bloomberg BB
WHERE BB.[Transaction ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    CASE WHEN ISNUMERIC([Story Id]) = 1 THEN [Story ID] ELSE 0 END AS StoryId,
    [Read Date],
    @SiteId,
    @SubSite,
    [Business Email],
    [User Name],
    CASE WHEN ISNUMERIC([UUID]) = 1 THEN [UUID] ELSE NULL END AS UUID,
    [Customer Name],
    [Customer #],
    NULL,
    [Transaction ID],
    @EmbargoStyle,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_Bloomberg BB
    WHERE BB.[Transaction ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_Bloomberg BB ON PU.TransactionId = BB.[Transaction ID] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage that were previously embargoed, with post-embargo data from Staging table by Transaction Id
  UPDATE PU
  SET PU.Email = BB.[Business Email],
      PU.Contact = BB.[User Name],
      PU.ContactId = CASE WHEN ISNUMERIC(BB.[UUID]) = 1 THEN [UUID] ELSE NULL END,
      PU.Account = BB.[Customer Name],
      PU.AccountId = BB.[Customer #],
      PU.EmbargoStyle = @EmbargoStyle,
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_Bloomberg BB ON PU.TransactionId = BB.[Transaction ID] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update rows marked as Pre-embargo (PRE)

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Populate [PortalClientEmbargo] table by accounts and file name e.g. 30d, 90d etc.
-- only the daily files to be used to populate client embargoes
-- monthly files should not be used to populate client embargoes

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct BB.[Customer Name]) FROM PortalUsageStaging_Bloomberg BB
WHERE BB.[Customer Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

DECLARE @NumEmbargoRowstoUpdate AS INT
SELECT @NumEmbargoRowstoUpdate = COUNT(*) FROM PortalClientEmbargo PCE
JOIN PortalUsageStaging_Bloomberg BB ON PCE.Account = BB.[Customer Name] AND PCE.DataStore = @DataStore

IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST30'
BEGIN
  -- Insert 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
    INSERT INTO PortalClientEmbargo (DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, BB.[Customer Name], BB.[Customer #], 30
    FROM PortalUsageStaging_Bloomberg BB
    WHERE BB.[Customer Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
      AND BB.[Customer Name] != 'N/A'
  END

  -- Update 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoUpdate > 0
  BEGIN
    UPDATE pce
    SET pce.NumDaysEmbargo = 30
    FROM [PortalClientEmbargo] AS pce
    INNER JOIN PortalUsageStaging_Bloomberg BB ON BB.[Customer #] = pce.[AccountId] AND BB.[Customer Name] = pce.[Account]
    WHERE pce.DataStore = @DataStore
  END
END
ELSE IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST90'
BEGIN
  -- Insert 90d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
    INSERT INTO PortalClientEmbargo (DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, BB.[Customer Name], BB.[Customer #], 90
    FROM PortalUsageStaging_Bloomberg BB
    WHERE BB.[Customer Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND BB.[Customer Name] != 'N/A'
  END
  /* if an account was mapped as 30 day embargo, do not re-map as 90 day, if reads also found in POST90 file */
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date] AS DATE) ), 101),
       @PeriodEndDate   = CONVERT(VARCHAR, MAX(CAST([Read Date] AS DATE) ), 101)
FROM PortalUsageStaging_Bloomberg
WHERE ISDATE([Read Date]) = 1

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

-- alter proc to load Portal Usage data for Factset
ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table
DECLARE
  @SiteId           INT,
  @SubSite          VARCHAR(50),
  @ContentType      VARCHAR(50),
  @DataStore        NVARCHAR(200),
  @PreEmbargoedText VARCHAR(30),
  @LoadDate         DATETIME,
  @PeriodStartDate  VARCHAR(10),
  @PeriodEndDate    VARCHAR(10),
  @RowsLoaded       INT

SET @SiteId = 12        -- Factset
SET @DataStore = 'Factset'
SET @SubSite = 'Factset'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_FactSet) RETURN

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_FactSet FS
WHERE FS.[Readership Event ID (FactSet)] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    CASE WHEN ISNUMERIC([Doc ID (contributor)]) = 1 THEN [Doc ID (contributor)] ELSE 0 END AS StoryId,
    [Date/time read],
    @SiteId,
    [Platform],
    [E-mail],
    [Reader name],
    CASE WHEN ISNUMERIC([Reader ID (FactSet)]) = 1 THEN [Reader ID (FactSet)] ELSE NULL END AS UUID,
    [Firm name],
    [Firm ID (FactSet)],
    NULL,
    [Readership Event ID (FactSet)],
    @EmbargoStyle,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_Factset FS
    WHERE FS.[Readership Event ID (FactSet)] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_FactSet FS ON PU.TransactionId = FS.[Readership Event ID (FactSet)] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage with post-embargo data from Staging table by Transaction Id
  UPDATE PU
  SET PU.Email = FS.[E-mail],
      PU.Contact = FS.[Reader name],
      PU.ContactId = CASE WHEN ISNUMERIC(FS.[Reader ID (FactSet)]) = 1 THEN [Reader ID (FactSet)] ELSE NULL END,
      PU.Account = FS.[Firm name],
      PU.AccountId = FS.[Firm ID (FactSet)],
      PU.EmbargoStyle = @EmbargoStyle,
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_Factset FS ON PU.TransactionId = FS.[Readership Event ID (FactSet)] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update rows marked as Pre-embargo (PRE)

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Populate [PortalClientEmbargo] table as per the file name e.g. 30d, 90d etc.
-- only the daily files to be used to populate client embargoes
-- monthly files should not be used to populate client embargoes

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct FS.[Firm name]) FROM PortalUsageStaging_FactSet FS
WHERE FS.[Firm name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

DECLARE @NumEmbargoRowstoUpdate AS INT
SELECT @NumEmbargoRowstoUpdate = COUNT(*) FROM PortalClientEmbargo PCE
JOIN PortalUsageStaging_FactSet FS ON PCE.Account = FS.[Firm name] AND PCE.DataStore = @DataStore

IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST30'
BEGIN
  -- Insert 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, FS.[Firm name], FS.[Firm ID (FactSet)], 30
    FROM PortalUsageStaging_Factset FS
    WHERE FS.[Firm name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND FS.[Firm name] != '***'
  END

  -- Update 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoUpdate > 0
  BEGIN
    UPDATE pce
    SET pce.NumDaysEmbargo = 30
    FROM PortalClientEmbargo AS pce
    INNER JOIN PortalUsageStaging_Factset FS ON FS.[Firm ID (FactSet)] = pce.[AccountId] AND FS.[Firm name] = pce.[Account]
    WHERE pce.DataStore = @DataStore
  END
END
ELSE IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST90'
BEGIN
  -- Insert 90d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, FS.[Firm name], FS.[Firm ID (FactSet)], 90
    FROM PortalUsageStaging_Factset FS
    WHERE FS.[Firm name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND FS.[Firm name] != '***'
  END

  /* if an account was mapped as 30 day embargo, do not re-map as 90 day, if reads also found in POST90 file */
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Date/time read] AS DATE) ), 101),
       @PeriodEndDate   = CONVERT(VARCHAR, MAX(CAST([Date/time read] AS DATE) ), 101)
FROM PortalUsageStaging_Factset
WHERE ISDATE([Date/time read]) = 1

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

-- alter proc to load Portal Usage data for Factset
ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table
DECLARE
  @SiteId           INT,
  @SubSite          VARCHAR(50),
  @ContentType      VARCHAR(50),
  @DataStore        NVARCHAR(200),
  @PreEmbargoedText VARCHAR(30),
  @LoadDate         DATETIME,
  @PeriodStartDate  VARCHAR(10),
  @PeriodEndDate    VARCHAR(10),
  @RowsLoaded       INT

SET @SiteId = 9      -- Thomson Reuters
SET @DataStore = 'TR'
SET @SubSite = 'TR'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'        -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_TR) RETURN

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_TR TR
WHERE TR.[Transaction ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    CASE WHEN ISNUMERIC(TR.[Local DocID]) = 1 THEN TR.[Local DocID] ELSE 0 END AS StoryId,
    TR.[Viewed Date],
    @SiteId,
    [Delivery],
    TR.[User Email],
    TR.[User Name],
    CASE WHEN ISNUMERIC(TR.[Unique ID]) = 1 THEN TR.[Unique ID] ELSE NULL END AS UUID,
    TR.[Client Name],
    TR.[Client Company ID],
    TR.[Client Type],
    TR.[Transaction ID],
    @EmbargoStyle,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_TR TR
    WHERE TR.[Transaction ID] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_TR TR ON PU.TransactionId = TR.[Transaction ID] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
-- Update those rows that were previously embargoed
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage with post-embargo data from Staging table by Transaction Id
  UPDATE pu
  SET PU.Email = TR.[User Email],
      PU.Contact = TR.[User Name],
      PU.ContactId = CASE WHEN ISNUMERIC(TR.[Unique ID]) = 1 THEN TR.[Unique ID] ELSE NULL END,
      PU.Account = TR.[Client Name],
      PU.AccountId = TR.[Client Company ID],
      PU.EmbargoStyle = @EmbargoStyle,
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_TR TR ON PU.TransactionId = TR.[Transaction ID] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update only the Pre-embargo rows

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Populate [PortalClientEmbargo] table as per the file name e.g. 30d, 90d etc.
-- only the daily files to be used to populate client embargoes
-- monthly files should not be used to populate client embargoes

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct TR.[Client Name]) FROM PortalUsageStaging_TR TR
WHERE TR.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

DECLARE @NumEmbargoRowstoUpdate AS INT
SELECT @NumEmbargoRowstoUpdate = COUNT(*) FROM PortalClientEmbargo PCE
JOIN PortalUsageStaging_TR TR  ON PCE.Account = TR.[Client Name] AND PCE.DataStore = @DataStore

IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST30'
BEGIN

  -- Insert 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, TR.[Client Name], TR.[Client Company ID], 30
    FROM PortalUsageStaging_TR TR
    WHERE TR.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
  END

  -- Update 30d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoUpdate > 0
  BEGIN
     UPDATE pce
     SET pce.NumDaysEmbargo = 30
     FROM PortalClientEmbargo AS pce
     INNER JOIN PortalUsageStaging_TR TR ON TR.[Client Company ID] = pce.[AccountId] AND TR.[Client Name] = pce.[Account]
     WHERE pce.DataStore = @DataStore
  END
END
ELSE IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'POST90'
BEGIN
  -- Insert 90d Accounts into PortalClientEmbargo
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
     INSERT INTO [PortalClientEmbargo] (DataStore, Account, AccountId, NumDaysEmbargo)
     SELECT DISTINCT @DataStore, TR.[Client Name], TR.[Client Company ID], 90
     FROM PortalUsageStaging_TR TR
     WHERE TR.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
  END
  /* if an account was mapped as 30 day embargo, do not re-map as 90 day, if reads also found in POST90 file */
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST(TR.[Viewed Date] AS DATE) ), 101),
       @PeriodEndDate   = CONVERT(VARCHAR, MAX(CAST(TR.[Viewed Date] AS DATE) ), 101)
FROM PortalUsageStaging_TR TR
WHERE ISDATE(TR.[Viewed Date]) = 1

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

-- alter proc to load Portal Usage data for CapitalIQ
ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
    @FileName        varchar(100),
    @FileFrequency   varchar(50),
    @EmbargoStyle    varchar(50),
    @UserId          int = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table
DECLARE
  @SiteId           INT,
  @SubSite          VARCHAR(50),
  @ContentType      VARCHAR(50),
  @DataStore        NVARCHAR(200),
  @PreEmbargoedText VARCHAR(30),
  @LoadDate         DATETIME,
  @PeriodStartDate  VARCHAR(10),
  @PeriodEndDate    VARCHAR(10),
  @RowsLoaded       INT

SET @SiteId = 11                  -- CapitalIQ
SET @DataStore = 'CIQ'
SET @SubSite = 'CIQ'
SET @ContentType = 'R'
SET @PreEmbargoedText = 'PRE'     -- flag rows to be updated when post-emabargo info is available
SET @LoadDate = getdate()

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_CIQ) RETURN

-- **Portal Usage data loads**
-- Insert into PortalUsage table for Non-Matching TransactionId rows
DECLARE @NumRowstoInsert AS INT
SELECT @NumRowstoInsert = COUNT(*) FROM PortalUsageStaging_CIQ CIQ
WHERE CIQ.[Activity Id] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

-- If transaction id does not exists in Portal Usage then insert, i.e. initial embargo state
IF @NumRowstoInsert > 0
BEGIN
    -- Insert rows in PortalUsage with new Transaction Id from Staging table
  INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType,
                           TransactionId, EmbargoStyle, FileName, LoadDate)
  SELECT
    @ContentType,
    -- Content Id
    CASE WHEN ISNUMERIC(CIQ.[Ctb Doc Id]) = 1 THEN CIQ.[Ctb Doc Id] ELSE 0 END,
    CIQ.[Activity Date],
    @SiteId,
    @SubSite,
    CIQ.[Email],
    CIQ.[User Name],
    CASE WHEN ISNUMERIC(CIQ.[User]) = 1 THEN CIQ.[User] ELSE NULL END AS UUID,
    CIQ.[Client Name],
    CIQ.[Client],
    CIQ.[Firm Type],
    CIQ.[Activity Id],
    -- Embargo Style
    CASE
      WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 90 THEN 'POST90'
      WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 30 THEN 'POST30'
      WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 1  THEN 'PRE'
      ELSE 'MIXED'
    END,
    @FileName,
    @LoadDate
  FROM PortalUsageStaging_CIQ CIQ
  WHERE CIQ.[Activity Id] NOT IN (SELECT distinct PU.TransactionId FROM PortalUsage PU WHERE SiteId = @SiteId AND PU.TransactionId is not null)

  SET @RowsLoaded = ISNULL(@@ROWCOUNT, 0)
END

-- Update PortalUsage table for Matching TransactionId rows
DECLARE @NumRowstoUpdate AS INT
SELECT @NumRowstoUpdate = COUNT(*) FROM PortalUsage PU
JOIN PortalUsageStaging_CIQ CIQ ON PU.TransactionId = CIQ.[Activity Id] AND PU.SiteId = @SiteId

-- If transaction id exists in Portal Usage table then update, i.e. update embargo state
-- Update those rows that were previously embargoed
IF @NumRowstoUpdate > 0
BEGIN
    -- Update rows in PortalUsage with post-embargo data from Staging table by Transaction Id
  UPDATE pu
  SET PU.Email = CIQ.[Email],
      PU.Contact = CIQ.[User Name],
      PU.ContactId = CASE WHEN ISNUMERIC(CIQ.[User]) = 1 THEN CIQ.[User] ELSE NULL END,
      PU.Account = CIQ.[Client Name],
      PU.AccountId = CIQ.[Client],
      PU.AccountType = CIQ.[Firm Type],
      PU.EmbargoStyle =
      CASE
          WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 90 THEN 'POST90'     -- reads in last -91 days
          WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 30 THEN 'POST30'     -- reads in last -31 days
          WHEN DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 1  THEN 'PRE'        -- reads in last -2 days
          ELSE ''
      END,
      PU.FileName = @FileName,
      PU.LoadDate = @LoadDate
  FROM PortalUsage AS PU
  INNER JOIN PortalUsageStaging_CIQ CIQ ON PU.TransactionId = CIQ.[Activity Id] AND PU.SiteId = @SiteId
  WHERE PU.EmbargoStyle = @PreEmbargoedText  -- Update only the Pre-embargo rows

  SET @RowsLoaded = ISNULL(@RowsLoaded, 0) + ISNULL(@@ROWCOUNT, 0)
END

-- **Portal Client Embargo data loads**
-- Populate [PortalClientEmbargo] table as per the file name e.g. ResearchActivity
-- only the daily files to be used to populate client embargoes
-- CapitalIQ daily file has -1, -31, -91 day read data

DECLARE @NumEmbargoRowstoInsert AS INT
SELECT @NumEmbargoRowstoInsert = COUNT(distinct CIQ.[Client Name]) FROM PortalUsageStaging_CIQ CIQ
WHERE CIQ.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)

IF @FileFrequency = 'DAILY' AND @EmbargoStyle = 'MIXED'
BEGIN
  IF @NumEmbargoRowstoInsert > 0
  BEGIN
      -- Identify accounts with 90 day embargo
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, CIQ.[Client Name], CIQ.[Client], 90
        FROM PortalUsageStaging_CIQ CIQ
    WHERE DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 90
    AND CIQ.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND LTRIM(RTRIM(CIQ.[Client Name])) != ''

    --Identify accounts with 30 day embargo
    INSERT INTO PortalClientEmbargo(DataStore, Account, AccountId, NumDaysEmbargo)
    SELECT DISTINCT @DataStore, CIQ.[Client Name], CIQ.[Client], 30
        FROM PortalUsageStaging_CIQ CIQ
    WHERE DATEDIFF(d, CIQ.[Activity Date], getdate()) >= 30 AND DATEDIFF(d, CIQ.[Activity Date], getdate()) < 90
    AND CIQ.[Client Name] NOT IN (SELECT distinct PCE.Account FROM PortalClientEmbargo PCE WHERE PCE.DataStore = @DataStore)
    AND LTRIM(RTRIM(CIQ.[Client Name])) != ''
  END
END

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST(CIQ.[Activity Date] AS DATE) ), 101),
       @PeriodEndDate   = CONVERT(VARCHAR, MAX(CAST(CIQ.[Activity Date] AS DATE) ), 101)
FROM PortalUsageStaging_CIQ CIQ
WHERE ISDATE(CIQ.[Activity Date]) = 1

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO
