-- spRptDwsDailySignals.sql
-- 02/04/2020

/*

DEV: beehivedbdev, 15610 || beehivedbdev\scbisdev

ALTER spRptDwsDailySignals

*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO


ALTER PROCEDURE [dbo].[spRptDwsDailySignals]
AS
BEGIN

SET NOCOUNT ON

DECLARE @StartDate  varchar(12)
DECLARE @EndDate    varchar(12)

-- Date range filter
SET @EndDate = getdate()  -- Set to date/time (mm/dd/yyyy hh:mm:ss) or date (mm/dd/yyyy)

IF datepart(dw,@EndDate) = 1               -- On Sunday set range to -72 hours
SET @StartDate = dateadd(dd,-3,@EndDate)
ELSE IF datepart(dw,@EndDate) = 7          -- On Saturday set range to -48 hours
SET @StartDate = dateadd(dd,-2,@EndDate)
ELSE                                       -- On weekday set range to -24 hours
SET @StartDate = dateadd(dd,-1,@EndDate)

-- SET @StartDate = dateadd(dd,-30,@EndDate)  -- Remove comment for testing

SELECT
  'BROKERID'        = 'BR001',
  'DATE'            = P.PublishedDate,
  'SEDOL'           = S.SEDOL,
  'INTERNAL_SEC_ID' = '',
  'RIC'             = S.RIC,
  'CUSIP'           = S.CUSIP,
  'ISIN'            = S.ISIN,
  'BB_TICKER'       = (CASE
                        WHEN charindex('.', S.Ticker,1) > 0
                        THEN LEFT(S.Ticker, charindex('.', S.Ticker,1) -1) +
                          ':' +
                          SUBSTRING(S.Ticker, charindex('.', S.Ticker,1)+1, len(S.Ticker)-charindex('.', S.Ticker,1))
                        ELSE S.Ticker + ':US'
                      END),
  'COMPANY_NAME'    = S.Company,
  'COUNTRY'         = S.CountryCode,
  'EXCHANGE'        = S.ExchangeCode,
  'DWS_SIGNAL'      = (CASE
                        WHEN VF.CoverageAction = 'Drop'    THEN 'DP' -- Drop Coverage
                        WHEN VF.CoverageAction = 'Suspend' THEN 'SP' -- Suspended
                        WHEN VF.Rating = 'O'               THEN 'O'  -- Outperform
                        WHEN VF.Rating = 'M'               THEN 'N'  -- Neutral
                        WHEN VF.Rating = 'U'               THEN 'U'  -- Underperform
                        WHEN VF.Rating = 'N'               THEN 'NR' -- Not Rated
                      END),
  'ANALYST_RATING'  = VF.Rating,
  'ANALYST_ID'      = '',
  'ANALYST'         = A.Last + ', ' + A.First,
  'ANALYST_TEAM_ID' = '',
  'ANALYST_TEAM'    = I.IndustryName,
  'EMAIL'           = A.ExtEmail,
  'VERSION'         = '2.1',
  'PRICE'           = VF.TargetPrice,
  'CURRENCY'        = S.CurrencyCode,
  'SOURCE_TYPE'     = 'FR'
FROM vFinancials VF
JOIN Publications P            ON P.PubNo       = VF.PubNo
JOIN Securities2 S             ON S.SecurityId  = VF.SecurityId
JOIN Authors A                 ON A.AuthorId    = VF.AnalystId
JOIN Industries I              ON I.IndustryID  = VF.IndustryId
JOIN Sectors ST                ON ST.SectorID   = I.SectorId
WHERE P.PublishedDate BETWEEN @StartDate AND @EndDate
AND P.Date BETWEEN @StartDate AND @EndDate -- Additionally minimize resubmits
AND (VF.RatingAction IN ('UPGRADE', 'DOWNGRADE', 'INITIATE')
     OR
     VF.CoverageAction IN ('DROP', 'SUSPEND', 'INITIATE'))
ORDER BY VF.Date DESC, S.Ticker, P.PubNo DESC

SET @StartDate = CONVERT(varchar(12), CONVERT(date, @StartDate), 101)
SET @EndDate = CONVERT(varchar(12), CONVERT(date, @EndDate), 101)

EXEC dbo.spSaveReportProcessingLog
'RESEARCH', 'DWS - Signals',  @StartDate, @EndDate, 'DWS_Signals.rdl', 'spRptDwsDailySignals'

END
GO


/*

EXEC spRptDwsDailySignals

SELECT TOP 100 * FROM ReportProcessingLog ORDER BY LogId DESC

-- update date format to mm/dd/yyyy
UPDATE ReportProcessingLog
SET StartDate = CONVERT(varchar(12), CONVERT(date, StartDate), 101),
    EndDate   = CONVERT(varchar(12), CONVERT(date, EndDate), 101)
WHERE Description = 'DWS - Signals'

*/
