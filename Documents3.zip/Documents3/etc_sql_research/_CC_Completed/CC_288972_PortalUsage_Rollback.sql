-- PortalUsage_Rollback.sql
-- 08/07/2018

/*

Drop PortalUsageStaging_ONEaccess
Drop spResetPortalUsageStaging_ONEaccess
Drop spLoadPortalUsageFromStaging_ONEaccess

Alter spGetPortals -- used by UI

Alter PortalUsageStaging_RSRCHX
Alter spLoadPortalUsageFromStaging_RSRCHX

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_ONEaccess]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_ONEaccess]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_ONEaccess]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spResetPortalUsageStaging_ONEaccess]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_ONEaccess]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_ONEaccess]
GO

ALTER PROCEDURE [dbo].[spGetPortals]
AS

SELECT SiteId, Site FROM DistributionSites WHERE SiteId IN (3, 9, 11, 12, 20, 22, 23)
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_RSRCHX]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_RSRCHX]
GO

CREATE TABLE [dbo].[PortalUsageStaging_RSRCHX](
	[Client Org Firm Name] [varchar](500) NULL,
	[Department] [varchar](500) NULL,
	[Forename] [varchar](500) NULL,
	[Surname] [varchar](500) NULL,
	[Email] [varchar](500) NULL,
	[Country] [varchar](500) NULL,
	[Action Type] [varchar](500) NULL,
	[Action ID] [varchar](500) NULL,
	[Action Date (UTC)] [varchar](500) NULL,
	[Action Time (UTC)] [varchar](500) NULL,
	[Report Identifier] [varchar](500) NULL,
	[Report Title] [varchar](500) NULL
) ON [PRIMARY]
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RSRCHX]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 22 -- RSRCHXchange

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RSRCHX) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_RSRCHX STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Action Date (UTC)])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Action Date (UTC)])
   AND DAY(PU.ReadDate) = DAY(STG.[Action Date (UTC)])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, Delivery)
SELECT
  [Report Identifier],
  [Action Date (UTC)],   -- 'read time' component not needed
  @SiteId,
  [Email],
  [Surname] + ', ' + [Forename],
  NULL,
  [Client Org Firm Name],
  NULL,
  NULL
FROM [dbo].[PortalUsageStaging_RSRCHX]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Action Date (UTC)] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Action Date (UTC)] AS DATE) ), 101)
FROM [PortalUsageStaging_RSRCHX]
WHERE ISDATE([Action Date (UTC)]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for RSRCHXchange from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO