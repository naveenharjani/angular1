-- spGetBloombergRequests_Rollback.sql
-- 03/01/2017

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- =======================================================================
-- Author:	Naveen Harjani
-- Create date:	4/30/2008
-- Description:	Renders all marketdata bloomberg requests
--------------------------------------------------------------------------
-- Revision Dt  | Comments
--------------------------------------------------------------------------
-- 03/18/2010   | Change Field references from BloombergRequests table to BloombergRequestTypes table
-- Fields e.g. ProgramName, FileHeader, SecCoverageType, RetentionDays
--------------------------------------------------------------------------
-- =======================================================================
ALTER PROCEDURE [dbo].[spGetBloombergRequests]
	@RequestId         int = NULL,
  @RequestStatus     varchar(40) = NULL
AS
BEGIN
SET NOCOUNT ON

declare @RequestStatusCode varchar(40)

SET @RequestStatusCode = upper(@RequestStatus)   --'ACTIVE'

IF ISNULL(@RequestId, 0) = 0

	IF ISNULL(@RequestStatusCode, '') = ''
		SELECT     R.RequestId, R.RequestName,
    				   R.RequestTypeId, T.TableType,
    				   T.RequestTypeName + ' - ' +  T.TableType AS RequestType,
    				   T.RequestTypeName,
    				   T.RequestTypeCode,	
    				   R.Description, T.ProgramName, R.ScheduleFrequency, 
    				   R.ReqFile, R.ScheduledTime, R.Active,
      				 T.FileHeader, 
    				   T.SecurityTypeCode,
    				   ST.SecurityType,
     				   T.RetentionDays, T.XmlFileName, T.TableName,
		    		   R.LastLoadDate, R.CreateDate, R.EditorID, R.EditDate
		FROM       dbo.BloombergRequests R, dbo.BloombergRequestTypes T
	  INNER JOIN dbo.BloombergSecurityTypes ST ON ST.SecurityTypeCode = T.SecurityTypeCode    
		WHERE      R.RequestTypeId = T.RequestTypeId  
		ORDER BY   R.RequestId
	ELSE
		SELECT     R.RequestId, R.RequestName, R.RequestTypeId,
				       T.RequestTypeCode, R.Active,
     				   T.RequestTypeName, T.XmlFileName, T.TableName
		FROM       dbo.BloombergRequests R, dbo.BloombergRequestTypes T
		WHERE      R.RequestTypeId = T.RequestTypeId 
          AND   R.Active = @RequestStatusCode
		ORDER BY   R.RequestId

ELSE
	SELECT     R.RequestId, R.RequestName,
    			   R.RequestTypeId, T.TableType,
		    	   T.RequestTypeName + ' - ' +  T.TableType AS RequestType,
  				   T.RequestTypeName,
			       T.RequestTypeCode,	
			       R.Description, T.ProgramName, R.ScheduleFrequency, 
			       R.ReqFile, R.ScheduledTime,  R.Active,
  		       T.FileHeader, 
  				   T.SecurityTypeCode,
   				   ST.SecurityType,
			       T.RetentionDays, T.XmlFileName,  T.TableName,
			       R.LastLoadDate, R.CreateDate, R.EditorID, R.EditDate
	FROM       dbo.BloombergRequests R, dbo.BloombergRequestTypes T
  INNER JOIN dbo.BloombergSecurityTypes ST ON ST.SecurityTypeCode = T.SecurityTypeCode    
	WHERE      R.RequestTypeId = T.RequestTypeId  
	  AND      R.RequestId = @RequestId

SET NOCOUNT OFF
END

GO


