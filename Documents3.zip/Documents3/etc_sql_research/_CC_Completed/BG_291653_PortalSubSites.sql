-- PortalSubSites.sql
-- 09/18/2018

/*

create table PortalSubSites        - New table which holds sub sites for portals

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalSubSites]') AND type in (N'U'))
DROP TABLE [dbo].[PortalSubSites]
GO

CREATE TABLE [dbo].[PortalSubSites]
(
  [PortalSubSiteId] [int]         NOT NULL IDENTITY(1,1),
  [SiteId]          [int]         NOT NULL,
  [Delivery]        [varchar](50)     NULL,
  [Alias]           [varchar](30) NOT NULL,
  [EditorId]        [int]         NOT NULL,
  [EditDate]        [datetime]    NOT NULL
  CONSTRAINT [PK_PortalSubSiteId] PRIMARY KEY CLUSTERED ([PortalSubSiteId] ASC)
)
GO

ALTER TABLE [dbo].[PortalSubSites] ADD  CONSTRAINT [IX_PortalSubSites_SiteId_Delivery] UNIQUE NONCLUSTERED
( [SiteId] ASC, [Delivery] ASC )
ON [PRIMARY]
GO

truncate table PortalSubSites
go

delete from PortalSubSites
go

insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (12, 'AlphaSense, Inc.', 'AlphaSense', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (11, 'CIQ ? iPad', 'CIQ', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (11, 'CIQ - iPad', 'CIQ', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (11, 'CIQ ? Website', 'CIQ', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (11, 'CIQ - Website', 'CIQ', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (11, 'CIQ � Android', 'CIQ', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (11, 'CIQ � Blackberry', 'CIQ', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (11, 'CIQ � iPad', 'CIQ', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (11, 'CIQ � iPhone', 'CIQ', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (11, 'API Download - Real Time', 'CIQ API', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (3,  NULL, 'Bloomberg', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (23, NULL, 'Red Deer', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (22, NULL, 'RSRCHX', 1, getdate())
insert into PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate) values (12, NULL, 'FactSet', 1, getdate())
go

/*

INSERT INTO PortalSubSites(SiteId, Delivery, Alias, EditorId, EditDate)
SELECT distinct DS.SiteId, --DS.Site,
       PU.Delivery, 
	   'Alias' = 
	   CASE
		   WHEN DS.SiteId = 3 THEN 'Bloomberg'
		   WHEN DS.SiteId = 9  AND Delivery IN ('TR API','TR Desktop & API','TR Desktop/Mobile') OR Delivery IS NULL
											   THEN DS.Site
		   WHEN DS.SiteId = 11 AND Delivery IN ('API Download - Real Time','CIQ ? iPad','CIQ ? Website',
												'CIQ � Android','CIQ � Blackberry','CIQ � iPad','CIQ � iPhone',
												'CIQ � Website','Download Via Linkback') OR Delivery IS NULL
											   THEN DS.Site
		   WHEN DS.SiteId = 12 AND Delivery IS NULL THEN DS.Site
		   WHEN DS.SiteId = 12 AND Delivery IS NULL THEN DS.Site
		   WHEN DS.SiteId = 20 AND Delivery = 'AlphaSense, Inc.' THEN 'AlphaSense'
		   WHEN DS.SiteId = 20 AND Delivery = 'RMS' THEN DS.Site
		   WHEN DS.SiteId = 21 AND Delivery IS NULL THEN DS.Site
		   WHEN DS.SiteId = 21 AND Delivery = 'Visible Alpha Inbox' THEN 'ONEaccess'
		   WHEN DS.SiteId = 22 AND Delivery IS NULL THEN DS.Site
		   WHEN DS.SiteId = 23 AND Delivery IS NULL THEN DS.Site
 		   ELSE PU.Delivery
	   END,
	   1229, getdate()
FROM PortalUsage PU
JOIN DistributionSites DS ON DS.SiteId = PU.SiteId
ORDER BY DS.SiteId ASC
GO

*/

-- Delivery to Subsite mapping for each site
select
  DS.Site,
  PS.Alias,
  PS.Delivery
from DistributionSites DS 
join PortalSubSites PS on DS.SiteID = PS.SiteId
where DS.Active = -1
order by 1, 2

--
-- Alias
-- Combine delivery types

select top 500 * from PortalUsage

select distinct
  DS.Site,
  PU.Delivery
from PortalUsage PU
join DistributionSites DS on DS.SiteId = PU.SiteId
order by 1, 2

select
  DS.SiteId,
  DS.Site,
  PU.Delivery,
  count(*)
from PortalUsage PU
join DistributionSites DS on DS.SiteId = PU.SiteId
group by DS.SiteId, DS.Site, PU.Delivery
order by 2, 3

select distinct
  DS.SiteId,
  DS.Site,
  PU.Delivery,
  PSS.Alias
from PortalUsage PU
join DistributionSites DS on DS.SiteId = PU.SiteId
left join PortalSubSites PSS on PSS.SiteId = PU.SiteId and isnull(PSS.Delivery, '') = isnull(PU.Delivery, '')
where PU.ReadDate >= '01/01/2016'
order by 2, 3

select * from PortalSubSites

select * from DistributionSites

