-- Securities2_III_Rollback.sql
-- 08/07/2017

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO


/*

drop replication views
rollback Securities Column Ticker & RIC varchar(10)
update Securities for 'CROMPTON.IN'
re-create replication views, re-establish replication

*/

-- Drop replications and RV Views
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVFinancialAttributes]'))
DROP VIEW [dbo].[RVFinancialAttributes]
GO
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVSecurities]'))
DROP VIEW [dbo].[RVSecurities]
GO
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVFinancials]'))
DROP VIEW [dbo].[RVFinancials]
GO
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVDocSecurities]'))
DROP VIEW [dbo].[RVDocSecurities]
GO
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVDocSecurityRegions]'))
DROP VIEW [dbo].[RVDocSecurityRegions]
GO
/*
-- only in DEV
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[RVDocRegions]'))
DROP VIEW [dbo].[RVDocRegions]
GO
*/

-- Stop replication, drop index and then rollback Securities2 column
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Securities2]') AND name = N'IX_Securities2_Ticker')
ALTER TABLE [dbo].[Securities2] DROP CONSTRAINT [IX_Securities2_Ticker]
GO
ALTER TABLE Securities2 ALTER COLUMN Ticker VARCHAR(10)
GO
ALTER TABLE Securities2 ALTER COLUMN RIC VARCHAR(10)
GO
ALTER TABLE [dbo].[Securities2] ADD  CONSTRAINT [IX_Securities2_Ticker] UNIQUE NONCLUSTERED ([Ticker] ASC)
GO
-- sp_help [Securities2]
--SELECT * FROM [Securities2] WHERE LEN(Ticker) > 10


-- Recreate RV Views
CREATE VIEW [dbo].[RVFinancialAttributes] WITH SCHEMABINDING AS
SELECT
  S.SecurityId,
  S.Ticker,
  FCS.TickerTableEpsId EpsTypeId,
  CASE FCS.TickerTableEpsId
    WHEN 3 THEN 'EPS Reported'
    WHEN 4 THEN 'EPS Adjusted'
  END EpsType,
  FCS.TickerTableValuationId MetricsTypeId,
  CASE FCS.TickerTableValuationId
    WHEN 55 THEN 'P/E'
    WHEN 56 THEN 'P/E'
    WHEN 60 THEN 'P/BV'
    WHEN 65 THEN 'EV/EBITDA'
  END MetricsType,
  FCS.BaseYear EstimatePeriodId,
  FCS.BaseYear EstimatePeriod,
  convert(varchar,FCS.BaseYear) + 'A' LastYear,
  convert(varchar,FCS.BaseYear + 1) + 'E' CurrentYear,
  convert(varchar,FCS.BaseYear + 2) + 'E' NextYear
FROM dbo.ResearchCoverage RC
JOIN dbo.Securities2 S ON RC.SecurityID = S.SecurityID
JOIN dbo.FinancialCompanySettings FCS ON S.CompanyId = FCS.CompanyId
WHERE 
RC.LaunchDate is not null AND RC.DropDate is null


GO
CREATE UNIQUE CLUSTERED INDEX [RVFinancialAttributes_SecurityId] ON [dbo].[RVFinancialAttributes]
(
	[SecurityId] ASC
)
GO

CREATE VIEW [dbo].[RVSecurities] WITH SCHEMABINDING AS
SELECT
  SecurityId,
  Ticker,
  RIC,
  Company,
  Cusip,
  Sedol,
  Isin,
  Status,                  -- iPad app Watch List - Picklist displays active coverage where Status is 1
  RefreshDate = EditDate,  -- iPad app Watch List - Refresh (additions, subtractions, modifications) when RefreshDate > WL RefreshDate
  GoUrl
FROM
  dbo.Securities2
WHERE
  TickerType = 'STOCK'


GO

CREATE UNIQUE CLUSTERED INDEX [RVSecurities_SecurityId] ON [dbo].[RVSecurities]
(
	[SecurityId] ASC
)
GO

CREATE VIEW [dbo].[RVFinancials]  WITH SCHEMABINDING AS
SELECT
  RC.SecurityId,
  PF.Ticker,
  P.Date,
  DocId = PF.PubNo,
  PF.CoverageAction,
  PF.Rating,
  PF.RatingAction,
  CASE WHEN isnumeric(PF.TargetPrice) = 1 THEN CONVERT(VARCHAR,CAST(PF.TargetPrice AS DECIMAL(18,2))) ELSE PF.TargetPrice END TargetPrice,
  PF.TargetPriceAction,
  PF.ClosePrice,
  PF.CloseDate,
  PF.BaseYear LastYear,
  PF.BaseYear + 1 ThisYear,
  PF.BaseYear + 2 NextYear,
  PF.EPSType,
  CASE WHEN isnumeric(PF.EpsFY0) = 1 THEN CONVERT(VARCHAR,CAST(PF.EpsFY0 AS DECIMAL(18,2))) ELSE PF.EpsFY0 END EPSLastYear,
  CASE WHEN isnumeric(PF.EpsFY1) = 1 THEN CONVERT(VARCHAR,CAST(PF.EpsFY1 AS DECIMAL(18,2))) ELSE PF.EpsFY1 END EPSThisYear,
  CASE WHEN isnumeric(PF.EpsFY2) = 1 THEN CONVERT(VARCHAR,CAST(PF.EpsFY2 AS DECIMAL(18,2))) ELSE PF.EpsFY2 END EPSNextYear,
  PF.EpsFY1Action EstimateAction,
  PF.EpsFY2Action EstimateNextYearAction,
  FNT.FinancialNumberType MetricType,
  BV.ValuationFY0 MetricLastYear,
  BV.ValuationFY1 MetricThisYear,
  BV.ValuationFY2 MetricNextYear,
  PF.PriceCurrency Currency,
  '' YTDRelPerf,
  '' Yield
FROM dbo.ResearchCoverage RC
JOIN dbo.PublicationFinancials PF ON PF.CoverageId = RC.CoverageId
JOIN dbo.TickerTableValuations BV ON BV.SecurityId = PF.SecurityId
JOIN dbo.Publications P ON P.PubNo = PF.PubNo
JOIN dbo.Securities2 S ON S.SecurityId = PF.SecurityId
JOIN dbo.FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
JOIN dbo.FinancialNumberTypes FNT ON FNT.FinancialNumberTypeId = FCS.TickerTableValuationId
WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL



GO
CREATE UNIQUE CLUSTERED INDEX [RVFinancials_Ticker] ON [dbo].[RVFinancials]
(
	[DocId] ASC,
	[Ticker] ASC,
	[Date] ASC
)
GO

CREATE VIEW [dbo].[RVDocSecurities] WITH SCHEMABINDING AS
SELECT
  DocId = P.PubNo,
  SecurityId,
  OrdinalId = PropNo,
  Ticker,
  RIC,
  Company
FROM
  dbo.Properties P JOIN dbo.Securities2 S ON P.PropValue = S.Ticker
  JOIN dbo.Publications Pub ON P.PubNo = Pub.PubNo
  JOIN dbo.PublicationTypes PT ON Pub.Type = PT.PublicationType
WHERE
  P.PropId = 13 and
  Pub.Date >= convert(datetime,'05/01/2003',110) and
  PT.IsRepl = 'Y' and
  S.TickerType = 'STOCK'


GO

CREATE UNIQUE CLUSTERED INDEX [RVDocSecurities_SecurityId] ON [dbo].[RVDocSecurities]
(
	[DocId] ASC,
	[SecurityId] ASC,
	[OrdinalId] ASC
)
GO

-- RVDocSecurityRegions
-- A report may be tagged with multiple tickers where each ticker is assigned to one geographic region.
-- This may result in duplicate rows.  The DISTINCT keyword is typically used to remove duplicate rows.
-- However, an index cannot be created on a view which contains the DISTINCT keyword.
-- Alternatively it can be replaced with GROUP BY.
CREATE VIEW [dbo].[RVDocSecurityRegions] WITH SCHEMABINDING AS
SELECT
  DocId = P.PubNo,
  RegionId,
  COUNT_BIG(*) AS DUMMY -- Needed to return distinct rows in an index view
FROM
  dbo.Properties P
  JOIN dbo.Securities2 S ON P.PropValue = S.Ticker
  JOIN dbo.Publications Pub ON P.PubNo = Pub.PubNo
  JOIN dbo.PublicationTypes PT ON Pub.Type = PT.PublicationType
WHERE
  P.PropId = 13 and
  Pub.Date >= convert(datetime, '05/01/2003', 110) and
  PT.IsRepl = 'Y' and
  S.TickerType = 'STOCK'
GROUP BY
  P.PubNo, RegionId


GO
CREATE UNIQUE CLUSTERED INDEX [RVDocSecurityRegions_RegionId] ON [dbo].[RVDocSecurityRegions]
(
	[DocId] ASC,
	[RegionId] ASC
)
GO

/*
-- only in DEV
CREATE VIEW [dbo].[RVDocRegions] WITH SCHEMABINDING AS
SELECT
  DocId = P.PubNo,
  SecurityId,
  OrdinalId = PropNo,
  Ticker,
  RIC,
  Company,
  S.RegionId,
  R.Region
FROM
  dbo.Properties P JOIN dbo.Securities2 S ON P.PropValue = S.Ticker
  JOIN dbo.Regions R ON S.RegionId = R.RegionID
  JOIN dbo.Publications Pub ON P.PubNo = Pub.PubNo
  JOIN dbo.PublicationTypes PT ON Pub.Type = PT.PublicationType
WHERE
  P.PropId = 13 and
  Pub.Date >= convert(datetime,'05/01/2003',110) and
  PT.IsRepl = 'Y' and
  S.TickerType = 'STOCK'

GO
*/


/*

SELECT * FROM [RVDocRegions]

*/