-- PortalUsage.sql
-- 11/06/2018

/*

create PortalUsageBak
insert into PortalUsageBak from existing PortalUsage

stop replication
drop RVPortalUsage
drop and create new PortalUsage (remove PubNo, Delivery; add ContentType, ContentId)
insert into new PortalUsage from PortalUsageBak
create RVPortalUsage with 2 added columns - ContentId, ContentType
start replication

alter PortalSubSites rename column Delivery to Subsite

create PortalUsageStaging_VisibleAlpha (load logic: delete db rows = date range in csv)
create spLoadPortalUsageFromStaging_VisibleAlpha

alter spLoadPortalUsageFromStaging_Factset (load logic: delete db rows >= min[readdate] in csv)

-- alter existing stored procs
-- The new Portalusage does not have [PubNo], [Delivery] columns
alter spLoadPortalUsageFromStaging_TR
alter spLoadPortalUsageFromStaging_Bloomberg
alter spLoadPortalUsageFromStaging_CIQ
alter spLoadPortalUsageFromStaging_RedDeer
alter spLoadPortalUsageFromStaging_ONEAccess
alter spLoadPortalUsageFromStaging_RSRCHX
alter spLoadPortalUsageFromStaging_BlueMatrix

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- **DO NOT RE-RUN BELOW COMMENTED
-- Create PortalUsageBak table from PortalUsage table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageBak]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageBak]
GO
SELECT * INTO [dbo].[PortalUsageBak] FROM [dbo].[PortalUsage]
GO
--  **

-- Stop replication, drop and recreate RVPortalUsage
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RVPortalUsage]') AND type in (N'V'))
DROP VIEW [dbo].[RVPortalUsage]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsage]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsage]
GO

CREATE TABLE [dbo].[PortalUsage]
(
	[UsageId]     [int]			NOT NULL IDENTITY(1,1),
	[ContentType] [varchar](50) NOT NULL,
	[ContentId]   [int]         NOT NULL,
	[ReadDate]    [datetime]    NOT NULL,
	[SiteId]      [int]         NOT NULL,
	[SubSite]     [varchar](50)     NULL,
	[Email]       [varchar](200)    NULL,
	[Contact]     [varchar](250)    NULL,
	[ContactId]   [varchar](50)     NULL,
	[Account]     [varchar](250)    NULL,
	[AccountId]   [varchar](50)     NULL,
	[AccountType] [varchar](50)     NULL,
	[ExclusionId] [int]				NULL,
 CONSTRAINT [PK_PortalUsage] PRIMARY KEY CLUSTERED( [UsageId] ASC) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PortalUsage]  WITH CHECK ADD  CONSTRAINT [FK_PortalUsage_PortalUsageExclusions] FOREIGN KEY([ExclusionId])
REFERENCES [dbo].[PortalUsageExclusions] ([ExclusionId])
GO

INSERT INTO [dbo].[PortalUsage]
(ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType, ExclusionId)
SELECT
 'R', PubNo, ReadDate, SiteId, Delivery, Email, Contact, ContactId, Account, AccountId, FirmType, ExclusionId
FROM [dbo].[PortalUsageBak]
GO

-- stop replication, update RVPortalUsage to add 2 new columns from new PortalUsage table, start replication
CREATE VIEW [dbo].[RVPortalUsage] WITH SCHEMABINDING AS
SELECT
  UsageId,
  ContentId AS PubNo,
  --ContentType,
  --ContentId,
  ReadDate,
  PU.SiteId,
  Site,
  Email,
  Contact,
  ContactId,
  Account,
  AccountId,
  '' AS FirmType,
  '' AS Delivery
FROM
  dbo.PortalUsage PU
  JOIN dbo.DistributionSites DS ON PU.SiteId = DS.SiteId
WHERE
  ExclusionId IS NULL AND
  ContentType = 'R'
GO

CREATE UNIQUE CLUSTERED INDEX [RVPortalUsage_UsageId] ON [dbo].[RVPortalUsage]
(
	[UsageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

-- Alter column 'Delivery' to 'Subsite' - PortalSubSites
IF EXISTS(SELECT 1 FROM sys.columns WHERE [name] = N'Delivery' AND [object_id] = OBJECT_ID(N'PortalSubSites'))
BEGIN
    EXEC sp_rename 'PortalSubSites.Delivery', 'SubSite', 'COLUMN';
END

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_VisibleAlpha]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_VisibleAlpha]
GO

CREATE TABLE [dbo].[PortalUsageStaging_VisibleAlpha]
(
	[file_date_UTC]       [varchar](500) NULL,
	[read_id]             [varchar](500) NULL,
	[viewed_date_UTC]     [varchar](500) NULL,
	[channel_type]        [varchar](500) NULL,
	[vendor_user_id]      [varchar](500) NULL,
	[user_name]           [varchar](500) NULL,
	[user_business_email] [varchar](500) NULL,
	[vendor_client_id]    [varchar](500) NULL,
	[client_name]         [varchar](500) NULL,
	[client_type]         [varchar](500) NULL,
	[broker_model_id]     [varchar](500) NULL,
	[vendor_document_id]  [varchar](500) NULL,
	[published_date_UTC]  [varchar](500) NULL,
	[broker_ticker]       [varchar](500) NULL,
	[vendor_analyst_id]   [varchar](500) NULL,
	[analyst_name]        [varchar](500) NULL,
	[analyst_email]       [varchar](500) NULL
) ON [PRIMARY]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_VisibleAlpha]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spResetPortalUsageStaging_VisibleAlpha]
GO
CREATE PROCEDURE [dbo].[spResetPortalUsageStaging_VisibleAlpha]
AS
BEGIN
SET NOCOUNT ON

DECLARE @RowsDeleted INT

DELETE FROM [dbo].[PortalUsageStaging_VisibleAlpha]
SET @RowsDeleted = @@ROWCOUNT
SELECT @RowsDeleted

SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_VisibleAlpha]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_VisibleAlpha]
GO

Create PROCEDURE [dbo].[spLoadPortalUsageFromStaging_VisibleAlpha]
 @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 27 -- Visible Alpha

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_VisibleAlpha) RETURN

-- Delete PortalUsage rows for data in date range found in csv file
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_VisibleAlpha STG
   WHERE MONTH(PU.ReadDate) = MONTH(CONVERT(date,replace(STG.file_date_UTC,'Z',':00'),127))
   AND YEAR(PU.ReadDate) = YEAR(CONVERT(date,replace(STG.file_date_UTC,'Z',':00'),127))
   AND DAY(PU.ReadDate) = DAY(CONVERT(date,replace(STG.file_date_UTC,'Z',':00'),127))
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId,ReadDate,SiteId,SubSite,Email,Contact,ContactId,Account,AccountId,AccountType)
SELECT
 'M',
 broker_model_id,
 CONVERT(DATETIME2,replace(file_date_UTC,'Z',':00'),127),
 @SiteId,
 channel_type,--Monitoring value
 user_business_email,
 [user_name],
 vendor_user_id,
 client_name,
 vendor_client_id,
 client_type
FROM [dbo].[PortalUsageStaging_VisibleAlpha]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CONVERT(DATETIME2,replace(file_date_UTC,'Z',':00'),127)), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CONVERT(DATETIME2,replace(file_date_UTC,'Z',':00'),127)), 101)
FROM PortalUsageStaging_VisibleAlpha
WHERE isdate(CONVERT(DATETIME,replace(file_date_UTC,'Z',':00'),127))= 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for FactSet from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 12 -- Factset

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_FactSet) RETURN

-- Delete PortalUsage rows later than (>=) min(readdate) in staging table
-- This will wipe out any data that was loaded later than the min(readDate) of the data file
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND PU.ReadDate >= (SELECT MIN(CAST([Date/time read] AS DATE)) FROM PortalUsageStaging_FactSet)

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  [Doc ID (contributor)],
  [Date/time read],
  @SiteId,
  [Platform],
  [E-mail],
  [Reader name],
  [Reader ID (FactSet)],
  [Firm name],
  [Firm ID (FactSet)]
FROM [dbo].[PortalUsageStaging_FactSet]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Date/time read] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Date/time read] AS DATE) ), 101)
FROM PortalUsageStaging_FactSet
WHERE ISDATE([Date/time read]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for FactSet from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO


ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 9 -- Thomson Reuters

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_TR) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_TR STG
   WHERE YEAR(PU.ReadDate) = YEAR(STG.[Viewed Date])
   AND MONTH(PU.ReadDate)= MONTH(STG.[Viewed Date])
   AND DAY(PU.ReadDate)  = DAY(STG.[Viewed Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType)
SELECT
  'R',
  CASE WHEN ISNUMERIC([Local DocID]) = 1 THEN [Local DocID] ELSE 0 END,
  CASE WHEN ISDATE([Viewed Date]) = 1 THEN [Viewed Date] ELSE NULL END,
  @SiteId,
  [Delivery],
  [User Email],
  [User Name],
  ISNULL([Unique ID],0),
  [Client Name],
  ISNULL([Client Company ID],0),
  [Client Type]
FROM [dbo].[PortalUsageStaging_TR]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Viewed Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Viewed Date] AS DATE) ), 101)
FROM PortalUsageStaging_TR
WHERE ISDATE([Viewed Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for TR from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 3 -- Bloomberg

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_Bloomberg) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_Bloomberg STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  CASE WHEN ISNUMERIC([Story Id]) = 1 THEN [Story ID] ELSE 0 END AS StoryId,
  [Read Date],
  @SiteId,
  '',
  [Business Email],
  [User Name],
  CASE WHEN ISNUMERIC([UUID]) = 1 THEN [UUID] ELSE NULL END AS UUID,
  [Customer Name],
  [Customer #]
FROM [dbo].[PortalUsageStaging_Bloomberg]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read Date] AS DATE) ), 101)
FROM PortalUsageStaging_Bloomberg
WHERE ISDATE([Read Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Bloomberg from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 11 -- Capital IQ

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_CIQ) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_CIQ STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Download Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Download Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Download Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType)
SELECT
  'R',
  [Ctb Doc Id],
  [Download Date],
  @SiteId,
  [Activity Type],
  [Email],
  [User Name],
  [User],
  [Company Name],
  [Company],
  [Firm Type]
FROM [dbo].[PortalUsageStaging_CIQ]
WHERE ISNUMERIC([Ctb Doc Id]) = 1

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Download Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Download Date] AS DATE) ), 101)
FROM PortalUsageStaging_CIQ
WHERE ISDATE([Download Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for CIQ from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RedDeer]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 23 -- RedDeer

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RedDeer) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_RedDeer STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read_Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read_Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read_Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  [Vendor_Doc_ID ****],
  [Read_Date],
  @SiteId,
  '',
  [User_Business_Email],
  [User_Name],
  [User_ID **],
  [Client_Name],
  [Client_ID *]
FROM [dbo].[PortalUsageStaging_RedDeer]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read_Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read_Date] AS DATE) ), 101)
FROM [PortalUsageStaging_RedDeer]
WHERE ISDATE([Read_Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Red Deer from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_ONEaccess]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 21 -- ONEaccess

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_ONEaccess) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_ONEaccess STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[viewed_date_UTC])
   AND YEAR(PU.ReadDate) = YEAR(STG.[viewed_date_UTC])
   AND DAY(PU.ReadDate) = DAY(STG.[viewed_date_UTC])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  [broker_document_id],
  [viewed_date_UTC],
  @SiteId,
  [Vendor Channel],
  [user_business_email],
  [user_name],
  [vendor_user_id],
  [client_name],
  [vendor_client_id]
FROM [dbo].[PortalUsageStaging_ONEaccess]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([viewed_date_UTC] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([viewed_date_UTC] AS DATE) ), 101)
FROM [PortalUsageStaging_ONEaccess]
WHERE ISDATE([viewed_date_UTC]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for OneAccess from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT  @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RSRCHX]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 22 -- RSRCHXchange

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RSRCHX) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_RSRCHX STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Action Date (UTC)])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Action Date (UTC)])
   AND DAY(PU.ReadDate) = DAY(STG.[Action Date (UTC)])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  [Provider's Identifier],
  [Action Date (UTC)],   -- 'read time' component not needed
  @SiteId,
  '',
  [Email],
  [Surname] + ', ' + [Forename],
  [User UUID],
  [Client Org Firm Name],
  [Client UUID]
FROM [dbo].[PortalUsageStaging_RSRCHX]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Action Date (UTC)] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Action Date (UTC)] AS DATE) ), 101)
FROM [PortalUsageStaging_RSRCHX]
WHERE ISDATE([Action Date (UTC)]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for RSRCHXchange from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END


GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_BlueMatrix]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 20 -- Blue Matrix

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_BlueMatrix) RETURN

-- Remove T Z from datetime
UPDATE PortalUsageStaging_BlueMatrix 
SET [Read Date/Time] = REPLACE(REPLACE([Read Date/Time],'T',''), 'Z', ''),
    [Document Date]  = REPLACE(REPLACE([Document Date],'T',''), 'Z', '')

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_BlueMatrix STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read Date/Time])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read Date/Time])
   AND DAY(PU.ReadDate) = DAY(STG.[Read Date/Time])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  [Product ID],
  [Read Date/Time],
  @SiteId,
  [Channel],
  [Primary E-Mail],
  [User Name],
  [User ID],
  [Firm name],
  [Firm ID]
FROM [dbo].[PortalUsageStaging_BlueMatrix]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date/Time] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read Date/Time] AS DATE) ), 101)
FROM [PortalUsageStaging_BlueMatrix]
WHERE ISDATE([Read Date/Time]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Blue Matrix from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate
--Changed by Anup Singh
SELECT @RowsLoaded,@PeriodStartDate,@PeriodEndDate

SET NOCOUNT OFF
END

GO

GRANT EXECUTE ON dbo.[spResetPortalUsageStaging_VisibleAlpha] TO DE_IIS,PowerUsers
GRANT EXECUTE ON dbo.[spLoadPortalUsageFromStaging_VisibleAlpha] TO DE_IIS,PowerUsers
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_VisibleAlpha] TO DE_IIS
GO

-- DEBUG

/*
SELECT TOP 1000 * FROM [dbo].[PortalUsage]    ORDER BY ReadDate DESC
SELECT TOP 1000 * FROM [dbo].[RVPortalUsage]  ORDER BY ReadDate DESC
SELECT TOP 1000 * FROM [dbo].[PortalUsageBak] ORDER BY ReadDate DESC

SELECT TOP 1000 * FROM [dbo].[PortalUsage] ORDER BY UsageId DESC

-- Verify rows count from the 3 sources
SELECT COUNT(*) FROM [dbo].[PortalUsage]
SELECT COUNT(*) FROM [dbo].[RVPortalUsage]
SELECT COUNT(*) FROM [dbo].[PortalUsageBak]

-- Verify portal reads
SELECT top 10000 * FROM [dbo].[PortalUsage] where SiteId = 27 ORDER BY ReadDate DESC -- Visible Alpha
SELECT top 10000 * FROM [dbo].[PortalUsage] where SiteId = 3  ORDER BY ReadDate DESC -- Bloomberg
SELECT top 10000 * FROM [dbo].[PortalUsage] where SiteId = 12 ORDER BY ReadDate DESC -- Factset
SELECT top 10000 * FROM [dbo].[PortalUsage] where SiteId = 9  ORDER BY ReadDate DESC -- Thomson Reuters
SELECT top 10000 * FROM [dbo].[PortalUsage] where SiteId = 11 ORDER BY ReadDate DESC -- Capital IQ
SELECT top 10000 * FROM [dbo].[PortalUsage] where SiteId = 23 ORDER BY ReadDate DESC -- RedDeer
SELECT top 10000 * FROM [dbo].[PortalUsage] where SiteId = 21 ORDER BY ReadDate DESC -- ONEaccess
SELECT top 10000 * FROM [dbo].[PortalUsage] where SiteId = 22 ORDER BY ReadDate DESC -- RSRCHX
SELECT top 10000 * FROM [dbo].[PortalUsage] where SiteId = 20 ORDER BY ReadDate DESC -- Blue Matrix

SELECT * FROM PortalLoadLog ORDER BY EditDate DESC
SELECT * FROM PortalSubSites

--Visible alpha
SELECT * FROM PortalUsageStaging_VisibleAlpha
EXEC spLoadPortalUsageFromStaging_VisibleAlpha

-- Factset
SELECT * FROM PortalUsageStaging_FactSet ORDER BY CAST([Date/time read] AS DATE) ASC
EXEC spLoadPortalUsageFromStaging_FactSet
SELECT TOP 60000 * FROM PortalUsage WHERE SiteId = 12 ORDER BY ReadDate DESC
SELECT MIN(CAST([Date/time read] AS DATE)) FROM PortalUsageStaging_FactSet

--Bloomberg
select * FROM [dbo].[PortalUsageStaging_Bloomberg]

-- CIQ
truncate table [dbo].[PortalUsageStaging_CIQ]
select * FROM [dbo].[PortalUsageStaging_CIQ]
exec [spLoadPortalUsageFromStaging_CIQ] 1229


select SiteId, FirmType, count(*) from PortalUsage group by SiteId, FirmType ORDER BY 1, 2
select PU.SiteId, DS.Site, PU.FirmType, count(*) as Num from PortalUsage PU
join DistributionSites DS on DS.SiteId = PU.SiteId group by PU.SiteId, DS.Site, PU.FirmType ORDER BY 1, 2
-- TR  - [Firm Type]
-- CIQ - [Client Type]
-- VA  - [client_type]

*/