-- AutonomousOnePercent.sql
-- 03/25/2019

/*
alter spRptGetSecurityCheckboxDisclosures - Modified to include Autonomous tickers
alter spRptSetSecurityCheckboxDisclosures - Modified to log to AdminLog table
alter spExportHoldings - Modified to apply ticker translation logic to bloomberg format
*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spRptGetSecurityCheckboxDisclosures]
@DisclosureId int
AS
BEGIN
SET NOCOUNT ON
--Active Bernstein Tickers
SELECT
  'SecurityId'         = S.SecurityId,
  'Ticker'             = S.Ticker,
  'ISIN'               = isnull(S.ISIN, ''),
  'Company'            = S.Company,
  'CheckboxDisclosure' = CASE SC.DisclosureId WHEN @DisclosureId THEN 'Yes' ELSE 'No' END
FROM ResearchCoverage V
JOIN Securities2 S ON S.SecurityID = V.SecurityID
LEFT JOIN SecurityCheckboxDisclosures SC ON SC.SecurityId = S.SecurityId AND SC.DisclosureId = @DisclosureId
WHERE DropDate IS NULL

UNION
--Autonomous Tickers
SELECT
  'SecurityId'         = S.SecurityId,
  'Ticker'             = S.Ticker,
  'ISIN'               = isnull(S.ISIN, ''),
  'Company'            = S.Company,
  'CheckboxDisclosure' = CASE SC.DisclosureId WHEN @DisclosureId THEN 'Yes' ELSE 'No' END
FROM Securities2 S
LEFT JOIN SecurityCheckboxDisclosures SC ON SC.SecurityId = S.SecurityId AND SC.DisclosureId = @DisclosureId
WHERE S.TypeId = 2 AND IsActive = -1
ORDER BY 4, 2

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spRptSetSecurityCheckboxDisclosures]
@DisclosureId       int,
@SecurityInsertList varchar(max),
@SecurityDeleteList varchar(max),
@Source             varchar(10),
@EditUser           varchar(50)
AS
BEGIN
SET NOCOUNT ON
DECLARE @UserId VARCHAR(8)
DECLARE @DisclosureText VARCHAR(2048)

  SELECT TOP 1 @UserId = CONVERT(VARCHAR(8),isnull(UserId,0)) FROM Users WHERE UserName like '%' + @EditUser + '%'
  SELECT @DisclosureText = Disclosure FROM SecurityCheckboxTypes WHERE DisclosureID = @DisclosureId

  IF EXISTS(SELECT * FROM UserRoles WHERE RoleId in (5,1) and UserId = @UserId)
  BEGIN TRY
    BEGIN TRANSACTION
    IF (@SecurityInsertList <> '' OR  @SecurityDeleteList <> '')
    BEGIN
      IF (@SecurityInsertList <> '')
      BEGIN
        CREATE TABLE #Tmp_Insert_Securities(SecurityId int)

        EXEC('INSERT INTO #Tmp_Insert_Securities(SecurityId)
        SELECT SecurityId FROM Securities2 WHERE SecurityId in (' + @SecurityInsertList + ')')

        INSERT INTO SecurityCheckboxDisclosures(SecurityId,DisclosureId,EditorID,EditDate)
        SELECT SecurityId,@DisclosureId,@UserId,getdate() FROM #Tmp_Insert_Securities

        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        SELECT
          'Disclosures | Firm',
          'A',
          CASE WHEN LEN(Ticker + ' | ' + @DisclosureText) > 100 THEN LEFT(Ticker + ' | ' + @DisclosureText, 97) + '...' ELSE Ticker + ' | ' + @DisclosureText END ,
          NULL,
          T.SecurityId,
          @UserId,
          GETDATE()
        FROM #Tmp_Insert_Securities T JOIN Securities2 S ON T.SecurityId = S.SecurityID

        DROP TABLE #Tmp_Insert_Securities
      END

      IF (@SecurityDeleteList <> '')
      BEGIN
        CREATE TABLE #Tmp_Delete_Securities(SecurityId int)

        EXEC('INSERT INTO #Tmp_Delete_Securities(SecurityId)
        SELECT SecurityId FROM Securities2 WHERE SecurityId in (' + @SecurityDeleteList + ')')

        DELETE FROM SecurityCheckboxDisclosures
        WHERE SecurityId in (SELECT SecurityId FROM #Tmp_Delete_Securities) AND DisclosureId = @DisclosureId

        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        SELECT
          'Disclosures | Firm',
          'D',
          '',
          CASE WHEN LEN(Ticker + ' | ' + @DisclosureText) > 100 THEN LEFT(Ticker + ' | ' + @DisclosureText, 97) + '...' ELSE Ticker + ' | ' + @DisclosureText END ,
          T.SecurityId,
          @UserId,
          GETDATE()
        FROM #Tmp_Delete_Securities T JOIN Securities2 S ON T.SecurityId = S.SecurityID

        DROP TABLE #Tmp_Delete_Securities
      END
    END
    SELECT 1 Return_Value
    COMMIT
  END TRY
  BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK
    DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
    SELECT @ErrMsg = ERROR_MESSAGE(), @ErrSeverity = ERROR_SEVERITY()

    RAISERROR(@ErrMsg, @ErrSeverity, 1)
  END CATCH
  ELSE
    SELECT 0 Return_Value
SET NOCOUNT OFF
END

GO

alter proc dbo.spExportHoldings
as
begin

  select
    1             as  tag,
    null          as  parent,
    null          as [Holdings!1!],
    null          as [Holding!2!name],
    null          as [Holding!2!email],
    null          as [Holding!2!company],
    null          as [Holding!2!ticker],
    null          as [Holding!2!isin]

  union

  select
    2             as  tag,
    1             as  parent,
    null          as [Holdings!1!],
    Name          as [Holding!2!name],
    Email         as [Holding!2!email],
    Company       as [Holding!2!company],
    case
    when CHARINDEX('.',H.Ticker) > 0 then replace(H.Ticker,'.',' ')
    else H.Ticker + ' US' end as [Holding!2!ticker],
    ISIN          as [Holding!2!isin]
  from vHoldings H

  order by 4, 5
  for xml explicit

end
go
