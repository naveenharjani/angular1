-- CC_spSearchResearchCoverage_Rollback.sql
-- 07/17/2018

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSearchResearchCoverage]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT,
  @Style         int
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'

DECLARE @WHERE varchar(2048)
IF @Style = 1 SET @WHERE = 'WHERE C.LaunchDate IS NOT NULL AND C.DropDate IS NULL' -- Launched, Not dropped
IF @Style = 2 SET @WHERE = 'WHERE C.DropDate IS NULL'                              -- Not dropped
IF @Style = 3 SET @WHERE = ''                                                      -- Launched/unlaunched, dropped/not dropped

CREATE TABLE #TmpSearch
(
  ID           int IDENTITY,
  Industry     varchar(50)   NULL,
  Analyst      varchar(50)   NULL,
  Ticker       varchar(15)   NULL,
  Company      varchar(63)   NULL,
  LaunchDate   datetime      NULL,
  DropDate     datetime      NULL,
  Rating       char(1)       NULL,
  Target       varchar(10)   NULL, -- decimal(9, 2)
  MetaAnalyst  varchar(48)   NULL,
  CoverageID   int           NULL,
  CUSIP        varchar(10)   NULL,
  SEDOL        varchar(10)   NULL,
  ISIN         varchar(12)   NULL
)
INSERT INTO #TmpSearch (Industry, Analyst, Ticker, Company, LaunchDate, DropDate, Rating, Target, MetaAnalyst, CoverageID, CUSIP, SEDOL, ISIN)
EXEC
(
'SELECT
  Industry    = I.IndustryName,
  Analyst     = A.Last + '', '' + A.First,
  Ticker      = S.Ticker,
  Company     = S.Company,
  LaunchDate  = C.LaunchDate,
  DropDate    = C.DropDate,
  Rating      = FL.Rating,
  Target      = CONVERT(varchar, FL.TargetPrice),
  MetaAnalyst = A.Name,
  CoverageID  = C.CoverageID,
  CUSIP       = ISNULL(S.CUSIP, ''''),
  SEDOL       = ISNULL(S.SEDOL, ''''),
  ISIN        = ISNULL(S.ISIN, '''')
FROM ResearchCoverage C
JOIN Industries I ON I.IndustryID = C.IndustryID
JOIN Authors A ON A.AuthorID = C.AnalystID
LEFT JOIN Securities2 S ON S.SecurityID = C.SecurityID -- SecurityID OPTIONAL, THEREFORE LEFT JOIN
LEFT JOIN vFinancialsLatest FL ON FL.CoverageID = C.CoverageID '
+ @WHERE
+ ' ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT Industry, Analyst, Ticker, Company, LaunchDate, DropDate, Rating, Target, MetaAnalyst, CoverageID, CUSIP, SEDOL, ISIN
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO
