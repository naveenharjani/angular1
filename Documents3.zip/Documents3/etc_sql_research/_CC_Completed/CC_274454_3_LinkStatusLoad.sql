--CC_LinkStatusLoad.sql
--02/15/2018
delete from LinkStatus
go
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 10,'Login Failed',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 11,'Invalid Email',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 12,'Invalid Password',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 13,'User not enabled for BR.Com access',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 14,'Account locked after multiple failed attempts',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 19,'Unable to retrieve ContactId from CRM',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 20,'Model access not enabled',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 21,'Product group access not enabled',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 22,'User exceeded quota',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 42,'CRM is down',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 61,'Document Id not found',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 62,'File not found',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 63,'File streaming error',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 100,'File streaming successful',1126,getdate()
insert into LinkStatus(StatusId,Status,EditorId,EditDate) select 101,'CRM down. File streamed successfully',1126,getdate()
go