-- SQL2017.sql
-- 10/02/2018

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*

vBloombergFXLatest uses collate to distinguish case sensitive currency codes, e.g. GBP vs GBp

SQL 2017 enforces strict use of collation

sp_helptext vBloombergFXLatest

alter spGetTickerTableApiXml       -- collation added (called by Tickertable UI)
drop spGetEstimatesTickerTableXml  -- duplicate proc (to spGetTickerTableApiXml), please drop

*/

ALTER PROCEDURE [dbo].[spGetTickerTableApiXml]
  @InXml TEXT
AS
SET NOCOUNT ON

/*

@InXml contains the DocumentInfo.xml

*/

DECLARE
  @hDoc             INT,
  @Date             DATETIME,
  @Type             VARCHAR(31),
  @Title            VARCHAR(255),
  @RptPubNo         INT,
  @Version          INT,
  @FinancialsXml    XML,
  @PublicationsXml  XML,
  @TickerTableXml   VARCHAR(MAX),
  @TickerBaseYearMajority INT,
  @IndexBaseYearFirst     INT

EXEC sp_xml_preparedocument @hDoc OUTPUT, @InXML

SELECT @Date = X.Date, @Type = X.Type, @Title = X.Title
FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
WITH (Date datetime '@pubDate', Type varchar(31) '@type', Title varchar(255) '@title') X

EXEC spCheckForResubmits @Date, @Type, @Title, @RptPubNo OUTPUT, @Version OUTPUT

SELECT
  ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo,
  X.SecurityId, X.Ticker, X.IndicateChange,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'live', @RptPubNo) AS SourceLive,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'old',  @RptPubNo) AS SourceOld,
  ISNULL(X.LastPubNo, '') AS LastChangePubNo,
  S.Company, FCS.BaseYear, S.Alias,
  S.CurrencyCode,
  -- Model Currency for primary ticker - use for FX Cross Rate
  'PrimaryModelCur' = (SELECT FSS.CurCode FROM FinancialSecuritySettings FSS
                       JOIN Securities2 s ON S.SecurityId = FSS.SecurityId
                       WHERE S.CompanyId = FCS.CompanyId and s.isprimary = 'Y'),
  FCS.CompanyId,
  SI.SecurityID as PrimaryIndexId, SI.Ticker as PrimaryIndex,
  S.TickerType, FCS.TickerTableEpsId, FCS.TickerTableValuationId,
  CASE WHEN X.CoverageId IS NULL OR X.CoverageId = '' OR X.CoverageId = '0' THEN RC.CoverageId
       ELSE X.CoverageId
  END AS CoverageId
INTO #TickerList
FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
WITH (SecurityId int '@id', Ticker varchar(30) '@ticker', IndicateChange varchar(30) '@indicateChange', LastPubNo int '@optLastPubNo', CoverageId INT '@coverageId') X
INNER JOIN Securities2 S ON S.SecurityId = X.SecurityId AND S.TickerType = 'STOCK'
INNER JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
INNER JOIN Securities2 SI ON SI.Ticker = S.BenchmarkIndex
INNER JOIN ResearchCoverage RC ON RC.SecurityId = S.SecurityId AND RC.DropDate IS NULL

-- Include Indexes for the provided tickers
INSERT INTO #TickerList
SELECT
  100 + ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo,
  SecurityId, Ticker, 'no',
  [dbo].[fnGetEstimateSource](SecurityId, 'no', 'live', @RptPubNo)  AS SourceLive,
  [dbo].[fnGetEstimateSource](SecurityId, 'no', 'old',  @RptPubNo)  AS SourceOld,
  0  AS LastChangePubNo,
  Company, FCS.BaseYear, '' as Alias,
  S.CurrencyCode,
  '' AS PrimaryModelCur,
  S.CompanyId,
  '', '', TickerType,
  FCS.TickerTableEpsId, FCS.TickerTableValuationId,
  0 as CoverageId
FROM Securities2 S
INNER JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
WHERE Ticker in ( SELECT PrimaryIndex FROM #TickerList)

-- Tickers - Get BaseYear count
SELECT S.BaseYear,Count(S.BaseYear) BaseYearTickerCount
INTO #TmpBaseYearOptions
FROM (SELECT distinct Ticker, BaseYear FROM #TickerList WHERE TickerType = 'STOCK') S
GROUP BY BaseYear

-- Tickers - Get BaseYear majority
SELECT @TickerBaseYearMajority = MAX(BaseYear) FROM #TmpBaseYearOptions WHERE BaseYearTickerCount = (SELECT MAX(BaseYearTickerCount) FROM #TmpBaseYearOptions)

-- Indexes - Get BaseYear of first index
SELECT TOP 1 @IndexBaseYearFirst = BaseYear FROM #TickerList WHERE TickerType = 'INDEX'

-- Analyst data - Draft and Published value rowset
-- This query returns Tickers and Index data
-- Since there may not be Rating/Target Price for Index, Use Securities2 and left join with vFinancialNumbersLatest, FinancialNumberTypes
SELECT
  TL.Ticker,
  TL.SecurityId,
  VFT.FinancialNumberTypeId,
  VFT.FinancialNumberType,
  FN.CurCode,
  FN.FinancialPeriodId,
  CONVERT(varchar,FN.Value)  AS LiveValue,
  CONVERT(varchar,FN2.Value) AS DraftValue,
  TL.BaseYear,
  VFT.ShortName AS Description,
  TL.Company,
  ISNULL(TL.Alias, '') AS Alias,
  TL.IndicateChange,
  TL.DisplayNo
INTO #TmpAnalystDataDraftLive
FROM #TickerList TL
INNER JOIN FinancialNumberTypes VFT ON  VFT.FinancialNumberType IN ('RATING', 'TARGETPRICE')
-- Only data for active ticker coverage (not dropped/suspended) using active CoverageId
LEFT JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = TL.SecurityId
                                        AND FN.CoverageId = TL.CoverageId
                                        AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                        AND FN.IsDraft                = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                        AND FN2.CoverageId = TL.CoverageId
                                        AND FN2.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                        AND FN2.IsDraft               = 1  -- Draft

-- Marketdata fields - if override else bloomberg
SELECT
  vmd.SecurityId,
  MAX(CASE WHEN vmd.FinancialNumberType = 'CRNCY' AND TL.TickerType = 'STOCK'
           THEN vmd.Value ELSE '' END) AS Cur,
  MAX(CASE vmd.FinancialNumberType WHEN 'CLOSEDATE'       THEN vmd.Value ELSE '' END) AS CloseDate,
  MAX(CASE vmd.FinancialNumberType WHEN 'CLOSEPRICE'      THEN vmd.Value ELSE '' END) AS ClosePrice,

  MAX(CASE vmd.FinancialNumberType WHEN 'CHG_PCT_1YR'     THEN vmd.Value ELSE '' END) AS Perf1YrTicker,
  MAX(CASE md2.FinancialNumberType WHEN 'CHG_PCT_1YR'     THEN md2.Value ELSE '' END) AS Perf1YrIndex,
  MAX(CASE vmd.FinancialNumberType WHEN 'CHG_PCT_1YR'     THEN
                                                                    CASE
                                                                      WHEN TL.TickerType = 'INDEX'
                                                                      THEN ''
                                                                      WHEN IsNumeric(vmd.Value)= 0 OR IsNumeric(md2.Value)= 0
                                                                      THEN 'NA'
                                                                      ELSE CONVERT(VARCHAR,(CAST(vmd.value AS float) - CAST(md2.value AS float)))
                                                                    END
                                                                  END) AS Perf1Yr,

  MAX(CASE vmd.FinancialNumberType WHEN 'CHG_PCT_YTD'     THEN vmd.Value ELSE '' END) AS PerfYtdTicker,
  MAX(CASE md2.FinancialNumberType WHEN 'CHG_PCT_YTD'     THEN md2.Value ELSE '' END) AS PerfYtdIndex,
  MAX(CASE vmd.FinancialNumberType WHEN 'CHG_PCT_YTD'     THEN
                                                                    CASE
                                                                       WHEN TL.TickerType = 'INDEX'
                                                                       THEN ''
                                                                       WHEN IsNumeric(vmd.Value)= 0 OR IsNumeric(md2.Value)= 0
                                                                       THEN 'NA'
                                                                       ELSE CONVERT(VARCHAR,(CAST(vmd.value AS float) - CAST(md2.value AS float)))
                                                                    END
                                                                  END) AS PerfYtd,

  MAX(CASE vmd.FinancialNumberType WHEN 'EQY_DVD_YLD_IND' THEN vmd.Value ELSE '' END) AS DivYld,

  MAX(CASE vmd.FinancialNumberType WHEN 'FXRATE' THEN vmd.Value ELSE '' END) AS FxRate,
  MAX(CASE vmd.FinancialNumberType WHEN 'EV' THEN vmd.UnitValue ELSE '' END) AS EV

INTO #TmpMarketdata
FROM #TickerList TL
LEFT JOIN vMarketData vmd ON vmd.SecurityID = TL.SecurityId
                          AND vmd.FinancialNumberTypeId IN (SELECT FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType IN
                                   ('CLOSEDATE', 'CLOSEPRICE', 'CRNCY', 'CHG_PCT_1YR', 'CHG_PCT_YTD', 'EQY_DVD_YLD_IND', 'FXRATE' , 'EV'))
LEFT JOIN vMarketData md2 ON md2.SecurityID = TL.PrimaryIndexId AND vmd.FinancialNumberTypeId = md2.FinancialNumberTypeId
GROUP BY vmd.SecurityId

-- Estimates eps data - Draft and Published value rowset
-- Tickers - FY0, FY1, FY2
-- Indexes - If TickerBaseYearMajority > IndexBaseYearFirst then FY1, FY2, FY3 else FY0, FY1, FY2
SELECT
  TL.Ticker,
  TL.SecurityId,
  VFT.FinancialNumberTypeId,
  VFT.FinancialNumberType,
  CASE WHEN TL.TickerType = 'STOCK' THEN CONVERT(varchar, FSS.CurCode) ELSE '' END AS CurCode,
  TL.PrimaryModelCur,
  FP.FinancialPeriodId,
  CONVERT(varchar,FN.Value)  AS LiveValue,
  CONVERT(varchar,FN2.Value) AS DraftValue,
  TL.BaseYear,
  CASE WHEN TL.TickerType = 'STOCK' THEN VFT.ShortName ELSE '' END AS Description,
  TL.IndicateChange,
  TL.TickerType,
  FP.FinancialPeriod
INTO #TmpEpsEstimatesDraftLive
FROM #TickerList TL
INNER JOIN FinancialNumberTypes VFT ON VFT.FinancialNumberTypeId = TL.TickerTableEpsId
CROSS JOIN FinancialPeriods FP
-- Only data for active ticker coverage (not dropped/suspended) using active CoverageId
LEFT JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = TL.SecurityId
                                        AND ( FN.CoverageId = TL.CoverageId OR FN.CoverageId IS NULL)  -- NULL for Indexes
                                        AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                        AND FN.FinancialPeriodId = FP.FinancialPeriodId
                                        AND FN.IsDraft                = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                        AND ( FN.CoverageId = TL.CoverageId OR FN.CoverageId IS NULL)
                                        AND FN2.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                        AND FN2.FinancialPeriodId = FP.FinancialPeriodId
                                        AND FN2.IsDraft               = 1  -- Draft
LEFT JOIN FinancialSecuritySettings FSS ON FSS.SecurityId = TL.SecurityId
WHERE (TL.TickerType = 'STOCK' AND FP.FinancialPeriod IN ('FY0','FY1','FY2'))
       OR
      (Tl.TickerType = 'INDEX' AND FP.FinancialPeriod IN ('FY0','FY1','FY2','FY3'))


-- Calculate FX Cross Rate by Ticker
SELECT DISTINCT M.Securityid, M.Cur, M.FxRate, M.EV,
       E.CurCode, E.PrimaryModelCur,
       CONCAT(E.PrimaryModelCur, M.Cur) AS FXCrossTicker,
       'FXCrossRate' = ( CASE
                            WHEN M.Cur <> E.PrimaryModelCur
                            THEN (SELECT MAX(Value) FROM vBloombergFXLatest WHERE BloombergMnemonic = 'PRIOR_CLOSE_MID'
                                                                              AND Ticker = E.PrimaryModelCur + M.Cur COLLATE SQL_Latin1_General_CP1_CS_AS)
                            ELSE '1'
                          END  )
INTO #TmpFxRates
FROM #TmpMarketdata M
JOIN #TmpEpsEstimatesDraftLive E ON M.Securityid = E.Securityid

-- Valuations eps data - Draft and Published value rowset
-- Conditionally align indexes FY with tickers FY
-- Tickers - FY0, FY1, FY2
-- Indexes - If TickerBaseYearMajority > IndexBaseYearFirst then FY1, FY2, FY3 else FY0, FY1, FY2
SELECT
  TL.Ticker,
  TL.SecurityId,
  VFT.FinancialNumberTypeId,
  VFT.FinancialNumberType,
  CASE WHEN TL.TickerType = 'STOCK' THEN TL.CurrencyCode ELSE '' END AS CurCode,
  FP.FinancialPeriodId,
  CONVERT(varchar,FN.Value)  AS LiveValue,
  CONVERT(varchar,FN2.Value) AS DraftValue,
  TL.BaseYear,
  CASE WHEN TL.TickerType = 'STOCK' THEN VFT.ShortName ELSE '' END AS Description,
  FP.FinancialPeriod
INTO #TmpValuationsDraftLive
FROM #TickerList TL
INNER JOIN FinancialNumberTypes VFT ON VFT.FinancialNumberTypeId = TL.TickerTableValuationId
CROSS JOIN FinancialPeriods FP
LEFT JOIN vValuationsLatest FN  ON FN.SecurityId = TL.SecurityId
                                  AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                  AND FN.FinancialPeriodId = FP.FinancialPeriodId
                                  AND FN.IsDraft                = 0  -- Live
LEFT JOIN vValuationsLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                  AND FN2.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                  AND FN2.FinancialPeriodId = FP.FinancialPeriodId
                                  AND FN2.IsDraft               = 1  -- Draft
WHERE (TL.TickerType = 'STOCK' AND FP.FinancialPeriod IN ('FY0','FY1','FY2'))
       OR
      (Tl.TickerType = 'INDEX' AND FP.FinancialPeriod IN ('FY0','FY1','FY2','FY3'))

-- Get Latest Financials data in a XML variable
SET @FinancialsXml =
(
SELECT * FROM
(
SELECT
  1                      AS tag,
  null                   AS parent,
  NULL                   AS [TickerTableBody!1!TickerTableBody],

  NULL                   AS [TickerTableBodyRow!2!securityId],
  NULL                   AS [TickerTableBodyRow!2!ticker],
  NULL                   AS [TickerTableBodyRow!2!alias],

  -- Rating, target
  NULL                   AS [TickerTableBodyRow!2!baseYear],
  NULL                   AS [TickerTableBodyRow!2!rating],
  NULL                   AS [TickerTableBodyRow!2!isBoldRating],
  NULL                   AS [TickerTableBodyRow!2!targetPrice],
  NULL                   AS [TickerTableBodyRow!2!isBoldTargetPrice],

  -- Market data
  NULL                   AS [TickerTableBodyRow!2!tradeCurrency],
  NULL                   AS [TickerTableBodyRow!2!closeDate],
  NULL                   AS [TickerTableBodyRow!2!closePrice],
  NULL                   AS [TickerTableBodyRow!2!perfType],
  NULL                   AS [TickerTableBodyRow!2!perf],
  NULL                   AS [TickerTableBodyRow!2!divYld],
  NULL                   AS [TickerTableBodyRow!2!fxRate],
  NULL                   AS [TickerTableBodyRow!2!ev],

  -- EPS
  NULL                   AS [TickerTableBodyRow!2!epsType],
  NULL                   AS [TickerTableBodyRow!2!epsCurrency],
  NULL                   AS [TickerTableBodyRow!2!epsFY0],
  NULL                   AS [TickerTableBodyRow!2!isBoldEpsFY0],
  NULL                   AS [TickerTableBodyRow!2!epsFY1],
  NULL                   AS [TickerTableBodyRow!2!isBoldEpsFY1],
  NULL                   AS [TickerTableBodyRow!2!epsFY2],
  NULL                   AS [TickerTableBodyRow!2!isBoldEpsFY2],

  -- Valuations
  NULL                   AS [TickerTableBodyRow!2!valType],
  NULL                   AS [TickerTableBodyRow!2!valFY0],
  NULL                   AS [TickerTableBodyRow!2!isBoldValFY0],
  NULL                   AS [TickerTableBodyRow!2!valFY1],
  NULL                   AS [TickerTableBodyRow!2!isBoldValFY1],
  NULL                   AS [TickerTableBodyRow!2!valFY2],
  NULL                   AS [TickerTableBodyRow!2!isBoldValFY2],

  NULL                   AS [TickerTableBodyRow!2!company],
  NULL                   AS [TickerTableBodyRow!2!dispOrder],
  NULL                   AS [TickerTableBodyRow!2!displayNo]

UNION ALL

-- Ticker - 1st row - draft or live
SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [TickerTableBody!1!TickerTableBody],

  A.SecurityID           AS [TickerTableBodyRow!2!securityId],
  MAX(A.Ticker)          AS [TickerTableBodyRow!2!ticker],
  MAX(A.Alias)           AS [TickerTableBodyRow!2!alias],

  MAX(A.BaseYear)        AS [TickerTableBodyRow!2!baseYear],

  -- rating value
  MAX(CASE WHEN A.FinancialNumberType = 'RATING' AND A.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN A.DraftValue
           WHEN A.FinancialNumberType = 'RATING' AND A.LiveValue  IS NOT NULL THEN A.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!rating],
  -- isBold attribute
  MAX(CASE
    WHEN A.FinancialNumberType = 'RATING' AND A.DraftValue IS NOT NULL AND A.LiveValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
  END)                      AS [TickerTableBodyRow!2!isBoldRating],

  -- target price value
  MAX(CASE WHEN A.FinancialNumberType = 'TARGETPRICE' AND A.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN A.DraftValue
           WHEN A.FinancialNumberType = 'TARGETPRICE' AND A.LiveValue  IS NOT NULL THEN A.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!targetPrice],
  -- isBold attribute
  MAX(CASE
    WHEN A.FinancialNumberType = 'TARGETPRICE' AND A.DraftValue IS NOT NULL AND A.LiveValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
  END)                      AS [TickerTableBodyRow!2!isBoldTargetPrice],

  -- Market data fields
  MAX(M.Cur)                   AS [TickerTableBodyRow!2!tradeCurrency],
  MAX(DATENAME(dd, M.CloseDate)) + ' ' + MAX(LEFT(DATENAME(mm, M.CloseDate),3)) + ' ' + MAX(DATENAME(yy, M.CloseDate))
               AS [TickerTableBodyRow!2!closeDate],
  MAX(M.ClosePrice)            AS [TickerTableBodyRow!2!closePrice],
  'TTM'                        AS [TickerTableBodyRow!2!perfType],
  MAX(M.Perf1Yr)               AS [TickerTableBodyRow!2!perf],
  MAX(M.DivYld)                AS [TickerTableBodyRow!2!divYld],
  MAX(CASE WHEN ISNULL(F.FxRate, '') <>'' THEN F.FxRate
           WHEN ISNULL(F.FXCrossRate, '') <>'' THEN F.FXCrossRate
           ELSE ' '
           END)
                               AS [TickerTableBodyRow!2!fxRate],
  MAX(M.EV)                    AS [TickerTableBodyRow!2!ev],

  -- EPS
  -- Conditionally align indexes FY with tickers FY
  -- Tickers - FY0, FY1, FY2
  -- Indexes - If TickerBaseYearMajority > IndexBaseYearFirst then FY1, FY2, FY3 else FY0, FY1, FY2
  MAX(E.Description)           AS [TickerTableBodyRow!2!epsType],
  MAX(E.CurCode)               AS [TickerTableBodyRow!2!epsCurrency],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                  WHEN E.FinancialPeriodId = 2 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 2 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
              END
           ELSE
               CASE
                  WHEN E.FinancialPeriodId = 1 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 1 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
               END
      END) AS [TickerTableBodyRow!2!epsFY0],

  -- isBold attribute - when draft and live value exists
  MAX(CASE WHEN E.FinancialPeriodId = 1 AND E.LiveValue  IS NOT NULL AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldEpsFY0],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                  WHEN E.FinancialPeriodId = 3 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 3 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
              END
           ELSE
               CASE
                  WHEN E.FinancialPeriodId = 2 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 2 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
               END
      END) AS [TickerTableBodyRow!2!epsFY1],

  MAX(CASE WHEN E.FinancialPeriodId = 2 AND E.LiveValue  IS NOT NULL AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldEpsFY1],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                  WHEN E.FinancialPeriodId = 4 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 4 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
              END
           ELSE
               CASE
                  WHEN E.FinancialPeriodId = 3 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.DraftValue
                  WHEN E.FinancialPeriodId = 3 AND E.LiveValue  IS NOT NULL THEN E.LiveValue
                  ELSE ''
               END
      END) AS [TickerTableBodyRow!2!epsFY2],

  MAX(CASE WHEN E.FinancialPeriodId = 3 AND E.LiveValue  IS NOT NULL AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldEpsFY2],

  -- Valuations
  -- Conditionally align indexes FY with tickers FY
  -- Tickers - FY0, FY1, FY2
  -- Indexes - If TickerBaseYearMajority > IndexBaseYearFirst then FY1, FY2, FY3 else FY0, FY1, FY2
  MAX(V.Description)   AS [TickerTableBodyRow!2!valType],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                 WHEN V.FinancialPeriodId = 2 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 2 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
              END
           ELSE
               CASE
                 WHEN V.FinancialPeriodId = 1 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 1 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
               END
      END) AS [TickerTableBodyRow!2!valFY0],
  -- isBold attribute - when draft and live value exists
  MAX(CASE WHEN V.FinancialPeriodId = 1 AND V.LiveValue  IS NOT NULL AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldValFY0],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                 WHEN V.FinancialPeriodId = 3 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 3 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
              END
           ELSE
               CASE
                 WHEN V.FinancialPeriodId = 2 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 2 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
               END
      END) AS [TickerTableBodyRow!2!valFY1],

  MAX(CASE WHEN V.FinancialPeriodId = 2 AND V.LiveValue  IS NOT NULL AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldValFY1],

  MAX(CASE
           WHEN E.TickerType = 'INDEX' AND @TickerBaseYearMajority > @IndexBaseYearFirst
           THEN
              CASE
                 WHEN V.FinancialPeriodId = 4 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 4 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
              END
           ELSE
               CASE
                 WHEN V.FinancialPeriodId = 3 AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN V.DraftValue
                 WHEN V.FinancialPeriodId = 3 AND V.LiveValue  IS NOT NULL THEN V.LiveValue
                 ELSE ''
               END
      END) AS [TickerTableBodyRow!2!valFY2],

  MAX(CASE WHEN V.FinancialPeriodId = 3 AND V.LiveValue  IS NOT NULL AND V.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [TickerTableBodyRow!2!isBoldvalFY2],

  MAX(A.Company)               AS [TickerTableBodyRow!2!company],
  1                            AS [TickerTableBodyRow!2!dispOrder],
  MAX(A.DisplayNo)             AS [TickerTableBodyRow!2!displayNo]

FROM #TmpAnalystDataDraftLive A
LEFT JOIN #TmpMarketdata M ON M.SecurityId = A.SecurityId
LEFT JOIN #TmpEpsEstimatesDraftLive E ON E.SecurityId = A.SecurityId
LEFT JOIN #TmpValuationsDraftLive V ON V.SecurityId = A.SecurityId
LEFT JOIN #TmpFxRates F ON F.SecurityId = A.SecurityId

GROUP BY A.SecurityId, E.SecurityId

UNION ALL

-- Ticker - 2nd row - live if draft exists
SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [TickerTableBody!1!TickerTableBody],

  A.SecurityID            AS [TickerTableBodyRow!2!securityId],
  'OLD'                   AS [TickerTableBodyRow!2!ticker],
  ''                      AS [TickerTableBodyRow!2!alias],

  ''                      AS [TickerTableBodyRow!2!baseYear],
  -- rating value
  MAX(CASE WHEN A.FinancialNumberType = 'RATING' AND A.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN A.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!rating],
  NULL AS [TickerTableBodyRow!2!isBoldRating],
  -- target price value
  MAX(CASE WHEN A.FinancialNumberType = 'TARGETPRICE' AND A.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN A.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!targetprice],
  NULL AS [TickerTableBodyRow!2!isBoldTargetPrice],

  -- Market data
  ''                     AS [TickerTableBodyRow!2!tradeCurrency],
  ''                     AS [TickerTableBodyRow!2!closeDate],
  ''                     AS [TickerTableBodyRow!2!closePrice],
  ''                     AS [TickerTableBodyRow!2!perfType],
  ''                     AS [TickerTableBodyRow!2!perf],
  ''                     AS [TickerTableBodyRow!2!divYld],
  MAX(CASE WHEN ISNULL(F.FxRate, '') <>'' THEN F.FxRate
           ELSE F.FXCrossRate
           END)
                         AS [TickerTableBodyRow!2!fxRate],
  ''                     AS [TickerTableBodyRow!2!ev],

  -- Estimates
  ''                     AS [TickerTableBodyRow!2!epsType],
  ''                     AS [TickerTableBodyRow!2!epsCurrency],

  MAX(CASE WHEN E.FinancialPeriodId = 1 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!epsFY0],
  ''                     AS [TickerTableBodyRow!2!isBoldEpsFY0],
  MAX(CASE WHEN E.FinancialPeriodId = 2 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!epsFY1],
  ''                     AS [TickerTableBodyRow!2!isBoldEpsFY1],
  MAX(CASE WHEN E.FinancialPeriodId = 3 AND E.DraftValue IS NOT NULL AND A.IndicateChange = 'yes' THEN E.LiveValue
           ELSE ''
      END) AS [TickerTableBodyRow!2!epsFY2],
  ''                     AS [TickerTableBodyRow!2!isBoldEpsFY2],

  -- Valuations
  ''                     AS [TickerTableBodyRow!2!valType],
  ''                     AS [TickerTableBodyRow!2!valFY0],
  ''                     AS [TickerTableBodyRow!2!isBoldValFY0],
  ''                     AS [TickerTableBodyRow!2!valFY1],
  ''                     AS [TickerTableBodyRow!2!isBoldValFY1],
  ''                     AS [TickerTableBodyRow!2!valFY2],
  ''                     AS [TickerTableBodyRow!2!valFY0],

  -- isBold attribute - when draft and live value exists
  MAX(A.Company)               AS [TickerTableBodyRow!2!company],
  2                            AS [TickerTableBodyRow!2!dispOrder],
  MAX(A.DisplayNo)             AS [TickerTableBodyRow!2!displayNo]
FROM #TmpAnalystDataDraftLive A
LEFT JOIN #TmpEpsEstimatesDraftLive E ON E.SecurityId = A.SecurityId
LEFT JOIN #TmpValuationsDraftLive V ON V.SecurityId = A.SecurityId
LEFT JOIN #TmpFxRates F ON F.SecurityId = A.SecurityId
WHERE A.IndicateChange = 'yes'
-- Show old row only if draft and live row both exists - analyst rating/TP/estimate data
-- Launch call - will have draft and no live data
AND
(  (A.DraftValue IS NOT NULL AND A.LiveValue IS NOT NULL)
    OR
   (E.DraftValue IS NOT NULL AND E.LiveValue IS NOT NULL)
)

GROUP BY A.SecurityId, E.SecurityId

) X
ORDER BY [TickerTableBodyRow!2!displayNo], [TickerTableBodyRow!2!dispOrder]
FOR XML Explicit
)

-- For v1(IndicateChange=no,yes), use the latest FinancialNumbers data - applicable for ticker table UI screens or from word template
IF @RptPubNo = 0 AND NOT EXISTS(SELECT * FROM #TickerList WHERE IndicateChange = 'last')
BEGIN
  SELECT @FinancialsXml
  RETURN
END

-- Get the PublicationsXml - lastRpt PubNo
SELECT @PublicationsXml = TickerTableXml FROM PublicationsXML  WHERE PubNo = @RptPubNo

-- Add column to store the Ticker Table XML for tickers with indicateChange="last" [lastChangePubNo]
ALTER TABLE #TickerList ADD LastChangeTickerTableXml XML

-- Update Ticker Table XML for tickers with indicateChange="last"
UPDATE #TickerList
SET #TickerList.LastChangeTickerTableXml = PX2.TickerTableXml
FROM PublicationsXML PX2
WHERE PX2.PubNo = #TickerList.LastChangePubNo

-- Selectively fetch applicable rows (by ticker, old/new row) from one of the 3 xml sources
-- use displayNo from the provided ticker list, not from old PubXml
-- Source: @FinancialsXml
SELECT
  CONVERT(varchar(MAX),F.Loc.query('.')) AS result,
  TL.DisplayNo  AS displayNo,
  F.Loc.value('./@dispOrder',     'INT') AS dispOrder,
  F.Loc.value('./@ticker',        'VARCHAR(MAX)') AS ticker,
  F.Loc.value('./@securityId',    'INT') AS securityId,
  TL.SourceLive, TL.SourceOld
INTO #TickerTableXml
FROM #TickerList TL
JOIN @FinancialsXml.nodes('/TickerTableBody/TickerTableBodyRow') F(Loc)
     ON TL.SecurityId = CAST(F.Loc.value('@securityId', 'INT') AS INT)
WHERE (TL.SourceLive = 'FN' AND CAST(F.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) != 'OLD')
       OR
      (TL.SourceOld = 'FN'  AND
       CAST(F.Loc.value('@securityId', 'INT') AS INT) = TL.SecurityId AND
       CAST(F.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) = 'OLD')

UNION

-- Source: @PublicationsXml for last published report
SELECT
  CONVERT(varchar(MAX),P.Loc.query('.')) AS result,
  TL.DisplayNo  AS displayNo,
  P.Loc.value('./@dispOrder',     'INT') AS dispOrder,
  P.Loc.value('./@ticker',        'VARCHAR(MAX)') AS ticker,
  P.Loc.value('./@securityId',    'INT') AS securityId,
  TL.SourceLive, TL.SourceOld
FROM #TickerList TL
JOIN @PublicationsXml.nodes('/TickerTable/TickerTableBody/TickerTableBodyRow') P(Loc)
     ON TL.SecurityId = CAST(P.Loc.value('@securityId', 'INT') AS INT)
WHERE (TL.SourceLive = 'PX' AND CAST(P.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) != 'OLD')
       OR
      (TL.SourceOld = 'PX' AND
       CAST(P.Loc.value('@securityId', 'INT') AS INT) = TL.SecurityId AND
       CAST(P.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) = 'OLD')

UNION

-- Source: @PublicationsXml for last change report (last n days)
SELECT
  CONVERT(varchar(MAX),P2.Loc.query('.')) AS result,
  TL.DisplayNo  AS displayNo,
  P2.Loc.value('./@dispOrder',     'INT') AS dispOrder,
  P2.Loc.value('./@ticker',        'VARCHAR(MAX)') AS ticker,
  P2.Loc.value('./@securityId',    'INT') AS securityId,
  TL.SourceLive, TL.SourceOld
FROM #TickerList TL
CROSS APPLY TL.LastChangeTickerTableXml.nodes('/TickerTable/TickerTableBody/TickerTableBodyRow') AS P2(Loc)
WHERE TL.SecurityId = CAST(P2.Loc.value('@securityId', 'INT') AS INT)
AND (TL.SourceLive = 'PXLAST' AND CAST(P2.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) != 'OLD')
     OR
   (TL.SourceOld = 'PXLAST'  AND
    CAST(P2.Loc.value('@securityId', 'INT') AS INT) = TL.SecurityId AND
    CAST(P2.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) = 'OLD')
ORDER BY 2, 5, 3

-- Combine individual ticker rows as one string
SELECT @TickerTableXml = STUFF(
                        (SELECT CHAR(13) + result
                           FROM #TickerTableXml
                            FOR XML PATH(''),type).value('.','NVARCHAR(MAX)'),1,1,'')
SELECT @TickerTableXml = '<TickerTableBody>' + CHAR(13) + @TickerTableXml + CHAR(13) + '</TickerTableBody>'
SELECT CAST(@TickerTableXml AS XML)

DROP TABLE #TickerList

SET NOCOUNT OFF



GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetEstimatesTickerTableXml]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spGetEstimatesTickerTableXml]
GO

-- DEBUG

/*
EXEC spGetTickerTableApiXml
'<DocumentInfo>
<DocumentSection title="American Express" perfType="TTM" valType="P/E Reported" epsType="EPS Reported"/>
<Securities>
<Security optLastPubNo="" optLastFlags="" optYesFlags="" optLastEnabled="N" optNoEnabled="Y" optYesEnabled="N" indicateChange="no" analyst="St. Pierre" tickerSheetId="" coverageId="1736" companyId="71" id="59" ticker="AXP"/>
<Security optLastPubNo="" optLastFlags="" optYesFlags="" optLastEnabled="N" optNoEnabled="Y" optYesEnabled="N" indicateChange="no" analyst="St. Pierre" tickerSheetId="" coverageId="1713" companyId="299" id="1667" ticker="CFG"/>
<Security optLastPubNo="" optLastFlags="" optYesFlags="" optLastEnabled="N" optNoEnabled="Y" optYesEnabled="N" indicateChange="no" analyst="St. Pierre" tickerSheetId="" coverageId="390" companyId="323" id="838" ticker="CMA"/>
</Securities>
</DocumentInfo>'
GO
*/