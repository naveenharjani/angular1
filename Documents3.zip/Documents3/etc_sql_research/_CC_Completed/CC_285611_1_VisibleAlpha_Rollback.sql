
-- CC_VisibleAlpha_Rollback.sql
-- 05/14/2018

/*

See DistributionPDU.sql to create Visible Alpha adapter

create IX_DistributionEntitlements_SiteId_ProductGroupId
alter spAddDistributionItem
create spGetAdapterVisibleAlpha

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO
if exists(select * from sys.columns where object_id = object_id('DistributionSites') and name = 'LinkBack')
begin
  alter table DistributionSites
  drop column LinkBack, LinkSourceId, SiteType
end

alter table DistributionSites
alter column FtpPassword varchar(16)

alter table DistributionSites
alter column FtpFolder varchar(48)

alter table DistributionSites
alter column ScbFolder varchar(48)
go

if not exists(select name from sys.indexes where name like '%IX_DistributionEntitlements_SiteId_ProductGroupId%')
begin
ALTER TABLE [dbo].[DistributionEntitlements] ADD  CONSTRAINT [IX_DistributionEntitlements_SiteId_ProductGroupId] UNIQUE NONCLUSTERED
(
  [SiteId] ASC,
  [ProductGroupId] ASC
)
end
go

ALTER PROCEDURE dbo.spAddDistributionItem
  @PubNo         int,
  @SiteId        int,
  @Operation     char(1) -- C (Contribute) or D (Delete)
AS
DECLARE @Scheduled      datetime
DECLARE @CurrentSiteId  int
DECLARE @Exception      smallint
DECLARE @Now            datetime
DECLARE @Published      datetime
DECLARE @PublicationTypeId int

-- 10/20/2016 switched Approved column from ApprovedDate to PublishedDate
SELECT @Published = PublishedDate,@PublicationTypeId = PublicationTypeId
FROM Publications P JOIN PublicationTypes PT ON P.Type = PT.PublicationType
WHERE PubNo = @PubNo

SELECT @Now = GETDATE()
SELECT SiteId INTO #Tmp_Sites FROM DistributionSubscriptions WHERE 1 = 2
IF @Operation = 'C'
BEGIN

-- Customized subscriptions
-- 04/24/2014 - Daiwa Bloomberg subscription limited to Pan-Euro product group, i.e. ProductGroupId = 2
-- 10/19/2016 - McKinsey subscription limited to McKinsey product group, i.e. ProductGroupId = 13

-- PASS 1 - Identify eligible sites
  IF @SiteId = 0
  -- All sites
  BEGIN
    --Standard subscriptions - Excluding custom subscriptions, e.g. Daiwa, McKinsey
    INSERT INTO #Tmp_Sites
    SELECT SS.SiteId FROM DistributionSubscriptions SS JOIN DistributionSites S ON SS.SiteId = S.SiteId WHERE S.Active = -1 AND SS.Active = -1 AND S.Site NOT LIKE '%Daiwa%' AND S.Site NOT LIKE '%McKinsey%' AND PublicationTypeId = @PublicationTypeId ORDER 
BY SS.SiteId

    --Custom subscriptions
    --Daiwa - Only when document in Pan-Euro product group
    IF EXISTS(SELECT * FROM ProductGroupDocuments WHERE PubNo = @PubNo AND ProductGroupId = 2)
    BEGIN
      INSERT INTO #Tmp_Sites
      SELECT SS.SiteId FROM DistributionSubscriptions SS JOIN DistributionSites S ON SS.SiteId = S.SiteId WHERE S.Active = -1 AND SS.Active = -1 AND S.Site LIKE '%Daiwa%' AND PublicationTypeId = @PublicationTypeId ORDER BY SS.SiteId
    END
    --McKinsey - Only when document in McKinsey product group
    IF EXISTS(SELECT * FROM ProductGroupDocuments WHERE PubNo = @PubNo AND ProductGroupId = 13)
    BEGIN
      INSERT INTO #Tmp_Sites
      SELECT SS.SiteId FROM DistributionSubscriptions SS JOIN DistributionSites S ON SS.SiteId = S.SiteId WHERE S.Active = -1 AND SS.Active = -1 AND S.Site LIKE '%McKinsey%' AND PublicationTypeId = @PublicationTypeId ORDER BY SS.SiteId
    END
  END
  ELSE
  -- One site
  BEGIN
    --Standard subscriptions - Excluding custom subscriptions, e.g. Daiwa, McKinsey
    IF ((SELECT Site FROM DistributionSites WHERE SiteId = @SiteId) NOT LIKE '%Daiwa%' AND
        (SELECT Site FROM DistributionSites WHERE SiteId = @SiteId) NOT LIKE '%McKinsey%')
    BEGIN
      INSERT INTO #Tmp_Sites
      SELECT SS.SiteId FROM DistributionSubscriptions SS JOIN DistributionSites S ON SS.SiteId = S.SiteId WHERE S.Active = -1 AND SS.Active = -1 AND PublicationTypeId = @PublicationTypeId AND SS.SiteId = @SiteId ORDER BY SS.SiteId
    END

    --Custom subscriptions
    --Daiwa - Only when document in Pan-Euro product group
    IF EXISTS(SELECT * FROM ProductGroupDocuments WHERE PubNo = @PubNo AND ProductGroupId = 2) AND (SELECT Site FROM DistributionSites WHERE SiteId = @SiteId) LIKE '%Daiwa%'
    BEGIN
      INSERT INTO #Tmp_Sites
      SELECT SS.SiteId FROM DistributionSubscriptions SS JOIN DistributionSites S ON SS.SiteId = S.SiteId WHERE S.Active = -1 AND SS.Active = -1 AND S.Site LIKE '%Daiwa%' AND PublicationTypeId = @PublicationTypeId ORDER BY SS.SiteId
    END
    --McKinsey - Only when document in McKinsey product group
    IF EXISTS(SELECT * FROM ProductGroupDocuments WHERE PubNo = @PubNo AND ProductGroupId = 13) AND (SELECT Site FROM DistributionSites WHERE SiteId = @SiteId) LIKE '%McKinsey%'
    BEGIN
      INSERT INTO #Tmp_Sites
      SELECT SS.SiteId FROM DistributionSubscriptions SS JOIN DistributionSites S ON SS.SiteId = S.SiteId WHERE S.Active = -1 AND SS.Active = -1 AND S.Site LIKE '%McKinsey%' AND PublicationTypeId = @PublicationTypeId ORDER BY SS.SiteId
    END
  END
END

IF @Operation = 'D'
BEGIN
  IF @SiteId = 0
  BEGIN
    INSERT INTO #Tmp_Sites
    SELECT S.SiteId FROM DistributionSites S JOIN DistributionQueue DQ ON S.SiteId = DQ.SiteId WHERE Pubno= @Pubno ORDER BY S.SiteId
  END
  ELSE
  BEGIN
    INSERT INTO #Tmp_Sites
    SELECT S.SiteId FROM DistributionSites S JOIN DistributionQueue DQ ON S.SiteId = DQ.SiteId WHERE Pubno= @Pubno AND S.SiteId = @SiteId ORDER BY S.SiteId
  END
END

-- PASS 2 - Distribute to eligible sites
SELECT TOP 1 @CurrentSiteId = SiteId from #Tmp_Sites ORDER BY SiteId
WHILE @@ROWCOUNT > 0
BEGIN

  UPDATE DistributionQueue  SET Cancelled = @Now
  WHERE PubNo = @PubNo AND SiteId = @CurrentSiteId AND Operation = 'C' AND Transferred IS NULL AND Cancelled IS NULL

  IF @Operation = 'C'
  BEGIN
    EXEC spGetException @CurrentSiteId, @PubNo, @Exception OUTPUT
    IF @Exception = 0
      BEGIN
        EXEC spGetScheduledTime @CurrentSiteId, @PubNo, @Scheduled OUTPUT
        INSERT INTO DistributionQueue (SiteId, PubNo, Operation, Approved, Received, Scheduled, IsException)
        VALUES (@CurrentSiteId, @PubNo, @Operation, @Published, @Now, @Scheduled, 0)
      END
  END
  IF @Operation = 'D'
  BEGIN
    IF EXISTS
      (
       SELECT * FROM DistributionQueue WITH (NOLOCK) WHERE Transferred IS NOT NULL
       AND DistributionID = (SELECT MAX(DistributionID) FROM DistributionQueue WITH (NOLOCK) WHERE PubNo = @PubNo AND SiteId = @CurrentSiteId)
      )
      BEGIN
        SELECT TOP 1 @Published = Approved FROM DistributionQueue WITH (NOLOCK) WHERE PubNo = @PubNo ORDER BY DistributionId desc
        INSERT INTO DistributionQueue (SiteId, PubNo, Operation, Approved, Received, Scheduled, IsException)
        VALUES (@CurrentSiteId, @PubNo, @Operation, @Published, @Now, @Now, 0)
      END
  END
  SELECT TOP 1 @CurrentSiteId = SiteId FROM #Tmp_Sites WHERE SiteId > @CurrentSiteId ORDER BY SiteId
END


GO
IF EXISTS(SELECT * FROM Sys.Objects WHERE type = 'P' and name = 'spGetAdapterVisibleAlpha')
DROP PROC dbo.spGetAdapterVisibleAlpha
GO
