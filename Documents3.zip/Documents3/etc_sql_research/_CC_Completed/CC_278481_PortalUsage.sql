-- PortalUsage.sql
-- 04/09/2017

/*

PortalUsageStaging_RSRCHX
spResetPortalUsageStaging_RSRCHX
spLoadPortalUsageFromStaging_RSRCHX

PortalUsageStaging_RedDeer
spResetPortalUsageStaging_RedDeer
spLoadPortalUsageFromStaging_RedDeer

alter spGetPortals -- used by UI

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_RSRCHX]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_RSRCHX]
GO

CREATE TABLE [dbo].[PortalUsageStaging_RSRCHX]
(
  [Client Org Firm Name] [varchar](500) NULL,
  [Department] [varchar](500) NULL,
  [Forename] [varchar](500) NULL,
  [Surname] [varchar](500) NULL,
  [Email] [varchar](500) NULL,
  [Country] [varchar](500) NULL,
  [Action Type] [varchar](500) NULL,
  [Action ID] [varchar](500) NULL,
  [Action Date (UTC)] [varchar](500) NULL,
  [Action Time (UTC)] [varchar](500) NULL,
  [Report Identifier] [varchar](500) NULL,
  [Report Title] [varchar](500) NULL
) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_RedDeer]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_RedDeer]
GO

CREATE TABLE [dbo].[PortalUsageStaging_RedDeer]
(
  [Client_ID *] [varchar](500) NULL,
  [Client_Name] [varchar](500) NULL,
  [Client_Type] [varchar](500) NULL,
  [User_ID **] [varchar](500) NULL,
  [User_Name] [varchar](500) NULL,
  [User_Business_Email] [varchar](500) NULL,
  [User_Country] [varchar](500) NULL,
  [User_Status] [varchar](500) NULL,
  [Red Deer_Transaction_ID ***] [varchar](500) NULL,
  [Vendor_Doc_ID ****] [varchar](500) NULL,
  [Read_Date] [varchar](500) NULL,
  [Read_Count] [varchar](500) NULL,
  [User_Sub_Start_Date] [varchar](500) NULL,
  [User_Sub_End_Date] [varchar](500) NULL,
) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_RSRCHX]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spResetPortalUsageStaging_RSRCHX]
GO

CREATE PROCEDURE [dbo].[spResetPortalUsageStaging_RSRCHX]
AS
BEGIN
SET NOCOUNT ON

DECLARE @RowsDeleted INT

DELETE FROM [dbo].[PortalUsageStaging_RSRCHX]
SET @RowsDeleted = @@ROWCOUNT
SELECT @RowsDeleted

SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_RedDeer]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spResetPortalUsageStaging_RedDeer]
GO

CREATE PROCEDURE [dbo].[spResetPortalUsageStaging_RedDeer]
AS
BEGIN
SET NOCOUNT ON

DECLARE @RowsDeleted INT

DELETE FROM [dbo].[PortalUsageStaging_RedDeer]
SET @RowsDeleted = @@ROWCOUNT
SELECT @RowsDeleted

SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_RSRCHX]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RSRCHX]
GO

CREATE PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RSRCHX]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 22 -- RSRCHXchange

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RSRCHX) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_RSRCHX STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Action Date (UTC)])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Action Date (UTC)])
   AND DAY(PU.ReadDate) = DAY(STG.[Action Date (UTC)])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, Delivery)
SELECT
  [Report Identifier],
  [Action Date (UTC)],   -- 'read time' component not needed
  @SiteId,
  [Email],
  [Surname] + ', ' + [Forename],
  NULL,
  [Client Org Firm Name],
  NULL,
  NULL
FROM [dbo].[PortalUsageStaging_RSRCHX]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Action Date (UTC)] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Action Date (UTC)] AS DATE) ), 101)
FROM [PortalUsageStaging_RSRCHX]
WHERE ISDATE([Action Date (UTC)]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for RSRCHXchange from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_RedDeer]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RedDeer]
GO

CREATE PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RedDeer]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 23 -- RedDeer

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RedDeer) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_RedDeer STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read_Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read_Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read_Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, Delivery)
SELECT
  [Vendor_Doc_ID ****],
  [Read_Date],
  23,
  [User_Business_Email],
  [User_Name],
  [User_ID **],
  [Client_Name],
  [Client_ID *],
  NULL
FROM [dbo].[PortalUsageStaging_RedDeer]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read_Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read_Date] AS DATE) ), 101)
FROM [PortalUsageStaging_RedDeer]
WHERE ISDATE([Read_Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Red Deer from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO

ALTER PROCEDURE [dbo].[spGetPortals]
AS

SELECT SiteId, Site FROM DistributionSites WHERE SiteId IN (3, 9, 11, 12, 20, 22, 23)

GO

-- User 'DE_IIS' - Grant bulk inserts from SSIS packages
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_RSRCHX]   TO  DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_RedDeer]   TO  DE_IIS
GO

GRANT EXECUTE ON [dbo].[spResetPortalUsageStaging_RSRCHX]      TO  DE_IIS, PowerUsers
GRANT EXECUTE ON [dbo].[spResetPortalUsageStaging_RedDeer]     TO  DE_IIS, PowerUsers
GRANT EXECUTE ON [dbo].[spLoadPortalUsageFromStaging_RSRCHX]   TO  DE_IIS, PowerUsers
GRANT EXECUTE ON [dbo].[spLoadPortalUsageFromStaging_RedDeer]  TO  DE_IIS, PowerUsers
GO

/*
-- RSRCHX [22]
EXEC [spResetPortalUsageStaging_RSRCHX]
EXEC [spLoadPortalUsageFromStaging_RSRCHX]

SELECT * FROM [PortalUsageStaging_RSRCHX] ORDER BY CAST([Action Date (UTC)] AS DATETIME) desc
SELECT * FROM PortalUsage WHERE SiteId = 22 ORDER BY UsageId DESC
DELETE FROM PortalUsage WHERE SiteId = 22

-- Red Deer [23]
EXEC [spResetPortalUsageStaging_RedDeer]
EXEC [spLoadPortalUsageFromStaging_RedDeer]

SELECT * FROM [PortalUsageStaging_RedDeer] ORDER BY CAST([Read_Date] AS DATETIME) desc
SELECT * FROM PortalUsage Where SiteId = 23 ORDER BY ReadDate DESC -- Red Deer
DELETE FROM PortalUsage WHERE SiteId = 23

EXEC [spGetPortals]
EXEC [spGetPortalUsageLoadHistory] 23
*/
