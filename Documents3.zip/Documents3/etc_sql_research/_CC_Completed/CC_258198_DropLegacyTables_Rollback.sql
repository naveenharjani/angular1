-- DropLegacyTables_Rollback.sql
-- 08/03/2017

/*

After the Flip Database Views to Estimates db is successful,
Step III - Drop Legacy Tables used by old Publishing engine in TTS schema

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*
Fix sql in sqlxml folders before dropping tables
SQL								Dependent Tables                                           Action
_researchcoverage.sql           MigratedAnalysts, epstypes, metrictypes, analystsettings   Fix
_estimates.sql                  BenchmarkEstimates                                         Drop - Not needed
*/

/*
Check again for any sql object dependency on the legacy tables
found if any, drop the dependent objects

-- Objects dependent on these tables
SELECT * FROM sys.objects where object_id in (SELECT referencing_id FROM sys.sql_expression_dependencies
WHERE referenced_id = OBJECT_ID(N'TickerTableSecurities') OR
      referenced_id = OBJECT_ID(N'TickerTableSecuritiesOld') OR
      referenced_id = OBJECT_ID(N'TickerTableSecurities_Backup') OR
      referenced_id = OBJECT_ID(N'TickerTables') OR
      referenced_id = OBJECT_ID(N'TickerSheetSecurities') OR
      referenced_id = OBJECT_ID(N'TickerSheetSecurities_backup') OR
      referenced_id = OBJECT_ID(N'TickerSheets') OR
      referenced_id = OBJECT_ID(N'Footnotes') OR
      referenced_id = OBJECT_ID(N'FootnotesRef') OR
      referenced_id = OBJECT_ID(N'AnalystSettings') OR
      referenced_id = OBJECT_ID(N'AnalystSettingsLog') OR
      referenced_id = OBJECT_ID(N'BenchmarkEstimates') OR
      referenced_id = OBJECT_ID(N'BenchmarkEstimatesLog') OR
      referenced_id = OBJECT_ID(N'EpsTypes') OR
      referenced_id = OBJECT_ID(N'MetricsTypes') OR
      referenced_id = OBJECT_ID(N'EstimatesPeriods') OR
      referenced_id = OBJECT_ID(N'MigratedAnalysts')
) ORDER BY 1
*/

/*
-- Drop tables used by old UI or legacy publishing engine or new estimates not anymore

View Table dependencies Drop Tables in the listed order, as per the table dependencies

EstimatesPeriods, EpsTypes, MetricsTypes
TickerSheetData, -- remains
TickerSheetSecurities, TickerSheets
FootnoteRefs, Footnotes, TickerTableSecuritiesOld, TickerTableSecurities, TickerTables
BenchmarkEstimates, BenchmarkEstimatesLog
AnalystSettings, AnalystSettingsLog
MigratedAnalysts

-- delete old backup tables
TickerTableSecurities_Backup, TickerSheetSecurities_backup

*/

/* EstimatesPeriods, EpsTypes, MetricsTypes */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EstimatesPeriods]') AND type in (N'U'))
DROP TABLE [dbo].[EstimatesPeriods]
GO
CREATE TABLE [dbo].[EstimatesPeriods](
	[EstimatePeriodId] [int] IDENTITY(1,1) NOT NULL,
	[EstimatePeriod] [varchar](50) NOT NULL,
	[EstimatePeriodDisplay] [varchar](10) NOT NULL,
	[Active] [int] NOT NULL,
	[EditorId] [int] NOT NULL,
	[EditDate] [datetime] NOT NULL,
 CONSTRAINT [PK_EstimatesPeriods] PRIMARY KEY CLUSTERED 
(
	[EstimatePeriodId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EpsTypes]') AND type in (N'U'))
DROP TABLE [dbo].[EpsTypes]
GO
CREATE TABLE [dbo].[EpsTypes](
	[EpsTypeId] [int] IDENTITY(1,1) NOT NULL,
	[EpsType] [varchar](10) NOT NULL,
 CONSTRAINT [PK_EpsTypes] PRIMARY KEY CLUSTERED 
(
	[EpsTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MetricsTypes]') AND type in (N'U'))
DROP TABLE [dbo].[MetricsTypes]
GO
CREATE TABLE [dbo].[MetricsTypes](
	[MetricsTypeId] [int] IDENTITY(1,1) NOT NULL,
	[MetricsType] [varchar](10) NOT NULL,
 CONSTRAINT [PK_MetricsTypes] PRIMARY KEY CLUSTERED 
(
	[MetricsTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO


/* TickerSheetData, TickerSheetSecurities, TickerSheets */
/*
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerSheetData]') AND type in (N'U'))
DROP TABLE [dbo].[TickerSheetData]
GO
CREATE TABLE [dbo].[TickerSheetData](
	[TickerSheetId] [int] IDENTITY(1,1) NOT NULL,
	[SecurityId] [int] NOT NULL,
	[PubNo] [int] NULL,
	[TickerSheetSubmitXml] [xml] NOT NULL,
	[EditorId] [int] NOT NULL,
	[EditDate] [datetime] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerSheets]') AND type in (N'U'))
DROP TABLE [dbo].[TickerSheets]
GO
CREATE TABLE [dbo].[TickerSheets](
	[TickerSheetId] [int] IDENTITY(1,1) NOT NULL,
	[EditorId] [int] NOT NULL,
	[EditDate] [datetime] NOT NULL,
 CONSTRAINT [PK_TickerSheets] PRIMARY KEY CLUSTERED 
(
	[TickerSheetId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerSheetSecurities]') AND type in (N'U'))
DROP TABLE [dbo].[TickerSheetSecurities]
GO
CREATE TABLE [dbo].[TickerSheetSecurities](
	[TickerSheetId] [int] NOT NULL,
	[SecurityId] [int] NOT NULL,
	[Security] [varchar](10) NOT NULL,
	[Xml] [xml] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
ALTER TABLE [dbo].[TickerSheetSecurities] ADD  DEFAULT ('<Security />') FOR [Xml]
GO
ALTER TABLE [dbo].[TickerSheetSecurities]  WITH CHECK ADD  CONSTRAINT [FK_TickerSheetSecurities_TickerSheets] FOREIGN KEY([TickerSheetId])
REFERENCES [dbo].[TickerSheets] ([TickerSheetId])
GO
ALTER TABLE [dbo].[TickerSheetSecurities] CHECK CONSTRAINT [FK_TickerSheetSecurities_TickerSheets]
GO




/* FootnoteRefs, Footnotes, TickerTableSecuritiesOld, TickerTableSecurities, TickerTables */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerTables]') AND type in (N'U'))
DROP TABLE [dbo].[TickerTables]
GO

CREATE TABLE [dbo].[TickerTables](
	[PubNo] [int] NOT NULL,
	[EPSType] [varchar](50) NULL,
	[MetricType] [varchar](50) NULL,
	[DisplayCloseDate] [varchar](12) NULL,
	[LastYear] [varchar](5) NOT NULL,
	[ThisYear] [varchar](5) NOT NULL,
	[NextYear] [varchar](5) NOT NULL,
	[RelPerfType] [varchar](10) NOT NULL,
 CONSTRAINT [PK_TickerTables] PRIMARY KEY CLUSTERED 
(
	[PubNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FootnoteRefs]') AND type in (N'U'))
DROP TABLE [dbo].[FootnoteRefs]
GO

CREATE TABLE [dbo].[FootnoteRefs](
	[PubNo] [int] NOT NULL,
	[FootNoteRef] [varchar](50) NOT NULL
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[FootnoteRefs]  WITH NOCHECK ADD  CONSTRAINT [FK_FootnoteRefs_TickerTables] FOREIGN KEY([PubNo])
REFERENCES [dbo].[TickerTables] ([PubNo])
GO
ALTER TABLE [dbo].[FootnoteRefs] CHECK CONSTRAINT [FK_FootnoteRefs_TickerTables]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Footnotes]') AND type in (N'U'))
DROP TABLE [dbo].[Footnotes]
GO

CREATE TABLE [dbo].[Footnotes](
	[PubNo] [int] NOT NULL,
	[FootNoteText] [varchar](2048) NOT NULL
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[Footnotes]  WITH NOCHECK ADD  CONSTRAINT [FK_Footnotes_TickerTables] FOREIGN KEY([PubNo])
REFERENCES [dbo].[TickerTables] ([PubNo])
GO
ALTER TABLE [dbo].[Footnotes] CHECK CONSTRAINT [FK_Footnotes_TickerTables]
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerTableSecuritiesOld]') AND type in (N'U'))
DROP TABLE [dbo].[TickerTableSecuritiesOld]
GO
CREATE TABLE [dbo].[TickerTableSecuritiesOld](
	[PubNo] [int] NOT NULL,
	[Ticker] [varchar](10) NOT NULL,
	[Rating] [char](1) NULL,
	[TargetPrice] [varchar](10) NULL,
	[EPSThisYear] [varchar](10) NULL,
	[EPSNextYear] [varchar](10) NULL,
	[TargetPriceOrig] [varchar](10) NULL
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[TickerTableSecuritiesOld]  WITH NOCHECK ADD  CONSTRAINT [FK_TickerTableSecuritiesOld_TickerTables] FOREIGN KEY([PubNo])
REFERENCES [dbo].[TickerTables] ([PubNo])
GO
ALTER TABLE [dbo].[TickerTableSecuritiesOld] CHECK CONSTRAINT [FK_TickerTableSecuritiesOld_TickerTables]
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerTableSecurities]') AND type in (N'U'))
DROP TABLE [dbo].[TickerTableSecurities]
GO

CREATE TABLE [dbo].[TickerTableSecurities](
	[PubNo] [int] NOT NULL,
	[Ticker] [varchar](10) NOT NULL,
	[Rating] [char](1) NOT NULL,
	[Currency] [char](3) NOT NULL,
	[CloseDate] [datetime] NULL,
	[ClosePrice] [varchar](10) NOT NULL,
	[TargetPrice] [varchar](10) NOT NULL,
	[YTDRelPerf] [varchar](10) NOT NULL,
	[EPSLastYear] [varchar](10) NOT NULL,
	[EPSThisYear] [varchar](10) NOT NULL,
	[EPSNextYear] [varchar](10) NOT NULL,
	[MetricLastYear] [varchar](10) NOT NULL,
	[MetricThisYear] [varchar](10) NOT NULL,
	[MetricNextYear] [varchar](10) NOT NULL,
	[Yield] [varchar](10) NOT NULL,
	[TickerOrder] [int] NOT NULL,
	[TargetPriceOrig] [varchar](10) NULL,
	[CoverageId] [int] NULL,
	[CoverageAction] [varchar](10) NULL,
	[RatingAction] [varchar](10) NULL,
	[TargetPriceAction] [varchar](10) NULL,
	[EstimateAction] [varchar](10) NULL,
	[EstimateNextYearAction] [varchar](10) NULL
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[TickerTableSecurities]  WITH NOCHECK ADD  CONSTRAINT [FK_TickerTableSecurities_TickerTables] FOREIGN KEY([PubNo])
REFERENCES [dbo].[TickerTables] ([PubNo])
GO
ALTER TABLE [dbo].[TickerTableSecurities] CHECK CONSTRAINT [FK_TickerTableSecurities_TickerTables]
GO





/* BenchmarkEstimates, BenchmarkEstimatesLog */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BenchmarkEstimates]') AND type in (N'U'))
DROP TABLE [dbo].[BenchmarkEstimates]
GO
CREATE TABLE [dbo].[BenchmarkEstimates](
	[BenchmarkEstimateId] [int] IDENTITY(1,1) NOT NULL,
	[BenchmarkIndex] [varchar](10) NOT NULL,
	[EffectiveDate] [datetime] NOT NULL,
	[EstimatePeriodId] [int] NOT NULL,
	[PriorYear2] [decimal](10, 2) NULL,
	[PriorYear] [decimal](10, 2) NOT NULL,
	[CurrentYear] [decimal](10, 2) NOT NULL,
	[NextYear] [decimal](10, 2) NOT NULL,
	[NextYear2] [decimal](10, 2) NULL,
	[DividendYield] [decimal](10, 2) NULL,
	[EditorId] [int] NOT NULL,
	[EditDate] [datetime] NOT NULL,
 CONSTRAINT [IX_BenchmarkEstimates_BenchmarkIndexEffectiveDate] UNIQUE NONCLUSTERED 
(
	[BenchmarkIndex] ASC,
	[EffectiveDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[BenchmarkEstimates]  WITH CHECK ADD  CONSTRAINT [FK_BenchmarkEstimates_EstimatePeriods] FOREIGN KEY([EstimatePeriodId])
REFERENCES [dbo].[EstimatesPeriods] ([EstimatePeriodId])
GO
ALTER TABLE [dbo].[BenchmarkEstimates] CHECK CONSTRAINT [FK_BenchmarkEstimates_EstimatePeriods]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BenchmarkEstimatesLog]') AND type in (N'U'))
DROP TABLE [dbo].[BenchmarkEstimatesLog]
GO
CREATE TABLE [dbo].[BenchmarkEstimatesLog](
	[LogId] [int] IDENTITY(1,1) NOT NULL,
	[Operation] [varchar](1) NOT NULL,
	[BenchmarkIndexNew] [varchar](10) NOT NULL,
	[BenchmarkIndexOld] [varchar](10) NULL,
	[EffectiveDateNew] [datetime] NOT NULL,
	[EffectiveDateOld] [datetime] NULL,
	[EstimatePeriodIdNew] [int] NOT NULL,
	[EstimatePeriodIdOld] [int] NULL,
	[PriorYear2New] [decimal](10, 2) NOT NULL,
	[PriorYear2Old] [decimal](10, 2) NULL,
	[PriorYearNew] [decimal](10, 2) NOT NULL,
	[PriorYearOld] [decimal](10, 2) NULL,
	[CurrentYearNew] [decimal](10, 2) NOT NULL,
	[CurrentYearOld] [decimal](10, 2) NULL,
	[NextYearNew] [decimal](10, 2) NULL,
	[NextYearOld] [decimal](10, 2) NULL,
	[NextYear2New] [decimal](10, 2) NULL,
	[NextYear2Old] [decimal](10, 2) NULL,
	[DividendYieldNew] [decimal](10, 2) NULL,
	[DividendYieldOld] [decimal](10, 2) NULL,
	[EditorId] [int] NOT NULL,
	[EditDate] [datetime] NOT NULL
) ON [PRIMARY]

GO

/* AnalystSettings, AnalystSettingsLog */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AnalystSettings]') AND type in (N'U'))
DROP TABLE [dbo].[AnalystSettings]
GO

CREATE TABLE [dbo].[AnalystSettings](
	[CoverageId] [int] NOT NULL,
	[EpsTypeId] [int] NOT NULL,
	[MetricsTypeId] [int] NOT NULL,
	[EstimatePeriodId] [int] NOT NULL,
	[EditorId] [int] NOT NULL,
	[EditDate] [datetime] NOT NULL,
 CONSTRAINT [PK_AnalystSettings] PRIMARY KEY CLUSTERED 
(
	[CoverageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[AnalystSettings]  WITH CHECK ADD  CONSTRAINT [FK_AnalystSettings_EpsTypes] FOREIGN KEY([EpsTypeId])
REFERENCES [dbo].[EpsTypes] ([EpsTypeId])
GO
ALTER TABLE [dbo].[AnalystSettings] CHECK CONSTRAINT [FK_AnalystSettings_EpsTypes]
GO
ALTER TABLE [dbo].[AnalystSettings]  WITH CHECK ADD  CONSTRAINT [FK_AnalystSettings_EstimatePeriods] FOREIGN KEY([EstimatePeriodId])
REFERENCES [dbo].[EstimatesPeriods] ([EstimatePeriodId])
GO
ALTER TABLE [dbo].[AnalystSettings] CHECK CONSTRAINT [FK_AnalystSettings_EstimatePeriods]
GO
ALTER TABLE [dbo].[AnalystSettings]  WITH CHECK ADD  CONSTRAINT [FK_AnalystSettings_MetricsTypes] FOREIGN KEY([MetricsTypeId])
REFERENCES [dbo].[MetricsTypes] ([MetricsTypeId])
GO
ALTER TABLE [dbo].[AnalystSettings] CHECK CONSTRAINT [FK_AnalystSettings_MetricsTypes]
GO
-- Drop AnalystId key constraint with ResearchCoverage table
ALTER TABLE [dbo].[AnalystSettings]  WITH CHECK ADD  CONSTRAINT [FK_AnalystSettings_ResearchCoverage] FOREIGN KEY([CoverageId])
REFERENCES [dbo].[ResearchCoverage] ([CoverageID])
GO
ALTER TABLE [dbo].[AnalystSettings] CHECK CONSTRAINT [FK_AnalystSettings_ResearchCoverage]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AnalystSettingsLog]') AND type in (N'U'))
DROP TABLE [dbo].[AnalystSettingsLog]
GO

CREATE TABLE [dbo].[AnalystSettingsLog](
	[LogId] [int] IDENTITY(1,1) NOT NULL,
	[Ticker] [varchar](30) NOT NULL,
	[Operation] [char](1) NOT NULL,
	[Type] [varchar](20) NOT NULL,
	[ValueNew] [varchar](255) NULL,
	[ValueOld] [varchar](255) NULL,
	[EditorId] [int] NOT NULL,
	[EditDate] [datetime] NOT NULL
) ON [PRIMARY]

GO

/* MigratedAnalysts */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MigratedAnalysts]') AND type in (N'U'))
DROP TABLE [dbo].[MigratedAnalysts]
GO
CREATE TABLE [dbo].[MigratedAnalysts](
	[AnalystId] [int] NOT NULL,
	[EditorId] [int] NOT NULL,
	[EditDate] [datetime] NOT NULL,
 CONSTRAINT [PK_MigratedAnalysts] PRIMARY KEY CLUSTERED 
(
	[AnalystId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

/* TickerTableSecurities_Backup, TickerSheetSecurities_backup (delete old backup tables) */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerTableSecurities_Backup]') AND type in (N'U'))
DROP TABLE [dbo].[TickerTableSecurities_Backup]
GO
CREATE TABLE [dbo].[TickerTableSecurities_Backup](
	[PubNo] [int] NOT NULL,
	[Ticker] [varchar](10) NOT NULL,
	[Rating] [char](1) NOT NULL,
	[Currency] [char](3) NOT NULL,
	[CloseDate] [datetime] NULL,
	[ClosePrice] [varchar](10) NOT NULL,
	[TargetPrice] [varchar](10) NOT NULL,
	[YTDRelPerf] [varchar](10) NOT NULL,
	[EPSLastYear] [varchar](10) NOT NULL,
	[EPSThisYear] [varchar](10) NOT NULL,
	[EPSNextYear] [varchar](10) NOT NULL,
	[MetricLastYear] [varchar](10) NOT NULL,
	[MetricThisYear] [varchar](10) NOT NULL,
	[MetricNextYear] [varchar](10) NOT NULL,
	[Yield] [varchar](10) NOT NULL,
	[TickerOrder] [int] NOT NULL,
	[TargetPriceOrig] [varchar](10) NULL,
	[CoverageId] [int] NULL,
	[CoverageAction] [varchar](10) NULL,
	[RatingAction] [varchar](10) NULL,
	[TargetPriceAction] [varchar](10) NULL,
	[EstimateAction] [varchar](10) NULL
) ON [PRIMARY]

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerSheetSecurities_backup]') AND type in (N'U'))
DROP TABLE [dbo].[TickerSheetSecurities_backup]
GO
CREATE TABLE [dbo].[TickerSheetSecurities_backup](
	[TickerSheetId] [int] NOT NULL,
	[SecurityId] [int] NOT NULL,
	[Security] [varchar](10) NOT NULL,
	[Xml] [xml] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
