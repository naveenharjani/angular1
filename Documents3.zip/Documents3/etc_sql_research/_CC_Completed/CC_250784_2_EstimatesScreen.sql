-- EstimatesScreen.sql
-- 04/06/2017


/*
-- Show Indicate Change option
-- If IndicateChange = 'yes' show draft values set else live values timeseries set
-- for eps grid, show draft in bold when live exists
-- Ticker - Increase to Varchar(12) - to take care of long tickers such as CROMPTON.IN

spGetEstimatesSetEps
spGetEstimatesSetFinancials
spGetEstimatesSetValuations

*/
GO

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spGetEstimatesSetEps]
    @Ticker         VARCHAR(12),
    @IndicateChange VARCHAR(3) = NULL
AS
SET NOCOUNT ON

DECLARE @SecurityId           INT,
        @BaseYear             INT,
        @PivotSQL             NVARCHAR(MAX),
        @PeriodYearList       NVARCHAR(MAX)

IF NOT EXISTS(SELECT * FROM Securities2 WHERE Ticker = @Ticker)
BEGIN
  SELECT 'Ticker:' + CONVERT(varchar, @Ticker) + ' not found.'
  RETURN
END

SELECT @SecurityId = S.SecurityId, @BaseYear = FCS.BaseYear
FROM Securities2 S
JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
WHERE S.Ticker = @Ticker

-- If IndicateChanges = 'yes' show draft value timeseries else live values timeseries
SELECT
  VFT.Ticker,
  VFT.FinancialNumberType,
  VFT.FullName,
  VFT.ShortName,
  VFT.Definition,
  '' AS Statement,
  @BaseYear AS BaseYear,
  CASE WHEN VFT.FinancialPeriodId = 1
       THEN 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'A'
       ELSE 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'E' END AS periodYear,
  VFT.CurCode AS Cur,
  FN1.Value AS LiveValue,
  FN2.Value AS DraftValue,
  -- eps value - draft or live
  CASE WHEN @IndicateChange = 'yes' AND FN2.Value IS NOT NULL THEN FN2.Value  -- draft value
       WHEN FN1.Value IS NOT NULL THEN FN1.Value  -- live value
       ELSE ''
  END as Value,
  -- isBold attribute - when draft and live value exists
  CASE WHEN @IndicateChange = 'yes' AND FN1.Value IS NOT NULL AND FN2.Value IS NOT NULL THEN 'Y'
       WHEN FN1.Value IS NOT NULL THEN 'N'
       ELSE ''
  END as IsBold,
  VFT.SecurityId,
  VFT.FinancialNumberTypeId,
  VFT.OrdNo,
  VFT.UnitMultiplier,
  ISNULL(VFT.Format,'') AS Format,
  VFT.FinancialNumberTypeCatOrd,
  ISNULL(VFT.Formula,'') AS Formula
INTO #TmpEpsSet
FROM vEstimateSetsPeriods VFT
LEFT JOIN vFinancialNumbersLatest FN1 ON FN1.SecurityId = VFT.SecurityId
                                     AND FN1.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                     AND FN1.FinancialPeriodId = VFT.FinancialPeriodId
                                     AND FN1.IsDraft = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2 ON FN2.SecurityId = VFT.SecurityId
                                     AND FN2.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                     AND FN2.FinancialPeriodId = VFT.FinancialPeriodId
                                     AND FN2.IsDraft = 1  -- Draft
WHERE VFT.SecurityId = @SecurityId
AND VFT.FinancialNumberTypeCat = 'E'
AND VFT.FinancialPeriodCat = 'Y'
AND VFT.FinancialNumberType IN ('EPSADJ', 'EPSRPT')

-- Get TimeSeriesMaxValue at FinancialNumberType level
SELECT Ticker, FinancialNumberType,
       MAX(UnitMultiplier) AS UnitMultiplier,
        CASE
          WHEN MAX(ISNUMERIC(Value)) = 0 THEN 0
          --ELSE MAX(CAST(Value AS FLOAT))
          ELSE MAX(ABS(Value))
        END AS TimeSeriesMaxValue
INTO #TmpEpsMax
FROM #TmpEpsSet
WHERE ISNUMERIC(VALUE) = 1
GROUP BY Ticker, FinancialNumberType

-- Get Style at FinancialNumberType level
SELECT Ticker, FinancialNumberType, UnitMultiplier,
       dbo.fnCalculateDisplayUnits(TimeSeriesMaxValue, UnitMultiplier) AS DisplayUnits
INTO #TmpEstimatesStyles
FROM #TmpEpsMax

-- Get Period list for the PIVOT Column list
SELECT @PeriodYearList = ISNULL(@PeriodYearList + ',','') + QUOTENAME(periodYear)
FROM (
       SELECT distinct periodYear FROM #TmpEpsSet
     ) AS Periods

 SELECT TE.FinancialNumberType, TE.FullName, TE.ShortName, TE.Definition, TE.Statement, TE.Cur, TE.periodYear, TE.FinancialNumberTypeId, TE.Format,
       CONVERT(varchar, dbo.fnConvertDisplayUnits(TE.Value, TS.DisplayUnits)) + ';' + CONVERT(varchar, TE.IsBold) AS Value,  --Converted value
       dbo.fnCalculateDisplayUnitsStyle(TS.DisplayUnits)   AS DisplayUnit,
       dbo.fnCalculateDisplayUnitsStyle(TE.UnitMultiplier) AS ModelUnit,
       TE.FinancialNumberTypeCatOrd, 
       TE.Formula
INTO #TmpEpsEstimates
FROM #TmpEpsSet TE
INNER JOIN #TmpEstimatesStyles TS ON TE.Ticker = TS.Ticker AND TE.FinancialNumberType = TS.FinancialNumberType

-- Prepare the dynamic PIVOT query
SELECT @PivotSQL =
  N'SELECT FinancialNumberType, FullName, ShortName, Definition, Statement, Cur, Format, ModelUnit, DisplayUnit, Formula, ' + @PeriodYearList + '
    FROM #TmpEpsEstimates
    PIVOT
    (
      MAX([Value]) FOR periodYear IN (' + @PeriodYearList + ')
    ) AS PVTTable
    ORDER BY FinancialNumberTypeCatOrd asc'

--Execute the dynamic Pivot query
EXEC sp_executesql @PivotSQL

SET NOCOUNT OFF


GO


ALTER PROCEDURE [dbo].[spGetEstimatesSetFinancials]
  @Ticker         VARCHAR(12),
  @IsPerShare     SMALLINT = NULL,   -- Per Share(1) or Non Per Share(0) or both(NULL)
  @IndicateChange VARCHAR(3)= NULL
AS
SET NOCOUNT ON

DECLARE @SecurityId           INT,
        @BaseYear             INT,
        @ModelCurCode         VARCHAR(3),
        @ModelUnitMultiplier  CHAR(1),
        @PivotSQL             NVARCHAR(MAX),
        @PeriodYearList       NVARCHAR(MAX)

IF NOT EXISTS(SELECT * FROM Securities2 WHERE Ticker = @Ticker)
BEGIN
  SELECT 'Ticker:' + CONVERT(varchar, @Ticker) + ' not found.'
  RETURN
END

SELECT @SecurityId = S.SecurityId, @BaseYear = FCS.BaseYear
FROM Securities2 S
JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
WHERE S.Ticker = @Ticker

SELECT @ModelUnitMultiplier =
        CASE
          WHEN FSS.UnitMultiplier IS NULL THEN  dbo.fnCalculateDisplayUnitsStyle(1)
          ELSE dbo.fnCalculateDisplayUnitsStyle(FSS.UnitMultiplier)
        END,
       @ModelCurCode = case when FSS.CurCode is not null then FSS.CurCode else S.CurrencyCode end
from Securities2 S
left join FinancialSecuritySettings FSS on FSS.SecurityId = S.SecurityId
where S.SecurityId = @SecurityId

-- If IndicateChanges = 'yes' show draft value timeseries else live values timeseries
SELECT
  VFT.Ticker,
  VFT.FinancialNumberType,
  VFT.FullName,
  VFT.ShortName,
  VFT.Definition,
  '' AS Statement,
  @BaseYear AS BaseYear,
  CASE WHEN VFT.FinancialPeriodId = 1
       THEN 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'A'
       ELSE 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'E' END AS periodYear,
  VFT.CurCode AS Cur,
  FN1.Value AS LiveValue,
  FN2.Value AS DraftValue,
  -- financials value - draft or live
  CASE WHEN @IndicateChange = 'yes' AND FN2.Value IS NOT NULL THEN FN2.Value  -- draft value
       WHEN FN1.Value IS NOT NULL THEN FN1.Value  -- live value
       ELSE ''
  END as Value,
  VFT.SecurityId,
  VFT.FinancialNumberTypeId,
  VFT.OrdNo,
  VFT.UnitMultiplier,
  ISNULL(VFT.Format,'') AS Format,
  VFT.IsPerShare,
  VFT.FinancialNumberTypeCatOrd,
  ISNULL(VFT.Formula,'') AS Formula
INTO #TmpFinancialsSet
FROM vEstimateSetsPeriods VFT
LEFT JOIN vFinancialNumbersLatest FN1  ON FN1.SecurityId = VFT.SecurityId
                                      AND FN1.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                      AND FN1.FinancialPeriodId = VFT.FinancialPeriodId
                                      AND FN1.IsDraft = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2  ON FN2.SecurityId = VFT.SecurityId
                                      AND FN2.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                      AND FN2.FinancialPeriodId = VFT.FinancialPeriodId
                                      AND FN2.IsDraft = 1  -- Draft
WHERE  VFT.SecurityId = @SecurityId
AND VFT.FinancialNumberTypeCat = 'E'
AND VFT.FinancialPeriodCat = 'Y'
AND VFT.FinancialNumberType NOT IN ('EPSADJ', 'EPSRPT')

-- Get Style at FinancialNumberType level
SELECT Ticker, FinancialNumberType,
       MAX(UnitMultiplier) AS UnitMultiplier,
        CASE
          WHEN MAX(ISNUMERIC(Value)) = 0 THEN 0
          --ELSE MAX(CAST(Value AS FLOAT))
          ELSE MAX(ABS(Value))
        END AS TimeSeriesMaxValue
INTO #TmpFinancialsMax
FROM #TmpFinancialsSet
WHERE ISNUMERIC(VALUE) = 1
GROUP BY Ticker, FinancialNumberType

SELECT Ticker, FinancialNumberType, UnitMultiplier,
       dbo.fnCalculateDisplayUnits(TimeSeriesMaxValue, UnitMultiplier) AS DisplayUnits
INTO #TmpFinancialsStyles
FROM #TmpFinancialsMax

-- Get FinancialPeriod list as PIVOT Column
SELECT @PeriodYearList= ISNULL(@PeriodYearList + ',','') + QUOTENAME(periodYear)
FROM (
  SELECT distinct periodYear FROM #TmpFinancialsSet
) AS Periods

SELECT TE.FinancialNumberType, TE.FullName, TE.ShortName, TE.Definition, TE.Statement, TE.Cur, TE.periodYear, TE.FinancialNumberTypeId, TE.Format,
       dbo.fnConvertDisplayUnits(TE.Value, TS.DisplayUnits) AS Value,  --Converted value
       dbo.fnCalculateDisplayUnitsStyle(TS.DisplayUnits) AS DisplayUnit,
       TE.IsPerShare,
       dbo.fnCalculateDisplayUnitsStyle(TE.UnitMultiplier) AS ModelUnit,
       TE.FinancialNumberTypeCatOrd, 
       TE.Formula
INTO #TmpFinancials
FROM #TmpFinancialsSet TE
INNER JOIN #TmpFinancialsStyles TS ON TE.Ticker = TS.Ticker AND TE.FinancialNumberType = TS.FinancialNumberType

-- Prepare the dynamic PIVOT query
SET @PivotSQL =
  N'SELECT FinancialNumberType, FullName, ShortName, Definition, Statement, Cur, Format, ''' + @ModelUnitMultiplier + + ''' AS ModelUnit, DisplayUnit, Formula, ' + @PeriodYearList + '
    FROM #TmpFinancials
    PIVOT(MAX([Value])
          FOR periodYear IN (' + @PeriodYearList + ')) AS PVTTable'

-- If Per Share or Non Per Share
IF @IsPerShare IN (0, 1)
  SET @PivotSQL = @PivotSQL + ' WHERE IsPerShare = ' + CONVERT(varchar, @IsPerShare) + ''

SET @PivotSQL = @PivotSQL + ' ORDER BY FinancialNumberTypeCatOrd asc'

--Execute the Dynamic Pivot Query
EXEC sp_executesql @PivotSQL


SET NOCOUNT OFF



GO


ALTER PROCEDURE [dbo].[spGetEstimatesSetValuations]
    @Ticker         VARCHAR(12),
    @IndicateChange VARCHAR(3) = NULL
AS
SET NOCOUNT ON

DECLARE @SecurityId           INT,
        @BaseYear             INT,
        @PivotSQL             NVARCHAR(MAX),
        @PeriodYearList       NVARCHAR(MAX)

IF NOT EXISTS(SELECT * FROM Securities2 WHERE Ticker = @Ticker)
BEGIN
  SELECT 'Ticker:' + CONVERT(varchar, @Ticker) + ' not found.'
  RETURN
END

SELECT @SecurityId = S.SecurityId, @BaseYear = FCS.BaseYear
FROM Securities2 S
JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
WHERE S.Ticker = @Ticker

-- If IndicateChanges = 'yes' show draft value timeseries else live values timeseries
SELECT
  VFT.Ticker,
  VFT.FinancialNumberType,
  VFT.FullName,
  VFT.ShortName,
  VFT.Definition,
  '' AS Statement,
  @BaseYear AS BaseYear,
  CASE WHEN VFT.FinancialPeriodId = 1
       THEN 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'A'
       ELSE 'F' + CONVERT(varchar, @BaseYear + VFT.FinancialPeriodId - 1) + 'E' END AS periodYear,
  VFT.CurCode AS Cur,
  -- valuations value - draft or live
  CASE WHEN @IndicateChange = 'yes' AND FN2.Value IS NOT NULL THEN FN2.Value  -- draft value
       WHEN FN1.Value IS NOT NULL THEN FN1.Value  -- live value
       ELSE ''
  END as Value,
  VFT.SecurityId,
  VFT.FinancialNumberTypeId,
  VFT.OrdNo,
  ISNULL(VFT.Format,'') AS Format,
  '' AS ModelUnit,
  '' AS DisplayUnit,
  VFT.FinancialNumberTypeCatOrd,
  ISNULL(VFT.Formula,'') AS Formula
INTO #TmpValuationsSet
FROM vEstimateSetsPeriods VFT
LEFT JOIN vValuationsLatest FN1       ON FN1.SecurityId = VFT.SecurityId
                                     AND FN1.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                     AND FN1.FinancialPeriodId = VFT.FinancialPeriodId
                                     AND FN1.IsDraft = 0  -- Live
LEFT JOIN vValuationsLatest FN2       ON FN2.SecurityId = VFT.SecurityId
                                     AND FN2.FinancialNumberTypeId = VFT.FinancialNumberTypeId
                                     AND FN2.FinancialPeriodId = VFT.FinancialPeriodId
                                     AND FN2.IsDraft = 1  -- Live
WHERE  VFT.SecurityId = @SecurityId
AND VFT.FinancialNumberTypeCat = 'V'
AND VFT.FinancialPeriodCat = 'Y'

-- Get FinancialPeriod list as PIVOT Column
SELECT @PeriodYearList= ISNULL(@PeriodYearList + ',','') + QUOTENAME(periodYear)
FROM (
    -- SELECT distinct FinancialPeriod FROM vEstimateSetsPeriods WHERE SecurityId = @SecurityId AND FinancialPeriodCat = 'Y'
    SELECT distinct periodYear FROM #TmpValuationsSet
) AS Periods

-- Prepare the dynamic PIVOT query
SET @PivotSQL =
  N'SELECT FinancialNumberType, FullName, ShortName, Definition, Statement, Cur, Format, ModelUnit, DisplayUnit, Formula, ' + @PeriodYearList + '
    FROM #TmpValuationsSet
    PIVOT(MAX([Value])
          FOR periodYear IN (' + @PeriodYearList + ')) AS PVTTable
          ORDER BY FinancialNumberTypeCatOrd asc'

--Execute the Dynamic Pivot Query
EXEC sp_executesql @PivotSQL

SET NOCOUNT OFF



GO



-- DEBUG

/*
-- eps set
-- EXEC spGetEstimatesSetEps 'AAPL'
 --EXEC spGetEstimatesSetEps 'AAPL', 'no'
EXEC spGetEstimatesSetEps 'AAPL', 'yes'

-- financials set
--EXEC spGetEstimatesSetFinancials 'AAPL', 0
--EXEC spGetEstimatesSetFinancials 'AAPL', 1
--EXEC spGetEstimatesSetFinancials 'AAPL', 0, 'no'
--EXEC spGetEstimatesSetFinancials 'AAPL', 1, 'no'
EXEC spGetEstimatesSetFinancials 'AAPL', 0, 'yes'
--EXEC spGetEstimatesSetFinancials 'AAPL', 1, 'yes'

-- valuations set
--EXEC spGetEstimatesSetValuations 'AAPL'
--EXEC spGetEstimatesSetValuations 'AAPL', 'no'
EXEC spGetEstimatesSetValuations 'AAPL', 'yes'

-- EXEC spGetEstimatesSetEps 'AAPL'
--EXEC spGetEstimatesSetEps 'AAPL', 'no'
--EXEC spGetEstimatesSetEps 'AAPL', 'yes'

EXEC spGetEstimatesSetEps 'BBY', 'no'
EXEC spGetEstimatesSetEps 'BBY', 'yes'

-- ticker with indicate changes
 -- EXEC spGetEstimatesSetFinancials 'BMY', 0, 'no'
 -- EXEC spGetEstimatesSetFinancials 'BMY', 0, 'yes'

 -- EXEC spGetEstimatesSetValuations 'BMY', 'no'
 -- EXEC spGetEstimatesSetValuations 'BMY', 'yes'
*/

/*

-- test data
-- and VFT.FinancialNumberType = 'GROSSPROFIT'  -- has draft data for AAPL

SELECT TOP 100 * FROM vEstimateSetsPeriods

sp_helptext vEstimateSetsPeriods
sp_helptext vEstimateSets

*/