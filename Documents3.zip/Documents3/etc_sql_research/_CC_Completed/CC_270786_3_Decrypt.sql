-- Decrypt.sql
-- 11/27/2017

/*

spRenderContentIds - Called by decrypteid.aspx

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spRenderContentIds]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spRenderContentIds]
GO

CREATE PROCEDURE [dbo].[spRenderContentIds]
  @ContentType   CHAR(1),
  @SecurityId    INT
AS

-- For the supplied ContentType and SecurityId return a list of Content Ids

IF @ContentType = 'R' -- Research
  SELECT
    'Value'   = P.PubNo,
    'Display' = CONVERT(varchar, P.Date, 101)
  FROM Publications P
  JOIN Properties PR ON P.PubNo = PR.PubNo AND PR.PropId = 13  -- Ticker
  JOIN Securities2 S ON S.Ticker = PR.PropValue
  WHERE S.SecurityId = @SecurityId
  ORDER BY P.PubNo DESC

ELSE IF @ContentType = 'M' -- Model
  SELECT
    'Value'   = (CASE WHEN ROW_NUMBER() OVER(ORDER BY ModelId DESC) = 1 THEN SecurityId
                 ELSE ModelId END),
    'Display' = (CASE WHEN ROW_NUMBER() OVER(ORDER BY ModelId DESC) = 1 THEN 'Latest'
                 ELSE CONVERT(varchar, EditDate, 120) END)
  FROM Models
  WHERE Securityid = @SecurityId
  ORDER BY ModelId DESC


GO

GRANT EXECUTE ON dbo.spRenderContentIds TO DE_IIS, PowerUsers
GO

/*

select Ticker, SecurityId, count(*) Num from vModels group by Ticker, SecurityId order by Num desc

EXEC spRenderContentIds 'R', 107
EXEC spRenderContentIds 'M', 107
GO

*/
