-- DropConstraint.sql
-- 06/09/2017

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists (select * from sys.foreign_keys 
   where object_id = OBJECT_ID('dbo.FK_TickerTables_Publications')
   and parent_object_id = OBJECT_ID('dbo.TickerTables')
)
alter table TickerTables drop constraint FK_TickerTables_Publications

GO