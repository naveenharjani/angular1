-- Models.sql
-- 05/02/2017

/*
Models
vModels
vModelsLatest
spGetPrimarySecurity
spSaveModel
spGetModels
spDeleteModel
spDeletePublication
spRollbackEstimates
*/

USE Research
GO

-- Make sure that all of the session settings are set properly
set ARITHABORT ON
set CONCAT_NULL_YIELDS_NULL ON
set QUOTED_IDENTIFIER ON
set ANSI_NULLS ON
set ANSI_PADDING ON
set ANSI_WARNINGS ON
set NUMERIC_ROUNDABORT OFF
GO

if not exists(select * from Counters where Name = 'ModelId')
insert into Counters(Name,Value,Description)
select 'ModelId',0,'Maintains the last ModelId in Models table'
go

if exists(select * from sys.objects where name = 'Models' and type = 'u')
drop table [dbo].[Models]
go

create table [dbo].[Models]
(
  ModelId       int         NOT NULL,
  SecurityId    int         NOT NULL,
  AnalystId     int         NOT NULL,
  FileName      varchar(30) NOT NULL,
  PubNo         int             NULL,
  Status        varchar(30) NOT NULL,  -- Active, Replaced, Deleted
  Source        varchar(30) NOT NULL,  -- Publishing, Upload
  EditorId      int         NOT NULL,
  EditDate      datetime    NOT NULL,
)
go

-- vModels w/ action tags
if exists(select * from sys.objects where name = 'vModels' and type = 'V')
drop view dbo.vModels
go

create view dbo.vModels
as
  select
    ModelId,
    S2.SecurityId,
    S2.Ticker,
    S2.CompanyId,
    S2.OrdNo,
    RatingAction,
    TargetPriceAction,
    EPSFY1Action,
    EPSFY2Action,
    AnalystId,
    M.PubNo,
    M.FileName,
    M.Status,
    M.Source,
    M.EditorId,
    M.EditDate
  from
    Models M
    join Securities2 S on M.SecurityId = S.SecurityId
    join Securities2 S2 on S.CompanyId = S2.CompanyId
    join PublicationFinancials PF on M.PubNo = PF.PubNo and S2.SecurityId = PF.SecurityId
go

if exists(select * from sys.objects where name = 'vModelsLatest' and type = 'V')
drop view dbo.vModelsLatest
go

create view dbo.vModelsLatest
as
  select
    ModelId,
    S2.SecurityId,
    S2.Ticker,
    S2.CompanyId,
    S2.OrdNo,
    RatingAction,
    TargetPriceAction,
    EPSFY1Action,
    EPSFY2Action,
    AnalystId,
    M.PubNo,
    M.FileName,
    M.Status,
    M.Source,
    M.EditorId,
    M.EditDate
  from
    Models M
    join Securities2 S on M.SecurityId = S.SecurityId
    join Securities2 S2 on S.CompanyId = S2.CompanyId
    join PublicationFinancials PF on M.PubNo = PF.PubNo and S2.SecurityId = PF.SecurityId
  where ModelId in (select Max(ModelId) from Models group by SecurityId)
go

if exists(select * from sys.objects where name = 'spGetPrimarySecurity' and type = 'P')
drop procedure spGetPrimarySecurity
go

create proc dbo.spGetPrimarySecurity (@SecurityId int)
as
begin
  select SecurityId PrimarySecurityId,Ticker PrimaryTicker from Securities2
  where CompanyId = (select CompanyId from Securities2 where SecurityId = @SecurityId) and
  IsPrimary = 'Y'
end
go

if exists(select * from sys.objects where name = 'spSaveModel' and type = 'P')
drop procedure spSaveModel
go

create proc dbo.spSaveModel (@ModelId int, @SecurityId int, @CoverageId int, @PubNo int, @FileName varchar(30), @EditorId int, @UploadType varchar(30))
as
begin

  begin transaction

  declare @PrimarySecurityId int
  declare @AnalystId int
  select @PrimarySecurityId = SecurityId from Securities2
  where CompanyId = (select CompanyId from Securities2 where SecurityId = @SecurityId) and
  IsPrimary = 'Y'

  select @AnalystId = AnalystId from ResearchCoverage
  where CoverageId = @CoverageId

  update Models
  set Status = 'Replaced', EditorId = @EditorId, EditDate = GETDATE()
  from Models M
  where SecurityId  = @PrimarySecurityId AND Status = 'Active'

  insert into Models(ModelId,AnalystId,SecurityId,PubNo,FileName,Status,Source,EditorId,EditDate)
  select  @ModelId,
		  @AnalystId,
          @PrimarySecurityId,
          @PubNo,
          @FileName,
          'Active',
          @UploadType,
          @EditorId,
          getdate()

  commit transaction
end
go

if exists(select * from sys.objects where name = 'spGetModels' and type = 'P')
drop proc dbo.spGetModels
go

create procedure [dbo].[spGetModels]
  @Type           int,  --0 - Latest, 1 - All
  @OrderBy        varchar(100),
  @OrderType      varchar(4),
  @SearchCriteria varchar(1000)
as
begin
  declare @sql VARCHAR(8000)

  if @OrderType = '' set @OrderType = 'desc'

  if @OrderBy = ''
  begin
    set @OrderBy = 'RegionId,Analyst,Ticker,SortId,ModelId desc'
  end
  else
  begin
    if @OrderBy = 'Analyst'      set @OrderBy = @OrderBy + ' ' + @OrderType + ', Ticker,SortId,ModelId desc'
    if @OrderBy = 'Ticker'       set @OrderBy = @OrderBy + ' ' + @OrderType + ', SortId,ModelId desc'
    if @OrderBy = 'Company'      set @OrderBy = @OrderBy + ' ' + @OrderType + ', SortId,ModelId desc'
    if @OrderBy = 'EditDate'     set @OrderBy = @OrderBy + ' ' + @OrderType + ', RegionId,Analyst,Ticker,SortId,ModelId desc'
    if @OrderBy = 'Report'       set @OrderBy = @OrderBy + ' ' + @OrderType + ', RegionId,Analyst,Ticker,SortId,ModelId desc'
    if @OrderBy = 'FileName'     set @OrderBy = @OrderBy + ' ' + @OrderType + ', RegionId,Analyst,Ticker,SortId,ModelId desc'
    if @OrderBy = 'PubNo'        set @OrderBy = @OrderBy + ' ' + @OrderType + ', RegionId,Analyst,Ticker,SortId,ModelId desc'
    if @OrderBy = 'Status'       set @OrderBy = @OrderBy + ' ' + @OrderType + ', RegionId,Analyst,Ticker,SortId,ModelId desc'
  end

  set @sql = 'set nocount on '  +
              'declare @Counter int select @Counter = Value from Counters where Name = ''ModelNo'' ' +
              'select AR.RegionId,' +
              'AR.Region,' +
              'A.Last + '', '' + A.First Analyst,' +
              'A.AuthorId,' +
              'S.Ticker,' +
              'S.SecurityId,' +
              'S.Company,' +
              'AM.ModelId,' +
              'RC.CoverageId,' +
              'CONVERT(Varchar,AM.ModelId) + ''.'' + REVERSE(SUBSTRING(REVERSE(AM.FileName),0,CHARINDEX(''.'',REVERSE(AM.FileName)))) ModelFileName,' +
              'AM.PubNo,' +
              'P.FileName ReportFileName,' +
              'P.Title,' +
              'AM.FileName,' +
              'AM.Status,' +
              'AM.EditDate, ' +
              '1 SortId '
  if @Type = 0
  set @sql =  @sql +
              'from ResearchCoverage RC left outer join Authors A on RC.AnalystId = A.AuthorId ' +
              'join Securities2 S on RC.SecurityId = S.SecurityId and S.IsPrimary = ''Y'' ' +
              'left outer join AuthorRegions AR on A.RegionId = AR.RegionId ' +
              'left outer join (select AM1.* from Models AM1 join (select AnalystId,SecurityId,max(ModelId) ModelId from Models group by AnalystId,SecurityId) v on AM1.ModelId = v.ModelId) AM on S.SecurityId = AM.SecurityId and A.AuthorId = AM.AnalystId ' +
              'left outer join Publications P on AM.PubNo = P.PubNo ' +
              'where RC.Launchdate is not null and RC.DropDate is null ' +
              'and (AM.Status is null or AM.Status = ''Active'') '
  else
  set @sql =  @sql +
              'from ResearchCoverage RC left outer join Authors A on RC.AnalystId = A.AuthorId ' +
              'join Securities2 S on RC.SecurityId = S.SecurityId and S.IsPrimary = ''Y'' ' +
              'left outer join AuthorRegions AR on A.RegionId = AR.RegionId ' +
              'left outer join Models AM on S.SecurityId = AM.SecurityId and A.AuthorId = AM.AnalystId ' +
              'left outer join Publications P on AM.PubNo = P.PubNo ' +
              'where RC.Launchdate is not null and RC.DropDate is null '

  if @SearchCriteria <> '' set @sql = @sql + 'and ' + @SearchCriteria + ' '

  --Populate rows for dropped analysts with previously uploaded models
  set @sql =  @sql + ' Union All ' +
              'select AR.RegionId,' +
              'AR.Region,' +
              'A.Last + '', '' + A.First Analyst,' +
              'A.AuthorId,' +
              'S.Ticker,' +
              'S.SecurityId,' +
              'S.Company,' +
              'AM.ModelId,' +
              'RC.CoverageId,' +
              'CONVERT(Varchar,AM.ModelId) + ''.'' + REVERSE(SUBSTRING(REVERSE(AM.FileName),0,CHARINDEX(''.'',REVERSE(AM.FileName)))) ModelFileName,' +
              'AM.PubNo,' +
              'P.FileName ReportFileName,' +
              'P.Title,' +
              'AM.FileName,' +
        'AM.Status,' +
              'AM.EditDate, ' +
              '1 SortId '
  if @Type = 0
  set @sql =  @sql +
              'from ResearchCoverage RC join Authors A on RC.AnalystId = A.AuthorId ' +
              'join Securities2 S on RC.SecurityId = S.SecurityId and S.IsPrimary = ''Y'' ' +
              'join AuthorRegions AR on A.RegionId = AR.RegionId ' +
              'join (select AM1.* from Models AM1 join (select AnalystId,SecurityId,max(ModelId) ModelId from Models group by AnalystId,SecurityId) v on AM1.ModelId = v.ModelId) AM on S.SecurityId = AM.SecurityId and A.AuthorId = AM.AnalystId ' +
              'join Publications P on AM.PubNo = P.PubNo ' +
              'where RC.Launchdate is not null and RC.DropDate is not null ' +
              'and (AM.Status is null or AM.Status = ''Active'') '
  else
  set @sql =  @sql +
              'from ResearchCoverage RC join Authors A on RC.AnalystId = A.AuthorId ' +
              'join Securities2 S on RC.SecurityId = S.SecurityId and S.IsPrimary = ''Y'' ' +
              'join AuthorRegions AR on A.RegionId = AR.RegionId ' +
              'join Models AM on S.SecurityId = AM.SecurityId and A.AuthorId = AM.AnalystId ' +
              'join Publications P on AM.PubNo = P.PubNo ' +
              'where RC.Launchdate is not null and RC.DropDate is not null '

  if @SearchCriteria <> '' set @sql = @sql + 'and ' + @SearchCriteria + ' '

  --Populate a dummy empty row if the latest for analyst/ticker is in 'Deleted' status.
  set @sql =  @sql + ' Union All ' +
              'select AR.RegionId,' +
              'AR.Region,' +
             'A.Last + '', '' + A.First Analyst,' +
              'A.AuthorId,' +
              'S.Ticker,' +
              'S.SecurityId,' +
              'S.Company,' +
              'null ModelId,' +
              'null CoverageId,' +
              'null ModelFileName,' +
              'null PubNo,' +
              'null ReportFileName,' +
              'null Title,' +
              'null FileName,' +
              'null Status,' +
              'null Date,' +
              '0 SortId ' +
              'from ResearchCoverage RC join Authors A on RC.AnalystId = A.AuthorId ' +
              'join Securities2 S on RC.SecurityId = S.SecurityId and S.IsPrimary = ''Y'' ' +
              'join AuthorRegions AR on A.RegionId = AR.RegionId ' +
              'join (select AM1.* from Models AM1 join (select AnalystId,SecurityId,max(ModelId) ModelId from Models group by AnalystId,SecurityId) v on AM1.ModelId = v.ModelId where AM1.Status = ''Deleted'') AM on S.SecurityId = AM.SecurityId and A.AuthorId = AM.AnalystId ' +
              'where RC.Launchdate is not null and RC.DropDate is null '

  if @SearchCriteria <> '' set @sql = @sql + 'and ' + @SearchCriteria + ' '

  set @sql = @sql + ' order by ' + @OrderBy
  print(@sql)
  exec(@sql)
end

go

if exists(select * from sys.objects where name = 'spDeleteModel' and type = 'P')
drop proc dbo.spDeleteModel
go

create procedure [dbo].[spDeleteModel]
  @ModelId        int,
  @EditorId       int
AS
begin
  update Models set Status = 'Deleted', EditorId = @EditorId, EditDate = GetDate() where ModelId = @ModelId
end
go

if exists(select * from sys.objects where name = 'spDeletePublication2' and type = 'P')
drop proc dbo.spDeletePublication2
go

if exists(select * from sys.objects where name = 'spDeletePublication' and type = 'P')
drop proc dbo.spDeletePublication
go

create procedure [dbo].[spDeletePublication]
  @PubNo         int,
  @Operation     char(1),
  @EditorId      int,
  @Numdeleted    int OUTPUT
AS
declare @AuditNo int

-- PREVENT PHANTOM deleteS (from STALE BROWSER) BY ONLY PROCESSING FIRST delete REQUEST
if NOT EXISTS(select * from Publications where PubNo = @PubNo)
  begin
    select @Numdeleted = 0 -- return OUTPUT PARAMETERS
    return
  end

-- return ROWset
select FileName from Documents where PubNo = @PubNo

delete from TickerTableSecurities       where PubNo = @PubNo
delete from TickerTableSecuritiesOld    where PubNo = @PubNo
delete from Footnotes                   where PubNo = @PubNo
delete from FootnoteRefs                where PubNo = @PubNo
delete from TickerTables                where PubNo = @PubNo
delete from ProductGroupDocuments       where PubNo = @PubNo
delete from RelatedPublications         where PubNo = @PubNo
if @Operation = 'D' --delete from FinancialNumbers only if "delete" invoked from research dashboard and not report resubmits
begin
  delete from PublicationFinancialNumbers where PubNo = @PubNo
  delete from PublicationFinancials       where PubNo = @PubNo
  delete from FinancialNumbers            where PubNo = @PubNo
  --update model status to deleted if this publication promoted any models to live
  if EXISTS(select * from Models where PubNo = @PubNo)
  begin
  update Models set Status = 'Deleted', EditorId = @EditorId, EditDate = GetDate() where PubNo = @PubNo AND Status = 'Active'
  end
end

-- RVdeletedDocuments replicated view uses the logs below for pdf cache control on BR.com
insert into AuditLog (Operation, EditorId, EditDate) VALUES (@Operation, @EditorId, GETDATE())
select @AuditNo = @@IDENTITY

insert into PublicationsLog (AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate)
select @AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate from Publications where PubNo = @PubNo

insert into DocumentsLog (AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig)
select @AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig from Documents where PubNo = @PubNo

insert into PropertiesLog (AuditNo, PubNo, PropNo, PropId, PropValue)
select @AuditNo, PubNo, PropNo, PropId, PropValue from Properties where PubNo = @PubNo

delete from Properties   where PubNo = @PubNo
delete from Documents    where PubNo = @PubNo
delete from Publications where PubNo = @PubNo

select @Numdeleted = @@ROWCOUNT -- return OUTPUT PARAMETERS
go

alter procedure [dbo].[spRollbackEstimates]
  @PubNo int,
  @SecurityId int,
  @EditorId int
as
begin try
  begin transaction
    --only one set of reports(with same source pubno) can be in correction mode at any time
    --reject if the prior set is not completed/cancelled
    if exists(select * from CorrectionQueue where status in ('Required','Optional') and SourcePubNo <> @PubNo)
    begin
        select -3 returnValue
        commit
        return
    end

    --if a report is already scheduled to be published for this ticker
    --prevent from doing a rollback
    declare @Qid int, @DXml xml, @hDoc int
    select top 1 @Qid = QueueId,@DXml = DocumentXml from PublicationQueue where ProcessStatus = 'Scheduled' order by QueueId

    while @@ROWCOUNT = 1
    begin
      exec sp_xml_preparedocument @hDoc output, @DXml

      if exists
      (select X.SecurityId,X.Ticker,X.IndicateChange
      from openxml (@hDoc, 'DocumentInfo/Securities/Security', 1)
      with (securityId      int         '@id',
            ticker          varchar(30) '@ticker',
            indicateChange  varchar(10) '@indicateChange'
            ) X
      where X.SecurityId = @SecurityId)
      begin
        select -2 returnValue
        commit
        return
      end

      exec sp_xml_removedocument @hDoc
      select top 1 @Qid = QueueId,@DXml = DocumentXml from PublicationQueue where ProcessStatus = 'Scheduled' AND QueueId > @Qid order by QueueId
    end
    --check to see if report exists in publicationxml table (new system)
    if exists(select PubNo from PublicationsXml where PubNo = @PubNo)
    begin

      declare @CurrentDate datetime
      declare @Ticker varchar(30)
      declare @UserName varchar(36)

      set @CurrentDate = GETDATE()
      select @Ticker = Ticker from Securities2 where SecurityId = @SecurityId
      select @UserName = UserName from Users where UserId = @EditorId

      --delete any pending drafts
      delete from FinancialNumbers where SecurityId = @SecurityId and IsDraft = 1

      --revert the latest live numbers to draft state
      delete PublicationFinancialNumbers
      from PublicationFinancialNumbers PFN
      join FinancialNumbers FN on PFN.FinancialNumberId = FN.FinancialNumberId
      where FN.SecurityId = @SecurityId
      and FN.PubNo = @PubNo
      and FN.IsDraft = 0

      update FinancialNumbers
      set IsDraft = 1, PubNo = null, Date = @currentdate
      where SecurityId = @SecurityId
      and PubNo = @PubNo
      and IsDraft = 0

      --update model status to deleted if this publication promoted any models to live
    if exists(select * from Models where PubNo = @PubNo)
    begin
    update Models set status = 'Deleted', EditorId = @EditorId, EditDate = GetDate() where PubNo = @PubNo and Status = 'Active'
    end

      --Determine the covering analyst for the rollback ticker
      declare @AnalystId int
      select @AnalystId = AnalystId from ResearchCoverage where SecurityId  = @SecurityId and LaunchDate is not null and DropDate is null

      --insert into CorrectionQueue table for source report
      insert into CorrectionQueue(PubNo,SecurityId,AnalystId,SourcePubNo,IsSource,CorrectionMode,Queued,QueuedBy,Status,EditorId,EditDate)
      select @PubNo,@SecurityId,@AnalystId,@PubNo,1,0,@CurrentDate,@EditorId,'Required',@EditorId,@CurrentDate

      --Retrieve dependent publication numbers
      select PubNo
      into #TmpDependentPublications
      from Properties PR
      join PropertyNames PN on PR.PropId = PN.PropId
      where PN.PropName = 'Ticker'
      and PR.PropValue = (select Ticker from Securities2 where SecurityId = @SecurityId)
      and PR.PubNo > @PubNo

      --insert into CorrectionQueue table for all dependent publications
      insert into CorrectionQueue(PubNo,SecurityId,AnalystId,SourcePubNo,IsSource,CorrectionMode,Queued,QueuedBy,Status,EditorId,EditDate)
      select PubNo,@SecurityId,@AnalystId,@PubNo,0,0,@CurrentDate,@EditorId,'Optional',@EditorId,@CurrentDate
      from #TmpDependentPublications


      exec spRestoreMarketData @PubNo, @SecurityId, @EditorId

    end
  select 0 returnValue
 commit
end try
begin catch
  if @@trancount > 0
    rollback
    --raise an error with the details of the exception
    declare @errmsg nvarchar(4000), @errseverity int
    select @errmsg = ERROR_MESSAGE(),
            @errseverity = ERROR_SEVERITY()
    select -1 returnValue
    Raiserror(@errmsg,@errseverity,1)
end catch
go

grant execute on dbo.spGetPrimarySecurity to DE_IIS, PowerUsers
grant execute on dbo.spSaveModel         to DE_IIS, PowerUsers
grant execute on dbo.spDeleteModel       to DE_IIS, PowerUsers
grant execute on dbo.spGetModels         to DE_IIS, PowerUsers
grant execute on dbo.spDeletePublication to DE_IIS, PowerUsers
go

/*
exec spinsertModel 126,'TE',127424,'CSGN.VX.xlsx',0,''

select * from Models

select * from vModels

select * from vModelsLatest

select * from vModels order by ModelId,PubNo,CompanyId,OrdNo

*/

