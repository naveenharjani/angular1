-- Blast.sql
-- 09/08/2020

/*

spGetAnalystBlastXml -- Enhanced version of spGetBlastXml

*/
USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO



IF EXISTS(SELECT * FROM Sys.objects WHERE name = 'spGetAnalystBlastXml' AND type = 'P')
DROP PROCEDURE [dbo].[spGetAnalystBlastXml]
GO

CREATE PROCEDURE [dbo].[spGetAnalystBlastXml]
  (@PubNo INT)
AS
BEGIN
	DECLARE @PrimaryAuthor VARCHAR(300)
	--Get the primary author of the report
	SELECT @PrimaryAuthor = PropValue FROM Properties Pr join
	(select min(PropNo) PropNo from Properties
		where PubNo = @PubNo and PropId = 5) Pr2 ON Pr.PropNo = Pr2.PropNo

    --Get Industries covered by primary author
	SELECT DISTINCT A.AuthorID,A.Name,I.IndustryID,I.IndustryName
	INTO #tmp_PrimaryAuthorIndustries
	FROM Authors A join ResearchCoverage RC on A.AuthorID = RC.AnalystID
	join Industries I on I.IndustryId = RC.IndustryID
	WHERE
		RC.LaunchDate is not null and RC.DropDate is null
		AND A.Name = @PrimaryAuthor
    
	--Get latest 3 podcasts/videos by primary author in the last 12 months
	SELECT TOP 3 P.PubNo, P.Date, P.Title, PT.PublicationTypeID, P.Type
	INTO #tmp_PodcastsVideos
	FROM 
	Publications P join Properties Pr	on Pr.PubNo = P.PubNo
	join PublicationTypes PT on P.Type = PT.PublicationType
	where
	PropValue = @PrimaryAuthor and PropID = 5
	--and P.Date > DATEADD(d,-90,getdate())
	and P.Type in ('Video','Podcast')
	and P.PubNo <> @PubNo
	ORDER BY P.PubNo desc

	--Get latest black book by primary author in the last 12 months
	SELECT TOP 1 P.PubNo, P.Date, P.Title, PT.PublicationTypeID, P.Type
	INTO #tmp_Blackbooks
	FROM
	Publications P join Properties Pr	on Pr.PubNo = P.PubNo
	join PublicationTypes PT on P.Type = PT.PublicationType
	where
	PropValue = @PrimaryAuthor and PropID = 5
	and P.PubNo <> @PubNo
	--and P.Date > DATEADD(YY,-1,getdate())
	and P.Type in ('Black Book')
	ORDER BY P.PubNo desc
	
	--Get latest marketing deck by primary author in the last 12 months
	SELECT distinct A.LinkId,A.Title,A.EffectiveDate
	INTO #tmp_MarketingDecks
	FROM Assets A join Authors AU on A.AnalystId = AU.AuthorID
	join AssetScreens AST on A.LinkId = AST.LinkId
	WHERE A.AssetTypeId = 1
	and A.ExpiryDate > getdate()
	and AU.Name = @PrimaryAuthor 
	ORDER BY A.LinkId desc

	--Get Keywords for document 
	SELECT DocId PubNo, Keyword
	INTO #tmp_DocKeywords
	FROM RVDocKeywords
	WHERE DocId = @PubNo 

	--Get Related Research 
	SELECT P.PubNo, P.Date, P.Title, PT.PublicationTypeID, P.Type
	INTO #tmp_RelatedResearch
	FROM 
	RelatedPublications RP join Publications P ON RP.RelatedPubNo = P.PubNo
	JOIN PublicationTypes PT ON P.Type = PT.PublicationType
	WHERE RP.PubNo = @PubNo
	ORDER BY P.PubNo desc

	IF NOT EXISTS (SELECT * FROM Publications WHERE PubNo = @PubNo)
	BEGIN
		SELECT '<NotExist>' + CONVERT(varchar, @PubNo) + '</NotExist>' AS XML
		RETURN
	END

	SET NOCOUNT ON

	SELECT
		1                          AS tag,
		null                       AS parent,
		P.pubNo                    AS [Publication!1!pubNo],
		UPPER(FORMAT(P.Date, 'ddd dd MMM yyyy', 'en-US')) AS [Publication!1!date],
		--UPPER(DATENAME(w, P.Date) + ' ' + DATENAME(dd, P.Date) + ' ' + DATENAME(mm, P.Date) + ' ' + DATENAME(yy, P.Date)) AS [Publication!1!date],
		P.Type                     AS [Publication!1!type],
		PT.PublicationTypeID       AS [Publication!1!typeId],
		P.SubType				   AS [Publication!1!subType],	
		P.Title                    AS [Publication!1!title],
		K.Keyword				   AS [Publication!1!keyword],	
		null					   AS [Industries!2!!element],
		null                       AS [Industry!3!id],
		null                       AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null					  AS [Securities!4!!element],
		null                       AS [Security!5!id],
		null                       AS [Security!5!ticker],
		null                       AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					  AS [Authors!6!!element],
		null                       AS [Author!7!id],
		null                       AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                       AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
	FROM Publications P WITH(NOLOCK) 
	JOIN PublicationTypes PT WITH(NOLOCK) ON PT.PublicationType = P.Type
	LEFT JOIN #tmp_DocKeywords K ON P.PubNo = K.PubNo
	WHERE P.PubNo = @PubNo

	UNION ALL

	SELECT
		2                          AS tag,
		1							AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],	
		null						AS [Industries!2!!element],
		null                       AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null					  AS [Securities!4!!element],
		null                       AS [Security!5!id],
		null                       AS [Security!5!ticker],
		null                       AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					  AS [Authors!6!!element],
		null                       AS [Author!7!id],
		null                       AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                       AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]


	UNION ALL

	SELECT DISTINCT
		3                          AS tag,
		2                          AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],			
		null						AS [Industries!2!!element],
		I.IndustryId                AS [Industry!3!id],
		I.IndustryName 		       AS [Industry!3!name],
		Pr.PropNo                   AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null                       AS [Security!5!id],
		null                       AS [Security!5!ticker],
		null                       AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					  AS [Authors!6!!element],
		null                       AS [Author!7!id],
		null                       AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                       AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]

	FROM Properties PR
	JOIN PropertyNames PN ON PR.PropID = PN.PropID
	JOIN Industries I ON PR.PropValue = I.IndustryName
	WHERE
	PR.PubNo = @PubNo AND
	PN.PropName IN ('Industry')


	UNION ALL

	SELECT
		4                          AS tag,
		1                       AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null                       AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null					  AS [Securities!4!!element],
		null                       AS [Security!5!id],
		null                       AS [Security!5!ticker],
		null                       AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					  AS [Authors!6!!element],
		null                       AS [Author!7!id],
		null                       AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                       AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
	UNION ALL

	SELECT
		5                          AS tag,
		4                          AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		S.SecurityID                AS [Security!5!id],
		S.Ticker 		            AS [Security!5!ticker],
		S.Company                   AS [Security!5!company],
		PR.PropNo					 AS [Security!5!seqNo!hide],
		null					  AS [Authors!6!!element],
		null                       AS [Author!7!id],
		null                       AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                       AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
	FROM Properties PR
	JOIN PropertyNames PN ON PR.PropID = PN.PropID
	JOIN Securities2 S ON PR.PropValue = S.Ticker
	WHERE
	PR.PubNo = @PubNo AND
	PN.PropName IN ('Ticker')

	UNION ALL

	SELECT
		6                          AS tag,
		1                       AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null                       AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null					  AS [Securities!4!!element],
		null                       AS [Security!5!id],
		null                       AS [Security!5!ticker],
		null                       AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					  AS [Authors!6!!element],
		null                       AS [Author!7!id],
		null                       AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                       AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]

	UNION ALL
	
	SELECT
		7                           AS tag,
		6                           AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null		                AS [Security!5!company],
		null					  AS [Securities!4!!element],
		null					  AS [Authors!6!!element],
		A.AuthorID				   AS [Author!7!id],
		A.Name                       AS [Author!7!name],
		A.Phone 				   AS [Author!7!phone],
		A.ExtEmail				   AS [Author!7!email],
		AT.Title                   AS [Author!7!title],
		PR.PropNo                    AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
	FROM Properties PR
	JOIN PropertyNames PN ON PR.PropID = PN.PropID
	JOIN Authors A ON PR.PropValue = A.Name
	JOIN AuthorTitles AT ON A.TitleID = AT.TitleID
	WHERE
	PR.PubNo = @PubNo AND
	PN.PropName IN ('Author')

	UNION ALL

	SELECT
		8                           AS tag,
		1                           AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null		                AS [Security!5!company],
		null						AS [Securities!4!!element],
		null						AS [Authors!6!!element],
		null						AS [Author!7!id],
		null                       AS [Author!7!name],
		null 						AS [Author!7!phone],
		null						AS [Author!7!email],
		null						AS [Author!7!title],
		null	                    AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
	
	UNION ALL
		SELECT
		9                           AS tag,
		8                           AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null		                AS [Security!5!company],
		null						AS [Securities!4!!element],
		null						AS [Authors!6!!element],
		null						AS [Author!7!id],
		null                       AS [Author!7!name],
		null 						AS [Author!7!phone],
		null						AS [Author!7!email],
		null						AS [Author!7!title],
		null	                    AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		IndustryId               AS [Industry!9!id],
		IndustryName				AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]

	FROM #tmp_PrimaryAuthorIndustries

	UNION ALL

	SELECT
		10                           AS tag,
		1                           AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null	 		            AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					    AS [Authors!6!!element],
		null    				    AS [Author!7!id],
		null                        AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                        AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		P.HighlightsXml            AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
	FROM PublicationsXml P
	WHERE P.PubNo = @PubNo

	UNION ALL

	SELECT
		11                           AS tag,
		1                           AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null	 		            AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					    AS [Authors!6!!element],
		null    				    AS [Author!7!id],
		null                        AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                        AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
		UNION ALL

		SELECT
		12                           AS tag,
		11                            AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null					   AS [Publication!1!keyword],		
		null						AS [Publication!1!title],
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null	 		            AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					    AS [Authors!6!!element],
		null    				    AS [Author!7!id],
		null                        AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                        AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		PubNo                       AS [Research!12!pubNo],
		FORMAT(Date, 'd MMM yyyy', 'en-US')					   AS [Research!12!date],
		Date					   AS [Research!12!dateorig!hide],
		PublicationTypeID                       AS [Research!12!typeId],
		Type                       AS [Research!12!type],
		Title                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
		from
		#tmp_PodcastsVideos

		UNION ALL

		SELECT
		13                           AS tag,
		1                            AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null	 		            AS [Security!5!company],
		null					  AS [Securities!4!!element],
		null					    AS [Authors!6!!element],
		null    				    AS [Author!7!id],
		null                        AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                        AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]

		UNION ALL

		SELECT
		14                           AS tag,
		13                            AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null	 		            AS [Security!5!company],
		null					  AS [Securities!4!!element],
		null					    AS [Authors!6!!element],
		null    				    AS [Author!7!id],
		null                        AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                        AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		PubNo                       AS [Research!14!pubNo],
		FORMAT(Date, 'd MMM yyyy', 'en-US') 					   AS [Research!14!date],
		Date					   AS [Research!14!dateorig!hide],
		PublicationTypeID                       AS [Research!14!typeId],
		Type                       AS [Research!14!type],
		Title                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
		FROM
		#tmp_Blackbooks

	UNION ALL

		SELECT
		15                           AS tag,
		1                            AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null	 		            AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					    AS [Authors!6!!element],
		null    				    AS [Author!7!id],
		null                        AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                        AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
		
		UNION ALL

		SELECT
		16                           AS tag,
		15                            AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null	 		            AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					    AS [Authors!6!!element],
		null    				    AS [Author!7!id],
		null                        AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                        AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		LinkId                    AS [Deck!16!linkId],
		CONVERT(VARCHAR(10),EffectiveDate,101)					   AS [Deck!16!date],
		EffectiveDate					   AS [Deck!16!dateorig!hide],
		Title                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]
		FROM
		#tmp_MarketingDecks

		UNION ALL

		SELECT
		17                           AS tag,
		1                            AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null	 		            AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					    AS [Authors!6!!element],
		null    				    AS [Author!7!id],
		null                        AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                        AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		null                       AS [Research!18!pubNo],
		null					   AS [Research!18!date],
		null					   AS [Research!18!dateorig!hide],
		null                       AS [Research!18!typeId],
		null                       AS [Research!18!type],
		null                       AS [Research!18!title]

	UNION ALL

		SELECT
		18                           AS tag,
		17                            AS parent,
		null						AS [Publication!1!pubNo],
		null						AS [Publication!1!date],
		null						AS [Publication!1!type],
		null						AS [Publication!1!typeId],
		null						AS [Publication!1!subType],	
		null						AS [Publication!1!title],
		null					   AS [Publication!1!keyword],		
		null						AS [Industries!2!!element],
		null						AS [Industry!3!id],
		null						AS [Industry!3!name],
		null                       AS [Industry!3!seqNo!hide],
		null  						AS	[Securities!4!!element],
		null		                AS [Security!5!id],
		null	 		            AS [Security!5!ticker],
		null	 		            AS [Security!5!company],
		null                       AS [Security!5!seqNo!hide],
		null					    AS [Authors!6!!element],
		null    				    AS [Author!7!id],
		null                        AS [Author!7!name],
		null                       AS [Author!7!phone],
		null                       AS [Author!7!email],
		null                       AS [Author!7!title],
		null                        AS [Author!7!seqNo!hide],
		null                       AS [PrimaryAuthorIndustries!8!!element],
		null                       AS [Industry!9!id],
		null                       AS [Industry!9!name],
		null                       AS [Highlights!10!xml],
		null                       AS [Media!11!!element],
		null                       AS [Research!12!pubNo],
		null					   AS [Research!12!date],
		null					   AS [Research!12!dateorig!hide],
		null                       AS [Research!12!typeId],
		null                       AS [Research!12!type],
		null                       AS [Research!12!title],
		null                       AS [Blackbooks!13!!element],
		null                       AS [Research!14!pubNo],
		null					   AS [Research!14!date],
		null					   AS [Research!14!dateorig!hide],
		null                       AS [Research!14!typeId],
		null                       AS [Research!14!type],
		null                       AS [Research!14!title],
		null					   AS [Decks!15!!element],
		null                       AS [Deck!16!linkId],
		null					   AS [Deck!16!date],
		null					   AS [Deck!16!dateorig!hide],
		null                       AS [Deck!16!title],
		null                       AS [RelatedResearch!17!!element],
		PubNo                       AS [Research!18!pubNo],
		FORMAT(Date, 'd MMM yyyy', 'en-US') 					   AS [Research!18!date],
		Date					   AS [Research!18!dateorig!hide],
		PublicationTypeID          AS [Research!18!typeId],
		Type                       AS [Research!18type],
		Title                      AS [Research!18!title]
	FROM
		#tmp_RelatedResearch

	ORDER BY tag, [Industry!3!seqNo!hide],[Security!5!seqNo!hide],[Author!7!seqNo!hide],[Research!12!dateorig!hide] desc,[Research!14!dateorig!hide] desc,[Deck!16!dateorig!hide] desc,[Research!18!dateorig!hide] desc
	FOR XML Explicit

END
GO

GRANT EXECUTE ON [dbo].[spGetAnalystBlastXml] TO DE_IIS, PowerUsers
GO

-- DEBUG

/*

spGetAnalystBlastXml 151457 

sp_helptext spGetBlastXml
go

sp_helptext spGetResearchXml
go

sp_helptext spGetModelXml
go

sp_helptext spGetAssetXml
go

sp_helptext spGetCartXml
go

sp_helptext spGetResearch
go

sp_helptext spGetAnalystBlastDetails
go

spGetBlastXml 150656
go

spGetResearchXml 150939
go

spGetModelXml 6
go

spGetAssetXml 102
go

spGetCartXml 1
go


-- ***
-- *** Enhanced version of spGetBlastXml
-- *** Industries, Authors, Tickers

<Research id="156721" version="1" documentType="Company Report" type="Research Call" subType="Company Report" pubDate="27 Aug 2020" title="Info Edge: Zomato - Online food delivery - Appetizer or a Buffet?" closeDate="27 Aug 2020" perfType="TTM" valType="P/E Reported" epsType="" baseYear="2019" ignoreAutoFootnote="N" actionLine="" sector="India Technology, Media &amp; Internet" includeValuationTable="N" includeFinancials="N" coauthored="N" strategy="N" coverageInitiation="N" alphalytics="N" moveTT="Y" userKeepTT="N" financialsFootnote="" approver="rpossa" approvedDate="August 27, 2020 03:41 pm" source="" docFileName="Info Edge Zomato Aug 2020.docx" tickerSheetVersion="2.00" userLastUpdated="bbalas" CollaborativeDisclosures="0" />
	<Industries>
		<Industry name="India Technology, Media &amp; Internet" id="172" />
	</Industries>
	<Authors>
		<Author id="874" name="Rahul Malhotra" phone="+91-22-6842-1431" email="rahul.malhotra@bernstein.com" title="Analyst" typeId="1" brokerDealer="HK" />
		<Author id="1029" name="Balakumar Balasubramanian" phone="+91-226-842-1447" email="balakumar.balasubramanian@bernstein.com" title="" typeId="1" brokerDealer="HK" />
	</Authors>
	<Securities>
		<Security ticker="INFOE.IN" id="1898" companyId="1440" coverageId="2442" tickerSheetId="48088" analyst="Malhotra" indicateChange="no" optYesFlags="" />
		<Security ticker="MXAPJ" id="1132" companyId="index" coverageId="" tickerSheetId="" analyst="" indicateChange="no" optYesFlags="" />
	</Securities>

7.	Podcasts & Videos
-	3 most recent Podcasts or Videos from Primary Author, from last 12 months, date appended to title.

8.	Featured Content
-	Latest Black Book from Primary Author, from last 12 months, date appended to title
-	Primary Author Marketing Deck

9.	Most Read
-	3 most read reports (excluding Blasts/Comments/Quick Takes), by Primary Author, last 3 months


	Featured Content
	� From research database

Most Read
	� From CRM database

*/
