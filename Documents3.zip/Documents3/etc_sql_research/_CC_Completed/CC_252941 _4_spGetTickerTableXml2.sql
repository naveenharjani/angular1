-- spGetTickerTableXml2.sql
-- 11/21/2016

/*

create spGetTickerTableXml2

POST CC
- spGetTickerTableXml - Now obsolete.  Drop in future CC

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE name = 'spGetTickerTableXml2' and TYPE = 'P')
  DROP PROCEDURE [dbo].[spGetTickerTableXml2]
GO

CREATE PROCEDURE [dbo].[spGetTickerTableXml2]
  @PubNo        INT
AS

IF NOT EXISTS (SELECT * FROM PublicationsXml WHERE PubNo = @PubNo)
BEGIN
  SELECT '' AS TickerTableXml
  RETURN
END

SELECT TickerTableXml FROM PublicationsXml WHERE PubNo = @PubNo
GO

GRANT EXECUTE ON [dbo].[spGetTickerTableXml2]                      TO PowerUsers, DE_IIS
GO



/*
-- DEBUG

spGetTickerTableXml2 127411 -- using TickerTableXml

spGetTickerTableXml 127411  -- old 

sp_helptext spGetTickerTableXml

*/