-- DWS.sql
-- 05/06/2019

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*
-- New Report with the entire universe of coverage & recommendations each month; 
-- Delivery: Email or SFTP;  
-- Format: csv
-- Date fields - Number format will be ideal � so 43101 for 1 Jan 2018

create proc spRptDwsCoverageData

Existing procs:
sp_helptext spRptDwsDailySignals   -- �BERN Coverage� SSRS sent out to DWS M-F 8am
sp_helptext spRptDwsWeeklyCoverage -- �BERN Signals� SSRS sent out to DWS each Friday 12:30pm

*/

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spRptDwsCoverageData]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spRptDwsCoverageData]
GO

CREATE PROCEDURE [dbo].[spRptDwsCoverageData]
AS
BEGIN
  SET NOCOUNT ON

  SELECT
    'SrNo'                          = ROW_NUMBER() OVER(ORDER BY A.Last, S.Ticker, S.OrdNo),
    'AnalystName'                   = A.Last + ', ' + A.First,
    'AnalystTelephone'              = SUBSTRING(A.Phone, 2, 50),
    'AnalystEmailAddress'           = A.ExtEmail,
    'CompanyCovered'                = S.Company,
    'SecurityTicker'                = (CASE WHEN CHARINDEX('.', S.Ticker,1) > 0 
                                            THEN LEFT(S.Ticker,CHARINDEX('.', S.Ticker,1) -1) + 
                                            ' ' +
                                            SUBSTRING(S.Ticker, CHARINDEX('.', S.Ticker,1)+1, LEN(S.Ticker)-CHARINDEX('.', S.Ticker,1))
                                            ELSE S.Ticker + ' US'
                                       END),
    'SecuritySEDOL'                 = S.SEDOL,
    'SecurityRIC'                   = S.RIC,
    'TargetSharePrice'              = VF.TargetPrice,
    'TargetSharePriceCurrency'      = S.CurrencyCode,
    'TargetSharePriceCurrencyScale' = (CASE WHEN S.CurrencyCode IN ('GBp', 'ZAr') THEN 0 ELSE 1 END),
    --'TargetSharePriceDate'        = (SELECT [Date] FROM Publications WHERE Pubno = (SELECT MAX(Pubno) FROM PublicationFinancials WHERE SecurityId = VF.SecurityId AND (TargetPriceAction IN ('Increase', 'Decrease') OR CoverageAction IN ('Initiate')))),
    'TargetSharePriceDate'          = (SELECT CONVERT(INT, [Date]) FROM Publications WHERE Pubno = (SELECT MAX(Pubno) FROM PublicationFinancials WHERE SecurityId = VF.SecurityId AND (TargetPriceAction IN ('Increase', 'Decrease') OR CoverageAction IN ('Initiate')))),
    'Recommendation'                = VF.Rating,
    --'RecommendationChangeDate'    = (SELECT [Date] FROM Publications WHERE Pubno = (SELECT MAX(Pubno) FROM PublicationFinancials WHERE SecurityId = VF.SecurityId AND (RatingAction IN ('Upgrade', 'Downgrade') OR CoverageAction IN ('Initiate')))),
    'RecommendationChangeDate'      = (SELECT CONVERT(INT, [Date]) FROM Publications WHERE Pubno = (SELECT MAX(Pubno) FROM PublicationFinancials WHERE SecurityId = VF.SecurityId AND (RatingAction IN ('Upgrade', 'Downgrade') OR CoverageAction IN ('Initiate')))),
    'EPS_FY1'                       = VF.EPSThisYear,
    'EPS_FY2'                       = VF.EPSNextYear,
    'EPS_FY3'                       = (SELECT MAX(CASE WHEN ISNUMERIC(FN.Value) = 1 THEN CONVERT(VARCHAR,CAST(FN.Value AS DECIMAL(18,2))) ELSE FN.Value END) AS Value
                                       FROM vFinancialNumbersLatest FN
                                       WHERE FN.SecurityId = VF.SecurityId
                                       AND FN.CoverageId = VF.CoverageId
                                       AND FN.FinancialNumberTypeId = (SELECT FCS.TickerTableEpsId FROM FinancialCompanySettings FCS INNER JOIN Securities2 S ON S.CompanyId = FCS.CompanyId WHERE S.SecurityId =  VF.SecurityId)
                                       AND FN.FinancialPeriodId = 4    -- FY3
                                       AND FN.IsDraft = 0),            -- Live
    'EPS_Currency'                  = FSS.CurCode,
    'EPS_CurrencyScale'             = (CASE WHEN FSS.CurCode IN ('GBp', 'ZAr') THEN 0 ELSE 1 END),
    'EPS_NumShares'                 = '-',
    'NetIncome_FY1'                 = (SELECT ISNULL(FN.Value, '') FROM vFinancialNumbersLatest FN
                                       WHERE FN.SecurityId = VF.SecurityId AND FN.CoverageId = VF.CoverageId
                                       AND FN.FinancialNumberTypeId = 39 -- NETINVESTINC
                                       AND FN.FinancialPeriodId = 2      -- FY1
                                       AND FN.IsDraft = 0),              -- Live
    'NetIncome_FY2'                 = (SELECT ISNULL(FN.Value, '') FROM vFinancialNumbersLatest FN 
                                       WHERE FN.SecurityId = VF.SecurityId AND FN.CoverageId = VF.CoverageId
                                       AND FN.FinancialNumberTypeId = 39 -- NETINVESTINC
                                       AND FN.FinancialPeriodId = 3      -- FY2
                                       AND FN.IsDraft = 0),              -- Live
    'AnalysisDate'                  = CONVERT(varchar(10), P.Date, 120),
    'EBITDA_FY1'                    = (SELECT ISNULL(FN.Value,'') FROM vFinancialNumbersLatest FN 
                                       WHERE FN.SecurityId = VF.SecurityId AND FN.CoverageId = VF.CoverageId
                                       AND FN.FinancialNumberTypeId = 7 -- EBITDA
                                       AND FN.FinancialPeriodId = 2      -- FY1
                                       AND FN.IsDraft = 0),              -- Live
    'EBITDA_FY2'                    = (SELECT ISNULL(FN.Value,'') FROM vFinancialNumbersLatest FN 
                                       WHERE FN.SecurityId = VF.SecurityId AND FN.CoverageId = VF.CoverageId
                                       AND FN.FinancialNumberTypeId = 7 -- EBITDA
                                       AND FN.FinancialPeriodId = 3      -- FY2
                                       AND FN.IsDraft = 0),              -- Live
    'Revenue_FY1'                    = (SELECT ISNULL(FN.Value,'') FROM vFinancialNumbersLatest FN 
                                       WHERE FN.SecurityId = VF.SecurityId AND FN.CoverageId = VF.CoverageId
                                       AND FN.FinancialNumberTypeId = 5 -- SALES
                                       AND FN.FinancialPeriodId = 2      -- FY1
                                       AND FN.IsDraft = 0),              -- Live
    'Revenue_FY2'                    = (SELECT ISNULL(FN.Value,'') FROM vFinancialNumbersLatest FN 
                                       WHERE FN.SecurityId = VF.SecurityId AND FN.CoverageId = VF.CoverageId
                                       AND FN.FinancialNumberTypeId = 5 -- SALES
                                       AND FN.FinancialPeriodId = 3      -- FY2
                                       AND FN.IsDraft = 0),              -- Live
    'CapEx_FY1'                    = (SELECT ISNULL(FN.Value,'') FROM vFinancialNumbersLatest FN 
                                       WHERE FN.SecurityId = VF.SecurityId AND FN.CoverageId = VF.CoverageId
                                       AND FN.FinancialNumberTypeId = 18 -- CAPEX
                                       AND FN.FinancialPeriodId = 2      -- FY1
                                       AND FN.IsDraft = 0),              -- Live
    'CapEx_FY2'                    = (SELECT ISNULL(FN.Value,'') FROM vFinancialNumbersLatest FN 
                                       WHERE FN.SecurityId = VF.SecurityId AND FN.CoverageId = VF.CoverageId
                                       AND FN.FinancialNumberTypeId = 18 -- CAPEX
                                       AND FN.FinancialPeriodId = 3      -- FY2
                                       AND FN.IsDraft = 0),              -- Live
    'EstimateCurrency'             = FSS.CurCode,
    'EstimateFY1YearEnd'           = (SELECT BaseYear + 1 FROM FinancialCompanySettings Where CompanyId = S.CompanyId)
  FROM vFinancialsLatest VF
  JOIN Publications P ON P.PubNo      = VF.PubNo
  JOIN Securities2 S  ON S.SecurityId = VF.SecurityId
  JOIN Authors A      ON A.AuthorId   = VF.AnalystId
  JOIN FinancialSecuritySettings FSS ON FSS.SecurityId = VF.SecurityId
  ORDER BY A.Last, S.Ticker, S.OrdNo

END
GO

GRANT EXECUTE ON dbo.[spRptDwsCoverageData] TO [SCBIS_Reports], [PowerUsers], [DE_IIS]
GO

/*

-- DEBUG

EXEC spRptDwsCoverageData
GO

*/
