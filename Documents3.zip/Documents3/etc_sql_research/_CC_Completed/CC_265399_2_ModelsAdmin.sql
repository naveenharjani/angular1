-- CC_ModelsAdmin.sql
-- 10/04/2017

/*

spSearchAnalystSettings
spGetFinancialSettings
spRenderEpsTypes
spRenderValuationTypes
spRenderEpsTypesTmp
spRenderValuationTypesTmp
spSaveModelDistributionStatus
spSaveCoverage

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if not exists(select * from sys.columns where name = 'ModelDistribution' and object_id = object_id('ResearchCoverage'))
alter table dbo.ResearchCoverage
add ModelDistribution char(1)
go

--populate DistributionEligible = 1 for all active tickers on Day 1 (ModelDistribution = 'y/n')
update ResearchCoverage
set ModelDistribution = 'Y'
where DropDate is null
and ModelDistribution is null
go

ALTER PROCEDURE [dbo].[spSearchAnalystSettings]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT,
  @AnalystId     int
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
DECLARE @AnalystFilter varchar(100)
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'

DECLARE @Sort varchar(100)
SELECT @Sort = CASE @SortCol
  WHEN '5' THEN @SortCol +  @SortDir + ', 27'
  WHEN '6' THEN @SortCol +  @SortDir
  ELSE @SortCol +  @SortDir + ', 5, 27'
END

-- Pivot relevant market data
SELECT
  Ticker,
  MAX(CASE BloombergMnemonic WHEN 'EXPECTED_REPORT_DT'     THEN Value ELSE '' END) ReportDate,
  MAX(CASE BloombergMnemonic WHEN 'EXPECTED_REPORT_PERIOD' THEN Value ELSE '' END) ReportPeriod,
  MAX(CASE BloombergMnemonic WHEN 'EQY_FISCAL_YR_END'      THEN Value ELSE '' END) FiscalYearEndLast,
  MAX(CASE BloombergMnemonic WHEN 'NEXT_FISCAL_YR_END'     THEN Value ELSE '' END) FiscalYearEndNext
INTO #TmpMarketData
FROM vBloombergPricingLatest
GROUP BY Ticker

-- Convert empty strings to null to enable downstream datetime conversion
UPDATE #TmpMarketData SET ReportDate = null WHERE ReportDate = ''
UPDATE #TmpMarketData SET FiscalYearEndNext = null WHERE FiscalYearEndNext = ''

SET @AnalystFilter = ''
IF @AnalystId <> -1 SET @AnalystFilter = 'and RC.AnalystId = ' + CONVERT(VARCHAR,@AnalystId)

CREATE TABLE #TmpSearch
(
  ID                    int IDENTITY,
  CoverageId            int,
  AnalystId             int,
  Region                varchar(100),
  Analyst               varchar(100),
  Company               varchar(100),
  Ticker                varchar(100),
  BenchmarkIndex        varchar(100),
  EpsTypeId             int,
  MetricsTypeId         int,
  EstimatePeriodId      int,
  EpsType               varchar(10),
  MetricsType           varchar(10),
  EstimatePeriod        varchar(10),
  ExchangeCurCode       varchar(10),
  ModelCurCode          varchar(10),
  UnitMultiplier        bigint,
  ModelDistribution     char(1),
  ReportDate            varchar(20), --datetime,
  ReportDateSort        varchar(20), --datetime,
  ReportPeriod          varchar(20),
  FiscalYearEndLast     varchar(20),
  FiscalYearEndLastSort varchar(20), --datetime,
  FiscalYearEndNext     varchar(20), --datetime,
  LaunchDate            datetime,
  Editor                varchar(36),
  EditDate              datetime,
  OrdNo                 int,
  IsPrimary             char(1),
  SecurityId            int
)

declare @sql varchar(max)

print '@AnalystFilter=' + @AnalystFilter

print '@SortCol=' + @SortCol

print '@SortDir=' + @SortDir

print '@Sort=' + @Sort

set @sql =
'select
  RC.CoverageId,
  RC.AnalystId,
  AR.Region,
  A.Last,
  S.Company,
  S.Ticker,
  S.BenchmarkIndex,
  FCS.TickerTableEpsId,
  FCS.TickerTableValuationId,
  FCS.BaseYear,
  EpsType = FNT1.FinancialNumberType,
  MetricsType = FNT2.FinancialNumberType,
  FCS.BaseYear,
  S.CurrencyCode,
  FSS.CurCode,
  FSS.UnitMultiplier,
  RC.ModelDistribution,
  T.ReportDate,
  substring(T.ReportDate, 7, 4) + substring(T.ReportDate, 1, 2) + substring(T.ReportDate, 4, 2) as ReportDateSort,
  T.ReportPeriod,
  T.FiscalYearEndLast,
  substring(T.FiscalYearEndLast, 4, 4) + substring(T.FiscalYearEndLast, 1, 2),
  T.FiscalYearEndNext,
  RC.LaunchDate,
  E.UserName,
  FCS.EditDate,
  S.OrdNo,
  S.IsPrimary,
  S.SecurityId
from ResearchCoverage RC
join Authors A on A.AuthorId = RC.AnalystId
join AuthorRegions AR on AR.RegionId = A.RegionId
join Securities2 S on S.SecurityId = RC.SecurityId
left join FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
left join FinancialSecuritySettings FSS on FSS.SecurityId = RC.SecurityId
left join FinancialNumberTypes FNT1 on FNT1.FinancialNumberTypeId = FCS.TickerTableEpsId
left join FinancialNumberTypes FNT2 on FNT2.FinancialNumberTypeId = FCS.TickerTableValuationId
left join #TmpMarketData T on T.Ticker = S.Ticker
left join Users E on E.UserId = FCS.EditorId
where RC.DropDate IS NULL ' + @AnalystFilter + '
order by ' + @Sort

print(@sql)

INSERT INTO #TmpSearch (CoverageId, AnalystId, Region, Analyst, Company, Ticker, BenchmarkIndex, EpsTypeId, MetricsTypeId, EstimatePeriodId, EpsType, MetricsType, EstimatePeriod, ExchangeCurCode, ModelCurCode, UnitMultiplier, ModelDistribution, ReportDate, ReportDateSort, ReportPeriod, FiscalYearEndLast, FiscalYearEndLastSort, FiscalYearEndNext, LaunchDate, Editor, EditDate, OrdNo, IsPrimary, SecurityId)
EXEC(@sql)

SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT CoverageId, AnalystId, Region, Analyst, Company, Ticker, BenchmarkIndex, EpsTypeId, MetricsTypeId, EstimatePeriodId, EpsType, MetricsType, EstimatePeriod, ExchangeCurCode, ModelCurCode, UnitMultiplier, ModelDistribution, ReportDate, ReportDateSort, ReportPeriod, FiscalYearEndLast, FiscalYearEndLastSort, FiscalYearEndNext, LaunchDate, Editor, EditDate, OrdNo, IsPrimary, SecurityId
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO

ALTER PROCEDURE [dbo].[spGetFinancialSettings]
  @SecurityId             int,
  @IsModelTicker          char(1)     output,
  @BaseYear               char(4)     output,
  @EpsId                  int         output,
  @ValuationId            int         output,
  @ExchangeCurCode        varchar(20) output,
  @ModelCurCode           varchar(20) output,
  @NumberUnitCode         varchar(20) output,
  @UnitMultiplier         varchar(20) output,
  @ModelDistribution      char(1)     output,
  @OnReportFinancialCount int         output,
  @OnReportValuationCount int         output
AS

declare @CompanyId int

select
  @CompanyId = CompanyId,
  @IsModelTicker = IsPrimary,
  @ExchangeCurCode = CurrencyCode
from Securities2 where SecurityId = @SecurityId

select
  @ModelDistribution = ModelDistribution
from ResearchCoverage where SecurityId = @SecurityId and DropDate is null

select
  @BaseYear = BaseYear,
  @EpsId = TickerTableEpsId,
  @ValuationId = TickerTableValuationId
from FinancialCompanySettings where CompanyId = @CompanyId

select @ModelCurCode = case when FSS.CurCode is not null then FSS.CurCode else S.CurrencyCode end
from Securities2 S
left join FinancialSecuritySettings FSS on FSS.SecurityId = S.SecurityId
where S.SecurityId = @SecurityId

select
  @NumberUnitCode = N.NumberUnitCode,
  @UnitMultiplier = N.UnitMultiplier
from NumberUnits N
join FinancialSecuritySettings FSS on FSS.UnitMultiplier = N.UnitMultiplier
where SecurityId = @SecurityId

select @OnReportFinancialCount = count(*) - 1 from vEstimateSets V where V.SecurityId = @SecurityId and V.FinancialNumberTypeCat = 'E' and IsOnReport = 1

select @OnReportValuationCount = count(*) from vEstimateSets V where V.SecurityId = @SecurityId and V.FinancialNumberTypeCat = 'V' and IsOnReport = 1

-- Returns 4 rowsets with same column critieria

-- Rowset: EPS Estimates

-- EPSRPT, EPSADJ
select
  VES.SecurityId,
  FNT.FinancialNumberTypeId,
  FNT.FinancialNumberType,
  FNT.FullName,
  FNT.ShortName,
  FNT.Definition,
  FNT.IsRequiredSet,
  FNT.IsRequiredReport,
  FNT.Format,
  VES.Formula,
  case when VES.FinancialNumberTypeId is null then 0 else 1 end EstimateSet,
  VES.IsOnReport ReportSet,
  FNT.FinancialNumberTypeCat,
  FNT.FinancialNumberTypeCatOrd,
  --FNT.Statement
  CASE FNT.Statement WHEN 'IS' THEN 'Income Statement' WHEN 'BS' THEN 'Balance Sheet' WHEN 'CF' THEN 'Cash Flow' ELSE FNT.Statement END as Statement,
  FNT.EditDate
from FinancialNumberTypes FNT
left join vEstimateSets VES on VES.FinancialNumberTypeId = FNT.FinancialNumberTypeId and VES.SecurityId = @SecurityId
where FNT.FinancialNumberTypeCat in ('E') and FNT.FinancialNumberType in ('EPSRPT', 'EPSADJ')

union

--EPS_ALT when reporting currency <> pricing currency
select
  S.SecurityId,
  FNT.FinancialNumberTypeId,
  FNT.FinancialNumberType,
  FNT.FullName,
  FNT.ShortName,
  FNT.Definition,
  FNT.IsRequiredSet,
  FNT.IsRequiredReport,
  FNT.Format,
  '' Formula,
  case when FSE.FinancialNumberTypeId is null then 1 else 0 end EstimateSet,
  case when FRS.FinancialNumberTypeId is null then 0 else 1 end ReportSet,
  FNT.FinancialNumberTypeCat,
  FNT.FinancialNumberTypeCatOrd,
  --FNT.Statement
  CASE FNT.Statement WHEN 'IS' THEN 'Income Statement' WHEN 'BS' THEN 'Balance Sheet' WHEN 'CF' THEN 'Cash Flow' ELSE FNT.Statement END as Statement,
  FNT.EditDate
from FinancialNumberTypes FNT cross join Securities2 S
join FinancialSecuritySettings FS on S.SecurityId = FS.SecurityId
left join FinancialSetExclusions FSE on FSE.FinancialNumberTypeId = FNT.FinancialNumberTypeId and FSE.CompanyId = S.CompanyId
left join FinancialReportSettings FRS on FRS.FinancialNumberTypeId = FNT.FinancialNumberTypeId and FRS.CompanyId = S.CompanyId
where FNT.FinancialNumberTypeCat in ('E') and FNT.FinancialNumberType in ('EPS_ALT')
and S.SecurityId = @SecurityId
and FS.CurCode <> S.CurrencyCode

order by FNT.FinancialNumberTypeCat, FNT.FinancialNumberTypeCatOrd

-- Rowset: Non-EPS Estimates - Non Pershare Items
select
  VES.SecurityId,
  FNT.FinancialNumberTypeId,
  FNT.FinancialNumberType,
 FNT.FullName,
  FNT.ShortName,
  FNT.Definition,
  FNT.IsRequiredSet,
  FNT.IsRequiredReport,
  FNT.Format,
  VES.Formula,
  case when VES.FinancialNumberTypeId is null then 0 else 1 end EstimateSet,
  VES.IsOnReport ReportSet,
  --FNT.Statement
  CASE FNT.Statement WHEN 'IS' THEN 'Income Statement' WHEN 'BS' THEN 'Balance Sheet' WHEN 'CF' THEN 'Cash Flow' ELSE FNT.Statement END as Statement,
  FNT.EditDate
from FinancialNumberTypes FNT
left join vEstimateSets VES on VES.FinancialNumberTypeId = FNT.FinancialNumberTypeId and VES.SecurityId = @SecurityId
where FNT.FinancialNumberTypeCat in ('E') and FNT.FinancialNumberType not in ('EPSRPT', 'EPSADJ', 'EPS_ALT')
and FNT.IsPerShare <> 1
order by FNT.FinancialNumberTypeCat, FNT.FinancialNumberTypeCatOrd

-- Rowset: Non-EPS Estimates - Per Share Items
select
  VES.SecurityId,
  FNT.FinancialNumberTypeId,
  FNT.FinancialNumberType,
  FNT.FullName,
  FNT.ShortName,
  FNT.Definition,
  FNT.IsRequiredSet,
  FNT.IsRequiredReport,
  FNT.Format,
  VES.Formula,
  case when VES.FinancialNumberTypeId is null then 0 else 1 end EstimateSet,
  VES.IsOnReport ReportSet,
  --FNT.Statement
  CASE FNT.Statement WHEN 'IS' THEN 'Income Statement' WHEN 'BS' THEN 'Balance Sheet' WHEN 'CF' THEN 'Cash Flow' ELSE FNT.Statement END as Statement,
  FNT.EditDate
from FinancialNumberTypes FNT
left join vEstimateSets VES on VES.FinancialNumberTypeId = FNT.FinancialNumberTypeId and VES.SecurityId = @SecurityId
where FNT.FinancialNumberTypeCat in ('E') and FNT.FinancialNumberType not in ('EPSRPT', 'EPSADJ', 'EPS_ALT')
and FNT.IsPerShare = 1
order by FNT.FinancialNumberTypeCat, FNT.FinancialNumberTypeCatOrd

-- Rowset: Valuation Metrics
select
  VES.SecurityId,
  FNT.FinancialNumberTypeId,
  FNT.FinancialNumberType,
  FNT.FullName,
  FNT.ShortName,
  FNT.Definition,
  FNT.IsRequiredSet,
  FNT.IsRequiredReport,
  FNT.Format,
  case when VES.Formula is not null then VES.Formula else FNT.Formula end Formula,
  case when VES.FinancialNumberTypeId is null then 0 else 1 end EstimateSet,
  VES.IsOnReport ReportSet,
  --FNT.Statement
  CASE FNT.Statement WHEN 'IS' THEN 'Income Statement' WHEN 'BS' THEN 'Balance Sheet' WHEN 'CF' THEN 'Cash Flow' ELSE FNT.Statement END as Statement,
  FNT.EditDate
from FinancialNumberTypes FNT
left join vEstimateSets VES on VES.FinancialNumberTypeId = FNT.FinancialNumberTypeId and VES.SecurityId = @SecurityId
where FNT.FinancialNumberTypeCat in ('V')
order by FNT.FinancialNumberTypeCat, FNT.FinancialNumberTypeCatOrd
GO

if exists(select * from sys.objects where name = 'spRenderEpsTypes' and type = 'P')
drop proc dbo.spRenderEpsTypes
go

create procedure [dbo].[spRenderEpsTypes]
as
select 'Value' = FinancialNumberTypeId, 'Display' = FinancialNumberType from FinancialNumberTypes where FinancialNumberType = 'EPSRPT'
union
select 'Value' = FinancialNumberTypeId, 'Display' = FinancialNumberType from FinancialNumberTypes where FinancialNumberType = 'EPSADJ'
go

if exists(select * from sys.objects where name = 'spRenderValuationTypes' and type = 'P')
drop proc dbo.spRenderValuationTypes
go

create procedure [dbo].[spRenderValuationTypes]
as
select 'Value' = 0, 'Display' = 'P/E'
union
select 'Value' = FinancialNumberTypeId, 'Display' = FinancialNumberType from FinancialNumberTypes where FinancialNumberType = 'P/BV'
union
select 'Value' = FinancialNumberTypeId, 'Display' = FinancialNumberType from FinancialNumberTypes where FinancialNumberType = 'EV/EBITDA'
go

if exists(select * from sys.objects where name = 'spRenderEpsTypesTmp' and type = 'P')
drop proc dbo.spRenderEpsTypesTmp
go

if exists(select * from sys.objects where name = 'spRenderValuationTypesTmp' and type = 'P')
drop proc dbo.spRenderValuationTypesTmp
go

if exists(select * from sys.objects where name = 'spSaveModelDistributionStatus' and type = 'P')
drop proc dbo.spSaveModelDistributionStatus
go

create procedure [dbo].[spSaveModelDistributionStatus]
  @CompanyId int,
  @AnalystId int,
  @Value     char(1),
  @UserId    int
as
begin
  declare @CoverageId int
  declare @SecurityId int
  select @SecurityId = SecurityId from Securities2 where CompanyId = @CompanyId and IsPrimary = 'Y'

  select @CoverageId = CoverageId from ResearchCoverage
  where AnalystId = @AnalystId and SecurityId = @SecurityId
  and DropDate is null

  update ResearchCoverage
  set ModelDistribution = @Value, EditorId = @UserId, EditDate = getdate()
  where CoverageId = @CoverageId

  return 0
end
go

ALTER PROCEDURE [dbo].[spSaveCoverage]
  @CoverageId    int OUTPUT,
  @IndustryId    int,
  @AnalystId     int,
  @SecurityId    int,
  @LaunchDate    datetime,
  @LaunchInd     char(1),
  @DropDate      datetime,
  @DropInd       char(1),
  @EditorId      int
AS
DECLARE @EditDate datetime
DECLARE @CoverageAction varchar(10)
DECLARE @RatingAction varchar(10)
DECLARE @PubNo int
DECLARE @EstimatePeriodId int
DECLARE @MsgOld varchar(100)
DECLARE @MsgNew varchar(100)
DECLARE @CompanyId int

SELECT @EditDate = GETDATE()
BEGIN TRANSACTION
BEGIN TRY
--Before insert/update row in ResearchCoverage table
--perform the two checks below

--Company should only be covered by one active analyst
SELECT @CompanyId = CompanyId FROM Securities2 WHERE SecurityId = @SecurityId
IF (SELECT DISTINCT RC.AnalystId FROM ResearchCoverage RC JOIN Securities2 S ON RC.SecurityId = S.SecurityId
WHERE CompanyId = @CompanyId AND  LaunchDate IS NOT NULL AND DropDate IS NULL) <> @AnalystId
BEGIN
  ROLLBACK TRANSACTION
  RETURN -1
END

--Security should only be covered by one active analyst
IF (SELECT COUNT(*) FROM ResearchCoverage
WHERE SecurityId = @SecurityId AND AnalystId <> @AnalystId AND  LaunchDate IS NOT NULL AND DropDate IS NULL) > 0
BEGIN
  ROLLBACK TRANSACTION
  RETURN -2
END

IF @DropInd = '' SELECT @DropInd = null
IF EXISTS (SELECT CoverageId FROM ResearchCoverage WHERE CoverageId = @CoverageId)
  -- EXISTING COVERAGE
  BEGIN
    SELECT @MsgOld = I.IndustryName + ' | ' + A.Last + ' | ' + ISNULL(S.Ticker, '-')
    FROM ResearchCoverage RC
    JOIN Industries I ON I.IndustryId = RC.IndustryId
    JOIN Authors A ON A.AuthorId = RC.AnalystId
    LEFT JOIN Securities2 S ON S.SecurityId = RC.SecurityId
    WHERE RC.CoverageId = @CoverageId

    UPDATE ResearchCoverage SET
      IndustryId = @IndustryId,
      AnalystId  = @AnalystId,
      SecurityId = @SecurityId,
      LaunchDate = @LaunchDate,
      LaunchInd  = @LaunchInd,
      DropDate   = @DropDate,
      DropInd    = @DropInd,
      EditorId   = @EditorId,
      EditDate   = @EditDate
    WHERE CoverageId = @CoverageId

    SELECT @MsgNew = I.IndustryName + ' | ' + A.Last + ' | ' + ISNULL(S.Ticker, '-')
    FROM ResearchCoverage RC
    JOIN Industries I ON I.IndustryId = RC.IndustryId
    JOIN Authors A ON A.AuthorId = RC.AnalystId
    LEFT JOIN Securities2 S ON S.SecurityId = RC.SecurityId
    WHERE RC.CoverageId = @CoverageId

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Coverage', 'U', @MsgNew, @MsgOld, @CoverageId, @EditorId, @EditDate)

    -- Drop Date validation
    -- A Call report must exist for the specified coverage drop date (when previously launched):
    --  * When strategy coverage, i.e. no security, a Call must exist for analyst & industry & drop date combination
    --  * When company coverage, i.e. security, a Call must exist for analyst & security & drop date combination
    -- Optimally, the drop date of a Discontinuing Coverage Call should be specified
    -- (otherwise the date of the last published Call should be specified).
    IF ((@LaunchDate is not null) OR (@LaunchDate <> '')) AND ((@DropDate is not null) OR (@DropDate <> ''))
    BEGIN
      -- Update Industry, Analyst and Security tables to reflect active coverage status (iPad)
      UPDATE Securities2 SET Status = 0,EditDate = getdate() WHERE SecurityId = @SecurityId
      IF NOT EXISTS(SELECT * FROM ResearchCoverage WHERE IndustryId = @IndustryId AND LaunchDate IS NOT NULL AND DropDate IS NULL)
      BEGIN
        UPDATE Industries SET Status = 0,EditDate = getdate() WHERE IndustryId = @IndustryId
      END
      IF NOT EXISTS(SELECT * FROM ResearchCoverage WHERE AnalystId = @AnalystId AND LaunchDate IS NOT NULL AND DropDate IS NULL)
      BEGIN
        UPDATE Authors SET Status = 0,EditDate = getdate() WHERE AuthorId = @AnalystId
      END
      -- Strategy coverage: Get PubNo for specified Call & analyst & industry & drop date combination
      IF ((@SecurityId is null) OR (@SecurityId < 1))
      BEGIN
        SELECT @PubNo = max(P.PubNo)
        FROM Publications P
        JOIN Properties Pr ON P.PubNo = Pr.PubNo AND Pr.PropId = 5
        JOIN Authors A ON Pr.PropValue = A.Name
        JOIN Properties Pr2 ON P.Pubno = Pr2.PubNo AND Pr2.PropId = 11
        JOIN Industries I ON Pr2.PropValue = I.IndustryName
        WHERE
          P.Type = 'Research Call' AND
          A.AuthorId = @AnalystId AND
          I.IndustryId = @IndustryId AND
          P.Date = @DropDate
      END
      -- Company coverage: Get PubNo for specified Call & analyst & security & drop date combination
      ELSE
      BEGIN
        SELECT @PubNo = max(P.PubNo )
        FROM Publications P
        JOIN Properties Pr ON P.PubNo = Pr.PubNo AND Pr.PropId = 5
        JOIN Authors A ON Pr.PropValue = A.Name
        JOIN Properties Pr2 ON P.Pubno = Pr2.PubNo AND Pr2.PropId = 13
        JOIN Securities2 S ON Pr2.PropValue = S.Ticker
        WHERE
          P.Type = 'Research Call' AND
          A.AuthorId = @AnalystId AND
          S.SecurityId = @SecurityId AND
          P.Date = @DropDate
      END

      --If Call does not exist for drop date then rollback
      IF (@PubNo is null)
      BEGIN
          ROLLBACK TRANSACTION
          RETURN -1
      END

      --If Call exists for drop date
      --  * Set the Coverage Action to Drop or Suspend
      --  * Set the Rating Action to Drop
      IF ((@SecurityId is not null) AND (@SecurityId > 1))
      BEGIN
        IF @DropInd = 'S'
          SELECT @CoverageAction = 'Suspend', @RatingAction = 'Drop'
        ELSE
          SELECT @CoverageAction = 'Drop', @RatingAction = 'Drop'

        UPDATE PublicationFinancials
        SET CoverageAction = @CoverageAction, RatingAction = @RatingAction
        WHERE
          PubNo = @PubNo AND
          Ticker = (SELECT Ticker FROM Securities2 WHERE SecurityId = @SecurityId)
      END
    END
  END
ELSE
  -- NEW COVERAGE
  BEGIN
    INSERT INTO ResearchCoverage (IndustryId, AnalystId, SecurityId, LaunchDate, LaunchInd, DropDate, DropInd, EditorId, EditDate, ModelDistribution)
    VALUES (@IndustryId, @AnalystId, @SecurityId, @LaunchDate, @LaunchInd, @DropDate, @DropInd, @EditorId, @EditDate, 'Y')
    SELECT @CoverageId = @@IDENTITY

    SELECT @MsgNew = I.IndustryName + ' | ' + A.Last + ' | ' + ISNULL(S.Ticker, '-')
    FROM ResearchCoverage RC
    JOIN Industries I ON I.IndustryId = RC.IndustryId
    JOIN Authors A ON A.AuthorId = RC.AnalystId
    LEFT JOIN Securities2 S ON S.SecurityId = RC.SecurityId
    WHERE RC.CoverageId = @CoverageId

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Coverage', 'A', @MsgNew, null, @CoverageId, @EditorId, @EditDate)

    -- When new coverage is added:
    -- 1) Initialize FinancialCompanySettings (TickerTableEps, TickerTableValuation, BaseYear & BaseQuarter)
    -- 2) Initialize FinancialSecuritySettings (Model Currency, Model Units)
    -- 3) Exclude EPS Alternate from estimate set
    DECLARE @BaseYear char(4), @BaseQuarter char(2), @TickerTableEpsId int, @TickerTableValuationId int, @UnitMultiplier bigint,@EPSAltId int

    SELECT @BaseYear = convert(varchar,datepart(yy,@EditDate) - 1), @BaseQuarter = 'Q1', @UnitMultiPlier = 1000000
    SELECT @TickerTableEpsId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'EPSRPT'
    SELECT @TickerTableValuationId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'P/EPSRPT'
    SELECT @EPSAltId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'EPS_ALT'

    --While adding a secondary ticker to coverage do not insert row into FinancialCompanySettings table (as parent ticker setup added the required row)
    IF NOT EXISTS(SELECT * FROM FinancialCompanySettings FCS JOIN Securities2 S ON FCS.CompanyId = S.CompanyId WHERE S.SecurityId = @SecurityId)
    BEGIN
      INSERT INTO dbo.FinancialCompanySettings(CompanyId,TickerTableEpsId,TickerTableValuationId,BaseYear,BaseQuarter,EditorId,EditDate)
      SELECT S.CompanyId,@TickerTableEpsId,@TickerTableValuationId,@BaseYear,@BaseQuarter,@EditorId,@EditDate
      FROM Securities2 S
      WHERE S.SecurityId = @SecurityId
    END

    IF NOT EXISTS(SELECT * FROM FinancialSecuritySettings WHERE SecurityId = @SecurityId)
    BEGIN
      INSERT INTO dbo.FinancialSecuritySettings(SecurityId,CurCode,UnitMultiplier,EditorId,EditDate)
      SELECT @SecurityId,CurrencyCode,@UnitMultiPlier,@EditorId,@EditDate
      FROM Securities2 S
      WHERE S.SecurityId = @SecurityId
    END

    --While adding a secondary ticker to coverage do not insert eps_alt exclusion row into FinancialSetExclusions table (as parent ticker setup added the required row)
    IF NOT EXISTS(SELECT * FROM FinancialSetExclusions FCS JOIN Securities2 S ON FCS.CompanyId = S.CompanyId WHERE S.SecurityId = @SecurityId AND FinancialNumberTypeId = @EPSAltId)
    BEGIN
      INSERT INTO dbo.FinancialSetExclusions(CompanyId,FinancialNumberTypeId,EditorId,EditDate)
      SELECT S.CompanyId,@EPSAltId,@EditorId,@EditDate
      FROM Securities2 S
      WHERE S.SecurityId = @SecurityId
    END
  END
END TRY
BEGIN CATCH
  IF @@TRANCOUNT > 0
  ROLLBACK TRANSACTION
END CATCH
  IF @@TRANCOUNT > 0
  COMMIT TRANSACTION
RETURN 0
go

grant execute on dbo.spRenderEpsTypes to DE_IIS, PowerUsers
grant execute on dbo.spRenderValuationTypes to DE_IIS, PowerUsers
grant execute on dbo.spSaveModelDistributionStatus to DE_IIS, PowerUsers
go

/*

-- DEBUG

spSearchAnalystSettings 22, 'a', 1, 5000, null, null

  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT,
  @AnalystId     int

*/
