-- LaunchFix.sql
-- 06/26/2019

/*
Missing Currency symbol for Target Price for an initiate call

alter proc spGetCompanyRatingXml    @InXml TEXT
*/
GO

ALTER PROCEDURE [dbo].[spGetCompanyRatingXml]
  @InXml TEXT
AS

SET NOCOUNT ON

DECLARE @CompanyId            INT,
        @Company              VARCHAR(60),
        @PrimarySecurityId    INT,
        @Industry             VARCHAR(50),
        @RatingCount          INT,
        @PrimaryTicker        VARCHAR(15),
        @Analyst              VARCHAR(48),
        @hDoc                 INT,
        @Date                 DATETIME,
        @Type                 VARCHAR(31),
        @Title                VARCHAR(255),
        @RptPubNo             INT,
        @Version              INT,
        @SecurityId           INT,
        @Ticker               VARCHAR(15),
        @IsEstimatesScreen    VARCHAR(5),
        @CompanyHeaderRow     VARCHAR(4000),
        @FinancialsXml        XML,
        @PublicationsXml      XML,
        @CompanyFinancialXml  VARCHAR(MAX)

EXEC sp_xml_preparedocument @hDoc OUTPUT, @InXml

SELECT @Date = X.Date, @Type = X.Type, @Title = X.Title
FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
WITH (Date datetime '@pubDate', Type varchar(31) '@type', Title varchar(255) '@title' ) X

EXEC spCheckForResubmits @Date, @Type, @Title, @RptPubNo OUTPUT, @Version OUTPUT

SELECT
  ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo,
  S.SecurityId, X.Ticker, X.IndicateChange, S.Company, S.CompanyId,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'live', @RptPubNo) AS SourceLive,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'old', @RptPubNo)  AS SourceOld,
  ISNULL(X.LastPubNo, '') AS LastChangePubNo,
  CASE WHEN X.CoverageId IS NULL OR X.CoverageId = '' OR X.CoverageId = '0' THEN RC.CoverageId
       ELSE X.CoverageId
  END AS CoverageId,
  S.OrdNo, S.Alias, S.CurrencyCode
INTO #TickerList
FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
WITH (SecurityId int '@id', Ticker varchar(30) '@ticker', IndicateChange  varchar(30) '@indicateChange', LastPubNo int '@optLastPubNo', CoverageId INT '@coverageId') X
INNER JOIN Securities2 S ON S.Ticker = X.Ticker
INNER JOIN ResearchCoverage RC ON RC.SecurityId = S.SecurityId AND RC.DropDate IS NULL

-- Get the Company of the first ticker in the list
SELECT TOP 1 @SecurityId = SecurityId, @Ticker = Ticker, @CompanyId = CompanyId, @Company = Company FROM #TickerList

IF NOT EXISTS(SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
BEGIN
  SELECT '<NotExist>' + 'Missing Company for provided Ticker. Security Id:' + CONVERT(VARCHAR, @SecurityId) + '</NotExist>' AS XML
  RETURN
END

SELECT @IsEstimatesScreen = X.IsEstimatesScreen
FROM OPENXML (@hDoc, 'DocumentInfo/Securities', 1)
WITH (IsEstimatesScreen varchar(5) '@isEstimatesScreen') X

-- Remove Tickers from the list not for the first ticker company
DELETE FROM #TickerList WHERE CompanyId != @CompanyId

-- Remove Tickers from the list > first 2 tickers in the list for that company
DELETE FROM #TickerList WHERE DisplayNo NOT IN (SELECT TOP 2 DisplayNo FROM  #TickerList ORDER BY DisplayNo ASC)

-- Get Primary, Secondary Ticker, Industry for the Company
IF EXISTS(SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
  SELECT @PrimarySecurityId = SecurityId, @PrimaryTicker =  Ticker
  FROM Securities2 WHERE CompanyId = @CompanyId AND IsPrimary = 'Y'
ELSE
  SELECT @PrimarySecurityId = @SecurityId, @PrimaryTicker = ''

SELECT @Industry = I.IndustryName FROM ResearchCoverage RC JOIN Industries I ON I.IndustryId = RC.IndustryId WHERE RC.SecurityId = @PrimarySecurityId AND RC.DropDate IS NULL
SELECT @Analyst = A.First + ' ' + A.Last FROM ResearchCoverage RC JOIN Authors A ON A.AuthorId = RC.AnalystId AND RC.SecurityId = @PrimarySecurityId AND RC.DropDate IS NULL

-- Analyst data - Draft and Published value rowset
SELECT
  TL.Ticker,
  TL.SecurityId,
  FNT.FinancialNumberTypeId,
  FNT.FinancialNumberType,
  TL.CurrencyCode AS CurCode,
  FN.FinancialPeriodId,
  CONVERT(VARCHAR,FN.Value)  AS LiveValue,
  CONVERT(VARCHAR,FN2.Value) AS DraftValue,
  (CASE WHEN FNT.FinancialNumberType = 'RATING' THEN ( SELECT RatingText FROM Ratings WHERE Rating = FN.Value)
        ELSE ''
   END) AS LiveValueText,
  (CASE WHEN FNT.FinancialNumberType = 'RATING' THEN ( SELECT RatingText FROM Ratings WHERE Rating = FN2.Value)
        ELSE ''
   END) AS DraftValueText,
  FN.BaseYear,
  FN.PeriodYear,
  FNT.ShortName AS Description,
  -- Get Alias only from text
  substring(TL.Alias,charindex('(', TL.Alias),len(TL.Alias)+ 1 - charindex('(', TL.Alias)) AS Alias,
  TL.OrdNo
INTO #TmpAnalystDataDraftLive
FROM #TickerList TL
INNER JOIN FinancialNumberTypes FNT ON FNT.FinancialNumberType IN ('RATING', 'TARGETPRICE')
-- Only data for active ticker coverage (not dropped/suspended) using active CoverageId
LEFT JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = TL.SecurityId
                                     AND FN.CoverageId = TL.CoverageId
                                     AND FN.FinancialNumberTypeId  = FNT.FinancialNumberTypeId
                                     AND FN.IsDraft = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                     AND FN2.CoverageId = TL.CoverageId
                                     AND FN2.FinancialNumberTypeId = FNT.FinancialNumberTypeId
                                     AND FN2.IsDraft = 1  -- Draft
WHERE TL.SecurityId IN (SELECT SecurityId FROM Securities2 WHERE CompanyId = @CompanyId)

-- Get Rating Count for this Company
SELECT @RatingCount = COUNT(Distinct(R.Value))
FROM (  SELECT
        TA.SecurityID              AS SecurityId,
        -- Rating value, take draft else live
        MAX(CASE WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN DraftValue
                 WHEN LiveValue  IS NOT NULL THEN LiveValue
                 ELSE ''
            END) AS Value
        FROM #TmpAnalystDataDraftLive TA
        INNER JOIN #TickerList TL ON TL.SecurityId = TA.SecurityId
        WHERE FinancialNumberType = 'RATING'
        GROUP BY TA.SecurityId
      ) R

-- Get Latest Financials data in a XML variable
SET @FinancialsXml =
(
SELECT * FROM
(
-- Returns Analyst data (1-2 Tickers) [RATING, TARGETPRICE]
SELECT
  1                      AS tag,
  null                   AS parent,
  @Company               AS [Company!1!company],
  @CompanyId             AS [Company!1!companyId],
  @Industry              AS [Company!1!industry],
  @RatingCount           AS [Company!1!ratingCount],
  CASE WHEN @IsEstimatesScreen = 'yes' THEN @Ticker
       ELSE @PrimaryTicker
  END                    AS [Company!1!ticker],
  @Analyst               AS [Company!1!analyst],
  @SecurityId            AS [Company!1!paramSecurityId],
  NULL                   AS [CompanyRow!2!ticker],
  NULL                   AS [CompanyRow!2!alias],
  NULL                   AS [CompanyRow!2!securityId],
  NULL                   AS [CompanyRow!2!financialNumberType],
  NULL                   AS [CompanyRow!2!value],
  NULL                   AS [CompanyRow!2!old],
  NULL                   AS [CompanyRow!2!textValue],
  NULL                   AS [CompanyRow!2!textOld],
  NULL                   AS [CompanyRow!2!isDraft],
  NULL                   AS [CompanyRow!2!isBold],
  NULL                   AS [CompanyRow!2!currency],
  NULL                   AS [CompanyRow!2!dispOrder]

UNION ALL

-- Both Tickers
-- IF @IndicateChange = 'yes' and Draft exists THEN display Draft, ELSE published
SELECT
  2                       AS tag,
  1                       AS parent,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  MAX(TA.Ticker)          AS [CompanyRow!2!ticker],
  MAX(TL.Alias)           AS [CompanyRow!2!alias],
  TA.SecurityID           AS [CompanyRow!2!securityId],
  TA.FinancialNumberType     AS [CompanyRow!2!financialNumberType],

  -- rating / target price value
  MAX(CASE WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN DraftValue
           WHEN LiveValue  IS NOT NULL THEN LiveValue
           ELSE ''
      END) AS [CompanyRow!2!value],
  MAX(CASE
    WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN LiveValue
  END)     AS [CompanyRow!2!old],

  -- Rating only text for display
  MAX(CASE WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN DraftValueText
           WHEN LiveValue  IS NOT NULL THEN LiveValueText
           ELSE ''
      END) AS [CompanyRow!2!textValue],
  MAX(CASE
    WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN LiveValueText
  END)     AS [CompanyRow!2!textOld],

  -- rating / target price value - draft[1] or live[0]
  MAX(CASE
    WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN 1
    WHEN LiveValue  IS NOT NULL                         THEN 0
  END)                      AS [CompanyRow!2!isDraft],
  MAX(CASE
    WHEN LiveValue  IS NOT NULL AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN 'Y'
    ELSE 'N'
  END)                      AS [CompanyRow!2!isBold],
  MAX(TA.CurCode)           AS [CompanyRow!2!currency],
  MAX(TL.OrdNo)             AS [CompanyRow!2!dispOrder]
FROM #TmpAnalystDataDraftLive TA
INNER JOIN #TickerList TL ON TL.SecurityId = TA.SecurityId
GROUP BY TA.SecurityId, TA.FinancialNumberType

) X
ORDER BY tag, [CompanyRow!2!dispOrder], [CompanyRow!2!financialNumberType]
FOR XML Explicit
)

-- For v1(IndicateChange=no,yes), use the latest FinancialNumbers data - applicable for ticker table UI screens or from word template
If @RptPubNo = 0 AND NOT EXISTS(SELECT * FROM #TickerList WHERE IndicateChange = 'last')
BEGIN
  SELECT @FinancialsXml
  RETURN
END

-- Get the PublicationsXml
SELECT @PublicationsXml = CompanyFinancialsXml FROM PublicationsXML  WHERE PubNo = @RptPubNo

-- Add column to store the Ticker Table XML for tickers with indicateChange="last" [lastChangePubNo]
ALTER TABLE #TickerList ADD LastChangeTickerTableXml XML

-- Update Ticker Table XML for tickers with indicateChange="last"
UPDATE #TickerList
SET #TickerList.LastChangeTickerTableXml = PX2.CompanyFinancialsXml
FROM PublicationsXML PX2
WHERE PX2.PubNo = #TickerList.LastChangePubNo

-- Selectively fetch applicable rows (by ticker) from one of the 3 xml sources
-- Source: FinancialsXml
SELECT
  CONVERT(varchar(MAX),F.c.query('.')) AS result,
  TL.DisplayNo AS dispOrder
INTO #CompanyFinancialXml
FROM #TickerList TL
JOIN @FinancialsXml.nodes('/Company/CompanyRow') F(c)
     ON TL.SecurityId = CAST(F.c.value('@securityId', 'INT') AS INT)
WHERE TL.SourceLive = 'FN'

UNION

-- Source: PublicationsXml for last Report
SELECT
  CONVERT(varchar(MAX),P.Loc.query('.')) AS result,
  TL.DisplayNo AS dispOrder
FROM #TickerList TL
JOIN @PublicationsXml.nodes('/CompanyFinancials/Company/CompanyRow') P(Loc)
     ON TL.SecurityId = CAST(P.Loc.value('@securityId', 'INT') AS INT)
WHERE TL.SourceLive = 'PX'

UNION

-- Source: @PublicationsXml for last Change Report
SELECT
  CONVERT(varchar(MAX),P2.Loc.query('.')) AS result,
  TL.DisplayNo AS dispOrder
FROM #TickerList TL
CROSS APPLY TL.LastChangeTickerTableXml.nodes('/CompanyFinancials/Company/CompanyRow') AS P2(Loc)
WHERE TL.SecurityId = CAST(P2.Loc.value('@securityId', 'INT') AS INT)
AND TL.SourceLive = 'PXLAST'

ORDER BY 2

SET @CompanyHeaderRow = '<Company company="' + [dbo].[fnCheckSpecialCharacters](@Company) + '"'
SET @CompanyHeaderRow = @CompanyHeaderRow + ' companyId="' + CONVERT(varchar, @CompanyId) + '"'
SET @CompanyHeaderRow = @CompanyHeaderRow + ' industry="' + [dbo].[fnCheckSpecialCharacters](@Industry) + '"'
SET @CompanyHeaderRow = @CompanyHeaderRow + ' ratingCount="' + CONVERT(varchar, @RatingCount) + '"'
IF @IsEstimatesScreen = 'yes'
  SET @CompanyHeaderRow = @CompanyHeaderRow + ' ticker="' + [dbo].[fnCheckSpecialCharacters](@Ticker) + '"'
ELSE
  SET @CompanyHeaderRow = @CompanyHeaderRow + ' ticker="' + [dbo].[fnCheckSpecialCharacters](@PrimaryTicker) + '"'

SET @CompanyHeaderRow = @CompanyHeaderRow + ' analyst="' + [dbo].[fnCheckSpecialCharacters](@Analyst) + '"'
SET @CompanyHeaderRow = @CompanyHeaderRow + ' paramSecurityId="' + CONVERT(varchar, @SecurityId) + '">'

-- Combine individual ticker rows as one string
SELECT @CompanyFinancialXml = STUFF(
                        (SELECT CHAR(13) + result
                           FROM #CompanyFinancialXml
                            FOR XML PATH(''),type).value('.','NVARCHAR(MAX)'),1,1,'')
SET @CompanyFinancialXml = @CompanyHeaderRow + CHAR(13) + @CompanyFinancialXml + CHAR(13) + '</Company>'

SELECT CAST(@CompanyFinancialXml AS XML)

SET NOCOUNT OFF





GO

-- DEBUG
/*
DECLARE  @xml varchar(MAX)
SET @xml =
'<DocumentInfo>
 <DocumentSection title="" pubDate="" type=""/>
  <Securities>
    <Security id= "2307" ticker="ATHM" indicateChange="yes" />
    <Security id= "1288" ticker="2303.TT" indicateChange="yes" />
 </Securities>
</DocumentInfo>'

EXEC spGetCompanyRatingXml @xml
GO
*/