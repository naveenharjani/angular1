-- GICS_2018_Updates_Rollback.sql
-- 09/19/2018

USE Research
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- Temporarily disable foreign key constraint
ALTER TABLE [dbo].[Securities2] NOCHECK CONSTRAINT [FK_Securities_GICS]
GO
DELETE FROM [dbo].[GICS]
GO

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 10, 'Energy' , 1010, 'Energy' , 101010, 'Energy Equipment & Services' , 10101010, 'Oil & Gas Drilling' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 10, 'Energy' , 1010, 'Energy' , 101010, 'Energy Equipment & Services' , 10101020, 'Oil & Gas Equipment & Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 10, 'Energy' , 1010, 'Energy' , 101020, 'Oil, Gas & Consumable Fuels' , 10102010, 'Integrated Oil & Gas' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 10, 'Energy' , 1010, 'Energy' , 101020, 'Oil, Gas & Consumable Fuels' , 10102020, 'Oil & Gas Exploration & Production' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 10, 'Energy' , 1010, 'Energy' , 101020, 'Oil, Gas & Consumable Fuels' , 10102030, 'Oil & Gas Refining & Marketing' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 10, 'Energy' , 1010, 'Energy' , 101020, 'Oil, Gas & Consumable Fuels' , 10102040, 'Oil & Gas Storage & Transportation' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 10, 'Energy' , 1010, 'Energy' , 101020, 'Oil, Gas & Consumable Fuels' , 10102050, 'Coal & Consumable Fuels' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151010, 'Chemicals' , 15101010, 'Commodity Chemicals' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151010, 'Chemicals' , 15101020, 'Diversified Chemicals' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151010, 'Chemicals' , 15101030, 'Fertilizers & Agricultural Chemicals' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151010, 'Chemicals' , 15101040, 'Industrial Gases' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151010, 'Chemicals' , 15101050, 'Specialty Chemicals' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151020, 'Construction Materials' , 15102010, 'Construction Materials' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151030, 'Containers & Packaging' , 15103010, 'Metal & Glass Containers' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151030, 'Containers & Packaging' , 15103020, 'Paper Packaging' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151040, 'Metals & Mining' , 15104010, 'Aluminum' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151040, 'Metals & Mining' , 15104020, 'Diversified Metals & Mining' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151040, 'Metals & Mining' , 15104025, 'Copper' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151040, 'Metals & Mining' , 15104030, 'Gold' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151040, 'Metals & Mining' , 15104040, 'Precious Metals & Minerals' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151040, 'Metals & Mining' , 15104045, 'Silver' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151040, 'Metals & Mining' , 15104050, 'Steel' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151050, 'Paper & Forest Products' , 15105010, 'Forest Products' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 15, 'Materials' , 1510, 'Materials' , 151050, 'Paper & Forest Products' , 15105020, 'Paper Products' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2010, 'Capital Goods' , 201010, 'Aerospace & Defense' , 20101010, 'Aerospace & Defense' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2010, 'Capital Goods' , 201020, 'Building Products' , 20102010, 'Building Products' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2010, 'Capital Goods' , 201030, 'Construction & Engineering' , 20103010, 'Construction & Engineering' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2010, 'Capital Goods' , 201040, 'Electrical Equipment' , 20104010, 'Electrical Components & Equipment' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2010, 'Capital Goods' , 201040, 'Electrical Equipment' , 20104020, 'Heavy Electrical Equipment' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2010, 'Capital Goods' , 201050, 'Industrial Conglomerates' , 20105010, 'Industrial Conglomerates' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2010, 'Capital Goods' , 201060, 'Machinery' , 20106010, 'Construction Machinery & Heavy Trucks' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2010, 'Capital Goods' , 201060, 'Machinery' , 20106015, 'Agricultural & Farm Machinery' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2010, 'Capital Goods' , 201060, 'Machinery' , 20106020, 'Industrial Machinery' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2010, 'Capital Goods' , 201070, 'Trading Companies & Distributors' , 20107010, 'Trading Companies & Distributors' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2020, 'Commercial & Professional Services' , 202010, 'Commercial Services & Supplies' , 20201010, 'Commercial Printing' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2020, 'Commercial & Professional Services' , 202010, 'Commercial Services & Supplies' , 20201050, 'Environmental & Facilities Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2020, 'Commercial & Professional Services' , 202010, 'Commercial Services & Supplies' , 20201060, 'Office Services & Supplies' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2020, 'Commercial & Professional Services' , 202010, 'Commercial Services & Supplies' , 20201070, 'Diversified Support Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2020, 'Commercial & Professional Services' , 202010, 'Commercial Services & Supplies' , 20201080, 'Security & Alarm Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2020, 'Commercial & Professional Services' , 202020, 'Professional Services' , 20202010, 'Human Resource & Employment Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2020, 'Commercial & Professional Services' , 202020, 'Professional Services' , 20202020, 'Research & Consulting Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2030, 'Transportation' , 203010, 'Air Freight & Logistics' , 20301010, 'Air Freight & Logistics' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2030, 'Transportation' , 203020, 'Airlines' , 20302010, 'Airlines' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2030, 'Transportation' , 203030, 'Marine' , 20303010, 'Marine' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2030, 'Transportation' , 203040, 'Road & Rail' , 20304010, 'Railroads' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2030, 'Transportation' , 203040, 'Road & Rail' , 20304020, 'Trucking' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2030, 'Transportation' , 203050, 'Transportation Infrastructure' , 20305010, 'Airport Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2030, 'Transportation' , 203050, 'Transportation Infrastructure' , 20305020, 'Highways & Railtracks' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 20, 'Industrials' , 2030, 'Transportation' , 203050, 'Transportation Infrastructure' , 20305030, 'Marine Ports & Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2510, 'Automobiles & Components' , 251010, 'Auto Components' , 25101010, 'Auto Parts & Equipment' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2510, 'Automobiles & Components' , 251010, 'Auto Components' , 25101020, 'Tires & Rubber' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2510, 'Automobiles & Components' , 251020, 'Automobiles' , 25102010, 'Automobile Manufacturers' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2510, 'Automobiles & Components' , 251020, 'Automobiles' , 25102020, 'Motorcycle Manufacturers' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2520, 'Consumer Durables & Apparel' , 252010, 'Household Durables' , 25201010, 'Consumer Electronics' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2520, 'Consumer Durables & Apparel' , 252010, 'Household Durables' , 25201020, 'Home Furnishings' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2520, 'Consumer Durables & Apparel' , 252010, 'Household Durables' , 25201030, 'Homebuilding' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2520, 'Consumer Durables & Apparel' , 252010, 'Household Durables' , 25201040, 'Household Appliances' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2520, 'Consumer Durables & Apparel' , 252010, 'Household Durables' , 25201050, 'Housewares & Specialties' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2520, 'Consumer Durables & Apparel' , 252020, 'Leisure Products' , 25202010, 'Leisure Products' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2520, 'Consumer Durables & Apparel' , 252030, 'Textiles, Apparel & Luxury Goods' , 25203010, 'Apparel, Accessories & Luxury Goods' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2520, 'Consumer Durables & Apparel' , 252030, 'Textiles, Apparel & Luxury Goods' , 25203020, 'Footwear' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2520, 'Consumer Durables & Apparel' , 252030, 'Textiles, Apparel & Luxury Goods' , 25203030, 'Textiles' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2530, 'Consumer Services' , 253010, 'Hotels, Restaurants & Leisure' , 25301010, 'Casinos & Gaming' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2530, 'Consumer Services' , 253010, 'Hotels, Restaurants & Leisure' , 25301020, 'Hotels, Resorts & Cruise Lines' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2530, 'Consumer Services' , 253010, 'Hotels, Restaurants & Leisure' , 25301030, 'Leisure Facilities' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2530, 'Consumer Services' , 253010, 'Hotels, Restaurants & Leisure' , 25301040, 'Restaurants' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2530, 'Consumer Services' , 253010, 'Hotels, Restaurants & Leisure' , 25302010, 'Education Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2530, 'Consumer Services' , 253010, 'Hotels, Restaurants & Leisure' , 25302020, 'Specialized Consumer Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2540, 'Media' , 254010, 'Media' , 25401010, 'Advertising' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2540, 'Media' , 254010, 'Media' , 25401020, 'Broadcasting' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2540, 'Media' , 254010, 'Media' , 25401025, 'Cable & Satellite' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2540, 'Media' , 254010, 'Media' , 25401030, 'Movies & Entertainment' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2540, 'Media' , 254010, 'Media' , 25401040, 'Publishing' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255010, 'Distributors' , 25501010, 'Distributors' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255020, 'Internet & Direct Marketing Retail' , 25502010, 'Catalog Retail - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255020, 'Internet & Direct Marketing Retail' , 25502020, 'Internet & Direct Marketing Retail' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255030, 'Multiline Retail' , 25503010, 'Department Stores' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255030, 'Multiline Retail' , 25503020, 'General Merchandise Stores' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255040, 'Specialty Retail' , 25504010, 'Apparel Retail' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255040, 'Specialty Retail' , 25504020, 'Computer & Electronics Retail' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255040, 'Specialty Retail' , 25504030, 'Home Improvement Retail' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255040, 'Specialty Retail' , 25504040, 'Specialty Stores' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255040, 'Specialty Retail' , 25504050, 'Automotive Retail' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 25, 'Consumer Discretionary' , 2550, 'Retailing' , 255040, 'Specialty Retail' , 25504060, 'Homefurnishing Retail' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3010, 'Food & Staples Retailing' , 301010, 'Food & Staples Retailing' , 30101010, 'Drug Retail' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3010, 'Food & Staples Retailing' , 301010, 'Food & Staples Retailing' , 30101020, 'Food Distributors' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3010, 'Food & Staples Retailing' , 301010, 'Food & Staples Retailing' , 30101030, 'Food Retail' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3010, 'Food & Staples Retailing' , 301010, 'Food & Staples Retailing' , 30101040, 'Hypermarkets & Super Centers' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3020, 'Food, Beverage & Tobacco' , 302010, 'Beverages' , 30201010, 'Brewers' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3020, 'Food, Beverage & Tobacco' , 302010, 'Beverages' , 30201020, 'Distillers & Vintners' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3020, 'Food, Beverage & Tobacco' , 302010, 'Beverages' , 30201030, 'Soft Drinks' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3020, 'Food, Beverage & Tobacco' , 302020, 'Food Products' , 30202010, 'Agricultural Products' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3020, 'Food, Beverage & Tobacco' , 302020, 'Food Products' , 30202030, 'Packaged Foods & Meats' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3020, 'Food, Beverage & Tobacco' , 302030, 'Tobacco' , 30203010, 'Tobacco' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3030, 'Household & Personal Products' , 303010, 'Household Products' , 30301010, 'Household Products' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 30, 'Consumer Staples' , 3030, 'Household & Personal Products' , 303020, 'Personal Products' , 30302010, 'Personal Products' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 35, 'Health Care' , 3510, 'Health Care Equipment & Services' , 351010, 'Health Care Equipment & Supplies' , 35101010, 'Health Care Equipment' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 35, 'Health Care' , 3510, 'Health Care Equipment & Services' , 351010, 'Health Care Equipment & Supplies' , 35101020, 'Health Care Supplies' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 35, 'Health Care' , 3510, 'Health Care Equipment & Services' , 351020, 'Health Care Providers & Services' , 35102010, 'Health Care Distributors' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 35, 'Health Care' , 3510, 'Health Care Equipment & Services' , 351020, 'Health Care Providers & Services' , 35102015, 'Health Care  Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 35, 'Health Care' , 3510, 'Health Care Equipment & Services' , 351020, 'Health Care Providers & Services' , 35102020, 'Health Care Facilities' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 35, 'Health Care' , 3510, 'Health Care Equipment & Services' , 351020, 'Health Care Providers & Services' , 35102030, 'Managed Health Care' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 35, 'Health Care' , 3510, 'Health Care Equipment & Services' , 351030, 'Health Care Technology' , 35103010, 'Health Care Technology' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 35, 'Health Care' , 3520, 'Pharmaceuticals, Biotechnology & Life Sciences' , 352010, 'Biotechnology' , 35201010, 'Biotechnology' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 35, 'Health Care' , 3520, 'Pharmaceuticals, Biotechnology & Life Sciences' , 352020, 'Pharmaceuticals' , 35202010, 'Pharmaceuticals' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 35, 'Health Care' , 3520, 'Pharmaceuticals, Biotechnology & Life Sciences' , 352030, 'Life Sciences Tools & Services' , 35203010, 'Life Sciences Tools & Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4010, 'Banks' , 401010, 'Banks' , 40101010, 'Diversified Banks' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4010, 'Banks' , 401010, 'Banks' , 40101015, 'Regional Banks' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4010, 'Banks' , 401020, 'Thrifts & Mortgage Finance' , 40102010, 'Thrifts & Mortgage Finance' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4020, 'Diversified Financials' , 402010, 'Diversified Financial Services' , 40201020, 'Other Diversified Financial Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4020, 'Diversified Financials' , 402010, 'Diversified Financial Services' , 40201030, 'Multi-Sector Holdings' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4020, 'Diversified Financials' , 402010, 'Diversified Financial Services' , 40201040, 'Specialized Finance' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4020, 'Diversified Financials' , 402020, 'Consumer Finance' , 40202010, 'Consumer Finance' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4020, 'Diversified Financials' , 402030, 'Capital Markets' , 40203010, 'Asset Management & Custody Banks' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4020, 'Diversified Financials' , 402030, 'Capital Markets' , 40203020, 'Investment Banking & Brokerage' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4020, 'Diversified Financials' , 402030, 'Capital Markets' , 40203030, 'Diversified Capital Markets' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4020, 'Diversified Financials' , 402030, 'Capital Markets' , 40203040, 'Financial Exchanges & Data' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4020, 'Diversified Financials' , 402040, 'Mortgage Real Estate Investment Trusts (REITs)' , 40204010, 'Mortgage REITs'

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4030, 'Insurance' , 403010, 'Insurance' , 40301010, 'Insurance Brokers' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4030, 'Insurance' , 403010, 'Insurance' , 40301020, 'Life & Health Insurance' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4030, 'Insurance' , 403010, 'Insurance' , 40301030, 'Multi-line Insurance' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4030, 'Insurance' , 403010, 'Insurance' , 40301040, 'Property & Casualty Insurance' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4030, 'Insurance' , 403010, 'Insurance' , 40301050, 'Reinsurance' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404020, 'Real Estate Investment Trusts (REITs) - discontinued effective close of Aug 31, 2016' , 40402010, 'Diversified REIT''s - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404020, 'Real Estate Investment Trusts (REITs) - discontinued effective close of Aug 31, 2016' , 40402020, 'Industrial REIT''s - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404020, 'Real Estate Investment Trusts (REITs) - discontinued effective close of Aug 31, 2016' , 40402030, 'Mortgage REIT''s - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404020, 'Real Estate Investment Trusts (REITs) - discontinued effective close of Aug 31, 2016' , 40402035, 'Hotel & Resort REIT''s - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404020, 'Real Estate Investment Trusts (REITs) - discontinued effective close of Aug 31, 2016' , 40402040, 'Office REIT''s - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404020, 'Real Estate Investment Trusts (REITs) - discontinued effective close of Aug 31, 2016' , 40402045, 'Health Care REIT''s - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404020, 'Real Estate Investment Trusts (REITs) - discontinued effective close of Aug 31, 2016' , 40402050, 'Residential REIT''s - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404020, 'Real Estate Investment Trusts (REITs) - discontinued effective close of Aug 31, 2016' , 40402060, 'Retail REIT''s - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404020, 'Real Estate Investment Trusts (REITs) - discontinued effective close of Aug 31, 2016' , 40402070, 'Specialized REIT''s - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404030, 'Real Estate Management & Development - discontinued effective close of Aug 31, 2016' , 40403010, 'Diversified Real Estate Activities - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404030, 'Real Estate Management & Development - discontinued effective close of Aug 31, 2016' , 40403020, 'Real Estate Operating Companies - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404030, 'Real Estate Management & Development - discontinued effective close of Aug 31, 2016' , 40403030, 'Real Estate Development - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 40, 'Financials' , 4040, 'Real Estate - discontinued effective close of Aug 31, 2016' , 404030, 'Real Estate Management & Development - discontinued effective close of Aug 31, 2016' , 40403040, 'Real Estate Services - discontinued effective close of Aug 31, 2016' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4510, 'Software & Services' , 451010, 'Internet Software & Services' , 45101010, 'Internet Software & Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4510, 'Software & Services' , 451020, 'IT Services' , 45102010, 'IT Consulting & Other Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4510, 'Software & Services' , 451020, 'IT Services' , 45102020, 'Data Processing & Outsourced Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4510, 'Software & Services' , 451030, 'Software' , 45103010, 'Application Software' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4510, 'Software & Services' , 451030, 'Software' , 45103020, 'Systems Software' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4510, 'Software & Services' , 451030, 'Software' , 45103030, 'Home Entertainment Software' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4520, 'Technology Hardware & Equipment' , 452010, 'Communications Equipment' , 45201020, 'Communications Equipment' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4520, 'Technology Hardware & Equipment' , 452020, 'Technology Hardware, Storage & Peripherals' , 45202030, 'Technology Hardware, Storage & Peripherals' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4520, 'Technology Hardware & Equipment' , 452030, 'Electronic Equipment, Instruments & Components' , 45203010, 'Electronic Equipment & Instruments ' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4520, 'Technology Hardware & Equipment' , 452030, 'Electronic Equipment, Instruments & Components' , 45203015, 'Electronic Components' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4520, 'Technology Hardware & Equipment' , 452030, 'Electronic Equipment, Instruments & Components' , 45203020, 'Electronic Manufacturing Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4520, 'Technology Hardware & Equipment' , 452030, 'Electronic Equipment, Instruments & Components' , 45203030, 'Technology Distributors' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4530, 'Semiconductors & Semiconductor Equipment' , 453010, 'Semiconductors & Semiconductor Equipment' , 45301010, 'Semiconductor Equipment ' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 45, 'Information Technology' , 4530, 'Semiconductors & Semiconductor Equipment' , 453010, 'Semiconductors & Semiconductor Equipment' , 45301020, 'Semiconductors' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 50, 'Telecommunication Services' , 5010, 'Telecommunication Services' , 501010, 'Diversified Telecommunication Services' , 50101010, 'Alternative Carriers' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 50, 'Telecommunication Services' , 5010, 'Telecommunication Services' , 501010, 'Diversified Telecommunication Services' , 50101020, 'Integrated Telecommunication Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 50, 'Telecommunication Services' , 5010, 'Telecommunication Services' , 501020, 'Wireless Telecommunication Services' , 50102010, 'Wireless Telecommunication Services' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 55, 'Utilities' , 5510, 'Utilities' , 551010, 'Electric Utilities' , 55101010, 'Electric Utilities' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 55, 'Utilities' , 5510, 'Utilities' , 551020, 'Gas Utilities' , 55102010, 'Gas Utilities' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 55, 'Utilities' , 5510, 'Utilities' , 551030, 'Multi-Utilities' , 55103010, 'Multi-Utilities' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 55, 'Utilities' , 5510, 'Utilities' , 551040, 'Water Utilities' , 55104010, 'Water Utilities' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 55, 'Utilities' , 5510, 'Utilities' , 551050, 'Independent Power and Renewable Electricity Producers' , 55105010, 'Independent Power Producers & Energy Traders' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 55, 'Utilities' , 5510, 'Utilities' , 551050, 'Independent Power and Renewable Electricity Producers' , 55105020, 'Renewable Electricity' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601010, 'Equity Real Estate Investment Trusts (REITs)' , 60101010, 'Diversified REITs'

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601010, 'Equity Real Estate Investment Trusts (REITs)' , 60101020, 'Industrial REITs'

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601010, 'Equity Real Estate Investment Trusts (REITs)' , 60101030, 'Hotel & Resort REITs'

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601010, 'Equity Real Estate Investment Trusts (REITs)' , 60101040, 'Office REITs '

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601010, 'Equity Real Estate Investment Trusts (REITs)' , 60101050, 'Health Care REITs '

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601010, 'Equity Real Estate Investment Trusts (REITs)' , 60101060, 'Residential REITs'

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601010, 'Equity Real Estate Investment Trusts (REITs)' , 60101070, 'Retail REITs'

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601010, 'Equity Real Estate Investment Trusts (REITs)' , 60101080, 'Specialized REITs '

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601020, 'Real Estate Management & Development' , 60102010, 'Diversified Real Estate Activities ' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601020, 'Real Estate Management & Development' , 60102020, 'Real Estate Operating Companies' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601020, 'Real Estate Management & Development' , 60102030, 'Real Estate Development ' 

INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry]) SELECT 60, 'Real Estate' , 6010, 'Real Estate' , 601020, 'Real Estate Management & Development' , 60102040, 'Real Estate Services ' 
GO

-- re-enable foreign key constraint
ALTER TABLE [dbo].[Securities2] CHECK CONSTRAINT [FK_Securities_GICS]
GO


/*
SELECT * FROM [dbo].[GICS] 
sp_help GICS

--Generate INSERT statements
SELECT 'INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry])
     SELECT ' + CAST(SectorId AS Varchar) + ', ''' + Sector + ''', ' +
                CAST(IndustryGroupId AS Varchar) + ', ''' + IndustryGroup + ''', ' +
                CAST(IndustryId AS Varchar) + ', ''' + Industry + ''', ' +
                CAST(SubIndustryId AS Varchar) + ', ''' + SubIndustry + ''''
FROM GICS

SELECT [SectorId]
      ,[Sector]
      ,[IndustryGroupId]
      ,[IndustryGroup]
      ,[IndustryId]
      ,[Industry]
      ,[SubIndustryId]
      ,[SubIndustry]
      ,
      'INSERT INTO [dbo].[GICS]([SectorId],[Sector],[IndustryGroupId],[IndustryGroup],[IndustryId],[Industry],[SubIndustryId],[SubIndustry])  SELECT ' + 
      CONVERT(varchar, SectorId) + ', ''' + Sector + ''', ' +
      CONVERT(varchar, IndustryGroupId) + ', ''' + IndustryGroup + ''', ' +
      CONVERT(varchar, IndustryId) + ', ''' + Industry + ''', ' +
      CONVERT(varchar, SubIndustryId) + ', ''' + SubIndustry + ''' '
  FROM [Research].[dbo].[GICS]

SELECT * FROM [dbo].[GICS_Bak]
-- SELECT * INTO [dbo].[GICS_Bak] FROM [dbo].[GICS]
*/