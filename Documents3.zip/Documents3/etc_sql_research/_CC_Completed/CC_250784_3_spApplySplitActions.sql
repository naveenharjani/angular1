-- spApplySplitActions.sql
-- 05/05/2017

/*

alter PublicationFinancials
alter spApplySplitActions

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM syscolumns WHERE name LIKE '%TargetPriceOrig%' AND id = OBJECT_ID('PublicationFinancials'))
ALTER TABLE PublicationFinancials DROP COLUMN TargetPriceOrig
GO

ALTER PROC [dbo].[spApplySplitActions] @SecurityId int = 0
AS
 -- ====================================================================================
 -- Author: Krishna Josyula
 -- Create date: 03/26/2008
 -- Description: Updates TargetPrice in TickerTableSecurities & TickerTablesecuritiesold
 --    Tables based on the split adjustment factor.
 -- Revised: 06/12/2013
 -- Apply splits only when the effective date of the split less than or equal to current date.
 -- Revised: 05/05/2017
 -- Apply splits to update EPS Reported and EPS Adjusted in FinancialNumbers & Publication Financials table
 -- ====================================================================================

BEGIN
DECLARE @AdjustmentFactor decimal(10,6)
DECLARE @EffectiveDate datetime
DECLARE @SplitActionId int
DECLARE @Ticker varchar(10)
DECLARE @FinancialNumberTypeId INT

SET NOCOUNT ON
IF @SecurityId = 0
  SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId
ELSE
  SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE SecurityId = @SecurityId and AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId

WHILE (@@rowcount > 0)
BEGIN

  --STEP 1:  Save pre-split values

  --Update TargetPriceOrig to original value in TickerTableSecurities, TickerTableSecuritiesOld
  --This is only done once for every qualified record

  Update TickerTableSecurities
  Set TargetPriceOrig = TargetPrice
  Where
   TargetPriceOrig is null and
   CloseDate <= @EffectiveDate and
   Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  Update TickerTableSecuritiesOld
  Set TargetPriceOrig = TTSO.TargetPrice
  From
   TickerTableSecurities TTS JOIN TickerTableSecuritiesOld TTSO ON TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
  Where
   TTSO.TargetPrice is not null and
   TTSO.TargetPrice <> '' and
   TTSO.TargetPriceOrig is null and
   TTS.CloseDate <= @EffectiveDate and
   TTSO.Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  --Update TargetPrice, EPS Reported and EPS Adusted to original value in FinancialNumbers
  --This is only done once for every qualified record

  update FinancialNumbers
  set ValueOrig = Value
  where SecurityId = @SecurityId
    and FinancialNumberTypeId in (select FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType in ('TARGETPRICE','EPSRPT','EPSADJ'))
    and IsDraft = 0
    and ValueOrig is null
    and Date <= @EffectiveDate
    and Date >= '2003-03-20'

  --STEP 2:  Apply split factor

  --Update TargetPrice & EPS columns with the adjustment factor for all the records in TickerTableSecurities, TickerTableSecuritiesOld, FinancialNumbers & PublicationFinancials
  --prior to the split date
  Update TickerTableSecurities
  Set TargetPrice  = case when isnumeric(TargetPrice) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TargetPrice) / @adjustmentfactor))) else TargetPrice end,
      EPSLastYear = case when isnumeric(EPSLastYear) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EPSLastYear) / @adjustmentfactor))) else EPSLastYear end,
      EPSThisYear = case when isnumeric(EPSThisYear) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EPSThisYear) / @adjustmentfactor))) else EPSThisYear end,
      EPSNextYear = case when isnumeric(EPSNextYear) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EPSNextYear) / @adjustmentfactor))) else EPSNextYear end
  Where
   CloseDate <= @EffectiveDate and
   Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  Update TickerTableSecuritiesOld
  Set TargetPrice  = case when isnumeric(TTSO.TargetPrice) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TTSO.TargetPrice) / @adjustmentfactor))) else TTSO.TargetPrice end,
      EPSThisYear = case when isnumeric(TTSO.EPSThisYear) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TTSO.EPSThisYear) / @adjustmentfactor)))  else TTSO.EPSThisYear end,
      EPSNextYear = case when isnumeric(TTSO.EPSNextYear) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TTSO.EPSNextYear) / @adjustmentfactor)))  else TTSO.EPSNextYear end
  From
   TickerTableSecurities TTS JOIN TickerTableSecuritiesOld TTSO ON TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
  Where
   TTSO.TargetPrice is not null and
   TTSO.TargetPrice <> '' and
   TTS.CloseDate <= @EffectiveDate and
   TTSO.Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  update FinancialNumbers
  set Value = case when isnumeric(Value) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),Value) / @adjustmentfactor))) else Value end,
      UnitValue = case when isnumeric(UnitValue) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),UnitValue) / @adjustmentfactor))) else UnitValue end
  where SecurityId = @SecurityId
  and FinancialNumberTypeId in (select FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType in ('TARGETPRICE','EPSRPT','EPSADJ'))
  and IsDraft = 0
  and Date <= @EffectiveDate
  and Date >= '2003-03-20'

  update PublicationFinancials
  set TargetPrice = case when isnumeric(TargetPrice) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TargetPrice) / @adjustmentfactor))) else TargetPrice end,
      EpsFY0 = case when isnumeric(EPSFY0) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EpsFY0) / @adjustmentfactor))) else EpsFY0 end,
      EpsFY1 = case when isnumeric(EPSFY1) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EpsFY1) / @adjustmentfactor))) else EPSFY1 end,
      EpsFY2 = case when isnumeric(EPSFY2) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EpsFY2) / @adjustmentfactor))) else EpsFY2 end
  where SecurityId = @SecurityId
  and CloseDate <= @EffectiveDate
  and CloseDate >= '2003-03-20'

  --STEP 3:  Mark split as applied

  --Update Status to 'Applied'
  update SplitActions
  set AppliedStatus = 'Y', AppliedDate = getdate()
  where SplitActionId = @SplitActionId

  IF @SecurityId = 0
    SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE SplitActionId > @SplitActionId AND AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId
  ELSE
    SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE SecurityId = @SecurityId AND SplitActionId > @SplitActionId and AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId

END
END
