-- spSaveSecurityCheckboxDisclosure.sql
-- 03/25/2019

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSaveSecurityCheckboxDisclosure]
  @SecurityId   int,
  @DisclosureId int,
  @Disclosure   smallint, -- Checked is -1
  @EditorId     int,
  @Ticker       varchar(15) OUTPUT
AS

DECLARE
@NewDisclosure varchar(2048),
@OldDisclosure varchar(2048),
@New varchar(100),
@Old varchar(100)

SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityId = @SecurityId

SELECT @NewDisclosure = Disclosure FROM SecurityCheckboxTypes WHERE DisclosureId = @DisclosureId
SELECT @OldDisclosure = SC.Disclosure FROM SecurityCheckboxDisclosures SCD
JOIN SecurityCheckboxTypes SC ON SCD.DisclosureId = SC.DisclosureId AND SCD.DisclosureId = @DisclosureId
WHERE SecurityId = @SecurityId

-- In case of long Disclosure text, limit to 97 characters text to fit into AdminLog
IF (LEN(@Ticker + ' | ' + @NewDisclosure) > 100)
SELECT @New = LEFT(@Ticker + ' | ' + @NewDisclosure, 97) + '...'
ELSE
SELECT @New = @Ticker + ' | ' + @NewDisclosure

IF (LEN(@Ticker + ' | ' + @OldDisclosure) > 100)
SELECT @Old = LEFT(@Ticker + ' | ' + @OldDisclosure, 97) + '...'
ELSE
SELECT @Old = @Ticker + ' | ' + @OldDisclosure

-- NO ROWS IMPLIES NO DISCLOSURE
IF @Disclosure = -1
  BEGIN
    IF NOT EXISTS (SELECT * FROM SecurityCheckboxDisclosures WHERE SecurityId = @SecurityId AND DisclosureId = @DisclosureId)
      BEGIN
      INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
      SELECT 'Disclosures | Firm', 'A', @New, NULL, @SecurityId, @EditorId, GETDATE()

      INSERT INTO SecurityCheckboxDisclosures (SecurityId, DisclosureId, EditorId, EditDate) VALUES (@SecurityId, @DisclosureId, @EditorId, GETDATE())
      END
  END
ELSE
  BEGIN
    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    SELECT 'Disclosures | Firm', 'D', '', @Old, @SecurityId, @EditorId, GETDATE()

    DELETE FROM SecurityCheckboxDisclosures WHERE SecurityId = @SecurityId AND DisclosureId = @DisclosureId
  END
RETURN 0

GO
