
USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM SYS.views WHERE name = 'RVLinkSources' AND type = 'V')
DROP VIEW [dbo].[RVLinkSources]
GO

IF EXISTS(SELECT * FROM SYS.views WHERE name = 'RVLinkProducts' AND type = 'V')
DROP VIEW [dbo].[RVLinkProducts]
GO

CREATE VIEW [dbo].[RVLinkSources] WITH SCHEMABINDING AS
SELECT
  SourceId,
  Source,
  SourceLaunchDate,
  EditorId,
  EditDate
FROM
  dbo.LinkSources
GO

CREATE UNIQUE CLUSTERED INDEX [RVLinkSources_SourceId] ON [dbo].[RVLinkSources]([SourceId] ASC) ON [PRIMARY]
GO