--spGetAuthorHoldings
--02/20/2019
--Updated:
--Includes holdings on autonomous tickers
USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE dbo.spGetAuthorHoldings(@DocXML xml)
AS
BEGIN
/*
Returns authors (Bern+Autonomous) holdings on tickers (Bern+Autonomous) in document xml
*/
DECLARE  @hDoc int,
    @RowId float,
    @AuthorId int,
    @SecurityId int,
    @PrevAuthorId int,
    @PrevSecurityId int,
    @Author varchar(48),
    @Ticker varchar(15),
    @Company varchar(63),
    @Text varchar(5000),
    @DisclosureText varchar(max)

EXEC sp_xml_preparedocument @hDoc OUTPUT, @DocXML

SET NOCOUNT ON
SELECT AuthorId, Name
INTO #TmpAuthorCollection
FROM OPENXML (@hDoc, 'DocumentInfo/Authors/Author', 1)
WITH (authorid        int         '@id',
    name            varchar(200) '@name'
    )

--Retrieve bernstein tickers & autonomous tickers from document xml
SELECT X.SecurityId, X.Ticker
INTO #TmpTickerCollection
FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
WITH (securityId      int         '@id',
    ticker          varchar(30) '@ticker'
    ) X JOIN Securities2 S ON X.Ticker = S.Ticker
WHERE S.TickerType = 'STOCK'
UNION
SELECT X.SecurityId, X.Ticker
FROM OPENXML (@hDoc, 'DocumentInfo/AutonomousSecurities/AutonomousSecurity', 1)
WITH (securityId      int         '@id',
    ticker          varchar(30) '@ticker'
    ) X JOIN Securities2 S ON X.Ticker = S.Ticker
WHERE S.TickerType = 'STOCK'

--Cross product of Authors & Tickers.
--This is needed to retrieve author holdings for each ticker on the report
--Note that analyst holdings for all tickers on the report (covered & non-covered) need to be reported
SELECT convert(float,convert(varchar,AuthorId) + convert(varchar,SecurityId)) RowId, AuthorId, SecurityId
INTO #TmpAuthorTickerCombinations
FROM
#TmpAuthorCollection TA,  #TmpTickerCollection TT

--Temp holdings table for analysts and tickers
SELECT RowId,Text
INTO #TmpHoldings
FROM
#TmpAuthorTickerCombinations T JOIN vHoldings V ON T.AuthorId = V.AuthorId and T.SecurityId = V.SecurityId

--loop through temp holdings table to build output text
SELECT @DisclosureText = '', @Text = ''
SELECT TOP 1 @RowId = RowId, @Text = Text FROM #TmpHoldings ORDER BY RowId
WHILE @@ROWCOUNT = 1
BEGIN
IF @Text <> ''
BEGIN
SET @DisclosureText = @DisclosureText + @Text + '.' + char(10)
END
SET @Text = ''
SELECT TOP 1 @RowId = RowId, @Text = Text FROM #TmpHoldings WHERE RowId > @RowId ORDER BY RowId
END
--Return output text
SELECT @DisclosureText DisclosureText

END

GO