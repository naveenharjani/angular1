-- vFinancialsFix_Rollback.sql
-- 06/07/2017

/*

alter vFinancials
alter RVFinancials

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER VIEW [dbo].[vFinancials]
AS

--Stocks
SELECT
  PF.SecurityId,
  S.Ticker,
  P.Date,
  PF.PubNo,
  PF.CoverageAction,
  PF.Rating,
  PF.RatingPrior,
  PF.RatingAction,
  PF.TargetPrice,
  PF.TargetPricePrior,
  PF.TargetPriceAction,
  PF.BaseYear AS LastYear,
  PF.BaseYear + 1 AS ThisYear,
  PF.BaseYear + 2 AS NextYear,
  PF.EpsType,
  CASE WHEN ISNUMERIC(PF.EpsFY0) = 1 THEN CAST(PF.EpsFY0 AS DECIMAL(18,2)) ELSE NULL END AS EPSLastYear,
  CASE WHEN ISNUMERIC(PF.EpsFY1) = 1 THEN CAST(PF.EpsFY1 AS DECIMAL(18,2)) ELSE NULL END AS EPSThisYear,
  CASE WHEN ISNUMERIC(PF.EpsFY1Prior) = 1 THEN CAST(PF.EpsFY1Prior AS DECIMAL(18,2)) ELSE NULL END AS EPSThisYearPrior,
  PF.EpsFY1Action AS EstimateAction,
  CASE WHEN ISNUMERIC(PF.EpsFY2) = 1 THEN CAST(PF.EpsFY2 AS DECIMAL(18,2)) ELSE NULL END AS EPSNextYear,
  CASE WHEN ISNUMERIC(PF.EpsFY2Prior) = 1 THEN CAST(PF.EpsFY2Prior AS DECIMAL(18,2)) ELSE NULL END AS EPSNextYearPrior,
  PF.EpsFY2Action AS EstimateNextYearAction,
  FNT.FinancialNumberType AS MetricType,
  '' AS MetricLastYear,
  '' AS MetricThisYear,
  '' AS MetricNextYear,
  PF.PriceCurrency AS Currency,
  '' AS YTDRelPerf,
  '' AS Yield,
  RC.LaunchDate,
  RC.DropDate,
  P.FileName,
  RC.CoverageId,
  RC.IndustryId,
  RC.AnalystId,
  PF.CloseDate,
  PF.ClosePrice,
  '' AS TickerOrder,
  '' AS DisplayCloseDate,
  '' AS RelPerfType
FROM ResearchCoverage RC
JOIN PublicationFinancials PF ON PF.CoverageId = RC.CoverageId
JOIN Securities2 S ON S.Ticker = PF.Ticker AND S.TickerType = 'Stock'
JOIN Publications P ON P.PubNo = PF.PubNo
LEFT JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
LEFT JOIN FinancialNumberTypes FNT ON FNT.FinancialNumberTypeId = FCS.TickerTableValuationId
WHERE RC.LaunchDate IS NOT NULL

UNION

--Indexes
SELECT
  PF.SecurityId,
  S.Ticker,
  P.Date,
  PF.PubNo,
  PF.CoverageAction,
  '' AS Rating,
  '' AS RatingPrior,
  '' AS RatingAction,
  '' AS TargetPrice,
  '' AS TargetPricePrior,
  '' AS TargetPriceAction,
  PF.BaseYear AS LastYear,
  PF.BaseYear + 1 AS ThisYear,
  PF.BaseYear + 2 AS NextYear,
  PF.EpsType,
  CASE WHEN ISNUMERIC(PF.EpsFY0) = 1 THEN CAST(PF.EpsFY0 AS DECIMAL(18,2)) ELSE NULL END AS EPSLastYear,
  CASE WHEN ISNUMERIC(PF.EpsFY1) = 1 THEN CAST(PF.EpsFY1 AS DECIMAL(18,2)) ELSE NULL END AS EPSThisYear,
  NULL AS EPSThisYearPrior,
  PF.EpsFY1Action AS EstimateAction,
  CASE WHEN ISNUMERIC(PF.EpsFY2) = 1 THEN CAST(PF.EpsFY2 AS DECIMAL(18,2)) ELSE NULL END AS EPSNextYear,
  NULL AS EPSNextYearPrior,
  PF.EpsFY2Action AS EstimateNextYearAction,
  '' AS MetricType,
  '' AS MetricLastYear,
  '' AS MetricThisYear,
  '' AS MetricNextYear,
  PF.PriceCurrency AS Currency,
  '' AS YTDRelPerf,
  '' AS Yield,
  NULL AS LaunchDate,
  NULL AS DropDate,
  P.FileName,
  NULL AS CoverageId,
  NULL AS IndustryId,
  NULL AS AnalystId,
  PF.CloseDate,
  PF.ClosePrice,
  '' AS TickerOrder,
  '' AS DisplayCloseDate,
  '' AS RelPerfType
FROM PublicationFinancials PF
JOIN Securities2 S ON S.Ticker = PF.Ticker AND S.TickerType = 'Index'
JOIN Publications P ON P.PubNo = PF.PubNo



GO




ALTER VIEW [dbo].[RVFinancials]  WITH SCHEMABINDING AS
SELECT
  RC.SecurityId,
  PF.Ticker,
  P.Date,
  DocId = PF.PubNo,
  PF.CoverageAction,
  PF.Rating,
  PF.RatingAction,
  PF.TargetPrice,
  PF.TargetPriceAction,
  PF.ClosePrice,
  PF.CloseDate,
  PF.BaseYear LastYear,
  PF.BaseYear + 1 ThisYear,
  PF.BaseYear + 2 NextYear,
  PF.EPSType,
  CASE WHEN isnumeric(PF.EpsFY0) = 1 THEN CONVERT(VARCHAR,CAST(PF.EpsFY0 AS DECIMAL(18,2))) ELSE PF.EpsFY0 END EPSLastYear,
  CASE WHEN isnumeric(PF.EpsFY1) = 1 THEN CONVERT(VARCHAR,CAST(PF.EpsFY1 AS DECIMAL(18,2))) ELSE PF.EpsFY1 END EPSThisYear,
  CASE WHEN isnumeric(PF.EpsFY2) = 1 THEN CONVERT(VARCHAR,CAST(PF.EpsFY2 AS DECIMAL(18,2))) ELSE PF.EpsFY2 END EPSNextYear,
  PF.EpsFY1Action EstimateAction,
  PF.EpsFY2Action EstimateNextYearAction,
  FNT.FinancialNumberType MetricType,
  BV.ValuationFY0 MetricLastYear,
  BV.ValuationFY1 MetricThisYear,
  BV.ValuationFY2 MetricNextYear,
  PF.PriceCurrency Currency,
  '' YTDRelPerf,
  '' Yield
FROM dbo.ResearchCoverage RC
JOIN dbo.PublicationFinancials PF ON PF.CoverageId = RC.CoverageId
JOIN dbo.TickerTableValuations BV ON BV.SecurityId = PF.SecurityId
JOIN dbo.Publications P ON P.PubNo = PF.PubNo
JOIN dbo.Securities2 S ON S.SecurityId = PF.SecurityId
JOIN dbo.FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
JOIN dbo.FinancialNumberTypes FNT ON FNT.FinancialNumberTypeId = FCS.TickerTableValuationId
WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL


GO


