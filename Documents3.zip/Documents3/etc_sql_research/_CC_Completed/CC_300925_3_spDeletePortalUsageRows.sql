-- spDeletePortalUsageRows.sql
-- 02/04/2019

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spDeletePortalUsageRows]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spDeletePortalUsageRows]
GO

CREATE PROCEDURE [dbo].[spDeletePortalUsageRows]
  @SiteId         int,
  @FromDate       varchar(20),
  @ToDate         varchar(20),
  @TransactionId  char(1) = ''
AS
BEGIN
  SET NOCOUNT ON

  IF @TransactionId = 'Y'
  BEGIN
    DELETE
    FROM PortalUsage
    WHERE SiteId = @SiteId
    AND ReadDate BETWEEN @FromDate AND dateadd(dd,1, CAST(@ToDate as DATE))
    AND TransactionId IS NOT NULL
  END
  ELSE
  BEGIN
    DELETE
    FROM PortalUsage
    WHERE SiteId = @SiteId
    AND ReadDate BETWEEN @FromDate AND dateadd(dd,1, CAST(@ToDate as DATE))
    AND TransactionId IS NULL
  END

  SELECT @@ROWCOUNT
  
  SET NOCOUNT OFF
END
GO

GRANT EXECUTE ON [dbo].[spDeletePortalUsageRows] TO DE_IIS, PowerUsers
GO

-- DEBUG
/*
EXEC [spDeletePortalUsageRows] 12, '01/15/2019', '01/15/2019'
EXEC [spDeletePortalUsageRows] 12, '01/15/2019', '01/15/2019', 'Y'
EXEC [spDeletePortalUsageRows] 12, '01/15/2019', '01/15/2019', 'N'
GO

SELECT TOP 10 * FROM PortalUsage

INSERT INTO PortalUsage(ContentType, ContentId, ReadDate, SiteId, SubSite, Account, AccountId, TransactionId, EmbargoStyle, FileName, LoadDate)
SELECT TOP 30 ContentType, ContentId, '01/15/2019', SiteId, SubSite, Account, AccountId, NULL, EmbargoStyle, FileName, LoadDate
FROM PortalUsage WHERE CONVERT(varchar, ReadDate, 101) = '01/14/2019'
AND SiteId = 12

INSERT INTO PortalUsage(ContentType, ContentId, ReadDate, SiteId, SubSite, Account, AccountId, TransactionId, EmbargoStyle, FileName, LoadDate)
SELECT TOP 50 ContentType, ContentId, '01/15/2019', SiteId, SubSite, Account, AccountId, TransactionId + 'xxx', EmbargoStyle, FileName, LoadDate
FROM PortalUsage WHERE CONVERT(varchar, ReadDate, 101) = '01/14/2019'
AND SiteId = 12

SELECT * FROM PortalUsage WHERE CONVERT(varchar, ReadDate, 101) = '01/15/2019' AND TransactionId IS NULL  AND SiteId = 12
SELECT * FROM PortalUsage WHERE CONVERT(varchar, ReadDate, 101) = '01/15/2019' AND TransactionId IS NOT NULL AND SiteId = 12

*/