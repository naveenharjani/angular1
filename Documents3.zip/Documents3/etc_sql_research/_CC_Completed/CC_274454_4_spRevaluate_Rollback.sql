--spRevaluate_Rollback.sql
--12/15/2017

USE [Research]
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spRevaluate] @SecurityId int = 0
AS
SET NOCOUNT ON

DECLARE @Type                     char(1),
        @FinancialNumberTypeCat   char(1),
        @EditorId                 int,
        @EditDate                 datetime

SET @Type                   = 'S'  -- Source = Standard formula for valuation
SET @FinancialNumberTypeCat = 'V'  -- Type   = Valuation Field
SET @EditorId               = 0    -- System
SET @EditDate               = getdate()

-- Cleanup Valuations each time
IF @SecurityId = 0
  DELETE FROM Valuations
ELSE
  DELETE FROM Valuations WHERE SecurityId = @SecurityId

-- Hold valuations rowset - Draft and Live
SELECT FNT.*,isDraft = 0 INTO #FNTP FROM vEstimateSetsPeriods FNT WHERE 1 = 2
IF @SecurityId = 0
BEGIN
  INSERT INTO #FNTP
  SELECT FNT.*, isDraft = 0
  FROM vEstimateSetsPeriods FNT WHERE FNT.FinancialNumberTypeCat = 'V'  AND FNT.FinancialPeriodCat = 'Y'
  UNION
  SELECT FNT.*, isDraft = 1
  FROM vEstimateSetsPeriods FNT WHERE FNT.FinancialNumberTypeCat = 'V'  AND FNT.FinancialPeriodCat = 'Y'
END
ELSE
BEGIN
  INSERT INTO #FNTP
  SELECT FNT.*, isDraft = 0
  FROM vEstimateSetsPeriods FNT WHERE FNT.FinancialNumberTypeCat = 'V' AND SecurityId = @SecurityId AND FNT.FinancialPeriodCat = 'Y'
  UNION
  SELECT FNT.*, isDraft = 1
  FROM vEstimateSetsPeriods FNT WHERE FNT.FinancialNumberTypeCat = 'V' AND SecurityId = @SecurityId AND FNT.FinancialPeriodCat = 'Y'
END
--select * from #FNTP

SELECT ROW_NUMBER() OVER(ORDER BY FormulaPassNo,FinancialNumberTypeId) as Row, FinancialNumberTypeId,FormulaPassNo,Formula,IsPercent,Numerator = substring(Formula,2,charindex(']',Formula)-2),Denominator=replace(substring(Formula,charindex('/[',Formula) + 
2,len(Formula)-charindex('/[',Formula) + 1),']','')
INTO #ValuationFormulae
FROM FinancialNumberTypes  WHERE FinancialNumberTypeCat = 'V' --AND FinancialNumberTypeId not in (31,32)

DECLARE @Numerator varchar(30), @Denominator varchar(30),@Formula varchar(100),@Row int,@IsPercent int,@FinancialNumberTypeId int
DECLARE @NumeratorTypeId varchar(30), @DenominatorTypeId varchar(30), @NumeratorType char(1), @DenominatorType char(1),@NumeratorTickerType varchar(10),@DenominatorTickerType varchar(10)
DECLARE @FXRateId int

SELECT top 1 @FinancialNumberTypeId=FinancialNumberTypeId,@Numerator = Numerator,@Denominator = Denominator,@Formula = Formula, @Row = Row,@IsPercent = IsPercent FROM #ValuationFormulae  ORDER BY Row
SELECT @FXRateId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'FXRATE'
WHILE @@ROWCOUNT = 1
BEGIN
  --SELECT @FinancialNumberTypeId,@Numerator ,@Denominator ,@Formula , @Row ,@IsPercent
  --Initialize for every valuation row
  SELECT @NumeratorTypeId = null,@DenominatorTypeId = null,@NumeratorType = null,@DenominatorType = null,@NumeratorTickerType = null,@DenominatorTickerType = null

  --Check if numerator or denominator are index valuations
  IF @Numerator like '%IDX!%'
  SELECT @NumeratorTickerType = 'Index',@Numerator = REPLACE(@Numerator,'IDX!','')
  ELSE
  SELECT @NumeratorTickerType = 'Ticker'

  IF @Denominator like '%IDX!%'
  SELECT @DenominatorTickerType = 'Index',@Denominator = REPLACE(@Numerator,'IDX!','')
  ELSE
  SELECT @DenominatorTickerType = 'Ticker'

  SELECT @NumeratorTypeId = FinancialNumberTypeId, @NumeratorType = FinancialNumberTypeCat FROM FinancialNumberTypes WHERE FinancialNumberType = @Numerator
  SELECT @DenominatorTypeId = FinancialNumberTypeId, @DenominatorType = FinancialNumberTypeCat FROM FinancialNumberTypes WHERE FinancialNumberType = @Denominator

  --SELECT @FinancialNumberTypeId,@NumeratorTypeId,@NumeratorType,@Numerator,@NumeratorTickerType,@DenominatorTypeId,@DenominatorType,@Denominator,@DenominatorTickerType,@Formula,@IsPercent

  --CASE 1: If Numerator is market data field, denominator is estimate data field and both are for a ticker
  IF @NumeratorType = 'M' AND @DenominatorType = 'E' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Ticker'
  BEGIN
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VE.PeriodYear,''),
      ISNULL(VE.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VMD.Value) = 1 AND ISNUMERIC(VE.Value)  = 1
          THEN CASE
               WHEN CAST(VE.Value AS FLOAT)  = 0 THEN NULL
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 1 AND VMDL.Value IS NOT NULL THEN CONVERT(varchar,CAST(((CAST(VMD.Value AS FLOAT) * 100) / (CAST(VE.Value AS FLOAT) * CAST(VMDL.Value AS FLOAT))) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 1 THEN CONVERT(varchar,CAST(((CAST(VMD.Value AS FLOAT) * 100) / (CAST(VE.Value AS FLOAT) * ISNULL(VBF.Value,1))) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 0 AND VMDL.Value IS NOT NULL THEN CONVERT(varchar, CAST((CAST(VMD.Value AS FLOAT) / (CAST(VE.Value AS FLOAT) * CAST(VMDL.Value AS FLOAT))) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VMD.Value AS FLOAT) / (CAST(VE.Value AS FLOAT) * ISNULL(VBF.Value,1))) AS DECIMAL(18,2)))
               WHEN VMD.CurCode = VE.CurCode  AND @IsPercent = 1 THEN CONVERT(varchar,CAST(((CAST(VMD.Value AS FLOAT) * 100) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
               WHEN VMD.CurCode = VE.CurCode  AND @IsPercent = 0 THEN CONVERT(varchar,CAST((CAST(VMD.Value AS FLOAT) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
               ELSE                                                   CONVERT(varchar,CAST(CAST(VMD.Value AS FLOAT) / CAST(VE.Value AS FLOAT) AS DECIMAL(18,2)))
               END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vFinancialNumbersLatest VE ON VE.SecurityId = FNT.SecurityId AND ISNULL(VE.CoverageId,'') = ISNULL(FNT.CoverageId,'')
    AND VE.FinancialNumberTypeId = @DenominatorTypeId
    --AND VE.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = FNT.IsDraft

    LEFT JOIN vMarketData VMD ON VMD.SecurityId = FNT.SecurityId
    --AND VMD.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VMD.FinancialNumberTypeId = @NumeratorTypeId
    LEFT JOIN vBloombergFXLatest VBF ON VBF.Ticker = VE.CurCode + VMD.CurCode COLLATE SQL_Latin1_General_CP1_CS_AS AND VBF.BloombergMnemonic = 'PX_LAST'
    LEFT JOIN vMarketDataLatest VMDL ON VMDL.SecurityId = FNT.SecurityId AND VMDL.FinancialNumberTypeId = @FXRateId AND VMDL.Type = 'O'
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FNT.FinancialNumberTypeId = @FinancialNumberTypeId
  END

  --CASE 2 If Numerator is estimate data field, denominator is market data field and both are for a ticker
  IF @NumeratorType = 'E' AND @DenominatorType = 'M' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Ticker'
  BEGIN
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VE.PeriodYear,''),
      ISNULL(VE.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VMD.Value) = 1 AND ISNUMERIC(VE.Value)  = 1
          THEN CASE
               WHEN CAST(VMD.Value AS FLOAT)  = 0 THEN NULL
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 1 AND VMDL.Value IS NOT NULL THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * 100 * CAST(VMDL.Value AS FLOAT)) / CAST(VMD.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * 100 * ISNULL(VBF.Value,1)) / CAST(VMD.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 0 AND VMDL.Value IS NOT NULL THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * CAST(VMDL.Value AS FLOAT)) / CAST(VMD.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VMD.CurCode <> VE.CurCode AND @IsPercent = 0 THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * ISNULL(VBF.Value,1)) / CAST(VMD.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VMD.CurCode = VE.CurCode  AND @IsPercent = 1 THEN CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) * 100 / CAST(VMD.Value AS FLOAT)) AS DECIMAL(18,2)))
               WHEN VMD.CurCode = VE.CurCode  AND @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) / CAST(VMD.Value AS FLOAT)) AS DECIMAL(18,2)))
               ELSE                                                   CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) / CAST(VMD.Value AS FLOAT)) AS DECIMAL(18,2)))
               END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vFinancialNumbersLatest VE ON VE.SecurityId = FNT.SecurityId AND ISNULL(VE.CoverageId,'') = ISNULL(FNT.CoverageId,'')
    AND VE.FinancialNumberTypeId = @NumeratorTypeId
    --AND VE.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = FNT.IsDraft
    LEFT JOIN vMarketData VMD ON VMD.SecurityId = FNT.SecurityId
    --AND VMD.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VMD.FinancialNumberTypeId = @DenominatorTypeId
    LEFT JOIN vBloombergFXLatest VBF ON VBF.Ticker = VE.CurCode + VMD.CurCode COLLATE SQL_Latin1_General_CP1_CS_AS AND VBF.BloombergMnemonic = 'PX_LAST'
    LEFT JOIN vMarketDataLatest VMDL ON VMDL.SecurityId = FNT.SecurityId AND VMDL.FinancialNumberTypeId = @FXRateId AND VMDL.Type = 'O'
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FNT.FinancialNumberTypeId = @FinancialNumberTypeId
  END

  --CASE 3 If Numerator is estimate data field, denominator is estimate data field and both are for a ticker
  IF @NumeratorType = 'E' AND @DenominatorType = 'E' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Ticker'
  BEGIN
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VE.PeriodYear,''),
      ISNULL(VE.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VE2.Value) = 1 AND ISNUMERIC(VE.Value) = 1
          THEN CASE
               WHEN CAST(VE2.Value AS FLOAT)  = 0 THEN NULL
               WHEN VE2.CurCode <> VE.CurCode AND @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * 100 * ISNULL(VBF.Value,1)) / CAST(VE2.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VE2.CurCode <> VE.CurCode AND @IsPercent = 0 THEN CONVERT(varchar, CAST(((CAST(VE.Value AS FLOAT) * ISNULL(VBF.Value,1)) / CAST(VE2.Value AS FLOAT) ) AS DECIMAL(18,2)))
               WHEN VE2.CurCode = VE.CurCode  AND @IsPercent = 1 THEN CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) * 100 / CAST(VE2.Value AS FLOAT)) AS DECIMAL(18,2)))
               WHEN VE2.CurCode = VE.CurCode  AND @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) / CAST(VE2.Value AS FLOAT)) AS DECIMAL(18,2)))
               ELSE                                           CONVERT(varchar, CAST((CAST(VE.Value AS FLOAT) / CAST(VE2.Value AS FLOAT)) AS DECIMAL(18,2)))
               END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vFinancialNumbersLatest VE ON VE.SecurityId = FNT.SecurityId AND ISNULL(VE.CoverageId,'') = ISNULL(FNT.CoverageId,'')
    AND VE.FinancialNumberTypeId = @NumeratorTypeId
    --AND VE.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = FNT.IsDraft
    LEFT JOIN vFinancialNumbersLatest VE2 ON VE2.SecurityId = FNT.SecurityId AND ISNULL(VE2.CoverageId,'') = ISNULL(FNT.CoverageId,'')
    --AND VE2.FinancialNumberTypeId = FNT.FinancialNumberTypeId
    AND VE2.FinancialNumberTypeId = @DenominatorTypeId
    AND VE2.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE2.IsDraft = FNT.IsDraft
    LEFT JOIN vBloombergFXLatest VBF ON VBF.Ticker = VE.CurCode + VE2.CurCode COLLATE SQL_Latin1_General_CP1_CS_AS AND VBF.BloombergMnemonic = 'PX_LAST'
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FNT.FinancialNumberTypeId = @FinancialNumberTypeId
  END

  --CASE 4 If Numerator is valuation data field, denominator is estimate data field and both are for a ticker
  IF @NumeratorType = 'V' AND @DenominatorType = 'E' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Ticker'
  BEGIN
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VE.PeriodYear,''),
      ISNULL(VE.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VV.Value) = 1 AND ISNUMERIC(VE.Value)  = 1
          THEN
            CASE
              WHEN CAST(VE.Value AS FLOAT)  = 0 THEN NULL
              WHEN @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VV.Value AS FLOAT) * 100) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
              WHEN @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VV.Value AS FLOAT) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
            END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vValuationsLatest VV ON VV.SecurityId = FNT.SecurityId
    AND VV.FinancialNumberTypeId = @NumeratorTypeId
    AND VV.FinancialPeriodId = FNT.FinancialPeriodId
    AND VV.IsDraft = FNT.IsDraft
    LEFT JOIN vFinancialNumbersLatest VE ON VE.SecurityId = FNT.SecurityId AND ISNULL(VE.CoverageId,'') = ISNULL(FNT.CoverageId,'')
    AND VE.FinancialNumberTypeId = @DenominatorTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = FNT.IsDraft
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FNT.FinancialNumberTypeId     = @FinancialNumberTypeId
  END

  --CASE 5 If Numerator is valuation data field, denominator is valuation data field and both are for a ticker
  IF @NumeratorType = 'V' AND @DenominatorType = 'V' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Ticker'
  BEGIN
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VE.PeriodYear,''),
      ISNULL(VE.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VV.Value) = 1 AND ISNUMERIC(VE.Value) = 1
          THEN
            CASE
              WHEN CAST(VE.Value AS FLOAT)  = 0 THEN NULL
              WHEN @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VV.Value AS FLOAT) * 100) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
              WHEN @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VV.Value AS FLOAT) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
            END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vValuationsLatest VV ON VV.SecurityId = FNT.SecurityId
    AND VV.FinancialNumberTypeId = @NumeratorTypeId
    AND VV.FinancialPeriodId = FNT.FinancialPeriodId
    AND VV.IsDraft = FNT.IsDraft
    LEFT JOIN vValuationsLatest VE ON VE.SecurityId = FNT.SecurityId
    AND VE.FinancialNumberTypeId = @DenominatorTypeId
    AND VV.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = FNT.IsDraft
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FNT.FinancialNumberTypeId     = @FinancialNumberTypeId
  END

    --CASE 6 If Numerator is valuation data field for a ticker and denominator is valuation data field for corresponding index
  IF @NumeratorType = 'V' AND @DenominatorType = 'V' AND @NumeratorTickerType = 'Ticker' AND @DenominatorTickerType = 'Index'
  BEGIN
    --For Tickers with base year = index base year
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VV.PeriodYear,''),
      ISNULL(VV.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VV.Value) = 1 AND ISNUMERIC(VE.Value)  = 1
          THEN
            CASE
              WHEN CAST(VE.Value AS FLOAT)  = 0 THEN NULL
              WHEN @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VV.Value AS FLOAT) * 100) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
              WHEN @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VV.Value AS FLOAT) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
            END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vValuationsLatest VV ON VV.SecurityId = FNT.SecurityId
    AND VV.FinancialNumberTypeId = @NumeratorTypeId
    AND VV.FinancialPeriodId = FNT.FinancialPeriodId
    AND VV.IsDraft = FNT.IsDraft
    LEFT JOIN Securities2 S ON FNT.SecurityId = S.SecurityId
    LEFT JOIN FinancialCompanySettings FCS1 ON S.CompanyId = FCS1.CompanyId
    LEFT JOIN Securities2 S2 ON S.BenchmarkIndex = S2.Ticker
    LEFT JOIN FinancialCompanySettings FCS2 ON S2.CompanyId = FCS2.CompanyId
    LEFT JOIN vValuationsLatest VE ON VE.SecurityId = S2.SecurityId
    AND VE.FinancialNumberTypeId = @DenominatorTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId
    AND VE.IsDraft = 0 --For index valuations only live values exist.
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FCS1.BaseYear = FCS2.BaseYear
    AND FNT.FinancialNumberTypeId     = @FinancialNumberTypeId

    --For Tickers with base year = index base year + 1
    INSERT INTO Valuations (SecurityId, FinancialNumberTypeId, FinancialPeriodId, PeriodYear, BaseYear, Type, Value, IsDraft, EditorId, EditDate)
    SELECT
      FNT.SecurityId,
      FNT.FinancialNumberTypeId,
      FNT.FinancialPeriodId,
      ISNULL(VV.PeriodYear,''),
      ISNULL(VV.BaseYear, ''),
      @Type,
      'Valuation' = CASE
        -- Check if not zero value AND if a valid Numeric #
          WHEN ISNUMERIC(VV.Value) = 1 AND ISNUMERIC(VE.Value) = 1
          THEN
            CASE
              WHEN CAST(VE.Value AS FLOAT)  = 0 THEN NULL
              WHEN @IsPercent = 1 THEN CONVERT(varchar, CAST(((CAST(VV.Value AS FLOAT) * 100) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
              WHEN @IsPercent = 0 THEN CONVERT(varchar, CAST((CAST(VV.Value AS FLOAT) / CAST(VE.Value AS FLOAT)) AS DECIMAL(18,2)))
            END
          ELSE NULL
        END,
      FNT.IsDraft,
      @EditorId,
      @EditDate
    FROM #FNTP FNT
    LEFT JOIN vValuationsLatest VV ON VV.SecurityId = FNT.SecurityId
    AND VV.FinancialNumberTypeId = @NumeratorTypeId
    AND VV.FinancialPeriodId = FNT.FinancialPeriodId
    AND VV.IsDraft = FNT.IsDraft
    LEFT JOIN Securities2 S ON FNT.SecurityId = S.SecurityId
    LEFT JOIN FinancialCompanySettings FCS1 ON S.CompanyId = FCS1.CompanyId
    LEFT JOIN Securities2 S2 ON S.BenchmarkIndex = S2.Ticker
    LEFT JOIN FinancialCompanySettings FCS2 ON S2.CompanyId = FCS2.CompanyId
    LEFT JOIN vValuationsLatest VE ON VE.SecurityId = S2.SecurityId
    AND VE.FinancialNumberTypeId = @DenominatorTypeId
    AND VE.FinancialPeriodId = FNT.FinancialPeriodId + 1 -- Shift base year for index by 1 as ticker base year is > index base year
    AND VE.IsDraft = 0 --For index valuations only live values exist.
    WHERE FNT.FinancialNumberTypeCat = 'V'  -- Valuations
    AND FNT.FinancialPeriodCat = 'Y'  -- Yearly
    AND FCS1.BaseYear = FCS2.BaseYear + 1 --Ticker base year = index base year + 1
    AND FNT.FinancialNumberTypeId     = @FinancialNumberTypeId

  END

  SELECT top 1 @FinancialNumberTypeId=FinancialNumberTypeId,@Numerator = Numerator,@Denominator = Denominator,@Formula = Formula, @Row = Row,@IsPercent = IsPercent FROM #ValuationFormulae WHERE Row > @Row ORDER BY Row
END

--Populate TickerTableValuations(flat table) with ticker table valuations
--TickerTableValuations is used by RVFinancials replicated index view to display eps and valuations on ticker landing page
IF @SecurityId = 0
BEGIN
  DELETE FROM TickerTableValuations

  INSERT INTO TickerTableValuations(SecurityId, TickerTableValuationId, ValuationFY0, ValuationFY1, ValuationFY2, ValuationFY3)
  SELECT S.SecurityId, FCS.TickerTableValuationId, V1.Value, V2.Value, V3.Value, V4.Value
  FROM ResearchCoverage RC
  JOIN Securities2 S ON RC.SecurityId = S.SecurityId
  JOIN FinancialCompanySettings FCS ON S.CompanyId = FCS.CompanyId
  LEFT JOIN Valuations V1 ON S.SecurityId = V1.SecurityId AND FCS.TickerTableValuationId = V1.FinancialNumberTypeId AND V1.FinancialPeriodId = 1 AND V1.IsDraft = 0
  LEFT JOIN Valuations V2 ON S.SecurityId = V2.SecurityId AND FCS.TickerTableValuationId = V2.FinancialNumberTypeId AND V2.FinancialPeriodId = 2 AND V2.IsDraft = 0
  LEFT JOIN Valuations V3 ON S.SecurityId = V3.SecurityId AND FCS.TickerTableValuationId = V3.FinancialNumberTypeId AND V3.FinancialPeriodId = 3 AND V3.IsDraft = 0
  LEFT JOIN Valuations V4 ON S.SecurityId = V4.SecurityId AND FCS.TickerTableValuationId = V4.FinancialNumberTypeId AND V4.FinancialPeriodId = 4 AND V4.IsDraft = 0
  WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
END
ELSE
BEGIN
  DELETE FROM TickerTableValuations WHERE SecurityId = @SecurityId

  INSERT INTO TickerTableValuations(SecurityId, TickerTableValuationId, ValuationFY0, ValuationFY1, ValuationFY2, ValuationFY3)
  SELECT S.SecurityId, FCS.TickerTableValuationId, V1.Value, V2.Value, V3.Value, V4.Value
  FROM ResearchCoverage RC
  JOIN Securities2 S ON RC.SecurityId = S.SecurityId
  JOIN FinancialCompanySettings FCS ON S.CompanyId = FCS.CompanyId
  LEFT JOIN Valuations V1 ON S.SecurityId = V1.SecurityId AND FCS.TickerTableValuationId = V1.FinancialNumberTypeId AND V1.FinancialPeriodId = 1 AND V1.IsDraft = 0
  LEFT JOIN Valuations V2 ON S.SecurityId = V2.SecurityId AND FCS.TickerTableValuationId = V2.FinancialNumberTypeId AND V2.FinancialPeriodId = 2 AND V2.IsDraft = 0
  LEFT JOIN Valuations V3 ON S.SecurityId = V3.SecurityId AND FCS.TickerTableValuationId = V3.FinancialNumberTypeId AND V3.FinancialPeriodId = 3 AND V3.IsDraft = 0
  LEFT JOIN Valuations V4 ON S.SecurityId = V4.SecurityId AND FCS.TickerTableValuationId = V4.FinancialNumberTypeId AND V4.FinancialPeriodId = 4 AND V4.IsDraft = 0
  WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
  AND S.SecurityId = @SecurityId
END

  SET NOCOUNT OFF
GO