-- 04/09/2019
-- CC_Admin.sql

/*

alter spSaveAuthor       - add TypeId
alter spSaveSecurity     - add TypeId
alter spSaveUser         - add Watermark
alter spGetAuthor        - add TypeId
alter spGetSecurity      - add TypeId

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSaveAuthor]
  @AuthorID        smallint OUTPUT,
  @Name            varchar(48),
  @Last            varchar(32),
  @First           varchar(16),
  @Phone           varchar(20),
  @Fax             varchar(20),
  @ExtEmail        varchar(50),
  @IntEmail        varchar(32),
  @IsAnalyst       smallint,
  @Active          smallint,
  @EditorID        int,
  @TitleID         int,
  @RegionID        int,
  @UserName        varchar(36),
  @MetricsEligible char(1),
  @IsResearch      char(1),
  @GoUrl           varchar(100),
  @TypeId          int
AS
DECLARE @EditDate datetime

SELECT
  @EditDate = GETDATE(),
  @Name = ltrim(rtrim(@Name)),
  @Last = ltrim(rtrim(@Last)),
  @First = ltrim(rtrim(@First))

BEGIN TRANSACTION
IF EXISTS (SELECT AuthorID FROM Authors WHERE AuthorID = @AuthorID)
  BEGIN
    DECLARE @NameOld varchar(48)
    SELECT @NameOld = Name FROM Authors WHERE AuthorID = @AuthorID
    IF @Name <> @NameOld
      BEGIN
        -- START - Propagate textual updates
        UPDATE Properties SET PropValue = @Name where PropID = 5 and PropValue = @NameOld
        UPDATE PropertiesLog SET PropValue = @Name where PropID = 5 and PropValue = @NameOld
        -- FINISH
        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('Authors', 'U', @Name, @NameOld, @AuthorID, @EditorID, @EditDate)
      END
    UPDATE Authors SET
      Name            = @Name,
      Last            = @Last,
      First           = @First,
      Phone           = @Phone,
      Fax             = @Fax,
      ExtEmail        = @ExtEmail,
      IntEmail        = @IntEmail,
      IsAnalyst       = @IsAnalyst,
      IsActive        = @Active,
      EditorID        = @EditorID,
      EditDate        = @EditDate,
      TitleID         = @TitleID,
      RegionID        = @RegionID,
      WindowsUserName = @UserName,
      MetricsEligible = @MetricsEligible,
      IsResearch      = @IsResearch,
      GoUrl           = @GoUrl,
      TypeId          = @TypeId

    WHERE AuthorID = @AuthorID
  END
ELSE
  BEGIN
    INSERT INTO Authors
      (Name, Last, First, Phone, Fax, ExtEmail, IntEmail, IsAnalyst, IsActive, EditorId, EditDate, TitleID, RegionID, MetricsEligible, WindowsUserName, IsResearch, GoUrl, TypeId)
    VALUES
      (@Name, @Last, @First, @Phone, @Fax, @ExtEmail, @IntEmail, @IsAnalyst, @Active, @EditorID, @EditDate, @TitleID, @RegionID, @MetricsEligible, @UserName, @IsResearch, @GoUrl, @TypeId)
    SELECT @AuthorID = @@IDENTITY
    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Authors', 'A', @Name, NULL, @AuthorID, @EditorID, @EditDate)
  END
COMMIT TRANSACTION
RETURN 0

GO

ALTER PROCEDURE [dbo].[spSaveSecurity]
  @SecurityId     int OUTPUT,
  @TickerType     varchar(10),
  @Company        varchar(63),
  @BLOOMBERG      varchar(15),
  @RIC            varchar(15),
  @CUSIP          varchar(10),
  @SEDOL          varchar(10),
  @CINS           varchar(10),
  @ISIN           varchar(12),
  @VALOREN        varchar(20),
  @ExchangeCode   varchar(10),
  @CurrencyCode   char(3),
  @BenchmarkIndex varchar(10),
  @CountryCode    char(2),
  @RegionId       int,
  @Active         smallint,
  @EditorId       int,
  @GICS_ID        int,
  @Alias          varchar(50),
  @CompanyId      int,
  @TypeId         int
AS

BEGIN TRANSACTION

DECLARE
  @Ticker    varchar(15),
  @EditDate  datetime,
  @IsPrimary char(1),
  @OrdNo     int

SELECT
  @Ticker   = ltrim(rtrim(@BLOOMBERG)),
  @EditDate = GETDATE(),
  @Company = ltrim(rtrim(@Company)),
  @BLOOMBERG = ltrim(rtrim(@BLOOMBERG))

-- Automate the following security attributes based on supplied Exchange Code

SELECT
  @CurrencyCode   = CurrencyCode,
  @BenchmarkIndex = BenchmarkIndex,
  @CountryCode    = CountryCode,
  @RegionId       = RegionId
FROM Exchanges WHERE ExchangeCode = @ExchangeCode

-- UPDATE existing security
IF EXISTS (SELECT SecurityId FROM Securities2 WHERE SecurityId = @SecurityId)
  BEGIN
    DECLARE @TickerOld varchar(15), @CompanyOld varchar(63), @CompanyIdOld int
    SELECT @TickerOld = Ticker, @CompanyOld = Company, @CompanyIdOld = CompanyId, @IsPrimary = IsPrimary, @OrdNo = OrdNo
    FROM Securities2 WHERE SecurityId = @SecurityId

    -- Realign existing security with NEW Company

    IF @CompanyId = -1
      BEGIN
        INSERT INTO Companies(Company) SELECT @Company
        SELECT @CompanyId = @@IDENTITY, @IsPrimary = 'Y', @OrdNo = 1

        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('Companies', 'A', @Company, NULL, @CompanyId, @EditorId, @EditDate)
      END

    -- Realign existing security with EXISTING Company

    ELSE
      BEGIN
        IF @CompanyId <> @CompanyIdOld
        BEGIN
          SELECT @Company = ltrim(rtrim(Company)) from Companies WHERE CompanyId = @CompanyId
          IF EXISTS (SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
            SELECT @IsPrimary = 'N', @OrdNo = MAX(OrdNo) + 1 FROM Securities2 WHERE CompanyId = @CompanyId
          ELSE
            SELECT @IsPrimary = 'Y', @OrdNo = 1
        END
      END

    IF @Ticker <> @TickerOld
    BEGIN
      -- Propagate ticker change
      UPDATE Properties    SET PropValue = @Ticker WHERE PropId = 13 AND PropValue = @TickerOld
      UPDATE PropertiesLog SET PropValue = @Ticker WHERE PropId = 13 AND PropValue = @TickerOld
      UPDATE PublicationFinancials SET Ticker = @Ticker WHERE Ticker = @TickerOld
    END

    IF (@CompanyIdOld = @CompanyId) AND (@CompanyOld <> @Company)
    BEGIN
      -- Propagate company change
      UPDATE Companies           SET Company = @Company WHERE Company = @CompanyOld
      UPDATE Securities2         SET Company = @Company WHERE Company = @CompanyOld
      UPDATE ValuationsCompanies SET Company = @Company WHERE Company = @CompanyOld
      UPDATE RisksCompanies      SET Company = @Company WHERE Company = @CompanyOld
    END

    UPDATE Securities2 SET
      TickerType     = @TickerType,
      Company        = @Company,
      Ticker         = @BLOOMBERG,
      RIC            = @RIC,
      CUSIP          = @CUSIP,
      SEDOL          = @SEDOL,
      CINS           = @CINS,
      ISIN           = @ISIN,
      VALOREN        = @VALOREN,
      ExchangeCode   = @ExchangeCode,
      CurrencyCode   = @CurrencyCode,
      BenchmarkIndex = @BenchmarkIndex,
      CountryCode    = @CountryCode,
      RegionId       = @RegionId,
      IsActive       = @Active,
      EditorId       = @EditorId,
      EditDate       = @EditDate,
      GICS_ID        = @GICS_ID,
      Alias          = @Alias,
      CompanyId      = @CompanyId,
      IsPrimary      = @IsPrimary,
      OrdNo          = @OrdNo,
      TypeId         = @TypeId
    WHERE SecurityId = @SecurityId

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Securities', 'U', @Ticker + ' | ' + @Company, @TickerOld + ' | ' + @CompanyOld, @SecurityId, @EditorId, @EditDate)

  END

-- ADD new security

ELSE
  BEGIN
    -- Align new security with NEW Company

    IF @CompanyId = -1
      BEGIN
        INSERT INTO Companies(Company) SELECT @Company
        SELECT @CompanyId = @@IDENTITY, @IsPrimary = 'Y', @OrdNo = 1

        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('Companies', 'A', @Company, NULL, @CompanyId, @EditorId, @EditDate)
      END

    -- Align new security with EXISTING Company
    ELSE
      BEGIN
        SELECT @Company = ltrim(rtrim(Company)) from Companies WHERE CompanyId = @CompanyId
        IF EXISTS (SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
          SELECT @IsPrimary = 'N', @OrdNo = max(OrdNo) + 1 FROM Securities2 WHERE CompanyId = @CompanyId
        ELSE
          SELECT @IsPrimary = 'Y', @OrdNo = 1
      END

    INSERT INTO Securities2
      (TickerType, Company, Ticker, RIC, CUSIP, SEDOL, CINS, ISIN, VALOREN, ExchangeCode, CurrencyCode, BenchmarkIndex, CountryCode, RegionId, IsActive, EditorId, EditDate, GICS_ID, Alias, CompanyId, IsPrimary, OrdNo, TypeId)
    VALUES
      (@TickerType, @Company, @BLOOMBERG, @RIC, @CUSIP, @SEDOL, @CINS, @ISIN, @VALOREN, @ExchangeCode, @CurrencyCode, @BenchmarkIndex, @CountryCode, @RegionId, @Active, @EditorId, @EditDate, @GICS_ID, @Alias, @CompanyId, @IsPrimary, @OrdNo, @TypeId)

    SELECT @SecurityId = @@IDENTITY
    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Securities', 'A', @Ticker + ' | ' + @Company, NULL, @SecurityId, @EditorId, @EditDate)

  END

COMMIT TRANSACTION

RETURN 0



GO

ALTER PROCEDURE [dbo].[spSaveUser]
  @UserId          int OUTPUT,
  @UserName        varchar(36),
  @LastName        varchar(32),
  @FirstName       varchar(16),
  @Email           varchar(50),
  @ExchangeEmail   varchar(50),
  @Phone           varchar(20),
  @Password        varchar(14),
  @RolesList       varchar(100),
  @Comment1        varchar(24),
  @Comment2        varchar(24),
  @Active          smallint,
  @EditorId        int,
  @Initials        varchar(4),
  @DepartmentId    int,
  @ReviewDate      datetime,
  @CostCenterCode  int,
  @SettingsList    varchar(100),
  @WatermarkTypeId int,
  @WatermarkText   varchar(100)
AS
DECLARE @EditDate    datetime
DECLARE @OldUserName varchar(36)

SELECT @EditDate = GETDATE()
BEGIN TRANSACTION

-- Temporarily save old roles and settings for comparison to new values and log the deltas
SELECT * INTO #TempUserRoles FROM UserRoles WHERE UserId = @UserId
SELECT * INTO #TempUserSettings FROM UserSettings WHERE UserId = @UserId

IF EXISTS (SELECT UserId FROM Users WHERE UserId = @UserId)
  BEGIN
    SELECT @OldUserName = UserName FROM Users WHERE UserId = @UserId

    UPDATE Users SET
      UserName        = @UserName,
      LastName        = @LastName,
      FirstName       = @FirstName,
      Email           = @Email,
      ExchangeEmail   = @ExchangeEmail,
      Phone           = @Phone,
      Password        = @Password,
      Comment1        = @Comment1,
      Comment2        = @Comment2,
      Active          = @Active,
      EditorId        = @EditorId,
      EditDate        = @EditDate,
      Initials        = @Initials,
      DepartmentId    = @DepartmentId,
      ReviewDate      = @ReviewDate,
      CostCenterCode  = @CostCenterCode,
      WatermarkTypeId = @WatermarkTypeId,
      WatermarkText   = @WatermarkText
    WHERE UserId = @UserId

    UPDATE Authors SET WindowsUserName = @UserName WHERE WindowsUserName = @OldUserName

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate) VALUES ('Users', 'U', @UserName, @OldUserName, 0, @EditorId, @EditDate)

  END
ELSE
  BEGIN
    INSERT INTO Users (UserName, LastName, FirstName, Email, ExchangeEmail, Phone, Password, Comment1, Comment2, Active, EditorId, EditDate, Initials, DepartmentId, ReviewDate,WatermarkTypeId,WatermarkText)
      VALUES (@UserName, @LastName, @FirstName, @Email, @ExchangeEmail, @Phone, @Password, @Comment1, @Comment2, @Active, @EditorId, @EditDate, @Initials, @DepartmentId, @ReviewDate,@WatermarkTypeId,@WatermarkText)
    SELECT @UserId = @@IDENTITY

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate) VALUES ('Users', 'A', @UserName, NULL, 0, @EditorId, @EditDate)
  END

DECLARE @Pos       int
DECLARE @Delimiter char(1)
DECLARE @String    varchar(max)
DECLARE @RoleId    varchar(max)
DECLARE @SettingId varchar(max)

SET @Delimiter = '|'

-- Re-save delimited list of User Roles posted from web form as individual rows
DELETE FROM UserRoles WHERE UserId = @UserId
SET @String = @RolesList
IF RIGHT(RTRIM(@String), 1) <> @Delimiter -- Ensure trailing delimiter
  SET @String = @String + @Delimiter
SET @Pos = CHARINDEX(@Delimiter, @String)
WHILE @Pos <> 0
BEGIN
  SET @RoleId = LEFT(@String, @Pos - 1)
  IF LTRIM(RTRIM(@RoleId)) <> ''
  BEGIN
    INSERT INTO UserRoles (UserId, RoleId, EditorId, EditDate) VALUES (@UserId, @RoleId, @EditorId, @EditDate)
  END
  SET @String = STUFF(@String, 1, @Pos, '')
  SET @Pos = CHARINDEX(@Delimiter, @String)
END

-- Re-save delimited list of User Settings posted from web form as individual rows
DELETE FROM UserSettings WHERE UserId = @UserId
SET @String = @SettingsList
IF RIGHT(RTRIM(@String), 1) <> @Delimiter -- Ensure trailing delimiter
  SET @String = @String + @Delimiter

SET @Pos = CHARINDEX(@Delimiter , @String)
WHILE @Pos <> 0
BEGIN
  SET @SettingId = LEFT(@String, @Pos - 1)
  IF LTRIM(RTRIM(@SettingId)) <> ''
  BEGIN
    INSERT INTO UserSettings (UserId, SettingId, EditorId, EditDate) VALUES (@UserId, @SettingId, @EditorId, @EditDate)
  END
  SET @String = STUFF(@String, 1, @Pos, '')
  SET @Pos = CHARINDEX(@Delimiter, @String)
END

-- Log User Roles additions
INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
SELECT
  'UserRoles', 'A',
  ISNULL(U.LastName, '') + ', ' + ISNULL(U.FirstName, '') + ' (' + U.UserName + ') | ' + R.Role,
  '',  0, @EditorId, @EditDate
FROM UserRoles UR
JOIN Users U ON U.UserId = UR.UserId
JOIN Roles R ON R.RoleId = UR.RoleId
WHERE UR.UserId = @UserId
AND NOT EXISTS (SELECT * FROM #TempUserRoles TUR WHERE TUR.UserId = UR.UserId AND TUR.RoleId = UR.RoleId)

-- Log User Roles deletions
INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
SELECT
  'UserRoles', 'D',
  ISNULL(U.LastName, '') + ', ' + ISNULL(U.FirstName, '') + ' (' + U.UserName + ') | ' + R.Role,
  '',  0, @EditorId, @EditDate
FROM #TempUserRoles TUR
JOIN Users U ON U.UserId = TUR.UserId
JOIN Roles R ON R.RoleId = TUR.RoleId
WHERE TUR.UserId = @UserId
AND NOT EXISTS (SELECT * FROM UserRoles UR WHERE UR.UserId = TUR.UserId AND UR.RoleId = TUR.RoleId)

-- Log User Settings additions
INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
SELECT
  'UserSettings', 'A',
  ISNULL(U.LastName, '') + ', ' + ISNULL(U.FirstName, '') + ' (' + U.UserName + ') | ' + S.Setting,
  '',  0, @EditorId, @EditDate
FROM UserSettings US
JOIN Users U ON U.UserId = US.UserId
JOIN Settings S ON S.SettingId = US.SettingId
WHERE US.UserId = @UserId
AND NOT EXISTS (SELECT * FROM #TempUserSettings TUS WHERE TUS.UserId = US.UserId AND TUS.SettingId = US.SettingId)

-- Log User Settings deletions
INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
SELECT
  'UserSettings', 'D',
  ISNULL(U.LastName, '') + ', ' + ISNULL(U.FirstName, '') + ' (' + U.UserName + ') | ' + S.Setting,
  '',  0, @EditorId, @EditDate
FROM #TempUserSettings TUS
JOIN Users U ON U.UserId = TUS.UserId
JOIN Settings S ON S.SettingId = TUS.SettingId
WHERE TUS.UserId = @UserId
AND NOT EXISTS (SELECT * FROM UserSettings US WHERE US.UserId = TUS.UserId AND US.SettingId = TUS.SettingId)

DROP TABLE #TempUserRoles
DROP TABLE #TempUserSettings

COMMIT TRANSACTION
RETURN 0

GO

ALTER PROCEDURE [dbo].[spGetAuthor]
  @AuthorID        smallint,
  @Name            varchar(48)  OUTPUT,
  @Last            varchar(32)  OUTPUT,
  @First           varchar(16)  OUTPUT,
  @Phone           varchar(20)  OUTPUT,
  @Fax             varchar(20)  OUTPUT,
  @ExtEmail        varchar(50)  OUTPUT,
  @IntEmail        varchar(32)  OUTPUT,
  @IsAnalyst       smallint     OUTPUT,
  @IsActive        smallint     OUTPUT,
  @Editor          varchar(36)  OUTPUT,
  @EditDate        datetime     OUTPUT,
  @UsageCt         int          OUTPUT,
  @TitleID         int          OUTPUT,
  @RegionID        int          OUTPUT,
  @UserName        varchar(36)  OUTPUT,
  @MetricsEligible char(1)      OUTPUT,
  @IsResearch      char(1)      OUTPUT,
  @GoUrl           varchar(100) OUTPUT,
  @TypeId          int          OUTPUT
AS
SELECT
  @Name            = A.Name,
  @Last            = A.Last,
  @First           = A.First,
  @Phone           = A.Phone,
  @Fax             = A.Fax,
  @ExtEmail        = A.ExtEmail,
  @IntEmail        = A.IntEmail,
  @IsAnalyst       = A.IsAnalyst,
  @IsActive        = A.IsActive,
  @Editor          = E.UserName,
  @EditDate        = A.EditDate,
  @TitleID         = A.TitleID,
  @RegionID        = A.RegionID,
  @UserName        = A.WindowsUserName,
  @MetricsEligible = A.MetricsEligible,
  @IsResearch      = A.IsResearch,
  @GoUrl           = A.GoUrl,
  @TypeId          = ISNULL(A.TypeId, 1)

FROM Authors A
LEFT JOIN Users E ON E.UserID = A.EditorID
WHERE AuthorID = @AuthorID

SELECT @UsageCt = COUNT(*) FROM Properties WHERE PropID = 5 AND PropValue = @Name
GO

Alter PROCEDURE [dbo].[spGetSecurity]
  @SecurityId     int,
  @Ticker         varchar(15) OUTPUT,
  @TickerType     varchar(10) OUTPUT,
  @Company        varchar(63) OUTPUT,
  @BLOOMBERG      varchar(15) OUTPUT,
  @RIC            varchar(15) OUTPUT,
  @CUSIP          varchar(10) OUTPUT,
  @SEDOL          varchar(10) OUTPUT,
  @CINS           varchar(10) OUTPUT,
  @ISIN           varchar(12) OUTPUT,
  @VALOREN        varchar(20) OUTPUT,
  @ExchangeCode   varchar(10) OUTPUT,
  @CurrencyCode   char(3)     OUTPUT,
  @BenchmarkIndex varchar(10) OUTPUT,
  @CountryCode    char(2)     OUTPUT,
  @RegionId       int         OUTPUT,
  @Active         smallint    OUTPUT,
  @Editor         varchar(36) OUTPUT,
  @EditDate       datetime    OUTPUT,
  @GICS_ID        int         OUTPUT,
  @UsageCt        int         OUTPUT,
  @Alias          varchar(50) OUTPUT,
  @CompanyId      int         OUTPUT,
  @TypeId         int         OUTPUT
AS
SELECT
  @Ticker         = S.Ticker,
  @TickerType     = S.TickerType,
  @Company        = S.Company,
  @BLOOMBERG      = S.Ticker,
  @RIC            = S.RIC,
  @CUSIP          = S.CUSIP,
  @SEDOL          = S.SEDOL,
  @CINS           = S.CINS,
  @ISIN           = S.ISIN,
  @VALOREN        = S.VALOREN,
  @ExchangeCode   = S.ExchangeCode,
  @CurrencyCode   = S.CurrencyCode,
  @BenchmarkIndex = S.BenchmarkIndex,
  @CountryCode    = S.CountryCode,
  @RegionId       = S.RegionId,
  @Active         = S.IsActive,
  @Editor         = E.UserName,
  @EditDate       = S.EditDate,
  @GICS_ID        = S.GICS_ID,
  @Alias          = S.Alias,
  @CompanyId      = S.CompanyId,
  @TypeId         = ISNULL(S.TypeId, 1)
FROM Securities2 S
LEFT JOIN Users E ON E.UserId = S.EditorId
WHERE SecurityId = @SecurityId

SELECT @UsageCt = COUNT(*) FROM Properties WHERE PropId = 13 AND PropValue = @Ticker


GO
