-- CC_ETL_MinorP_Rollback.sql
-- 02/12/2019

/*
Tables
rollback table PortalUsageStaging_ONEaccess
rollback table PortalUsageStaging_RedDeer

Procs
rollback proc spLoadPortalUsageFromStaging_ONEaccess
rollback proc spLoadPortalUsageFromStaging_RedDeer
rollback proc spLoadPortalUsageFromStaging_BlueMatrix
rollback proc spLoadPortalUsageFromStaging_RSRCHX
*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_ONEaccess]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_ONEaccess]
GO

CREATE TABLE [dbo].[PortalUsageStaging_ONEaccess](
	[file_date_UTC] [varchar](500) NULL,
	[read_id] [varchar](500) NULL,
	[vendor_document_id] [varchar](500) NULL,
	[broker_document_id] [varchar](500) NULL,
	[headline] [varchar](500) NULL,
	[ric_ticker] [varchar](500) NULL,
	[vendor_analyst_id] [varchar](500) NULL,
	[analyst_name] [varchar](500) NULL,
	[analyst_email] [varchar](500) NULL,
	[published_date_UTC] [varchar](500) NULL,
	[viewed_date_UTC] [varchar](500) NULL,
	[vendor_client_id] [varchar](500) NULL,
	[client_name] [varchar](500) NULL,
	[client_address] [varchar](500) NULL,
	[client_city] [varchar](500) NULL,
	[client_state] [varchar](500) NULL,
	[client_country] [varchar](500) NULL,
	[client_type] [varchar](500) NULL,
	[Vendor Channel] [varchar](500) NULL,
	[Readership_type] [varchar](500) NULL,
	[vendor_user_id] [varchar](500) NULL,
	[user_name] [varchar](500) NULL,
	[user_business_email] [varchar](500) NULL,
	[user_alt_email] [varchar](500) NULL,
	[user_phone] [varchar](500) NULL,
	[user_address] [varchar](500) NULL,
	[user_city] [varchar](500) NULL,
	[user_state] [varchar](500) NULL,
	[user_country] [varchar](500) NULL,
	[user_role] [varchar](500) NULL
) ON [PRIMARY]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_RedDeer]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_RedDeer]
GO

CREATE TABLE [dbo].[PortalUsageStaging_RedDeer](
	[Client_ID *] [varchar](500) NULL,
	[Client_Name] [varchar](500) NULL,
	[Client_Type] [varchar](500) NULL,
	[User_ID **] [varchar](500) NULL,
	[User_Name] [varchar](500) NULL,
	[User_Business_Email] [varchar](500) NULL,
	[User_Country] [varchar](500) NULL,
	[User_Status] [varchar](500) NULL,
	[Red Deer_Transaction_ID ***] [varchar](500) NULL,
	[Vendor_Doc_ID ****] [varchar](500) NULL,
	[Read_Date] [varchar](500) NULL,
	[Read_Count] [varchar](500) NULL,
	[User_Sub_Start_Date] [varchar](500) NULL,
	[User_Sub_End_Date] [varchar](500) NULL
) ON [PRIMARY]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_BlueMatrix]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_BlueMatrix]
GO

CREATE TABLE [dbo].[PortalUsageStaging_BlueMatrix](
	[Transaction ID] [varchar](500) NULL,
	[Read Date/Time] [varchar](500) NULL,
	[Document ID] [varchar](500) NULL,
	[Title] [varchar](500) NULL,
	[Document Date] [varchar](500) NULL,
	[User Name] [varchar](500) NULL,
	[Primary E-Mail] [varchar](500) NULL,
	[User ID] [varchar](500) NULL,
	[Firm Name] [varchar](500) NULL,
	[Firm ID] [varchar](500) NULL,
	[Product ID] [varchar](500) NULL,
	[Reader of Content] [varchar](500) NULL,
	[Reader E-Mail] [varchar](500) NULL,
	[Publisher Country] [varchar](500) NULL,
	[Ticker] [varchar](500) NULL,
	[Channel] [varchar](500) NULL
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_RSRCHX]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_RSRCHX]
GO

CREATE TABLE [dbo].[PortalUsageStaging_RSRCHX](
	[Client UUID] [varchar](500) NULL,
	[Client Org Firm Name] [varchar](500) NULL,
	[Client Org Country] [varchar](500) NULL,
	[Department] [varchar](500) NULL,
	[User UUID] [varchar](500) NULL,
	[Forename] [varchar](500) NULL,
	[Surname] [varchar](500) NULL,
	[Email] [varchar](500) NULL,
	[Country] [varchar](500) NULL,
	[Provider Name] [varchar](500) NULL,
	[Provider Country] [varchar](500) NULL,
	[Action Type] [varchar](500) NULL,
	[Action ID] [varchar](500) NULL,
	[Action Date (UTC)] [varchar](500) NULL,
	[Action Time (UTC)] [varchar](500) NULL,
	[Scrollage (%)] [varchar](500) NULL,
	[Total read time (secs)] [varchar](500) NULL,
	[Provider's Identifier] [varchar](500) NULL,
	[Report Title] [varchar](500) NULL,
	[Num of pages] [varchar](500) NULL,
	[Published Date] [varchar](500) NULL,
	[Authors] [varchar](500) NULL,
	[Regions] [varchar](500) NULL,
	[Countries] [varchar](500) NULL,
	[Specialities] [varchar](500) NULL,
	[Disciplines] [varchar](500) NULL,
	[Research Approach] [varchar](500) NULL,
	[Asset Classes] [varchar](500) NULL,
	[Asset Types] [varchar](500) NULL,
	[Sectors] [varchar](500) NULL,
	[Issuers] [varchar](500) NULL
) ON [PRIMARY]

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_ONEaccess]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 21 -- ONEaccess

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_ONEaccess) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_ONEaccess STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[viewed_date_UTC])
   AND YEAR(PU.ReadDate) = YEAR(STG.[viewed_date_UTC])
   AND DAY(PU.ReadDate) = DAY(STG.[viewed_date_UTC])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  [broker_document_id],
  [viewed_date_UTC],
  @SiteId,
  [Vendor Channel],
  [user_business_email],
  [user_name],
  [vendor_user_id],
  [client_name],
  [vendor_client_id]
FROM [dbo].[PortalUsageStaging_ONEaccess]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([viewed_date_UTC] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([viewed_date_UTC] AS DATE) ), 101)
FROM [PortalUsageStaging_ONEaccess]
WHERE ISDATE([viewed_date_UTC]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for OneAccess from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT  @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END


GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RedDeer]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 23 -- RedDeer

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RedDeer) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_RedDeer STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read_Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read_Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read_Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  [Vendor_Doc_ID ****],
  [Read_Date],
  @SiteId,
  '',
  [User_Business_Email],
  [User_Name],
  [User_ID **],
  [Client_Name],
  [Client_ID *]
FROM [dbo].[PortalUsageStaging_RedDeer]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read_Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read_Date] AS DATE) ), 101)
FROM [PortalUsageStaging_RedDeer]
WHERE ISDATE([Read_Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Red Deer from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END


GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_BlueMatrix]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 20 -- Blue Matrix

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_BlueMatrix) RETURN

-- Remove T Z from datetime
UPDATE PortalUsageStaging_BlueMatrix 
SET [Read Date/Time] = REPLACE(REPLACE([Read Date/Time],'T',''), 'Z', ''),
    [Document Date]  = REPLACE(REPLACE([Document Date],'T',''), 'Z', '')

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_BlueMatrix STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read Date/Time])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read Date/Time])
   AND DAY(PU.ReadDate) = DAY(STG.[Read Date/Time])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  [Product ID],
  [Read Date/Time],
  @SiteId,
  [Channel],
  [Primary E-Mail],
  [User Name],
  [User ID],
  [Firm name],
  [Firm ID]
FROM [dbo].[PortalUsageStaging_BlueMatrix]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date/Time] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read Date/Time] AS DATE) ), 101)
FROM [PortalUsageStaging_BlueMatrix]
WHERE ISDATE([Read Date/Time]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Blue Matrix from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate
--Changed by Anup Singh
SELECT @RowsLoaded,@PeriodStartDate,@PeriodEndDate

SET NOCOUNT OFF
END


GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_RSRCHX]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 22 -- RSRCHXchange

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_RSRCHX) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_RSRCHX STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Action Date (UTC)])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Action Date (UTC)])
   AND DAY(PU.ReadDate) = DAY(STG.[Action Date (UTC)])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  [Provider's Identifier],
  [Action Date (UTC)],   -- 'read time' component not needed
  @SiteId,
  '',
  [Email],
  [Surname] + ', ' + [Forename],
  [User UUID],
  [Client Org Firm Name],
  [Client UUID]
FROM [dbo].[PortalUsageStaging_RSRCHX]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Action Date (UTC)] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Action Date (UTC)] AS DATE) ), 101)
FROM [PortalUsageStaging_RSRCHX]
WHERE ISDATE([Action Date (UTC)]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for RSRCHXchange from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END



GO

-- Grant Permissions
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_ONEaccess]  TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_RedDeer]    TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_BlueMatrix] TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_RSRCHX]     TO DE_IIS
GO