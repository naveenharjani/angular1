-- spSearchAnalystSettings_Rollback.sql
-- 08/14/217

/*
spSearchAnalystSettings


*/
USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSearchAnalystSettings]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT,
  @AnalystId     int
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
DECLARE @AnalystFilter varchar(100)
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'

DECLARE @Sort varchar(100)
SELECT @Sort = CASE @SortCol
  WHEN '5' THEN @SortCol +  @SortDir + ', 27'
  WHEN '6' THEN @SortCol +  @SortDir
  ELSE @SortCol +  @SortDir + ', 5, 27'
END

-- Pivot relevant market data
SELECT
  Ticker,
  MAX(CASE BloombergMnemonic WHEN 'EXPECTED_REPORT_DT'     THEN Value ELSE '' END) ReportDate,
  MAX(CASE BloombergMnemonic WHEN 'EXPECTED_REPORT_PERIOD' THEN Value ELSE '' END) ReportPeriod,
  MAX(CASE BloombergMnemonic WHEN 'EQY_FISCAL_YR_END'      THEN Value ELSE '' END) FiscalYearEndLast,
  MAX(CASE BloombergMnemonic WHEN 'NEXT_FISCAL_YR_END'     THEN Value ELSE '' END) FiscalYearEndNext
INTO #TmpMarketData
FROM vBloombergPricingLatest
GROUP BY Ticker

-- Convert empty strings to null to enable downstream datetime conversion
UPDATE #TmpMarketData SET ReportDate = null WHERE ReportDate = ''
UPDATE #TmpMarketData SET FiscalYearEndNext = null WHERE FiscalYearEndNext = ''

SET @AnalystFilter = ''
IF @AnalystId <> -1 SET @AnalystFilter = 'and RC.AnalystId = ' + CONVERT(VARCHAR,@AnalystId)

CREATE TABLE #TmpSearch
(
  ID                    int IDENTITY,
  CoverageId            int,
  AnalystId             int,
  Region                varchar(100),
  Analyst               varchar(100),
  Company               varchar(100),
  Ticker                varchar(100),
  BenchmarkIndex        varchar(100),
  EpsTypeId             int,
  MetricsTypeId         int,
  EstimatePeriodId      int,
  EpsType               varchar(10),
  MetricsType           varchar(10),
  EstimatePeriod        varchar(10),
  ExchangeCurCode       varchar(10),
  ModelCurCode          varchar(10),
  UnitMultiplier        bigint,
  ReportDate            varchar(20), --datetime,
  ReportDateSort        varchar(20), --datetime,
  ReportPeriod          varchar(20),
  FiscalYearEndLast     varchar(20),
  FiscalYearEndLastSort varchar(20), --datetime,
  FiscalYearEndNext     varchar(20), --datetime,
  LaunchDate            datetime,
  Editor                varchar(36),
  EditDate              datetime,
  IsMigrated            int,
  OrdNo                 int,
  IsPrimary             char(1),
  SecurityId            int
)

declare @sql varchar(max)

print '@AnalystFilter=' + @AnalystFilter

print '@SortCol=' + @SortCol

print '@SortDir=' + @SortDir

print '@Sort=' + @Sort

set @sql =
'select
  RC.CoverageId,
  RC.AnalystId,
  AR.Region,
  A.Last,
  S.Company,
  S.Ticker,
  S.BenchmarkIndex,
  AN.EpsTypeId,
  AN.MetricsTypeId,
  AN.EstimatePeriodId,
  ET.EpsType,
  MT.MetricsType,
  left(EP.EstimatePeriodDisplay, 4),
  S.CurrencyCode,
  FSS.CurCode,
  FSS.UnitMultiplier,
  T.ReportDate,
  substring(T.ReportDate, 7, 4) + substring(T.ReportDate, 1, 2) + substring(T.ReportDate, 4, 2) as ReportDateSort,
  T.ReportPeriod,
  T.FiscalYearEndLast,
  substring(T.FiscalYearEndLast, 4, 4) + substring(T.FiscalYearEndLast, 1, 2),
  T.FiscalYearEndNext,
  RC.LaunchDate,
  E.UserName,
  AN.EditDate,
  0, -- Not migrated
  S.OrdNo,
  S.IsPrimary,
  S.SecurityId
from ResearchCoverage RC
join Authors A on A.AuthorId = RC.AnalystId
join AuthorRegions AR on AR.RegionId = A.RegionId
join Securities2 S ON S.SecurityId = RC.SecurityId
join AnalystSettings AN on AN.CoverageId = RC.CoverageId
join EpsTypes ET on ET.EpsTypeId = AN.EpsTypeId
join MetricsTypes MT on MT.MetricsTypeId = AN.MetricsTypeId
join EstimatesPeriods EP on EP.EstimatePeriodID = AN.EstimatePeriodId
left join FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
left join FinancialSecuritySettings FSS on FSS.SecurityId = RC.SecurityId
left join #TmpMarketData T on T.Ticker = S.Ticker
left join Users E ON E.UserId = AN.EditorId
where RC.DropDate IS NULL
and RC.AnalystId not in (select AnalystId from MigratedAnalysts) ' + @AnalystFilter + '

union

select
  RC.CoverageId,
  RC.AnalystId,
  AR.Region,
  A.Last,
  S.Company,
  S.Ticker,
  S.BenchmarkIndex,
  FCS.TickerTableEpsId,
  FCS.TickerTableValuationId,
  FCS.BaseYear,
  EpsType = FNT1.FinancialNumberType,
  MetricsType = FNT2.FinancialNumberType,
  FCS.BaseYear,
  S.CurrencyCode,
  FSS.CurCode,
  FSS.UnitMultiplier,
  T.ReportDate,
  substring(T.ReportDate, 7, 4) + substring(T.ReportDate, 1, 2) + substring(T.ReportDate, 4, 2) as ReportDateSort,
  T.ReportPeriod,
  T.FiscalYearEndLast,
  substring(T.FiscalYearEndLast, 4, 4) + substring(T.FiscalYearEndLast, 1, 2),
  T.FiscalYearEndNext,
  RC.LaunchDate,
  E.UserName,
  FCS.EditDate,
  1, -- Migrated
  S.OrdNo,
  S.IsPrimary,
  S.SecurityId
from ResearchCoverage RC
join Authors A on A.AuthorId = RC.AnalystId
join AuthorRegions AR on AR.RegionId = A.RegionId
join Securities2 S on S.SecurityId = RC.SecurityId
left join FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
left join FinancialSecuritySettings FSS on FSS.SecurityId = RC.SecurityId
left join FinancialNumberTypes FNT1 on FNT1.FinancialNumberTypeId = FCS.TickerTableEpsId
left join FinancialNumberTypes FNT2 on FNT2.FinancialNumberTypeId = FCS.TickerTableValuationId
left join #TmpMarketData T on T.Ticker = S.Ticker
left join Users E on E.UserId = FCS.EditorId
where RC.DropDate IS NULL
and RC.AnalystId in (select AnalystId from MigratedAnalysts) ' + @AnalystFilter + '

order by ' + @Sort

print(@sql)

INSERT INTO #TmpSearch (CoverageId, AnalystId, Region, Analyst, Company, Ticker, BenchmarkIndex, EpsTypeId, MetricsTypeId, EstimatePeriodId, EpsType, MetricsType, EstimatePeriod, ExchangeCurCode, ModelCurCode, UnitMultiplier, ReportDate, ReportDateSort, ReportPeriod, FiscalYearEndLast, FiscalYearEndLastSort, FiscalYearEndNext, LaunchDate, Editor, EditDate, IsMigrated, OrdNo, IsPrimary, SecurityId)
EXEC(@sql)

SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT CoverageId, AnalystId, Region, Analyst, Company, Ticker, BenchmarkIndex, EpsTypeId, MetricsTypeId, EstimatePeriodId, EpsType, MetricsType, EstimatePeriod, ExchangeCurCode, ModelCurCode, UnitMultiplier, ReportDate, ReportDateSort, ReportPeriod, FiscalYearEndLast, FiscalYearEndLastSort, FiscalYearEndNext, LaunchDate, Editor, EditDate, IsMigrated, OrdNo, IsPrimary, SecurityId
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF
GO
