-- Fx.sql
-- 03/08/2017

/*

Support selection of any model currency on Estimate Set Administration screen
Dynamic market data selection of needed cross rates (obsolete need for static selection via poke)

spGetBloombergSecurities
vBloombergFXLatest - FX Cross, minor Cur, Same Cur - synthesize cross rate of 1
vFxLatest - New prototype
spGetBloombergFXRatesForXml - do not use BloombergSecurities

POST CC
- Delete FXSEC rows from BloombergSecurities
- Determine if BloombergSecurities table is still needed
- spRenderModelCurrencies - Now obsolete.  Drop in future CC
- How to use new view vFxLatest.  Integerate into revaluation (genereric FX formulas), supports market cap queries
- Determine if vFxLatest requires minor  is still needed
- Determine if vBloombergFXLatest is still needed
- Retrofit spRevaluate to use single valuation algebra using cross rates

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- =======================================================================
-- Author:  Naveen Harjani
-- Create date:  5/19/2008
-- Description:  Get the list of security tickers and index for the request
--------------------------------------------------------------------------
-- Revision Dt   Comments
--------------------------------------------------------------------------
-- 02/26/10      Get Currency TickerCodes as required for the FX Rates Ticker list needs.
-- 03/02/17      Get FX Securities list dynamically. Alias value as START_OF_DATA
--------------------------------------------------------------------------
-- =======================================================================

ALTER PROCEDURE [dbo].[spGetBloombergSecurities]
  @RequestTypeCode VARCHAR(6)
AS
BEGIN
SET NOCOUNT ON

-- Populate START-OF-DATA Bloomberg .req file section
-- Ticker - AAPL US Equity
-- Index  - SPX Index
-- FX     - USDGBP Curncy

IF @RequestTypeCode = 'ALLSEC' --All Securities
BEGIN
  SELECT
    CASE
      WHEN CHARINDEX('.', Ticker) > 0
      THEN REPLACE(Ticker, '.', ' ') + ' Equity'
      ELSE Ticker + ' US Equity'
    END AS 'START-OF-DATA', 'T' AS Type
  FROM dbo.Securities2
  UNION
  SELECT DISTINCT BenchmarkIndex + ' Index' AS 'START-OF-DATA', 'I' AS Type
  FROM dbo.Securities2
  WHERE BenchmarkIndex IS NOT NULL
  ORDER BY 2 DESC, 1
END

ELSE IF @RequestTypeCode = 'COVSEC' --Covered Securities
BEGIN
  SELECT
    CASE
      WHEN CHARINDEX('.', Ticker) > 0
      THEN REPLACE(Ticker, '.', ' ') + ' Equity'
      ELSE Ticker + ' US Equity'
    END AS 'START-OF-DATA', 'T' AS Type
  FROM ResearchCoverage RC
  JOIN Securities2 S ON S.SecurityId = RC.SecurityId
  WHERE RC.DropDate IS NULL
  UNION
  SELECT DISTINCT BenchmarkIndex + ' Index' AS 'START-OF-DATA', 'I' AS Type
  FROM ResearchCoverage RC
  JOIN Securities2 S on S.SecurityId = RC.SecurityId
  WHERE RC.DropDate is NULL
  ORDER BY 2 DESC, 1
END

ELSE IF @RequestTypeCode = 'FXSEC' --FX Currency Codes
BEGIN

  -- Model cur : Pricing cur (when currencies are different)
  -- Sample use:  Convert E in P/E to currency of P
  select distinct FSS.CurCode + S.CurrencyCode + ' Curncy' AS 'START-OF-DATA'
  from ResearchCoverage RC
  join Securities2 S on S.SecurityId = RC.SecurityId
  join FinancialSecuritySettings FSS on FSS.SecurityId = RC.SecurityId
  where RC.DropDate is null
  and S.CurrencyCode <> FSS.CurCode

  -- Model cur : Pricing cur (when currencies are same)
  -- Do not request cross rate when both currencies are the same, i.e. value of 1
  -- Bloomberg ignores and will not return a value of 1.
  -- Synthesize value of 1 in view vBloombergFXLatest

union

  -- Pricing cur : USD
  -- Sample use:  Convert non-USD market cap to USD market cap for comparison, e.g. small cap coverage
  select distinct S.CurrencyCode + 'USD' + ' Curncy' AS 'START-OF-DATA'
  from ResearchCoverage RC
  join Securities2 S on S.SecurityId = RC.SecurityId
  where RC.DropDate is null
  and S.CurrencyCode <> 'USD'

  order by 1
END

SET NOCOUNT OFF
END

GO

-- =======================================================================
-- Author:  Naveen Harjani
-- Create date:  8/4/2008
-- Description:  Get the latest marketdata pricing data.
-- 11/23/2015 : Includes FX Rate for minor currency tickers - USDGBp
-- 12/14/2015 : Includes FX Rate for minor currency tickers - GBpUSD, GBpHKD, GBpZAR
-- 9/8/2016   : Includes FX Rate for minor currency tickers - EURGBp
-- 3/10/2017  : Add Minor Currency and Same Currency Tickers list
-- =======================================================================
ALTER VIEW [dbo].[vBloombergFxLatest]
AS

-- FX Tickers
SELECT TOP 100 PERCENT
  md.Ticker,
  bf.Mnemonic AS BloombergMnemonic,
  md.RunDate AS DateAsOf,
  md.Value
FROM   dbo.BloombergPivotFX md
INNER JOIN (SELECT MAX(md2.Ticker) AS Ticker, MAX(md2.LoadDate) AS LoadDate
      FROM dbo.BloombergPivotFX md2
      GROUP BY md2.Ticker) md_latest
      ON md.Ticker = md_latest.Ticker AND md.LoadDate = md_latest.LoadDate
INNER JOIN dbo.BloombergFields bf ON md.FieldId = bf.FieldId

UNION

-- Minor Currency Tickers - synthesize value based on major currency values
SELECT TOP 100 PERCENT
  CASE
    WHEN md.Ticker = 'USDGBP' THEN 'USDGBp' COLLATE SQL_Latin1_General_CP1_CS_AS
    WHEN md.Ticker = 'EURGBP' THEN 'EURGBp' COLLATE SQL_Latin1_General_CP1_CS_AS
    WHEN md.Ticker = 'GBPUSD' THEN 'GBpUSD' COLLATE SQL_Latin1_General_CP1_CS_AS
    WHEN md.Ticker = 'GBPHKD' THEN 'GBpHKD' COLLATE SQL_Latin1_General_CP1_CS_AS
    WHEN md.Ticker = 'GBPZAR' THEN 'GBpZAR' COLLATE SQL_Latin1_General_CP1_CS_AS
    ELSE md.Ticker
  END as Ticker,
  bf.Mnemonic AS BloombergMnemonic,
  md.RunDate AS DateAsOf,
  CASE
    WHEN bf.Mnemonic = 'PX_LAST' AND md.Ticker = 'USDGBP' THEN CONVERT(varchar, CAST(md.Value as FLOAT) * 100)
    WHEN bf.Mnemonic = 'PX_LAST' AND md.Ticker = 'EURGBP' THEN CONVERT(varchar, CAST(md.Value as FLOAT) * 100)
    WHEN bf.Mnemonic = 'PX_LAST' AND md.Ticker = 'GBPUSD' THEN CONVERT(varchar, CAST(md.Value as FLOAT) / 100)
    WHEN bf.Mnemonic = 'PX_LAST' AND md.Ticker = 'GBPHKD' THEN CONVERT(varchar, CAST(md.Value as FLOAT) / 100)
    WHEN bf.Mnemonic = 'PX_LAST' AND md.Ticker = 'GBPZAR' THEN CONVERT(varchar, CAST(md.Value as FLOAT) / 100)
    ELSE md.Value
  END as Value
FROM dbo.BloombergPivotFX md
INNER JOIN (SELECT MAX(md2.Ticker) AS Ticker, MAX(md2.LoadDate) AS LoadDate
      FROM  dbo.BloombergPivotFX md2
      WHERE Ticker IN ('USDGBP', 'GBPUSD', 'GBPHKD', 'GBPZAR', 'EURGBP')
      GROUP BY md2.Ticker) md_latest
      ON md.Ticker = md_latest.Ticker AND md.LoadDate = md_latest.LoadDate
INNER JOIN dbo.BloombergFields bf ON md.FieldId = bf.FieldId

UNION

-- Same Currency Tickers - synthesize fx cross rate of 1 when Price Currency same as Estimate Currency
SELECT distinct TOP 100 PERCENT
   FSS.CurCode + S.CurrencyCode AS Ticker,
  'PX_LAST' AS BloombergMnemonic,
  getdate() AS DateAsOf,
  '1' AS Value
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN FinancialSecuritySettings FSS ON FSS.SecurityId = RC.SecurityId
WHERE RC.DropDate IS NULL
AND S.CurrencyCode = FSS.CurCode

ORDER BY 1, 2
-- The ORDER BY clause is invalid in views, inline functions, derived tables, subqueries, and common table expressions, unless TOP, OFFSET or FOR XML is also specified.

GO

IF EXISTS(SELECT * FROM SYS.views WHERE name = 'vFXLatest' AND type = 'V')
DROP VIEW [dbo].[vFxLatest]
GO

CREATE VIEW [dbo].[vFxLatest]
AS
SELECT
  FX1.Ticker,
  FX1.Value as Price,
  FX2.Value as Date
FROM BloombergPivotFX FX1
JOIN (SELECT MAX(Ticker) AS Ticker, MAX(LoadDate) AS LoadDate FROM BloombergPivotFX GROUP BY Ticker) FX_latest ON FX1.Ticker = FX_latest.Ticker AND FX1.LoadDate = FX_latest.LoadDate  -- Latest FX
JOIN BloombergPivotFX FX2 ON FX2.Ticker = FX1.Ticker AND FX2.LoadDate = FX1.LoadDate
WHERE FX1.FieldId = (SELECT FieldId FROM BloombergFields WHERE Mnemonic = 'PX_LAST' AND RequestTypeId = 5) -- Close Price
AND FX2.FieldId = (SELECT FieldId FROM BloombergFields WHERE Mnemonic = 'PX_CLOSE_DT' AND RequestTypeId = 5) -- Close Date
GO

-- =======================================================================
-- Author:  Naveen Harjani
-- Create date:  02/26/2010
-- Description:  Retrieves the latest available marketdata formatted for fx.xml generation (pivotted)
-- 11/23/2015 : Includes FX Rate for minor currency tickers - USDGBp
-- =======================================================================
ALTER PROCEDURE [dbo].[spGetBloombergFxRatesForXml] AS
BEGIN
  SET NOCOUNT ON

  DECLARE @cFXRequestTypeCode varchar(4)

  --Set the Request Id for the 'EOD FX' request for generating the FX xml
  SET @cFXRequestTypeCode = 'FXP'

  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  -- create hash for MarketdataFields table
  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  --select Mnemonic AS BloombergMnemonic, XmlAttribute, dataType
  SELECT Mnemonic AS BloombergMnemonic, dataType
    INTO #tmp_MarketdataFields
    FROM BloombergFields
    WHERE RequestTypeId IN (SELECT RequestTypeId FROM BloombergRequestTypes WHERE RequestTypeCode = @cFXRequestTypeCode)

  --Check if the global temporary table "##tmpFXLatestFormattedData" exists, then drop the table.
  if exists (select  * from tempdb.dbo.sysobjects o where o.xtype in ('U') and o.id = object_id( N'tempdb..##tmpFXLatestFormattedData'))
  begin
    drop table ##tmpFXLatestFormattedData
  end

  --Check if the global temporary table "##tmpFXLatestXML" exists, then drop the table.
  if exists (select  * from tempdb.dbo.sysobjects o where o.xtype in ('U') and o.id = object_id( N'tempdb..##tmpFXLatestXML'))
  begin
    drop table ##tmpFXLatestXML
  end

  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  -- declare local variables
  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  declare @pivot_query varchar(8000)
  declare @BloombergMnemonic varchar(32)
  --declare @XmlAttribute varchar(64)
  declare @index int
  set @pivot_query = 'SELECT max(md.DateAsOf) AS dateAsOf,  max(CASE WHEN md.Ticker IS NOT NULL THEN md.Ticker COLLATE Latin1_General_CS_AS ELSE md.Ticker END) AS ticker, '

  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  -- construct pivot query string
  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  select @index=count(*) from #tmp_MarketdataFields
  --
  while (@index>0)
  begin
  set rowcount 1
    --select @BloombergMnemonic = BloombergMnemonic, @XmlAttribute = XmlAttribute
    select @BloombergMnemonic = BloombergMnemonic
    from #tmp_MarketdataFields order by BloombergMnemonic
    set @pivot_query =   @pivot_query + 'max(CASE md.BloombergMnemonic WHEN ''' + @BloombergMnemonic + ''' THEN [Value] ELSE '''' END) AS ' + @BloombergMnemonic + ', '
    set @index = @index-1
    delete from #tmp_MarketdataFields where BloombergMnemonic = @BloombergMnemonic
  end
  set rowcount 0
  -- trim the last comma and space (2 characters)
  set @pivot_query = substring(@pivot_query, 0, len(@pivot_query))

    --append into temp table
  set @pivot_query = @pivot_query + ' INTO ##tmpFXLatestFormattedData '

  -- append from statement
  set @pivot_query = @pivot_query + ' FROM vBloombergFXLatest md '

  --set @pivot_query = @pivot_query + ' INNER JOIN BloombergSecurities s ON md.Ticker = s.Identifier'
  set @pivot_query = @pivot_query + ' GROUP BY md.ticker  ORDER BY MAX(md.Ticker)'

  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  -- execute pivot query
  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  exec (@pivot_query)
  --select(@pivot_query) -- debug
  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -

  --Apply column formatting to various xml fields as required for the marketdata.xml file
  SELECT *
  INTO    ##tmpFXLatestXML
  FROM  ##tmpFXLatestFormattedData

  SELECT  * FROM ##tmpFXLatestXML

  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  -- clean up
  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  drop table ##tmpFXLatestFormattedData
  drop table ##tmpFXLatestXML
  drop table #tmp_MarketdataFields
  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - -

  SET NOCOUNT OFF
END


GO

/*
-- DEBUG

spGetBloombergSecurities 'ALLSEC'
go
spGetBloombergSecurities 'COVSEC'
go
spGetBloombergSecurities 'FXSEC'
go

SELECT * FROM vBloombergFxLatest
SELECT * FROM vBloombergFxLatest where Value <> '1'
SELECT * FROM vBloombergFxLatest where Value = '1'
go

SELECT * FROM vFxLatest
go

spGetBloombergFXRatesForXml
go

---
SELECT * FROM BloombergPivotFX
SELECT * FROM BloombergFields
SELECT * FROM BloombergSecurities ORDER BY EditDate ASC
SELECT * FROM Currencies ORDER BY CurrencyCode

spRenderModelCurrencies -- 'USD'
spRenderModelCurrencies dependency: analystsettingsadm.asp
sp_helptext spRenderModelCurrencies

sp_helptext spRenderCurrencies

SELECT * FROM Currencies

FX Rates dependency:  spGetFinancialNumbersFXRatesXml, spRevaluate

-- Get Tickers with minor Currency 'GBp', 'ZAR', as per active coverage
SELECT distinct
--S.SecurityId, S.Ticker, S.Company,
S.CurrencyCode as PriceCur,
FSS.CurCode AS EstimateCur
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN FinancialSecuritySettings FSS ON FSS.SecurityId = RC.SecurityId
WHERE RC.DropDate IS NULL
and S.CurrencyCode IN ('GBp', 'ZAR')
-- and S.CurrencyCode IN ('GBp') and FSS.CurCode = 'EUR'
and S.CurrencyCode != FSS.CurCode

-- GBp	EUR  e.g. VOD.LN	Vodafone Group PLC
-- GBp	GBp  e.g  BARC.LN Barclays PLC
-- GBp	USD  e.g. AZN.LN  AstraZeneca PLC
-- ZAR	ZAR  e.g. OML.SJ	Old Mutual PLC

*/