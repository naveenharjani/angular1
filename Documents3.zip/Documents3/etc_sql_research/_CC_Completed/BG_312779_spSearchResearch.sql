-- CC_spSearchResearch.sql
-- 07/11/2019

/*
alter spSearchResearch - Increase the size of @SQL to varchar(max) to accomodate for text search via elastic.
Elastic text search returns upto a max of 1000 comma separated PubNo's
*/
use Research
go

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSearchResearch]
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT,
  @Max           int,
  @SQL           varchar(max)
AS

SET NOCOUNT ON

DECLARE @FirstRow int
DECLARE @LastRow  int

CREATE TABLE #TmpSearch
(
  ID            int IDENTITY,
  PubNo         int,
  Date          datetime,
  Type          varchar(31),
  Title         varchar(255),
  FileName      varchar(255),
  Approver      varchar(31),
  ApprovedDate  datetime,
  PublishedDate datetime,
  Version       int,
  SubType       varchar(30)
)

SET ROWCOUNT @Max
INSERT INTO #TmpSearch (PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, SubType)
EXEC
(
'SELECT a.PubNo, a.Date, a.Type, a.Title, a.FileName, a.Approver, a.ApprovedDate, a.PublishedDate, a.Version, a.SubType FROM Publications a WITH(NOLOCK) '
+ @SQL
+ ' ORDER BY a.Date DESC, a.PubNo DESC'
)
SET ROWCOUNT 0
SELECT @Ct = COUNT(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT
  T.PubNo,
  T.Date,
  CASE T.Type
    WHEN 'Research Call'    THEN 'Call'
    WHEN 'External Flash'   THEN 'Quick Take'
    WHEN 'Research Note'    THEN 'Note'
    WHEN 'Black Book'       THEN 'Blackbook'
    WHEN 'White Book'       THEN 'Whitebook'
    WHEN 'Research Summary' THEN 'Summary'
    ELSE T.Type
  END 'Type',
  T.Title,
  T.FileName,
  T.Approver,
  T.ApprovedDate,
  T.PublishedDate,
  T.Version,
  CASE
    WHEN SubType LIKE 'Industry%' THEN 'Industry '
    WHEN SubType LIKE 'Company%'  THEN 'Company '
    ELSE ''
  END 'SubType'
FROM #TmpSearch T
WHERE T.ID > @FirstRow AND T.ID < @LastRow
GROUP BY T.PubNo, T.Date, T.Type, T.Title, T.FileName, T.Approver, T.ApprovedDate, T.PublishedDate, T.Version, T.SubType
ORDER BY T.Date DESC, T.PubNo Desc
SET NOCOUNT OFF

GO