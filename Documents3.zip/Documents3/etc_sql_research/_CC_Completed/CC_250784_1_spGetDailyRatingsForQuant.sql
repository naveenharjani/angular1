-- spGetDailyRatingsForQuant.sql
-- 05/04/2017

/*

spGetDailyRatingsForQUANT
SinceDate
UntilDate

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE name = 'spGetDailyRatingsForQUANT' and TYPE = 'P')
DROP PROCEDURE [dbo].[spGetDailyRatingsForQUANT]
GO

CREATE PROCEDURE [dbo].[spGetDailyRatingsForQUANT]
  @SinceDate  VARCHAR(10) = NULL,
  @UntilDate  VARCHAR(10) = NULL
AS
BEGIN

SET NOCOUNT ON

-- Set default date range
IF (@SinceDate IS NULL OR @UntilDate IS NULL)
BEGIN
  SET @SinceDate = dateadd(dd,-5, CAST(getdate() as DATE))
  SET @UntilDate = dateadd(dd, 0, CAST(getdate() as DATE))
END

SELECT
  CONVERT(VARCHAR(30), S.Company) AS Company,
  S.Ticker,
  CONVERT(VARCHAR(15), A.Last) AS Analyst,
  R.RegionAlias AS Region,
  DR.Date,
  DR.Rating,
  S.ISIN,
  S.SEDOL,
  S.CUSIP
FROM DailyRatings DR
JOIN ResearchCoverage RC ON RC.CoverageId = DR.CoverageId
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN Authors A ON A.AuthorId = RC.AnalystId
JOIN Regions R ON R.RegionId = S.RegionId
WHERE S.IsPrimary = 'Y'
AND DR.Date BETWEEN @SinceDate AND @UntilDate
ORDER BY 1, 2, 3, 5

-- Write to Event Log
INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'QUANT', 'QUANT (' + CURRENT_USER + ') retrieved data (spGetDailyRatingsForQUANT)')

END
GO

GRANT EXECUTE ON [dbo].[spGetDailyRatingsForQUANT] TO PowerUsers, SCBIS_QUANT
GO

-- DEBUG
/*


EXEC [dbo].[spGetDailyRatingsForQUANT]
GO

EXEC [dbo].[spGetDailyRatingsForQUANT] '04/15/2017', '04/30/2017'
GO

SELECT * FROM DailyRatings DR WHERE Date BETWEEN '04/01/2017' AND '04/15/2017'

SELECT * FROM EVentLog Where Source = 'QUANT' ORDER BY TimeStamp DESC

*/