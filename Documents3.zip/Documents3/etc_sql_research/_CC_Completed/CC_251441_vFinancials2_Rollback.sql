-- CC_vFinancials2_Rollback.sql
-- 05/15/2017

/*

alter vFinancials2

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO


ALTER VIEW [dbo].[vFinancials2]
AS

--Stocks
SELECT
  PF.SecurityId,
  S.Ticker,
  P.Date,
  PF.PubNo,
  PF.CoverageAction,
  -- Rating
  PF.Rating,
  PF.RatingPrior,
  PF.RatingAction,
  -- Target Price
  PF.TargetPrice,
  PF.TargetPricePrior,
  PF.TargetPriceAction,
  PF.TargetPriceOrig,
  --
  PF.BaseYear AS LastYear,
  PF.BaseYear + 1 AS ThisYear,
  PF.BaseYear + 2 AS NextYear,
  -- EPS
  PF.EpsType,
  PF.EpsFY0 AS EPSLastYear,
  PF.EpsFY1 AS EPSThisYear,
  PF.EpsFY1Prior AS EPSThisYearPrior,
  PF.EpsFY1Action AS EstimateAction,
  PF.EpsFY2 AS EPSNextYear,
  PF.EpsFY2Prior AS EPSNextYearPrior,
  PF.EpsFY2Action AS EstimateNextYearAction,
  -- Metric
  FNT.FinancialNumberType AS MetricType,
  '' AS MetricLastYear,
  '' AS MetricThisYear,
  '' AS MetricNextYear,
  --
  PF.PriceCurrency AS Currency,
  '' AS YTDRelPerf,
  '' AS Yield,
  -- Coverage dates
  RC.LaunchDate,
  RC.DropDate,
  P.FileName,
  RC.CoverageId,
  RC.IndustryId,
  RC.AnalystId,
  PF.CloseDate,
  PF.ClosePrice,
  '' AS TickerOrder,
  '' AS DisplayCloseDate,
  '' AS RelPerfType
FROM
  ResearchCoverage RC
  JOIN PublicationFinancials PF ON PF.CoverageId = RC.CoverageId
  JOIN Publications P ON P.PubNo = PF.PubNo
  JOIN Securities2 S ON S.Ticker = PF.Ticker AND S.TickerType = 'Stock'
  LEFT JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
  LEFT JOIN FinancialNumberTypes FNT ON FNT.FinancialNumberTypeId = FCS.TickerTableValuationId
WHERE
  RC.LaunchDate IS NOT NULL

UNION

--Indexes
SELECT
  PF.SecurityId,
  S.Ticker,
  P.Date,
  PF.PubNo,
  PF.CoverageAction,
  -- Rating
  '' AS Rating,
  '' AS RatingPrior,
  '' AS RatingAction,
  -- Target Price
  '' AS TargetPrice,
  '' AS TargetPricePrior,
  '' AS TargetPriceAction,
  '' AS TargetPriceOrig,
  --
  PF.BaseYear AS LastYear,
  PF.BaseYear + 1 AS ThisYear,
  PF.BaseYear + 2 AS NextYear,
  -- EPS
  PF.EpsType,
  PF.EpsFY0 AS EPSLastYear,
  PF.EpsFY1 AS EPSThisYear,
  '' AS EPSThisYearPrior,
  PF.EpsFY1Action AS EstimateAction,
  PF.EpsFY2 AS EPSNextYear,
  '' AS EPSNextYearPrior,
  PF.EpsFY2Action AS EstimateNextYearAction,
  -- Metric
  '' AS MetricType,
  '' AS MetricLastYear,
  '' AS MetricThisYear,
  '' AS MetricNextYear,
  --
  PF.PriceCurrency AS Currency,
  '' AS YTDRelPerf,
  '' AS Yield,
  -- Coverage dates
  NULL AS LaunchDate,
  NULL AS DropDate,
  P.FileName,
  NULL AS CoverageId,
  NULL AS IndustryId,
  NULL AS AnalystId,
  PF.CloseDate,
  PF.ClosePrice,
  '' AS TickerOrder,
  '' AS DisplayCloseDate,
  '' AS RelPerfType
FROM
  PublicationFinancials PF
  JOIN Publications P ON P.PubNo = PF.PubNo
  JOIN Securities2 S ON S.Ticker = PF.Ticker AND S.TickerType = 'Index'


GO