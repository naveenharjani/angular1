-- Admin_Rollback.sql
-- 03/20/2017

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- Trailing spaces in Name fields
GO

ALTER PROCEDURE [dbo].[spSaveSecurity]
  @SecurityId     int OUTPUT,
  @TickerType     varchar(10),
  @Company        varchar(63),
  @BLOOMBERG      varchar(10),
  @RIC            varchar(10),
  @CUSIP          varchar(10),
  @SEDOL          varchar(10),
  @CINS           varchar(10),
  @ISIN           varchar(12),
  @VALOREN        varchar(20),
  @ExchangeCode   varchar(10),
  @CurrencyCode   char(3),
  @BenchmarkIndex varchar(10),
  @CountryCode    char(2),
  @RegionId       int,
  @Active         smallint,
  @EditorId       int,
  @GICS_ID        int,
  @Alias          varchar(50),
  @CompanyId      int
AS

BEGIN TRANSACTION

DECLARE
  @Ticker    varchar(10),
  @EditDate  datetime,
  @IsPrimary char(1),
  @OrdNo     int

SELECT
  @Ticker   = @BLOOMBERG,
  @EditDate = GETDATE()

-- Automate the following security attributes based on supplied Exchange Code

SELECT
  @CurrencyCode   = CurrencyCode,
  @BenchmarkIndex = BenchmarkIndex,
  @CountryCode    = CountryCode,
  @RegionId       = RegionId
FROM Exchanges WHERE ExchangeCode = @ExchangeCode

-- UPDATE existing security
IF EXISTS (SELECT SecurityId FROM Securities2 WHERE SecurityId = @SecurityId)
  BEGIN
    DECLARE @TickerOld varchar(10), @CompanyOld varchar(63), @CompanyIdOld int
    SELECT @TickerOld = Ticker, @CompanyOld = Company, @CompanyIdOld = CompanyId, @IsPrimary = IsPrimary, @OrdNo = OrdNo
    FROM Securities2 WHERE SecurityId = @SecurityId

    -- Realign existing security with NEW Company

    IF @CompanyId = -1
      BEGIN
        INSERT INTO Companies(Company) SELECT @Company
        SELECT @CompanyId = @@IDENTITY, @IsPrimary = 'Y', @OrdNo = 1

        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('Companies', 'A', @Company, NULL, @CompanyId, @EditorId, @EditDate)
      END

    -- Realign existing security with EXISTING Company

    ELSE
      BEGIN
        IF @CompanyId <> @CompanyIdOld
        BEGIN
          SELECT @Company = Company from Companies WHERE CompanyId = @CompanyId
          IF EXISTS (SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
            SELECT @IsPrimary = 'N', @OrdNo = MAX(OrdNo) + 1 FROM Securities2 WHERE CompanyId = @CompanyId
          ELSE
            SELECT @IsPrimary = 'Y', @OrdNo = 1
        END
      END

    IF @Ticker <> @TickerOld
    BEGIN
      -- Propagate ticker change
      UPDATE Properties    SET PropValue = @Ticker WHERE PropId = 13 AND PropValue = @TickerOld
      UPDATE PropertiesLog SET PropValue = @Ticker WHERE PropId = 13 AND PropValue = @TickerOld
      UPDATE TickerTableSecurities    SET Ticker = @Ticker WHERE Ticker = @TickerOld
      UPDATE TickerTableSecuritiesOld SET Ticker = @Ticker WHERE Ticker = @TickerOld
      UPDATE PublicationFinancials SET Ticker = @Ticker WHERE Ticker = @TickerOld
    END

    IF (@CompanyIdOld = @CompanyId) AND (@CompanyOld <> @Company)
    BEGIN
      -- Propagate company change
      UPDATE Companies           SET Company = @Company WHERE Company = @CompanyOld
      UPDATE Securities2         SET Company = @Company WHERE Company = @CompanyOld
      UPDATE ValuationsCompanies SET Company = @Company WHERE Company = @CompanyOld
      UPDATE RisksCompanies      SET Company = @Company WHERE Company = @CompanyOld
    END

    UPDATE Securities2 SET
      TickerType     = @TickerType,
      Company        = @Company,
      Ticker         = @BLOOMBERG,
      RIC            = @RIC,
      CUSIP          = @CUSIP,
      SEDOL          = @SEDOL,
      CINS           = @CINS,
      ISIN           = @ISIN,
      VALOREN        = @VALOREN,
      ExchangeCode   = @ExchangeCode,
      CurrencyCode   = @CurrencyCode,
      BenchmarkIndex = @BenchmarkIndex,
      CountryCode    = @CountryCode,
      RegionId       = @RegionId,
      IsActive       = @Active,
      EditorId       = @EditorId,
      EditDate       = @EditDate,
      GICS_ID        = @GICS_ID,
      Alias          = @Alias,
      CompanyId      = @CompanyId,
      IsPrimary      = @IsPrimary,
      OrdNo          = @OrdNo
    WHERE SecurityId = @SecurityId

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Securities', 'U', @Ticker + ' | ' + @Company, @TickerOld + ' | ' + @CompanyOld, @SecurityId, @EditorId, @EditDate)

  END

-- ADD new security

ELSE
  BEGIN
    -- Align new security with NEW Company

    IF @CompanyId = -1
      BEGIN
        INSERT INTO Companies(Company) SELECT @Company
        SELECT @CompanyId = @@IDENTITY, @IsPrimary = 'Y', @OrdNo = 1

        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('Companies', 'A', @Company, NULL, @CompanyId, @EditorId, @EditDate)
      END

    -- Align new security with EXISTING Company
    ELSE
      BEGIN
        SELECT @Company = Company from Companies WHERE CompanyId = @CompanyId
        IF EXISTS (SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
          SELECT @IsPrimary = 'N', @OrdNo = max(OrdNo) + 1 FROM Securities2 WHERE CompanyId = @CompanyId
        ELSE
          SELECT @IsPrimary = 'Y', @OrdNo = 1
      END

    INSERT INTO Securities2
      (TickerType, Company, Ticker, RIC, CUSIP, SEDOL, CINS, ISIN, VALOREN, ExchangeCode, CurrencyCode, BenchmarkIndex, CountryCode, RegionId, IsActive, EditorId, EditDate, GICS_ID, Alias, CompanyId, IsPrimary, OrdNo)
    VALUES
      (@TickerType, @Company, @BLOOMBERG, @RIC, @CUSIP, @SEDOL, @CINS, @ISIN, @VALOREN, @ExchangeCode, @CurrencyCode, @BenchmarkIndex, @CountryCode, @RegionId, @Active, @EditorId, @EditDate, @GICS_ID, @Alias, @CompanyId, @IsPrimary, @OrdNo)

    SELECT @SecurityId = @@IDENTITY
    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Securities', 'A', @Ticker + ' | ' + @Company, NULL, @SecurityId, @EditorId, @EditDate)

  END

COMMIT TRANSACTION

RETURN 0


GO



ALTER PROCEDURE [dbo].[spSaveAuthor]
  @AuthorID        smallint OUTPUT,
  @Name            varchar(48),
  @Last            varchar(32),
  @First           varchar(16),
  @Phone           varchar(20),
  @Fax             varchar(20),
  @ExtEmail        varchar(50),
  @IntEmail        varchar(32),
  @IsAnalyst       smallint,
  @Active          smallint,
  @EditorID        int,
  @TitleID         int,
  @RegionID        int,
  @UserName        varchar(36),
  @MetricsEligible char(1),
  @IsResearch      char(1),
  @GoUrl           varchar(100)
AS
DECLARE @EditDate datetime
SELECT @EditDate = GETDATE()

BEGIN TRANSACTION
IF EXISTS (SELECT AuthorID FROM Authors WHERE AuthorID = @AuthorID)
  BEGIN
    DECLARE @NameOld varchar(48)
    SELECT @NameOld = Name FROM Authors WHERE AuthorID = @AuthorID
    IF @Name <> @NameOld
      BEGIN
        -- START - Propagate textual updates
        UPDATE Properties SET PropValue = @Name where PropID = 5 and PropValue = @NameOld
        UPDATE PropertiesLog SET PropValue = @Name where PropID = 5 and PropValue = @NameOld
        -- FINISH
        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('Authors', 'U', @Name, @NameOld, @AuthorID, @EditorID, @EditDate)
      END
    UPDATE Authors SET
      Name            = @Name,
      Last            = @Last,
      First           = @First,
      Phone           = @Phone,
      Fax             = @Fax,
      ExtEmail        = @ExtEmail,
      IntEmail        = @IntEmail,
      IsAnalyst       = @IsAnalyst,
      IsActive        = @Active,
      EditorID        = @EditorID,
      EditDate        = @EditDate,
      TitleID         = @TitleID,
      RegionID        = @RegionID,
      WindowsUserName = @UserName,
      MetricsEligible = @MetricsEligible,
      IsResearch      = @IsResearch,
      GoUrl           = @GoUrl
    WHERE AuthorID = @AuthorID
  END
ELSE
  BEGIN
    INSERT INTO Authors
      (Name, Last, First, Phone, Fax, ExtEmail, IntEmail, IsAnalyst, IsActive, EditorId, EditDate, TitleID, RegionID, MetricsEligible, WindowsUserName, IsResearch, GoUrl)
    VALUES
      (@Name, @Last, @First, @Phone, @Fax, @ExtEmail, @IntEmail, @IsAnalyst, @Active, @EditorID, @EditDate, @TitleID, @RegionID, @MetricsEligible, @UserName, @IsResearch, @GoUrl)
    SELECT @AuthorID = @@IDENTITY
    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Authors', 'A', @Name, NULL, @AuthorID, @EditorID, @EditDate)
  END
COMMIT TRANSACTION
RETURN 0

GO




/*

-- Trailing spaces in Securities2.Company, Securities2.Ticker, Companies.Company
sp_helptext spSaveSecurity  -- Securities2.Company, Companies.Company

-- Trailing spaces in Authors.Name
sp_helptext spSaveAuthor

sp_helptext spSaveUser

*/
