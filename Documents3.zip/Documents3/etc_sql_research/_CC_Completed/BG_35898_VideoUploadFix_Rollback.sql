-- VideoUploadFix_Rollback.sql
-- 02/08/2021

/*

alter spSavePublication2       

*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSavePublication2]
  @PublicationXML text
AS

/*
This proc is used by Beehive Content Contribution to publish media types "Video" and "Podcast".
*/

DECLARE @hDoc int
DECLARE @vPubNo int
DECLARE @vPublishedDate datetime
DECLARE @vType varchar(31)
DECLARE @EditorId int
DECLARE @EditDate datetime

EXEC sp_xml_preparedocument @hDoc OUTPUT, @PublicationXML

--Retrive PubNo, Date, Type, EditDate & EditorId from payload xml
SELECT @vPubNo = PubNo, @vPublishedDate = PublishedDate, @vType = Type, @EditorId = EditorId, @EditDate = EditDate FROM OPENXML (@hDoc, '/Research/Publications',1)
WITH (PubNo int '@PubNo', PublishedDate datetime '@PublishedDate', Type varchar(31) '@Type', EditorId int '@EditorId', EditDate datetime '@EditDate')

--Add Publication metadata to Publications table
INSERT INTO Publications (PubNo, Date, Type, Title, FileName, FileSize, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate)
SELECT * FROM OPENXML (@hDoc, '/Research/Publications', 1)
WITH (PubNo int '@PubNo', Date datetime '@Date', Type varchar(31) '@Type', Title varchar(255) '@Title', FileName varchar(255) '@FileName', FileSize int '@FileSize', Approver varchar(31) '@Approver', ApprovedDate datetime '@ApprovedDate', PublishedDate datetime '@PublishedDate',  Version int '@Version', Instructions int '@Instructions', EditorId int '@EditorId', EditDate datetime '@EditDate')

--Add ticker/industry/author metadata to Properties table
INSERT INTO Properties (PubNo, PropId, PropValue)
SELECT @vPubNo,PropId,PropValue FROM OPENXML (@hDoc, '/Research/Properties/Property', 1)
WITH (PropId smallint '@propId',PropValue varchar(255) '@value')

--Populate related publications 
INSERT INTO RelatedPublications (PubNo, RelatedPubNo, EditorId, EditDate)
SELECT @vPubNo, RelatedPubno, @EditorId, @EditDate FROM OPENXML (@hDoc, '/Research/RelatedPublications/RelatedPublication', 1)
WITH (RelatedPubNo int '@pubNo')

--Map Video/Podcast to product groups based on the metadata
EXEC spInsProductGroupDocsByPubNo @vPubNo,@vPublishedDate ,@vType

--Index video/podcast metadata in elastic
INSERT INTO ElasticQueue(PubNo,Operation,Queued,QueuedBy)
SELECT @vPubNo,'I',getdate(),0

EXEC sp_xml_removedocument @hDoc
GO