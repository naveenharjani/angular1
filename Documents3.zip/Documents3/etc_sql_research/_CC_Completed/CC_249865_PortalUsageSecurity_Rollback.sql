-- PortalUsageSecurity_Rollback.sql
-- 04/28/2017

/*

Create Role 'Role_SSIS_user' that DE_IIS user inherits - for bulk inserts from SSIS packages
DE_IIS needs BULK INSERT to load into tables

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- Role that DE_IIS inherits - for bulk inserts from SSIS packages
DROP ROLE [Role_SSIS_user]
GO
