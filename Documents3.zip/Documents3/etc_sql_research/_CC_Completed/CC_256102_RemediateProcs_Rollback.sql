-- RemediateProcs_Rollback.sql
-- 06/09/2017

/*

After the Flip Database Views to Estimates db is successful,
Remediate Procs to stop writing to Old TTS schema

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*

-- Remove legacy table references or mirror that writes to old tables

Object                  Dependency - Old                  Comment
spSavePublicationsXml   TickerTableSecurities, Footnotes  Remove mirror
spDeletePublication     TickerTableSecurities, Footnotes  Remove legacy table references
spApplySplitActions     TickerTableSecurities			  Remove legacy table references
spRollbackSplitActions  TickerTableSecurities			  Remove legacy table references
spSaveCoverage          TickerTableSecurities			  Remove legacy table references
spSaveSecurity          TickerTableSecurities			  Remove legacy table references
spGetEligibleChanges    TickerTableSecurities             Remove legacy table references 
spRptTrefisTargetPrices AnalystSettings                   Remove legacy table references
spGetTickerTableXML     Footnotes                         Remove legacy table references

*/
GO


ALTER PROCEDURE [dbo].[spSavePublicationsXml]
  @PropertiesXml xml,
  @CompanyFinancialsXml xml,
  @TickerTableXml xml,
  @HighlightsXml xml,
  @EditorId int = 0
AS
BEGIN TRY
  BEGIN TRANSACTION

  DECLARE
  @Date         DATETIME,
  @Type         VARCHAR(30),
  @SubType      VARCHAR(30),
  @Title        VARCHAR(300),
  @PubNo        INT,
  @Version      INT,
  @hDoc         INT,
  @hDoc2        INT,
  @hDoc3        INT,
  @CurrentDate  DATETIME,
  @FileName     VARCHAR(63),
  @FileSize     BIGINT,
  @PageCount    INT,
  @Approver     VARCHAR(50),
  @ApprovedDate DATETIME,
  @AuditNo      INT

  SELECT @CurrentDate = getdate()

  EXEC sp_xml_preparedocument @hDoc OUTPUT, @PropertiesXml

    --Retrieve approver & approved date(UTC format) from document info node
  SELECT @Approver = U.ExchangeEmail, @ApprovedDate = ApprovedDate
  FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
  WITH (Approver  varchar(31)  '@approver',
        ApprovedDate datetime  '@approvedDate'
        ) X JOIN Users U on X.Approver = replace(replace(UserName, 'ac/',''),'ac\','')

  --convert approved date from UTC to EST(db server time zone)
  SET @ApprovedDate = dateadd(hh,datediff(hh,getutcdate(),getdate()),@ApprovedDate)

  --If no approver info, default to Cheryl
  IF (@Approver = '' or @Approver is null)
  BEGIN
    SELECT @Approver = ExchangeEmail, @ApprovedDate = @CurrentDate
    FROM Users
    WHERE
    replace(replace(UserName, 'ac/',''),'ac\','') = 'cdekre'
  END

  --Retrieve date,type,title from document info node
  SELECT @Date = X.Date, @Type = X.Type, @SubType = X.SubType, @Title = X.Title, @PubNo = X.PubNo, @Version = X.Version
  FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
  WITH (Date      datetime     '@pubDate',
        Type      varchar(31)  '@type',
        SubType   varchar(30)  '@subType',
        Title     varchar(255) '@title',
        PubNo     int          '@pubNo',
        Version   int          '@version'
        ) X

  SELECT @FileName = X.FileName, @FileSize =  X.FileSize, @PageCount = X.PageCount
  FROM OPENXML (@hDoc, 'DocumentInfo/Documents/Document', 1)
  WITH (DocType       varchar(4)  '@docType',
        FileName      varchar(30) '@fileName',
        FileSize      bigint      '@fileSize',
        PageCount     int         '@pageCount'
        ) X
  WHERE
    X.DocType = 'PDF'

  --Incase of resubmits delete the previous vesion
  IF @Version > 1
  BEGIN
    DELETE FROM TickerTableSecurities       WHERE PubNo = @PubNo
    DELETE FROM TickerTableSecuritiesOld    WHERE PubNo = @PubNo
    DELETE FROM Footnotes                   WHERE PubNo = @PubNo
    DELETE FROM FootnoteRefs                WHERE PubNo = @PubNo
    DELETE FROM TickerTables                WHERE PubNo = @PubNo
    DELETE FROM ProductGroupDocuments       WHERE PubNo = @PubNo
    DELETE FROM RelatedPublications         WHERE PubNo = @PubNo

    INSERT INTO AuditLog (Operation, EditorId, EditDate) VALUES ('R', @EditorId, @CurrentDate)
    SELECT @AuditNo = @@IDENTITY

    INSERT INTO PublicationsLog (AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate)
    SELECT @AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate FROM Publications WHERE PubNo = @PubNo

    INSERT INTO DocumentsLog (AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig)
    SELECT @AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig FROM Documents WHERE PubNo = @PubNo

    INSERT INTO PropertiesLog (AuditNo, PubNo, PropNo, PropId, PropValue)
    SELECT @AuditNo, PubNo, PropNo, PropId, PropValue FROM Properties WHERE PubNo = @PubNo

    --Delete if exists in PublicationFinancialNumbers (for resubmit)
    DELETE FROM PublicationFinancialNumbers WHERE PubNo = @PubNo
    DELETE FROM PublicationFinancials       WHERE PubNo = @PubNo
    DELETE FROM Properties                  WHERE PubNo = @PubNo
    DELETE FROM Documents                   WHERE PubNo = @PubNo
    DELETE FROM Publications                WHERE PubNo = @PubNo
  END

  --insert into Publications table
  INSERT INTO Publications (PubNo, Date, Type, SubType, Title, FileName, FileSize, Approver, ApprovedDate, PublishedDate, Version, Instructions, PageCount, EditorId, EditDate)
  SELECT @PubNo, @Date, @Type, @SubType, @Title, @FileName, @FileSize,@Approver, @ApprovedDate, @CurrentDate, @Version, 4, @PageCount, 0, @CurrentDate

  INSERT INTO Documents (PubNo, DocNo, DocType, FileName, FileNameOrig)
  SELECT @PubNo, X.DocNo, X.DocType, X.FileName, X.FileNameOrig
  FROM OPENXML (@hDoc, 'DocumentInfo/Documents/Document', 1)
  WITH (DocNo         int         '@docNo',
        DocType       varchar(4)  '@docType',
        FileName      varchar(30) '@fileName',
        FileNameOrig  varchar(63) '@fileNameOrig'
        ) X


  --insert into properties table with report meta data
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, Value, Name
  INTO #TmpPropertyCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Properties/Property', 1)
  WITH (value           varchar(200) '@value',
        name            varchar(30)  '@name'
        )
  WHERE Name <> ''

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Value
  FROM #TmpPropertyCollection T JOIN PropertyNames PN ON PN.PropName = T.Name

  --Retrieve Authors
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, AuthorId, Name
  INTO #TmpAuthorCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Authors/Author', 1)
  WITH (authorid        int         '@id',
        name            varchar(200) '@name'
        )

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Name
  FROM #TmpAuthorCollection T CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'Author'

  --Retrieve Industries
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, IndustryId, Name
  INTO #TmpIndustryCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Industries/Industry', 1)
  WITH (industryid      int         '@id',
        name            varchar(200) '@name'
        )

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Name
  FROM #TmpIndustryCollection T CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'Industry'

  --Retrieve tickers from Securities collection of document properties xml
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, X.SecurityId, X.Ticker, X.IndicateChange, X.TickerSheetId
  INTO #TmpTickerCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
  WITH (securityId      int         '@id',
        ticker          varchar(30) '@ticker',
        indicateChange  varchar(10) '@indicateChange',
        tickerSheetId   bigint      '@tickerSheetId'
        ) X --JOIN Securities2 S ON X.Ticker = S.Ticker
  --WHERE S.TickerType = 'STOCK'

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Ticker
  FROM #TmpTickerCollection T CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'Ticker'

  --Retrieve Investor Themes
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, ThemeId, Name
  INTO #TmpInvestorThemeCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/InvestorThemes/Theme', 1)
  WITH (ThemeId         int           '@id',
        Name            varchar(200)  '@name'
        )

  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, T.Name
  FROM #TmpInvestorThemeCollection T CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'InvestorTheme'

  --Retrieve Auto Blast Lists
  SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, BlastListId, Name
  INTO #TmpBlastListCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Blastlists/Blastlist', 1)
  WITH (BlastListId     varchar(100)  '@blastListId',
        Name            varchar(200)  '@name'
        )


  INSERT INTO Properties (PubNo, PropId, PropValue)
  SELECT @PubNo, PN.PropId, B.BlastListId
  FROM #TmpBlastListCollection B CROSS JOIN PropertyNames PN
  WHERE
    PropName = 'BlastList'

  --Temp table to store indicatechange='Yes' tickers (subset of securities collection)
  SELECT DisplayNo, SecurityId, Ticker, IndicateChange, TickerSheetId
  INTO #Tmp_ChangeTickers
  FROM #TmpTickerCollection
  WHERE IndicateChange = 'Yes'

  --First version of the report
  IF @Version = 1
  BEGIN
    --Promote drafts to live if change report (Rating/TP/Estimates)
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = @PubNo, Date = @CurrentDate
    FROM FinancialNumbers FN
    JOIN #Tmp_ChangeTickers T ON FN.SecurityId = T.SecurityId
    WHERE FN.IsDraft = 1

    --update PubNo in TickesheetData table for change tickers
    UPDATE TickerSheetData
    SET PubNo = @PubNo
    FROM TickerSheetData TS JOIN #Tmp_ChangeTickers T ON TS.SecurityId = T.SecurityId AND TS.TickerSheetId = T.TickerSheetId

    --Save document xml's into PublicationXml table
    INSERT INTO PublicationsXml(PubNo, PropertiesXml, CompanyFinancialsXml, TickerTableXml, HighlightsXml,EditorId,EditDate)
    SELECT @PubNo, @PropertiesXml, @CompanyFinancialsXml, @TickerTableXml, @HighlightsXml,@EditorId,@CurrentDate
  END
  ELSE
  --if Version > 1 (Resubmit)
  BEGIN

    DECLARE @DocPropertiesXml XML
    SELECT @DocPropertiesXml = PropertiesXml FROM PublicationsXml WHERE PubNo = @PubNo

    --If correction exists for this report
    IF (SELECT max(CorrectionMode) FROM CorrectionQueue WHERE PubNo = @PubNo AND Status in ('Required','Optional')) = 1
    BEGIN
      --Get the list of by pass tickers

      SELECT C.SecurityId, S.Ticker
      INTO #TmpBypassTickers
      FROM CorrectionQueue C JOIN Securities2 S ON C.SecurityId = S.SecurityID
      WHERE PubNo = @PubNo
      AND C.Status in ('Required','Optional') AND
      CorrectionMode = 1

      --For the correction tickers promote draft to live (corrected value)
      UPDATE FinancialNumbers
      SET IsDraft = 0, PubNo = @PubNo, Date = @CurrentDate
      FROM FinancialNumbers FN
      JOIN #TmpBypassTickers T ON FN.SecurityId = T.SecurityId
      WHERE FN.IsDraft = 1

      --Release marketdata override for correction tickers
      UPDATE CorrectionQueue
      SET CorrectionMode = 0,Completed = @CurrentDate,Status = 'Completed'
      WHERE Pubno = @PubNo
      AND SecurityId IN (SELECT SecurityId FROM #TmpBypassTickers)

      --Delete marketdata overrides of the corrected report
      DELETE FROM MarketData
      WHERE SecurityId IN (SELECT SecurityId FROM #TmpBypassTickers)
      AND Type = 'O'

      DECLARE @NextDependentPub INT
      --Check if current report is a source report
      IF (SELECT max(IsSource) FROM CorrectionQueue WHERE PubNo = @PubNo) = 1
      BEGIN
        SELECT @NextDependentPub = min(PubNo) FROM CorrectionQueue
        WHERE SourcePubNo = @PubNo
        AND PubNo > @PubNo
        AND Status = 'Optional'
      END
      ELSE
      BEGIN
        SELECT @NextDependentPub = min(PubNo) FROM CorrectionQueue
        WHERE SourcePubNo = (SELECT max(SourcePubNo) FROM CorrectionQueue WHERE Pubno = @PubNo)
        AND PubNo > @PubNo
        AND Status = 'Optional'
      END

      --Populate marketdata overrides for each of the correction tickers
      --Loop through all tickers in #TmpTickerCollection to see if they are bypassed
      --on the dependent report and perform RestoreMarketData in loop
        SELECT @DocPropertiesXml = PropertiesXml FROM PublicationsXml WHERE PubNo = @NextDependentPub

        DECLARE @hDependentPubNo int, @SecurityId int

        --EXEC sp_xml_preparedocument @hDependentPubNo OUTPUT, @BypassXml

        SELECT C.SecurityId, S.Ticker
        INTO #TmpDependentPubNoBypassTickers
        FROM CorrectionQueue C JOIN Securities2 S ON C.SecurityId = S.SecurityID WHERE PubNo = @NextDependentPub
        AND C.Status in ('Required','Optional')
        --AND CorrectionMode = 1

        SELECT TOP 1 @SecurityId = SecurityId FROM #TmpDependentPubNoBypassTickers ORDER BY SecurityId
        WHILE @@ROWCOUNT = 1
        BEGIN
          EXEC spRestoreMarketData @NextDependentPub, @SecurityId, @EditorId
          EXEC spRevaluate @SecurityId
          SELECT TOP 1 @SecurityId = SecurityId FROM #TmpDependentPubNoBypassTickers WHERE SecurityId > @SecurityId ORDER BY SecurityId
        END

      --EXEC sp_xml_removedocument @hDependentPubNo
    END

    --Get Tickers with IndicateChange = 'Yes' in this version and not in previous version
    EXEC sp_xml_preparedocument @hDoc2 OUTPUT, @DocPropertiesXml

    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, X.SecurityId, X.Ticker, X.IndicateChange
    INTO #TmpPreviusTickerList
    FROM OPENXML (@hDoc2, 'DocumentInfo/Securities/Security', 1)
    WITH (securityId     int         '@id',
          ticker         varchar(30) '@ticker',
          indicateChange varchar(10) '@indicateChange'
         ) X JOIN Securities2 S ON X.Ticker = S.Ticker
    WHERE S.TickerType = 'STOCK'
    AND X.IndicateChange = 'Yes'

    --update FinancialNumbers to promote draft for ticker additions where indicate change='Yes'
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = @PubNo, Date = @CurrentDate
    FROM FinancialNumbers FN
    JOIN #Tmp_ChangeTickers T ON FN.SecurityId = T.SecurityId
    WHERE FN.IsDraft = 1
    AND T.SecurityId NOT IN (SELECT SecurityId FROM #TmpPreviusTickerList)

    --update TickerSheetData table with PubNo for ticker additions where indicate change='Yes'
    UPDATE TickerSheetData
    SET PubNo = @PubNo
    FROM TickerSheetData TS JOIN #Tmp_ChangeTickers T ON TS.TickerSheetId = T.TickerSheetId AND TS.SecurityId = T.SecurityId
    WHERE T.SecurityId NOT IN (SELECT SecurityId FROM #TmpPreviusTickerList)

    --Update publications xml
    UPDATE PublicationsXml
    SET PropertiesXml = @PropertiesXml,
        TickerTableXml = @TickerTableXml,
        CompanyFinancialsXml = @CompanyFinancialsXml,
        HighlightsXml = @HighlightsXml,
        EditDate = @CurrentDate,
        EditorId = @EditorId
        --,BypassXml = null
    WHERE PubNo = @PubNo

  END

    --Call Revaluate for indicate change = 'Yes' tickers
    DECLARE @ChangeTickerCount int,@ChangeSecurityId int
    SELECT Top 1 @ChangeSecurityId = SecurityId FROM #Tmp_ChangeTickers ORDER BY SecurityId
    WHILE @@ROWCOUNT = 1
    BEGIN
      EXEC spRevaluate @ChangeSecurityId
      SELECT Top 1 @ChangeSecurityId = SecurityId FROM #Tmp_ChangeTickers WHERE SecurityId > @ChangeSecurityId ORDER BY SecurityId
    END

    --Insert into PublicationsFinancialNumbers
    INSERT INTO PublicationFinancialNumbers(PubNo, FinancialNumberId, CoverageId, EditorId, EditDate)
    SELECT @PubNo, FinancialNumberId, CoverageId, 1, @CurrentDate
    FROM vFinancialNumbersLatest
    WHERE SecurityId IN (SELECT SecurityId FROM #TmpTickerCollection)
    AND IsDraft = 0

    --Call sync stored procedure to keep TickerTableSecurities in sync with FinancialNumbers table.
    --This is a temporary call until all the teams are migrated to new reports
    IF @TickerTableXml.exist('/TickerTable') = 1
    BEGIN
      EXEC spMirrorTickerTableSecurities @PubNo, @TickerTableXml
    END

    --Populate PublicationActionTags flat structured table (denormalized)
    IF @TickerTableXml.exist('/TickerTable') = 1
    BEGIN
      --print 'test'
      EXEC spSavePublicationFinancials @PubNo, @TickerTableXml, @EditorId
    END
    
    --Call to populate rows into ProductGroupDocuments table
    EXEC spInsProductGroupDocsByPubNo @PubNo,@Date ,@Type

    --Call to populate rows into distribution queue
    EXEC spAddDistributionItem @PubNo, 0, 'C'

    --Call to populate row into analyst blast queue
    EXEC spAddBlastItem @PubNo

    EXEC sp_xml_removedocument @hDoc

    COMMIT
END TRY
BEGIN CATCH
  IF @@TRANCOUNT > 0
     ROLLBACK

  -- Raise an error with the details of the exception
  DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
  SELECT @ErrMsg = ERROR_MESSAGE(),
         @ErrSeverity = ERROR_SEVERITY()

  RAISERROR(@ErrMsg, @ErrSeverity, 1)
END CATCH

GO

ALTER procedure [dbo].[spDeletePublication]
  @PubNo         int,
  @Operation     char(1),
  @EditorId      int,
  @Numdeleted    int OUTPUT
AS
declare @AuditNo int

-- PREVENT PHANTOM deleteS (from STALE BROWSER) BY ONLY PROCESSING FIRST delete REQUEST
if NOT EXISTS(select * from Publications where PubNo = @PubNo)
  begin
    select @Numdeleted = 0 -- return OUTPUT PARAMETERS
    return
  end

-- return ROWset
select FileName from Documents where PubNo = @PubNo

delete from TickerTableSecurities       where PubNo = @PubNo
delete from TickerTableSecuritiesOld    where PubNo = @PubNo
delete from Footnotes                   where PubNo = @PubNo
delete from FootnoteRefs                where PubNo = @PubNo
delete from TickerTables                where PubNo = @PubNo
delete from ProductGroupDocuments       where PubNo = @PubNo
delete from RelatedPublications         where PubNo = @PubNo
if @Operation = 'D' --delete from FinancialNumbers only if "delete" invoked from research dashboard and not report resubmits
begin
  delete from PublicationFinancialNumbers where PubNo = @PubNo
  delete from PublicationFinancials       where PubNo = @PubNo
  delete from FinancialNumbers            where PubNo = @PubNo
  --update model status to deleted if this publication promoted any models to live
  if EXISTS(select * from Models where PubNo = @PubNo)
  begin
  update Models set Status = 'Deleted' where PubNo = @PubNo AND Status = 'Active'
  end
end

-- RVdeletedDocuments replicated view uses the logs below for pdf cache control on BR.com
insert into AuditLog (Operation, EditorId, EditDate) VALUES (@Operation, @EditorId, GETDATE())
select @AuditNo = @@IDENTITY

insert into PublicationsLog (AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate)
select @AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate from Publications where PubNo = @PubNo

insert into DocumentsLog (AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig)
select @AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig from Documents where PubNo = @PubNo

insert into PropertiesLog (AuditNo, PubNo, PropNo, PropId, PropValue)
select @AuditNo, PubNo, PropNo, PropId, PropValue from Properties where PubNo = @PubNo

delete from Properties   where PubNo = @PubNo
delete from Documents    where PubNo = @PubNo
delete from Publications where PubNo = @PubNo

select @Numdeleted = @@ROWCOUNT -- return OUTPUT PARAMETERS

GO


ALTER PROC [dbo].[spApplySplitActions] @SecurityId int = 0
AS
 -- ====================================================================================
 -- Author: Krishna Josyula
 -- Create date: 03/26/2008
 -- Description: Updates TargetPrice in TickerTableSecurities & TickerTablesecuritiesold
 --    Tables based on the split adjustment factor.
 -- Revised: 06/12/2013
 -- Apply splits only when the effective date of the split less than or equal to current date.
 -- Revised: 05/05/2017
 -- Apply splits to update EPS Reported and EPS Adjusted in FinancialNumbers & Publication Financials table
 -- ====================================================================================

BEGIN
DECLARE @AdjustmentFactor decimal(10,6)
DECLARE @EffectiveDate datetime
DECLARE @SplitActionId int
DECLARE @Ticker varchar(10)
DECLARE @FinancialNumberTypeId INT

SET NOCOUNT ON
IF @SecurityId = 0
  SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId
ELSE
  SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE SecurityId = @SecurityId and AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId

WHILE (@@rowcount > 0)
BEGIN

  --STEP 1:  Save pre-split values

  --Update TargetPriceOrig to original value in TickerTableSecurities, TickerTableSecuritiesOld
  --This is only done once for every qualified record

  Update TickerTableSecurities
  Set TargetPriceOrig = TargetPrice
  Where
   TargetPriceOrig is null and
   CloseDate <= @EffectiveDate and
   Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  Update TickerTableSecuritiesOld
  Set TargetPriceOrig = TTSO.TargetPrice
  From
   TickerTableSecurities TTS JOIN TickerTableSecuritiesOld TTSO ON TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
  Where
   TTSO.TargetPrice is not null and
   TTSO.TargetPrice <> '' and
   TTSO.TargetPriceOrig is null and
   TTS.CloseDate <= @EffectiveDate and
   TTSO.Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  --Update TargetPrice, EPS Reported and EPS Adusted to original value in FinancialNumbers
  --This is only done once for every qualified record

  update FinancialNumbers
  set ValueOrig = Value
  where SecurityId = @SecurityId
    and FinancialNumberTypeId in (select FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType in ('TARGETPRICE','EPSRPT','EPSADJ'))
    and IsDraft = 0
    and ValueOrig is null
    and Date <= @EffectiveDate
    and Date >= '2003-03-20'

  --STEP 2:  Apply split factor

  --Update TargetPrice & EPS columns with the adjustment factor for all the records in TickerTableSecurities, TickerTableSecuritiesOld, FinancialNumbers & PublicationFinancials
  --prior to the split date
  Update TickerTableSecurities
  Set TargetPrice  = case when isnumeric(TargetPrice) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TargetPrice) / @adjustmentfactor))) else TargetPrice end,
      EPSLastYear = case when isnumeric(EPSLastYear) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EPSLastYear) / @adjustmentfactor))) else EPSLastYear end,
      EPSThisYear = case when isnumeric(EPSThisYear) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EPSThisYear) / @adjustmentfactor))) else EPSThisYear end,
      EPSNextYear = case when isnumeric(EPSNextYear) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EPSNextYear) / @adjustmentfactor))) else EPSNextYear end
  Where
   CloseDate <= @EffectiveDate and
   Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  Update TickerTableSecuritiesOld
  Set TargetPrice  = case when isnumeric(TTSO.TargetPrice) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TTSO.TargetPrice) / @adjustmentfactor))) else TTSO.TargetPrice end,
      EPSThisYear = case when isnumeric(TTSO.EPSThisYear) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TTSO.EPSThisYear) / @adjustmentfactor)))  else TTSO.EPSThisYear end,
      EPSNextYear = case when isnumeric(TTSO.EPSNextYear) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TTSO.EPSNextYear) / @adjustmentfactor)))  else TTSO.EPSNextYear end
  From
   TickerTableSecurities TTS JOIN TickerTableSecuritiesOld TTSO ON TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
  Where
   TTSO.TargetPrice is not null and
   TTSO.TargetPrice <> '' and
   TTS.CloseDate <= @EffectiveDate and
   TTSO.Ticker = @Ticker and
   CloseDate >= '2003-03-20'

  update FinancialNumbers
  set Value = case when isnumeric(Value) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),Value) / @adjustmentfactor))) else Value end,
      UnitValue = case when isnumeric(UnitValue) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),UnitValue) / @adjustmentfactor))) else UnitValue end
  where SecurityId = @SecurityId
  and FinancialNumberTypeId in (select FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType in ('TARGETPRICE','EPSRPT','EPSADJ'))
  and IsDraft = 0
  and Date <= @EffectiveDate
  and Date >= '2003-03-20'

  update PublicationFinancials
  set TargetPrice = case when isnumeric(TargetPrice) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),TargetPrice) / @adjustmentfactor))) else TargetPrice end,
      EpsFY0 = case when isnumeric(EPSFY0) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EpsFY0) / @adjustmentfactor))) else EpsFY0 end,
      EpsFY1 = case when isnumeric(EPSFY1) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EpsFY1) / @adjustmentfactor))) else EPSFY1 end,
      EpsFY2 = case when isnumeric(EPSFY2) = 1 then convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),EpsFY2) / @adjustmentfactor))) else EpsFY2 end
  where SecurityId = @SecurityId
  and CloseDate <= @EffectiveDate
  and CloseDate >= '2003-03-20'

  --STEP 3:  Mark split as applied

  --Update Status to 'Applied'
  update SplitActions
  set AppliedStatus = 'Y', AppliedDate = getdate()
  where SplitActionId = @SplitActionId

  IF @SecurityId = 0
    SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE SplitActionId > @SplitActionId AND AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId
  ELSE
    SELECT TOP 1 @SplitActionId = SplitActionId, @Ticker = Ticker, @EffectiveDate = EffectiveDate, @AdjustmentFactor = AdjustmentFactor FROM SplitActions WHERE SecurityId = @SecurityId AND SplitActionId > @SplitActionId and AppliedStatus = 'N' AND EffectiveDate <= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) ORDER BY SecurityId, EffectiveDate, SplitActionId

END
END

GO

ALTER PROC [dbo].[spRollbackSplitActions]  @Ticker varchar(10)
AS
  -- =======================================================================
  -- Author:  Krishna Josyula
  -- Create date:  03/26/2008
  -- Description:  Rolls TargetPrice column values back from TargetPriceOrig Column
  -- =======================================================================
BEGIN

  SET NOCOUNT ON
  DECLARE @SecurityId INT
  DECLARE @FinancialNumberTypeId INT

 SELECT SecurityId FROM Securities2 Where Ticker = @Ticker
 SELECT @FinancialNumberTypeId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'TARGETPRICE'

  UPDATE TickerTableSecurities
  SET TargetPrice = TargetPriceOrig
  WHERE
    Ticker = @Ticker and
    TargetPriceOrig is not null

  UPDATE FinancialNumbers
  SET Value  = ValueOrig,
      UnitValue  = ValueOrig
  WHERE SecurityId = @SecurityId
    and FinancialNumberTypeId = @FinancialNumberTypeId
    and IsDraft = 0
    and ValueOrig is not null

   UPDATE TickerTableSecuritiesOld
  SET TargetPrice = TargetPriceOrig
  WHERE
    Ticker = @Ticker and
    TargetPriceOrig is not null

  --UPDATE PublicationFinancials
  --SET TargetPrice = TargetPriceOrig
  --WHERE
  --  Ticker = @Ticker and
  --  TargetPriceOrig is not null

  UPDATE TickerTableSecurities
  SET TargetPriceOrig = null
  WHERE
    Ticker = @Ticker

  UPDATE FinancialNumbers
  SET ValueOrig = null
  WHERE SecurityId = @SecurityId
    and FinancialNumberTypeId = @FinancialNumberTypeId
    and IsDraft = 0
    and ValueOrig is not null


  UPDATE TickerTableSecuritiesOld
  SET TargetPriceOrig = null
  WHERE
    Ticker = @Ticker

  --UPDATE PublicationFinancials
  --SET TargetPriceOrig = null
  --WHERE
  --  Ticker = @Ticker and
  --  TargetPriceOrig is not null

  UPDATE SplitActions
  SET AppliedStatus = 'N', AppliedDate = null
  WHERE
    Ticker = @Ticker
END


GO

ALTER PROCEDURE [dbo].[spSaveCoverage]
  @CoverageId    int OUTPUT,
  @IndustryId    int,
  @AnalystId     int,
  @SecurityId    int,
  @LaunchDate    datetime,
  @LaunchInd     char(1),
  @DropDate      datetime,
  @DropInd       char(1),
  @EditorId      int
AS
DECLARE @EditDate datetime
DECLARE @CoverageAction varchar(10)
DECLARE @RatingAction varchar(10)
DECLARE @PubNo int
DECLARE @EstimatePeriodId int
DECLARE @MsgOld varchar(100)
DECLARE @MsgNew varchar(100)
DECLARE @CompanyId int

SELECT @EditDate = GETDATE()
BEGIN TRANSACTION
BEGIN TRY
--Before insert/update row in ResearchCoverage table
--perform the two checks below

--Company should only be covered by one active analyst
SELECT @CompanyId = CompanyId FROM Securities2 WHERE SecurityId = @SecurityId
IF (SELECT DISTINCT RC.AnalystId FROM ResearchCoverage RC JOIN Securities2 S ON RC.SecurityId = S.SecurityId
WHERE CompanyId = @CompanyId AND  LaunchDate IS NOT NULL AND DropDate IS NULL) <> @AnalystId
BEGIN
  ROLLBACK TRANSACTION
  RETURN -1
END

--Security should only be covered by one active analyst
IF (SELECT COUNT(*) FROM ResearchCoverage
WHERE SecurityId = @SecurityId AND AnalystId <> @AnalystId AND  LaunchDate IS NOT NULL AND DropDate IS NULL) > 0
BEGIN
  ROLLBACK TRANSACTION
  RETURN -2
END

IF @DropInd = '' SELECT @DropInd = null
IF EXISTS (SELECT CoverageId FROM ResearchCoverage WHERE CoverageId = @CoverageId)
  -- EXISTING COVERAGE
  BEGIN
    SELECT @MsgOld = I.IndustryName + ' | ' + A.Last + ' | ' + ISNULL(S.Ticker, '-')
    FROM ResearchCoverage RC
    JOIN Industries I ON I.IndustryId = RC.IndustryId
    JOIN Authors A ON A.AuthorId = RC.AnalystId
    LEFT JOIN Securities2 S ON S.SecurityId = RC.SecurityId
    WHERE RC.CoverageId = @CoverageId

    UPDATE ResearchCoverage SET
      IndustryId = @IndustryId,
      AnalystId  = @AnalystId,
      SecurityId = @SecurityId,
      LaunchDate = @LaunchDate,
      LaunchInd  = @LaunchInd,
      DropDate   = @DropDate,
      DropInd    = @DropInd,
      EditorId   = @EditorId,
      EditDate   = @EditDate
    WHERE CoverageId = @CoverageId

    SELECT @MsgNew = I.IndustryName + ' | ' + A.Last + ' | ' + ISNULL(S.Ticker, '-')
    FROM ResearchCoverage RC
    JOIN Industries I ON I.IndustryId = RC.IndustryId
    JOIN Authors A ON A.AuthorId = RC.AnalystId
    LEFT JOIN Securities2 S ON S.SecurityId = RC.SecurityId
    WHERE RC.CoverageId = @CoverageId

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Coverage', 'U', @MsgNew, @MsgOld, @CoverageId, @EditorId, @EditDate)

    -- Drop Date validation
    -- A Call report must exist for the specified coverage drop date (when previously launched):
    --  * When strategy coverage, i.e. no security, a Call must exist for analyst & industry & drop date combination
    --  * When company coverage, i.e. security, a Call must exist for analyst & security & drop date combination
    -- Optimally, the drop date of a Discontinuing Coverage Call should be specified
    -- (otherwise the date of the last published Call should be specified).
    IF ((@LaunchDate is not null) OR (@LaunchDate <> '')) AND ((@DropDate is not null) OR (@DropDate <> ''))
    BEGIN
      -- Update Industry, Analyst and Security tables to reflect active coverage status (iPad)
      UPDATE Securities2 SET Status = 0,EditDate = getdate() WHERE SecurityId = @SecurityId
      IF NOT EXISTS(SELECT * FROM ResearchCoverage WHERE IndustryId = @IndustryId AND LaunchDate IS NOT NULL AND DropDate IS NULL)
      BEGIN
        UPDATE Industries SET Status = 0,EditDate = getdate() WHERE IndustryId = @IndustryId
      END
      IF NOT EXISTS(SELECT * FROM ResearchCoverage WHERE AnalystId = @AnalystId AND LaunchDate IS NOT NULL AND DropDate IS NULL)
      BEGIN
        UPDATE Authors SET Status = 0,EditDate = getdate() WHERE AuthorId = @AnalystId
      END
      -- Strategy coverage: Get PubNo for specified Call & analyst & industry & drop date combination
      IF ((@SecurityId is null) OR (@SecurityId < 1))
      BEGIN
        SELECT @PubNo = max(P.PubNo)
        FROM Publications P
        JOIN Properties Pr ON P.PubNo = Pr.PubNo AND Pr.PropId = 5
        JOIN Authors A ON Pr.PropValue = A.Name
        JOIN Properties Pr2 ON P.Pubno = Pr2.PubNo AND Pr2.PropId = 11
        JOIN Industries I ON Pr2.PropValue = I.IndustryName
        WHERE
          P.Type = 'Research Call' AND
          A.AuthorId = @AnalystId AND
          I.IndustryId = @IndustryId AND
          P.Date = @DropDate
      END
      -- Company coverage: Get PubNo for specified Call & analyst & security & drop date combination
      ELSE
      BEGIN
        SELECT @PubNo = max(P.PubNo )
        FROM Publications P
        JOIN Properties Pr ON P.PubNo = Pr.PubNo AND Pr.PropId = 5
        JOIN Authors A ON Pr.PropValue = A.Name
        JOIN Properties Pr2 ON P.Pubno = Pr2.PubNo AND Pr2.PropId = 13
        JOIN Securities2 S ON Pr2.PropValue = S.Ticker
        WHERE
          P.Type = 'Research Call' AND
          A.AuthorId = @AnalystId AND
          S.SecurityId = @SecurityId AND
          P.Date = @DropDate
      END

      --If Call does not exist for drop date then rollback
      IF (@PubNo is null)
      BEGIN
          ROLLBACK TRANSACTION
          RETURN -1
      END

      --If Call exists for drop date
      --  * Set the Coverage Action to Drop or Suspend
      --  * Set the Rating Action to Drop
      IF ((@SecurityId is not null) AND (@SecurityId > 1))
      BEGIN
        IF @DropInd = 'S'
          SELECT @CoverageAction = 'Suspend', @RatingAction = 'Drop'
        ELSE
          SELECT @CoverageAction = 'Drop', @RatingAction = 'Drop'

        UPDATE TickerTableSecurities
        SET CoverageAction = @CoverageAction, RatingAction = @RatingAction
        WHERE
          PubNo = @PubNo AND
          Ticker = (SELECT Ticker FROM Securities2 WHERE SecurityId = @SecurityId)

        UPDATE PublicationFinancials
        SET CoverageAction = @CoverageAction, RatingAction = @RatingAction
        WHERE
          PubNo = @PubNo AND
          Ticker = (SELECT Ticker FROM Securities2 WHERE SecurityId = @SecurityId)
      END
    END
  END
ELSE
  -- NEW COVERAGE
  BEGIN
    INSERT INTO ResearchCoverage (IndustryId, AnalystId, SecurityId, LaunchDate, LaunchInd, DropDate, DropInd, EditorId, EditDate)
    VALUES (@IndustryId, @AnalystId, @SecurityId, @LaunchDate, @LaunchInd, @DropDate, @DropInd, @EditorId, @EditDate)
    SELECT @CoverageId = @@IDENTITY

    SELECT @MsgNew = I.IndustryName + ' | ' + A.Last + ' | ' + ISNULL(S.Ticker, '-')
    FROM ResearchCoverage RC
    JOIN Industries I ON I.IndustryId = RC.IndustryId
    JOIN Authors A ON A.AuthorId = RC.AnalystId
    LEFT JOIN Securities2 S ON S.SecurityId = RC.SecurityId
    WHERE RC.CoverageId = @CoverageId

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Coverage', 'A', @MsgNew, null, @CoverageId, @EditorId, @EditDate)

    -- When new coverage is added:
    -- 1) Initialize FinancialCompanySettings (TickerTableEps, TickerTableValuation, BaseYear & BaseQuarter)
    -- 2) Initialize FinancialSecuritySettings (Model Currency, Model Units)
    -- 3) Exclude EPS Alternate from estimate set
    DECLARE @BaseYear char(4), @BaseQuarter char(2), @TickerTableEpsId int, @TickerTableValuationId int, @UnitMultiplier bigint,@EPSAltId int

    SELECT @BaseYear = convert(varchar,datepart(yy,@EditDate) - 1), @BaseQuarter = 'Q1', @UnitMultiPlier = 1000000
    SELECT @TickerTableEpsId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'EPSRPT'
    SELECT @TickerTableValuationId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'P/EPSRPT'
    SELECT @EPSAltId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'EPS_ALT'

    --While adding a secondary ticker to coverage do not insert row into FinancialCompanySettings table (as parent ticker setup added the required row)
    IF NOT EXISTS(SELECT * FROM FinancialCompanySettings FCS JOIN Securities2 S ON FCS.CompanyId = S.CompanyId WHERE S.SecurityId = @SecurityId)
    BEGIN
      INSERT INTO dbo.FinancialCompanySettings(CompanyId,TickerTableEpsId,TickerTableValuationId,BaseYear,BaseQuarter,EditorId,EditDate)
      SELECT S.CompanyId,@TickerTableEpsId,@TickerTableValuationId,@BaseYear,@BaseQuarter,@EditorId,@EditDate
      FROM Securities2 S
      WHERE S.SecurityId = @SecurityId
    END

    IF NOT EXISTS(SELECT * FROM FinancialSecuritySettings WHERE SecurityId = @SecurityId)
    BEGIN
      INSERT INTO dbo.FinancialSecuritySettings(SecurityId,CurCode,UnitMultiplier,EditorId,EditDate)
      SELECT @SecurityId,CurrencyCode,@UnitMultiPlier,@EditorId,@EditDate
      FROM Securities2 S
      WHERE S.SecurityId = @SecurityId
    END

    --While adding a secondary ticker to coverage do not insert eps_alt exclusion row into FinancialSetExclusions table (as parent ticker setup added the required row)
    IF NOT EXISTS(SELECT * FROM FinancialSetExclusions FCS JOIN Securities2 S ON FCS.CompanyId = S.CompanyId WHERE S.SecurityId = @SecurityId AND FinancialNumberTypeId = @EPSAltId)
    BEGIN
      INSERT INTO dbo.FinancialSetExclusions(CompanyId,FinancialNumberTypeId,EditorId,EditDate)
      SELECT S.CompanyId,@EPSAltId,@EditorId,@EditDate
      FROM Securities2 S
      WHERE S.SecurityId = @SecurityId
    END
  END
END TRY
BEGIN CATCH
  IF @@TRANCOUNT > 0
  ROLLBACK TRANSACTION
END CATCH
  IF @@TRANCOUNT > 0
  COMMIT TRANSACTION
RETURN 0


GO

ALTER PROCEDURE [dbo].[spSaveSecurity]
  @SecurityId     int OUTPUT,
  @TickerType     varchar(10),
  @Company        varchar(63),
  @BLOOMBERG      varchar(10),
  @RIC            varchar(10),
  @CUSIP          varchar(10),
  @SEDOL          varchar(10),
  @CINS           varchar(10),
  @ISIN           varchar(12),
  @VALOREN        varchar(20),
  @ExchangeCode   varchar(10),
  @CurrencyCode   char(3),
  @BenchmarkIndex varchar(10),
  @CountryCode    char(2),
  @RegionId       int,
  @Active         smallint,
  @EditorId       int,
  @GICS_ID        int,
  @Alias          varchar(50),
  @CompanyId      int
AS

BEGIN TRANSACTION

DECLARE
  @Ticker    varchar(10),
  @EditDate  datetime,
  @IsPrimary char(1),
  @OrdNo     int

SELECT
  @Ticker   = ltrim(rtrim(@BLOOMBERG)),
  @EditDate = GETDATE(),
  @Company = ltrim(rtrim(@Company)),
  @BLOOMBERG = ltrim(rtrim(@BLOOMBERG))

-- Automate the following security attributes based on supplied Exchange Code

SELECT
  @CurrencyCode   = CurrencyCode,
  @BenchmarkIndex = BenchmarkIndex,
  @CountryCode    = CountryCode,
  @RegionId       = RegionId
FROM Exchanges WHERE ExchangeCode = @ExchangeCode

-- UPDATE existing security
IF EXISTS (SELECT SecurityId FROM Securities2 WHERE SecurityId = @SecurityId)
  BEGIN
    DECLARE @TickerOld varchar(10), @CompanyOld varchar(63), @CompanyIdOld int
    SELECT @TickerOld = Ticker, @CompanyOld = Company, @CompanyIdOld = CompanyId, @IsPrimary = IsPrimary, @OrdNo = OrdNo
    FROM Securities2 WHERE SecurityId = @SecurityId

    -- Realign existing security with NEW Company

    IF @CompanyId = -1
      BEGIN
        INSERT INTO Companies(Company) SELECT @Company
        SELECT @CompanyId = @@IDENTITY, @IsPrimary = 'Y', @OrdNo = 1

        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('Companies', 'A', @Company, NULL, @CompanyId, @EditorId, @EditDate)
      END

    -- Realign existing security with EXISTING Company

    ELSE
      BEGIN
        IF @CompanyId <> @CompanyIdOld
        BEGIN
          SELECT @Company = ltrim(rtrim(Company)) from Companies WHERE CompanyId = @CompanyId
          IF EXISTS (SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
            SELECT @IsPrimary = 'N', @OrdNo = MAX(OrdNo) + 1 FROM Securities2 WHERE CompanyId = @CompanyId
          ELSE
            SELECT @IsPrimary = 'Y', @OrdNo = 1
        END
      END

    IF @Ticker <> @TickerOld
    BEGIN
      -- Propagate ticker change
      UPDATE Properties    SET PropValue = @Ticker WHERE PropId = 13 AND PropValue = @TickerOld
      UPDATE PropertiesLog SET PropValue = @Ticker WHERE PropId = 13 AND PropValue = @TickerOld
      UPDATE TickerTableSecurities    SET Ticker = @Ticker WHERE Ticker = @TickerOld
      UPDATE TickerTableSecuritiesOld SET Ticker = @Ticker WHERE Ticker = @TickerOld
      UPDATE PublicationFinancials SET Ticker = @Ticker WHERE Ticker = @TickerOld
    END

    IF (@CompanyIdOld = @CompanyId) AND (@CompanyOld <> @Company)
    BEGIN
      -- Propagate company change
      UPDATE Companies           SET Company = @Company WHERE Company = @CompanyOld
      UPDATE Securities2         SET Company = @Company WHERE Company = @CompanyOld
      UPDATE ValuationsCompanies SET Company = @Company WHERE Company = @CompanyOld
      UPDATE RisksCompanies      SET Company = @Company WHERE Company = @CompanyOld
    END

    UPDATE Securities2 SET
      TickerType     = @TickerType,
      Company        = @Company,
      Ticker         = @BLOOMBERG,
      RIC            = @RIC,
      CUSIP          = @CUSIP,
      SEDOL          = @SEDOL,
      CINS           = @CINS,
      ISIN           = @ISIN,
      VALOREN        = @VALOREN,
      ExchangeCode   = @ExchangeCode,
      CurrencyCode   = @CurrencyCode,
      BenchmarkIndex = @BenchmarkIndex,
      CountryCode    = @CountryCode,
      RegionId       = @RegionId,
      IsActive       = @Active,
      EditorId       = @EditorId,
      EditDate       = @EditDate,
      GICS_ID        = @GICS_ID,
      Alias          = @Alias,
      CompanyId      = @CompanyId,
      IsPrimary      = @IsPrimary,
      OrdNo          = @OrdNo
    WHERE SecurityId = @SecurityId

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Securities', 'U', @Ticker + ' | ' + @Company, @TickerOld + ' | ' + @CompanyOld, @SecurityId, @EditorId, @EditDate)

  END

-- ADD new security

ELSE
  BEGIN
    -- Align new security with NEW Company

    IF @CompanyId = -1
      BEGIN
        INSERT INTO Companies(Company) SELECT @Company
        SELECT @CompanyId = @@IDENTITY, @IsPrimary = 'Y', @OrdNo = 1

        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('Companies', 'A', @Company, NULL, @CompanyId, @EditorId, @EditDate)
      END

    -- Align new security with EXISTING Company
    ELSE
      BEGIN
        SELECT @Company = ltrim(rtrim(Company)) from Companies WHERE CompanyId = @CompanyId
        IF EXISTS (SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
          SELECT @IsPrimary = 'N', @OrdNo = max(OrdNo) + 1 FROM Securities2 WHERE CompanyId = @CompanyId
        ELSE
          SELECT @IsPrimary = 'Y', @OrdNo = 1
      END

    INSERT INTO Securities2
      (TickerType, Company, Ticker, RIC, CUSIP, SEDOL, CINS, ISIN, VALOREN, ExchangeCode, CurrencyCode, BenchmarkIndex, CountryCode, RegionId, IsActive, EditorId, EditDate, GICS_ID, Alias, CompanyId, IsPrimary, OrdNo)
    VALUES
      (@TickerType, @Company, @BLOOMBERG, @RIC, @CUSIP, @SEDOL, @CINS, @ISIN, @VALOREN, @ExchangeCode, @CurrencyCode, @BenchmarkIndex, @CountryCode, @RegionId, @Active, @EditorId, @EditDate, @GICS_ID, @Alias, @CompanyId, @IsPrimary, @OrdNo)

    SELECT @SecurityId = @@IDENTITY
    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Securities', 'A', @Ticker + ' | ' + @Company, NULL, @SecurityId, @EditorId, @EditDate)

  END

COMMIT TRANSACTION

RETURN 0



GO

ALTER PROCEDURE [dbo].[spGetEligibleChanges]
  @inXml xml
AS
BEGIN

DECLARE
  @Date        DATETIME,
  @Type        VARCHAR(30),
  @Title       VARCHAR(300),
  @PubNo       INT,
  @Version     INT,
  @hDoc        INT,
  @DocumentXml XML,
  @hDoc2       INT

EXEC sp_xml_preparedocument @hDoc OUTPUT, @inXml

SELECT @Date = X.Date, @Type = X.Type, @Title = X.Title
FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
WITH (Date   datetime     '@pubDate',
      Type   varchar(31)  '@type',
      Title  varchar(255) '@title'
     ) X

--Check for resubmit and retrieve pubno & version
exec spCheckForResubmits @Date, @Type, @Title, @PubNo output, @Version output

--Retrieve prior version indicate change in case of resubmit
select @DocumentXml = PropertiesXml from PublicationsXml where PubNo = @PubNo
exec sp_xml_preparedocument @hDoc2 output, @DocumentXml

select X.SecurityId, X.IndicateChange
into #TmpPriorVersionTickerList
from openxml (@hDoc2, 'DocumentInfo/Securities/Security', 1)
with (SecurityId      int         '@id',
      Ticker          varchar(30) '@ticker',
      IndicateChange  varchar(10) '@indicateChange'
     ) X

exec sp_xml_removedocument @hDoc2

--Retrieve tickers from Securities collection of input xml and calculate option buttons (No,Yes,Last) settings for each ticker
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo, X.SecurityId, X.Ticker, X.Analyst, X.IndicateChange, dbo.fnGetTickerSettings(X.SecurityId, X.CoverageId, X.IndicateChange, T.IndicateChange, @Type, @PubNo) AS Settings
INTO #TickerList
FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
WITH (securityId      int          '@id',
      coverageid      int          '@coverageId',
      ticker          varchar(30)  '@ticker',
      analyst         varchar(100) '@analyst',
      indicateChange  varchar(10)  '@indicateChange'
     ) X LEFT OUTER JOIN #TmpPriorVersionTickerList T ON X.SecurityId = T.SecurityId


--Populate CoverageAction for each of the tickers in the report
--This is required to display action line on the report for ex: Initiating Coverage/Resuming Coverage etc.,
SELECT SecurityId, Ticker, CoverageAction
INTO #TmpCoverageAction
FROM PublicationFinancials
WHERE 1 = 2

IF @PubNo <> 0
BEGIN
  INSERT INTO #TmpCoverageAction
  SELECT T.SecurityId, T.Ticker, PF.CoverageAction
  FROM #TickerList T join TickerTableSecurities PF ON T.Ticker = PF.Ticker
  WHERE PubNo = @PubNo
END
ELSE
BEGIN
  INSERT INTO #TmpCoverageAction
  SELECT T.SecurityId, T.Ticker, case when LaunchDate is null and LaunchInd = 'I' then 'Initiate' when LaunchDate is null and LaunchInd = 'R' then 'Resume' else '' end CoverageAction
  FROM #TickerList T JOIN ResearchCoverage RC ON T.SecurityId = RC.SecurityId
  WHERE DropDate is null
END

--Generate output securities collection xml from the calculated values
SELECT
  1                          AS tag,
  null                       AS parent,
  null                       AS [Securities!1!!element],
  null                       AS [Security!2!displaynum!hide],
  null                       AS [Security!2!id],
  null                       AS [Security!2!ticker],
  null                       AS [Security!2!analyst],
  null                       AS [Security!2!indicateChange],
  null                       AS [Security!2!optNoEnabled],
  null                       AS [Security!2!optYesEnabled],
  null                       AS [Security!2!optLastEnabled],
  null                       AS [Security!2!optYesFlags],
  null                       AS [Security!2!optLastFlags],
  null                       AS [Security!2!optLastPubNo],
  null                       AS [Security!2!coverageAction]

UNION ALL

SELECT
  2                          AS tag,
  1                          AS parent,
  null                       AS [Securities!1!!element],
  DisplayNo                  AS [Security!2!displaynum!hide],
  T.SecurityId               AS [Security!2!id],
  T.Ticker                   AS [Security!2!ticker],
  Analyst                    AS [Security!2!analyst],
  CASE SUBSTRING(Settings,1,1)
    WHEN 1 THEN 'no'
    WHEN 2 THEN 'yes'
    WHEN 3 THEN 'last'
  END                        AS [Security!2!indicateChange],
  SUBSTRING(Settings,3,1)    AS [Security!2!optNoEnabled],
  SUBSTRING(Settings,5,1)    AS [Security!2!optYesEnabled],
  SUBSTRING(Settings,7,1)    AS [Security!2!optLastEnabled],
  SUBSTRING(Settings,dbo.fnCharIndex('|',Settings,4) + 1,dbo.fnCharIndex('|',Settings,5) - dbo.fnCharIndex('|',Settings,4)-1) AS [Security!2!optYesFlags],
  SUBSTRING(Settings,dbo.fnCharIndex('|',Settings,5) + 1,dbo.fnCharIndex('|',Settings,6) - dbo.fnCharIndex('|',Settings,5)-1) AS [Security!2!optLastFlags],
  SUBSTRING(Settings,dbo.fnCharIndex('|',Settings,6) + 1,len(Settings) - dbo.fnCharIndex('|',Settings,6)) AS [Security!2!optLastPubNo],
  TC.CoverageAction
FROM #TickerList T JOIN #TmpCoverageAction TC ON T.SecurityId = TC.SecurityId

ORDER BY Tag,[Security!2!displaynum!hide]
FOR XML Explicit

EXEC sp_xml_removedocument @hDoc

END

GO

ALTER procedure [dbo].[spRptTrefisTargetPrices]
as

-- Trefis daily feed
begin

  set nocount on
  --Temp table to hold tickers(for active trefis models) along with their target price & date when it's established
  select VF.Ticker,VF.TargetPrice,convert(varchar,P.Date,101) Date
  into #TmpTickerTargetPrice
  from vFinancials VF
  join Publications P on VF.PubNo = P.PubNo
  join
    (select S.Ticker, max(VF1.PubNo) MaxPubNo
    from TrefisModels TM
    join Securities2 S on S.SecurityId = TM.SecurityId
    join vFinancials VF1 on VF1.Ticker = S.Ticker
    where TM.Status = 1 and (RatingAction in ('initiate') or TargetPriceAction in ('increase', 'decrease'))
    group by S.Ticker
    ) V on V.Ticker= VF.Ticker and V.MaxPubNo = VF.PubNo

  --Temp table to hold tickers(for active trefis models) along with their epslastyear, epsthisyear & date when it's established
  select VF.Ticker,VF.EPSLastYear,VF.LastYear,EPSThisYear,VF.ThisYear,convert(varchar,P.Date,101) Date
  into #TmpTickerEPSFY1
  from vFinancials VF
  join Publications P on VF.PubNo = P.PubNo
  join
    (select S.Ticker, max(VF1.PubNo) MaxPubNo
    from TrefisModels TM
    join Securities2 S on S.SecurityId = TM.SecurityId
    join vFinancials VF1 on VF1.Ticker = S.Ticker
    where TM.Status = 1 and (RatingAction in ('initiate') or EstimateAction in ('upgrade', 'downgrade'))
    group by S.Ticker
    ) V on V.Ticker= VF.Ticker and V.MaxPubNo = VF.PubNo

  --Temp table to hold tickers(for active trefis models) along with their epsnextyear & date when it's established
  select VF.Ticker,VF.EPSNextYear,VF.NextYear,convert(varchar,P.Date,101) Date
  into #TmpTickerEPSFY2
  from vFinancials VF
  join Publications P on VF.PubNo = P.PubNo
  join
    (select S.Ticker, max(VF1.PubNo) MaxPubNo
    from TrefisModels TM
    join Securities2 S on S.SecurityId = TM.SecurityId
    join vFinancials VF1 on VF1.Ticker = S.Ticker
    where TM.Status = 1 and (RatingAction in ('initiate') or EstimateNextYearAction in ('upgrade', 'downgrade'))
    group by S.Ticker
    )V on V.Ticker= VF.Ticker and V.MaxPubNo = VF.PubNo

  -- Output rowset
  select
    convert(varchar, getdate(), 101) RunDate,
    S.Ticker Bloomberg,
    S.RIC,
    S.ISIN,
    S.Company,
    T1.TargetPrice,
    S.CurrencyCode,
    T1.Date TargetPriceDate,
    convert(varchar, TM.UploadDate, 101) ModelDate,
    ET.EpsType EPS_TYPE,
    CONVERT(varchar, CONVERT(int, FCS.BaseYear)) + 'A' FY0,
    CONVERT(varchar, CONVERT(int, FCS.BaseYear) + 1) + 'E' FY1,
    CONVERT(varchar, CONVERT(int, FCS.BaseYear) + 2) + 'E' FY2,
    T2.EPSLastYear EPS_FY0,
    T2.EPSThisYear EPS_FY1,
    T3.EPSNextYear EPS_FY2,
    T2.Date EPS_FY1_DATE,
    T3.Date EPS_FY2_DATE
  from TrefisModels TM
  join Securities2 S on S.SecurityId = TM.SecurityId
  join ResearchCoverage RC on RC.SecurityId = S.SecurityId
  join AnalystSettings AST on  AST.CoverageId = RC.CoverageId
  JOIN FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
  join EpsTypes ET on ET.EpsTypeId = AST.EpsTypeId
  join #TmpTickerTargetPrice T1 on T1.Ticker = S.Ticker
  join #TmpTickerEPSFY1 T2 on T2.Ticker = S.Ticker
  join #TmpTickerEPSFY2 T3 on T3.Ticker = S.Ticker
  where TM.Status = 1 and RC.LaunchDate is not null and RC.DropDate is null
  order by S.Ticker

  drop table #TmpTickerTargetPrice
  drop table #TmpTickerEPSFY1
  drop table #TmpTickerEPSFY2

end



GO

-- =================================================================================================
-- Author:      Krishna Josyula
-- Revised:     12/10/2009
-- Description:  Get TickerTableXML for a given publication
-- =================================================================================================
ALTER PROCEDURE [dbo].[spGetTickerTableXML]
  @PubNo        int
AS
IF NOT EXISTS (SELECT * FROM vFinancials WHERE PubNo = @PubNo)
  BEGIN
    SELECT '<NotExist>' + CONVERT(varchar, @PubNo) + '</NotExist>' AS XML
    RETURN
  END

SELECT TOP 1
  1                   as Tag,
  NULL                as Parent,
  PubNo               as [TickerTable!1!pubNo],
  EPSType             as [TickerTable!1!epsType],
  MetricType          as [TickerTable!1!metricType],
  DisplayCloseDate    as [TickerTable!1!displayCloseDate],
  LastYear            as [TickerTable!1!lastYear],
  ThisYear            as [TickerTable!1!thisYear],
  NextYear            as [TickerTable!1!nextYear],
  RelPerfType         as [TickerTable!1!relPerfType],
  NULL                as [Security!2!ticker],    --11
  NULL                as [Security!2!rating],
  NULL                as [Security!2!currency],
  NULL                as [Security!2!closeDate],
  NULL                as [Security!2!closePrice],
  NULL                as [Security!2!targetPrice],
  NULL                as [Security!2!ytdRelPerf],
  NULL                as [Security!2!ttmRelPerf],
  NULL                as [Security!2!epsLastYear],
  NULL                as [Security!2!epsThisYear],
  NULL                as [Security!2!epsNextYear],
  NULL                as [Security!2!metricLastYear],
  NULL                as [Security!2!metricThisYear],
  NULL                as [Security!2!metricNextYear],
  NULL                as [Security!2!yield],
  NULL                as [Security!2!coverageAction],
  NULL                as [Security!2!ratingAction],
  NULL                as [Security!2!targetpriceAction],
  NULL                as [Security!2!estimateAction],
  NULL                as [Security!2!tickerOrder],  --30
  NULL                as [Old!3!rating],
  NULL                as [Old!3!targetPrice],
  NULL                as [Old!3!epsThisYear],
  NULL                as [Old!3!epsNextYear],
  NULL                as [Old!3!ticker!hide],        --35
  NULL                as [Footnote!4!text],
  NULL                as [Ref!5!ref]
FROM vFinancials WITH(NOLOCK) WHERE PubNo = @PubNo

UNION ALL

SELECT
  2                   as tag,
  1                   as Parent,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  VF.Ticker,
  VF.Rating,
  VF.Currency,
  CONVERT(varchar, VF.CloseDate, 101),
  VF.ClosePrice,
  VF.TargetPrice,
  CASE WHEN VF.RelPerfType = 'YTD' THEN VF.YTDRelPerf ELSE '' END AS YTDRelPerf,
  CASE WHEN VF.RelPerfType = 'TTM' THEN VF.YTDRelPerf ELSE '' END AS TTMRelPerf,
  VF.EPSLastYear,
  VF.EPSThisYear,
  VF.EPSNextYear,
  VF.MetricLastYear,
  VF.MetricThisYear,
  VF.MetricNextYear,
  VF.Yield,
  ISNULL(VF.CoverageAction,''),
  ISNULL(VF.RatingAction,''),
  ISNULL(VF.TargetPriceAction,''),
  ISNULL(VF.EstimateAction,''),
  VF.TickerOrder,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL

FROM vFinancials VF WITH(NOLOCK) WHERE VF.PubNo = @PubNo

UNION ALL

SELECT
  3                   as tag,
  2                   as Parent,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  VF.Ticker,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  VF.TickerOrder,
  ISNULL(VF.RatingPrior, ''),
  ISNULL(VF.TargetPricePrior, ''),
  VF.EPSThisYearPrior,
  VF.EPSNextYearPrior,
  VF.Ticker,
  NULL,
  NULL
FROM vFinancials VF WHERE VF.PubNo = @PubNo
AND (VF.RatingPrior IS NOT NULL OR
     VF.TargetPricePrior IS NOT NULL OR
     VF.EPSThisYearPrior IS NOT NULL OR
     VF.EPSNextYearPrior IS NOT NULL)

UNION ALL

SELECT
  4                   as tag,
  1                   as Parent,
  FN.PubNo,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  99,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  FN.FootnoteText,
  NULL
FROM FootNotes FN WITH(NOLOCK) WHERE FN.PubNo = @PubNo

UNION ALL

SELECT
  5                   as tag,
  4                   as Parent,
  FNR.PubNo,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  99,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  FNR.FootNoteRef
FROM FootnoteRefs FNR WITH(NOLOCK) WHERE FNR.PubNo = @PubNo

ORDER BY 30, 11, 35
FOR XML EXPLICIT



GO
