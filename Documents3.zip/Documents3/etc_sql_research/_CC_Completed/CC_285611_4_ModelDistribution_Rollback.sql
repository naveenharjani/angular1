-- CC_x_4_ModelDistribution_Rollback.sql
-- 06/12/2018

/*

create ModelDistributionQueue
create spSaveModelSchedulerState
create spUpdateModelDistributionItem

alter spSaveModel
alter spUpdateDistributionItem
alter spGetFTPLogin
alter spGetDistributionDetail
alter spGetDistributionSummary
alter spSearchDistributionSites

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ModelDistributionQueue]') AND type in (N'U'))
DROP TABLE [dbo].[DistributionQueue]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spSaveModelSchedulerState]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spSaveModelSchedulerState]
GO

IF EXISTS(SELECT * FROM Sys.Objects WHERE type = 'P' and name = 'spUpdateModelDistributionItem')
DROP PROC dbo.spUpdateModelDistributionItem
GO

alter proc dbo.spSaveModel (@ModelId int, @SecurityId int, @CoverageId int, @PubNo int, @FileName varchar(30), @FileNameOrig varchar(100), @FileSize int, @ActionId int, @UserName varchar(10))
as
begin try
  begin transaction

  declare @PrimarySecurityId int
  declare @AnalystId int
  declare @UserId int

  if @UserName is null or @UserName = ''
  select @UserId = 0
  else
  select top 1 @UserId = UserId from Users where UserName like '%' + @UserName+ '%'

  select @PrimarySecurityId = SecurityId from Securities2
  where CompanyId = (select CompanyId from Securities2 where SecurityId = @SecurityId)
  and IsPrimary = 'Y'

  select @AnalystId = AnalystId from ResearchCoverage where CoverageId = @CoverageId

  update Models
  set StateId = 2
  from Models M
  where SecurityId = @PrimarySecurityId and StateId = 1

  insert into Models(ModelId,CoverageId,AnalystId,SecurityId,PubNo,FileName,FileNameOrig,FileSize,ActionId,StateId,EditorId,EditDate)
  select
    @ModelId,
    @CoverageId,
    @AnalystId,
    @PrimarySecurityId,
    @PubNo,
    @FileName,
    @FileNameOrig,
    @FileSize,
    @ActionId,
    1,
    @UserId,
    getdate()
  select 0 ReturnValue
  commit
end try
begin catch
    if @@TRANCOUNT > 0
      rollback
    -- Raise an error with the details of the exception
    declare @ErrMsg nvarchar(4000), @ErrSeverity int
    select @ErrMsg = ERROR_MESSAGE(), @ErrSeverity = ERROR_SEVERITY()

    select -1 ReturnValue
    raiserror(@ErrMsg, @ErrSeverity, 1)
end catch

GO
ALTER PROCEDURE dbo.spUpdateDistributionItem
  @DistributionID  int,
  @SiteID          int,
  @ColumnName      varchar(15)
AS

IF @ColumnName = 'Transferred'
  UPDATE DistributionQueue
  SET Transferred = GETDATE(), LinkBack = CASE WHEN DSI.LinkBack = -1  AND DSI.LinkSourceId is not null THEN 'T' ELSE null END
  FROM DistributionSites DSI JOIN DistributionQueue DQ ON DSI.SiteId = DQ.SiteId
  WHERE DQ.DistributionID = @DistributionID AND DSI.SiteID = @SiteID

IF @ColumnName = 'Cancelled'
  UPDATE DistributionQueue
  SET Cancelled = GETDATE()
  WHERE DistributionID = @DistributionID AND SiteID = @SiteID

GO

ALTER PROCEDURE dbo.spGetFTPLogin
  @SiteId     int
AS
SELECT FtpLogon, FtpPassword, FtpFolder, ScbFolder, FtpType, FtpPort
FROM DistributionSites WHERE SiteId = @SiteId
GO

CREATE PROCEDURE [dbo].[spGetDistributionDetail]
  @PubNo int
AS
SELECT
  DQ.PubNo,
  DQ.DistributionID,
  S.SiteID,  -- NEED ID FROM SITES TABLE TO INCLUDE POTENTIAL NEW DISTRIBUTION
  S.Site,
  CONVERT(varchar, DQ.Approved, 101)  + ' ' + SUBSTRING(CONVERT(varchar, DQ.Approved,  108), 1, LEN(CONVERT(varchar, DQ.Approved,  108)) - 3),
  CONVERT(varchar, DQ.Scheduled, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Scheduled, 108), 1, LEN(CONVERT(varchar, DQ.Scheduled, 108)) - 3),
  CASE DQ.Operation
    WHEN 'C' THEN
      CASE
        WHEN DQ.IsException = -1      THEN 'Excluded'
        WHEN DQ.Cancelled IS NOT NULL THEN 'Cancelled '   + CONVERT(varchar, DQ.Cancelled,   101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Cancelled,   108), 1, LEN(CONVERT(varchar, DQ.Cancelled,   108)) - 3)
        ELSE                               'Contributed ' + CONVERT(varchar, DQ.Transferred, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Transferred, 108), 1, LEN(CONVERT(varchar, DQ.Transferred, 108)) - 3)
      END
    WHEN 'D' THEN
      CASE
        WHEN DQ.Cancelled IS NOT NULL THEN 'Cancelled '    + CONVERT(varchar, DQ.Cancelled,   101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Cancelled,   108), 1, LEN(CONVERT(varchar, DQ.Cancelled,   108)) - 3)
        ELSE                               'Recalled '     + CONVERT(varchar, DQ.Transferred, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Transferred, 108), 1, LEN(CONVERT(varchar, DQ.Transferred, 108)) - 3)
      END
  END AS Status,
  'Out' =
    CASE
      WHEN DQ.Transferred IS NOT NULL THEN
        CASE
          WHEN DF.FileType = 'K' AND LEN(DF.FileVersion) = 1 THEN S.ScbFolder + '\' + CONVERT(varchar, DF.DistributionID) + '.' + DF.FileType + '0' + CONVERT(varchar, DF.FileVersion) + '.txt'
          WHEN DF.FileType = 'K' AND LEN(DF.FileVersion) > 1 THEN S.ScbFolder + '\' + CONVERT(varchar, DF.DistributionID) + '.' + DF.FileType + CONVERT(varchar, DF.FileVersion) + '.txt'
          WHEN DF.FileType = 'XML' THEN S.ScbFolder + '\' + CONVERT(varchar, DF.DistributionID) + '.' + DF.FileType
          ELSE S.ScbFolder + '\' + CONVERT(varchar, DF.DistributionID) + '.' + DF.FileType + '.txt'
        END
      ELSE NULL
    END,
  CASE DQ.Operation
    WHEN 'C' THEN 'SEND'
    WHEN 'D' THEN 'RECALL'
  END AS Operation,
  S.Active   -- FOR ASP SUPPORT:  DETERMINES THE NEED TO DISPLAY SEND/RECALL/CANCEL LINKS UNDER "OPTIONS" COLUMN
FROM DistributionSites S
LEFT JOIN DistributionQueue DQ ON DQ.SiteID = S.SiteID AND DQ.PubNo = @PubNo
LEFT JOIN DistributionFiles DF ON DF.DistributionID = DQ.DistributionID AND DF.FileType IN ('HDM', 'XML', 'K', 'CTL', 'CTLD')
WHERE S.Active = -1 OR S.SiteID = DQ.SiteID -- DISPLAY PREVIOUSLY DISTRIBUTED BUT NOT ACTIVE ANYMORE
ORDER BY DQ.PubNo DESC, S.Site ASC, DQ.DistributionID DESC
GO

ALTER PROCEDURE [dbo].[spGetDistributionSummary]
  @SiteID       int,
  @Since         datetime,
  @Until         datetime
AS
SELECT
  DQ.PubNo,
  DQ.DistributionID,
  DQ.SiteID,
  S.Site,
  CONVERT(varchar, DQ.Approved, 101)  + ' ' + SUBSTRING(CONVERT(varchar, DQ.Approved, 108), 1, LEN(CONVERT(varchar, DQ.Approved, 108)) - 3),
  CONVERT(varchar, DQ.Scheduled, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Scheduled, 108), 1, LEN(CONVERT(varchar, DQ.Scheduled, 108)) - 3),
  CASE DQ.Operation
    WHEN 'C' THEN
      CASE
        WHEN DQ.IsException = -1      THEN 'Excluded'
        WHEN DQ.Cancelled IS NOT NULL THEN 'Cancelled '   + CONVERT(varchar, DQ.Cancelled,   101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Cancelled, 108), 1, LEN(CONVERT(varchar, DQ.Cancelled, 108)) - 3)
        ELSE                               'Contributed ' + CONVERT(varchar, DQ.Transferred, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Transferred, 108), 1, LEN(CONVERT(varchar, DQ.Transferred, 108)) - 3)
      END
    WHEN 'D' THEN
      CASE
        WHEN DQ.Cancelled IS NOT NULL THEN 'Cancelled '    + CONVERT(varchar, DQ.Cancelled,   101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Cancelled, 108), 1, LEN(CONVERT(varchar, DQ.Cancelled, 108)) - 3)
        ELSE                               'Recalled  '    + CONVERT(varchar, DQ.Transferred, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Transferred, 108), 1, LEN(CONVERT(varchar, DQ.Transferred, 108)) - 3)
      END
  END AS Status
FROM DistributionQueue DQ
JOIN DistributionSites S ON S.SiteID = DQ.SiteID
WHERE (S.SiteID & @SiteID = @SiteID) AND DQ.Approved BETWEEN @Since AND @Until + 1
AND DQ.DistributionID IN -- FOR SUMMARY PURPOSES, DISPLAY ONLY THE LATEST DISTRIBUTION STATUS PER PUBNO PER SITE
  (SELECT MAX(DQ.DistributionID) FROM DistributionQueue DQ WHERE DQ.Approved BETWEEN @Since AND @Until + 1 GROUP BY DQ.PubNo, DQ.SiteID)
ORDER BY DQ.PubNo DESC, S.Site ASC, DQ.Scheduled DESC, DQ.Transferred DESC
GO

ALTER PROCEDURE [dbo].[spSearchDistributionSites]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'
CREATE TABLE #TmpSearch
(
  ID             int IDENTITY,
  SiteID         int         NOT NULL,
  Site           varchar(32) NOT NULL,
  Model          char(4)     NOT NULL,
  Adapter        varchar(16) NOT NULL,
  Codeset        varchar(16) NOT NULL,
  FtpLogon       varchar(64) NOT NULL,
  FtpPassword    varchar(16) NOT NULL,
  FtpFolder      varchar(48) NOT NULL,
  ScbFolder      varchar(48) NOT NULL,
  RixmlOrgIdType varchar(100)    NULL,
  RixmlOrgId     varchar(100)    NULL,
  WatermarkText  varchar(100)    NULL,
  UseSchedule    int         NOT NULL,
  Active         int         NOT NULL,
  Min            datetime        NULL,
  Max            datetime        NULL,
  Num            int             NULL,
  Editor         varchar(36)     NULL,
  EditDate       datetime        NULL
)
INSERT INTO #TmpSearch (SiteID, Site, Model, Adapter, Codeset, FtpLogon, FtpPassword, FtpFolder, ScbFolder, RixmlOrgIdType, RixmlOrgId, WatermarkText, UseSchedule, Active, Min, Max, Num, Editor, EditDate)
EXEC
('
SELECT
  SI.SiteID,
  SI.Site,
  SI.Model,
  AD.Adapter,
  SI.Codeset,
  SI.FtpLogon,
  SI.FtpPassword,
  SI.FtpFolder,
  SI.ScbFolder,
  SI.RixmlOrgIdType,
  SI.RixmlOrgId,
  SI.WatermarkText,
  SI.UseSchedule,
  SI.Active,
  Min = (SELECT MIN(Transferred) FROM DistributionQueue WHERE SiteID = SI.SiteID AND Transferred IS NOT NULL),
  Max = (SELECT MAX(Transferred) FROM DistributionQueue WHERE SiteID = SI.SiteID AND Transferred IS NOT NULL),
  Num = (SELECT COUNT(*) FROM DistributionQueue WHERE SiteID = SI.SiteID),
  E.UserName,
  SI.EditDate
FROM DistributionSites SI
JOIN DistributionAdapters AD ON AD.AdapterID = SI.AdapterID
LEFT JOIN Users E ON E.UserID = SI.EditorID
ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT SiteID, Site, Model, Adapter, Codeset, FtpLogon, FtpPassword, FtpFolder, ScbFolder, RixmlOrgIdType, RixmlOrgId, WatermarkText, UseSchedule, Active, Min, Max, Num, Editor, EditDate
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO
