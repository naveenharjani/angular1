--09/06/2018
/*
alter spSearchDistributionSites           - Alter to MinDate, MaxDate & Number of models from ModelDistributionQueue table
*/
USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spSearchDistributionSites]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'
CREATE TABLE #TmpSearch
(
  ID             int IDENTITY,
  SiteId         int          NOT NULL,
  Site           varchar(32)  NOT NULL,
  Model          char(4)      NOT NULL,
  Adapter        varchar(16)  NOT NULL,
  Codeset        varchar(16)  NOT NULL,
  FtpLogon       varchar(64)  NOT NULL,
  FtpPassword    varchar(64)  NOT NULL,
  FtpFolder      varchar(100) NOT NULL,
  ScbFolder      varchar(100) NOT NULL,
  RixmlOrgIdType varchar(100)     NULL,
  RixmlOrgId     varchar(100)     NULL,
  WatermarkText  varchar(100)     NULL,
  UseSchedule    int          NOT NULL,
  Active         int          NOT NULL,
  Min            datetime         NULL,
  Max            datetime         NULL,
  Num            int              NULL,
  Editor         varchar(36)      NULL,
  EditDate       datetime         NULL,
  LinkBack       int              NULL,
  SiteType       char(1)          NULL,
)
INSERT INTO #TmpSearch (SiteId, Site, Model, Adapter, Codeset, FtpLogon, FtpPassword, FtpFolder, ScbFolder, RixmlOrgIdType, RixmlOrgId, WatermarkText, UseSchedule, Active, Min, Max, Num, Editor, EditDate, LinkBack, SiteType)
EXEC
('
SELECT
  SI.SiteId,
  SI.Site,
  SI.Model,
  AD.Adapter,
  SI.Codeset,
  SI.FtpLogon,
  SI.FtpPassword,
  SI.FtpFolder,
  SI.ScbFolder,
  SI.RixmlOrgIdType,
  SI.RixmlOrgId,
  SI.WatermarkText,
  SI.UseSchedule,
  SI.Active,
  Min = (SELECT MIN(Transferred) FROM DistributionQueue WHERE SiteId = SI.SiteId AND Transferred IS NOT NULL),
  Max = (SELECT MAX(Transferred) FROM DistributionQueue WHERE SiteId = SI.SiteId AND Transferred IS NOT NULL),
  Num = (SELECT COUNT(*) FROM DistributionQueue WHERE SiteId = SI.SiteId),
  E.UserName,
  SI.EditDate,
  SI.LinkBack,
  SI.SiteType
FROM DistributionSites SI
JOIN DistributionAdapters AD ON AD.AdapterID = SI.AdapterID
LEFT JOIN Users E ON E.UserID = SI.EditorID 
WHERE SiteType = ''R''
UNION
SELECT
  SI.SiteId,
  SI.Site,
  SI.Model,
  AD.Adapter,
  SI.Codeset,
  SI.FtpLogon,
  SI.FtpPassword,
  SI.FtpFolder,
  SI.ScbFolder,
  SI.RixmlOrgIdType,
  SI.RixmlOrgId,
  SI.WatermarkText,
  SI.UseSchedule,
  SI.Active,
  Min = (SELECT MIN(Completed) FROM ModelDistributionQueue WHERE SiteId = SI.SiteId AND Completed IS NOT NULL),
  Max = (SELECT MAX(Completed) FROM ModelDistributionQueue WHERE SiteId = SI.SiteId AND Completed IS NOT NULL),
  Num = (SELECT COUNT(*) FROM ModelDistributionQueue WHERE SiteId = SI.SiteId AND Completed IS NOT NULL),
  E.UserName,
  SI.EditDate,
  SI.LinkBack,
  SI.SiteType
FROM DistributionSites SI
JOIN DistributionAdapters AD ON AD.AdapterID = SI.AdapterID
LEFT JOIN Users E ON E.UserID = SI.EditorID 
WHERE SiteType = ''M''
ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT SiteId, Site, Model, Adapter, Codeset, FtpLogon, FtpPassword, FtpFolder, ScbFolder, RixmlOrgIdType, RixmlOrgId, WatermarkText, UseSchedule, Active, Min, Max, Num, Editor, EditDate, LinkBack, SiteType
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO
