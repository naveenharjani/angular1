-- AutonomousDisclosures.sql
-- 03/04/2019

/*

-- Author Disclosures (authortextdisclosures.asp)
-- Author dropdown filter    : spRenderAuthors 4
-- Disclosures Listing       : spGetAuthorTextDisclosures
-- Save                      : spSaveAuthorTextDisclosure -- Add logging

-- Security Disclosures (securitytextdisclosures.asp)
-- Security dropdown filter  : spRenderActiveSecurities
-- Disclosure Listing        : spGetSecurityTextDisclosures
-- Save                      : spSaveSecurityTextDisclosure -- Add logging

-- Security Checkbox Disclosures (securitycheckboxdisclosures.asp)
-- Disclosure listing        : spSearchSecurityCheckboxDisclosures
-- Save                      : spSaveSecurityCheckboxDisclosure -- Add logging

alter Authors
alter Securities2
alter spRenderAuthors
alter spRenderSecurities
alter spGetAuthorTextDisclosures
alter spGetSecurityTextDisclosures
alter spSearchSecurityCheckboxDisclosures
alter spSaveAuthorTextDisclosure
alter spSaveSecurityTextDisclosure
alter spSaveSecurityCheckboxDisclosure

*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if not exists(select * from sys.columns where name = 'AltId' and object_id = OBJECT_ID('Authors'))
alter table Authors
add TypeId int, AltId int
GO

/*
alter table Authors drop column TypeId, AltId
select * from authors where typeid = 2
delete from AuthorTextDisclosures where AuthorId in (select AuthorId from Authors where typeid = 2)
Update A Set TypeId = 1 from Authors A join ResearchCoverage RC on A.AuthorId = RC.AnalystId where A.typeid = 2 and RC.DropDate is not null
delete from Authors where typeid = 2
*/

if not exists(select * from sys.columns where name = 'AltId' and object_id = OBJECT_ID('Securities2'))
alter table Securities2
add TypeId int, AltId int
GO

/*
alter table Securities2 drop column TypeId, AltId
select * from Securities2 where typeid = 2
delete from SecurityTextDisclosures where SecurityId in (select SecurityId from Securities2 where typeid = 2)
Update S Set TypeId = 1 from Securities2 S join ResearchCoverage RC on S.SecurityId = RC.SecurityId where S.typeid = 2 and ((launchdate is not null and RC.DropDate is not null) or (launchdate is null and dropdate is null))

delete from Securities2 where typeid = 2
select * from Securities2 where typeid = 2
select * from financialsecuritysettings where securityid in (select SecurityId from Securities2 where typeid = 2)
*/

--Initialize TypeId = 1 for Bernstein Authors
update Authors set TypeId = 1 where TypeId is null

--Initialize TypeId = 1 for Bernstein Tickers
update Securities2 set TypeId = 1 where TypeId is null
GO

--Initialize Fax column with Broker-Dealer location values based on Phone
/*
update Authors
set Fax = case  when Phone like '+1%' or Phone like '1%' then 'US'
        when Phone like '+41%' or Phone like '+44%' then 'UK'
        when Phone like '+852%' or Phone like '+65%' then 'HK'
        end
*/

ALTER PROCEDURE [dbo].[spRenderAuthors]
  @Style  int,
  @Region int = 1
AS
IF @Style = 1      SELECT 'Value' = Name,     'Display' = Last + ', ' + First FROM Authors                                        ORDER BY Display
ELSE IF @Style = 2 SELECT 'Value' = Name,     'Display' = Last + ', ' + First FROM Authors WHERE IsActive = -1 AND IsAnalyst = -1 ORDER BY Display
ELSE IF @Style = 3 SELECT 'Value' = AuthorID, 'Display' = Last + ', ' + First FROM Authors                                        ORDER BY Display
ELSE IF @Style = 4 SELECT 'Value' = AuthorID, 'Display' = Last + ', ' + First FROM Authors WHERE IsActive = -1                    ORDER BY Display
ELSE IF @Style = 5 SELECT 'Value' = AuthorID, 'Display' = Last + ', ' + First FROM Authors WHERE IsActive = -1 AND IsAnalyst = -1 AND TypeId = 1 ORDER BY Display

--Active Analysts in a region
ELSE IF @Style = 6
SELECT distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
FROM Authors A JOIN ResearchCoverage RC ON A.AuthorId = RC.AnalystId
LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
WHERE IsAnalyst = -1
AND RC.Launchdate is not null AND RC.Dropdate is null
AND R.RegionId = @Region
ORDER BY Display

--Active Analysts in all regions
ELSE IF @Style = 7
SELECT distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
FROM Authors A JOIN ResearchCoverage RC ON A.AuthorId = RC.AnalystId
LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
WHERE IsAnalyst = -1
AND RC.Launchdate is not null and RC.Dropdate is null
AND TypeId = 1 
ORDER BY Display

--All Analysts in a region
ELSE IF @Style = 8
SELECT distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
FROM Authors A LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
WHERE
IsAnalyst = -1 and
R.RegionId = @Region
ORDER BY Display

--All Analysts in all regions
ELSE IF @Style = 9
SELECT distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
FROM Authors A LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
WHERE IsAnalyst = -1
ORDER BY Display

--Used by Author/Security/Firm disclosures where Autonomous authors are displayed
ELSE IF @Style = 10
SELECT Value, Display
FROM
(
  SELECT 'Value' = '', 'Display' = 'BERNSTEIN ==========',  1 TypeId, 1 SeqNo
  UNION
  SELECT 'Value' = '', 'Display' = 'AUTONOMOUS ==========',  2, 1
  UNION
  SELECT 'Value' = AuthorId, 'Display' = Last + ', ' + First, ISNULL(TypeId, 1), 2
  FROM Authors WHERE IsActive = -1
) V
ORDER BY TypeId, SeqNo, Display

GO

ALTER PROCEDURE [dbo].[spRenderSecurities]
  @Style int,
  @CompanyId int = NULL,
  @AnalystId int = NULL
AS
SET NOCOUNT ON
DECLARE @Analysts TABLE(AnalystId int)

IF @Style = 1      SELECT 'Value' = Ticker,     'Display' = Ticker + ' / ' + Company FROM Securities2                     ORDER BY Display
ELSE IF @Style = 2 SELECT 'Value' = Ticker,     'Display' = Ticker + ' / ' + Company FROM Securities2 WHERE IsActive = -1 ORDER BY Display
ELSE IF @Style = 3 SELECT 'Value' = SecurityId, 'Display' = Ticker + ' / ' + Company FROM Securities2                     ORDER BY Display
ELSE IF @Style = 4 SELECT 'Value' = SecurityId, 'Display' = Ticker + ' / ' + Company FROM Securities2 WHERE IsActive = -1 ORDER BY Display
ELSE IF @Style = 5
BEGIN
SELECT
  'Value' = S.SecurityId,
  'Display' = S.Ticker
FROM Companies C
JOIN Securities2 S ON S.CompanyId = C.CompanyId
WHERE C.CompanyId = @CompanyId AND S.IsActive = -1 ORDER BY S.OrdNo
END
ELSE IF @Style = 6
BEGIN
IF @AnalystId = -1 OR ISNULL(@AnalystId, 0) = 0
  INSERT @Analysts SELECT AuthorId FROM Authors WHERE IsAnalyst = -1 AND IsActive = -1
ELSE
  INSERT @Analysts SELECT @AnalystId

SELECT DISTINCT
  'Value'   = S.SecurityId,
  'Display' = S.Ticker + ' / ' + S.Company
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
WHERE RC.DropDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)
ORDER BY Display
END

ELSE IF @Style = 7
BEGIN
SELECT Value, Display
FROM
(
  SELECT 'Value' = '', 'Display' = 'BERNSTEIN ==========', 1 TypeId, 1 SeqNo
  UNION
  SELECT 'Value' = '', 'Display' = 'AUTONOMOUS ==========',  2, 1
  UNION
  SELECT 'Value' = S.SecurityId, 'Display' = S.Ticker + ' / ' + S.Company, TypeId, 2
  FROM Securities2 S
  JOIN ResearchCoverage RC ON RC.SecurityId = S.SecurityId
  WHERE S.TypeId = 1 AND RC.DropDate IS NULL
  UNION
  SELECT 'Value' = S.SecurityId, 'Display' = S.Ticker + ' / ' + S.Company, TypeId, 2
  FROM Securities2 S
  WHERE TypeId = 2 AND IsActive = -1
) V
ORDER BY TypeId, SeqNo, Display
END
GO

ALTER PROCEDURE dbo.spGetAuthorTextDisclosures
  @AuthorID      int,
  @Disclosure    varchar(2048) OUTPUT,
  @Editor        varchar(36)   OUTPUT,
  @EditDate      datetime      OUTPUT
AS
-- RETURN OUTPUT PARAMETERS
SELECT
  @Disclosure = D.Disclosure,
  @Editor     = U.UserName,
  @EditDate   = D.EditDate
FROM AuthorTextDisclosures D
LEFT JOIN Users U ON U.UserID = D.EditorID
WHERE D.AuthorID = @AuthorID
-- RETURN ROWSET
SELECT D.AuthorID, A.Last + ', ' + A.First, CASE A.TypeId WHEN 1 THEN 'Bernstein' WHEN 2 THEN 'Autonomous' END Type, D.Disclosure, U.UserName, D.EditDate
FROM Authors A
JOIN AuthorTextDisclosures D ON D.AuthorID = A.AuthorID
LEFT JOIN Users U ON U.UserID = D.EditorID
WHERE A.IsActive = -1 ORDER BY 3 desc, 2
GO

ALTER PROCEDURE dbo.spGetSecurityTextDisclosures
  @SecurityId    int,
  @Disclosure    varchar(2048) OUTPUT,
  @Editor        varchar(36)   OUTPUT,
  @EditDate      datetime      OUTPUT
AS
-- RETURN OUTPUT PARAMETERS
SELECT
  @Disclosure = D.Disclosure,
  @Editor     = U.UserName,
  @EditDate   = D.EditDate
FROM SecurityTextDisclosures D
LEFT JOIN Users U ON U.UserID = D.EditorID
WHERE D.SecurityId = @SecurityId
-- RETURN ROWSET
SELECT D.SecurityId, S.Ticker + ' / ' + S.Company, 'Bernstein' Type, D.Disclosure, U.UserName, D.EditDate
FROM ResearchCoverage C
JOIN SecurityTextDisclosures D ON D.SecurityId = C.SecurityId
JOIN Securities2 S ON S.SecurityId = C.SecurityId
LEFT JOIN Users U ON U.UserID = D.EditorID
WHERE S.TypeId = 1 AND C.DropDate IS NULL

UNION

SELECT D.SecurityId, S.Ticker + ' / ' + S.Company, 'Autonomous' Type, D.Disclosure, U.UserName, D.EditDate
FROM SecurityTextDisclosures D
JOIN Securities2 S ON S.SecurityId = D.SecurityId
LEFT JOIN Users U ON U.UserID = D.EditorID
WHERE S.TypeId = 2 AND S.IsActive = -1 ORDER BY 3 desc, 2

GO

ALTER PROCEDURE [dbo].[spSearchSecurityCheckboxDisclosures]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'
CREATE TABLE #TmpSearch
(
  ID         int IDENTITY,
  SecurityId int         NULL,
  Ticker     varchar(15) NULL,
  Company    varchar(63) NULL,
  Type       varchar(50) NULL,
  D1         smallint    NULL,
  D2         smallint    NULL,
  D3         smallint    NULL,
  D4         smallint    NULL,
  D5         smallint    NULL,
  D6         smallint    NULL,
  D7         smallint    NULL,
  D8         smallint    NULL,
  D9         smallint    NULL,
  D10        smallint    NULL
)
INSERT INTO #TmpSearch (SecurityId, Ticker, Company, Type, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10)
EXEC
('
SELECT
  SecurityId = C.SecurityId,
  Ticker     = S.Ticker,
  Company    = S.Company,
  Type       = ''Bernstein'',
  SUM(CASE WHEN D.DisclosureId =  1 THEN -1 ELSE 0 END) AS D1,
  SUM(CASE WHEN D.DisclosureId =  2 THEN -1 ELSE 0 END) AS D2,
  SUM(CASE WHEN D.DisclosureId =  3 THEN -1 ELSE 0 END) AS D3,
  SUM(CASE WHEN D.DisclosureId =  4 THEN -1 ELSE 0 END) AS D4,
  SUM(CASE WHEN D.DisclosureId =  5 THEN -1 ELSE 0 END) AS D5,
  SUM(CASE WHEN D.DisclosureId =  6 THEN -1 ELSE 0 END) AS D6,
  SUM(CASE WHEN D.DisclosureId =  7 THEN -1 ELSE 0 END) AS D7,
  SUM(CASE WHEN D.DisclosureId =  8 THEN -1 ELSE 0 END) AS D8,
  SUM(CASE WHEN D.DisclosureId =  9 THEN -1 ELSE 0 END) AS D9,
  SUM(CASE WHEN D.DisclosureId = 10 THEN -1 ELSE 0 END) AS D10
FROM ResearchCoverage C
JOIN Securities2 S ON S.SecurityId  = C.SecurityId
LEFT JOIN SecurityCheckboxDisclosures D ON D.SecurityId = C.SecurityId
WHERE S.TypeId = 1 AND C.DropDate IS NULL
GROUP BY C.SecurityId, S.Ticker, S.Company

 UNION

SELECT
  SecurityId = S.SecurityId,
  Ticker     = S.Ticker,
  Company    = S.Company,
  Type       = ''Autonomous'',
  SUM(CASE WHEN D.DisclosureId =  1 THEN -1 ELSE 0 END) AS D1,
  SUM(CASE WHEN D.DisclosureId =  2 THEN -1 ELSE 0 END) AS D2,
  SUM(CASE WHEN D.DisclosureId =  3 THEN -1 ELSE 0 END) AS D3,
  SUM(CASE WHEN D.DisclosureId =  4 THEN -1 ELSE 0 END) AS D4,
  SUM(CASE WHEN D.DisclosureId =  5 THEN -1 ELSE 0 END) AS D5,
  SUM(CASE WHEN D.DisclosureId =  6 THEN -1 ELSE 0 END) AS D6,
  SUM(CASE WHEN D.DisclosureId =  7 THEN -1 ELSE 0 END) AS D7,
  SUM(CASE WHEN D.DisclosureId =  8 THEN -1 ELSE 0 END) AS D8,
  SUM(CASE WHEN D.DisclosureId =  9 THEN -1 ELSE 0 END) AS D9,
  SUM(CASE WHEN D.DisclosureId = 10 THEN -1 ELSE 0 END) AS D10
FROM Securities2 S
LEFT JOIN SecurityCheckboxDisclosures D ON D.SecurityId = S.SecurityId
WHERE S.TypeId = 2 AND S.IsActive = -1
GROUP BY S.SecurityId, S.Ticker, S.Company

ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT SecurityId, Ticker, Company, Type, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO

ALTER PROCEDURE dbo.spSaveAuthorTextDisclosure
  @AuthorId      int,
  @Disclosure    varchar(2048),
  @EditorId      int
AS
-- NO ROW IMPLIES NO DISCLOSURE
DECLARE
@Author varchar(100),
@OldDisclosure varchar(2048),
@New varchar(100),
@Old varchar(100)

SELECT @Author = Last + ', ' + First FROM Authors WHERE AuthorId = @AuthorId
SELECT @OldDisclosure = Disclosure FROM AuthorTextDisclosures WHERE AuthorId = @AuthorId

-- In case of long Disclosure text, limit to 97 characters text to fit into AdminLog
IF (LEN(@Author + ' | ' + @Disclosure) > 100)
SELECT @New = LEFT(@Author + ' | ' + @Disclosure, 97) + '...'
ELSE
SELECT @New = @Author + ' | ' + @Disclosure

IF (LEN(@Author + ' | ' + @OldDisclosure) > 100)
SELECT @Old = LEFT(@Author + ' | ' + @OldDisclosure, 97) + '...'
ELSE
SELECT @Old = @Author + ' | ' + @OldDisclosure

IF @Disclosure IS NOT NULL
  BEGIN
    IF NOT EXISTS (SELECT AuthorId FROM AuthorTextDisclosures WHERE AuthorId = @AuthorId)
      BEGIN
      INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
      SELECT 'Disclosures | Author', 'A', @New, NULL, @AuthorId, @EditorId, GETDATE()

      INSERT INTO AuthorTextDisclosures (AuthorId, Disclosure, EditorId, EditDate) VALUES (@AuthorId, @Disclosure, @EditorId, GETDATE())
      END
    ELSE
      BEGIN
      INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
      SELECT 'Disclosures | Author', 'U',  @New, @Old, @AuthorId, @EditorId, GETDATE()

      UPDATE AuthorTextDisclosures SET Disclosure = @Disclosure, EditorId = @EditorId, EditDate = GETDATE() WHERE AuthorId = @AuthorId
      END
  END
ELSE
  BEGIN
    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    SELECT 'Disclosures | Author', 'D', '', @Old, @AuthorId, @EditorId, GETDATE()

    DELETE FROM AuthorTextDisclosures WHERE AuthorId = @AuthorId
  END
RETURN 0
GO

ALTER PROCEDURE dbo.spSaveSecurityTextDisclosure
  @SecurityId    int,
  @Disclosure    varchar(2048),
  @EditorId      int
AS
DECLARE
@Ticker varchar(100),
@OldDisclosure varchar(2048),
@New varchar(100),
@Old varchar(100)

SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityId = @SecurityId
SELECT @OldDisclosure = Disclosure FROM SecurityTextDisclosures WHERE SecurityId = @SecurityId

-- In case of long Disclosure text, limit to 97 characters text to fit into AdminLog
IF (LEN(@Ticker + ' | ' + @Disclosure) > 100)
SELECT @New = LEFT(@Ticker + ' | ' + @Disclosure, 97) + '...'
ELSE
SELECT @New = @Ticker + ' | ' + @Disclosure

IF (LEN(@Ticker + ' | ' + @OldDisclosure) > 100)
SELECT @Old = LEFT(@Ticker + ' | ' + @OldDisclosure, 97) + '...'
ELSE
SELECT @Old = @Ticker + ' | ' + @OldDisclosure

-- NO ROW IMPLIES NO DISCLOSURE
IF @Disclosure  IS NOT NULL
  BEGIN
    IF NOT EXISTS (SELECT SecurityId FROM SecurityTextDisclosures WHERE SecurityId = @SecurityId)
    BEGIN
      INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
      SELECT 'Disclosures | Security', 'A', @New, NULL, @SecurityId, @EditorId, GETDATE()

      INSERT INTO SecurityTextDisclosures (SecurityId, Disclosure, EditorId, EditDate) VALUES (@SecurityId, @Disclosure, @EditorId, GETDATE())
    END
    ELSE
    BEGIN
      INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
      SELECT 'Disclosures | Security', 'U', @New, @Old, @SecurityId, @EditorId, GETDATE()

      UPDATE SecurityTextDisclosures SET Disclosure = @Disclosure, EditorId = @EditorId, EditDate = GETDATE() WHERE SecurityId = @SecurityId
    END
  END
ELSE
  BEGIN
    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    SELECT 'Disclosures | Security', 'D', '', @Old, @SecurityId, @EditorId, GETDATE()

    DELETE FROM SecurityTextDisclosures WHERE SecurityId = @SecurityId
  END
RETURN 0
GO

ALTER PROCEDURE [dbo].[spSaveSecurityCheckboxDisclosure]
  @SecurityId   int,
  @DisclosureId int,
  @Disclosure   smallint, -- Checked is -1
  @EditorId     int,
  @Ticker       varchar(15) OUTPUT
AS

DECLARE
@NewDisclosure varchar(2048),
@OldDisclosure varchar(2048),
@New varchar(100),
@Old varchar(100)

SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityId = @SecurityId

SELECT @NewDisclosure = Disclosure FROM SecurityCheckboxTypes WHERE DisclosureId = @DisclosureId
SELECT @OldDisclosure = SC.Disclosure FROM SecurityCheckboxDisclosures SCD
JOIN SecurityCheckboxTypes SC ON SCD.DisclosureId = SC.DisclosureId
WHERE SecurityId = @SecurityId

-- In case of long Disclosure text, limit to 97 characters text to fit into AdminLog
IF (LEN(@Ticker + ' | ' + @NewDisclosure) > 100)
SELECT @New = LEFT(@Ticker + ' | ' + @NewDisclosure, 97) + '...'
ELSE
SELECT @New = @Ticker + ' | ' + @NewDisclosure

IF (LEN(@Ticker + ' | ' + @OldDisclosure) > 100)
SELECT @Old = LEFT(@Ticker + ' | ' + @OldDisclosure, 97) + '...'
ELSE
SELECT @Old = @Ticker + ' | ' + @OldDisclosure

-- NO ROWS IMPLIES NO DISCLOSURE
IF @Disclosure = -1
  BEGIN
    IF NOT EXISTS (SELECT * FROM SecurityCheckboxDisclosures WHERE SecurityId = @SecurityId AND DisclosureId = @DisclosureId)
      BEGIN
      INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
      SELECT 'Disclosures | Firm', 'A', @New, NULL, @SecurityId, @EditorId, GETDATE()

      INSERT INTO SecurityCheckboxDisclosures (SecurityId, DisclosureId, EditorId, EditDate) VALUES (@SecurityId, @DisclosureId, @EditorId, GETDATE())
      END
  END
ELSE
  BEGIN
    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    SELECT 'Disclosures | Firm', 'D', '', @Old, @SecurityId, @EditorId, GETDATE()

    DELETE FROM SecurityCheckboxDisclosures WHERE SecurityId = @SecurityId AND DisclosureId = @DisclosureId
  END
RETURN 0
GO

/*

-- DEBUG

spRenderAuthors 10

spRenderSecurities 7

declare @ct int
exec spSearchSecurityCheckboxDisclosures '2', 'a', 1, 5000, @ct output
select @ct

select * from Securities2 where typeid = 2

select * from SecurityCheckboxDisclosures

sp_helptext spRenderActiveSecurities -- securitytextdisclosures.asp
go

sp_helptext spRenderSecurities
go

sp_helptext spRenderTickers
go

sp_helptext spRenderGetLinkSources -- Indented picklist
go

sp_helptext spSaveSolactiveNote -- Logging
go

select * from AdminLog
--where [Table] = 'Securities'
order by AdminLogId desc

spRenderAuthors 4
GO

DECLARE
  @Disclosure    varchar(2048),
  @Editor        varchar(36),
  @EditDate      datetime
EXEC spGetAuthorTextDisclosures 320, @Disclosure OUTPUT, @Editor OUTPUT, @EditDate OUTPUT
SELECT @Disclosure AS Disclosure, @Editor AS Editor, @EditDate AS EditDate
GO

spRenderActiveSecurities
GO

DECLARE
  @Disclosure    varchar(2048),
  @Editor        varchar(36),
  @EditDate      datetime
EXEC spGetSecurityTextDisclosures 700, @Disclosure OUTPUT, @Editor OUTPUT, @EditDate OUTPUT
SELECT @Disclosure AS Disclosure, @Editor AS Editor, @EditDate AS EditDate
GO

EXEC spSearchSecurityCheckboxDisclosures 1, 'a', 1, 1000, null
GO

-- Overload Authors Fax column to store Broker-Dealer

select Fax, EditDate, * from Authors A
where Fax is not null
order by A.EditDate desc

select Fax, count(*) as Num, min(EditDate), max(EditDate) from Authors group by Fax order by 2

select Fax, EditDate, * from Authors A where Fax = '' order by A.EditDate desc
select Fax, EditDate, * from Authors A where Fax is null order by A.EditDate desc

sp_helptext spSaveAuthor -- passes '' value (via save.aspx)

sp_helptext spLoadAutonomousAuthors  -- no value passed, hence null

Add < brokerDealer="US" > attribute to sql xml

Append to Name

*/
