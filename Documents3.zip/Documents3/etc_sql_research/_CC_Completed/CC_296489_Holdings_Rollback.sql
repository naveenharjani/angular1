-- Holdings_rollback.sql
-- 11/16/2018

/*

drop Holdings
drop vHoldings
drop spDeleteHoldings

*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Holdings]') AND type in (N'U'))
	DROP TABLE [dbo].[Holdings]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE name = 'vHoldings' AND type = 'V')
	DROP VIEW  [dbo].[vHoldings]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spDeleteHoldings]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spDeleteHoldings] 
GO