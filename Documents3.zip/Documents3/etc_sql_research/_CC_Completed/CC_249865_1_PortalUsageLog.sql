-- PortalUsageLog.sql
-- 04/11/2017

/*

PortalUsageLoadLog
spGetPortals
spGetPortalUsageLoadHistory

alter spLoadPortalUsageFromStaging_TR
alter spLoadPortalUsageFromStaging_CIQ
alter spLoadPortalUsageFromStaging_FactSet
alter spLoadPortalUsageFromStaging_Bloomberg

alter load procs to get write to PortalUsageLoadLog table

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE name = 'PortalUsageLoadLog' and TYPE = 'U')
DROP TABLE dbo.PortalUsageLoadLog
GO

CREATE TABLE dbo.PortalUsageLoadLog
(
  PortalUsageLoadLogId int          NOT NULL IDENTITY(1,1),
  SiteId               int          NOT NULL,
  PeriodStart          varchar(10)  NOT NULL,
  PeriodEnd            varchar(10)  NOT NULL,
  RowsLoaded           int          NOT NULL,
  EditorId             int          NOT NULL,
  EditDate             datetime     NOT NULL
)
GO

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE name = 'spGetPortals' and TYPE = 'P')
DROP PROCEDURE dbo.spGetPortals
GO

CREATE PROCEDURE [dbo].[spGetPortals]
AS

SELECT SiteId, Site FROM DistributionSites WHERE SiteId IN (3, 9, 11, 12)

GO

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE name = 'spGetPortalUsageLoadHistory' and TYPE = 'P')
DROP PROCEDURE dbo.spGetPortalUsageLoadHistory
GO

CREATE PROCEDURE [dbo].[spGetPortalUsageLoadHistory]
  @SiteId int = NULL
AS

SELECT TOP 10
  PL.PortalUsageLoadLogId,
  PL.SiteId,
  DS.Site AS Portal,
  PL.PeriodStart,
  PL.PeriodEnd,
  FORMAT(PL.RowsLoaded, '#,##0') AS RowsLoaded,
  U.UserName,
  PL.EditorId,
  PL.EditDate
FROM PortalUsageLoadLog PL
JOIN DistributionSites DS ON DS.SiteId = PL.SiteId
JOIN Users U ON U.UserId = PL.EditorId
WHERE
(
  PL.SiteId = @SiteId
  OR
  (ISNULL(@SiteId, '') = '' AND PL.SiteId in ( SELECT SiteId FROM DistributionSites) )
)

ORDER BY PL.EditDate DESC
GO

GRANT EXECUTE ON spGetPortals    TO PowerUsers, DE_IIS
GRANT EXECUTE ON spGetPortalUsageLoadHistory TO PowerUsers, DE_IIS
GO


ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT

SET @SiteId = 9 -- Thomson Reuters

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_TR) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_TR STG
   WHERE YEAR(PU.ReadDate) = YEAR(STG.[Viewed Date])
   AND MONTH(PU.ReadDate)= MONTH(STG.[Viewed Date])
   AND DAY(PU.ReadDate)  = DAY(STG.[Viewed Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (PubNo, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, FirmType, Delivery)
SELECT
  CASE WHEN ISNUMERIC([Local DocID]) = 1 THEN [Local DocID] ELSE 0 END,
  CASE WHEN ISDATE([Viewed Date]) = 1 THEN [Viewed Date] ELSE NULL END,
  @SiteId,
  [User Email],
  [User Name],
  ISNULL([Unique ID],0),
  [Client Name],
  ISNULL([Client Company ID],0),
  [Client Type],
  [Delivery]
FROM [dbo].[PortalUsageStaging_TR]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Viewed Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Viewed Date] AS DATE) ), 101)
FROM PortalUsageStaging_TR
WHERE ISDATE([Viewed Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for TR from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

INSERT INTO PortalUsageLoadLog
(SiteId, PeriodStart, PeriodEnd, RowsLoaded, EditorId, EditDate)
VALUES (@SiteId,  @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, getdate())

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT

SET @SiteId = 11 -- Capital IQ

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_CIQ) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_CIQ STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Download Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Download Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Download Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, FirmType, Delivery)
SELECT
  [Ctb Doc Id],
  [Download Date],
  @SiteId,
  [Email],
  [User Name],
  [User],
  [Company Name],
  [Company],
  [Firm Type],
  [Activity Type]
FROM [dbo].[PortalUsageStaging_CIQ]
WHERE ISNUMERIC([Ctb Doc Id]) = 1

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Download Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Download Date] AS DATE) ), 101)
FROM PortalUsageStaging_CIQ
WHERE ISDATE([Download Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for CIQ from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

INSERT INTO PortalUsageLoadLog
(SiteId, PeriodStart, PeriodEnd, RowsLoaded, EditorId, EditDate)
VALUES (@SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, getdate())

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT

SET @SiteId = 12 -- Factset

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_FactSet) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_FactSet STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Date/time read])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Date/time read])
   AND DAY(PU.ReadDate) = DAY(STG.[Date/time read])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId)
SELECT
  [Doc ID (contributor)],
  [Date/time read],
  @SiteId,
  [E-mail],
  [Reader name],
  [Reader ID (FactSet)],
  [Firm name],
  [Firm ID (FactSet)]
FROM [dbo].[PortalUsageStaging_FactSet]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Date/time read] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Date/time read] AS DATE) ), 101)
FROM PortalUsageStaging_FactSet
WHERE ISDATE([Date/time read]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for FactSet from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

INSERT INTO PortalUsageLoadLog
(SiteId, PeriodStart, PeriodEnd, RowsLoaded, EditorId, EditDate)
VALUES (@SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, getdate())

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT

SET @SiteId = 3 -- Bloomberg

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_Bloomberg) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_Bloomberg STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId)
SELECT
  CASE WHEN ISNUMERIC([Story Id]) = 1 THEN [Story ID] ELSE 0 END AS StoryId,
  [Read Date],
  @SiteId,
  [Business Email],
  [User Name],
  CASE WHEN ISNUMERIC([UUID]) = 1 THEN [UUID] ELSE NULL END AS UUID,
  [Customer Name],
  [Customer #]
FROM [dbo].[PortalUsageStaging_Bloomberg]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read Date] AS DATE) ), 101)
FROM PortalUsageStaging_Bloomberg
WHERE ISDATE([Read Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Bloomberg from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

INSERT INTO PortalUsageLoadLog
(SiteId, PeriodStart, PeriodEnd, RowsLoaded, EditorId, EditDate)
VALUES (@SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, getdate())

SELECT @RowsLoaded

SET NOCOUNT OFF
END

GO

GRANT EXECUTE ON spResetPortalUsageStaging_TR TO DE_IIS
GRANT EXECUTE ON spResetPortalUsageStaging_CIQ TO DE_IIS
GRANT EXECUTE ON spResetPortalUsageStaging_FactSet TO DE_IIS
GRANT EXECUTE ON spResetPortalUsageStaging_Bloomberg TO DE_IIS

GRANT EXECUTE ON spLoadPortalUsageFromStaging_TR TO DE_IIS
GRANT EXECUTE ON spLoadPortalUsageFromStaging_CIQ TO DE_IIS
GRANT EXECUTE ON spLoadPortalUsageFromStaging_FactSet TO DE_IIS
GRANT EXECUTE ON spLoadPortalUsageFromStaging_Bloomberg TO DE_IIS
GO

/*

-- DEBUG

-- sp_help PortalUsageLoadLog
SELECT * FROM PortalUsageLoadLog ORDER BY PortalUsageLogId DESC

SELECT TOP 1000 * FROM EventLog WHERE Source = 'Portal Usage' ORDER BY Timestamp DESC

spGetPortals

spGetPortalUsageLoadHistory 9  -- Reuters
spGetPortalUsageLoadHistory 3  -- Bloomberg (SANB)
spGetPortalUsageLoadHistory 11 -- CapitalIQ
spGetPortalUsageLoadHistory 12 -- FactSet

select * from PortalUsageLoadLog
select * from PortalUsageLog

*/

/*

SELECT distinct Source  FROM EventLog order by 1
sp_help distributionsites

select * from distributionsites

create 'SCBIS_SSIS' user to execute packages to load portal usage data
-- windows authentication will help, no password needed to execute to execute dtsx
-- Create user/role to run SSIS dtsx package e.g. SCBIS_SSIS, this should have windows authentication.
-- Create service account to logon to server to run dtsx packagesm if needed.
-- not needed
*/

/*
-- test date formats - mm/dd/yyyy

DECLARE
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate  VARCHAR(10)

SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Viewed Date] AS DATETIME) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Viewed Date] AS DATETIME) ), 101)
FROM PortalUsageStaging_TR
WHERE ISDATE([Viewed Date]) = 1

SELECT @PeriodStartDate, @PeriodEndDate

INSERT INTO PortalUsageLoadLog
(SiteId, PeriodStart, PeriodEnd, RowsLoaded, EditorId, EditDate)
VALUES (3, @PeriodStartDate, @PeriodEndDate, 100000, 1229, getdate())

SELECT * FROM PortalUsageLoadLog ORDER BY 1 desc

*/