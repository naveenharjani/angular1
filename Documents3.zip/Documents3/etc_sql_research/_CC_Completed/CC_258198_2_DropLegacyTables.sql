-- DropLegacyTables.sql
-- 08/03/2017

/*


After the Flip Database Views to Estimates db is successful,
Step III - Drop Legacy Tables used by old Publishing engine in TTS schema

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*
Fix sql in sqlxml folders before dropping tables
SQL								Dependent Tables                                           Action
_researchcoverage.sql           MigratedAnalysts, epstypes, metrictypes, analystsettings   Fix
_estimates.sql                  BenchmarkEstimates                                         Drop - Not needed
*/

/*
Check again for any sql object dependency on the legacy tables
found if any, drop the dependent objects

-- Objects dependent on these tables
SELECT * FROM sys.objects where object_id in (SELECT referencing_id FROM sys.sql_expression_dependencies
WHERE referenced_id = OBJECT_ID(N'TickerTableSecurities') OR
      referenced_id = OBJECT_ID(N'TickerTableSecuritiesOld') OR
      referenced_id = OBJECT_ID(N'TickerTableSecurities_Backup') OR
      referenced_id = OBJECT_ID(N'TickerTables') OR
      referenced_id = OBJECT_ID(N'TickerSheetSecurities') OR
      referenced_id = OBJECT_ID(N'TickerSheetSecurities_backup') OR
      referenced_id = OBJECT_ID(N'TickerSheets') OR
      referenced_id = OBJECT_ID(N'Footnotes') OR
      referenced_id = OBJECT_ID(N'FootnotesRef') OR
      referenced_id = OBJECT_ID(N'AnalystSettings') OR
      referenced_id = OBJECT_ID(N'AnalystSettingsLog') OR
      referenced_id = OBJECT_ID(N'BenchmarkEstimates') OR
      referenced_id = OBJECT_ID(N'BenchmarkEstimatesLog') OR
      referenced_id = OBJECT_ID(N'EpsTypes') OR
      referenced_id = OBJECT_ID(N'MetricsTypes') OR
      referenced_id = OBJECT_ID(N'EstimatesPeriods') OR
      referenced_id = OBJECT_ID(N'MigratedAnalysts')
) ORDER BY 1
*/

/*
please ensure backup legacy tables data as .dat files was done as in previous step
*/

/*
-- Drop tables used by old UI or legacy publishing engine or new estimates not anymore

View Table dependencies Drop Tables in the listed order, as per the table dependencies

EstimatesPeriods, EpsTypes, MetricsTypes
TickerSheetData, -- remains
TickerSheetSecurities, TickerSheets
FootnoteRefs, Footnotes, TickerTableSecuritiesOld, TickerTableSecurities, TickerTables
BenchmarkEstimates, BenchmarkEstimatesLog
AnalystSettings, AnalystSettingsLog
MigratedAnalysts

-- delete old backup tables
TickerTableSecurities_Backup, TickerSheetSecurities_backup

*/

/* EstimatesPeriods, EpsTypes, MetricsTypes */

/* EstimatesPeriods */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FK_BenchmarkEstimates_EstimatePeriods]') and OBJECTPROPERTY(object_id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[BenchmarkEstimates]  DROP CONSTRAINT [FK_BenchmarkEstimates_EstimatePeriods]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FK_AnalystSettings_EstimatePeriods]') and OBJECTPROPERTY(object_id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[AnalystSettings]  DROP CONSTRAINT [FK_AnalystSettings_EstimatePeriods]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EstimatesPeriods]') AND type in (N'U'))
DROP TABLE [dbo].[EstimatesPeriods]
GO

/* EpsTypes */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FK_AnalystSettings_EpsTypes]') and OBJECTPROPERTY(object_id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[AnalystSettings] DROP CONSTRAINT [FK_AnalystSettings_EpsTypes]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EpsTypes]') AND type in (N'U'))
DROP TABLE [dbo].[EpsTypes]
GO

/* MetricsTypes */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FK_AnalystSettings_MetricsTypes]') and OBJECTPROPERTY(object_id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[AnalystSettings] DROP CONSTRAINT [FK_AnalystSettings_MetricsTypes]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MetricsTypes]') AND type in (N'U'))
DROP TABLE [dbo].[MetricsTypes]
GO

/* TickerSheetData, TickerSheetSecurities, TickerSheets */
/*
-- TickerSheetData - remains
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerSheetData]') AND type in (N'U'))
--DROP TABLE [dbo].[TickerSheetData]
--GO
*/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerSheetSecurities]') AND type in (N'U'))
DROP TABLE [dbo].[TickerSheetSecurities]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerSheets]') AND type in (N'U'))
DROP TABLE [dbo].[TickerSheets]
GO

/* FootnotesRefs, Footnotes, TickerTableSecuritiesOld, TickerTableSecurities, TickerTables */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FootnoteRefs]') AND type in (N'U'))
DROP TABLE [dbo].[FootnoteRefs]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Footnotes]') AND type in (N'U'))
DROP TABLE [dbo].[Footnotes]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerTableSecuritiesOld]') AND type in (N'U'))
DROP TABLE [dbo].[TickerTableSecuritiesOld]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerTableSecurities]') AND type in (N'U'))
DROP TABLE [dbo].[TickerTableSecurities]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerTables]') AND type in (N'U'))
DROP TABLE [dbo].[TickerTables]
GO

/* BenchmarkEstimates, BenchmarkEstimatesLog */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BenchmarkEstimates]') AND type in (N'U'))
DROP TABLE [dbo].[BenchmarkEstimates]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BenchmarkEstimatesLog]') AND type in (N'U'))
DROP TABLE [dbo].[BenchmarkEstimatesLog]
GO

/* AnalystSettings, AnalystSettingsLog */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AnalystSettings]') AND type in (N'U'))
DROP TABLE [dbo].[AnalystSettings]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AnalystSettingsLog]') AND type in (N'U'))
DROP TABLE [dbo].[AnalystSettingsLog]
GO

/* MigratedAnalysts */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MigratedAnalysts]') AND type in (N'U'))
DROP TABLE [dbo].[MigratedAnalysts]
GO

/* TickerTableSecurities_Backup, TickerSheetSecurities_backup (delete old backup tables) */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerTableSecurities_Backup]') AND type in (N'U'))
DROP TABLE [dbo].[TickerTableSecurities_Backup]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TickerSheetSecurities_backup]') AND type in (N'U'))
DROP TABLE [dbo].[TickerSheetSecurities_backup]
GO


/*
SELECT * FROM EstimatesPeriods
SELECT * FROM EpsTypes
SELECT * FROM MetricsTypes
--SELECT * FROM TickerSheetData
SELECT * FROM TickerSheetSecurities
SELECT * FROM TickerSheets
SELECT * FROM FootnoteRefs
SELECT * FROM Footnotes
SELECT * FROM TickerTableSecuritiesOld
SELECT * FROM TickerTableSecurities
SELECT * FROM TickerTables
SELECT * FROM BenchmarkEstimates
SELECT * FROM BenchmarkEstimatesLog
SELECT * FROM AnalystSettings
SELECT * FROM AnalystSettingsLog
SELECT * FROM MigratedAnalysts
SELECT * FROM TickerTableSecurities_Backup
SELECT * FROM TickerSheetSecurities_backup

--IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_BenchmarkEstimates_EstimatePeriods]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FK_BenchmarkEstimates_EstimatePeriods]')

*/
