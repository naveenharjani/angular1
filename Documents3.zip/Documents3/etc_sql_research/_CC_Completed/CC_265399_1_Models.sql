-- CC_Models.sql
-- 09/18/2017

/*

ModelActions
ModelStates
Models
vModels
vModelsLatest
spDeletePublication
spSaveModel
spDeleteModel
spGetModels
spGetModelChangeToolTip
spCheckForCorrections
spGetModelFilePath
spSearchData

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where name = 'FK_Models_ModelStates' and type = 'F')
alter table [dbo].[Models] drop constraint [FK_Models_ModelStates]
go
if exists(select * from sys.objects where name = 'FK_Models_ModelActions' and type = 'F')
alter table [dbo].[Models] drop constraint [FK_Models_ModelActions]
go

if exists(select * from sys.objects where name = 'Models')
  drop table dbo.Models
go
  create table dbo.Models
  (
    ModelId      int          not null,
    CoverageId   int          not null,
    SecurityId   int          not null,
    AnalystId    int          not null,
    FileName     varchar(30)  not null,
    FileNameOrig varchar(100)     null,
    FileSize     int          not null,
    ActionId     int          not null,
    StateId      int          not null,
    PubNo        int              null,
    EditorId     int          not null,
    EditDate     datetime     not null
  )
alter table [dbo].[Models] add constraint [PK_Models] primary key clustered([ModelId] ASC)
go

if exists(select * from sys.objects where name = 'ModelStates')
drop table ModelStates
go

create table dbo.ModelStates
(
StateId    int          not null,
State      varchar(100) not null,
EditorId   int          not null,
EditorDate datetime     not null
)
alter table [dbo].[ModelStates] add constraint [PK_ModelStates] primary key clustered([StateId] ASC)
go

alter table [dbo].[Models] with check add constraint [FK_Models_ModelStates] foreign key(StateId)
references[dbo].[ModelStates]([StateId])
go

/*

insert into ModelStates(StateId,State,EditorId,EditorDate) select 1,'Active',  1126,getdate()
insert into ModelStates(StateId,State,EditorId,EditorDate) select 2,'Archived',1126,getdate()
insert into ModelStates(StateId,State,EditorId,EditorDate) select 3,'Deleted', 1126,getdate()

select * from ModelStates

*/

if exists(select * from sys.objects where name = 'ModelActions')
drop table ModelActions
go

create table dbo.ModelActions
(
ActionId   int          not null,
Action     varchar(100) not null,
EditorId   int          not null,
EditorDate datetime     not null
)
alter table [dbo].[ModelActions] add constraint [PK_ModelActions] primary key clustered([ActionId] ASC)
go

alter table [dbo].[Models] with check add constraint [FK_Models_ModelActions] foreign key(ActionId)
references[dbo].[ModelActions]([ActionId])
go

/*

insert into ModelActions(ActionId,Action,EditorId,EditorDate) select 1,'Updated (Rating, Target or EPS estimates)',1126,getdate()
insert into ModelActions(ActionId,Action,EditorId,EditorDate) select 2,'Updated (Non-EPS estimates)',1126,getdate()
insert into ModelActions(ActionId,Action,EditorId,EditorDate) select 3,'Updated (Actuals)',1126,getdate()
insert into ModelActions(ActionId,Action,EditorId,EditorDate) select 4,'Replaced',1126,getdate()

*/
if exists(select * from sys.objects where name = 'ModelDeletions')
drop table ModelDeletions
go

create table dbo.ModelDeletions
(
ModelId   int          not null,
EditorId  int          not null,
EditDate  datetime     not null
)
alter table [dbo].[ModelDeletions] add constraint [PK_ModelDeletions] primary key clustered([ModelId] ASC)
go

/*alter table [dbo].[Models] with check add constraint [FK_Models_ModelDeletions] foreign key(ModelId)
references[dbo].[ModelDeletions]([ModelId])*/
go

alter proc dbo.spSaveModel (@ModelId int, @SecurityId int, @CoverageId int, @PubNo int, @FileName varchar(30), @FileNameOrig varchar(100), @FileSize int, @ActionId int, @UserName varchar(10))
as
begin try
  begin transaction

  declare @PrimarySecurityId int
  declare @AnalystId int
  declare @UserId int

  if @UserName is null or @UserName = ''
  select @UserId = 0
  else
  select top 1 @UserId = UserId from Users where UserName like '%' + @UserName+ '%'

  select @PrimarySecurityId = SecurityId from Securities2
  where CompanyId = (select CompanyId from Securities2 where SecurityId = @SecurityId)
  and IsPrimary = 'Y'

  select @AnalystId = AnalystId from ResearchCoverage where CoverageId = @CoverageId

  update Models
  set StateId = 2
  from Models M
  where SecurityId = @PrimarySecurityId and StateId = 1

  insert into Models(ModelId,CoverageId,AnalystId,SecurityId,PubNo,FileName,FileNameOrig,FileSize,ActionId,StateId,EditorId,EditDate)
  select
    @ModelId,
    @CoverageId,
    @AnalystId,
    @PrimarySecurityId,
    @PubNo,
    @FileName,
    @FileNameOrig,
    @FileSize,
    @ActionId,
    1,
    @UserId,
    getdate()
  select 0 ReturnValue
  commit
end try
begin catch
    if @@TRANCOUNT > 0
      rollback
    -- Raise an error with the details of the exception
    declare @ErrMsg nvarchar(4000), @ErrSeverity int
    select @ErrMsg = ERROR_MESSAGE(), @ErrSeverity = ERROR_SEVERITY()

    select -1 ReturnValue
    raiserror(@ErrMsg, @ErrSeverity, 1)
end catch
go

alter procedure [dbo].[spDeleteModel]
  @ModelId        int,
  @EditorId       int
AS
begin try
  begin tran
  update Models set StateId = 3 where ModelId = @ModelId

  if not exists(select * from ModelDeletions where ModelId = @ModelId)
  begin
    insert into ModelDeletions(ModelId, EditorId, EditDate)
    select @ModelId, @EditorId, getdate()
  end

  select 0 ReturnValue
  commit tran
end try
begin catch
  if @@trancount > 0
  rollback
    -- Raise an error with the details of the exception
    declare @ErrMsg nvarchar(4000), @ErrSeverity int
    select @ErrMsg = ERROR_MESSAGE(), @ErrSeverity = ERROR_SEVERITY()

    select -1 ReturnValue
    raiserror(@ErrMsg, @ErrSeverity, 1)
end catch
go

alter procedure [dbo].[spGetModels]
  @Type           int,  --0 - Latest, 1 - All
  @OrderBy        varchar(100),
  @OrderType      varchar(4),
  @SearchCriteria varchar(1000)
as
begin
  declare @sql varchar(8000)

  if @OrderBy = ''
  begin
    set @OrderBy = 'Company,ModelId desc'
  end
  else
  begin
  if @OrderBy = 'Analyst'      set @OrderBy = @OrderBy + ' ' + @OrderType + ', Company,ModelId desc'
    else if @OrderBy = 'Ticker'       set @OrderBy = @OrderBy + ' ' + @OrderType + ', ModelId desc'
    else if @OrderBy = 'Company'      set @OrderBy = @OrderBy + ' ' + @OrderType + ', ModelId desc'
    else set @OrderBy = @OrderBy + ' ' + @OrderType + ', Company,ModelId desc'
  end
  set @sql = 'set nocount on '  +
              'declare @Counter int select @Counter = Value from Counters where Name = ''ModelNo'' ' +
              'select RegionId,' +
              'Region,' +
              'Analyst,' +
              'AnalystId,' +
              'Ticker,' +
              'SecurityId,' +
              'Company,' +
              'ModelId,' +
              'CoverageId,' +
              'FileName ModelFileName,' +
              'FileName,' +
              'PubNo,' +
              'ReportFileName,' +
              'Title,' +
              'round(convert(float,FileSize)/1000000,1) Filesize,' +
              'FileType,' +
              'ActionId,' +
              'Action,' +
              'StateId,' +
              'State Status,' +
              'dateadd(mi,datediff(mi,getdate(),getutcdate()),editdate) EditDateUTC, ' +
              'EditDate, ' +
              'DeletedByUser, ' +
              'dateadd(mi,datediff(mi,getdate(),getutcdate()),DeletedDate) DeletedDateUTC, ' +
              'DeletedDate '
  if @Type = 0
  set @sql =  @sql + 'from vModelsLatest '
  else
  set @sql =  @sql + 'from vModels '

  if @SearchCriteria <> '' set @sql = @sql + ' where ' + @SearchCriteria + ' '

  set @sql = @sql + ' order by ' + @OrderBy
  print(@sql)
  exec(@sql)
end
go

alter view dbo.vModels
as
  select
    M.ModelId,
    RC.CoverageId,
    RC.SecurityId,
    S.Ticker,
    S.CompanyId,
    S.Company,
    RC.AnalystId,
    A.Last + ', ' + A.First Analyst,
    AR.RegionId,
    AR.Region,
    M.FileName,
    substring(M.FileName,charindex('.',M.FileName) + 1,10) FileType,
    M.FileSize,
    M.ActionId,
    case when PF.RatingAction = 'Initiate' then 'Coverage Initiation' else MA.Action end Action,
    case when RC.ModelDistribution = 'Y' then M.StateId else 0 end StateId,
    case when RC.ModelDistribution = 'N' then 'Excluded' when M.StateId = 3 then 'Deleted' else MS.State end State,

    -- Model details when promoted by change report
    M.PubNo,
    P.Title,
    P.FileName ReportFileName,
    PF.Rating,
    PF.RatingPrior,
    PF.RatingAction,
    PF.TargetPrice,
    PF.TargetPricePrior,
    PF.TargetPriceAction,
    PF.BaseYear,
    PF.EPSFY1,
    PF.EPSFY1Prior,
    PF.EPSFY1Action,
    PF.EPSFY2,
    PF.EPSFY2Prior,
    PF.EPSFY2Action,
    M.EditorId,
    M.EditDate,
    U.UserName DeletedByUser,
    MD.EditDate DeletedDate
  from ResearchCoverage RC
  join Securities2 S on S.SecurityId = RC.SecurityId and S.IsPrimary = 'Y'
  join Authors A on A.AuthorId = RC.AnalystId
  left outer join AuthorRegions AR on AR.RegionId = A.RegionId
  left outer join Models M on M.SecurityId = RC.SecurityId and M.AnalystId = RC.AnalystId
  left outer join ModelStates MS on MS.StateId = M.StateId
  left outer join ModelActions MA on MA.ActionId = M.Actionid
  left outer join PublicationFinancials PF on M.PubNo = PF.PubNo and M.SecurityId = PF.SecurityId
  left outer join Publications P on M.PubNo = P.Pubno
  left outer join ModelDeletions MD on M.ModelId = MD.ModelId
  left outer join Users U on MD.EditorId = U.UserId
  where  RC.LaunchDate is not null and RC.DropDate is null
go

alter view dbo.vModelsLatest
as
  select
    V2.ModelId,
    RC.CoverageId,
    RC.SecurityId,
    S.Ticker,
    S.CompanyId,
    S.Company,
    RC.AnalystId,
    A.Last + ', ' + A.First Analyst,
    AR.RegionId,
    AR.Region,
    V2.FileName,
    substring(V2.FileName,charindex('.',V2.FileName) + 1,10) FileType,
    V2.FileSize,
    V2.ActionId,
    case when (RC.ModelDistribution = 'N' or V2.StateId = 3) then '' when PF.RatingAction = 'Initiate' then 'Coverage Initiation' else MA.Action end Action,
    case when RC.ModelDistribution = 'Y' then V2.StateId else 0 end StateId,
    case when RC.ModelDistribution = 'N' then 'Not Available' when V2.StateId = 3 then 'Not Available' else MS.State end State,
    -- Model details when promoted by change report
    V2.PubNo,
    P.Title,
    P.FileName ReportFileName,
    PF.Rating,
    PF.RatingPrior,
    PF.RatingAction,
    PF.TargetPrice,
    PF.TargetPricePrior,
    PF.TargetPriceAction,
    PF.BaseYear,
    PF.EPSFY1,
    PF.EPSFY1Prior,
    PF.EPSFY1Action,
    PF.EPSFY2,
    PF.EPSFY2Prior,
    PF.EPSFY2Action,
    V2.EditorId,
    case when (RC.ModelDistribution = 'N' or V2.StateId = 3) then null else V2.EditDate end EditDate,
    '' DeletedByUser,
    '' DeletedDate
  from ResearchCoverage RC
  join Securities2 S on S.SecurityId = RC.SecurityId and S.IsPrimary = 'Y'
  join Authors A on A.AuthorId = RC.AnalystId
  left outer join AuthorRegions AR on AR.RegionId = A.RegionId
  left outer join
    -- Latest models
    (select M1.* from Models M1 join
      -- Latest model ids
      (select M2.SecurityId, M2.AnalystId, max(ModelId) ModelId
       from Models M2 join ResearchCoverage RC2 on M2.SecurityId = RC2.SecurityId and M2.AnalystId = RC2.AnalystId
       where RC2.LaunchDate is not null and RC2.DropDate is null
       group by M2.SecurityId, M2.AnalystId)
     V on M1.ModelId = V.ModelId)
   V2 on V2.SecurityId = RC.SecurityId and V2.AnalystId = RC.AnalystId
  left outer join ModelStates MS on MS.StateId = V2.StateId
  left outer join ModelActions MA on MA.ActionId = V2.Actionid
  left outer join PublicationFinancials PF on V2.PubNo = PF.PubNo and V2.SecurityId = PF.SecurityId
  left outer join Publications P on V2.PubNo = P.Pubno
  where  RC.LaunchDate is not null and RC.DropDate is null
go

alter procedure [dbo].[spDeletePublication]
  @PubNo         int,
  @Operation     char(1),
  @EditorId      int,
  @Numdeleted    int OUTPUT
AS
declare @AuditNo int

-- PREVENT PHANTOM deleteS (from STALE BROWSER) BY ONLY PROCESSING FIRST delete REQUEST
if NOT EXISTS(select * from Publications where PubNo = @PubNo)
  begin
    select @Numdeleted = 0 -- return OUTPUT PARAMETERS
    return
  end

-- return ROWset
select FileName from Documents where PubNo = @PubNo

delete from ProductGroupDocuments       where PubNo = @PubNo
delete from RelatedPublications         where PubNo = @PubNo
if @Operation = 'D' --delete from FinancialNumbers only if "delete" invoked from research dashboard and not report resubmits
begin
  delete from PublicationFinancialNumbers where PubNo = @PubNo
  delete from PublicationFinancials       where PubNo = @PubNo
  delete from FinancialNumbers            where PubNo = @PubNo
  --update model status to deleted if this publication promoted any models to live
  if EXISTS(select * from Models where PubNo = @PubNo)
  begin
  update Models set StateId = 3 where PubNo = @PubNo AND StateId = 1
  end
end

-- RVdeletedDocuments replicated view uses the logs below for pdf cache control on BR.com
insert into AuditLog (Operation, EditorId, EditDate) VALUES (@Operation, @EditorId, GETDATE())
select @AuditNo = @@IDENTITY

insert into PublicationsLog (AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate)
select @AuditNo, PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorId, EditDate from Publications where PubNo = @PubNo

insert into DocumentsLog (AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig)
select @AuditNo, PubNo, DocNo, DocType, FileName, FileNameOrig from Documents where PubNo = @PubNo

insert into PropertiesLog (AuditNo, PubNo, PropNo, PropId, PropValue)
select @AuditNo, PubNo, PropNo, PropId, PropValue from Properties where PubNo = @PubNo

delete from Properties   where PubNo = @PubNo
delete from Documents    where PubNo = @PubNo
delete from Publications where PubNo = @PubNo

select @Numdeleted = @@ROWCOUNT -- return OUTPUT PARAMETERS
go

alter procedure [dbo].[spRollbackEstimates]
  @PubNo int,
  @SecurityId int,
  @EditorId int
as
begin try
  begin transaction
    --only one set of reports(with same source pubno) can be in correction mode at any time
    --reject if the prior set is not completed/cancelled
    if exists(select * from CorrectionQueue where status in ('Required','Optional') and SourcePubNo <> @PubNo)
    begin
        select -3 returnValue
        commit
        return
    end

    --if a report is already scheduled to be published for this ticker
    --prevent from doing a rollback
    declare @Qid int, @DXml xml, @hDoc int
    select top 1 @Qid = QueueId,@DXml = DocumentXml from PublicationQueue where ProcessStatus = 'Scheduled' order by QueueId

    while @@ROWCOUNT = 1
    begin
      exec sp_xml_preparedocument @hDoc output, @DXml

      if exists
      (select X.SecurityId,X.Ticker,X.IndicateChange
      from openxml (@hDoc, 'DocumentInfo/Securities/Security', 1)
      with (securityId      int         '@id',
            ticker          varchar(30) '@ticker',
            indicateChange  varchar(10) '@indicateChange'
            ) X
      where X.SecurityId = @SecurityId)
      begin
        select -2 returnValue
        commit
        return
      end

      exec sp_xml_removedocument @hDoc
      select top 1 @Qid = QueueId,@DXml = DocumentXml from PublicationQueue where ProcessStatus = 'Scheduled' AND QueueId > @Qid order by QueueId
    end
    --check to see if report exists in publicationxml table (new system)
    if exists(select PubNo from PublicationsXml where PubNo = @PubNo)
    begin

      declare @CurrentDate datetime
      declare @Ticker varchar(30)
      declare @UserName varchar(36)

      set @CurrentDate = GETDATE()
      select @Ticker = Ticker from Securities2 where SecurityId = @SecurityId
      select @UserName = UserName from Users where UserId = @EditorId

      --delete any pending drafts
      delete from FinancialNumbers where SecurityId = @SecurityId and IsDraft = 1

      --revert the latest live numbers to draft state
      delete PublicationFinancialNumbers
      from PublicationFinancialNumbers PFN
      join FinancialNumbers FN on PFN.FinancialNumberId = FN.FinancialNumberId
      where FN.SecurityId = @SecurityId
      and FN.PubNo = @PubNo
      and FN.IsDraft = 0

      update FinancialNumbers
      set IsDraft = 1, PubNo = null, Date = @currentdate
      where SecurityId = @SecurityId
      and PubNo = @PubNo
      and IsDraft = 0

      --update model status to deleted if this publication promoted any models to live
    if exists(select * from Models where PubNo = @PubNo)
    begin
    update Models set StateId = 3 where PubNo = @PubNo and StateId = 1
      end

      --Determine the covering analyst for the rollback ticker
      declare @AnalystId int
      select @AnalystId = AnalystId from ResearchCoverage where SecurityId  = @SecurityId and LaunchDate is not null and DropDate is null

      --insert into CorrectionQueue table for source report
      insert into CorrectionQueue(PubNo,SecurityId,AnalystId,SourcePubNo,IsSource,CorrectionMode,Queued,QueuedBy,Status,EditorId,EditDate)
      select @PubNo,@SecurityId,@AnalystId,@PubNo,1,0,@CurrentDate,@EditorId,'Required',@EditorId,@CurrentDate

      --Retrieve dependent publication numbers
      select PubNo
      into #TmpDependentPublications
      from Properties PR
      join PropertyNames PN on PR.PropId = PN.PropId
      where PN.PropName = 'Ticker'
      and PR.PropValue = (select Ticker from Securities2 where SecurityId = @SecurityId)
      and PR.PubNo > @PubNo

      --insert into CorrectionQueue table for all dependent publications
      insert into CorrectionQueue(PubNo,SecurityId,AnalystId,SourcePubNo,IsSource,CorrectionMode,Queued,QueuedBy,Status,EditorId,EditDate)
      select PubNo,@SecurityId,@AnalystId,@PubNo,0,0,@CurrentDate,@EditorId,'Optional',@EditorId,@CurrentDate
      from #TmpDependentPublications


      exec spRestoreMarketData @PubNo, @SecurityId, @EditorId

    end
  select 0 returnValue
 commit
end try
begin catch
  if @@trancount > 0
    rollback
    --raise an error with the details of the exception
    declare @errmsg nvarchar(4000), @errseverity int
    select @errmsg = ERROR_MESSAGE(),
            @errseverity = ERROR_SEVERITY()
    select -1 returnValue
    Raiserror(@errmsg,@errseverity,1)
end catch
go

if exists(select * from sys.objects where name = 'spGetModelChangeToolTip' and type = 'P')
drop proc dbo.spGetModelChangeToolTip
go

create procedure dbo.spGetModelChangeToolTip
@ModelId int
as
begin
select top 1
    Rating,
    RatingPrior,
    RatingAction,
    format(cast(TargetPrice AS money), '#,###0.#0;(#,###0.#0)')TargetPrice,
    format(cast(TargetPricePrior AS money), '#,###0.#0;(#,###0.#0)')TargetPricePrior,
    TargetPriceAction,
    format(cast(cast(TargetPrice as  float) - cast(TargetPricePrior as  float) AS money), '#,###0.#0;(#,###0.#0)') TargetPriceDelta,
    format(cast(EPSFY1 AS money), '#,###0.#0;(#,###0.#0)')EPSFY1,
    format(cast(EPSFY1Prior AS money), '#,###0.#0;(#,###0.#0)') EPSFY1Prior,
    EPSFY1Action,
    format(cast(cast(EPSFY1 as  float) - cast(EPSFY1Prior as  float) AS money), '#,###0.#0;(#,###0.#0)') EPSFY1Delta,
    format(cast(EPSFY2 AS money), '#,###0.#0;(#,###0.#0)')EPSFY2,
    format(cast(EPSFY2Prior AS money), '#,###0.#0;(#,###0.#0)')EPSFY2Prior,
    EPSFY2Action,
    format(cast(cast(EPSFY2 as  float) - cast(EPSFY2Prior as  float) AS money), '#,###0.#0;(#,###0.#0)') EPSFY2Delta,
    BaseYear+1 as EPSFY1Label,
    BaseYear+2 as EPSFY2Label
from vModels
where ModelId = @ModelId
end
go

if exists(select * from sys.objects where name = 'spCheckForCorrections' and type = 'P')
drop proc dbo.spCheckForCorrections
go

create procedure dbo.spCheckForCorrections
  @PubNo int,
  @SecurityId int
as
begin
if exists(select * from CorrectionQueue where SourcePubNo = @PubNo and SecurityId = @SecurityId)
  select 1 status
else
  select 0 status
end
go

if exists(select * from sys.objects where name = 'spGetModelFilePath' and type = 'P')
drop proc dbo.spGetModelFilePath
go

create procedure dbo.spGetModelFilePath @SecurityId int
as
begin
  select top 1 TickerSheetSubmitXml.value('(/Security/@originalFilePath)[1]', 'varchar(100)') as FilePath
  from TickerSheetData
  where SecurityId = @SecurityId
  order by EditDate desc
end
go

-- =================================================================================================
-- Author:       Sandarsh M S
-- Revisions:    08/04/2016 - Created
-- 08/29/2017 -  Added filter to remove unlaunched tickers which were not covered previously.
-- 10/25/2017 -  Added search in Models feature
-- Description:  Get Typeahead data for a given @SearchText
-- =================================================================================================
alter procedure [dbo].[spSearchData]
  @Style int,
  @UserId int,
  @SearchText nvarchar(200),
  @SearchTextComp nvarchar(200)

as
begin

Set @SearchText = '%'+ @SearchText+'%'
Set @SearchTextComp = '%'+ @SearchText+'%'


declare @Analyst table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL,
  Header int NULL
 )

insert into @Analyst
select top 10
  Name as Label,
  Name as Ticker,
  'Analyst' as Groups,
  Row_Number() OVER (ORDER BY [Name]) +3  AS Header
from Authors where IsAnalyst = -1 and (First like @SearchText or Last like @SearchText or [Name] like @SearchText)
AND AuthorId in (select  Distinct AnalystID from ResearchCoverage) order by [Name]

declare @Ticker table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL
 )
 declare @DroppedTicker table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL
 )


insert into @Ticker
select distinct top (18 - (select Count(*) from @Analyst))
  Ticker + ' / ' + Company as Label,
  Ticker,
  'Research' as Groups
from Securities2 S
join ResearchCoverage RC on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null AND RC.DropDate is null
and (Ticker like @SearchText or  Company like @SearchTextComp)
order by Ticker + ' / ' + Company


insert into @DroppedTicker
select distinct top (26 - (select Count(*) from @Ticker))
  Ticker + ' / ' + Company as Label,
  Ticker,
  'Dropped' as Groups
from Securities2 S
join ResearchCoverage RC on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null  AND RC.DropDate is not null
and s.Ticker not in (select distinct ticker from @Ticker)
and (Ticker like @SearchText or  Company like @SearchTextComp)
order by Ticker + ' / ' + Company

declare @Financials table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL
 )

insert into @Financials
select
  S.Ticker + ' / ' +  S.Company as Label,
  Ticker,
  'Financials' as Groups
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null AND RC.DropDate is null and s.Ticker = (select top 1 Ticker from (select top 1 Ticker from @Ticker union select top 1 Ticker from @DroppedTicker) a)
and RC.AnalystId in (select AuthorId from Authors where IsAnalyst = -1 AND IsActive = -1)
order by S.Ticker + ' / ' + S.Company

declare @Model table
(
  Label  varchar(100) NULL,
  Ticker varchar(50) NULL,
  Groups varchar(50) NULL
 )

insert into @Model
Select
  S.Ticker + ' / ' +  S.Company as Label,S.Ticker,'Models' as Groups
from ResearchCoverage RC
join Securities2 S on RC.SecurityId = S.SecurityId
join Models M on S.SecurityId = M.SecurityId
join ModelStates MS on M.StateId = MS.StateId
where MS.State = 'Active' and S.Ticker = (select top 1 Ticker from (select top 1 Ticker from @Ticker union select top 1 Ticker from @DroppedTicker) a)
 AND RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL

/*
 Select
  S.Ticker + ' / ' +  S.Company as Label,S.Ticker,'Models' as Groups
FROM vModelsLatest RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
WHERE  S.Ticker = (select top 1 Ticker from (select top 1 Ticker from @Ticker union select top 1 Ticker from @DroppedTicker) a) -- AND RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
order by S.Ticker + ' / ' + S.Company
*/
--DECLARE @Charts TABLE
--(
--  Label  varchar(100) NULL,
--  Ticker varchar(50) NULL,
--  Groups varchar(50) NULL
-- )

-- INSERT INTO @Charts
-- Select
--  S.Ticker + ' / ' +  S.Company as Label,Ticker,'Charts' as Groups
--FROM ResearchCoverage RC
--JOIN Securities2 S on S.SecurityId = RC.SecurityId
--WHERE  S.Ticker = (Select top 1 Ticker from @Ticker) AND RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
--order by S.Ticker + ' / ' + S.Company

select *, ROW_NUMBER() over(partition by Ticker
order by Groups desc) AS Header
from (
select * from @Ticker
union
select * from @DroppedTicker
union
select * from @Financials
union
select * from @Model
--union
--select * from @Charts
) as uni
union All
select * from @Analyst
End
go

grant execute on dbo.spDeleteModel to DE_IIS, PowerUsers
grant execute on dbo.spGetModelChangeToolTip to DE_IIS, PowerUsers
grant execute on dbo.spCheckforCorrections to DE_IIS, PowerUsers
grant execute on dbo.spGetModelFilePath to DE_IIS, PowerUsers
go

/*

select * from ModelActions
select * from ModelStates
select * from Models order by ModelId desc
select * from vModels
select * from vModelsLatest
where securityid = 1060

select * from Models order by ModelId desc
select Max(ModelId) from Models group by SecurityId
select * from researchcoverage where launchdate is not null and dropdate is null and securityid is not null and DistributionEligible = 1
spGetModels 1,'EditDate','desc','ticker=''2883.hk'''
spGetModels 1,'EditDate','desc','authorid=506'
select * from vModelsLatest  where ticker = '2883.hk'
select * from authors where last like '%anderson%'

select * from vModelsLatest
where filesize is not null
spGetModels 0,'EditDate','desc','analystid=431'
spGetModels 0,'EditDate','desc','ticker=''2883.hk'''

select top 2 * from publicationfinancials order by pubno desc
spGetModelChangeToolTip
spGetModels 0,'','',''
spGetModels 1,'','',''
*/

