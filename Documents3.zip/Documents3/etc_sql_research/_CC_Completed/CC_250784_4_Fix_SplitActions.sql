-- FixSplitActions.sql
-- 05/11/2017

ALTER TABLE SplitActions ALTER COLUMN AdjustmentFactor decimal(15, 6) NULL
GO
 
-- ==========================================================================================================================
-- Author:		Naveen Harjani
-- Create date: March 26, 2008
-- Description: Insert into SplitActions Table from BloombergSplitHistory Table.
--				This procedure will check the Bloomberg Load Table BloombergSplitHistory and insert all records into the 
--				Split Actions AppliedStatus Table that were previsouly not inserted into the AppliedStatus table.
--
-- Revisions:
-- Change date: October 2, 2008
-- Description: The join between BloombergSplitHistory & Securities2 table can now be directly by TICKER column,
--              not the SUBSTRING(B.TICKER, 1, CHARINDEX(' ', B.TICKER) - 1) as was previously used for bcp process
-- ===========================================================================================================================

ALTER PROCEDURE [dbo].[spInsertSplitActions]
AS
BEGIN
SET NOCOUNT ON

BEGIN TRANSACTION

--Declare a AppliedStatus Variable
DECLARE @YearSinceData int
SET @YearSinceData = 2000   --Year since the data to be copied[SELECT/INSERT] into SplitActions Table from BloombergSplitHistory Table.

DECLARE @AppliedStatus char(1)
SET @AppliedStatus = 'N'             --Store the AppliedStatus at Load into Split Actions Table

DECLARE @DaysToLoad int
SET @DaysToLoad = 15        --Get only the last 15 days data

DECLARE @DateLoaded datetime
SET @DateLoaded = getdate()  --Get the system date to load the inserted records with

-- Create Bloomberg Load temp table and insert all valid data prior to the load process
CREATE TABLE ##BloomSplitTemp
	( Ticker  varchar(50),
	  SecurityID int,
	  EffectiveDate datetime,
	  AdjustmentFactor decimal(15,6),
      LoadDate datetime)

INSERT INTO ##BloomSplitTemp
(Ticker, SecurityID, EffectiveDate, AdjustmentFactor, LoadDate)
--Get Distinct List for a Ticker/SplitDate/AdjustmentFactor
SELECT DISTINCT S.TICKER, S.SecurityID, 
	   CAST(B.EQY_SPLIT_EX_DT AS datetime) AS EQY_SPLIT_EX_DT,
	   CAST(B.EQY_SPLIT_ADJUSTMENT_FACTOR AS decimal(15,6)) AS EQY_SPLIT_ADJUSTMENT_FACTOR, 
       B.LoadDate
	FROM   dbo.BloombergSplitHistory B, Securities2 S
	WHERE  S.TICKER = B.TICKER
	--WHERE  S.TICKER = SUBSTRING(B.TICKER, 1, CHARINDEX(' ', B.TICKER) - 1)  --previously used by bcp process
 	  --AND  DATEPART(year, CAST(B.EQY_SPLIT_EX_DT AS datetime)) >= @YearSinceData   --Get records since Year specified [2000]
      AND  (ISNUMERIC(B.EQY_SPLIT_ADJUSTMENT_FACTOR) = 1) AND (ISDATE(B.EQY_SPLIT_EX_DT) = 1)

IF NOT EXISTS (SELECT * FROM SplitActions)
 BEGIN

	--Condition I: First Ever Load into SplitActions Table.
	--Check in SplitActions table, if there NOT EXISTS any records, 
	--then a INSERT all DISTINCT records into SplitActions Table from BloombergSplitHistory Table.

	--Insert into SplitActions table all data
	INSERT INTO SplitActions
	(LoadDate, Ticker, SecurityID, EffectiveDate, AdjustmentFactor, AppliedStatus, AppliedDate)
	SELECT DISTINCT @DateLoaded, TICKER, SecurityID, EffectiveDate, AdjustmentFactor, @AppliedStatus, null
    FROM ##BloomSplitTemp 
   WHERE  DATEPART(year, EffectiveDate) >= @YearSinceData   --Get records since Year specified [2000]
   ORDER BY SecurityId, EffectiveDate ASC

 END

ELSE
 BEGIN

	-- Declare the variables to store the values returned by FETCH.
	DECLARE @Ticker varchar(30)
    DECLARE @SecurityID int
	DECLARE @SplitAdjFactor decimal(15,6)
	DECLARE @SplitAdjDate datetime

	--Declare a CURSOR for the SplitActions.
	DECLARE curBloomSplitHS CURSOR FOR
	SELECT DISTINCT Ticker, SecurityID, EffectiveDate, AdjustmentFactor
    FROM ##BloomSplitTemp
	WHERE DATEPART(year, CAST(EffectiveDate AS datetime)) >= @YearSinceData   --Consider records since Year specified [2000]
	AND DATEDIFF(day, LoadDate, getdate()) <= @DaysToLoad                   --Get data loaded in the last @DaystoLoad[15]
	ORDER BY SecurityId, EffectiveDate ASC

	--Open the Cursor
	OPEN curBloomSplitHS

	-- Perform the first fetch and store the values in variables.
	-- Note: The variables are in the same order as the columns in the SELECT statement. 
	FETCH NEXT FROM curBloomSplitHS
	INTO @Ticker, @SecurityID, @SplitAdjDate, @SplitAdjFactor

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	WHILE @@FETCH_STATUS = 0
	BEGIN

		--Condition II: Single [first] split for a Ticker for an effective date
		--Check in SplitActions table, if there NOT EXISTS a record for a Ticker/effective date, 
		--then a INSERT into SplitActions Table
		IF NOT EXISTS (
			SELECT * FROM SplitActions WHERE Ticker = @Ticker AND EffectiveDate = @SplitAdjDate)
		 BEGIN

			INSERT INTO SplitActions
			(LoadDate, Ticker, SecurityID, EffectiveDate, AdjustmentFactor, AppliedStatus, AppliedDate)
			VALUES(@DateLoaded,  @Ticker, @SecurityID, @SplitAdjDate, @SplitAdjFactor, @AppliedStatus, null)

		 END

		--Condition III: MULTIPLE Splits for a Ticker on the same effective date
		--Check in SplitActions table, if there NOT EXISTS a record for a Ticker/EffectiveDate/SplitAdjFactor, 
		--then INSERT into SplitActions Table

		--e.g. Sample Data: 
        --SplitActionId  Ticker  SecurityId Effective Date      Adjustment Factor
        --*************  ******  ********** ******************  *****************
		--	286	         RTN		866		 2001-05-15  		   0.05
		--***Scenario 1: Same effective date but different adjustment factor, will copy over data.
		--	287	         RTN		866		 2001-05-15	  	       20.00
		--***Scenario 2: Different effective date with same adj factor, will copy over data.
		--	288	         RTN		866		 2001-06-15	  	       0.05
        --*************  ******  ********** ******************  *****************
		ELSE IF NOT EXISTS (
			SELECT * FROM SplitActions WHERE Ticker = @Ticker AND EffectiveDate = @SplitAdjDate AND AdjustmentFactor = @SplitAdjFactor)
		 BEGIN

			INSERT INTO SplitActions
			(LoadDate, Ticker, SecurityID, EffectiveDate, AdjustmentFactor, AppliedStatus, AppliedDate)
			VALUES(@DateLoaded,  @Ticker, @SecurityID, @SplitAdjDate, @SplitAdjFactor, @AppliedStatus, null)
		 END

	   -- This is executed as long as the previous fetch succeeds.
  	   FETCH NEXT FROM curBloomSplitHS
	   INTO @Ticker, @SecurityID, @SplitAdjDate, @SplitAdjFactor

	END

	CLOSE curBloomSplitHS
	DEALLOCATE curBloomSplitHS

END

--Clean up, drop temp tables
DROP TABLE ##BloomSplitTemp

COMMIT TRANSACTION

SET NOCOUNT OFF
END

GO


/*
SELECT * FROM BloombergSplitHistory ORDER BY LoadDate DESC
GO
SELECT * FROM SplitActions
WHERE AppliedStatus = 'N'
ORDER BY AppliedDate DESC
GO

SELECT * FROM SplitActions where ticker IN ('CFG', 'HLT') -- has splits in thousands
GO


DELETE FROM BloombergSplitHistory
DELETE FROM SplitActions WHERE AppliedStatus = 'N'
GO

sp_help SplitActions

exec spInsertSplitActions
*/