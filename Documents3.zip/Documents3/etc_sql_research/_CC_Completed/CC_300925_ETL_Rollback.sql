-- ETL_Rollback.sql
-- 12/19/2018

/*
alter table PortalUsage - drop TransactionId, EmbargoStyle, FileName, LoadDate
drop index (SiteId, TransactionId) on PortalUsage
drop table FileLoadInstructions
drop table PortalClientEmbargo
drop proc spGetFileLoadInstruction

-- Bloomberg
rollback table PortalUsageStaging_Bloomberg
rollback proc spLoadPortalUsageFromStaging_Bloomberg

--Factset
rollback table PortalUsageStaging_FactSet
rollback proc spLoadPortalUsageFromStaging_FactSet

--ThomsonReuters
rollback table PortalUsageStaging_TR
rollback proc spLoadPortalUsageFromStaging_TR

--CapitalIQ
rollback table PortalUsageStaging_CIQ
rollback proc spLoadPortalUsageFromStaging_CIQ

rollback proc spAddFileProcessingLog

*/

USE [Research]
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- drop ClientEmbargo
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalClientEmbargo]') AND type in (N'U'))
DROP TABLE [dbo].[PortalClientEmbargo]
GO

-- drop FileLoadInstructions
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FileLoadInstructions]') AND type in (N'U'))
DROP TABLE [dbo].[FileLoadInstructions]
GO

--alter FileprocessingConfig
--ALTER TABLE [dbo].[FileProcessingConfig] DROP CONSTRAINT [PK_FileProcessingConfig]
--GO
--ALTER TABLE [dbo].[FileProcessingConfig] ADD  CONSTRAINT [PK_ReadershipFileConfig] PRIMARY KEY CLUSTERED 
--( [ConfigId] ASC ) ON [PRIMARY]
--GO

-- alter PortalUsage
-- Drop index on PortalUsage
IF EXISTS(SELECT * FROM sys.indexes WHERE Name = N'IX_PortalUsage_SiteIdTransactionId' AND Object_ID = Object_ID(N'[dbo].[PortalUsage]'))
	DROP INDEX IX_PortalUsage_SiteIdTransactionId ON [dbo].[PortalUsage]
GO
-- drop columns
IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'TransactionId' AND Object_ID = Object_ID(N'[dbo].[PortalUsage]'))
	ALTER TABLE [dbo].[PortalUsage] DROP COLUMN TransactionId
GO
IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'EmbargoStyle' AND Object_ID = Object_ID(N'[dbo].[PortalUsage]'))
	ALTER TABLE [dbo].[PortalUsage] DROP COLUMN EmbargoStyle
GO
IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'FileName' AND Object_ID = Object_ID(N'[dbo].[PortalUsage]'))
	ALTER TABLE [dbo].[PortalUsage] DROP COLUMN [FileName]
GO
IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'LoadDate' AND Object_ID = Object_ID(N'[dbo].[PortalUsage]'))
	ALTER TABLE [dbo].[PortalUsage] DROP COLUMN LoadDate
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FileProcessingConfig]') AND type in (N'U'))
   DROP TABLE [dbo].[FileProcessingConfig]
GO

CREATE TABLE [dbo].[FileProcessingConfig]
(
	[ConfigId]       [int]           NOT NULL IDENTITY(1,1),
	[DataStore]      [nvarchar](100) NOT NULL,
	[SourceFilePath] [nvarchar](max) NOT NULL,
	[BackupFilePath] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_ReadershipFileConfig] PRIMARY KEY CLUSTERED ( [ConfigId] ASC ) ON [PRIMARY]
) ON [PRIMARY]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetFileLoadInstruction]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spGetFileLoadInstruction]
GO

-- Create or alter Bloomberg staging table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_Bloomberg]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_Bloomberg]
GO

-- Existing Staging table for Bloomberg
CREATE TABLE [dbo].[PortalUsageStaging_Bloomberg](
	[Story ID]          [varchar](500)  NULL,
	[Wire]              [varchar](500)  NULL,
	[Class]             [varchar](500)  NULL,
	[Customer #]        [varchar](500)  NULL,
	[Customer Name]     [varchar](500)  NULL,
	[Firm #]            [varchar](500)  NULL,
	[UUID]              [varchar](500)  NULL,
	[User Name]         [varchar](500)  NULL,
	[Business Email]    [varchar](500)  NULL,
	[Alternate Email]   [varchar](500)  NULL,
	[User Country]      [varchar](500)  NULL,
	[User State]        [varchar](500)  NULL,
	[User City]         [varchar](500)  NULL,
	[Transaction ID]    [varchar](500)  NULL,
	[Story Headline]    [varchar](500)  NULL,
	[Post Date]         [varchar](500)  NULL,
	[Read Date]         [varchar](500)  NULL
) ON [PRIMARY]
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 3 -- Bloomberg

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_Bloomberg) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_Bloomberg STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  CASE WHEN ISNUMERIC([Story Id]) = 1 THEN [Story ID] ELSE 0 END AS StoryId,
  [Read Date],
  @SiteId,
  '',
  [Business Email],
  [User Name],
  CASE WHEN ISNUMERIC([UUID]) = 1 THEN [UUID] ELSE NULL END AS UUID,
  [Customer Name],
  [Customer #]
FROM [dbo].[PortalUsageStaging_Bloomberg]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read Date] AS DATE) ), 101)
FROM PortalUsageStaging_Bloomberg
WHERE ISDATE([Read Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Bloomberg from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded,@PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_FactSet]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_FactSet]
GO

-- Existing Staging table for Factset
CREATE TABLE [dbo].[PortalUsageStaging_FactSet](
	[Date/time read]                [varchar](500) NULL,
	[Platform]                      [varchar](500) NULL,
	[Reader ID (FactSet)]           [varchar](500) NULL,
	[Reader name]                   [varchar](500) NULL,
	[E-mail]                        [varchar](500) NULL,
	[Phone]                         [varchar](500) NULL,
	[Parent Firm ID (FactSet)]      [varchar](500) NULL,
	[Parent Firm name]              [varchar](500) NULL,
	[Firm ID (FactSet)]             [varchar](500) NULL,
	[Firm name]                     [varchar](500) NULL,
	[Address]                       [varchar](500) NULL,
	[City]                          [varchar](500) NULL,
	[State]                         [varchar](500) NULL,
	[Country]                       [varchar](500) NULL,
	[Doc ID (contributor)]          [varchar](500) NULL,
	[Doc ID (FactSet)]              [varchar](500) NULL,
	[Readership Event ID (FactSet)] [varchar](500) NULL,
	[Date/time published]           [varchar](500) NULL,
	[Date/time received]            [varchar](500) NULL,
	[Report title]                  [varchar](500) NULL
) ON [PRIMARY]
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 12 -- Factset

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_FactSet) RETURN

-- Delete PortalUsage rows later than (>=) min(readdate) in staging table
-- This will wipe out any data that was loaded later than the min(readDate) of the data file
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND PU.ReadDate >= (SELECT MIN(CAST([Date/time read] AS DATE)) FROM PortalUsageStaging_FactSet)

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId)
SELECT
  'R',
  [Doc ID (contributor)],
  [Date/time read],
  @SiteId,
  [Platform],
  [E-mail],
  [Reader name],
  [Reader ID (FactSet)],
  [Firm name],
  [Firm ID (FactSet)]
FROM [dbo].[PortalUsageStaging_FactSet]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Date/time read] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Date/time read] AS DATE) ), 101)
FROM PortalUsageStaging_FactSet
WHERE ISDATE([Date/time read]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for FactSet from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO

-- Thomson Reuters staging table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_TR]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_TR]
GO

CREATE TABLE [dbo].[PortalUsageStaging_TR](
	[TR DocID]              [varchar](500)  NULL,
	[Local DocID]           [varchar](500)  NULL,
	[Headline]              [varchar](500)  NULL,
	[# Pages]               [varchar](500)  NULL,
	[Ticker]                [varchar](500)  NULL,
	[Industry]              [varchar](500)  NULL,
	[Country]               [varchar](500)  NULL,
	[Analyst]               [varchar](500)  NULL,
	[TR Analyst ID]         [varchar](500)  NULL,
	[Local Analyst ID]      [varchar](500)  NULL,
	[Published Date]        [varchar](500)  NULL,
	[Viewed Date]           [varchar](500)  NULL,
	[Client Name]           [varchar](500)  NULL,
	[Client Company ID]     [varchar](500)  NULL,
	[User Name]             [varchar](500)  NULL,
	[Unique ID]             [varchar](500)  NULL,
	[User Job Role]         [varchar](500)  NULL,
	[User Division]         [varchar](500)  NULL,
	[User Email]            [varchar](500)  NULL,
	[User Phone]            [varchar](500)  NULL,
	[User Address]          [varchar](500)  NULL,
	[User City]             [varchar](500)  NULL,
	[User State]            [varchar](500)  NULL,
	[User Country]          [varchar](500)  NULL,
	[Client Address]        [varchar](500)  NULL,
	[Client City]           [varchar](500)  NULL,
	[Client State]          [varchar](500)  NULL,
	[Client Country]        [varchar](500)  NULL,
	[Client Type]           [varchar](500)  NULL,
	[Delivery]              [varchar](500)  NULL
) ON [PRIMARY]

GO


ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 9 -- Thomson Reuters

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_TR) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_TR STG
   WHERE YEAR(PU.ReadDate) = YEAR(STG.[Viewed Date])
   AND MONTH(PU.ReadDate)= MONTH(STG.[Viewed Date])
   AND DAY(PU.ReadDate)  = DAY(STG.[Viewed Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType)
SELECT
  'R',
  CASE WHEN ISNUMERIC([Local DocID]) = 1 THEN [Local DocID] ELSE 0 END,
  CASE WHEN ISDATE([Viewed Date]) = 1 THEN [Viewed Date] ELSE NULL END,
  @SiteId,
  [Delivery],
  [User Email],
  [User Name],
  ISNULL([Unique ID],0),
  [Client Name],
  ISNULL([Client Company ID],0),
  [Client Type]
FROM [dbo].[PortalUsageStaging_TR]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Viewed Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Viewed Date] AS DATE) ), 101)
FROM PortalUsageStaging_TR
WHERE ISDATE([Viewed Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for TR from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_CIQ]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_CIQ]
GO

-- Existing Staging table for Capital IQ
CREATE TABLE [dbo].[PortalUsageStaging_CIQ](
	[Download Date]         [varchar](500)  NULL,
	[CIQ Doc Id]            [varchar](500)  NULL,
	[Ctb Doc Id]            [varchar](500)  NULL,
	[Company]               [varchar](500)  NULL,
	[Company Name]          [varchar](500)  NULL,
	[User]                  [varchar](500)  NULL,
	[User Name]             [varchar](500)  NULL,
	[Email]                 [varchar](500)  NULL,
	[Firm Type]             [varchar](500)  NULL,
	[Doc Type]              [varchar](500)  NULL,
	[Industry]              [varchar](500)  NULL,
	[Analyst]               [varchar](500)  NULL,
	[Headline]              [varchar](500)  NULL,
	[Price]                 [varchar](500)  NULL,
	[Document Posted Date]  [varchar](500)  NULL,
	[Type]                  [varchar](500)  NULL,
	[Activity Type]         [varchar](500)  NULL,
	[Activity Id]           [varchar](500)  NULL
) ON [PRIMARY]
GO



ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT,
@EditDate         DATETIME

SET @SiteId = 11 -- Capital IQ

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_CIQ) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_CIQ STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Download Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Download Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Download Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (ContentType, ContentId, ReadDate, SiteId, SubSite, Email, Contact, ContactId, Account, AccountId, AccountType)
SELECT
  'R',
  [Ctb Doc Id],
  [Download Date],
  @SiteId,
  [Activity Type],
  [Email],
  [User Name],
  [User],
  [Company Name],
  [Company],
  [Firm Type]
FROM [dbo].[PortalUsageStaging_CIQ]
WHERE ISNUMERIC([Ctb Doc Id]) = 1

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Download Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Download Date] AS DATE) ), 101)
FROM PortalUsageStaging_CIQ
WHERE ISDATE([Download Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for CIQ from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @EditDate = getdate()
EXEC spLoadPortalLoadLog @SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, @EditDate

SELECT @RowsLoaded, @PeriodStartDate, @PeriodEndDate

SET NOCOUNT OFF
END


GO


-- =================================================================================================
-- Author:       Anup Singh
-- Revisions:    10/23/2018 - Created
-- Description:  To enter log for file processing project like Holdings, Readership,Model
-- =================================================================================================
ALTER PROC [dbo].[spAddFileProcessingLog]
(
 @DataStore as nvarchar(250),
 @filename as nvarchar(250),
 @ServerName as nvarchar(100),
 @EditorId as int,
 @Comment as nvarchar(max) = null
)
AS
BEGIN
			
		IF @DataStore  = 'Holdings'
		BEGIN
		    INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,LastExecution))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,LastExecution))), 101)
					 ,count(*)
					 ,@EditorId
					 ,'Holdings ' + Convert(varchar(10),count(*)) + ' / vHoldings ' + Convert(Varchar(10),(select count(*) from vHoldings)) 
					 from Holdings
		END
		ELSE IF @DataStore  = 'ONEaccess'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,file_date_UTC))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,file_date_UTC))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment 
					 from PortalUsageStaging_ONEaccess
		END
		ELSE IF @DataStore  = 'Bloomberg'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Read Date]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Read Date]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_Bloomberg
		END

		ELSE IF @DataStore  = 'BlueMatrix'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Read Date/Time]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Read Date/Time]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_BlueMatrix
		END
		ELSE IF @DataStore  = 'FactSet'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Date/time read]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Date/time read]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_FactSet
		END
		ELSE IF @DataStore  = 'TR'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Viewed Date]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Viewed Date]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_TR
		END
		ELSE IF @DataStore  = 'CIQ'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Download Date]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Download Date]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_CIQ
		END

		ELSE IF @DataStore  = 'RSRCHX'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Action Date (UTC)]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Action Date (UTC)]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_RSRCHX
		END

		ELSE IF @DataStore  = 'REDDEER'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(Convert(Date,[Read_Date]))), 101)
					 ,convert(varchar, Convert(date,Max(Convert(Date,[Read_Date]))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_RedDeer
		END
		ELSE IF @DataStore  = 'VISIBLEALPHA'
		BEGIN
		     INSERT INTO FileProcessingLog
			                             (
										 LoadDate
										,DataStore
										,[Server]
										,[FileName]
										,PeriodStart
										,PeriodEnd
										,RowsLoaded
										,EditorId
										,Comment
										 )
			  select GETDATE()
			         ,@DataStore
					 ,@ServerName
			         ,@filename
					 ,convert(varchar, Convert(date,Min(CONVERT(date,replace(file_date_UTC,'Z',':00'),127))), 101)
					 ,convert(varchar, Convert(date,Max(CONVERT(date,replace(file_date_UTC,'Z',':00'),127))), 101)
					 ,count(*)
					 ,@EditorId
					 ,@Comment
					 from PortalUsageStaging_VisibleAlpha
		END
END

GO

GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_Bloomberg]  TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_FactSet]    TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_TR]         TO DE_IIS
GRANT INSERT, DELETE, UPDATE ON [dbo].[PortalUsageStaging_CIQ]        TO DE_IIS
GO
