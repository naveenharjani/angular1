-- spGetTickerTableXml2_Rollback.sql
-- 11/21/2016

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE name = 'spGetTickerTableXml2' and TYPE = 'P')
  DROP PROCEDURE [dbo].[spGetTickerTableXml2]
GO