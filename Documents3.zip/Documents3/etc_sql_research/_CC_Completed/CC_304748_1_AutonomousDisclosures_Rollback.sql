-- AutonomousDisclosuresRollback.sql
-- 03/04/2019

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.columns where name = 'AltId' and object_id = OBJECT_ID('Authors'))
alter table Authors
drop column TypeId, AltId 
GO
if exists(select * from sys.columns where name = 'AltId' and object_id = OBJECT_ID('Securities2'))
alter table Securities2
drop column TypeId, AltId 
GO
ALTER PROCEDURE [dbo].[spRenderAuthors]
  @Style int , @Region int = 1
AS
IF @Style = 1      SELECT 'Value' = Name,     'Display' = Last + ', ' + First FROM Authors                                        ORDER BY Display
ELSE IF @Style = 2 SELECT 'Value' = Name,     'Display' = Last + ', ' + First FROM Authors WHERE IsActive = -1 AND IsAnalyst = -1 ORDER BY Display
ELSE IF @Style = 3 SELECT 'Value' = AuthorID, 'Display' = Last + ', ' + First FROM Authors                                        ORDER BY Display
ELSE IF @Style = 4 SELECT 'Value' = AuthorID, 'Display' = Last + ', ' + First FROM Authors WHERE IsActive = -1                    ORDER BY Display
ELSE IF @Style = 5 SELECT 'Value' = AuthorID, 'Display' = Last + ', ' + First FROM Authors WHERE IsActive = -1 AND IsAnalyst = -1 ORDER BY Display
--Active Analysts in a region
ELSE IF @Style = 6
SELECT distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
FROM Authors A JOIN ResearchCoverage RC ON A.AuthorId = RC.AnalystId
LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
WHERE
IsAnalyst = -1 and
RC.Launchdate is not null and
RC.Dropdate is null and
R.RegionId = @Region
ORDER BY Display
--Active Analysts in all regions
ELSE IF @Style = 7
SELECT distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
FROM Authors A JOIN ResearchCoverage RC ON A.AuthorId = RC.AnalystId
LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
WHERE
IsAnalyst = -1 and
RC.Launchdate is not null and
RC.Dropdate is null
ORDER BY Display
--All Analysts in a region
ELSE IF @Style = 8
SELECT distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
FROM Authors A LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
WHERE
IsAnalyst = -1 and
R.RegionId = @Region
ORDER BY Display
--All Analysts in all regions
ELSE IF @Style = 9
SELECT distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
FROM Authors A LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
WHERE
IsAnalyst = -1
ORDER BY Display

GO

ALTER PROCEDURE [dbo].[spRenderSecurities]
  @Style int,
  @CompanyId int = NULL,
  @AnalystId int = NULL
AS
SET NOCOUNT ON
DECLARE @Analysts TABLE(AnalystId int)

IF @Style = 1      SELECT 'Value' = Ticker,     'Display' = Ticker + ' / ' + Company FROM Securities2                     ORDER BY Display
ELSE IF @Style = 2 SELECT 'Value' = Ticker,     'Display' = Ticker + ' / ' + Company FROM Securities2 WHERE IsActive = -1 ORDER BY Display
ELSE IF @Style = 3 SELECT 'Value' = SecurityId, 'Display' = Ticker + ' / ' + Company FROM Securities2                     ORDER BY Display
ELSE IF @Style = 4 SELECT 'Value' = SecurityId, 'Display' = Ticker + ' / ' + Company FROM Securities2 WHERE IsActive = -1 ORDER BY Display
ELSE IF @Style = 5

SELECT
  'Value' = S.SecurityId,
  'Display' = S.Ticker
FROM Companies C
JOIN Securities2 S ON S.CompanyId = C.CompanyId
WHERE C.CompanyId = @CompanyId AND S.IsActive = -1 ORDER BY S.OrdNo

ELSE IF @Style = 6
BEGIN
IF @AnalystId = -1 OR ISNULL(@AnalystId, 0) = 0
  INSERT @Analysts SELECT AuthorId FROM Authors WHERE IsAnalyst = -1 AND IsActive = -1
ELSE
  INSERT @Analysts SELECT @AnalystId

SELECT DISTINCT
  'Value'   = S.SecurityId,
  'Display' = S.Ticker + ' / ' + S.Company
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
WHERE RC.DropDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)
ORDER BY Display
END

GO

ALTER PROCEDURE dbo.spGetAuthorTextDisclosures
  @AuthorID      int,
  @Disclosure    varchar(2048) OUTPUT,
  @Editor        varchar(36)   OUTPUT,
  @EditDate      datetime      OUTPUT
AS
-- RETURN OUTPUT PARAMETERS
SELECT
  @Disclosure = D.Disclosure,
  @Editor     = U.UserName,
  @EditDate   = D.EditDate
FROM AuthorTextDisclosures D
LEFT JOIN Users U ON U.UserID = D.EditorID
WHERE D.AuthorID = @AuthorID
-- RETURN ROWSET
SELECT D.AuthorID, A.Last + ', ' + A.First, D.Disclosure, U.UserName, D.EditDate
FROM Authors A
JOIN AuthorTextDisclosures D ON D.AuthorID = A.AuthorID
LEFT JOIN Users U ON U.UserID = D.EditorID
WHERE A.IsActive = -1 ORDER BY 2
GO

ALTER PROCEDURE dbo.spGetSecurityTextDisclosures
  @SecurityID    int,
  @Disclosure    varchar(2048) OUTPUT,
  @Editor        varchar(36)   OUTPUT,
  @EditDate      datetime      OUTPUT
AS
-- RETURN OUTPUT PARAMETERS
SELECT
  @Disclosure = D.Disclosure,
  @Editor     = U.UserName,
  @EditDate   = D.EditDate
FROM SecurityTextDisclosures D
LEFT JOIN Users U ON U.UserID = D.EditorID
WHERE D.SecurityID = @SecurityID
-- RETURN ROWSET
SELECT D.SecurityID, S.Ticker + ' / ' + S.Company, D.Disclosure, U.UserName, D.EditDate
FROM ResearchCoverage C
JOIN SecurityTextDisclosures D ON D.SecurityID = C.SecurityID
JOIN Securities2 S ON S.SecurityID = C.SecurityID
LEFT JOIN Users U ON U.UserID = D.EditorID
WHERE C.DropDate IS NULL ORDER BY 2

GO

ALTER PROCEDURE [dbo].[spSearchSecurityCheckboxDisclosures]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'
CREATE TABLE #TmpSearch
(
  ID         int IDENTITY,
  SecurityID int         NULL,
  Ticker     varchar(15) NULL,
  Company    varchar(63) NULL,
  D1         smallint    NULL,
  D2         smallint    NULL,
  D3         smallint    NULL,
  D4         smallint    NULL,
  D5         smallint    NULL,
  D6         smallint    NULL,
  D7         smallint    NULL,
  D8         smallint    NULL,
  D9         smallint    NULL,
  D10        smallint    NULL
)
INSERT INTO #TmpSearch (SecurityID, Ticker, Company, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10)
EXEC
(
'SELECT'
+ ' SecurityID = C.SecurityID,'
+ ' Ticker     = S.Ticker,'
+ ' Company    = S.Company,'
+ ' SUM(CASE WHEN D.DisclosureID =  1 THEN -1 ELSE 0 END) AS D1,'
+ ' SUM(CASE WHEN D.DisclosureID =  2 THEN -1 ELSE 0 END) AS D2,'
+ ' SUM(CASE WHEN D.DisclosureID =  3 THEN -1 ELSE 0 END) AS D3,'
+ ' SUM(CASE WHEN D.DisclosureID =  4 THEN -1 ELSE 0 END) AS D4,'
+ ' SUM(CASE WHEN D.DisclosureID =  5 THEN -1 ELSE 0 END) AS D5,'
+ ' SUM(CASE WHEN D.DisclosureID =  6 THEN -1 ELSE 0 END) AS D6,'
+ ' SUM(CASE WHEN D.DisclosureID =  7 THEN -1 ELSE 0 END) AS D7,'
+ ' SUM(CASE WHEN D.DisclosureID =  8 THEN -1 ELSE 0 END) AS D8,'
+ ' SUM(CASE WHEN D.DisclosureID =  9 THEN -1 ELSE 0 END) AS D9,'
+ ' SUM(CASE WHEN D.DisclosureID = 10 THEN -1 ELSE 0 END) AS D10'
+ ' FROM ResearchCoverage C'
+ ' JOIN Securities2 S ON S.SecurityID  = C.SecurityID'
+ ' LEFT JOIN SecurityCheckboxDisclosures D ON D.SecurityID = C.SecurityID'
+ ' WHERE C.DropDate IS NULL'
+ ' GROUP BY C.SecurityID, S.Ticker, S.Company'
+ ' ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT SecurityID, Ticker, Company, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO

ALTER PROCEDURE [dbo].[spSaveAuthorTextDisclosure]
  @AuthorID      int,
  @Disclosure    varchar(2048),
  @EditorID      int
AS
-- NO ROW IMPLIES NO DISCLOSURE
IF @Disclosure IS NOT NULL
  BEGIN
    IF NOT EXISTS (SELECT AuthorID FROM AuthorTextDisclosures WHERE AuthorID = @AuthorID)
      INSERT INTO AuthorTextDisclosures (AuthorID, Disclosure, EditorID, EditDate) VALUES (@AuthorID, @Disclosure, @EditorID, GETDATE())
    ELSE
      UPDATE AuthorTextDisclosures SET Disclosure = @Disclosure, EditorID = @EditorID, EditDate = GETDATE() WHERE AuthorID = @AuthorID
  END
ELSE
  BEGIN
    DELETE FROM AuthorTextDisclosures WHERE AuthorID = @AuthorID
  END
RETURN 0
GO

ALTER PROCEDURE [dbo].[spSaveSecurityTextDisclosure]
  @SecurityID    int,
  @Disclosure    varchar(2048),
  @EditorID      int
AS
-- NO ROW IMPLIES NO DISCLOSURE
IF @Disclosure  IS NOT NULL
  BEGIN
    IF NOT EXISTS (SELECT SecurityID FROM SecurityTextDisclosures WHERE SecurityID = @SecurityID)
      INSERT INTO SecurityTextDisclosures (SecurityID, Disclosure, EditorID, EditDate) VALUES (@SecurityID, @Disclosure, @EditorID, GETDATE())
    ELSE
      UPDATE SecurityTextDisclosures SET Disclosure = @Disclosure, EditorID = @EditorID, EditDate = GETDATE() WHERE SecurityID = @SecurityID
  END
ELSE
  BEGIN
    DELETE FROM SecurityTextDisclosures WHERE SecurityID = @SecurityID
  END
RETURN 0
GO

ALTER PROCEDURE [dbo].[spSaveSecurityCheckboxDisclosure]
  @SecurityID   int,
  @DisclosureID int,
  @Disclosure   smallint,
  @EditorID     int,
  @Ticker       varchar(15) OUTPUT
AS
SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityID = @SecurityID
-- NO ROWS IMPLIES NO DISCLOSURE
IF @Disclosure = -1
  BEGIN
    IF NOT EXISTS (SELECT * FROM SecurityCheckboxDisclosures WHERE SecurityID = @SecurityID AND DisclosureID = @DisclosureID)
      INSERT INTO SecurityCheckboxDisclosures (SecurityID, DisclosureID, EditorID, EditDate) VALUES (@SecurityID, @DisclosureID, @EditorID, GETDATE())
    ELSE
      UPDATE SecurityCheckboxDisclosures SET EditorID = @EditorID, EditDate = GETDATE() WHERE SecurityID = @SecurityID AND DisclosureID = @DisclosureID
  END
ELSE
  BEGIN
    DELETE FROM SecurityCheckboxDisclosures WHERE SecurityID = @SecurityID AND DisclosureID = @DisclosureID
  END
RETURN 0
GO

ALTER PROCEDURE [dbo].[spRenderActiveSecurities]
AS
SELECT
  'Value'   = S.SecurityID,
  'Display' = S.Ticker + ' / ' + S.Company
FROM Securities2 S JOIN ResearchCoverage C ON C.SecurityID = S.SecurityID WHERE C.DropDate IS NULL ORDER BY Display
GO
