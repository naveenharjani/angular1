-- CC_x_1_VisibleAlpha.sql
-- 05/14/2018

/*

See DistributionPDU.sql to create Visible Alpha adapter

create IX_DistributionEntitlements_SiteId_ProductGroupId

alter DistributionSites         - Add LinkBack, LinkSourceId, SiteType. Lengthen FtpPassword, FtpFolder, ScbFolder.
alter spAddDistributionItem     - Custom subscriptions for Visible Alpha models and Restricted List
create spGetAdapterVisibleAlpha - Proc used to generate custom model metadata file for Visible Alpha

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if not exists(select * from sys.columns where object_id = object_id('DistributionSites') and name = 'LinkBack')
begin
  alter table DistributionSites
  add LinkBack int, LinkSourceId int , SiteType char(1)
end
go

update DistributionSites set LinkBack = 0, LinkSourceId = null
go

update DistributionSites set SiteType = 'R' where Site not like '%Visible Alpha%'
go

update DistributionSites set SiteType = 'M' where Site like '%Visible Alpha%'
go

alter table DistributionSites
alter column FtpPassword varchar(64)

alter table DistributionSites
alter column FtpFolder varchar(100)

alter table DistributionSites
alter column ScbFolder varchar(100)
go

if not exists(select name from sys.indexes where name like '%IX_DistributionEntitlements_SiteId_ProductGroupId%')
begin
ALTER TABLE [dbo].[DistributionEntitlements] ADD  CONSTRAINT [IX_DistributionEntitlements_SiteId_ProductGroupId] UNIQUE NONCLUSTERED
(
  [SiteId] ASC,
  [ProductGroupId] ASC
)
end
go

ALTER PROCEDURE dbo.spAddDistributionItem
  @PubNo         int,
  @SiteId        int,
  @Operation     char(1) -- C (Contribute) or D (Delete)
AS
DECLARE @Scheduled      datetime
DECLARE @CurrentSiteId  int
DECLARE @Exception      smallint
DECLARE @Now            datetime
DECLARE @Published      datetime
DECLARE @PublicationTypeId int

-- 10/20/2016 switched Approved column from ApprovedDate to PublishedDate
SELECT @Published = PublishedDate, @PublicationTypeId = PublicationTypeId
FROM Publications P JOIN PublicationTypes PT ON P.Type = PT.PublicationType
WHERE PubNo = @PubNo

SELECT @Now = GETDATE()
SELECT SiteId INTO #Tmp_Sites FROM DistributionSubscriptions WHERE 1 = 2
IF @Operation = 'C'
BEGIN
-- Customized subscriptions
-- 04/24/2014 - Daiwa Bloomberg subscription limited to Pan-Euro product group, i.e. ProductGroupId = 2
-- 10/19/2016 - McKinsey subscription limited to McKinsey product group, i.e. ProductGroupId = 13
-- 05/14/2018 - Restricted List - Only v1 reports with Initiate or Rating changes

-- PASS 1 - Identify eligible sites
  IF @SiteId = 0
  -- All sites
  BEGIN
    --Standard subscriptions - Excluding custom subscriptions, e.g. Daiwa, McKinsey
    INSERT INTO #Tmp_Sites
    SELECT DSU.SiteId FROM DistributionSubscriptions DSU JOIN DistributionSites DSI ON DSU.SiteId = DSI.SiteId
    WHERE DSI.Active = -1 AND DSU.Active = -1 AND PublicationTypeId = @PublicationTypeId
    AND DSI.SiteType = 'R'
    AND DSI.Site NOT LIKE '%Daiwa%'
    AND DSI.Site NOT LIKE '%McKinsey%'
    AND DSI.Site NOT LIKE '%Restricted%'
    ORDER BY DSU.SiteId
  END
  ELSE
  -- One site
  BEGIN
    --Standard subscriptions - Excluding custom subscriptions, e.g. Daiwa, McKinsey
    IF ((SELECT Site FROM DistributionSites WHERE SiteId = @SiteId) NOT LIKE '%Daiwa%' AND
        (SELECT Site FROM DistributionSites WHERE SiteId = @SiteId) NOT LIKE '%McKinsey%' AND
        (SELECT Site FROM DistributionSites WHERE SiteId = @SiteId) NOT LIKE '%Restricted%')
    BEGIN
      INSERT INTO #Tmp_Sites
      SELECT DSU.SiteId FROM DistributionSubscriptions DSU JOIN DistributionSites DSI ON DSU.SiteId = DSI.SiteId
      WHERE DSI.Active = -1 AND DSU.Active = -1 AND PublicationTypeId = @PublicationTypeId
      AND DSI.SiteType = 'R'
      AND DSU.SiteId = @SiteId ORDER BY DSU.SiteId
    END
  END

--Custom Subscriptions
  --Daiwa - Only when document in Pan-Euro product group
  IF (@SiteId = 0) OR ((SELECT Site FROM DistributionSites WHERE SiteId = @SiteId) LIKE '%Daiwa%')
  BEGIN
    IF EXISTS(SELECT * FROM ProductGroupDocuments WHERE PubNo = @PubNo AND ProductGroupId = 2)
    BEGIN
      INSERT INTO #Tmp_Sites
      SELECT DSU.SiteId FROM DistributionSubscriptions DSU JOIN DistributionSites DSI ON DSU.SiteId = DSI.SiteId
      WHERE DSI.Active = -1 AND DSU.Active = -1
      AND DSI.SiteType = 'R'
      AND PublicationTypeId = @PublicationTypeId
      AND DSI.Site LIKE '%Daiwa%'
    END
  END

  --McKinsey - Only when document in McKinsey product group
  IF (@SiteId = 0) OR ((SELECT Site FROM DistributionSites WHERE SiteId = @SiteId) LIKE '%McKinsey%')
  BEGIN
    IF EXISTS(SELECT * FROM ProductGroupDocuments WHERE PubNo = @PubNo AND ProductGroupId = 13)
    BEGIN
      INSERT INTO #Tmp_Sites
      SELECT DSU.SiteId FROM DistributionSubscriptions DSU JOIN DistributionSites DSI ON DSU.SiteId = DSI.SiteId
      WHERE DSI.Active = -1 AND DSU.Active = -1
      AND DSI.SiteType = 'R'
      AND PublicationTypeId = @PublicationTypeId
      AND DSI.Site LIKE '%McKinsey%'
    END
  END

  --Restricted List - Only v1 reports with Initiate or Rating changes
  IF (@SiteId = 0) OR ((SELECT Site FROM DistributionSites WHERE SiteId = @SiteId) LIKE '%Restricted%')
  BEGIN
    IF EXISTS(SELECT * FROM Publications P join PublicationFinancials PF ON P.PubNo = PF.PubNo WHERE P.PubNo = @PubNo AND P.Version = 1 AND PF.RatingAction in ('INITIATE','UPGRADE','DOWNGRADE'))
    BEGIN
      INSERT INTO #Tmp_Sites
      SELECT DSU.SiteId FROM DistributionSubscriptions DSU JOIN DistributionSites DSI ON DSU.SiteId = DSI.SiteId
      WHERE DSI.Active = -1 AND DSU.Active = -1
      AND DSI.SiteType = 'R'
      AND PublicationTypeId = @PublicationTypeId
      AND DSI.Site LIKE '%Restricted%'
    END
  END
END

IF @Operation = 'D'
BEGIN
  IF @SiteId = 0
  BEGIN
    INSERT INTO #Tmp_Sites
    SELECT DSI.SiteId FROM DistributionSites DSI JOIN DistributionQueue DQ ON DSI.SiteId = DQ.SiteId
    AND DSI.SiteType = 'R'
    WHERE PubNo = @PubNo
    ORDER BY DSI.SiteId
  END
  ELSE
  BEGIN
    INSERT INTO #Tmp_Sites
    SELECT DSI.SiteId FROM DistributionSites DSI JOIN DistributionQueue DQ ON DSI.SiteId = DQ.SiteId
    AND DSI.SiteType = 'R'
    WHERE PubNo = @PubNo AND DSI.SiteId = @SiteId
  END
END

-- PASS 2 - Distribute to eligible sites
SELECT TOP 1 @CurrentSiteId = SiteId from #Tmp_Sites ORDER BY SiteId
WHILE @@ROWCOUNT > 0
BEGIN
  --Cancel any pending distribution items if exists for same publication, site
  UPDATE DistributionQueue  SET Cancelled = @Now
  WHERE PubNo = @PubNo AND SiteId = @CurrentSiteId AND Operation = 'C' AND Transferred IS NULL AND Cancelled IS NULL

  IF @Operation = 'C'
  BEGIN
    EXEC spGetException @CurrentSiteId, @PubNo, @Exception OUTPUT
    IF @Exception = 0
      BEGIN
        EXEC spGetScheduledTime @CurrentSiteId, @PubNo, @Scheduled OUTPUT
        INSERT INTO DistributionQueue (SiteId, PubNo, Operation, Approved, Received, Scheduled, IsException)
        VALUES (@CurrentSiteId, @PubNo, @Operation, @Published, @Now, @Scheduled, 0)
      END
  END
  IF @Operation = 'D'
  BEGIN
    IF EXISTS
      (
       SELECT * FROM DistributionQueue WITH (NOLOCK) WHERE Transferred IS NOT NULL
       AND DistributionID = (SELECT MAX(DistributionID) FROM DistributionQueue WITH (NOLOCK) WHERE PubNo = @PubNo AND SiteId = @CurrentSiteId)
      )
      BEGIN
        SELECT TOP 1 @Published = Approved FROM DistributionQueue WITH (NOLOCK) WHERE PubNo = @PubNo ORDER BY DistributionId desc
        INSERT INTO DistributionQueue (SiteId, PubNo, Operation, Approved, Received, Scheduled, IsException)
        VALUES (@CurrentSiteId, @PubNo, @Operation, @Published, @Now, @Now, 0)
      END
  END
  SELECT TOP 1 @CurrentSiteId = SiteId FROM #Tmp_Sites WHERE SiteId > @CurrentSiteId ORDER BY SiteId
END

GO

IF EXISTS(SELECT * FROM Sys.Objects WHERE type = 'P' and name = 'spGetAdapterVisibleAlpha')
DROP PROC dbo.spGetAdapterVisibleAlpha
GO

-- =================================================================================================
-- Author:      Sandarsh M S
-- Revised:     02/20/2018
-- Description: Get Model MetaData based on ModelId.
--              This proc is used to generate custom meta data file for visible alpha models adapter
-- =================================================================================================

create procedure dbo.spGetAdapterVisibleAlpha
@ModelId int
as
begin
 select
  M.FileName,
  M.FileSize,
  M.ModelId,
  M.SecurityId,
  M.CompanyId,
  M.Company,
  M.Ticker,
  M.Region,
  M.AnalystId,
  M.Analyst,
  A.First,
  A.Last,
  A.ExtEmail as Email,
  M.Action,
  M.ActionId,
  dateadd(mi,datediff(mi,getdate(),getutcdate()),M.EditDate) EditDateUTC,
  S.ExchangeCode,
  C.Country,
  PF.EpsCurrency,
  P.Version
 from vModels M
 left outer join Authors A on M.AnalystId=A.AuthorID
 left outer join Securities2 S on S.SecurityID = M.SecurityId
 left outer join PublicationFinancials PF on S.SecurityId = PF.SecurityId and PF.EpsCurrency <> '' and PF.PubNo = M.PubNo
 left outer join Publications P on P.PubNo = M.PubNo
 left outer join Countries C on C.CountryCode = S.CountryCode
 where M.ModelId = @ModelId
end
go

GRANT EXECUTE ON dbo.spGetAdapterVisibleAlpha  TO DE_IIS,PowerUsers
GO

/*
--DEBUG

spGetAdapterVisibleAlpha 135276

*/
