-- RestrictedList_Rollback.sql
-- 12/05/2018

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER procedure [dbo].[spGetAdapterRestrictedList]
  @PubNo int
as
begin

select
  'Research.TradeDateTimeZone.Code' = '',
  'Research.TradeDate.Local' = '',
  'Research.SetStartDateTimeZone.Code' = 'EST',
  'Research.SetStartDate.Local' = CONVERT(VARCHAR(30), PU.PublishedDate, 120),
  'Research.SetEndDate.TimeZone.Code' = '',
  'Research.SetEndDate.Local' = '',
  'Research.EffectiveStartDate.TimeZone.Code' = '',
  'Research.EffectiveStartDate.Local' = '',
  'Research.EffectiveEndDate.TimeZone.Code' = '',
  'Research.EffectiveEndDate.Local' = '',
  'Research.Quantity' = '',
  'Research.PriceAmount' = '',
  'Research.Price.CurrencyCode' = '',
  'Research.TradeDirection' = '',
  'Research.LineOfBusiness.Name' = '',
  'Research.LineOfBusiness.CustomerKey' = '',
  'Research.Office.Name' = '',
  'Research.Office.CustomerKey' = '',
  'Research.UserGroup.Name' = '',
  'Research.UserGroup.CustomerKey' = '',
  'Research.UserAccount.UserName' = '',
  'Research.UserAccount.CustomerKey' = '',
  'Research.Security.Description' = S.Company,
  'Research.Security.Symbol' = VF.Ticker,
  'Research.Security.CUSIP'='',
  'Research.Security.SEDOL'='',
  'Research.Security.ISIN' = S.ISIN,
  'Research.Security.SecurityType.Code' = '',
  'Research.Security.Issuer.Code' = '',
  'Research.Security.Memo' =
    'ID=' + convert(varchar, PU.PubNo) +
    ' / Author=' + replace(A.Last, ',', ' ') + ' + ' + replace(A.First, ',', ' ') +
    ' / RatingAction=' + VF.RatingAction +
    ' / Rating=' + VF.Rating +
    ' / RatingPrior=' + isnull(VF.RatingPrior, ''),
  'Research.CustomerKey' = '',
  'Research.Security.FIGI' = '',
  'Research.Security.BloombergTicker' = ''
from Publications PU
join vFinancials VF on VF.PubNo = PU.PubNo
join Authors A on A.AuthorId = VF.AnalystId
join Securities2 S on S.SecurityId = VF.SecurityId
where PU.PubNo = @PubNo
and PU.Version = 1
and VF.RatingAction in ('Initiate', 'Upgrade', 'Downgrade')

end

GO


-- DEBUG

-- spGetAdapterRestrictedlist 140751