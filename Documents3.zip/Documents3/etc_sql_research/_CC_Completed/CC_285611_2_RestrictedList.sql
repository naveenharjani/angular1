-- CC_x_2_RestrictedList.sql
-- 04/26/2018

/*

alter spGetDistributionSite           - Alter to retrieve the newly added columns
alter spSaveDistributionSite          - Alter to save the newly added columns
create spGetAdapterRestrictedList - New proc to generate the restricted list daily data file

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER PROCEDURE [dbo].[spGetDistributionSite]
  @SiteId         int,
  @Site           varchar(32)  OUTPUT,
  @Model          char(4)      OUTPUT,
  @AdapterId      int          OUTPUT,
  @Codeset        varchar(16)  OUTPUT,
  @FtpType        varchar(10)  OUTPUT,
  @FtpLogon       varchar(64)  OUTPUT,
  @FtpPassword    varchar(64)  OUTPUT,
  @FtpPort        int          OUTPUT,
  @FtpFolder      varchar(100) OUTPUT,
  @ScbFolder      varchar(100) OUTPUT,
  @RixmlOrgIdType varchar(100) OUTPUT,
  @RixmlOrgId     varchar(100) OUTPUT,
  @WatermarkText  varchar(100) OUTPUT,
  @UseSchedule    int          OUTPUT,
  @Active         int          OUTPUT,
  @LinkBack       int          OUTPUT,
  @LinkSourceId   int          OUTPUT,
  @SiteType       char(1)      OUTPUT,
  @Editor         varchar(36)  OUTPUT,
  @EditDate       datetime     OUTPUT
AS
SELECT
  @Site           = SI.Site,
  @Model          = SI.Model,
  @AdapterId      = SI.AdapterId,
  @Codeset        = SI.Codeset,
  @FtpType        = SI.FtpType,
  @FtpLogon       = SI.FtpLogon,
  @FtpPassword    = SI.FtpPassword,
  @FtpPort        = SI.FtpPort,
  @FtpFolder      = SI.FtpFolder,
  @ScbFolder      = SI.ScbFolder,
  @RixmlOrgIdType = SI.RixmlOrgIdType,
  @RixmlOrgId     = SI.RixmlOrgId,
  @WatermarkText  = SI.WatermarkText,
  @UseSchedule    = SI.UseSchedule,
  @Active         = SI.Active,
  @LinkBack       = SI.LinkBack,
  @LinkSourceId   = SI.LinkSourceId,
  @SiteType       = SI.SiteType,
  @Editor         = E.UserName,
  @EditDate       = SI.EditDate
FROM DistributionSites SI
LEFT JOIN Users E ON E.UserID = SI.EditorID
WHERE SI.SiteId = @SiteId
GO

ALTER PROCEDURE [dbo].[spSaveDistributionSite]
  @SiteId         int OUTPUT,
  @Site           varchar(32),
  @Model          char(4),
  @AdapterId      int,
  @Codeset        varchar(16),
  @FtpType        varchar(10),
  @FtpLogon       varchar(64),
  @FtpPassword    varchar(64),
  @FtpPort        int,
  @FtpFolder      varchar(100),
  @ScbFolder      varchar(100),
  @RixmlOrgIdType varchar(100),
  @RixmlOrgId     varchar(100),
  @WatermarkText  varchar(100),
  @UseSchedule    int,
  @Active         int,
  @LinkBack       int,
  @LinkSourceId   int,
  @SiteType       char(1),
  @EditorID       int
AS
DECLARE @EditDate datetime
SELECT  @EditDate = GETDATE()
BEGIN TRANSACTION
IF EXISTS (SELECT SiteId FROM DistributionSites WHERE SiteId = @SiteId)
  BEGIN
    UPDATE DistributionSites SET
      Site           = @Site,
      Model          = @Model,
      AdapterId      = @AdapterId,
      Codeset        = @Codeset,
      FtpType        = @FtpType,
      FtpLogon       = @FtpLogon,
      FtpPassword    = @FtpPassword,
      FtpPort        = @FtpPort,
      FtpFolder      = @FtpFolder,
      ScbFolder      = @ScbFolder,
      RixmlOrgIdType = @RixmlOrgIdType,
      RixmlOrgId     = @RixmlOrgId,
      WatermarkText  = @WatermarkText,
      UseSchedule    = @UseSchedule,
      Active         = @Active,
      LinkBack       = @LinkBack,
      LinkSourceId   = @LinkSourceId,
      SiteType       = @SiteType,
      EditorID       = @EditorID,
      EditDate       = @EditDate
    WHERE SiteId = @SiteId
  END
ELSE
  BEGIN
    INSERT INTO DistributionSites
      ( Site, Model, AdapterId, Codeset, FtpType, FtpLogon, FtpPassword, FtpPort, FtpFolder, ScbFolder, RixmlOrgIdType, RixmlOrgId, WatermarkText, UseSchedule, Active, LinkBack, LinkSourceId, SiteType, EditorID, EditDate)
    VALUES
      (@Site, @Model, @AdapterId, @Codeset, @FtpType, @FtpLogon, @FtpPassword, @FtpPort, @FtpFolder, @ScbFolder, @RixmlOrgIdType, @RixmlOrgId, @WatermarkText, @UseSchedule, @Active, @LinkBack, @LinkSourceId, @SiteType, @EditorID, @EditDate)
    SELECT @SiteId = @@IDENTITY
  END
COMMIT TRANSACTION
RETURN 0
GO

IF EXISTS(SELECT * FROM sys.objects where name like '%spGetAdapterRestrictedList%')
DROP PROCEDURE dbo.spGetAdapterRestrictedList
GO

CREATE procedure [dbo].[spGetAdapterRestrictedList]
  @PubNo int
as
begin

select
  'Research.TradeDateTimeZone.Code' = '',
  'Research.TradeDate.Local' = '',
  'Research.SetStartDateTimeZone.Code' = 'EST',
  'Research.SetStartDate.Local' = CONVERT(VARCHAR(30), PU.PublishedDate, 120),
  'Research.SetEndDate.TimeZone.Code' = '',
  'Research.SetEndDate.Local' = '',
  'Research.EffectiveStartDate.TimeZone.Code' = '',
  'Research.EffectiveStartDate.Local' = '',
  'Research.EffectiveEndDate.TimeZone.Code' = '',
  'Research.EffectiveEndDate.Local' = '',
  'Research.Quantity' = '',
  'Research.PriceAmount' = '',
  'Research.Price.CurrencyCode' = '',
  'Research.TradeDirection' = '',
  'Research.LineOfBusiness.Name' = '',
  'Research.LineOfBusiness.CustomerKey' = '',
  'Research.Office.Name' = '',
  'Research.Office.CustomerKey' = '',
  'Research.UserGroup.Name' = '',
  'Research.UserGroup.CustomerKey' = '',
  'Research.UserAccount.UserName' = '',
  'Research.UserAccount.CustomerKey' = '',
  'Research.Security.Description' = S.Company,
  'Research.Security.Symbol' = VF.Ticker,
  'Research.Security.CUSIP'='',
  'Research.Security.SEDOL'='',
  'Research.Security.ISIN' = S.ISIN,
  'Research.Security.SecurityType.Code' = '',
  'Research.Security.Issuer.Code' = '',
  'Research.Security.Memo' =
    'ID=' + convert(varchar, PU.PubNo) +
    ' / Author=' + replace(A.Last, ',', ' ') + ' + ' + replace(A.First, ',', ' ') +
    ' / RatingAction=' + VF.RatingAction +
    ' / Rating=' + VF.Rating +
    ' / RatingPrior=' + isnull(VF.RatingPrior, ''),
  'Research.CustomerKey' = '',
  'Research.Security.FIGI' = '',
  'Research.Security.BloombergTicker' = ''
from Publications PU
join vFinancials VF on VF.PubNo = PU.PubNo
join Authors A on A.AuthorId = VF.AnalystId
join Securities2 S on S.SecurityId = VF.SecurityId
where PU.PubNo = @PubNo
and PU.Version = 1
and VF.RatingAction in ('Initiate', 'Upgrade', 'Downgrade')

end
go

grant execute on [dbo].[spGetAdapterRestrictedList] to DE_IIS, PowerUsers
go

/*

-- DEBUG

spGetAdapterRestrictedList 135246

Requires v1 Date!
Include PublicationsLog to support manual re-distribution? Yes

select * from Publications

select top 500 * from PublicationsLog
select top 500 * from AuditLog where operation = 'U' order by AuditNo desc

select top 500 * from vFinancials
where RatingAction in ('Initiate', 'Upgrade', 'Downgrade')

select * from PublicationFinancials

spGetFtpLogin 17

select * from DistributionSites

-- SAVE BEGIN

-- Get publication version 1 datetime from either Publications or PublicationsLog

select top 500
  PU.PubNo,
  PU.PublishedDate as 'Restriction Commenced',
  A.Last + ', ' + A.First as Analyst,
--  PR.PropValue as Analyst,
  VF.Ticker,
  S.Company,
  'Rating Action' = VF.RatingAction,
  'Rating' = VF.Rating,
  'Rating Prior' = isnull(VF.RatingPrior, ''),
  S.ISIN
--  'Publications'
--  PU.*,
--  VF.*
from Publications PU
join vFinancials VF on VF.PubNo = PU.PubNo
join Authors A on A.AuthorId = VF.AnalystId
--join Properties PR on PR.PubNo = PU.PubNo and PR.PropID = 5 -- Author
join Securities2 S on S.SecurityId = VF.SecurityId
where VF.RatingAction in ('Initiate', 'Upgrade', 'Downgrade')
and PU.PublishedDate >= DATEADD(day, -30, GETDATE())
and PU.Version = 1

union

select top 500
  PL.PubNo,
  PL.PublishedDate as 'Restriction Commenced',
  A.Last + ', ' + A.First as Analyst,
--  PR.PropValue as Analyst,
  VF.Ticker,
  S.Company,
  'Rating Action' = VF.RatingAction,
  'Rating' = VF.Rating,
  'Rating Prior' = isnull(VF.RatingPrior, ''),
  S.ISIN
--  'PublicationsLog'
--  PU.*,
--  VF.*
from PublicationsLog PL
join AuditLog AL on AL.AuditNo = PL.AuditNo and AL.Operation <> 'D'
join vFinancials VF on VF.PubNo = PL.PubNo
join Authors A on A.AuthorId = VF.AnalystId
--join Properties PR on PR.PubNo = PU.PubNo and PR.PropID = 5 -- Author
join Securities2 S on S.SecurityId = VF.SecurityId
where VF.RatingAction in ('Initiate', 'Upgrade', 'Downgrade')
and PL.PublishedDate >= DATEADD(day, -30, GETDATE())
and PL.Version = 1

order by 1

-- SAVE END

exec spSearchDistributionSites 1, 'a', 1, 5000, null



ALTER PROCEDURE [dbo].[spSearchDistributionSites]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
*/
