-- PortalUsage.sql
-- 09/21/2016

/*

Tables:  (Staging table to store csv columns as varchar(500) for SSIS loads)
PortalUsageStaging_TR
PortalUsageStaging_CIQ
PortalUsageStaging_FactSet
PortalUsageStaging_Bloomberg

Procedures: (Called by SSIS package)
spResetPortalUsageStaging_TR
spResetPortalUsageStaging_CIQ
spResetPortalUsageStaging_FactSet
spResetPortalUsageStaging_Bloomberg

spLoadPortalUsageFromStaging_TR
spLoadPortalUsageFromStaging_CIQ
spLoadPortalUsageFromStaging_FactSet
spLoadPortalUsageFromStaging_Bloomberg

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- Tables - Portals staging
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_TR]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_TR]
GO
CREATE TABLE [dbo].[PortalUsageStaging_TR](
  [TR DocID] [varchar](500) NULL,
  [Local DocID] [varchar](500) NULL,
  [Headline] [varchar](500) NULL,
  [# Pages] [varchar](500) NULL,
  [Ticker] [varchar](500) NULL,
  [Industry] [varchar](500) NULL,
  [Country] [varchar](500) NULL,
  [Analyst] [varchar](500) NULL,
  [TR Analyst ID] [varchar](500) NULL,
  [Local Analyst ID] [varchar](500) NULL,
  [Published Date] [varchar](500) NULL,
  [Viewed Date] [varchar](500) NULL,
  [Client Name] [varchar](500) NULL,
  [Client Company ID] [varchar](500) NULL,
  [User Name] [varchar](500) NULL,
  [Unique ID] [varchar](500) NULL,
  [User Job Role] [varchar](500) NULL,
  [User Division] [varchar](500) NULL,
  [User Email] [varchar](500) NULL,
  [User Phone] [varchar](500) NULL,
  [User Address] [varchar](500) NULL,
  [User City] [varchar](500) NULL,
  [User State] [varchar](500) NULL,
  [User Country] [varchar](500) NULL,
  [Client Address] [varchar](500) NULL,
  [Client City] [varchar](500) NULL,
  [Client State] [varchar](500) NULL,
  [Client Country] [varchar](500) NULL,
  [Client Type] [varchar](500) NULL,
  [Delivery] [varchar](500) NULL
) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_CIQ]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_CIQ]
GO
CREATE TABLE [dbo].[PortalUsageStaging_CIQ]
(
  [Download Date] [varchar](500) NULL,
  [CIQ Doc Id] [varchar](500) NULL,
  [Ctb Doc Id] [varchar](500) NULL,
  [Company] [varchar](500) NULL,
  [Company Name] [varchar](500) NULL,
  [User] [varchar](500) NULL,
  [User Name] [varchar](500) NULL,
  [Email] [varchar](500) NULL,
  [Firm Type] [varchar](500) NULL,
  [Doc Type] [varchar](500) NULL,
  [Industry] [varchar](500) NULL,
  [Analyst] [varchar](500) NULL,
  [Headline] [varchar](500) NULL,
  [Price] [varchar](500) NULL,
  [Document Posted Date] [varchar](500) NULL,
  [Type] [varchar](500) NULL,
  [Activity Type] [varchar](500) NULL,
  [Activity Id] [varchar](500) NULL,
)
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_FactSet]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_FactSet]
GO
CREATE TABLE [dbo].[PortalUsageStaging_FactSet](
  [Date/time read] [varchar](500) NULL,
  [Reader ID (FactSet)] [varchar](500) NULL,
  [Reader name] [varchar](500) NULL,
  [E-mail] [varchar](500) NULL,
  [Phone] [varchar](500) NULL,
  [Parent Firm ID (FactSet)] [varchar](500) NULL,
  [Parent Firm name] [varchar](500) NULL,
  [Firm ID (FactSet)] [varchar](500) NULL,
  [Firm name] [varchar](500) NULL,
  [Address] [varchar](500) NULL,
  [City] [varchar](500) NULL,
  [State] [varchar](500) NULL,
  [Country] [varchar](500) NULL,
  [Doc ID (contributor)] [varchar](500) NULL,
  [Doc ID (FactSet)] [varchar](500) NULL,
  [Date/time published] [varchar](500) NULL,
  [Date/time received] [varchar](500) NULL,
  [Report title] [varchar](500) NULL
) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_Bloomberg]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_Bloomberg]
GO
CREATE TABLE [dbo].[PortalUsageStaging_Bloomberg](
  [Story ID] [varchar](500) NULL,
  [Wire] [varchar](500) NULL,
  [Class] [varchar](500) NULL,
  [Customer #] [varchar](500) NULL,
  [Customer Name] [varchar](500) NULL,
  [Firm #] [varchar](500) NULL,
  [UUID] [varchar](500) NULL,
  [User Name] [varchar](500) NULL,
  [Business Email] [varchar](500) NULL,
  [Alternate Email] [varchar](500) NULL,
  [User Country] [varchar](500) NULL,
  [User State] [varchar](500) NULL,
  [User City] [varchar](500) NULL,
  [Transaction ID] [varchar](500) NULL,
  [Story Headline] [varchar](500) NULL,
  [Post Date] [varchar](500) NULL,
  [Read Date] [varchar](500) NULL,
) ON [PRIMARY]
GO

-- Procedures - Reset/Cleanup data
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_TR]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spResetPortalUsageStaging_TR]
GO

CREATE PROCEDURE [dbo].[spResetPortalUsageStaging_TR]
AS
BEGIN
SET NOCOUNT ON

DECLARE @RowsDeleted INT

DELETE FROM [dbo].[PortalUsageStaging_TR]
SET @RowsDeleted = @@ROWCOUNT
SELECT @RowsDeleted

SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_CIQ]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spResetPortalUsageStaging_CIQ]
GO

CREATE PROCEDURE [dbo].[spResetPortalUsageStaging_CIQ]
AS
BEGIN
SET NOCOUNT ON

DECLARE @RowsDeleted INT

DELETE FROM [dbo].[PortalUsageStaging_CIQ]
SET @RowsDeleted = @@ROWCOUNT
SELECT @RowsDeleted

SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_FactSet]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spResetPortalUsageStaging_FactSet]
GO

CREATE PROCEDURE [dbo].[spResetPortalUsageStaging_FactSet]
AS
BEGIN
SET NOCOUNT ON

DECLARE @RowsDeleted INT

DELETE FROM [dbo].[PortalUsageStaging_FactSet]
SET @RowsDeleted = @@ROWCOUNT
SELECT @RowsDeleted

SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_Bloomberg]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spResetPortalUsageStaging_Bloomberg]
GO

CREATE PROCEDURE [dbo].[spResetPortalUsageStaging_Bloomberg]
AS
BEGIN
SET NOCOUNT ON

DECLARE @RowsDeleted INT

DELETE FROM [dbo].[PortalUsageStaging_Bloomberg]
SET @RowsDeleted = @@ROWCOUNT
SELECT @RowsDeleted

SET NOCOUNT OFF
END
GO

-- Procedures - Reset/Cleanup data
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_TR]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
GO

CREATE PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId       INT,
@MinReadDate  VARCHAR(10),
@MaxReadDate  VARCHAR(10),
@RowsLoaded   INT

SET @SiteId = 9 -- Thomson Reuters

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_TR) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_TR STG
   WHERE YEAR(PU.ReadDate) = YEAR(STG.[Viewed Date])
   AND MONTH(PU.ReadDate)= MONTH(STG.[Viewed Date])
   AND DAY(PU.ReadDate)  = DAY(STG.[Viewed Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (PubNo, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, FirmType, Delivery)
SELECT
  CASE WHEN ISNUMERIC([Local DocID]) = 1 THEN [Local DocID] ELSE 0 END,
  CASE WHEN ISDATE([Viewed Date]) = 1 THEN [Viewed Date] ELSE NULL END,
  @SiteId,
  [User Email],
  [User Name],
  ISNULL([Unique ID],0),
  [Client Name],
  ISNULL([Client Company ID],0),
  [Client Type],
  [Delivery]
FROM [dbo].[PortalUsageStaging_TR]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @MinReadDate = CONVERT(VARCHAR, MIN(CAST([Viewed Date] AS DATE) ), 101),
       @MaxReadDate = CONVERT(VARCHAR, MAX(CAST([Viewed Date] AS DATE) ), 101)
FROM PortalUsageStaging_TR
WHERE ISDATE([Viewed Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for TR from ' + @MinReadDate + ' to ' + @MaxReadDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_CIQ]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
GO

CREATE PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId       INT,
@MinReadDate  VARCHAR(10),
@MaxReadDate  VARCHAR(10),
@RowsLoaded   INT

SET @SiteId = 11 -- Capital IQ

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_CIQ) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_CIQ STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Download Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Download Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Download Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, FirmType, Delivery)
SELECT
  [Ctb Doc Id],
  [Download Date],
  @SiteId,
  [Email],
  [User Name],
  [User],
  [Company Name],
  [Company],
  [Firm Type],
  [Activity Type]
FROM [dbo].[PortalUsageStaging_CIQ]
WHERE ISNUMERIC([Ctb Doc Id]) = 1

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @MinReadDate = CONVERT(VARCHAR, MIN(CAST([Download Date] AS DATE) ), 101),
       @MaxReadDate = CONVERT(VARCHAR, MAX(CAST([Download Date] AS DATE) ), 101)
FROM PortalUsageStaging_CIQ
WHERE ISDATE([Download Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for CIQ from ' + @MinReadDate + ' to ' + @MaxReadDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_FactSet]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
GO

CREATE PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId       INT,
@MinReadDate  VARCHAR(10),
@MaxReadDate  VARCHAR(10),
@RowsLoaded   INT

SET @SiteId = 12 -- Factset

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_FactSet) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_FactSet STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Date/time read])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Date/time read])
   AND DAY(PU.ReadDate) = DAY(STG.[Date/time read])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId)
SELECT
  [Doc ID (contributor)],
  [Date/time read],
  @SiteId,
  [E-mail],
  [Reader name],
  [Reader ID (FactSet)],
  [Firm name],
  [Firm ID (FactSet)]
FROM [dbo].[PortalUsageStaging_FactSet]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @MinReadDate = CONVERT(VARCHAR, MIN(CAST([Date/time read] AS DATE) ), 101),
       @MaxReadDate = CONVERT(VARCHAR, MAX(CAST([Date/time read] AS DATE) ), 101)
FROM PortalUsageStaging_FactSet
WHERE ISDATE([Date/time read]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for FactSet from ' + @MinReadDate + ' to ' + @MaxReadDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_Bloomberg]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
GO

CREATE PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId       INT,
@MinReadDate  VARCHAR(10),
@MaxReadDate  VARCHAR(10),
@RowsLoaded   INT

SET @SiteId = 3 -- Bloomberg

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_Bloomberg) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_Bloomberg STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId)
SELECT
  CASE WHEN ISNUMERIC([Story Id]) = 1 THEN [Story ID] ELSE 0 END AS StoryId,
  [Read Date],
  @SiteId,
  [Business Email],
  [User Name],
  CASE WHEN ISNUMERIC([UUID]) = 1 THEN [UUID] ELSE NULL END AS UUID,
  [Customer Name],
  [Customer #]
FROM [dbo].[PortalUsageStaging_Bloomberg]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @MinReadDate = CONVERT(VARCHAR, MIN(CAST([Read Date] AS DATE) ), 101),
       @MaxReadDate = CONVERT(VARCHAR, MAX(CAST([Read Date] AS DATE) ), 101)
FROM PortalUsageStaging_Bloomberg
WHERE ISDATE([Read Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Bloomberg from ' + @MinReadDate + ' to ' + @MaxReadDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO

GRANT EXECUTE ON [dbo].[spResetPortalUsageStaging_TR]             TO PowerUsers
GRANT EXECUTE ON [dbo].[spResetPortalUsageStaging_CIQ]            TO PowerUsers
GRANT EXECUTE ON [dbo].[spResetPortalUsageStaging_FactSet]        TO PowerUsers
GRANT EXECUTE ON [dbo].[spResetPortalUsageStaging_Bloomberg]      TO PowerUsers

GRANT EXECUTE ON [dbo].[spLoadPortalUsageFromStaging_TR]          TO PowerUsers
GRANT EXECUTE ON [dbo].[spLoadPortalUsageFromStaging_CIQ]         TO PowerUsers
GRANT EXECUTE ON [dbo].[spLoadPortalUsageFromStaging_FactSet]     TO PowerUsers
GRANT EXECUTE ON [dbo].[spLoadPortalUsageFromStaging_Bloomberg]   TO PowerUsers
GO

-- DEBUG

/*
-- ThomsonReuters
EXEC spResetPortalUsageStaging_TR -- 9
EXEC spLoadPortalUsageFromStaging_TR
SELECT * FROM PortalUsage WHERE SiteId = 9 ORDER BY UsageId DESC

SELECT * FROM [dbo].[PortalUsageStaging_TR] ORDER BY CAST([Viewed Date] AS DATETIME) DESC
SELECT * FROM PortalUsage WHERE SiteId = 9 ORDER BY UsageId DESC

SELECT * FROM PortalUsage WHERE SiteId = 9 ORDER BY ReadDate DESC
SELECT * FROM PortalUsage WHERE SiteId = 9 AND MONTH(ReadDate) = 9
-- Pre:   Apr - 9190, May - 9320; June - 8987;
-- Post:  Apr - 10397, May - 9790; June - 9475; July - 8725; Aug - 7266; Sept - 7953
-- TRUNCATE TABLE [dbo].[PortalUsageStaging_TR]

SELECT * FROM EventLog WHERE Source = 'Portal Usage' ORDER BY TimeStamp DESC

SELECT * FROM [Research].[dbo].[Tmp_ThomsonReutersReadership_SSIS]

*/

/*
-- CapitalIQ
EXEC spResetPortalUsageStaging_CIQ  -- 11
EXEC spLoadPortalUsageFromStaging_CIQ
SELECT  * FROM PortalUsage WHERE SiteId = 11 ORDER BY UsageId DESC

SELECT * FROM [dbo].[PortalUsageStaging_CIQ] ORDER BY CAST([Download Date] AS DATETIME) DESC
SELECT * FROM PortalUsage WHERE SiteId = 11 ORDER BY UsageId DESC

SELECT * FROM PortalUsage WHERE SiteId = 11 ORDER BY ReadDate DESC
SELECT * FROM PortalUsage WHERE SiteId = 11 AND MONTH(ReadDate) = 4
-- Pre:   Apr - 7443, May - 7119; June - 7947;
-- Post:  Apr - 7443, May - 7119; June - 7947; July - 6989; Aug - 6794; Sept - 7115
-- TRUNCATE TABLE [dbo].[PortalUsageStaging_CIQ]
*/

/*
-- Factset
EXEC spResetPortalUsageStaging_FactSet  --  12
EXEC spLoadPortalUsageFromStaging_FactSet
SELECT * FROM PortalUsage WHERE SiteId = 12 ORDER BY UsageId DESC

SELECT * FROM [dbo].[PortalUsageStaging_FactSet] ORDER BY CAST([Date/time read] AS DATETIME) desc
SELECT * FROM PortalUsage WHERE SiteId = 12 ORDER BY UsageId DESC

SELECT * FROM PortalUsage WHERE SiteId = 12 ORDER BY ReadDate DESC
SELECT * FROM PortalUsage WHERE SiteId = 12 AND MONTH(ReadDate) = 4
-- Pre:   Apr - 13913, May - 10671; June - 9262;
-- Post:  Apr - 13913, May - 10671; June - 8340; July - 8550; Aug - 8726; Sept - 10069
-- TRUNCATE TABLE [dbo].[PortalUsageStaging_FactSet]
*/

/*
-- Bloomberg
EXEC spResetPortalUsageStaging_Bloomberg  -- 3
EXEC spLoadPortalUsageFromStaging_Bloomberg
SELECT TOP 50000 * FROM PortalUsage WHERE SiteId = 3 ORDER BY UsageId DESC

SELECT * FROM [dbo].[PortalUsageStaging_Bloomberg] ORDER BY CAST([Read Date] AS DATETIME) desc
SELECT * FROM PortalUsage WHERE SiteId = 3 ORDER BY UsageId DESC

SELECT * FROM PortalUsage WHERE SiteId = 3 AND MONTH(ReadDate) = 4
-- -- DELETE FROM PortalUsage WHERE SiteId = 3 and MONTH(readdate) = 3
-- Post:  Apr - 28425, May - 26682; June - 29197; July - 26933; Aug - 23505; Sept - -
-- TRUNCATE TABLE [dbo].[PortalUsageStaging_Bloomberg]
*/

/*

-- Test partial loads (file with data for 2017 01-18, no data for 19-31
SELECT * FROM PortalUsageStaging_Bloomberg ORDER BY [Read Date] DESC
SELECT * FROM PortalUsage WHERE SiteId = 3 and YEAR(ReadDate) = 2017 and MONTH(ReadDate) = 1 ORDER BY UsageId DESC

*/

/*
-- Verify Portal Usage data
SELECT COUNT(*) FROM [dbo].[PortalUsage] where readdate >= '01/01/2016'
SELECT * FROM [dbo].[PortalUsage] where readdate >= '01/01/2016' order by readdate desc
SELECT * FROM [dbo].[PortalUsage] where siteid = 9  order by readdate desc -- ThomsonReuters
SELECT * FROM [dbo].[PortalUsage] where siteid = 3  order by readdate desc -- Bloomberg
SELECT * FROM [dbo].[PortalUsage] where siteid = 12 order by readdate desc -- Factset
SELECT * FROM [dbo].[PortalUsage] where siteid = 11 order by readdate desc -- CapitalIQ
*/

/*
SELECT TOP 1000 * FROM EventLog WHERE Source = 'Portal Usage' ORDER BY EventNo DESC
SELECT * FROM [OLE DB Destination]  ORDER BY [Activity Date] desc    -- Failure records while load
SELECT DISTINCT SiteId FROM PortalUsage
SELECT * FROM DistributionSites

sp_help PortalUsage

sp_help Tmp_CapitalIQReadership
sp_help Tmp_ThomsonReutersReadership
sp_help Tmp_BloombergReadership
sp_help Tmp_FactsetReadership

sp_help PortalUsageStaging_CIQ
sp_help PortalUsageStaging_TR
sp_help PortalUsageStaging_FactSet
sp_help PortalUsageStaging_Bloomberg

Portal Sites  [PortalUsage table]
SiteId = 11    - 'CapitalIQ'
SiteId = 12    - 'Factset'
SiteId = 3     - 'Bloomberg'
SiteId = 9     - 'ThomsonReuters'

Tmp Portal Usage tables
\\research\researchdev\Etc\sql\Research\Adhoc\PortalUsage\PortalUsageTempTables.sql

--Backup
-- SELECT * INTO PortalUsage_Prior_1116 FROM PortalUsage
SELECT COUNT(*) FROM PortalUsage
SELECT COUNT(*) FROM PortalUsage_Prior_1116
-- DELETE FROM PortalUsage

*/

/*

SELECT @MinReadDate = CONVERT(DATE, MIN([Viewed Date]), 101), @MaxReadDate = CONVERT(DATE, MAX([Viewed Date]), 101)
FROM PortalUsageStaging_TR
--FROM Tmp_ThomsonReutersReadership_SSIS
WHERE ISDATE([Viewed Date]) = 1


SELECT *
FROM PortalUsage PU
WHERE EXISTS
  (SELECT * FROM Tmp_ThomsonReutersReadership_SSIS  STG
   WHERE YEAR(PU.ReadDate) = YEAR(STG.[Viewed Date])
     AND MONTH(PU.ReadDate)= MONTH(STG.[Viewed Date])
     AND DAY(PU.ReadDate)  = DAY(STG.[Viewed Date])
  )
  ORDER BY ReadDate ASC

*/