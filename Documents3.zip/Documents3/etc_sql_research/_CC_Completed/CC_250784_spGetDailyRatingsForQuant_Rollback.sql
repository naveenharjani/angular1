-- spGetDailyRatingsForQuant_Rollback.sql
-- 05/04/2017

/*

spGetDailyRatingsForQUANT
SinceDate
UntilDate

*/

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE name = 'spGetDailyRatingsForQUANT' and TYPE = 'P')
DROP PROCEDURE [dbo].[spGetDailyRatingsForQUANT]
GO