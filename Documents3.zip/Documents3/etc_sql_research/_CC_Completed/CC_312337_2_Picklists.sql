-- Picklists.sql
-- 06/19/2019

/*

Procs used by REST api getPicklist(list, style)

spPickTickers
spPickIndustries
spPickAuthors
spPickTypes
spPickSubTypes
spPickKeywords
spPickInvestorThemes
spPickThematicTags
spPickCoverageActions
spPickRatingActions
spPickTargetPriceActions
spPickEstimateActions

*/

USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTifIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

if exists(select * from sys.objects where type = 'P' and name = 'spPickTickers')
drop proc dbo.spPickTickers
go

create procedure [dbo].[spPickTickers]
  @Style int,
  @UserId int = NULL,
  @AnalystId int = NULL
AS

/*
Styles
1 - All tickers
2 - Launched and unlaunched tickers - All analysts or specified analyst
3 - Launched tickers - All analysts or specified analyst
4 - Launched and unlaunched ticker - All analysts or specified analyst where unluanched only visible to Team Members
*/

set nocount on

declare @Analysts TABLE(AnalystId int)

-- All tickers
if @Style = 1
select
  'Value'   = S.SecurityID,
  'Display' = S.Ticker + ' / ' + S.Company
from Securities2 S
order by Display

-- Launched and unlaunched tickers - All analysts or specified analyst
else if @Style = 2
begin
if ISNULL(@AnalystId, '') = ''
  insert @Analysts select AuthorId from Authors where IsAnalyst = -1 AND IsActive = -1
else
  insert @Analysts select @AnalystId

select distinct
  'Value'   = S.SecurityID,
  'Display' =  S.Ticker + ' / ' + S.Company,
  'Ticker' =  S.Ticker
from ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
where RC.DropDate IS NULL
AND RC.AnalystId IN (select AnalystId from @Analysts)
order by Display
end

-- Launched tickers - All analysts or specified analyst
else if @Style = 3
begin
if ISNULL(@AnalystId, '') = ''
  insert @Analysts select AuthorId from Authors where IsAnalyst = -1 AND IsActive = -1
else
  insert @Analysts select @AnalystId
select distinct
  'Value'   = S.SecurityID,
  'Display' = S.Ticker
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
AND RC.AnalystId IN (select AnalystId from @Analysts)
order by Display
end

-- Launched primary tickers only - All analysts or specified analyst
else if @Style = 4
begin

if ISNULL(@AnalystId, '') = ''
  insert @Analysts select AuthorId from Authors where IsAnalyst = -1 AND IsActive = -1
else
  insert @Analysts select @AnalystId

-- Launched tickers (visible to all)
select distinct
  'Value'   = S.SecurityID,
  'Display' = S.Ticker
from ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
AND RC.AnalystId IN (select AnalystId from @Analysts)

union

-- Unlaunched tickers (visible to Team Members)
select
  'Value'   = S.SecurityID,
  'Display' = S.Ticker
from ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate IS NULL AND RC.DropDate IS NULL
AND RC.AnalystId IN (select AnalystId from @Analysts)
AND (RC.AnalystId IN (select AnalystId from AnalystTeamMembers where UserId = @UserId)
     OR
     RC.AnalystId = @UserId)
order by Display

end

set nocount off

go
if exists(select * from sys.objects where type = 'P' and name = 'spPickIndustries')
drop proc dbo.spPickIndustries
go

create procedure dbo.spPickIndustries
  @Style int
AS
if @Style = 1      select 'Value' = IndustryName, 'Display' = IndustryName from Industries order by Display
else if @Style = 2 select 'Value' = IndustryName, 'Display' = IndustryName from Industries order by Display -- FUTURE USE ACTIVE
else if @Style = 3 select 'Value' = IndustryID,   'Display' = IndustryName from Industries order by Display
else if @Style = 4 select 'Value' = IndustryID,   'Display' = IndustryName from Industries order by Display -- FUTURE USE ACTIVE
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickAuthors')
drop proc dbo.spPickAuthors
go

create procedure [dbo].[spPickAuthors]
  @Style  int,
  @Region int = 1
AS
if @Style = 1      select 'Value' = Name,     'Display' = Last + ', ' + First from Authors                                        order by Display
else if @Style = 2 select 'Value' = Name,     'Display' = Last + ', ' + First from Authors where IsActive = -1 AND IsAnalyst = -1 order by Display
else if @Style = 3 select 'Value' = AuthorID, 'Display' = Last + ', ' + First from Authors                                        order by Display
else if @Style = 4 select 'Value' = AuthorID, 'Display' = Last + ', ' + First from Authors where IsActive = -1                    order by Display
else if @Style = 5 select 'Value' = AuthorID, 'Display' = Last + ', ' + First from Authors where IsActive = -1 AND IsAnalyst = -1 AND TypeId = 1 order by Display

--Active Analysts in a region
else if @Style = 6
select distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
from Authors A JOIN ResearchCoverage RC ON A.AuthorId = RC.AnalystId
LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
where IsAnalyst = -1
AND RC.Launchdate is not null AND RC.Dropdate is null
AND R.RegionId = @Region
order by Display

--Active Analysts in all regions
else if @Style = 7
select distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
from Authors A JOIN ResearchCoverage RC ON A.AuthorId = RC.AnalystId
LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
where IsAnalyst = -1
AND RC.Launchdate is not null and RC.Dropdate is null
AND TypeId = 1
order by Display

--All Analysts in a region
else if @Style = 8
select distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
from Authors A LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
where
IsAnalyst = -1 and
R.RegionId = @Region
order by Display

--All Analysts in all regions
else if @Style = 9
select distinct 'Value' = AuthorID, 'Display' = Last + ', ' + First,'RegionId' = A.RegionId,'Region' = R.Region
from Authors A LEFT OUTER JOIN AuthorRegions R ON A.RegionId = R.RegionId
where IsAnalyst = -1
order by Display

--Used by Author/Security/Firm disclosures where Autonomous authors are displayed
else if @Style = 10
select Value, Display
from
(
  select 'Value' = '', 'Display' = 'BERNSTEIN ==========',  1 TypeId, 1 SeqNo
  union
  select 'Value' = '', 'Display' = 'AUTONOMOUS ==========',  2, 1
  union
  select 'Value' = AuthorId, 'Display' = Last + ', ' + First, ISNULL(TypeId, 1), 2
  from Authors where IsActive = -1
) V
order by TypeId, SeqNo, Display
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickTypes')
drop proc dbo.spPickTypes
go

create procedure spPickTypes
  @Style int = 1
as

select
  'Value' = PublicationTypeId,
  'Display' = case PublicationType
    when 'Research Call'  then 'Call'
    when 'External Flash' then 'Quick Take'
    when 'Black Book'     then 'Blackbook'
    when 'White Book'     then 'Whitebook'
    else PublicationType
   end,
  'SeqNo' = case PublicationType
    when 'Research Call'  then 1
    when 'External Flash' then 2
    when 'Comment'        then 3
    when 'Video'          then 4
    when 'Podcast'        then 5
    when 'Black Book'     then 6
    when 'White Book'     then 7
    when 'Lighter Side'   then 8
    else 9
   end
from PublicationTypes
order by SeqNo, Display

go

if exists(select * from sys.objects where type = 'P' and name = 'spPickSubTypes')
drop proc dbo.spPickSubTypes
go

create procedure [dbo].[spPickSubTypes]
as

select
  'Value'   = '1',
  'Display' = 'Company Report'
union all
select
  'Value'   = '2',
  'Display' = 'Industry Report'

go

if exists(select * from sys.objects where type = 'P' and name = 'spPickKeywords')
drop proc dbo.spPickKeywords
go

create procedure [dbo].[spPickKeywords]

as

select
  'Value'   = KeywordId,
  'Display' = Keyword,
  'SeqNo' = case Keyword
  when 'Blast'             then 1
  when 'Greenbook'         then 2
  when 'Primer'            then 3
  when 'Best of Bernstein' then 4
  when 'Long View'         then 5
  when 'Big Think'         then 6
  -- Blackbooks
  when 'Bernstein Disciplined-Strategies Monitor' then 10
  when 'Bernstein Quantitative Handbook'          then 11
  when 'Single Company Analysis Blackbook'        then 12
  when 'Applied Global Quantitative Strategy'     then 13
  -- Summaries
  when 'Daily Summary: Global Edition'               then 20
  when 'Research Summary: Mid and Small Cap Edition' then 21
  when 'Research Summary: UK Edition'                then 22
  when 'Daily Summary: US Edition'                   then 23
  when 'Daily Summary: Pan-European Edition'         then 24
  when 'Daily Summary: Asian Edition'                then 25
  when 'Daily Summary: Emerging Markets Edition'     then 26
    else 100
   end
from Keywords
order by SeqNo, Display

go

if exists(select * from sys.objects where type = 'P' and name = 'spPickInvestorThemes')
drop proc dbo.spPickInvestorThemes
go

create procedure [dbo].[spPickInvestorThemes]
  @Style int = 3
as

select 'Value' = InvestorThemeId, 'Display' = InvestorTheme from InvestorThemes where IsLive = 'Y' order by SeqNo

/*
if @Style = 1      select 'Value' = InvestorTheme,   'Display' = InvestorTheme from InvestorThemes order by Display
else if @Style = 2 select 'Value' = InvestorThemeId, 'Display' = InvestorTheme from InvestorThemes order by Display
else if @Style = 3 select 'Value' = InvestorThemeId, 'Display' = InvestorTheme from InvestorThemes where Active = -1 order by SeqNo
*/

go

if exists(select * from sys.objects where type = 'P' and name = 'spPickThematicTags')
drop proc dbo.spPickThematicTags
go

create procedure [dbo].[spPickThematicTags]
  @Style int = 1
as

select
  'Value'   = ThematicTagId,
  'Display' = PR.PropValue,
   max(PU.Date)
from ThematicTags TT
join Properties PR on PR.PropValue = TT.ThematicTag and PR.PropId = 41
join Publications PU on PU.PubNo = PR.PubNo -- and PR.PropId = 41 -- Thematictag
where PR.PropValue <> ''
group by PR.PropValue, TT.ThematicTagId
order by 3 desc

go

if exists(select * from sys.objects where type = 'P' and name = 'spPickCoverageActions')
drop proc dbo.spPickCoverageActions
go

create proc dbo.spPickCoverageActions
as
begin
  select 'Value' = 'INITIATE', 'Display' = 'Coverage Initiate' , 'SeqNo' = 1
  union
  select 'Value' = 'DROP', 'Display' = 'Coverage Drop' , 'SeqNo' = 2
  union
  select 'Value' = 'SUSPend', 'Display' = 'Coverage Suspend' , 'SeqNo' = 3
  union
  select 'Value' = 'RESUME', 'Display' = 'Coverage Resume' , 'SeqNo' = 4
  order by 3
end
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickRatingActions')
drop proc dbo.spPickRatingActions
go

create proc dbo.spPickRatingActions
as
begin
  select 'Value' = 'UPGRADE', 'Display' = 'Rating Upgrade' , 'SeqNo' = 1
  union
  select 'Value' = 'DOWNGRADE', 'Display' = 'Rating Downgrade' , 'SeqNo' = 2
  union
  select 'Value' = 'REITERATE', 'Display' = 'Rating Reiterate' , 'SeqNo' = 3
  union
  select 'Value' = 'INITIATE', 'Display' = 'Rating Initiate' , 'SeqNo' = 4
  union
  select 'Value' = 'DROP', 'Display' = 'Rating Drop' , 'SeqNo' = 5
  order by 3
end
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickTargetPriceActions')
drop proc dbo.spPickTargetPriceActions
go

create proc dbo.spPickTargetPriceActions
as
begin
  select 'Value' = 'INCREASE', 'Display' = 'TargetPrice Increase' , 'SeqNo' = 1
  union
  select 'Value' = 'DECREASE', 'Display' = 'TargetPrice Decrease' , 'SeqNo' = 2
  union
  select 'Value' = 'UPDATE', 'Display' = 'TargetPrice Update' , 'SeqNo' = 3
  order by 3
end
go

if exists(select * from sys.objects where type = 'P' and name = 'spPickEstimateActions')
drop proc dbo.spPickEstimateActions
go

create proc dbo.spPickEstimateActions
as
begin
  select 'Value' = 'UPGRADE', 'Display' = 'Estimate Upgrade' , 'SeqNo' = 1
  union
  select 'Value' = 'DOWNGRADE', 'Display' = 'Estimate Downgrade' , 'SeqNo' = 2
  union
  select 'Value' = 'REITERATE', 'Display' = 'Estimate Reiterate' , 'SeqNo' = 3
  order by 3
end
go

grant execute on spPickTickers            to DE_IIS, PowerUsers
grant execute on spPickIndustries         to DE_IIS, PowerUsers
grant execute on spPickAuthors            to DE_IIS, PowerUsers
grant execute on spPickTypes              to DE_IIS, PowerUsers
grant execute on spPickSubTypes           to DE_IIS, PowerUsers
grant execute on spPickKeywords           to DE_IIS, PowerUsers
grant execute on spPickInvestorThemes     to DE_IIS, PowerUsers
grant execute on spPickThematicTags       to DE_IIS, PowerUsers
grant execute on spPickCoverageActions    to DE_IIS, PowerUsers
grant execute on spPickRatingActions      to DE_IIS, PowerUsers
grant execute on spPickTargetPriceActions to DE_IIS, PowerUsers
grant execute on spPickEstimateActions    to DE_IIS, PowerUsers
go

/*

DEBUG

-- LEGACY

sp_helptext spRenderTypes

sp_helptext spRenderTickers

sp_helptext spRenderInvestorThemes

spRenderTypes

spRenderSubTypes

spRenderInvestorThemes 3

spRenderTickers 1

select * from InvestorThemes where Active = -1 order by SeqNo

-- NEW

spPickTypes
go

spPickSubTypes
go

spPickKeywords
go

spPickInvestorThemes 3
go

spPickThematicTags 1
go

spPickCoverageActions
go

spPickRatingActions
go

spPickTargetPriceActions
go

spPickEstimateActions
go

*/
