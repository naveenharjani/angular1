-- CC_x_4_ModelDistribution.sql
-- 06/12/2018

/*

create ModelDistributionQueue        - New table which holds distribution queue items for models
create spSaveModelSchedulerState     - New proc which saves state of ModelDistributionQueue item
create spUpdateModelDistributionItem - New proc to update status of ModelDistributionQueue item

alter spSaveModel                    - Alter to insert row into ModelDistributionQueue
alter spUpdateDistributionItem       - Alter to update LinkBank column in DistributionQueue table
alter spGetFTPLogin                  - 
alter spGetDistributionDetail        - Alter to display only research sites on distribution detail page
alter spGetDistributionSummary       - Alter to include ModelDistributionQueue items, include SiteType, LinkBack columns
alter spSearchDistributionSites      - Alter to include SiteType,LinkBack columns from DistributionSites table

*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ModelDistributionQueue]') AND type in (N'U'))
DROP TABLE [dbo].[ModelDistributionQueue]
GO

CREATE TABLE [dbo].[ModelDistributionQueue]
(
  [DistributionId] [int]      NOT NULL IDENTITY(1,1),
  [ModelId]        [int]      NOT NULL,
  [SiteId]         [int]      NOT NULL,
  [Operation]      [char](1)  NOT NULL,
  [Queued]         [datetime] NOT NULL,
  [Scheduled]      [datetime]     NULL,
  [Completed]      [datetime]     NULL,
  [Cancelled]      [datetime]     NULL,
  [RetryCount]     [int]          NULL
 CONSTRAINT [PK_ModelDistributionQueue] PRIMARY KEY CLUSTERED ([DistributionId] ASC)
)
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spSaveModelSchedulerState]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spSaveModelSchedulerState]
GO

CREATE PROCEDURE dbo.spSaveModelSchedulerState
  @DistributionId int,
  @SchedulerMaxNormalRetries int,
  @SchedulerDelayMinutes int
AS
DECLARE @CurrentRetryCount  int

--Initial retry count is 0, meaning initial error.
IF EXISTS (SELECT DistributionId FROM ModelDistributionQueue WHERE DistributionId = @DistributionId and RetryCount is null)
  UPDATE ModelDistributionQueue SET RetryCount = 0 WHERE DistributionId = @DistributionId
ELSE
  UPDATE ModelDistributionQueue SET RetryCount = RetryCount + 1 WHERE DistributionId = @DistributionId

--Further Delay the ScheduleTime for the Failed Distribution
--At this point, service window should not be of concern.

SELECT @CurrentRetryCount = RetryCount
FROM ModelDistributionQueue WHERE DistributionId = @DistributionId

IF @CurrentRetryCount > @SchedulerMaxNormalRetries
  UPDATE ModelDistributionQueue SET Scheduled = DATEADD(mi, @SchedulerDelayMinutes, Scheduled) WHERE DistributionId = @DistributionId

GO

if exists(select * from Sys.Objects where type = 'P' and name = 'spUpdateModelDistributionItem')
drop proc dbo.spUpdateModelDistributionItem
go

create procedure dbo.spUpdateModelDistributionItem
  @DistributionId  int,
  @SiteId          int,
  @ColumnName      varchar(15)
AS

if @ColumnName = 'Completed'
  update ModelDistributionQueue
  set Completed = GETDATE()
  where DistributionId = @DistributionId AND SiteId = @SiteId

if @ColumnName = 'Cancelled'
  update DistributionQueue
  set Cancelled = GETDATE()
  where DistributionId = @DistributionId AND SiteId = @SiteId

go

alter proc [dbo].[spSaveModel] (@ModelId int, @SecurityId int, @CoverageId int, @PubNo int, @FileName varchar(30), @FileNameOrig varchar(100), @FileSize int, @ActionId int, @UserName varchar(10))
as
begin try
  begin transaction

  declare @PrimarySecurityId int
  declare @AnalystId int
  declare @UserId int
  declare @Now datetime

  set @Now = GETDATE()

  if @UserName is null or @UserName = ''
  select @UserId = 0
  else
  select top 1 @UserId = UserId from Users where UserName like '%' + @UserName+ '%'

  select @PrimarySecurityId = SecurityId from Securities2
  where CompanyId = (select CompanyId from Securities2 where SecurityId = @SecurityId)
  and IsPrimary = 'Y'

  select @AnalystId = AnalystId from ResearchCoverage where CoverageId = @CoverageId

  update Models
  set StateId = 2
  from Models M
  where SecurityId = @PrimarySecurityId and StateId = 1

  insert into Models(ModelId,CoverageId,AnalystId,SecurityId,PubNo,FileName,FileNameOrig,FileSize,ActionId,StateId,EditorId,EditDate)
  select
    @ModelId,
    @CoverageId,
    @AnalystId,
    @PrimarySecurityId,
    @PubNo,
    @FileName,
    @FileNameOrig,
    @FileSize,
    @ActionId,
    1,
    @UserId,
    @Now

  insert into ModelDistributionQueue(ModelId, SiteId, Operation, Queued, Scheduled)
  select @ModelId, SiteId, 'C', @Now, Dateadd(mi,20,@Now)
  from DistributionSites
  where SiteType = 'M' and Active = -1

  select 0 ReturnValue
  commit
end try
begin catch
    if @@TRANCOUNT > 0
      rollback
    -- Raise an error with the details of the exception
    declare @ErrMsg nvarchar(4000), @ErrSeverity int
    select @ErrMsg = ERROR_MESSAGE(), @ErrSeverity = ERROR_SEVERITY()

    select -1 ReturnValue
    raiserror(@ErrMsg, @ErrSeverity, 1)
end catch

GO

ALTER PROCEDURE dbo.spUpdateDistributionItem
  @DistributionId  int,
  @SiteId          int,
  @ColumnName      varchar(15)
AS

IF @ColumnName = 'Transferred'
  UPDATE DistributionQueue
  SET Transferred = GETDATE(), LinkBack = CASE WHEN DSI.LinkBack = -1  AND DSI.LinkSourceId is not null THEN -1 ELSE 0 END
  FROM DistributionSites DSI JOIN DistributionQueue DQ ON DSI.SiteId = DQ.SiteId
  WHERE DQ.DistributionId = @DistributionId AND DSI.SiteId = @SiteId

IF @ColumnName = 'Cancelled'
  UPDATE DistributionQueue
  SET Cancelled = GETDATE()
  WHERE DistributionId = @DistributionId AND SiteId = @SiteId

GO

-- =================================================================================================
-- Author:      Krishna, Josyula
-- Modified By: Sandarsh
-- Modified On: 06/15/2018
-- Description: Get FTP Login Details based on SiteId, Added WatermarkText Column for Model Distribution.
-- =================================================================================================
alter procedure dbo.spGetFTPLogin
  @SiteId     int
AS
select FtpLogon, FtpPassword, FtpFolder, ScbFolder, FtpType, FtpPort, WatermarkText
from DistributionSites where SiteId = @SiteId
GO

ALTER PROCEDURE [dbo].[spGetDistributionDetail]
  @PubNo int
AS
SELECT
  DQ.PubNo,
  DQ.DistributionId,
  S.SiteId,  -- NEED ID FROM SITES TABLE TO INCLUDE POTENTIAL NEW DISTRIBUTION
  S.Site,
  CONVERT(varchar, DQ.Approved, 101)  + ' ' + SUBSTRING(CONVERT(varchar, DQ.Approved,  108), 1, LEN(CONVERT(varchar, DQ.Approved,  108)) - 3),
  CONVERT(varchar, DQ.Scheduled, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Scheduled, 108), 1, LEN(CONVERT(varchar, DQ.Scheduled, 108)) - 3),
  CASE DQ.Operation
    WHEN 'C' THEN
      CASE
        WHEN DQ.IsException = -1      THEN 'Excluded'
        WHEN DQ.Cancelled IS NOT NULL THEN 'Cancelled '   + CONVERT(varchar, DQ.Cancelled,   101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Cancelled,   108), 1, LEN(CONVERT(varchar, DQ.Cancelled,   108)) - 3)
        ELSE                               'Contributed ' + CONVERT(varchar, DQ.Transferred, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Transferred, 108), 1, LEN(CONVERT(varchar, DQ.Transferred, 108)) - 3)
      END
    WHEN 'D' THEN
      CASE
        WHEN DQ.Cancelled IS NOT NULL THEN 'Cancelled '    + CONVERT(varchar, DQ.Cancelled,   101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Cancelled,   108), 1, LEN(CONVERT(varchar, DQ.Cancelled,   108)) - 3)
        ELSE                               'Recalled '     + CONVERT(varchar, DQ.Transferred, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Transferred, 108), 1, LEN(CONVERT(varchar, DQ.Transferred, 108)) - 3)
      END
  END AS Status,
  'Out' =
    CASE
      WHEN DQ.Transferred IS NOT NULL THEN
        CASE
          WHEN DF.FileType = 'K' AND LEN(DF.FileVersion) = 1 THEN S.ScbFolder + '\' + CONVERT(varchar, DF.DistributionId) + '.' + DF.FileType + '0' + CONVERT(varchar, DF.FileVersion) + '.txt'
          WHEN DF.FileType = 'K' AND LEN(DF.FileVersion) > 1 THEN S.ScbFolder + '\' + CONVERT(varchar, DF.DistributionId) + '.' + DF.FileType + CONVERT(varchar, DF.FileVersion) + '.txt'
          WHEN DF.FileType = 'XML' THEN S.ScbFolder + '\' + CONVERT(varchar, DF.DistributionId) + '.' + DF.FileType
          ELSE S.ScbFolder + '\' + CONVERT(varchar, DF.DistributionId) + '.' + DF.FileType + '.txt'
        END
      ELSE NULL
    END,
  CASE DQ.Operation
    WHEN 'C' THEN 'SEND'
    WHEN 'D' THEN 'RECALL'
  END AS Operation,
  S.Active   -- FOR ASP SUPPORT:  DETERMINES THE NEED TO DISPLAY SEND/RECALL/CANCEL LINKS UNDER "OPTIONS" COLUMN
FROM DistributionSites S
LEFT JOIN DistributionQueue DQ ON DQ.SiteId = S.SiteId AND DQ.PubNo = @PubNo
LEFT JOIN DistributionFiles DF ON DF.DistributionId = DQ.DistributionId AND DF.FileType IN ('HDM', 'XML', 'K', 'CTL', 'CTLD')
WHERE (S.Active = -1 OR S.SiteId = DQ.SiteId) -- DISPLAY PREVIOUSLY DISTRIBUTED BUT NOT ACTIVE ANYMORE
AND S.SiteType = 'R'
ORDER BY DQ.PubNo DESC, S.Site ASC, DQ.DistributionId DESC
GO

ALTER PROCEDURE [dbo].[spGetDistributionSummary]
  @SiteId       int,
  @Since         datetime,
  @Until         datetime
AS
SELECT
  DQ.PubNo,
  DQ.DistributionId,
  DQ.SiteId,
  S.Site,
  CONVERT(varchar, DQ.Approved, 101)  + ' ' + SUBSTRING(CONVERT(varchar, DQ.Approved, 108), 1, LEN(CONVERT(varchar, DQ.Approved, 108)) - 3) Approved,
  CONVERT(varchar, DQ.Scheduled, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Scheduled, 108), 1, LEN(CONVERT(varchar, DQ.Scheduled, 108)) - 3) Scheduled,
  CASE DQ.Operation
    WHEN 'C' THEN
      CASE
        WHEN DQ.IsException = -1      THEN 'Excluded'
        WHEN DQ.Cancelled IS NOT NULL THEN 'Cancelled '   + CONVERT(varchar, DQ.Cancelled,   101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Cancelled, 108), 1, LEN(CONVERT(varchar, DQ.Cancelled, 108)) - 3)
        ELSE                               'Contributed ' + CONVERT(varchar, DQ.Transferred, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Transferred, 108), 1, LEN(CONVERT(varchar, DQ.Transferred, 108)) - 3)
      END
    WHEN 'D' THEN
      CASE
        WHEN DQ.Cancelled IS NOT NULL THEN 'Cancelled '    + CONVERT(varchar, DQ.Cancelled,   101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Cancelled, 108), 1, LEN(CONVERT(varchar, DQ.Cancelled, 108)) - 3)
        ELSE                               'Recalled  '    + CONVERT(varchar, DQ.Transferred, 101) + ' ' + SUBSTRING(CONVERT(varchar, DQ.Transferred, 108), 1, LEN(CONVERT(varchar, DQ.Transferred, 108)) - 3)
      END
  END AS Status,
  Transferred,
  S.SiteType,
  DQ.LinkBack
FROM DistributionQueue DQ
JOIN DistributionSites S ON S.SiteId = DQ.SiteId
WHERE (S.SiteId & @SiteId = @SiteId) AND DQ.Approved BETWEEN @Since AND @Until + 1
AND DQ.DistributionId IN -- FOR SUMMARY PURPOSES, DISPLAY ONLY THE LATEST DISTRIBUTION STATUS PER PUBNO PER SITE
  (SELECT MAX(DQ.DistributionId) FROM DistributionQueue DQ WHERE DQ.Approved BETWEEN @Since AND @Until + 1 GROUP BY DQ.PubNo, DQ.SiteId)

UNION ALL

SELECT
  MDQ.ModelId,
  MDQ.DistributionId,
  MDQ.SiteId,
  S.Site,
  CONVERT(varchar, MDQ.Queued, 101)  + ' ' + SUBSTRING(CONVERT(varchar, MDQ.Queued, 108), 1, LEN(CONVERT(varchar, MDQ.Queued, 108)) - 3) Approved,
  CONVERT(varchar, MDQ.Scheduled, 101) + ' ' + SUBSTRING(CONVERT(varchar, MDQ.Scheduled, 108), 1, LEN(CONVERT(varchar, MDQ.Scheduled, 108)) - 3) Scheduled,
  CASE MDQ.Operation
    WHEN 'C' THEN
      CASE
        WHEN MDQ.Cancelled IS NOT NULL THEN 'Cancelled '   + CONVERT(varchar, MDQ.Cancelled,   101) + ' ' + SUBSTRING(CONVERT(varchar, MDQ.Cancelled, 108), 1, LEN(CONVERT(varchar, MDQ.Cancelled, 108)) - 3)
        ELSE                                'Contributed ' + CONVERT(varchar, MDQ.Completed, 101) + ' ' + SUBSTRING(CONVERT(varchar, MDQ.Completed, 108), 1, LEN(CONVERT(varchar, MDQ.Completed, 108)) - 3)
      END
    WHEN 'D' THEN
      CASE
        WHEN MDQ.Cancelled IS NOT NULL THEN 'Cancelled '    + CONVERT(varchar, MDQ.Cancelled,   101) + ' ' + SUBSTRING(CONVERT(varchar, MDQ.Cancelled, 108), 1, LEN(CONVERT(varchar, MDQ.Cancelled, 108)) - 3)
        ELSE                                'Recalled  '    + CONVERT(varchar, MDQ.Completed, 101) + ' ' + SUBSTRING(CONVERT(varchar, MDQ.Completed, 108), 1, LEN(CONVERT(varchar, MDQ.Completed, 108)) - 3)
      END
  END AS Status,
  Completed,
  S.SiteType,
  null LinkBack
FROM ModelDistributionQueue MDQ
JOIN DistributionSites S ON S.SiteId = MDQ.SiteId
WHERE (S.SiteId & @SiteId = @SiteId) AND MDQ.Queued BETWEEN @Since AND @Until + 1
ORDER BY Scheduled DESC, Transferred DESC, PubNo DESC, Site ASC
GO

ALTER PROCEDURE [dbo].[spSearchDistributionSites]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'
CREATE TABLE #TmpSearch
(
  ID             int IDENTITY,
  SiteId         int          NOT NULL,
  Site           varchar(32)  NOT NULL,
  Model          char(4)      NOT NULL,
  Adapter        varchar(16)  NOT NULL,
  Codeset        varchar(16)  NOT NULL,
  FtpLogon       varchar(64)  NOT NULL,
  FtpPassword    varchar(64)  NOT NULL,
  FtpFolder      varchar(100) NOT NULL,
  ScbFolder      varchar(100) NOT NULL,
  RixmlOrgIdType varchar(100)     NULL,
  RixmlOrgId     varchar(100)     NULL,
  WatermarkText  varchar(100)     NULL,
  UseSchedule    int          NOT NULL,
  Active         int          NOT NULL,
  Min            datetime         NULL,
  Max            datetime         NULL,
  Num            int              NULL,
  Editor         varchar(36)      NULL,
  EditDate       datetime         NULL,
  LinkBack       int              NULL,
  SiteType       char(1)          NULL,
)
INSERT INTO #TmpSearch (SiteId, Site, Model, Adapter, Codeset, FtpLogon, FtpPassword, FtpFolder, ScbFolder, RixmlOrgIdType, RixmlOrgId, WatermarkText, UseSchedule, Active, Min, Max, Num, Editor, EditDate, LinkBack, SiteType)
EXEC
('
SELECT
  SI.SiteId,
  SI.Site,
  SI.Model,
  AD.Adapter,
  SI.Codeset,
  SI.FtpLogon,
  SI.FtpPassword,
  SI.FtpFolder,
  SI.ScbFolder,
  SI.RixmlOrgIdType,
  SI.RixmlOrgId,
  SI.WatermarkText,
  SI.UseSchedule,
  SI.Active,
  Min = (SELECT MIN(Transferred) FROM DistributionQueue WHERE SiteId = SI.SiteId AND Transferred IS NOT NULL),
  Max = (SELECT MAX(Transferred) FROM DistributionQueue WHERE SiteId = SI.SiteId AND Transferred IS NOT NULL),
  Num = (SELECT COUNT(*) FROM DistributionQueue WHERE SiteId = SI.SiteId),
  E.UserName,
  SI.EditDate,
  SI.LinkBack,
  SI.SiteType
FROM DistributionSites SI
JOIN DistributionAdapters AD ON AD.AdapterID = SI.AdapterID
LEFT JOIN Users E ON E.UserID = SI.EditorID
ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT SiteId, Site, Model, Adapter, Codeset, FtpLogon, FtpPassword, FtpFolder, ScbFolder, RixmlOrgIdType, RixmlOrgId, WatermarkText, UseSchedule, Active, Min, Max, Num, Editor, EditDate, LinkBack, SiteType
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF
GO

GRANT EXECUTE ON dbo.spSaveModelSchedulerState      TO DE_IIS,PowerUsers
GRANT EXECUTE ON dbo.spUpdateModelDistributionItem  TO DE_IIS,PowerUsers
GO
