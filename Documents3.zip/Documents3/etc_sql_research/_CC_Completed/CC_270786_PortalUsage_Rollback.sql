-- PortalUsage_Rollback.sql
-- 12/20/2017

/*
-- Factset - rollback schema to remove 'Platform' column (Delivery Type)
-- Blue Matrix - new portal usage load

Table:  (Staging table to store csv columns as varchar(500) for SSIS loads)
Rollback Table PortalUsageStaging_FactSet
Drop Table PortalUsageStaging_BlueMatrix
Drop Table PortalLoadLog

Procedures: (Called by SSIS package)
Rollback spLoadPortalUsageFromStaging_FactSet
Drop spResetPortalUsageStaging_BlueMatrix
Drop spLoadPortalUsageFromStaging_BlueMatrix
Drop spLoadPortalLoadLog
Rollback spLoadPortalUsageFromStaging_TR
Rollback spLoadPortalUsageFromStaging_Bloomberg
Rollback spLoadPortalUsageFromStaging_CIQ

-- Called by PortalUsageLoad UI
Rollback spGetPortals
Rollback spGetPortalUsageLoadHistory
*/

USE Research
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_FactSet]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_FactSet]
GO
CREATE TABLE [dbo].[PortalUsageStaging_FactSet](
	[Date/time read] [varchar](500) NULL,
	[Reader ID (FactSet)] [varchar](500) NULL,
	[Reader name] [varchar](500) NULL,
	[E-mail] [varchar](500) NULL,
	[Phone] [varchar](500) NULL,
	[Parent Firm ID (FactSet)] [varchar](500) NULL,
	[Parent Firm name] [varchar](500) NULL,
	[Firm ID (FactSet)] [varchar](500) NULL,
	[Firm name] [varchar](500) NULL,
	[Address] [varchar](500) NULL,
	[City] [varchar](500) NULL,
	[State] [varchar](500) NULL,
	[Country] [varchar](500) NULL,
	[Doc ID (contributor)] [varchar](500) NULL,
	[Doc ID (FactSet)] [varchar](500) NULL,
	[Date/time published] [varchar](500) NULL,
	[Date/time received] [varchar](500) NULL,
	[Report title] [varchar](500) NULL
) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalUsageStaging_BlueMatrix]') AND type in (N'U'))
DROP TABLE [dbo].[PortalUsageStaging_BlueMatrix]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PortalLoadLog]') AND type in (N'U'))
DROP TABLE [dbo].[PortalLoadLog]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalLoadLog]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spLoadPortalLoadLog]
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_FactSet]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT

SET @SiteId = 12 -- Factset

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_FactSet) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_FactSet STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Date/time read])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Date/time read])
   AND DAY(PU.ReadDate) = DAY(STG.[Date/time read])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId)
SELECT
  [Doc ID (contributor)],
  [Date/time read],
  @SiteId,
  [E-mail],
  [Reader name],
  [Reader ID (FactSet)],
  [Firm name],
  [Firm ID (FactSet)]
FROM [dbo].[PortalUsageStaging_FactSet]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Date/time read] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Date/time read] AS DATE) ), 101)
FROM PortalUsageStaging_FactSet
WHERE ISDATE([Date/time read]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for FactSet from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

INSERT INTO PortalUsageLoadLog
(SiteId, PeriodStart, PeriodEnd, RowsLoaded, EditorId, EditDate)
VALUES (@SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, getdate())

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spResetPortalUsageStaging_BlueMatrix]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spResetPortalUsageStaging_BlueMatrix]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spLoadPortalUsageFromStaging_BlueMatrix]') AND type in (N'P'))
DROP PROCEDURE [dbo].[spLoadPortalUsageFromStaging_BlueMatrix]
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_TR]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT

SET @SiteId = 9 -- Thomson Reuters

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_TR) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_TR STG
   WHERE YEAR(PU.ReadDate) = YEAR(STG.[Viewed Date])
   AND MONTH(PU.ReadDate)= MONTH(STG.[Viewed Date])
   AND DAY(PU.ReadDate)  = DAY(STG.[Viewed Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (PubNo, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, FirmType, Delivery)
SELECT
  CASE WHEN ISNUMERIC([Local DocID]) = 1 THEN [Local DocID] ELSE 0 END,
  CASE WHEN ISDATE([Viewed Date]) = 1 THEN [Viewed Date] ELSE NULL END,
  @SiteId,
  [User Email],
  [User Name],
  ISNULL([Unique ID],0),
  [Client Name],
  ISNULL([Client Company ID],0),
  [Client Type],
  [Delivery]
FROM [dbo].[PortalUsageStaging_TR]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Viewed Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Viewed Date] AS DATE) ), 101)
FROM PortalUsageStaging_TR
WHERE ISDATE([Viewed Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for TR from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

INSERT INTO PortalUsageLoadLog
(SiteId, PeriodStart, PeriodEnd, RowsLoaded, EditorId, EditDate)
VALUES (@SiteId,  @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, getdate())

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_Bloomberg]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT

SET @SiteId = 3 -- Bloomberg

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_Bloomberg) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_Bloomberg STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Read Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Read Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Read Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId)
SELECT
  CASE WHEN ISNUMERIC([Story Id]) = 1 THEN [Story ID] ELSE 0 END AS StoryId,
  [Read Date],
  @SiteId,
  [Business Email],
  [User Name],
  CASE WHEN ISNUMERIC([UUID]) = 1 THEN [UUID] ELSE NULL END AS UUID,
  [Customer Name],
  [Customer #]
FROM [dbo].[PortalUsageStaging_Bloomberg]

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Read Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Read Date] AS DATE) ), 101)
FROM PortalUsageStaging_Bloomberg
WHERE ISDATE([Read Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for Bloomberg from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

INSERT INTO PortalUsageLoadLog
(SiteId, PeriodStart, PeriodEnd, RowsLoaded, EditorId, EditDate)
VALUES (@SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, getdate())

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO

ALTER PROCEDURE [dbo].[spLoadPortalUsageFromStaging_CIQ]
  @UserId INT = 0
AS
BEGIN
SET NOCOUNT ON

-- Load (or re-load) PortalUsage table for dates that exist in staging table

DECLARE
@SiteId           INT,
@PeriodStartDate  VARCHAR(10),
@PeriodEndDate    VARCHAR(10),
@RowsLoaded       INT

SET @SiteId = 11 -- Capital IQ

IF NOT EXISTS (SELECT * FROM PortalUsageStaging_CIQ) RETURN

-- Delete PortalUsage data for dates that exists in staging table
DELETE PU
FROM PortalUsage PU
WHERE PU.SiteId = @SiteId
AND EXISTS
  (SELECT * FROM PortalUsageStaging_CIQ STG
   WHERE MONTH(PU.ReadDate) = MONTH(STG.[Download Date])
   AND YEAR(PU.ReadDate) = YEAR(STG.[Download Date])
   AND DAY(PU.ReadDate) = DAY(STG.[Download Date])
  )

-- Load into PortalUsage table from staging
INSERT INTO PortalUsage (Pubno, ReadDate, SiteId, Email, Contact, ContactId, Account, AccountId, FirmType, Delivery)
SELECT
  [Ctb Doc Id],
  [Download Date],
  @SiteId,
  [Email],
  [User Name],
  [User],
  [Company Name],
  [Company],
  [Firm Type],
  [Activity Type]
FROM [dbo].[PortalUsageStaging_CIQ]
WHERE ISNUMERIC([Ctb Doc Id]) = 1

SET @RowsLoaded = @@ROWCOUNT

-- Log the load details
SELECT @PeriodStartDate = CONVERT(VARCHAR, MIN(CAST([Download Date] AS DATE) ), 101),
       @PeriodEndDate = CONVERT(VARCHAR, MAX(CAST([Download Date] AS DATE) ), 101)
FROM PortalUsageStaging_CIQ
WHERE ISDATE([Download Date]) = 1

INSERT INTO [dbo].EventLog(Type, TimeStamp, Source, Message)
VALUES ('I', getdate(), 'Portal Usage', 'Usage loaded for CIQ from ' + @PeriodStartDate + ' to ' + @PeriodEndDate + ' (' + FORMAT(@RowsLoaded, '###,##') + ' rows)')

INSERT INTO PortalUsageLoadLog
(SiteId, PeriodStart, PeriodEnd, RowsLoaded, EditorId, EditDate)
VALUES (@SiteId, @PeriodStartDate, @PeriodEndDate, @RowsLoaded, @UserId, getdate())

SELECT @RowsLoaded

SET NOCOUNT OFF
END
GO

ALTER PROCEDURE [dbo].[spGetPortals]
AS

SELECT SiteId, Site FROM DistributionSites WHERE SiteId IN (3, 9, 11, 12)


GO

ALTER PROCEDURE [dbo].[spGetPortalUsageLoadHistory]
  @SiteId int = NULL
AS

SELECT TOP 10
  PL.PortalUsageLoadLogId,
  PL.SiteId,
  DS.Site AS Portal,
  PL.PeriodStart,
  PL.PeriodEnd,
  FORMAT(PL.RowsLoaded, '#,##0') AS RowsLoaded,
  U.UserName,
  PL.EditorId,
  PL.EditDate
FROM PortalUsageLoadLog PL
JOIN DistributionSites DS ON DS.SiteId = PL.SiteId
JOIN Users U ON U.UserId = PL.EditorId
WHERE
(
  PL.SiteId = @SiteId
  OR
  (ISNULL(@SiteId, '') = '' AND PL.SiteId in ( SELECT SiteId FROM DistributionSites) )
)

ORDER BY PL.EditDate DESC

GO
