-- CC_HoldingsApi.sql
-- 12/03/2018

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' and name = 'spGetAuthorHoldings')
DROP PROC dbo.spGetAuthorHoldings
GO
CREATE PROCEDURE dbo.spGetAuthorHoldings(@DocXML xml)
AS
BEGIN

DECLARE  @hDoc int,
    @RowId float,
    @AuthorId int,
    @SecurityId int,
    @PrevAuthorId int,
    @PrevSecurityId int,
    @Author varchar(48),
    @Ticker varchar(15),
    @Company varchar(63),
    @Text varchar(5000),
    @DisclosureText varchar(max)

EXEC sp_xml_preparedocument @hDoc OUTPUT, @DocXML

SET NOCOUNT ON

  --Retrieve authors from document xml
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS AuthorRowNumber, AuthorId, Name
  INTO #TmpAuthorCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Authors/Author', 1)
  WITH (authorid        int         '@id',
        name            varchar(200) '@name'
        )

--Retrieve tickers from document xml
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS TickerRowNumber, X.SecurityId, X.Ticker
  INTO #TmpTickerCollection
  FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
  WITH (securityId      int         '@id',
        ticker          varchar(30) '@ticker'
        ) X JOIN Securities2 S ON X.Ticker = S.Ticker
  WHERE S.TickerType = 'STOCK'

  --Cross product of Authors & Tickers.
  --This is needed to retrieve author holdings for each ticker on the report
  --Note that analyst holdings for all tickers on the report (covered & non-covered) need to be reported
SELECT convert(float,convert(varchar,AuthorRowNumber) + convert(varchar,TickerRowNumber)) RowId, AuthorId, SecurityId
INTO #TmpAuthorTickerCombinations
FROM
#TmpAuthorCollection TA,  #TmpTickerCollection TT

--Temp holdings table for analyst and tickers
SELECT RowId,Text
INTO #TmpHoldings
FROM
  #TmpAuthorTickerCombinations T JOIN vHoldings V ON T.AuthorId = V.AuthorId and T.SecurityId = V.SecurityId

--loop through temp holdings table to build output text
SELECT @DisclosureText = '', @Text = ''
SELECT TOP 1 @RowId = RowId, @Text = Text FROM #TmpHoldings ORDER BY RowId
WHILE @@ROWCOUNT = 1
BEGIN
  IF @Text <> ''
  BEGIN
    SET @DisclosureText = @DisclosureText + @Text + '.' + char(10)
  END
  SET @Text = ''
  SELECT TOP 1 @RowId = RowId, @Text = Text FROM #TmpHoldings WHERE RowId > @RowId ORDER BY RowId
END
SELECT @DisclosureText DisclosureText
DROP TABLE #TmpAuthorCollection
DROP TABLE #TmpTickerCollection
DROP TABLE #TmpAuthorTickerCombinations
DROP TABLE #TmpHoldings
END
GO
GRANT EXECUTE ON dbo.spGetAuthorHoldings TO DE_IIS,PowerUsers
GO

/*

DECLARE @PropertiesXml varchar(8000)
SET @PropertiesXml =
'<DocumentInfo>
  <DocumentSection pubNo="142761" version="1" documentType="Industry Report" type="Research Call" subType="Industry Report" keyword="" pubDate="28 Nov 2018" title="Biosimilars: adoption update in EU &amp; US - Sep ''18 data: Impact of Humira biosimilars, implied Rituxan and Herceptin price" closeDate="27 Nov 2018" perfType="TTM" valType="P/E Adjusted" epsType="" baseYear="2017" ignoreAutoFootnote="N" actionLine="" sector="Global Specialty Pharma &amp; US Biotech" includeValuationTable="N" includeFinancials="N" coauthored="N" strategy="N" coverageInitiation="N" moveTT="N" userKeepTT="Y" financialsFootnote="" approver="fkagda" approvedDate="November 28, 2018 03:55 am" source="" docFileName="Biosimilar Update Oct ''18.docx" tickerSheetVersion="2.00" userLastUpdated="bhuang1" />
  <Documents>
    <Document docNo="311425" docType="DOCX" fileName="00311425.DOCX" fileSize="1771594" />
    <Document docNo="311426" docType="PDF" fileName="00311426.PDF" fileSize="1286996" pageCount="35" />
  </Documents>
  <Properties>
    <Property name="Keywords" value="" />
    <Property name="Template Version" value="10.14" />
    <Property name="Office Version" value="16.0" />
    <Property name="Computer Name" value="W7XDCLFR190651" />
    <Property name="Disclosure Version" value="" />
    <Property name="Revision Number" value="2391" />
    <Property name="Proactivity" value="F" />
    <Property name="BlastTime" value="" />
    <Property name="BlastUser" value="" />
    <Property name="ExcludePressIndustry" value="0" />
    <Property name="ImmediateBlast" value="0" />
    <Property name="ThematicTag" value="" />
    <Property name="CCAuthors" value="0" />
    <Property name="Reblast" value="0" />
    <Property name="syncRequired" value="0" />
  </Properties>
  <Securities>
    <Security ticker="000858.CH" id="1797" companyId="190" coverageId="1941" tickerSheetId="33397" analyst="Nbeveridge" indicateChange="no" />
    <Security ticker="002415.CH" id="1953" companyId="81" coverageId="1940" tickerSheetId="33640" analyst="Nbeveridge" indicateChange="no" />
    <Security ticker="1299.HK" id="1457" companyId="49" coverageId="544" tickerSheetId="33616" analyst="Nbeveridge" indicateChange="no" />
    <Security ticker="HEI.GR" id="1251" companyId="804" coverageId="541" tickerSheetId="33884" analyst="Gal" indicateChange="no" />
    <Security ticker="VOD.LN" id="647" companyId="1165" coverageId="543" tickerSheetId="33733" analyst="Gal" indicateChange="no" />
    <Security ticker="MSDLE15" id="800" companyId="index" coverageId="" tickerSheetId="" analyst="" indicateChange="no" />
    <Security ticker="SPX" id="735" companyId="index" coverageId="" tickerSheetId="" analyst="" indicateChange="no" />
  </Securities>
  <Authors>
  <Author id="431" name="Beveridge, Neil" phone="+1-212-756-4208" email="ronny.gal@bernstein.com" title="Analyst" />
    <Author id="808" name="Bentley, Charles" phone="+1-212-756-4208" email="ronny.gal@bernstein.com" title="Analyst" />
    <Author id="775" name="Betty  Huang" phone="+1-212-756-4602" email="betty.huang@bernstein.com" title="" />
    <Author id="842" name="Andy Chen, Ph.D." phone="+1-212-823-2732" email="andy.chen@bernstein.com" title="" />
  </Authors>
  <Industries>
    <Industry name="Global Specialty Pharmaceuticals" id="125" />
    <Industry name="Global Biotechnology" id="58" />
  </Industries>
  <Blastlists />
  <Icons>
    <Icon fileName="call_ind_analystpg.jpg" hyperlink="https://www.bernsteinresearch.com/brweb/analyst.aspx?id=309" text="Analyst Page" />
    <Icon fileName="call_ind_events.jpg" hyperlink="https://bernstein.dealogic.com/clientportal/ssologin?SelectedTab=10" text="Bernstein Events" />
    <Icon fileName="call_ind_industrypg.jpg" hyperlink="https://www.bernsteinresearch.com/brweb/industry.aspx?id=125" text="Industry Page" />
  </Icons>
  <Certifications />
  <InvestorThemes />
</DocumentInfo>'

Exec dbo.spGetAnalystHoldings @PropertiesXML

DECLARE @PropertiesXml varchar(max)
SET @PropertiesXml =
'<DocumentInfo>
  <DocumentSection pubNo="0" version="" documentType="Industry Report" type="Research Call" subType="Industry Report" keyword="" pubDate="1 Feb 2019" title="Use BERNSTEIN: Document Information button to set document title" closeDate="30 Jan 2019" perfType="TTM" valType="P/E Reported" epsType="EPS Reported" baseYear="2016" ignoreAutoFootnote="N" actionLine="" sector="Asia-Pacific Gas Distributors" includeValuationTable="Y" includeFinancials="Y" coauthored="N" strategy="N" coverageInitiation="N" moveTT="N" userKeepTT="Y" financialsFootnote="" approver="" approvedDate="" source="" docFileName="Research Suite Redesign - Technical Notes.docx" tickerSheetVersion="2.00" userLastUpdated="sgovil" RisksValCategories="AI" RisksValHeaders="Y"></DocumentSection>
  <Properties>
    <Property name="Keywords" value=""/>
    <Property name="Template Version" value="10.15"/>
    <Property name="Office Version" value="16.0"/>
    <Property name="Computer Name" value="NYCW7D-BF9EE5"/>
    <Property name="Disclosure Version" value=""/>
    <Property name="Revision Number" value="1"/>
    <Property name="Proactivity" value=""/>
    <Property name="BlastTime" value=""/>
    <Property name="BlastUser" value=""/>
    <Property name="ExcludePressIndustry" value="0"/>
    <Property name="ImmediateBlast" value="0"/>
    <Property name="ThematicTag" value=""/>
    <Property name="CCAuthors" value="0"/>
  </Properties>
  <Securities>
    <Security ticker="392.HK" id="1989" companyId="1521" coverageId="2208" tickerSheetId="21686" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="384.HK" id="1988" companyId="1520" coverageId="2207" tickerSheetId="22876" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="1193.HK" id="1991" companyId="1523" coverageId="2210" tickerSheetId="22878" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="2688.HK" id="1231" companyId="434" coverageId="2211" tickerSheetId="22877" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="135.HK" id="1232" companyId="674" coverageId="1406" tickerSheetId="25618" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="1083.HK" id="1990" companyId="1522" coverageId="2209" tickerSheetId="25617" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="2883.HK" id="1357" companyId="275" coverageId="1267" tickerSheetId="25621" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="601808.CH" id="1721" companyId="275" coverageId="1793" tickerSheetId="25622" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="386.HK" id="1094" companyId="278" coverageId="864" tickerSheetId="21774" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="600028.CH" id="1720" companyId="278" coverageId="1792" tickerSheetId="22344" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="SNP" id="1133" companyId="278" coverageId="933" tickerSheetId="22343" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="883.HK" id="1093" companyId="310" coverageId="866" tickerSheetId="22345" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="CEO" id="1135" companyId="310" coverageId="935" tickerSheetId="22346" analyst="Beveridge" indicateChange="no" optYesEnabled="Y" optNoEnabled="Y" optLastEnabled="N" optYesFlags="E" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="1605.JP" id="1500" companyId="617" coverageId="1445" tickerSheetId="22352" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="ONGC.IN" id="1096" companyId="869" coverageId="867" tickerSheetId="22351" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="OSH.AU" id="1130" companyId="870" coverageId="930" tickerSheetId="22348" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="857.HK" id="1091" companyId="908" coverageId="865" tickerSheetId="22847" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="601857.CH" id="1719" companyId="908" coverageId="1791" tickerSheetId="22849" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="PTR" id="1134" companyId="908" coverageId="934" tickerSheetId="22848" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="PTTEP.TB" id="1220" companyId="957" coverageId="1058" tickerSheetId="22353" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="RIL.IN" id="1095" companyId="977" coverageId="868" tickerSheetId="25500" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="RIGD.LI" id="1183" companyId="977" coverageId="1014" tickerSheetId="25501" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="STO.AU" id="1098" companyId="1035" coverageId="869" tickerSheetId="22350" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="WPL.AU" id="1097" companyId="1284" coverageId="870" tickerSheetId="22347" analyst="Beveridge" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="AZN.LN" id="61" companyId="111" coverageId="702" tickerSheetId="25597" analyst="Anderson" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="AZN" id="759" companyId="111" coverageId="701" tickerSheetId="25598" analyst="Anderson" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="700.HK" id="1890" companyId="1432" coverageId="2061" tickerSheetId="21662" analyst="Vajpayee" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="KO" id="304" companyId="313" coverageId="1098" tickerSheetId="19715" analyst="Dibadj" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="TGT" id="522" companyId="1135" coverageId="2015" tickerSheetId="25633" analyst="Fletcher" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="WMT" id="583" companyId="1260" coverageId="2014" tickerSheetId="25278" analyst="Fletcher" indicateChange="no" optYesEnabled="N" optNoEnabled="Y" optLastEnabled="N" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="MSDLE15" id="800" companyId="index" coverageId="" tickerSheetId="" analyst="" indicateChange="no" optYesEnabled="" optNoEnabled="" optLastEnabled="" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="MXEF" id="1092" companyId="index" coverageId="" tickerSheetId="" analyst="" indicateChange="no" optYesEnabled="" optNoEnabled="" optLastEnabled="" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="MXJP" id="1501" companyId="index" coverageId="" tickerSheetId="" analyst="" indicateChange="no" optYesEnabled="" optNoEnabled="" optLastEnabled="" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="SPX" id="735" companyId="index" coverageId="" tickerSheetId="" analyst="" indicateChange="no" optYesEnabled="" optNoEnabled="" optLastEnabled="" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
    <Security ticker="MXAPJ" id="1132" companyId="index" coverageId="" tickerSheetId="" analyst="" indicateChange="no" optYesEnabled="" optNoEnabled="" optLastEnabled="" optYesFlags="" optLastFlags="" optLastPubNo="" coverageAction=""/>
  </Securities>
  <Authors>
    <Author id="431" name="Neil Beveridge, Ph.D." phone="+852-2918-5741" email="neil.beveridge@bernstein.com" title="Analyst"/>
    <Author id="783" name="Bhavtosh Vajpayee" phone="+852-2918-5735" email="bhavtosh.vajpayee@bernstein.com" title="Analyst"/>
    <Author id="320" name="Ali Dibadj" phone="+1-212-756-4137" email="ali.dibadj@bernstein.com" title="Analyst"/>
    <Author id="216" name="Ian J. Gordon" phone="+1-212-823-3852" email="ian.gordon@bernstein.com" title="Analyst"/>
    <Author id="697" name="Vincent Chen, M.D., CFA" phone="+1-212-969-6607" email="vincent.chen@bernstein.com" title="Analyst"/>
    <Author id="770" name="Brandon Fletcher, CFA" phone="+1-212-969-1498" email="brandon.fletcher@bernstein.com" title="Analyst"/>
    <Author id="377" name="Tim Anderson, MD" phone="+1-212-407-5901" email="tim.anderson@bernstein.com" title="Analyst"/>
  </Authors>
  <Industries>
    <Industry name="Asia-Pacific Gas Distributors" id="159"/>
    <Industry name="Asia-Pacific Oil &amp; Gas" id="92"/>
    <Industry name="Global Pharmaceuticals" id="86"/>
    <Industry name="Asia Internet" id="149"/>
    <Industry name="U.S. Beverages and Snacks" id="33"/>
    <Industry name="U.S. SMID-Cap Biotechnology" id="158"/>
    <Industry name="U.S. Broadlines &amp; Hardlines Retail" id="146"/>
  </Industries>
  <Blastlists></Blastlists>
  <Icons>
    <Icon fileName="call_ind_analystpg.jpg" hyperlink="https://www.bernsteinresearch.com/brweb/analyst.aspx?id=431" text="Analyst Page"/>
    <Icon fileName="call_ind_events.jpg" hyperlink="https://bernstein.dealogic.com/clientportal/ssologin?SelectedTab=10" text="Bernstein Events"/>
    <Icon fileName="call_ind_industrypg.jpg" hyperlink="https://www.bernsteinresearch.com/brweb/industry.aspx?id=159" text="Industry Page"/>
    <Icon fileName="call_ind_financials.jpg" hyperlink="FinAppendix" text="Financials"/>
    <Icon fileName="call_ind_compval.jpg" hyperlink="ValuationTable" text="Comp Valuation"/>
  </Icons>
  <Certifications></Certifications>
</DocumentInfo>
'
Exec dbo.spGetAnalystHoldings @PropertiesXML

*/