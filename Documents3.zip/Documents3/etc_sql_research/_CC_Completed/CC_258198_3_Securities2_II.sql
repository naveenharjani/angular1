-- Securities2_II.sql
-- 08/03/2017

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*

-- ALTER procs to use varchar(15) for [Securities2.Ticker] & [Securities2.RIC]
-- which otherwise fails with a 11 character Ticker ['CROMPTON.IN']

-- Set 2 procs:
alter spRollbackSplitActions
alter spSearchChartCountExclusions
alter spSearchResearchCoverage
alter spSearchSecurityCheckboxDisclosures
alter spSaveSolactiveIndexTicker
alter spGetResearchCoverageDetail
alter spGetImplicitChanges
alter spSetCompanySecurityPrimary
alter spSetCompanySecurityOrdNo
alter spSaveSecurityFilter
alter spSearchSecurityFilters
alter spSaveChartCountExclusion
alter spSaveSecurityCheckboxDisclosure

-- dropped from last CC
-- alter spMirrorFinancialNumbers
-- alter spUpdateActionTags

*/
GO


ALTER PROC [dbo].[spRollbackSplitActions]  @Ticker varchar(15)
AS
  -- =======================================================================
  -- Author:  Krishna Josyula
  -- Create date:  03/26/2008
  -- Description:  Rolls TargetPrice column values back from ValueOrig Column
  -- =======================================================================
BEGIN

  SET NOCOUNT ON
  DECLARE @SecurityId INT
  DECLARE @FinancialNumberTypeId INT

 SELECT SecurityId FROM Securities2 Where Ticker = @Ticker
 SELECT @FinancialNumberTypeId = FinancialNumberTypeId FROM FinancialNumberTypes WHERE FinancialNumberType = 'TARGETPRICE'

  UPDATE FinancialNumbers
  SET Value  = ValueOrig,
      UnitValue  = ValueOrig
  WHERE SecurityId = @SecurityId
    and FinancialNumberTypeId = @FinancialNumberTypeId
    and IsDraft = 0
    and ValueOrig is not null

  UPDATE FinancialNumbers
  SET ValueOrig = null
  WHERE SecurityId = @SecurityId
    and FinancialNumberTypeId = @FinancialNumberTypeId
    and IsDraft = 0
    and ValueOrig is not null

  UPDATE SplitActions
  SET AppliedStatus = 'N', AppliedDate = null
  WHERE
    Ticker = @Ticker
END



GO

ALTER PROCEDURE [dbo].[spSearchChartCountExclusions]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'
CREATE TABLE #TmpSearch
(
  ID         int IDENTITY,
  SecurityID int         NULL,
  Ticker     varchar(15) NULL,
  Company    varchar(63) NULL,
  Excluded   smallint    NULL,
  Editor     varchar(50) NULL,
  EditDate   datetime    NULL
)
INSERT INTO #TmpSearch (SecurityID, Ticker, Company, Excluded, Editor, EditDate)
EXEC
(
'SELECT'
+ ' SecurityID   = C.SecurityID,'
+ ' Ticker       = S.Ticker,'
+ ' Company      = S.Company,'
+ ' (CASE WHEN D.SecurityID IS NULL THEN 0 ELSE -1 END) AS Excluded,'
+ ' Editor       = U.UserName,'
+ ' EditDate     = D.EditDate'
+ ' FROM ResearchCoverage C'
+ ' JOIN Securities2 S ON S.SecurityID  = C.SecurityID'
+ ' LEFT JOIN ChartCountExclusions D ON D.SecurityID = C.SecurityID'
+ ' LEFT JOIN Users U ON UserID = D.EditorID'
+ ' WHERE C.DropDate IS NULL'
+ ' ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT SecurityID, Ticker, Company, Excluded, Editor, EditDate
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF


GO

ALTER PROCEDURE [dbo].[spSearchResearchCoverage]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT,
  @Style         int
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'

DECLARE @WHERE varchar(2048)
IF @Style = 1 SET @WHERE = 'WHERE C.LaunchDate IS NOT NULL AND C.DropDate IS NULL' -- Launched, Not dropped
IF @Style = 2 SET @WHERE = 'WHERE C.DropDate IS NULL'                              -- Not dropped
IF @Style = 3 SET @WHERE = ''                                                      -- Launched/unlaunched, dropped/not dropped

CREATE TABLE #TmpSearch
(
  ID           int IDENTITY,
  Industry     varchar(50)   NULL,
  Analyst      varchar(50)   NULL,
  Ticker       varchar(15)   NULL,
  Company      varchar(63)   NULL,
  LaunchDate   datetime      NULL,
  DropDate     datetime      NULL,
  Rating       char(1)       NULL,
  Target       varchar(10)   NULL, -- decimal(9, 2)
  MetaAnalyst  varchar(48)   NULL,
  CoverageID   int           NULL,
  CUSIP        varchar(10)   NULL,
  SEDOL        varchar(10)   NULL,
  ISIN         varchar(12)   NULL
)
INSERT INTO #TmpSearch (Industry, Analyst, Ticker, Company, LaunchDate, DropDate, Rating, Target, MetaAnalyst, CoverageID, CUSIP, SEDOL, ISIN)
EXEC
(
'SELECT
  Industry    = I.IndustryName,
  Analyst     = A.Last + '', '' + A.First,
  Ticker      = S.Ticker,
  Company     = S.Company,
  LaunchDate  = C.LaunchDate,
  DropDate    = C.DropDate,
  Rating      = FL.Rating,
  Target      = CONVERT(varchar, FL.TargetPrice),
  MetaAnalyst = A.Name,
  CoverageID  = C.CoverageID,
  CUSIP       = ISNULL(S.CUSIP, ''''),
  SEDOL       = ISNULL(S.SEDOL, ''''),
  ISIN        = ISNULL(S.ISIN, '''')
FROM ResearchCoverage C
JOIN Industries I ON I.IndustryID = C.IndustryID
JOIN Authors A ON A.AuthorID = C.AnalystID
LEFT JOIN Securities2 S ON S.SecurityID = C.SecurityID -- SecurityID OPTIONAL, THEREFORE LEFT JOIN
LEFT JOIN vFinancialsLatest FL ON FL.CoverageID = C.CoverageID '
+ @WHERE
+ ' ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT Industry, Analyst, Ticker, Company, LaunchDate, DropDate, Rating, Target, MetaAnalyst, CoverageID, CUSIP, SEDOL, ISIN
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO

ALTER PROCEDURE [dbo].[spSearchSecurityCheckboxDisclosures]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'
CREATE TABLE #TmpSearch
(
  ID         int IDENTITY,
  SecurityID int         NULL,
  Ticker     varchar(15) NULL,
  Company    varchar(63) NULL,
  D1         smallint    NULL,
  D2         smallint    NULL,
  D3         smallint    NULL,
  D4         smallint    NULL,
  D5         smallint    NULL,
  D6         smallint    NULL,
  D7         smallint    NULL,
  D8         smallint    NULL,
  D9         smallint    NULL,
  D10        smallint    NULL
)
INSERT INTO #TmpSearch (SecurityID, Ticker, Company, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10)
EXEC
(
'SELECT'
+ ' SecurityID = C.SecurityID,'
+ ' Ticker     = S.Ticker,'
+ ' Company    = S.Company,'
+ ' SUM(CASE WHEN D.DisclosureID =  1 THEN -1 ELSE 0 END) AS D1,'
+ ' SUM(CASE WHEN D.DisclosureID =  2 THEN -1 ELSE 0 END) AS D2,'
+ ' SUM(CASE WHEN D.DisclosureID =  3 THEN -1 ELSE 0 END) AS D3,'
+ ' SUM(CASE WHEN D.DisclosureID =  4 THEN -1 ELSE 0 END) AS D4,'
+ ' SUM(CASE WHEN D.DisclosureID =  5 THEN -1 ELSE 0 END) AS D5,'
+ ' SUM(CASE WHEN D.DisclosureID =  6 THEN -1 ELSE 0 END) AS D6,'
+ ' SUM(CASE WHEN D.DisclosureID =  7 THEN -1 ELSE 0 END) AS D7,'
+ ' SUM(CASE WHEN D.DisclosureID =  8 THEN -1 ELSE 0 END) AS D8,'
+ ' SUM(CASE WHEN D.DisclosureID =  9 THEN -1 ELSE 0 END) AS D9,'
+ ' SUM(CASE WHEN D.DisclosureID = 10 THEN -1 ELSE 0 END) AS D10'
+ ' FROM ResearchCoverage C'
+ ' JOIN Securities2 S ON S.SecurityID  = C.SecurityID'
+ ' LEFT JOIN SecurityCheckboxDisclosures D ON D.SecurityID = C.SecurityID'
+ ' WHERE C.DropDate IS NULL'
+ ' GROUP BY C.SecurityID, S.Ticker, S.Company'
+ ' ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT SecurityID, Ticker, Company, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF


GO

ALTER PROCEDURE [dbo].[spSaveSolactiveIndexTicker]
  @IndexId    int,
  @SecurityId int,          -- Supplied via Beehive interface
  @Ticker     varchar(15),  -- Supplied via Excel interface
  @Checked    int,
  @EditorId   int
AS

SET NOCOUNT ON

DECLARE
@EditDate datetime,
@IndexCode varchar(50)

SELECT @EditDate = GETDATE()

SELECT @IndexCode = IndexCode FROM SolactiveIndexes WHERE IndexId = @IndexId

IF @SecurityId IS NULL
SELECT @SecurityId = SecurityId FROM Securities2 WHERE Ticker = @Ticker

IF (@Ticker IS NULL OR @Ticker = '')
SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityID = @SecurityId

BEGIN TRY
  BEGIN TRANSACTION
    IF @Checked = 1
      BEGIN
        IF NOT EXISTS (SELECT * FROM SolactiveIndexTickers WHERE SecurityId = @SecurityId AND IndexId = @IndexId)
        BEGIN
          INSERT INTO SolactiveIndexTickers (IndexId, SecurityId, EditorId, EditDate) VALUES (@IndexId, @SecurityId, @EditorId, @EditDate)

          INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
          VALUES ('SolactiveIndexTickers', 'A', @IndexCode + ' | ' + @Ticker, NULL, @SecurityId, @EditorId, @EditDate)
        END
      END
    ELSE
      BEGIN
        DELETE FROM SolactiveIndexTickers WHERE IndexId = @IndexId AND SecurityId = @SecurityId
    
        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('SolactiveIndexTickers', 'D', @IndexCode + ' | ' + @Ticker, NULL, @SecurityId, @EditorId, @EditDate)
      END
    SELECT 0
  COMMIT TRANSACTION
END TRY
BEGIN CATCH
  ROLLBACK TRANSACTION
  SELECT ERROR_NUMBER() AS ErrorNumber, ERROR_MESSAGE() AS ErrorMessage
END CATCH

GO

/*

Revised 09/05/2013

Expanded sort to chronologically order coverage, e.g. same day coverage transfer.

Expanded target price and close price to #,###,###.##, e.g. 005930.KS / Samsung Electronics

*/

ALTER PROCEDURE [dbo].[spGetResearchCoverageDetail]
  @CoverageID   int,
  @IndustryID   int           OUTPUT,
  @Industry     varchar(50)   OUTPUT,
  @AnalystID    int           OUTPUT,
  @Analyst      varchar(48)   OUTPUT,
  @SecurityID   int           OUTPUT,
  @Ticker       varchar(15)   OUTPUT,
  @Company      varchar(63)   OUTPUT,
  @Rating       char(1)       OUTPUT,
  @Exchange     varchar(10)   OUTPUT,
  @Currency     varchar(10)   OUTPUT,
  @Index        varchar(10)   OUTPUT,
  @LaunchDate   datetime      OUTPUT,
  @LaunchInd    char(1)       OUTPUT,
  @DropDate     datetime      OUTPUT,
  @DropInd      char(1)       OUTPUT,
  @AnalystDx    varchar(2048) OUTPUT,
  @SecurityDx   varchar(2048) OUTPUT
AS

-- RETURN OUTPUT PARAMETERS
SELECT
  @IndustryID   = C.IndustryID,
  @Industry     = I.IndustryName,
  @AnalystID    = C.AnalystID,
  @Analyst      = A.Name,
  @SecurityID   = S.SecurityID,
  @Ticker       = S.Ticker,
  @Company      = S.Company,
  @Rating       = V.Rating,
  @Exchange     = S.ExchangeCode,
  @Currency     = S.CurrencyCode,
  @Index        = S.BenchmarkIndex,
  @LaunchDate   = C.LaunchDate,
  @LaunchInd    = C.LaunchInd,
  @DropDate     = C.DropDate,
  @DropInd      = C.DropInd,
  @AnalystDx    = AD.Disclosure,
  @SecurityDx   = SD.Disclosure
FROM ResearchCoverage              C
JOIN Industries                    I ON I.IndustryID  = C.IndustryID
JOIN Authors                       A ON A.AuthorID    = C.AnalystID
LEFT JOIN Securities2              S ON S.SecurityID  = C.SecurityID
LEFT JOIN (SELECT SecurityID, Date = MAX(Date) FROM vFinancials GROUP BY SecurityID) X ON X.SecurityID = C.SecurityID
LEFT JOIN vFinancials             V ON V.SecurityID = X.SecurityID AND V.Date = X.Date
LEFT JOIN AuthorTextDisclosures   AD ON AD.AuthorID   = C.AnalystID
LEFT JOIN SecurityTextDisclosures SD ON SD.SecurityID = C.SecurityID
WHERE C.CoverageID = @CoverageID

-- RETURN ROWSET
SELECT
  'Date'              = CONVERT(char(10), V.Date, 101),
  'Rating'            = V.Rating,
  'RatingAction'      = V.RatingAction,
  'TargetPrice'       = STR(V.TargetPrice, 10, 2) + ' ' + S.CurrencyCode,
  'TargetPriceAction' = V.TargetPriceAction,
  'ClosingPrice'      = STR(P.PX_Last, 10, 2) + ' ' + S.CurrencyCode,
  'Analyst'           = A.Last
FROM Securities2 S
JOIN vFinancials V ON V.SecurityID = S.SecurityID AND (V.TargetPriceAction in ('INCREASE','DECREASE') OR V.RatingAction in ('UPGRADE','DOWNGRADE','INITIATE','DROP'))
JOIN Authors A ON A.AuthorID = V.AnalystID
LEFT OUTER JOIN BloombergPriceHistory P ON P.Ticker = S.Ticker AND V.Date = P.CloseDate
WHERE S.SecurityId = @SecurityID
ORDER BY V.Date DESC, V.CoverageId DESC

-- RETURN ROWSET
SELECT
  T.DisclosureID,
  'Disclosure' = (CASE WHEN D.DisclosureID IS NULL THEN 0 ELSE -1 END),
  T.Disclosure
FROM SecurityCheckboxTypes T
LEFT JOIN SecurityCheckboxDisclosures D ON D.DisclosureID = T.DisclosureID AND  D.SecurityID = @SecurityID


GO

ALTER PROCEDURE [dbo].[spGetImplicitChanges]
@FinancialType varchar(50),
@Date datetime
AS
BEGIN
SET NOCOUNT ON

DECLARE @CloseDate           datetime
DECLARE @PubNo               int
DECLARE @PubNo_Prev          int
DECLARE @Rating              char(1)
DECLARE @Rating_Prev         char(1)
DECLARE @TargetPrice         varchar(10)
DECLARE @TargetPrice_Prev    varchar(10)
DECLARE @Ticker              varchar(15)
DECLARE @EPSThisYear         varchar(10)
DECLARE @EPSThisYear_Prev    varchar(10)
DECLARE @CoverageAction      varchar(20)
DECLARE @CoverageAction_Prev varchar(20)
DECLARE @CoverageId          int

-- Flags for implicit rating, target price and estimate changes
DECLARE @I_R char(1)
DECLARE @I_T char(1)
DECLARE @I_E char(1)

-- Create temp table to store implicit changes
SELECT PubNo PubNo,PubNo PubNo_Prev,CloseDate,Ticker,Rating,Rating Rating_Prev,TargetPrice,TargetPrice TargetPrice_Prev,EPSThisYear,EPSThisYear EPSThisYear_Prev,CoverageId,
 '*' as I_R, '*' as I_T, '*' as I_E
INTO #tmp_ImplicitChanges
FROM vFinancials
WHERE 1 = 2

-- Outer loop cursor to enumerate tickers under coverage
DECLARE Ticker_cursor CURSOR FOR
SELECT DISTINCT VF.Ticker
FROM vFinancials VF
JOIN Securities2 s ON VF.Ticker = s.Ticker
JOIN ResearchCoverage rc ON s.SecurityId = rc.SecurityId
WHERE rc.LaunchDate IS NOT NULL AND rc.DropDate IS NULL
ORDER BY Ticker

OPEN Ticker_cursor

FETCH NEXT FROM Ticker_cursor INTO @Ticker

WHILE @@FETCH_STATUS = 0
BEGIN

  --SELECT @Ticker Ticker

  -- Inner loop cursor to compare consecutive reports where:
  -- 1) Value on next report differs from value on prior report (excluding coverage change)
  -- 2) No old row
  DECLARE tts_cursor CURSOR FOR
  SELECT PubNo,Rating,TargetPrice,EPSThisYear,CloseDate,CoverageAction,CoverageId
  FROM vFinancials
  WHERE Ticker = @Ticker AND CloseDate >= @Date
  ORDER BY PubNo

  OPEN tts_cursor

  FETCH NEXT FROM tts_cursor INTO @PubNo_Prev,@Rating_Prev,@TargetPrice_Prev,@EPSThisYear_Prev,@CloseDate,@CoverageAction_Prev,@CoverageId
  FETCH NEXT FROM tts_cursor INTO @PubNo,@Rating,@TargetPrice,@EPSThisYear,@CloseDate,@CoverageAction,@CoverageId

  WHILE @@FETCH_STATUS = 0
  BEGIN
    SELECT @I_R = '', @I_T = '', @I_E = ''  -- Reset implicit change flags
    IF (@FinancialType = 'Rating' OR @FinancialType = 'ALL')
    BEGIN
      IF ((@Rating <> @Rating_Prev) AND ISNULL(@CoverageAction_Prev,'') <> 'DROP' AND ISNULL(@CoverageAction,'') <> 'INITIATE')
      BEGIN
        IF NOT EXISTS(SELECT * FROM vFinancials WHERE PubNo = @PubNo AND RatingPrior <> '')
        SET @I_R = '*'
      END
    END
    IF (@FinancialType = 'TargetPrice' OR @FinancialType = 'ALL')
    BEGIN
      IF ((@TargetPrice <> @TargetPrice_Prev) AND ISNULL(@CoverageAction_Prev,'') <> 'DROP' AND ISNULL(@CoverageAction,'') <> 'INITIATE')
      BEGIN
        IF NOT EXISTS(SELECT * FROM vFinancials WHERE PubNo = @PubNo AND TargetPricePrior <> '')
      SET @I_T = '*'
      END
    END
    IF (@FinancialType = 'Estimate' OR @FinancialType = 'ALL')
    BEGIN
      IF ((@EPSThisYear <> @EPSThisYear_Prev) AND ISNULL(@CoverageAction_Prev,'') <> 'DROP' AND ISNULL(@CoverageAction,'') <> 'INITIATE')
      BEGIN
        IF NOT EXISTS(SELECT * FROM vFinancials WHERE PubNo = @PubNo AND EPSThisYearPrior <> '')
        SET @I_E = '*'
      END
    END

    IF @I_R = '*' OR @I_T = '*' OR @I_E = '*'
    INSERT INTO #tmp_ImplicitChanges
    SELECT @PubNo,@PubNo_Prev,@CloseDate,@Ticker,@Rating,@Rating_Prev,@TargetPrice,@TargetPrice_Prev,@EPSThisYear,@EPSThisYear_Prev,@CoverageId, @I_R, @I_T, @I_E

    SELECT @PubNo_Prev = @PubNo,@Rating_Prev = @Rating,@TargetPrice_Prev = @TargetPrice,@EPSThisYear_Prev=@EPSThisYear,@CoverageAction_Prev = @CoverageAction
    FETCH NEXT FROM tts_cursor INTO @PubNo,@Rating,@TargetPrice,@EPSThisYear,@CloseDate,@CoverageAction,@CoverageId
  END

  CLOSE tts_cursor
  DEALLOCATE tts_cursor

  FETCH NEXT FROM Ticker_cursor INTO @Ticker
END

CLOSE Ticker_cursor
DEALLOCATE Ticker_cursor

SELECT p.PubNo,PubNo_Prev,convert(varchar(10), p.date, 101) AS Date,Ticker,I_R,I_T,I_E,Rating,Rating_Prev,TargetPrice,TargetPrice_Prev,EPSThisYear,EPSThisYear_Prev,a.Last + ', ' + a.First AS [Analyst]
FROM #tmp_ImplicitChanges  t
JOIN Publications p ON t.PubNo = p.PubNo
JOIN ResearchCoverage rc ON t.CoverageId = rc.CoverageId
JOIN Authors a ON rc.AnalystId = a.AuthorId
ORDER BY [Analyst],PubNo,Date DESC
END


GO

ALTER PROCEDURE [dbo].[spSetCompanySecurityPrimary]
  @SecurityId int,
  @EditorId   int
AS
BEGIN TRANSACTION

DECLARE @Ticker varchar(15), @IsPrimaryOld char(1), @New varchar(100), @Old varchar(100)
SELECT @Ticker = Ticker, @IsPrimaryOld = IsPrimary FROM Securities2 WHERE SecurityId = @SecurityId
SET @New = @Ticker + ' | IsPrimary Y'
SET @Old = @Ticker + ' | IsPrimary ' + @IsPrimaryOld

UPDATE Securities2 SET IsPrimary ='N' WHERE CompanyId = (SELECT CompanyId FROM Securities2 WHERE SecurityId = @SecurityId)
UPDATE Securities2 SET IsPrimary ='Y', OrdNo = 1 WHERE SecurityId = @SecurityId

INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
VALUES ('Securities', 'U', @New, @Old, @SecurityId, @EditorId, getdate())

COMMIT TRANSACTION

GO

ALTER PROCEDURE [dbo].[spSetCompanySecurityOrdNo]
  @SecurityId int,
  @OrdNo      int,
  @EditorId   int
AS
BEGIN TRANSACTION

DECLARE @Ticker varchar(15), @OrdNoOld int, @New varchar(100), @Old varchar(100)
SELECT @Ticker = Ticker, @OrdNoOld = OrdNo FROM Securities2 WHERE SecurityId = @SecurityId
SET @New = @Ticker + ' | OrdNo ' + convert(varchar, @OrdNoOld)
SET @Old = @Ticker + ' | OrdNo ' + convert(varchar, @OrdNo)

UPDATE Securities2 SET OrdNo = @OrdNo WHERE SecurityId = @SecurityId

INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
VALUES ('Securities', 'U', @New, @Old, @SecurityId, @EditorId, getdate())

COMMIT TRANSACTION

GO

ALTER PROCEDURE [dbo].[spSaveSecurityFilter]
  @SecurityID   int,
  @FilterID     int,
  @Filter       int,
  @EditorID     int,
  @Ticker       varchar(15) OUTPUT
AS
SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityID = @SecurityID
-- The SecurityFilters table is to be pivoted on the SecurityID column so that each security can record a variable number of filters
-- NO ROWS IMPLIES NO FILTER
IF @Filter = -1
  BEGIN
    IF NOT EXISTS (SELECT * FROM SecurityFilters WHERE SecurityID = @SecurityID AND FilterID = @FilterID)
      INSERT INTO SecurityFilters (SecurityID, FilterID, EditorID, EditDate) VALUES (@SecurityID, @FilterID, @EditorID, GETDATE())
    ELSE
      UPDATE SecurityFilters SET EditorID = @EditorID, EditDate = GETDATE() WHERE SecurityID = @SecurityID AND FilterID = @FilterID
  END
ELSE
  BEGIN
    DELETE FROM SecurityFilters WHERE SecurityID = @SecurityID AND FilterID = @FilterID
  END
RETURN 0

GO

ALTER PROCEDURE [dbo].[spSearchSecurityFilters]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'
CREATE TABLE #TmpSearch
(
  ID           int IDENTITY,
  SecurityID   int         NULL,
  Ticker       varchar(15) NULL,
  Company      varchar(63) NULL,
  ExchangeCode varchar(63) NULL,
  LaunchDate   datetime    NULL,
  V1           int         NULL,
  V2           int         NULL,
  V3           int         NULL,
  V4           int         NULL,
  V5           int         NULL,
  V6           int         NULL,
  V7           int         NULL,
  V8           int         NULL,
  V9           int         NULL,
  V10          int         NULL
)
INSERT INTO #TmpSearch (SecurityID, Ticker, Company, ExchangeCode, LaunchDate, V1, V2, V3, V4, V5, V6, V7, V8, V9, V10)
EXEC
(
'SELECT
SecurityID   = C.SecurityID,
Ticker       = S.Ticker,
Company      = S.Company,
ExchangeCode = S.ExchangeCode,
LaunchDate   = C.LaunchDate,
SUM(CASE WHEN SF.FilterID =  1 THEN -1 ELSE 0 END) AS V1,
SUM(CASE WHEN SF.FilterID =  2 THEN -1 ELSE 0 END) AS V2,
SUM(CASE WHEN SF.FilterID =  3 THEN -1 ELSE 0 END) AS V3,
SUM(CASE WHEN SF.FilterID =  4 THEN -1 ELSE 0 END) AS V4,
SUM(CASE WHEN SF.FilterID =  5 THEN -1 ELSE 0 END) AS V5,
SUM(CASE WHEN SF.FilterID =  6 THEN -1 ELSE 0 END) AS V6,
SUM(CASE WHEN SF.FilterID =  7 THEN -1 ELSE 0 END) AS V7,
SUM(CASE WHEN SF.FilterID =  8 THEN -1 ELSE 0 END) AS V8,
SUM(CASE WHEN SF.FilterID =  9 THEN -1 ELSE 0 END) AS V9,
SUM(CASE WHEN SF.FilterID = 10 THEN -1 ELSE 0 END) AS V10
FROM ResearchCoverage C
JOIN Securities2 S ON S.SecurityID  = C.SecurityID
LEFT JOIN SecurityFilters SF ON SF.SecurityID = C.SecurityID
WHERE C.DropDate IS NULL
GROUP BY C.SecurityID, S.Ticker, S.Company, S.ExchangeCode, C.LaunchDate
ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT SecurityID, Ticker, Company, ExchangeCode, LaunchDate, V1, V2, V3, V4, V5, V6, V7, V8, V9, V10
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO

ALTER PROCEDURE [dbo].[spSaveChartCountExclusion]
  @SecurityID    int,
  @Excluded      smallint,
  @EditorID      int,
  @Ticker        varchar(15) OUTPUT
AS
SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityID = @SecurityID
-- NO ROWS IMPLIES NO DISCLOSURE
IF @Excluded = -1
  BEGIN
    IF NOT EXISTS (SELECT * FROM ChartCountExclusions WHERE SecurityID = @SecurityID)
      INSERT INTO ChartCountExclusions (SecurityID, EditorID, EditDate) VALUES (@SecurityID, @EditorID, GETDATE())
    ELSE
      UPDATE ChartCountExclusions SET EditorID = @EditorID, EditDate = GETDATE() WHERE SecurityID = @SecurityID
  END
ELSE
  BEGIN
    DELETE FROM ChartCountExclusions WHERE SecurityID = @SecurityID
  END
RETURN 0


GO

ALTER PROCEDURE [dbo].[spSaveSecurityCheckboxDisclosure]
  @SecurityID   int,
  @DisclosureID int,
  @Disclosure   smallint,
  @EditorID     int,
  @Ticker       varchar(15) OUTPUT
AS
SELECT @Ticker = Ticker FROM Securities2 WHERE SecurityID = @SecurityID
-- NO ROWS IMPLIES NO DISCLOSURE
IF @Disclosure = -1
  BEGIN
    IF NOT EXISTS (SELECT * FROM SecurityCheckboxDisclosures WHERE SecurityID = @SecurityID AND DisclosureID = @DisclosureID)
      INSERT INTO SecurityCheckboxDisclosures (SecurityID, DisclosureID, EditorID, EditDate) VALUES (@SecurityID, @DisclosureID, @EditorID, GETDATE())
    ELSE
      UPDATE SecurityCheckboxDisclosures SET EditorID = @EditorID, EditDate = GETDATE() WHERE SecurityID = @SecurityID AND DisclosureID = @DisclosureID
  END
ELSE
  BEGIN
    DELETE FROM SecurityCheckboxDisclosures WHERE SecurityID = @SecurityID AND DisclosureID = @DisclosureID
  END
RETURN 0


GO





/*
-- NO CHANGE
-- Procs that use Securities2, Ticker, but no varchar(10) in use
spGetTickerSheetIdData
spSaveFinancialNumbers
spSavePublicationExcel
spCancelPublicationQueueItem
spGetReportState
spGetEligibleCorrections
spRollbackEstimates
spSearchAnalystSettings
spGetCompanyPerformanceXml
spGetCompanyFinancialsXml
spGetCompanyValuationsXml
spRptEarningsCalendar
spGetDailyRatings
spRptDwsWeeklyCoverage
spGetEstimatesMarketdataXml
spGetEstimatesFinancialsXml
spSaveCoverage
spGetEstimatesValuationsXml
spGetTrefisModels
*/