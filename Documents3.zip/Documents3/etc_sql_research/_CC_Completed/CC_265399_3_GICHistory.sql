-- GICHistory.sql
-- 10/31/2017

/*

spRptGICRatingsHistory
spRptGICTargetPriceHistory

*/

USE [Research]
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spRptGICRatingsHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spRptGICRatingsHistory]
GO

CREATE PROCEDURE [dbo].[spRptGICRatingsHistory]
  @SinceDate  varchar(20),
  @UntilDate  varchar(20)
AS
select
  S.Company,
  S.Ticker,
  S.SEDOL,
  S.CountryCode,
  A.Last + ', ' + A.First as Analyst,
  convert(varchar, VF.Date, 101) as RatingDate,
  VF.Rating
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join Authors A on RC.AnalystId = A.AuthorId
join vFinancials VF on VF.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null and RC.SecurityId is not null
and VF.RatingAction <> 'Reiterate'
and Date BETWEEN @SinceDate AND @UntilDate
order by 1, 2
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spRptGICTargetPriceHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spRptGICTargetPriceHistory]
GO

CREATE PROCEDURE [dbo].[spRptGICTargetPriceHistory]
  @SinceDate  varchar(20),
  @UntilDate  varchar(20)
AS
select
  S.Company,
  S.Ticker,
  S.SEDOL,
  S.CountryCode,
  A.Last + ', ' + A.First as Analyst,
  convert(varchar, VF.Date, 101) as TargetPriceDate,
  VF.TargetPrice,
  VF.Currency
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
join Authors A on RC.AnalystId = A.AuthorId
join vFinancials VF on VF.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null and RC.SecurityId is not null
and (VF.TargetPriceAction in ('increase', 'decrease') or VF.RatingAction <> 'Reiterate')
and Date BETWEEN @SinceDate AND @UntilDate
order by 1, 2
GO


GRANT EXECUTE ON [dbo].[spRptGICRatingsHistory]		TO PowerUsers, SCBIS_Reports
GRANT EXECUTE ON [dbo].[spRptGICTargetPriceHistory]	TO PowerUsers, SCBIS_Reports
GO


/*
EXEC [spRptGICRatingsHistory] '10/01/2017', '10/31/2017'
EXEC [spRptGICRatingsHistory] '01/01/2017', '10/31/2017'
EXEC [spRptGICTargetPriceHistory] '10/01/2017', '10/31/2017'
EXEC [spRptGICTargetPriceHistory] '01/01/2017', '10/31/2017'
*/