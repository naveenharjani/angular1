-- AutonomousExport_Rollback.sql
-- 02/22/2019
/*

alter vHoldings

-- Coverage.xml
drop spExportCoverageAuthors
drop spExportCoverageSecurities

- Disclosures.xml
drop spExportAuthorTextDisclosures
drop spExportSecurityTextDisclosures
drop spExportFirmDisclosures
drop spExportHoldings

*/
USE Research
GO

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

ALTER VIEW [dbo].[vHoldings]
as
select distinct
  A.Last + ', ' + A.First as Author
 ,S.Ticker
 ,S.Company
 ,A.Name + ' maintains a long position in ' + S.Company + ' (' + S.Ticker + ')' as [Text]
 ,A.AuthorId
 ,S.SecurityId
 ,'' as LoadDate -- EffectiveDate
 ,H.EmployeeID
 ,H.EmployeeUserName
 ,H.EmployeeLastName
 ,H.EmployeeFirstName
 ,H.Description
 ,H.Cusip
 ,H.BloombergTicker
 ,H.ISIN
 ,H.SEDOL
 ,H.SecurityType
 ,H.HoldingQuantity
 ,H.UserAccountStatus
 ,H.LastExecution
 ,H.ReportRunDate
from Holdings H
inner join Authors A on ltrim(rtrim(A.WindowsUserName)) = 'ac\' + ltrim(rtrim(H.EmployeeUserName))
inner join ResearchCoverage as RC on RC.DropDate is null
inner join Securities2 as S on RC.SecurityId = S.SecurityId and ltrim(rtrim(S.ISIN)) = ltrim(rtrim(H.ISIN))
where H.EmployeeUserName is not null and ltrim(rtrim(H.EmployeeUserName)) <> ''
and H.ISIN is not null and ltrim(rtrim(H.ISIN)) <> ''
GO
if exists(select * from sys.objects where type = 'P' and name = 'spExportCoverageAuthors')
drop proc dbo.spExportCoverageAuthors
go
if exists(select * from sys.objects where type = 'P' and name = 'spExportCoverageSecurities')
drop proc dbo.spExportCoverageSecurities
go
if exists(select * from sys.objects where type = 'P' and name = 'spExportAuthorTextDisclosures')
drop proc dbo.spExportAuthorTextDisclosures
go
if exists(select * from sys.objects where type = 'P' and name = 'spExportSecurityTextDisclosures')
drop proc dbo.spExportSecurityTextDisclosures
go
if exists(select * from sys.objects where type = 'P' and name = 'spExportFirmDisclosures')
drop proc dbo.spExportFirmDisclosures
go
if exists(select * from sys.objects where type = 'P' and name = 'spExportHoldings')
drop proc dbo.spExportHoldings
go

sp_helptext vHoldings