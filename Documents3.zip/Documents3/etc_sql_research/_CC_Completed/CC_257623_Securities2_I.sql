-- Securities2_I.sql
-- 04/21/2017

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

/*
-- ALTER procs to use varchar(15) for [Securities2.Ticker] & [Securities2.RIC]
-- which otherwise fails with a 11 character Ticker ['CROMPTON.IN']

alter spSearchCoverage              -- Coverage admin
alter spGetCoverage                 -- Coverage admin
alter spGetSecurity                 -- Security admin/Security text disclosures
alter spSaveSecurity                -- Securities admin, save.asp
alter spSearchSecurities            -- Securities admin/securities.asp

-- alter spSaveTickerTable          -- Save Ticker table (legacy)  -- to be dropped with 8/3/2017 CC

alter spGetCompanyMarketDataXml     -- Company Financials
alter spGetCompanyRatingXml         -- Company Financials
alter spGetCompanyEpsXml            -- Company Financials
alter spGetCompanySecurities        -- Company Financials

*/


ALTER PROCEDURE [dbo].[spSearchCoverage]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'
CREATE TABLE #TmpSearch
(
  ID           int IDENTITY,
  CoverageID   int,
  Industry     varchar(50),
  Analyst      varchar(50),
  Ticker       varchar(15),
  Company      varchar(63),
  LaunchDate   datetime,
  LaunchInd    char(1),
  DropDate     datetime,
  Dropind      char(1),
  Editor       varchar(36),
  EditDate     datetime
)
INSERT INTO #TmpSearch (CoverageID, Industry, Analyst, Ticker, Company, LaunchDate, LaunchInd, DropDate, DropInd, Editor, EditDate)
EXEC
(
'SELECT
  C.CoverageID,
  I.IndustryName,
  A.Last,
  S.Ticker,
  S.Company,
  C.LaunchDate,
  C.LaunchInd,
  C.DropDate,
  C.DropInd,
  E.UserName,
  C.EditDate
FROM ResearchCoverage C
JOIN Industries I ON I.IndustryID = C.IndustryID
JOIN Authors A ON A.AuthorID = C.AnalystID
LEFT JOIN Securities2 S ON S.SecurityID = C.SecurityID -- SecurityID OPTIONAL, THEREFORE LEFT JOIN
LEFT JOIN Users E ON E.UserID = C.EditorID
ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT CoverageID, Industry, Analyst, Ticker, Company, LaunchDate, LaunchInd, DropDate, DropInd, Editor, EditDate
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO

ALTER PROCEDURE [dbo].[spGetCoverage]
  @CoverageID   int,
  @IndustryID   int         OUTPUT,
  @Industry     varchar(50) OUTPUT,
  @AnalystID    int         OUTPUT,
  @Analyst      varchar(48) OUTPUT,
  @SecurityID   int         OUTPUT,
  @Ticker       varchar(15) OUTPUT,
  @Company      varchar(63) OUTPUT,
  @LaunchDate   datetime    OUTPUT,
  @LaunchInd    char(1)     OUTPUT,
  @DropDate     datetime    OUTPUT,
  @DropInd      char(1)     OUTPUT,
  @Editor       varchar(36) OUTPUT,
  @EditDate     datetime    OUTPUT
AS
-- RETURN OUTPUT PARAMETERS
SELECT
  @IndustryID   = RC.IndustryID,
  @Industry     = I.IndustryName,
  @AnalystID    = RC.AnalystID,
  @Analyst      = A.Name,
  @SecurityID   = S.SecurityID,
  @Ticker       = S.Ticker,
  @Company      = S.Company,
  @LaunchDate   = RC.LaunchDate,
  @LaunchInd    = RC.LaunchInd,
  @DropDate     = RC.DropDate,
  @DropInd      = RC.DropInd,
  @Editor       = E.UserName,
  @EditDate     = RC.EditDate
FROM ResearchCoverage RC
JOIN Industries I ON I.IndustryID = RC.IndustryID
JOIN Authors A ON A.AuthorID = RC.AnalystID
LEFT JOIN Securities2 S ON S.SecurityID = RC.SecurityID
LEFT JOIN Users E ON E.UserID = RC.EditorID
WHERE RC.CoverageID = @CoverageID

-- RETURN ROWSET - Related coverage
select RC.CoverageId, RC.SecurityId, S.Ticker, S.Company, RC.LaunchDate, RC.LaunchInd, RC.DropDate, RC.DropInd, S.Alias
from ResearchCoverage RC
join Securities2 S on S.SecurityID  = RC.SecurityID
where RC.IndustryId = @IndustryId and RC.AnalystId = @AnalystId
order by S.Company

GO

ALTER PROCEDURE [dbo].[spGetSecurity]
  @SecurityId     int,
  @Ticker         varchar(15) OUTPUT,
  @TickerType     varchar(10) OUTPUT,
  @Company        varchar(63) OUTPUT,
  @BLOOMBERG      varchar(15) OUTPUT,
  @RIC            varchar(15) OUTPUT,
  @CUSIP          varchar(10) OUTPUT,
  @SEDOL          varchar(10) OUTPUT,
  @CINS           varchar(10) OUTPUT,
  @ISIN           varchar(12) OUTPUT,
  @VALOREN        varchar(20) OUTPUT,
  @ExchangeCode   varchar(10) OUTPUT,
  @CurrencyCode   char(3)     OUTPUT,
  @BenchmarkIndex varchar(10) OUTPUT,
  @CountryCode    char(2)     OUTPUT,
  @RegionId       int         OUTPUT,
  @Active         smallint    OUTPUT,
  @Editor         varchar(36) OUTPUT,
  @EditDate       datetime    OUTPUT,
  @GICS_ID        int         OUTPUT,
  @UsageCt        int         OUTPUT,
  @Alias          varchar(50) OUTPUT,
  @CompanyId      int         OUTPUT
AS
SELECT
  @Ticker         = S.Ticker,
  @TickerType     = S.TickerType,
  @Company        = S.Company,
  @BLOOMBERG      = S.Ticker,
  @RIC            = S.RIC,
  @CUSIP          = S.CUSIP,
  @SEDOL          = S.SEDOL,
  @CINS           = S.CINS,
  @ISIN           = S.ISIN,
  @VALOREN        = S.VALOREN,
  @ExchangeCode   = S.ExchangeCode,
  @CurrencyCode   = S.CurrencyCode,
  @BenchmarkIndex = S.BenchmarkIndex,
  @CountryCode    = S.CountryCode,
  @RegionId       = S.RegionId,
  @Active         = S.IsActive,
  @Editor         = E.UserName,
  @EditDate       = S.EditDate,
  @GICS_ID        = S.GICS_ID,
  @Alias          = S.Alias,
  @CompanyId      = S.CompanyId
FROM Securities2 S
LEFT JOIN Users E ON E.UserId = S.EditorId
WHERE SecurityId = @SecurityId

SELECT @UsageCt = COUNT(*) FROM Properties WHERE PropId = 13 AND PropValue = @Ticker


GO

ALTER PROCEDURE [dbo].[spSaveSecurity]
  @SecurityId     int OUTPUT,
  @TickerType     varchar(10),
  @Company        varchar(63),
  @BLOOMBERG      varchar(15),
  @RIC            varchar(15),
  @CUSIP          varchar(10),
  @SEDOL          varchar(10),
  @CINS           varchar(10),
  @ISIN           varchar(12),
  @VALOREN        varchar(20),
  @ExchangeCode   varchar(10),
  @CurrencyCode   char(3),
  @BenchmarkIndex varchar(10),
  @CountryCode    char(2),
  @RegionId       int,
  @Active         smallint,
  @EditorId       int,
  @GICS_ID        int,
  @Alias          varchar(50),
  @CompanyId      int
AS

BEGIN TRANSACTION

DECLARE
  @Ticker    varchar(15),
  @EditDate  datetime,
  @IsPrimary char(1),
  @OrdNo     int

SELECT
  @Ticker   = ltrim(rtrim(@BLOOMBERG)),
  @EditDate = GETDATE(),
  @Company = ltrim(rtrim(@Company)),
  @BLOOMBERG = ltrim(rtrim(@BLOOMBERG))

-- Automate the following security attributes based on supplied Exchange Code

SELECT
  @CurrencyCode   = CurrencyCode,
  @BenchmarkIndex = BenchmarkIndex,
  @CountryCode    = CountryCode,
  @RegionId       = RegionId
FROM Exchanges WHERE ExchangeCode = @ExchangeCode

-- UPDATE existing security
IF EXISTS (SELECT SecurityId FROM Securities2 WHERE SecurityId = @SecurityId)
  BEGIN
    DECLARE @TickerOld varchar(15), @CompanyOld varchar(63), @CompanyIdOld int
    SELECT @TickerOld = Ticker, @CompanyOld = Company, @CompanyIdOld = CompanyId, @IsPrimary = IsPrimary, @OrdNo = OrdNo
    FROM Securities2 WHERE SecurityId = @SecurityId

    -- Realign existing security with NEW Company

    IF @CompanyId = -1
      BEGIN
        INSERT INTO Companies(Company) SELECT @Company
        SELECT @CompanyId = @@IDENTITY, @IsPrimary = 'Y', @OrdNo = 1

        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('Companies', 'A', @Company, NULL, @CompanyId, @EditorId, @EditDate)
      END

    -- Realign existing security with EXISTING Company

    ELSE
      BEGIN
        IF @CompanyId <> @CompanyIdOld
        BEGIN
          SELECT @Company = ltrim(rtrim(Company)) from Companies WHERE CompanyId = @CompanyId
          IF EXISTS (SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
            SELECT @IsPrimary = 'N', @OrdNo = MAX(OrdNo) + 1 FROM Securities2 WHERE CompanyId = @CompanyId
          ELSE
            SELECT @IsPrimary = 'Y', @OrdNo = 1
        END
      END

    IF @Ticker <> @TickerOld
    BEGIN
      -- Propagate ticker change
      UPDATE Properties    SET PropValue = @Ticker WHERE PropId = 13 AND PropValue = @TickerOld
      UPDATE PropertiesLog SET PropValue = @Ticker WHERE PropId = 13 AND PropValue = @TickerOld
      UPDATE PublicationFinancials SET Ticker = @Ticker WHERE Ticker = @TickerOld
    END

    IF (@CompanyIdOld = @CompanyId) AND (@CompanyOld <> @Company)
    BEGIN
      -- Propagate company change
      UPDATE Companies           SET Company = @Company WHERE Company = @CompanyOld
      UPDATE Securities2         SET Company = @Company WHERE Company = @CompanyOld
      UPDATE ValuationsCompanies SET Company = @Company WHERE Company = @CompanyOld
      UPDATE RisksCompanies      SET Company = @Company WHERE Company = @CompanyOld
    END

    UPDATE Securities2 SET
      TickerType     = @TickerType,
      Company        = @Company,
      Ticker         = @BLOOMBERG,
      RIC            = @RIC,
      CUSIP          = @CUSIP,
      SEDOL          = @SEDOL,
      CINS           = @CINS,
      ISIN           = @ISIN,
      VALOREN        = @VALOREN,
      ExchangeCode   = @ExchangeCode,
      CurrencyCode   = @CurrencyCode,
      BenchmarkIndex = @BenchmarkIndex,
      CountryCode    = @CountryCode,
      RegionId       = @RegionId,
      IsActive       = @Active,
      EditorId       = @EditorId,
      EditDate       = @EditDate,
      GICS_ID        = @GICS_ID,
      Alias          = @Alias,
      CompanyId      = @CompanyId,
      IsPrimary      = @IsPrimary,
      OrdNo          = @OrdNo
    WHERE SecurityId = @SecurityId

    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Securities', 'U', @Ticker + ' | ' + @Company, @TickerOld + ' | ' + @CompanyOld, @SecurityId, @EditorId, @EditDate)

  END

-- ADD new security

ELSE
  BEGIN
    -- Align new security with NEW Company

    IF @CompanyId = -1
      BEGIN
        INSERT INTO Companies(Company) SELECT @Company
        SELECT @CompanyId = @@IDENTITY, @IsPrimary = 'Y', @OrdNo = 1

        INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
        VALUES ('Companies', 'A', @Company, NULL, @CompanyId, @EditorId, @EditDate)
      END

    -- Align new security with EXISTING Company
    ELSE
      BEGIN
        SELECT @Company = ltrim(rtrim(Company)) from Companies WHERE CompanyId = @CompanyId
        IF EXISTS (SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
          SELECT @IsPrimary = 'N', @OrdNo = max(OrdNo) + 1 FROM Securities2 WHERE CompanyId = @CompanyId
        ELSE
          SELECT @IsPrimary = 'Y', @OrdNo = 1
      END

    INSERT INTO Securities2
      (TickerType, Company, Ticker, RIC, CUSIP, SEDOL, CINS, ISIN, VALOREN, ExchangeCode, CurrencyCode, BenchmarkIndex, CountryCode, RegionId, IsActive, EditorId, EditDate, GICS_ID, Alias, CompanyId, IsPrimary, OrdNo)
    VALUES
      (@TickerType, @Company, @BLOOMBERG, @RIC, @CUSIP, @SEDOL, @CINS, @ISIN, @VALOREN, @ExchangeCode, @CurrencyCode, @BenchmarkIndex, @CountryCode, @RegionId, @Active, @EditorId, @EditDate, @GICS_ID, @Alias, @CompanyId, @IsPrimary, @OrdNo)

    SELECT @SecurityId = @@IDENTITY
    INSERT INTO AdminLog ([Table], Operation, New, Old, Id, EditorId, EditDate)
    VALUES ('Securities', 'A', @Ticker + ' | ' + @Company, NULL, @SecurityId, @EditorId, @EditDate)

  END

COMMIT TRANSACTION

RETURN 0



GO

ALTER PROCEDURE [dbo].[spSearchSecurities]
  @SortCol       varchar(5),
  @SortDir       varchar(5),
  @Pg            int,
  @Sz            int,
  @Ct            int OUTPUT,
  @FilterId      int
AS
SET NOCOUNT ON
DECLARE @FirstRow int
DECLARE @LastRow  int
DECLARE @SecurityFilter varchar(255)

IF @SortDir = 'd'
  SELECT @SortDir = ' DESC'
ELSE
  SELECT @SortDir = ' ASC'

/*

Filters:
1 Securities - All
2 Securities - Active
3 Companies - All
4 Companies - Active

*/

IF @FilterId = 1 SET @SecurityFilter = ' '
IF @FilterId = 2 SET @SecurityFilter = 'WHERE S.SecurityId IN (SELECT SecurityId FROM ResearchCoverage WHERE DropDate IS NOT NULL) '
IF @FilterId = 3 SET @SecurityFilter = 'WHERE S.IsPrimary = ''Y'' '
IF @FilterId = 4 SET @SecurityFilter = 'WHERE S.IsPrimary = ''Y'' AND S.SecurityId IN (SELECT SecurityId FROM ResearchCoverage WHERE DropDate IS NOT NULL) '

CREATE TABLE #TmpSearch
(
  ID             int IDENTITY,
  SecurityId     int,
  Ticker         varchar(15),
  RIC            varchar(15),
  Company        varchar(63),
  Exchange       varchar(10),
  Currency       varchar(10),
  BenchmarkIndex varchar(10),
  IsActive       smallint,
  Num            int,
  Editor         varchar(36)     NULL,
  EditDate       datetime        NULL
)
INSERT INTO #TmpSearch (SecurityId, Ticker, RIC, Company, Exchange, Currency, BenchmarkIndex, IsActive, Num, Editor, EditDate)
EXEC
('
SELECT
  S.SecurityId,
  S.Ticker,
  S.RIC,
  S.Company,
  S.ExchangeCode,
  S.CurrencyCode,
  S.BenchmarkIndex,
  S.IsActive,
  Num = (SELECT COUNT(*) FROM Properties WHERE PropId = 13 AND PropValue = Ticker),
  E.UserName,
  S.EditDate
FROM Securities2 S
LEFT JOIN Users E ON E.UserId = S.EditorId '
+ @SecurityFilter +
' ORDER BY ' + @SortCol +  @SortDir
)
SELECT @Ct = Count(*) FROM #TmpSearch
SELECT @FirstRow = (@Pg - 1) * @Sz
SELECT @LastRow = (@Pg * @Sz + 1)
SELECT SecurityId, Company, Ticker, RIC, Exchange, Currency, BenchmarkIndex, IsActive, Num, Editor, EditDate
  FROM #TmpSearch WHERE ID > @FirstRow AND ID < @LastRow
SET NOCOUNT OFF

GO

/*
ALTER PROCEDURE [dbo].[spSaveTickerTable]
  @PubNo          int,
  @TickerTableXML text
AS
DECLARE @hDoc int
DECLARE @RelPerfType varchar(10)
DELETE FROM TickerTableSecurities    WHERE PubNo = @PubNo
DELETE FROM TickerTableSecuritiesOld WHERE PubNo = @PubNo
DELETE FROM Footnotes                WHERE PubNo = @PubNo
DELETE FROM FootnoteRefs             WHERE PubNo = @PubNo
DELETE FROM TickerTables             WHERE PubNo = @PubNo

-- 03/28/2012 - Enforce encoding standard
-- Replace xml header <?xml version="1.0"?> with <?xml version="1.0" encoding="ISO8859-1" ?>
DECLARE @TickerTableXmlString VARCHAR(MAX)
SET @TickerTableXmlString = REPLACE(CONVERT(varchar(max), @TickerTableXML), '<?xml version="1.0"?>', '') -- Strip
SET @TickerTableXmlString = '<?xml version="1.0" encoding="ISO8859-1" ?>' + @TickerTableXmlString        -- Prepend

EXEC sp_xml_preparedocument @hDoc OUTPUT, @TickerTableXmlString

--DETERMINE RELATIVE PERFORMANCE TYPE
IF EXISTS(SELECT Isnull(ttmRelPerf,'') FROM OPENXML (@hDoc , '/TickerTable/Security',1) WITH (ttmRelPerf varchar(10) '@ttmRelPerf') WHERE Isnull(ttmRelPerf,'') <> '')
  SET @RelPerfType = 'TTM'
ELSE
  SET @RelPerfType = 'YTD'

-- ACCOMMODATE 2 VERSIONS OF TICKER TABLE XML
IF (SELECT DisplayCloseDate FROM OPENXML (@hDoc, '/TickerTable', 1) WITH (DisplayCloseDate varchar(12) '@displayCloseDate')) IS NOT NULL
  INSERT INTO TickerTables (PubNo, EPSType, MetricType, DisplayCloseDate, LastYear, ThisYear, NextYear, RelPerfType)
  --SELECT * FROM OPENXML (@hDoc, '/TickerTable', 1)
  SELECT PubNo,EPSType,MetricType,DisplayCloseDate,LastYear,ThisYear,NextYear,@RelPerfType
  FROM OPENXML (@hDoc, '/TickerTable', 1)
  WITH (PubNo int '@pubNo', EPSType varchar(10) '@epsType', MetricType varchar(10) '@metricType', DisplayCloseDate varchar(12) '@displayCloseDate',
        LastYear varchar(5) '@lastYear', ThisYear varchar(5) '@thisYear', NextYear varchar(5) '@nextYear')
ELSE
  INSERT INTO TickerTables (PubNo, EPSType, MetricType, DisplayCloseDate, LastYear, ThisYear, NextYear, RelPerfType)
  --SELECT * FROM OPENXML (@hDoc, '/TickerTable', 1)
  SELECT PubNo,EPSType,MetricType,DisplayCloseDate,LastYear,ThisYear,NextYear,@RelPerfType
  FROM OPENXML (@hDoc, '/TickerTable', 1)
  WITH (PubNo int '@pubNo', EPSType varchar(10) '@epsType', MetricType varchar(10) '@metricType', DisplayCloseDate varchar(10) '//Security/@closeDate',
        LastYear varchar(5) '@lastYear', ThisYear varchar(5) '@thisYear', NextYear varchar(5) '@nextYear')

INSERT INTO TickerTableSecurities (PubNo, Ticker, Rating, Currency, CloseDate, ClosePrice, TargetPrice, YTDRelPerf, EPSLastYear, EPSThisYear, EPSNextYear, MetricLastYear, MetricThisYear, MetricNextYear, Yield, TickerOrder)
SELECT @PubNo, Ticker, Rating, Currency, CloseDate, ClosePrice, TargetPrice,
      CASE IsNull(YTDRelPerf,'') when '' then IsNull(TTMRelPerf,'') else YTDRelPerf end YTDRelPerf,
      EPSLastYear, EPSThisYear, EPSNextYear, MetricLastYear, MetricThisYear, MetricNextYear, Yield, TickerOrder
FROM OPENXML (@hDoc, '/TickerTable/Security', 1)
WITH (Ticker varchar(15) '@ticker', Rating char(1) '@rating', Currency char(3) '@currency', CloseDate datetime '@closeDate',
      ClosePrice varchar(10) '@closePrice', TargetPrice varchar(10) '@targetPrice', YTDRelPerf varchar(10) '@ytdRelPerf',TTMRelPerf varchar(10) '@ttmRelPerf',
      EPSLastYear varchar(10) '@epsLastYear', EPSThisYear varchar(10) '@epsThisYear', EPSNextYear varchar(10) '@epsNextYear',
      MetricLastYear varchar(10) '@metricLastYear', MetricThisYear varchar(10) '@metricThisYear',
      MetricNextYear varchar(10) '@metricNextYear', Yield varchar(10) '@yield', TickerOrder int '@tickerOrder')

IF EXISTS (SELECT @PubNo, * FROM OPENXML (@hDoc, '/TickerTable/Security/Old', 1) WITH (Ticker varchar(10) '@ticker', Rating char(1) '@rating', TargetPrice varchar(10) '@targetPrice', EPSThisYear varchar(10) '@epsThisYear', EPSNextYear varchar(10) '@epsNextYear'))
  INSERT INTO TickerTableSecuritiesOld (PubNo, Ticker, Rating, TargetPrice, EPSThisYear, EPSNextYear)
  SELECT @PubNo,* FROM OPENXML (@hDoc, '/TickerTable/Security/Old', 1)
  WITH (Ticker varchar(15) '../@ticker', Rating char(1) '@rating', TargetPrice varchar(10) '@targetPrice', EPSThisYear varchar(10) '@epsThisYear', EPSNextYear varchar(10) '@epsNextYear')

IF EXISTS (SELECT @PubNo, * FROM OPENXML (@hDoc, '/TickerTable/Footnote', 1) WITH (Text varchar(2048) '@text'))
  BEGIN
    INSERT INTO Footnotes (PubNo, FootnoteText)
    SELECT @PubNo, Text FROM OPENXML (@hDoc, 'TickerTable/Footnote') WITH (Text varchar(2048) '@text')
    WHERE Text <> ''

    INSERT INTO FootnoteRefs (PubNo, FootnoteRef)
    SELECT @PubNo, Ref FROM OPENXML (@hDoc, 'TickerTable/Footnote/Ref') WITH (Ref varchar(2048) '@ref')
    WHERE Ref <> ''
  END

--Krishna's change starts here 05/27/2008
--Update ActionTags & CoverageId for the tickers
SELECT @PubNo PubNo,Ticker
INTO #tmp
FROM OPENXML (@hDoc, '/TickerTable/Security', 1)
WITH (Ticker varchar(15) '@ticker')

DELETE FROM #tmp WHERE Ticker IN (SELECT Ticker FROM Securities2 WHERE TickerType = 'Index')

--Check if anyone of the authors on the report is a migrated analyst
DECLARE @IsMigratedAnalystOnReport INT
SET @IsMigratedAnalystOnReport = 0
IF EXISTS(SELECT M.* FROM Migratedanalysts M JOIN ResearchCoverage RC ON M.AnalystId = RC.AnalystID
          JOIN Securities2 S ON RC.SecurityId = S.SecurityId WHERE S.Ticker IN (SELECT Ticker FROM #tmp))
BEGIN
  SET @IsMigratedAnalystOnReport = 1
END

--Loop through all the tickers in publication and update action tags
DECLARE
  @Ticker         varchar(15),
  @PubDate        datetime,
  @Rating         char(1),
  @RatingOld      char(1),
  @TargetPrice    varchar(10),
  @TargetPriceOld varchar(10),
  @EPSThisYear    varchar(10),
  @EPSThisYearOld varchar(10),
  @EPSNextYear    varchar(10),
  @EPSNextYearOld varchar(10),
  @TickerCount    int

SELECT @TickerCount = Count(*) FROM #tmp
SELECT top 1 @Ticker = Ticker FROM #tmp
DECLARE @SecurityId int
WHILE @@rowcount > 0
BEGIN
  SELECT @PubDate = Date,@Rating = TTS.Rating,@RatingOld = TTSO.Rating,@TargetPrice = TTS.TargetPrice,
      @TargetPriceOld = TTSO.TargetPrice,@EPSThisYear = TTS.EPSThisYear,@EPSThisYearOld = TTSO.EPSThisYear,@EPSNextYear = TTS.EPSNextYear,@EPSNextYearOld = TTSO.EPSNextYear
  FROM
      Publications P join TickerTableSecurities TTS on P.PubNo = TTS.PubNo
      left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
  WHERE
      TTS.Ticker = @Ticker and
      TTS.PubNo = @PubNo

  EXEC spUpdateActionTags @PubNo, @Ticker,@PubDate,@Rating,@RatingOld,@TargetPrice,@TargetPriceOld,@EPSThisYear,@EPSThisYearOld,@EPSNextYear,@EPSNextYearOld
  EXEC spMirrorFinancialNumbers @PubNo, @Ticker,@PubDate,@Rating,@RatingOld,@TargetPrice,@TargetPriceOld,@EPSThisYear,@EPSThisYearOld,@EPSNextYear,@EPSNextYearOld
  SELECT @SecurityId = SecurityId FROM Securities2 WHERE Ticker = @Ticker
  --Revaluate for each ticker only if ticker count less than or equal to 20
  IF @TickerCount <= 20
  BEGIN
    EXEC spRevaluate @SecurityId
  END
  DELETE FROM #tmp WHERE Ticker = @Ticker
  SELECT top 1 @Ticker = Ticker FROM #tmp
END
DROP TABLE #Tmp
--Revaluate all only once if ticker count > 15
IF @TickerCount > 20
BEGIN
  EXEC spRevaluate
END
--If anyone of the authors is a migrated analyst, request to regenerate TickerTableDraft.xml
IF @IsMigratedAnalystOnReport = 1
BEGIN
  UPDATE JobSchedules
  SET NextRunTime = DATEADD(mi,1,getdate())
  FROM JobSchedules JS JOIN Jobs J ON JS.JobId = J.JobId
  JOIN Schedules S ON JS.ScheduleId = S.ScheduleId
  WHERE
  S.Description = 'Revaluate Ticker Table XML'
END
--Krishna's change ends here

EXEC sp_xml_removedocument @hDoc


GO
*/


ALTER PROCEDURE [dbo].[spGetCompanyMarketDataXml]
  @InXml TEXT
AS

SET NOCOUNT ON

DECLARE @CompanyId            INT,
        @Company              VARCHAR(60),
        @SelectedSecurityId   INT,
        @BenchmarkIndexId     INT,
        @BenchmarkIndex       VARCHAR(10),
        @Ticker               varchar(15),
        @TargetPrice          VARCHAR(30),
        @TargetPriceDesc      VARCHAR(50),
        @TargetPriceIsDraft   SMALLINT,
        @TargetPriceIsBold    CHAR,
        @TargetPriceCurCode   CHAR(3),
        @ClosePrice           VARCHAR(50),
        @UpsideDownsideRatio  VARCHAR(20),
        @TradeCurrency        VARCHAR(20),
        @FundCurrency         VARCHAR(20),
        @ClosePriceCurrency   VARCHAR(20),
        @hDoc                 INT,
        @Date                 DATETIME,
        @Type                 VARCHAR(31),
        @Title                VARCHAR(255),
        @RptPubNo             INT,
        @Version              INT,
        @SecurityId           INT,
        @IndicateChange       VARCHAR(10),
        @IsEstimatesScreen    VARCHAR(5),
        @FinancialsHeaderRow  VARCHAR(4000),
        @FinancialsXml        XML,
        @PublicationsXml      XML,
        @PublicationsLastChangeXml    XML,
        @CompanyFinancialXml  VARCHAR(MAX)

EXEC sp_xml_preparedocument @hDoc OUTPUT, @InXml

SELECT @Date = X.Date, @Type = X.Type, @Title = X.Title
FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
WITH (Date datetime '@pubDate', Type varchar(31) '@type', Title varchar(255) '@title' ) X

EXEC spCheckForResubmits @Date, @Type, @Title, @RptPubNo OUTPUT, @Version OUTPUT

SELECT
  ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo,
  S.SecurityId, X.Ticker, X.IndicateChange, S.Company, S.CompanyId,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'live', @RptPubNo) AS SourceLive,
  ISNULL(X.LastPubNo, '') AS LastChangePubNo,
  CASE WHEN X.CoverageId IS NULL OR X.CoverageId = '' OR X.CoverageId = '0' THEN RC.CoverageId
       ELSE X.CoverageId
  END AS CoverageId
INTO #TickerList
FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
WITH (SecurityId int '@id', Ticker varchar(30) '@ticker', IndicateChange  varchar(30) '@indicateChange', LastPubNo int '@optLastPubNo', CoverageId INT '@coverageId') X
INNER JOIN Securities2 S ON S.Ticker = X.Ticker
INNER JOIN ResearchCoverage RC ON RC.SecurityId = S.SecurityId AND RC.DropDate IS NULL

-- Get the Company of the first ticker in the list
SELECT TOP 1 @SecurityId = SecurityId, @CompanyId = CompanyId, @Company = Company, @Ticker = Ticker FROM #TickerList

IF NOT EXISTS(SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
BEGIN
  SELECT '<NotExist>' + 'Missing Company for provided Ticker. Security Id:' + CONVERT(VARCHAR, @SecurityId) + '</NotExist>' AS XML
  RETURN
END

SELECT @IsEstimatesScreen = X.IsEstimatesScreen
FROM OPENXML (@hDoc, 'DocumentInfo/Securities', 1)
WITH (IsEstimatesScreen varchar(5) '@isEstimatesScreen') X

IF @IsEstimatesScreen = 'yes'
  SELECT @SelectedSecurityId = @SecurityId
-- Get Primary Ticker for the Company
ELSE IF EXISTS(SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
  SELECT @SelectedSecurityId = SecurityId FROM Securities2 WHERE CompanyId = @CompanyId AND IsPrimary = 'Y'
ELSE
  SELECT @SelectedSecurityId = @SecurityId

-- Get Benchmark Index for the selected Ticker
SELECT @BenchmarkIndexId = SecurityId     FROM Securities2 WHERE Ticker = ( SELECT BenchmarkIndex FROM Securities2  WHERE SecurityId = @SelectedSecurityId)
SELECT @BenchmarkIndex   = BenchmarkIndex FROM Securities2 WHERE SecurityId = @SelectedSecurityId

-- Get Indicate Change for primary ticker
SELECT @IndicateChange = IndicateChange FROM #TickerList WHERE SecurityId = @SelectedSecurityId

-- Get Target Price value -  primary ticker [Calculate Upside/Downside]
SELECT
  @TargetPriceDesc = FNT.ShortName,
  -- target price value
  @TargetPrice = (CASE WHEN FN2.Value IS NOT NULL AND @IndicateChange = 'yes' THEN FN2.Value ELSE FN.Value END),
  -- target price flag - draft[1] or live[0]
  @TargetPriceIsDraft = (CASE WHEN FN2.Value IS NOT NULL AND @IndicateChange = 'yes' THEN 1 ELSE 0 END),
  @TargetPriceIsBold  = (CASE WHEN FN2.Value IS NOT NULL AND FN.Value IS NOT NULL AND @IndicateChange = 'yes' THEN 'Y' ELSE 'N' END),
  @TargetPriceCurCode = (CASE WHEN FN2.Value IS NOT NULL AND @IndicateChange = 'yes' THEN FN2.CurCode ELSE FN.CurCode END)
FROM #TickerList TL
INNER JOIN FinancialNumberTypes FNT ON  FNT.FinancialNumberType IN ('TARGETPRICE')
-- Only data for active ticker coverage (not dropped/suspended) using active CoverageId
LEFT JOIN vFinancialNumbersLatest FN ON FN.SecurityId = TL.SecurityId
                                    AND FN.CoverageId = TL.CoverageId
                                    AND FN.FinancialNumberTypeId = FNT.FinancialNumberTypeId
                                    AND FN.IsDraft = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                     AND FN2.CoverageId= TL.CoverageId
                                     AND FN2.FinancialNumberTypeId = FNT.FinancialNumberTypeId
                                     AND FN2.IsDraft = 1  -- Draft
WHERE TL.SecurityId = @SelectedSecurityId

-- Get data from the 3 sources and then set the Target Price
-- Get the PubXml for last report
SELECT @PublicationsXml = CompanyFinancialsXml FROM PublicationsXML  WHERE PubNo = @RptPubNo

-- Get the PubXml for last change report
SELECT @PublicationsLastChangeXml = CompanyFinancialsXml FROM PublicationsXML
WHERE PubNo = (SELECT LastChangePubNo FROM #TickerList WHERE SecurityId = @SelectedSecurityId)

-- Get Close Price - primary ticker [Calculate Upside/Downside]
SELECT @ClosePrice = VMD.Value
FROM FinancialNumberTypes FNT
INNER JOIN vMarketData VMD on FNT.FinancialNumberTypeId = VMD.FinancialNumberTypeId and FNT.FinancialNumberType  = 'CLOSEPRICE'
WHERE VMD.SecurityId = @SelectedSecurityId

-- Get Trade Currency [Market Cap]
SELECT @TradeCurrency = VMD.Value
FROM vMarketDataLatest VMD
INNER JOIN FinancialNumberTypes FNT ON FNT.FinancialNumberTypeId = VMD.FinancialNumberTypeId AND FNT.FinancialNumberType = 'CRNCY'
WHERE SecurityId = @SelectedSecurityId AND VMD.Type = 'B'

-- Get Fundamental Currency [EV]
SELECT @FundCurrency = Value
FROM vMarketDataLatest VMD
INNER JOIN FinancialNumberTypes FNT ON FNT.FinancialNumberTypeId = VMD.FinancialNumberTypeId AND FNT.FinancialNumberType = 'EQY_FUND_CRNCY'
WHERE SecurityId = @SelectedSecurityId AND VMD.Type = 'B'

-- Get Close Price Currency [Close Price] - handle exceptions for GBp
SELECT @ClosePriceCurrency = CurrencyCode FROM Securities2 WHERE SecurityId = @SelectedSecurityId

-- Calculate Upside/Downside - primary ticker
IF @ClosePrice = '' OR @ClosePrice = '0'
  SELECT @UpsideDownsideRatio = ''
ELSE IF ISNUMERIC(@TargetPrice) = 0
  SELECT @UpsideDownsideRatio = 'NM'
ELSE
  SELECT @UpsideDownsideRatio =  (CONVERT(FLOAT, @TargetPrice) - CONVERT(FLOAT, @ClosePrice) ) * 100 / CONVERT(FLOAT, @ClosePrice)

-- get DisplayUnits for certain marketdata fields
SELECT vmd.SecurityId, vmd.FinancialNumberType, vmd.Value, fnt.UnitMultiplier,
       dbo.fnCalculateDisplayUnits(vmd.Value, fnt.UnitMultiplier) AS DisplayUnits
INTO #TmpMarketdataStyles
FROM vMarketData vmd
INNER JOIN FinancialNumberTypes fnt on fnt.FinancialNumberTypeId = vmd.FinancialNumberTypeId
WHERE vmd.SecurityID = @SelectedSecurityId
AND fnt.FinancialNumberType IN ('CUR_MKT_CAP', 'EV')

-- Get Latest Financials data in a XML variable
SET @FinancialsXml =
(
SELECT * FROM
(
SELECT
  1                      AS tag,
  null                   AS parent,
  @Company               AS [MarketData!1!company],
  @CompanyId             AS [MarketData!1!companyId],
  @Ticker                AS [MarketData!1!ticker],
  @BenchmarkIndex        AS [MarketData!1!index],
  @SecurityId            AS [MarketData!1!paramSecurityId],
  NULL                   AS [MarketDataRow!2!ticker],
  NULL                   AS [MarketDataRow!2!financialNumberType],
  NULL                   AS [MarketDataRow!2!label],
  NULL                   AS [MarketDataRow!2!value],
  NULL                   AS [MarketDataRow!2!curCode],
  NULL                   AS [MarketDataRow!2!isDraft],
  NULL                   AS [MarketDataRow!2!isBold],
  ''                     AS [MarketDataRow!2!tickerType],
  NULL                   AS [MarketDataRow!2!units],
  NULL                   AS [MarketDataRow!2!format],
  NULL                   AS [MarketDataRow!2!dispOrder]

UNION ALL

SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [MarketData!1!company],
  NULL                    AS [MarketData!1!companyId],
  NULL                    AS [MarketData!1!ticker],
  NULL                    AS [MarketData!1!index],
  NULL                    AS [MarketData!1!paramSecurityId],
  MAX(S.Ticker)           AS [MarketDataRow!2!ticker],
  fnt.FinancialNumberType AS [MarketDataRow!2!financialNumberType],
  MAX(fnt.ShortName)      AS [MarketDataRow!2!label],
  CASE
     WHEN fnt.FinancialNumberType IN ('CUR_MKT_CAP','EV') AND MAX(ISNUMERIC(vmd.Value)) = 1
     THEN MAX(dbo.fnConvertDisplayUnits(vmd.Value, TS.DisplayUnits))
     ELSE MAX(vmd.Value)
  END                     AS [MarketDataRow!2!value],
  CASE
     WHEN fnt.FinancialNumberType = 'CLOSEPRICE'     THEN @ClosePriceCurrency
     WHEN fnt.FinancialNumberType = 'CUR_MKT_CAP'    THEN UPPER(@TradeCurrency)
     WHEN fnt.FinancialNumberType = 'EV'             THEN @FundCurrency
     ELSE ''
  END                     AS [MarketDataRow!2!curCode],
  NULL                    AS [MarketDataRow!2!isDraft],
  NULL                    AS [MarketDataRow!2!isBold],
  'STOCK'                 AS [MarketDataRow!2!tickerType],
  CASE
    -- Get Display Units Style for EV, Market Cap
    WHEN fnt.FinancialNumberType IN ('CUR_MKT_CAP','EV')
    THEN MAX([dbo].[fnCalculateDisplayUnitsStyle](TS.DisplayUnits))
    ELSE ''
  END                               AS [MarketDataRow!2!units],
  MAX(ISNULL(fnt.Format,''))        AS [MarketDataRow!2!format],
  CASE
    WHEN fnt.FinancialNumberType = 'CLOSEPRICE'        THEN 2
    WHEN fnt.FinancialNumberType = '52_WEEK_LOW'       THEN 6
    WHEN fnt.FinancialNumberType = '52_WEEK_HIGH'      THEN 7
    WHEN fnt.FinancialNumberType = 'EQY_DVD_YLD_IND'   THEN 10
    WHEN fnt.FinancialNumberType = 'CUR_MKT_CAP'       THEN 11
    WHEN fnt.FinancialNumberType = 'EV'                THEN 12
    ELSE 99999
  END                      AS [MarketDataRow!2!dispOrder]
FROM vMarketData vmd
INNER JOIN FinancialNumberTypes fnt on fnt.FinancialNumberTypeId = vmd.FinancialNumberTypeId
INNER JOIN Securities2 S ON S.SecurityId = vmd.SecurityId
LEFT JOIN #TmpMarketdataStyles TS ON TS.SecurityId = vmd.SecurityId AND TS.FinancialNumberType = vmd.FinancialNumberType
WHERE vmd.SecurityID = @SelectedSecurityId
  AND fnt.FinancialNumberType IN ('CLOSEPRICE', '52_WEEK_HIGH', '52_WEEK_LOW','EQY_DVD_YLD_IND', 'CUR_MKT_CAP', 'EV')
GROUP BY fnt.FinancialNumberType

UNION ALL

SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [MarketData!1!company],
  NULL                    AS [MarketData!1!companyId],
  NULL                    AS [MarketData!1!ticker],
  NULL                    AS [MarketData!1!index],
  NULL                    AS [MarketData!1!paramSecurityId],
  S.Ticker                AS [MarketDataRow!2!ticker],
  fnt.FinancialNumberType AS [MarketDataRow!2!financialNumberType],
  fnt.ShortName           AS [MarketDataRow!2!label],
  DATENAME(dd, vmd.Value) + '-' + LEFT(DATENAME(mm, vmd.Value),3) + '-' + DATENAME(yy, vmd.Value)   AS [MarketDataRow!2!value],
  NULL                    AS [MarketDataRow!2!curCode],
  NULL                    AS [MarketDataRow!2!isDraft],
  NULL                    AS [MarketDataRow!2!isBold],
  'STOCK'                 AS [MarketDataRow!2!tickerType],
  ''                      AS [MarketDataRow!2!units],
  ISNULL(fnt.Format,'')   AS [MarketDataRow!2!format],
  1                       AS [MarketDataRow!2!dispOrder]
FROM vMarketData vmd
INNER JOIN FinancialNumberTypes fnt on fnt.FinancialNumberTypeId = vmd.FinancialNumberTypeId
INNER JOIN Securities2 S ON S.SecurityId = vmd.SecurityId
WHERE vmd.SecurityID = @SelectedSecurityId
AND fnt.FinancialNumberType IN ('CLOSEDATE')

UNION ALL

-- FYE
SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [MarketData!1!company],
  NULL                    AS [MarketData!1!companyId],
  NULL                    AS [MarketData!1!ticker],
  NULL                    AS [MarketData!1!index],
  NULL                    AS [MarketData!1!paramSecurityId],
  S.Ticker                AS [MarketDataRow!2!ticker],
  fnt.FinancialNumberType AS [MarketDataRow!2!financialNumberType],
  fnt.ShortName           AS [MarketDataRow!2!label],
  CASE
    WHEN ISNULL(vmd.Value,'') != ''
    THEN CONVERT(Varchar(3), DATENAME(MONTH, Left(vmd.Value,3) + '01/' + SUBSTRING(vmd.Value, 4, 4)))
    ELSE ''
  END                     AS [MarketDataRow!2!value],
  NULL                    AS [MarketDataRow!2!curCode],
  NULL                    AS [MarketDataRow!2!isDraft],
  NULL                    AS [MarketDataRow!2!isBold],
  'STOCK'                 AS [MarketDataRow!2!tickerType],
  ''                      AS [MarketDataRow!2!units],
  ISNULL(fnt.Format,'')   AS [MarketDataRow!2!format],
  9                       AS [MarketDataRow!2!dispOrder]
FROM vMarketData vmd
INNER JOIN FinancialNumberTypes fnt on fnt.FinancialNumberTypeId = vmd.FinancialNumberTypeId
INNER JOIN Securities2 S ON S.SecurityId = vmd.SecurityId
WHERE vmd.SecurityID = @SelectedSecurityId
AND fnt.FinancialNumberType IN ('EQY_FISCAL_YR_END')

UNION ALL

-- Target Price - Ticker
SELECT
  2                          AS tag,
  1                          AS parent,
  NULL                       AS [MarketData!1!company],
  NULL                       AS [MarketData!1!companyId],
  NULL                       AS [MarketData!1!ticker],
  NULL                       AS [MarketData!1!index],
  NULL                       AS [MarketData!1!paramSecurityId],
  S.Ticker                   AS [MarketDataRow!2!ticker],
  'TARGETPRICE'              AS [MarketDataRow!2!financialNumberType],
  @TargetPriceDesc           AS [MarketDataRow!2!label],
  CASE WHEN ISNUMERIC(@TargetPrice) = 0 THEN @TargetPrice
       ELSE CAST(CAST(@TargetPrice AS DECIMAL(30,2)) AS VARCHAR(50))
  END
                             AS [MarketDataRow!2!value],
  @TargetPriceCurCode        AS [MarketDataRow!2!curCode],
  @TargetPriceIsDraft        AS [MarketDataRow!2!isDraft],
  @TargetPriceIsBold         AS [MarketDataRow!2!isBold],
  'STOCK'                    AS [MarketDataRow!2!tickerType],
  ''                         AS [MarketDataRow!2!units],
  ''                         AS [MarketDataRow!2!format],
  3                          AS [MarketDataRow!2!dispOrder]
FROM Securities2 S
WHERE S.SecurityId = @SelectedSecurityId

UNION ALL

-- Upside/(Downside) - Ticker
SELECT
  2                          AS tag,
  1                          AS parent,
  NULL                       AS [MarketData!1!company],
  NULL                       AS [MarketData!1!companyId],
  NULL                       AS [MarketData!1!ticker],
  NULL                       AS [MarketData!1!index],
  NULL                       AS [MarketData!1!paramSecurityId],
  S.Ticker                   AS [MarketDataRow!2!ticker],
  'UPSIDEDOWNSIDE'           AS [MarketDataRow!2!financialNumberType],
  'Upside/(Downside)'        AS [MarketDataRow!2!label],
  @UpsideDownsideRatio       AS [MarketDataRow!2!value],
  NULL                       AS [MarketDataRow!2!curCode],
  NULL                       AS [MarketDataRow!2!isDraft],
  NULL                       AS [MarketDataRow!2!isBold],
  'STOCK'                    AS [MarketDataRow!2!tickerType],
  ''                         AS [MarketDataRow!2!units],
  ''                         AS [MarketDataRow!2!format],
  5                          AS [MarketDataRow!2!dispOrder]
FROM Securities2 S
WHERE S.SecurityId = @SelectedSecurityId

UNION ALL

-- Close Price - Index
SELECT
  2                       AS tag,
  1                       AS parent,
  NULL                    AS [MarketData!1!company],
  NULL                    AS [MarketData!1!companyId],
  NULL                    AS [MarketData!1!ticker],
  NULL                    AS [MarketData!1!index],
  NULL                    AS [MarketData!1!paramSecurityId],
  MAX(S.Ticker)           AS [MarketDataRow!2!ticker],
  FNT.FinancialNumberType AS [MarketDataRow!2!financialNumberType],
  MAX(FNT.ShortName)      AS [MarketDataRow!2!label],
  MAX(vmd.Value)          AS [MarketDataRow!2!value],
  NULL                    AS [MarketDataRow!2!curCode],
  NULL                    AS [MarketDataRow!2!isDraft],
  NULL                    AS [MarketDataRow!2!isBold],
  'INDEX'                 AS [MarketDataRow!2!tickerType],
  ''                            AS [MarketDataRow!2!units],
  MAX(ISNULL(fnt.Format,''))    AS [MarketDataRow!2!format],
  8                             AS [MarketDataRow!2!dispOrder]
FROM vMarketData vmd
inner join FinancialNumberTypes fnt on fnt.FinancialNumberTypeId = vmd.FinancialNumberTypeId and fnt.FinancialNumberType  = 'CLOSEPRICE'
INNER JOIN Securities2 S ON S.SecurityId = vmd.SecurityId
WHERE vmd.SecurityID = @BenchmarkIndexId
GROUP BY fnt.FinancialNumberType
) X

ORDER BY tag, [MarketDataRow!2!dispOrder] ASC
FOR XML Explicit
)

-- For v1(IndicateChange=no,yes), use the latest FinancialNumbers data
If @RptPubNo = 0 AND NOT EXISTS(SELECT * FROM #TickerList WHERE IndicateChange = 'last')
BEGIN
  SELECT @FinancialsXml
  RETURN
END

-- Get the PubXml for last report
SELECT @PublicationsXml = CompanyFinancialsXml FROM PublicationsXML  WHERE PubNo = @RptPubNo

-- Get the PubXml for last change report
SELECT @PublicationsLastChangeXml = CompanyFinancialsXml FROM PublicationsXML
WHERE PubNo = (SELECT LastChangePubNo FROM #TickerList WHERE SecurityId = @SelectedSecurityId)

-- Selectively fetch applicable rows (by ticker) from one of the 3 xml sources
-- Source: FinancialsXml
SELECT
  CONVERT(varchar(MAX),F.c.query('.')) AS result,
  F.c.value('./@dispOrder', 'INT')     AS dispOrder
INTO #CompanyFinancialXml
FROM #TickerList TL
JOIN @FinancialsXml.nodes('/MarketData/MarketDataRow') F(c)
     ON TL.SecurityId = CAST(F.c.value('../@paramSecurityId', 'INT') AS INT)
WHERE TL.SourceLive = 'FN'

UNION

-- Source: PublicationsXml for last Report
SELECT
  CONVERT(varchar(MAX),P.c.query('.')) AS result,
  P.c.value('./@dispOrder', 'INT')     AS dispOrder
FROM #TickerList TL
JOIN @PublicationsXml.nodes('/CompanyFinancials/MarketData/MarketDataRow') P(c)
     ON TL.SecurityId = CAST(P.c.value('../@paramSecurityId', 'INT') AS INT)
  WHERE TL.SourceLive = 'PX'

UNION

-- Source: PublicationsXml for last Change Report
SELECT
  CONVERT(varchar(MAX),PC.c.query('.')) AS result,
  PC.c.value('./@dispOrder', 'INT')     AS dispOrder
FROM #TickerList TL
JOIN @PublicationsLastChangeXml.nodes('/CompanyFinancials/MarketData/MarketDataRow') PC(c)
     ON TL.SecurityId = CAST(PC.c.value('../@paramSecurityId', 'INT') AS INT)
  WHERE TL.SourceLive = 'PXLAST'

ORDER BY 2

SET @FinancialsHeaderRow = '<MarketData company="' + [dbo].[fnCheckSpecialCharacters](@Company) + '"'
SET @FinancialsHeaderRow = @FinancialsHeaderRow + ' companyId="' + CONVERT(varchar, @CompanyId) + '"'
SET @FinancialsHeaderRow = @FinancialsHeaderRow + ' ticker="' + @Ticker + '"'
SET @FinancialsHeaderRow = @FinancialsHeaderRow + ' index="' + @BenchmarkIndex + '"'
SET @FinancialsHeaderRow = @FinancialsHeaderRow + ' paramSecurityId="' + CONVERT(varchar, @SecurityId) + '">'

-- Combine individual ticker rows as one string
SELECT @CompanyFinancialXml = STUFF(
                        (SELECT CHAR(13) + result
                           FROM #CompanyFinancialXml
                            FOR XML PATH(''),type).value('.','NVARCHAR(MAX)'),1,1,'')
SELECT @CompanyFinancialXml = @FinancialsHeaderRow + CHAR(13) + @CompanyFinancialXml + CHAR(13) + '</MarketData>'

SELECT CAST(@CompanyFinancialXml AS XML)


SET NOCOUNT OFF

GO

ALTER PROCEDURE [dbo].[spGetCompanyRatingXml]
  @InXml TEXT
AS

SET NOCOUNT ON

DECLARE @CompanyId            INT,
        @Company              VARCHAR(60),
        @PrimarySecurityId    INT,
        @Industry             VARCHAR(50),
        @RatingCount          INT,
        @PrimaryTicker        VARCHAR(15),
        @Analyst              VARCHAR(48),
        @hDoc                 INT,
        @Date                 DATETIME,
        @Type                 VARCHAR(31),
        @Title                VARCHAR(255),
        @RptPubNo             INT,
        @Version              INT,
        @SecurityId           INT,
        @Ticker               VARCHAR(15),
        @IsEstimatesScreen    VARCHAR(5),
        @CompanyHeaderRow     VARCHAR(4000),
        @FinancialsXml        XML,
        @PublicationsXml      XML,
        @CompanyFinancialXml  VARCHAR(MAX)

EXEC sp_xml_preparedocument @hDoc OUTPUT, @InXml

SELECT @Date = X.Date, @Type = X.Type, @Title = X.Title
FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
WITH (Date datetime '@pubDate', Type varchar(31) '@type', Title varchar(255) '@title' ) X

EXEC spCheckForResubmits @Date, @Type, @Title, @RptPubNo OUTPUT, @Version OUTPUT

SELECT
  ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo,
  S.SecurityId, X.Ticker, X.IndicateChange, S.Company, S.CompanyId,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'live', @RptPubNo) AS SourceLive,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'old', @RptPubNo)  AS SourceOld,
  ISNULL(X.LastPubNo, '') AS LastChangePubNo,
  CASE WHEN X.CoverageId IS NULL OR X.CoverageId = '' OR X.CoverageId = '0' THEN RC.CoverageId
       ELSE X.CoverageId
  END AS CoverageId,
  S.OrdNo, S.Alias
INTO #TickerList
FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
WITH (SecurityId int '@id', Ticker varchar(30) '@ticker', IndicateChange  varchar(30) '@indicateChange', LastPubNo int '@optLastPubNo', CoverageId INT '@coverageId') X
INNER JOIN Securities2 S ON S.Ticker = X.Ticker
INNER JOIN ResearchCoverage RC ON RC.SecurityId = S.SecurityId AND RC.DropDate IS NULL

-- Get the Company of the first ticker in the list
SELECT TOP 1 @SecurityId = SecurityId, @Ticker = Ticker, @CompanyId = CompanyId, @Company = Company FROM #TickerList

IF NOT EXISTS(SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
BEGIN
  SELECT '<NotExist>' + 'Missing Company for provided Ticker. Security Id:' + CONVERT(VARCHAR, @SecurityId) + '</NotExist>' AS XML
  RETURN
END

SELECT @IsEstimatesScreen = X.IsEstimatesScreen
FROM OPENXML (@hDoc, 'DocumentInfo/Securities', 1)
WITH (IsEstimatesScreen varchar(5) '@isEstimatesScreen') X

-- Remove Tickers from the list not for the first ticker company
DELETE FROM #TickerList WHERE CompanyId != @CompanyId

-- Remove Tickers from the list > first 2 tickers in the list for that company
DELETE FROM #TickerList WHERE DisplayNo NOT IN (SELECT TOP 2 DisplayNo FROM  #TickerList ORDER BY DisplayNo ASC)

-- Get Primary, Secondary Ticker, Industry for the Company
IF EXISTS(SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
  SELECT @PrimarySecurityId = SecurityId, @PrimaryTicker =  Ticker
  FROM Securities2 WHERE CompanyId = @CompanyId AND IsPrimary = 'Y'
ELSE
  SELECT @PrimarySecurityId = @SecurityId, @PrimaryTicker = ''

SELECT @Industry = I.IndustryName FROM ResearchCoverage RC JOIN Industries I ON I.IndustryId = RC.IndustryId WHERE RC.SecurityId = @PrimarySecurityId AND RC.DropDate IS NULL
SELECT @Analyst = A.First + ' ' + A.Last FROM ResearchCoverage RC JOIN Authors A ON A.AuthorId = RC.AnalystId AND RC.SecurityId = @PrimarySecurityId AND RC.DropDate IS NULL

-- Analyst data - Draft and Published value rowset
SELECT
  TL.Ticker,
  TL.SecurityId,
  FNT.FinancialNumberTypeId,
  FNT.FinancialNumberType,
  FN.CurCode,
  FN.FinancialPeriodId,
  CONVERT(VARCHAR,FN.Value)  AS LiveValue,
  CONVERT(VARCHAR,FN2.Value) AS DraftValue,
  (CASE WHEN FNT.FinancialNumberType = 'RATING' THEN ( SELECT RatingText FROM Ratings WHERE Rating = FN.Value)
        ELSE ''
   END) AS LiveValueText,
  (CASE WHEN FNT.FinancialNumberType = 'RATING' THEN ( SELECT RatingText FROM Ratings WHERE Rating = FN2.Value)
        ELSE ''
   END) AS DraftValueText,
  FN.BaseYear,
  FN.PeriodYear,
  FNT.ShortName AS Description,
  -- Get Alias only from text
  substring(TL.Alias,charindex('(', TL.Alias),len(TL.Alias)+ 1 - charindex('(', TL.Alias)) AS Alias,
  TL.OrdNo
INTO #TmpAnalystDataDraftLive
FROM #TickerList TL
INNER JOIN FinancialNumberTypes FNT ON FNT.FinancialNumberType IN ('RATING', 'TARGETPRICE')
-- Only data for active ticker coverage (not dropped/suspended) using active CoverageId
LEFT JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = TL.SecurityId
                                     AND FN.CoverageId = TL.CoverageId
                                     AND FN.FinancialNumberTypeId  = FNT.FinancialNumberTypeId
                                     AND FN.IsDraft = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                     AND FN2.CoverageId = TL.CoverageId
                                     AND FN2.FinancialNumberTypeId = FNT.FinancialNumberTypeId
                                     AND FN2.IsDraft = 1  -- Draft
WHERE TL.SecurityId IN (SELECT SecurityId FROM Securities2 WHERE CompanyId = @CompanyId)

-- Get Rating Count for this Company
SELECT @RatingCount = COUNT(Distinct(R.Value))
FROM (  SELECT
        TA.SecurityID              AS SecurityId,
        -- Rating value, take draft else live
        MAX(CASE WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN DraftValue
                 WHEN LiveValue  IS NOT NULL THEN LiveValue
                 ELSE ''
            END) AS Value
        FROM #TmpAnalystDataDraftLive TA
        INNER JOIN #TickerList TL ON TL.SecurityId = TA.SecurityId
        WHERE FinancialNumberType = 'RATING'
        GROUP BY TA.SecurityId
      ) R

-- Get Latest Financials data in a XML variable
SET @FinancialsXml =
(
SELECT * FROM
(
-- Returns Analyst data (1-2 Tickers) [RATING, TARGETPRICE]
SELECT
  1                      AS tag,
  null                   AS parent,
  @Company               AS [Company!1!company],
  @CompanyId             AS [Company!1!companyId],
  @Industry              AS [Company!1!industry],
  @RatingCount           AS [Company!1!ratingCount],
  CASE WHEN @IsEstimatesScreen = 'yes' THEN @Ticker
       ELSE @PrimaryTicker
  END                    AS [Company!1!ticker],
  @Analyst               AS [Company!1!analyst],
  @SecurityId            AS [Company!1!paramSecurityId],
  NULL                   AS [CompanyRow!2!ticker],
  NULL                   AS [CompanyRow!2!alias],
  NULL                   AS [CompanyRow!2!securityId],
  NULL                   AS [CompanyRow!2!financialNumberType],
  NULL                   AS [CompanyRow!2!value],
  NULL                   AS [CompanyRow!2!old],
  NULL                   AS [CompanyRow!2!textValue],
  NULL                   AS [CompanyRow!2!textOld],
  NULL                   AS [CompanyRow!2!isDraft],
  NULL                   AS [CompanyRow!2!isBold],
  NULL                   AS [CompanyRow!2!currency],
  NULL                   AS [CompanyRow!2!dispOrder]

UNION ALL

-- Both Tickers
-- IF @IndicateChange = 'yes' and Draft exists THEN display Draft, ELSE published
SELECT
  2                       AS tag,
  1                       AS parent,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  MAX(TA.Ticker)          AS [CompanyRow!2!ticker],
  MAX(TL.Alias)           AS [CompanyRow!2!alias],
  TA.SecurityID           AS [CompanyRow!2!securityId],
  TA.FinancialNumberType     AS [CompanyRow!2!financialNumberType],

  -- rating / target price value
  MAX(CASE WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN DraftValue
           WHEN LiveValue  IS NOT NULL THEN LiveValue
           ELSE ''
      END) AS [CompanyRow!2!value],
  MAX(CASE
    WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN LiveValue
  END)     AS [CompanyRow!2!old],

  -- Rating only text for display
  MAX(CASE WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN DraftValueText
           WHEN LiveValue  IS NOT NULL THEN LiveValueText
           ELSE ''
      END) AS [CompanyRow!2!textValue],
  MAX(CASE
    WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN LiveValueText
  END)     AS [CompanyRow!2!textOld],

  -- rating / target price value - draft[1] or live[0]
  MAX(CASE
    WHEN DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN 1
    WHEN LiveValue  IS NOT NULL                         THEN 0
  END)                      AS [CompanyRow!2!isDraft],
  MAX(CASE
    WHEN LiveValue  IS NOT NULL AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN 'Y'
    ELSE 'N'
  END)                      AS [CompanyRow!2!isBold],
  MAX(TA.CurCode)           AS [CompanyRow!2!currency],
  MAX(TL.OrdNo)             AS [CompanyRow!2!dispOrder]
FROM #TmpAnalystDataDraftLive TA
INNER JOIN #TickerList TL ON TL.SecurityId = TA.SecurityId
GROUP BY TA.SecurityId, TA.FinancialNumberType

) X
ORDER BY tag, [CompanyRow!2!dispOrder], [CompanyRow!2!financialNumberType]
FOR XML Explicit
)

-- For v1(IndicateChange=no,yes), use the latest FinancialNumbers data - applicable for ticker table UI screens or from word template
If @RptPubNo = 0 AND NOT EXISTS(SELECT * FROM #TickerList WHERE IndicateChange = 'last')
BEGIN
  SELECT @FinancialsXml
  RETURN
END

-- Get the PublicationsXml
SELECT @PublicationsXml = CompanyFinancialsXml FROM PublicationsXML  WHERE PubNo = @RptPubNo

-- Add column to store the Ticker Table XML for tickers with indicateChange="last" [lastChangePubNo]
ALTER TABLE #TickerList ADD LastChangeTickerTableXml XML

-- Update Ticker Table XML for tickers with indicateChange="last"
UPDATE #TickerList
SET #TickerList.LastChangeTickerTableXml = PX2.CompanyFinancialsXml
FROM PublicationsXML PX2
WHERE PX2.PubNo = #TickerList.LastChangePubNo

-- Selectively fetch applicable rows (by ticker) from one of the 3 xml sources
-- Source: FinancialsXml
SELECT
  CONVERT(varchar(MAX),F.c.query('.')) AS result,
  TL.DisplayNo AS dispOrder
INTO #CompanyFinancialXml
FROM #TickerList TL
JOIN @FinancialsXml.nodes('/Company/CompanyRow') F(c)
     ON TL.SecurityId = CAST(F.c.value('@securityId', 'INT') AS INT)
WHERE TL.SourceLive = 'FN'

UNION

-- Source: PublicationsXml for last Report
SELECT
  CONVERT(varchar(MAX),P.Loc.query('.')) AS result,
  TL.DisplayNo AS dispOrder
FROM #TickerList TL
JOIN @PublicationsXml.nodes('/CompanyFinancials/Company/CompanyRow') P(Loc)
     ON TL.SecurityId = CAST(P.Loc.value('@securityId', 'INT') AS INT)
WHERE TL.SourceLive = 'PX'

UNION

-- Source: @PublicationsXml for last Change Report
SELECT
  CONVERT(varchar(MAX),P2.Loc.query('.')) AS result,
  TL.DisplayNo AS dispOrder
FROM #TickerList TL
CROSS APPLY TL.LastChangeTickerTableXml.nodes('/CompanyFinancials/Company/CompanyRow') AS P2(Loc)
WHERE TL.SecurityId = CAST(P2.Loc.value('@securityId', 'INT') AS INT)
AND TL.SourceLive = 'PXLAST'

ORDER BY 2

SET @CompanyHeaderRow = '<Company company="' + [dbo].[fnCheckSpecialCharacters](@Company) + '"'
SET @CompanyHeaderRow = @CompanyHeaderRow + ' companyId="' + CONVERT(varchar, @CompanyId) + '"'
SET @CompanyHeaderRow = @CompanyHeaderRow + ' industry="' + [dbo].[fnCheckSpecialCharacters](@Industry) + '"'
SET @CompanyHeaderRow = @CompanyHeaderRow + ' ratingCount="' + CONVERT(varchar, @RatingCount) + '"'
IF @IsEstimatesScreen = 'yes'
  SET @CompanyHeaderRow = @CompanyHeaderRow + ' ticker="' + [dbo].[fnCheckSpecialCharacters](@Ticker) + '"'
ELSE
  SET @CompanyHeaderRow = @CompanyHeaderRow + ' ticker="' + [dbo].[fnCheckSpecialCharacters](@PrimaryTicker) + '"'

SET @CompanyHeaderRow = @CompanyHeaderRow + ' analyst="' + [dbo].[fnCheckSpecialCharacters](@Analyst) + '"'
SET @CompanyHeaderRow = @CompanyHeaderRow + ' paramSecurityId="' + CONVERT(varchar, @SecurityId) + '">'

-- Combine individual ticker rows as one string
SELECT @CompanyFinancialXml = STUFF(
                        (SELECT CHAR(13) + result
                           FROM #CompanyFinancialXml
                            FOR XML PATH(''),type).value('.','NVARCHAR(MAX)'),1,1,'')
SET @CompanyFinancialXml = @CompanyHeaderRow + CHAR(13) + @CompanyFinancialXml + CHAR(13) + '</Company>'

SELECT CAST(@CompanyFinancialXml AS XML)

SET NOCOUNT OFF




GO

ALTER PROCEDURE [dbo].[spGetCompanyEpsXml]
  @InXml TEXT
AS

SET NOCOUNT ON

DECLARE @CompanyId            INT,
        @Company              VARCHAR(60),
        @PrimarySecurityId    INT,
        @PrimaryIndexId       INT,
        @hDoc                 INT,
        @Date                 DATETIME,
        @Type                 VARCHAR(31),
        @Title                VARCHAR(255),
        @RptPubNo             INT,
        @Version              INT,
        @SecurityId           INT,
        @BaseYear             INT,
        @EpsHeaderRow         VARCHAR(4000),
        @FinancialsXml        XML,
        @PublicationsXml      XML,
        @CompanyFinancialXml  VARCHAR(MAX),
        @TickerBaseYearMajority INT,
        @IndexBaseYearFirst     INT

EXEC sp_xml_preparedocument @hDoc OUTPUT, @InXml

SELECT @Date = X.Date, @Type = X.Type, @Title = X.Title
FROM OPENXML (@hDoc, 'DocumentInfo/DocumentSection', 1)
WITH (Date datetime '@pubDate', Type varchar(31) '@type', Title varchar(255) '@title' ) X

EXEC spCheckForResubmits @Date, @Type, @Title, @RptPubNo OUTPUT, @Version OUTPUT

SELECT
  ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo,
  S.SecurityId, X.Ticker, X.IndicateChange, S.Company, S.CompanyId, S.TickerType,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'live', @RptPubNo) AS SourceLive,
  [dbo].[fnGetEstimateSource](X.SecurityId, X.IndicateChange, 'old', @RptPubNo)  AS SourceOld,
  ISNULL(X.LastPubNo, '') AS LastChangePubNo,
  FCS.BaseYear,
  CASE WHEN X.CoverageId IS NULL OR X.CoverageId = '' OR X.CoverageId = '0' THEN RC.CoverageId
       ELSE X.CoverageId
  END AS CoverageId
INTO #TickerList
FROM OPENXML (@hDoc, 'DocumentInfo/Securities/Security', 1)
WITH (SecurityId int '@id', Ticker varchar(30) '@ticker', IndicateChange  varchar(30) '@indicateChange', LastPubNo int '@optLastPubNo', CoverageId INT '@coverageId') X
INNER JOIN Securities2 S ON S.Ticker = X.Ticker AND S.TickerType = 'STOCK'
INNER JOIN FinancialCompanySettings FCS ON FCS.CompanyId = S.CompanyId
INNER JOIN ResearchCoverage RC ON RC.SecurityId = S.SecurityId AND RC.DropDate IS NULL

-- Get the Company of the first ticker in the list
SELECT TOP 1 @SecurityId = SecurityId, @CompanyId = CompanyId, @Company = Company FROM #TickerList

IF NOT EXISTS(SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
BEGIN
  --SELECT 'Missing Company for provided Security. Security Id:' + CONVERT(VARCHAR, @SecurityId)
  SELECT '<NotExist>' + 'Missing Company for provided Ticker. Security Id:' + CONVERT(VARCHAR, @SecurityId) + '</NotExist>' AS XML
  RETURN
END

-- Remove Tickers from the list not for the first ticker company
DELETE FROM #TickerList Where CompanyId != @CompanyId

-- Remove Tickers from the list > first 2 tickers in the list for that company
DELETE FROM #TickerList WHERE DisplayNo NOT IN (SELECT TOP 2 DisplayNo FROM  #TickerList ORDER BY DisplayNo ASC)


-- Get Primary Ticker and Index for the Company
IF EXISTS(SELECT * FROM Securities2 WHERE CompanyId = @CompanyId)
  SELECT @PrimarySecurityId = SecurityId FROM Securities2 WHERE CompanyId = @CompanyId AND IsPrimary = 'Y'
ELSE
  SELECT @PrimarySecurityId = @SecurityId

SELECT @PrimaryIndexId      = SecurityId                FROM Securities2 WHERE Ticker = ( SELECT BenchmarkIndex FROM Securities2  WHERE SecurityId = @PrimarySecurityId)

-- Get all Indexes for the Company Tickers - Fix performance issue
CREATE TABLE #IndexList(SecurityId INT, Ticker VARCHAR(15), TickerType VARCHAR(10), BaseYear CHAR(4))
INSERT INTO #IndexList
SELECT S.SecurityId, S.Ticker, S.TickerType, FCS.BaseYear
FROM Securities2 S
JOIN FinancialCompanySettings FCS ON S.CompanyId = FCS.CompanyId
WHERE Ticker IN (SELECT S.BenchmarkIndex FROM Securities2 S
                                  INNER JOIN ResearchCoverage RC ON RC.SecurityID = S.SecurityId AND RC.DropDate IS NULL
                                  WHERE S.SecurityId IN (SELECT SecurityId FROM #TickerList))

-- Indexes - Get BaseYear of first index
SELECT TOP 1 @IndexBaseYearFirst = BaseYear FROM #IndexList

-- Insert the applicable indexes for the tickers
INSERT INTO #TickerList
SELECT
  100 + ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS DisplayNo,
  SecurityId, Ticker, 'no', '', '', TickerType,
  [dbo].[fnGetEstimateSource](SecurityId, 'no', 'live', @RptPubNo) AS SourceLive,
  [dbo].[fnGetEstimateSource](SecurityId, 'no', 'old', @RptPubNo)  AS SourceOld,
   0  AS LastChangePubNo, BaseYear, 0 AS CoverageId
FROM #IndexList


-- Dataset that includes Draft and Published value
SELECT
  VFT.Ticker,
  VFT.TickerType,
  VFT.SecurityId,
  VFT.FinancialNumberTypeId,
  VFT.CurCode,
  VFT.FinancialPeriodId,
  CONVERT(VARCHAR,FN.Value)  AS LiveValue,
  CONVERT(VARCHAR,FN2.Value) AS DraftValue,
  VFT.BaseYear,
  VFT.OrdNo,
  ISNULL(VFT.Format,'') AS Format,
  VFT.FinancialNumberType        AS FinancialNumberType,
  VFT.ShortName                  AS ShortName,
  VFT.FinancialNumberTypeCatOrd,
  VFT.FinancialPeriod
INTO #TmpEPSEstimates
FROM #TickerList TL
INNER JOIN vEstimateSetsPeriods VFT ON  VFT.SecurityId = TL.SecurityId
                                    AND VFT.CoverageId = TL.CoverageId
-- Only data for active ticker coverage (not dropped/suspended) using active CoverageId
LEFT JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = TL.SecurityId
                                     AND FN.CoverageId = TL.CoverageId
                                     AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                     AND FN.FinancialPeriodId = VFT.FinancialPeriodId
                                     AND FN.IsDraft = 0  -- Live
LEFT JOIN vFinancialNumbersLatest FN2 ON FN2.SecurityId = TL.SecurityId
                                     AND FN2.CoverageId = TL.CoverageId
                                     AND FN2.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                     AND FN2.FinancialPeriodId = VFT.FinancialPeriodId
                                     AND FN2.IsDraft = 1  -- Draft
WHERE VFT.CompanyId = @CompanyId
AND VFT.FinancialPeriod IN ('FY0','FY1','FY2')
AND VFT.FinancialNumberTypeId = ( SELECT FCS.TickerTableEpsId
                                  FROM FinancialCompanySettings FCS
                                  INNER JOIN Securities2 S ON S.CompanyId = FCS.CompanyId
                                  WHERE S.SecurityId =  VFT.SecurityId)

-- Tickers - Get BaseYear count
SELECT BaseYear,Count(BaseYear) BaseYearTickerCount
INTO #TmpBaseYearOptions
FROM #TickerList
WHERE TickerType = 'STOCK'
GROUP BY BaseYear

-- Tickers - Get BaseYear majority
SELECT @TickerBaseYearMajority = MAX(BaseYear) FROM #TmpBaseYearOptions WHERE BaseYearTickerCount = (SELECT MAX(BaseYearTickerCount) FROM #TmpBaseYearOptions)

-- Get TimeSeriesMaxValue at NumberType level
SELECT VFT.SecurityId, VFT.FinancialNumberTypeId,
        CASE
          WHEN MAX(ISNUMERIC(FN.Value)) = 0 THEN ''
          ELSE MAX(ABS(FN.VALUE))
        END AS TimeSeriesMaxValue,
        MAX(VFT.UnitMultiplier) AS UnitMultiplier
INTO #TmpEstimatesMax
FROM vEstimateSetsPeriods VFT
INNER JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = VFT.SecurityId
                                      AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                      AND FN.FinancialPeriodId = VFT.FinancialPeriodId
WHERE VFT.CompanyId = @CompanyId
  AND VFT.FinancialPeriod IN ('FY0','FY1','FY2')
AND VFT.FinancialNumberTypeId = (SELECT FCS.TickerTableEpsId
                                   FROM FinancialCompanySettings FCS
                                  INNER JOIN Securities2 S ON S.CompanyId = FCS.CompanyId
                                  WHERE S.SecurityId =  VFT.SecurityId)
AND ISNUMERIC(FN.VALUE) = 1
GROUP BY VFT.SecurityId, VFT.FinancialNumberTypeId


-- Get DisplayUnits at NumberType level
SELECT
  SecurityId,
  FinancialNumberTypeId,
  TimeSeriesMaxValue,
  UnitMultiplier,
  dbo.fnCalculateDisplayUnits(TimeSeriesMaxValue, UnitMultiplier) AS DisplayUnits
INTO #TmpEstimatesStyles
FROM #TmpEstimatesMax

-- Get BaseYear
SELECT @BaseYear = BaseYear
FROM FinancialCompanySettings FCS
INNER JOIN Securities2 S ON S.CompanyId = FCS.CompanyId
WHERE S.SecurityId = @PrimarySecurityId


-- Get Latest Financials data in a XML variable
SET @FinancialsXml =
(
SELECT * FROM
(
SELECT
  1                      AS tag,
  null                   AS parent,
  @Company               AS [Eps!1!company],
  @CompanyId             AS [Eps!1!companyId],
  @BaseYear              AS [Eps!1!FY0],
  @BaseYear + 1          AS [Eps!1!FY1],
  @BaseYear + 2          AS [Eps!1!FY2],
  @SecurityId            AS [Eps!1!paramSecurityId],
  NULL                   AS [EpsRow!2!ticker],
  NULL                   AS [EpsRow!2!tickerType],
  NULL                   AS [EpsRow!2!currency],
  NULL                   AS [EpsRow!2!epsFY0],
  NULL                   AS [EpsRow!2!epsFY1],
  NULL                   AS [EpsRow!2!epsFY2],
  NULL                   AS [EpsRow!2!isDraftFY0],
  NULL                   AS [EpsRow!2!isDraftFY1],
  NULL                   AS [EpsRow!2!isDraftFY2],
  NULL                   AS [EpsRow!2!isBoldFY0],
  NULL                   AS [EpsRow!2!isBoldFY1],
  NULL                   AS [EpsRow!2!isBoldFY2],
  NULL                   AS [EpsRow!2!baseYear],
  NULL                   AS [EpsRow!2!units],
  NULL                   AS [EpsRow!2!format],
  NULL                   AS [EpsRow!2!financialNumberTypeId],
  NULL                   AS [EpsRow!2!financialNumberType],
  NULL                   AS [EpsRow!2!label],
  NULL                   AS [EpsRow!2!tickerOrder],
  NULL                   AS [EpsRow!2!tickerRowOrder],
  NULL                   AS [EpsRow!2!financialNumberTypeCatOrd],
  NULL                   AS [EpsRow!2!securityId]

UNION ALL

-- Tickers for the Company - Latest (draft or live)
SELECT
  2                      AS tag,
  1                      AS parent,
  NULL                   AS [Eps!1!company],
  NULL                   AS [Eps!1!companyId],
  NULL                   AS [Eps!1!FY0],
  NULL                   AS [Eps!1!FY1],
  NULL                   AS [Eps!1!FY2],
  NULL                   AS [Eps!1!paramSecurityId],
  EE.Ticker              AS [EpsRow!2!ticker],
  MAX(EE.TickerType)     AS [EpsRow!2!tickerType],
  MAX(CurCode)           AS [EpsRow!2!currency],
  -- eps value - draft or live
  MAX(dbo.fnConvertDisplayUnits(
  CASE WHEN FinancialPeriodId = 1 AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN DraftValue
           WHEN FinancialPeriodId = 1 AND LiveValue  IS NOT NULL THEN LiveValue
           ELSE ''
      END, ES.DisplayUnits)) AS [EpsRow!2!epsFY0],

  MAX(dbo.fnConvertDisplayUnits(
  CASE WHEN FinancialPeriodId = 2 AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN DraftValue
           WHEN FinancialPeriodId = 2 AND LiveValue  IS NOT NULL THEN LiveValue
           ELSE ''
      END, ES.DisplayUnits)) AS [EpsRow!2!epsFY1],

  MAX(dbo.fnConvertDisplayUnits(
  CASE WHEN FinancialPeriodId = 3 AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN DraftValue
           WHEN FinancialPeriodId = 3 AND LiveValue  IS NOT NULL THEN LiveValue
           ELSE ''
      END, ES.DisplayUnits)) AS [EpsRow!2!epsFY2],

  -- eps value flag - draft or live
  MAX(CASE WHEN FinancialPeriodId = 1 AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN 1
           WHEN FinancialPeriodId = 1 AND LiveValue  IS NOT NULL THEN 0
           ELSE ''
      END) AS [EpsRow!2!isDraftFY0],
  MAX(CASE WHEN FinancialPeriodId = 2 AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN 1
           WHEN FinancialPeriodId = 2 AND LiveValue  IS NOT NULL THEN 0
           ELSE ''
      END) AS [EpsRow!2!isDraftFY1],
  MAX(CASE WHEN FinancialPeriodId = 3 AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN 1
           WHEN FinancialPeriodId = 3 AND LiveValue  IS NOT NULL THEN 0
           ELSE ''
      END) AS [EpsRow!2!isDraftFY2],
  -- isBold attribute - when draft and live value exists
  MAX(CASE WHEN FinancialPeriodId = 1 AND LiveValue  IS NOT NULL AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [EpsRow!2!isBoldFY0],
  MAX(CASE WHEN FinancialPeriodId = 2 AND LiveValue  IS NOT NULL AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [EpsRow!2!isBoldFY1],
  MAX(CASE WHEN FinancialPeriodId = 3 AND LiveValue  IS NOT NULL AND DraftValue IS NOT NULL AND TL.IndicateChange = 'yes' THEN 'Y'
           ELSE 'N'
      END) AS [EpsRow!2!isBoldFY2],

  MAX(EE.BaseYear)                  AS [EpsRow!2!baseYear],
  MAX([dbo].[fnCalculateDisplayUnitsStyle](ES.DisplayUnits)) AS [EpsRow!2!units],
  MAX(EE.Format)                    AS [EpsRow!2!format],

  MAX(EE.FinancialNumberTypeId)     AS [EpsRow!2!financialNumberTypeId],
  MAX(FinancialNumberType)          AS [EpsRow!2!financialNumberType],
  MAX(ShortName)                    AS [EpsRow!2!label],

  MAX(OrdNo)                        AS [EpsRow!2!tickerOrder],
  1                                 AS [EpsRow!2!tickerRowOrder],
  MAX(FinancialNumberTypeCatOrd)    AS [EpsRow!2!financialNumberTypeCatOrd],
  ISNULL(EE.SecurityId, @SecurityId) AS [EpsRow!2!securityId]
FROM #TmpEPSEstimates EE
INNER JOIN #TmpEstimatesStyles ES ON ES.SecurityId = EE.SecurityId AND ES.FinancialNumberTypeId = EE.FinancialNumberTypeId
INNER JOIN #TickerList TL ON TL.SecurityId = EE.SecurityId
GROUP BY EE.Ticker, EE.SecurityId

UNION ALL

-- Tickers for the Company - OLD (live)
-- Show OLD row only if Promote Draft was selected and Ticker is already launched
SELECT
  2                      AS tag,
  1                      AS parent,
  NULL                   AS [Eps!1!company],
  NULL                   AS [Eps!1!companyId],
  NULL                   AS [Eps!1!FY0],
  NULL                   AS [Eps!1!FY1],
  NULL                   AS [Eps!1!FY2],
  NULL                   AS [Eps!1!paramSecurityId],
  'OLD'                  AS [EpsRow!2!ticker],
  MAX(EE.TickerType)     AS [EpsRow!2!tickerType],
  MAX(CurCode)           AS [EpsRow!2!currency],
  -- eps value - draft or live
  MAX(dbo.fnConvertDisplayUnits(
  CASE WHEN FinancialPeriodId = 1 AND DraftValue IS NOT NULL THEN LiveValue
           ELSE ''
      END, ES.DisplayUnits)) AS [EpsRow!2!epsFY0],

  MAX(dbo.fnConvertDisplayUnits(
  CASE WHEN FinancialPeriodId = 2 AND DraftValue IS NOT NULL THEN LiveValue
           ELSE ''
      END, ES.DisplayUnits)) AS [EpsRow!2!epsFY1],

  MAX(dbo.fnConvertDisplayUnits(
  CASE WHEN FinancialPeriodId = 3 AND DraftValue IS NOT NULL THEN LiveValue
           ELSE ''
      END, ES.DisplayUnits)) AS [EpsRow!2!epsFY2],

  -- eps value flag - draft or live
  MAX(CASE WHEN FinancialPeriodId = 1 AND DraftValue IS NOT NULL THEN 0
           ELSE ''
      END) AS [EpsRow!2!isDraftFY0],
  MAX(CASE WHEN FinancialPeriodId = 2 AND DraftValue IS NOT NULL THEN 0
           ELSE ''
      END) AS [EpsRow!2!isDraftFY1],
  MAX(CASE WHEN FinancialPeriodId = 3 AND DraftValue IS NOT NULL THEN 0
           ELSE ''
      END) AS [EpsRow!2!isDraftFY2],
  -- isBold attribute
  NULL                              AS [EpsRow!2!isBoldFY0],
  NULL                              AS [EpsRow!2!isBoldFY1],
  NULL                              AS [EpsRow!2!isBoldFY2],
  MAX(EE.BaseYear)                  AS [EpsRow!2!baseYear],
  MAX([dbo].[fnCalculateDisplayUnitsStyle](ES.DisplayUnits)) AS [EpsRow!2!units],
  MAX(EE.Format)                    AS [EpsRow!2!format],

  MAX(EE.FinancialNumberTypeId)     AS [EpsRow!2!financialNumberTypeId],
  MAX(FinancialNumberType)          AS [EpsRow!2!financialNumberType],
  MAX(ShortName)                    AS [EpsRow!2!label],

  MAX(OrdNo)                        AS [EpsRow!2!tickerOrder],
  2                                 AS [EpsRow!2!tickerRowOrder],
  MAX(FinancialNumberTypeCatOrd)    AS [EpsRow!2!financialNumberTypeCatOrd],
  ISNULL(EE.SecurityId, @SecurityId) AS [EpsRow!2!securityId]
FROM #TmpEPSEstimates EE
INNER JOIN #TmpEstimatesStyles ES ON ES.SecurityId = EE.SecurityId AND ES.FinancialNumberTypeId = EE.FinancialNumberTypeId
INNER JOIN #TickerList TL ON TL.SecurityId = EE.SecurityId
WHERE DraftValue IS NOT NULL
AND EE.SecurityId IN (SELECT SecurityId FROM ResearchCoverage WHERE LaunchDate IS NOT NULL)
AND EE.DraftValue <> EE.LiveValue  -- Show old only if draft is different from live value
AND TL.IndicateChange = 'yes'
GROUP BY EE.Ticker, EE.SecurityId

UNION ALL

-- Indexes
SELECT
  2                      AS tag,
  1                      AS parent,
  NULL                   AS [Eps!1!company],
  NULL                   AS [Eps!1!companyId],
  NULL                   AS [Eps!1!FY0],
  NULL                   AS [Eps!1!FY1],
  NULL                   AS [Eps!1!FY2],
  NULL                   AS [Eps!1!paramSecurityId],
  MAX(VFT.Ticker)        AS [EpsRow!2!ticker],
  MAX(VFT.TickerType)    AS [EpsRow!2!tickerType],
  NULL                   AS [EpsRow!2!currency],

  -- Conditionally align indexes FY with tickers FY
  -- If TickerBaseYearMajority > IndexBaseYearFirst then FY1, FY2, FY3 else FY0, FY1, FY2
  MAX(CASE WHEN @TickerBaseYearMajority > @IndexBaseYearFirst  AND FN.FinancialPeriodId = 2 THEN FN.Value
           WHEN @TickerBaseYearMajority <= @IndexBaseYearFirst AND FN.FinancialPeriodId = 1 THEN FN.Value
           ELSE '' END) AS [EpsRow!2!epsFY0],

  MAX(CASE WHEN @TickerBaseYearMajority > @IndexBaseYearFirst  AND FN.FinancialPeriodId = 3 THEN FN.Value
           WHEN @TickerBaseYearMajority <= @IndexBaseYearFirst AND FN.FinancialPeriodId = 2 THEN FN.Value
           ELSE '' END) AS [EpsRow!2!epsFY1],

  MAX(CASE WHEN @TickerBaseYearMajority > @IndexBaseYearFirst  AND FN.FinancialPeriodId = 4 THEN FN.Value
           WHEN @TickerBaseYearMajority <= @IndexBaseYearFirst AND FN.FinancialPeriodId = 3 THEN FN.Value
           ELSE '' END) AS [EpsRow!2!epsFY2],

  MAX(FN.IsDraft)        AS [EpsRow!2!isDraftFY0],
  MAX(FN.IsDraft)        AS [EpsRow!2!isDraftFY1],
  MAX(FN.IsDraft)        AS [EpsRow!2!isDraftFY2],
  -- isBold attribute
  NULL                   AS [EpsRow!2!isBoldFY0],
  NULL                   AS [EpsRow!2!isBoldFY1],
  NULL                   AS [EpsRow!2!isBoldFY2],
  MAX(FN.BaseYear)       AS [EpsRow!2!baseYear],
  'D'                    AS [EpsRow!2!units],
  MAX(ISNULL(VFT.Format,''))   AS [EpsRow!2!format],

  MAX(VFT.FinancialNumberTypeId)    AS [EpsRow!2!financialNumberTypeId],
  MAX(VFT.FinancialNumberType)      AS [EpsRow!2!financialNumberType],
  MAX(VFT.ShortName)                AS [EpsRow!2!label],

  CASE WHEN FN.SecurityId = @PrimaryIndexId THEN 101 ELSE 102 END       AS [EpsRow!2!tickerOrder],
  1                                                                     AS [EpsRow!2!tickerRowOrder],
  MAX(FinancialNumberTypeCatOrd)    AS [EpsRow!2!financialNumberTypeCatOrd],
  ISNULL(FN.SecurityId, 0)          AS [EpsRow!2!securityId]
FROM vEstimateSetsPeriods VFT
LEFT JOIN vFinancialNumbersLatest FN  ON FN.SecurityId = VFT.SecurityId
                                     AND FN.FinancialNumberTypeId  = VFT.FinancialNumberTypeId
                                     AND FN.FinancialPeriodId = VFT.FinancialPeriodId
                                     AND FN.IsDraft                = 0  -- Live
WHERE
VFT.FinancialNumberTypeId = ( SELECT FCS.TickerTableEpsId
                                  FROM FinancialCompanySettings FCS
                                  INNER JOIN Securities2 S ON S.CompanyId = FCS.CompanyId
                                  WHERE S.SecurityId =  VFT.SecurityId)
AND VFT.FinancialPeriodId IN (SELECT FinancialPeriodId FROM FinancialPeriods WHERE FinancialPeriod IN ('FY0','FY1','FY2','FY3'))
AND VFT.SecurityId    IN (SELECT SecurityId FROM #IndexList)

GROUP BY FN.SecurityId

) X
ORDER BY tag, [EpsRow!2!tickerOrder], [EpsRow!2!tickerRowOrder],  [EpsRow!2!securityId], [EpsRow!2!financialNumberTypeCatOrd]
FOR XML Explicit
)

-- For v1(IndicateChange=no,yes), use the latest FinancialNumbers data - applicable for ticker table UI screens or from word template
IF @RptPubNo = 0 AND NOT EXISTS(SELECT * FROM #TickerList WHERE IndicateChange = 'last')
BEGIN
  SELECT @FinancialsXml
  RETURN
END

-- Get the PublicationsXml
SELECT @PublicationsXml = CompanyFinancialsXml FROM PublicationsXML  WHERE PubNo = @RptPubNo

-- Add column to store the Ticker Table XML for tickers with indicateChange="last" [lastChangePubNo]
ALTER TABLE #TickerList ADD LastChangeTickerTableXml XML

-- Update Ticker Table XML for tickers with indicateChange="last"
UPDATE #TickerList
SET #TickerList.LastChangeTickerTableXml = PX2.CompanyFinancialsXml
FROM PublicationsXML PX2
WHERE PX2.PubNo = #TickerList.LastChangePubNo

-- Selectively fetch applicable rows (by ticker, old/new row) from one of the 3 xml sources
-- Source: FinancialsXml
SELECT
  CONVERT(varchar(MAX),F.Loc.query('.'))  AS result,
  TL.DisplayNo AS tickerOrder,
  F.Loc.value('./@tickerRowOrder', 'INT') AS tickerRowOrder,
  F.Loc.value('./@securityId',     'INT') AS securityId
INTO #CompanyFinancialXml
FROM #TickerList TL
JOIN @FinancialsXml.nodes('/Eps/EpsRow') F(Loc)
     ON TL.SecurityId = CAST(F.Loc.value('@securityId', 'INT') AS INT)
WHERE (TL.SourceLive = 'FN' AND CAST(F.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) != 'OLD')
       OR
      (TL.SourceOld = 'FN'  AND
       CAST(F.Loc.value('@securityId', 'INT') AS INT) = TL.SecurityId AND
       CAST(F.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) = 'OLD')

UNION

-- Source: PublicationsXml
SELECT
  CONVERT(varchar(MAX),P.Loc.query('.'))       AS result,
  TL.DisplayNo AS tickerOrder,
  P.Loc.value('./@tickerRowOrder',  'INT')     AS tickerRowOrder,
  P.Loc.value('./@securityId',      'INT')     AS securityId
FROM #TickerList TL
JOIN @PublicationsXml.nodes('/CompanyFinancials/Eps/EpsRow') P(Loc)
     ON TL.SecurityId = CAST(P.Loc.value('@securityId', 'INT') AS INT)
WHERE (TL.SourceLive = 'PX' AND CAST(P.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) != 'OLD')
       OR
      (TL.SourceOld = 'PX' AND
       CAST(P.Loc.value('@securityId', 'INT') AS INT) = TL.SecurityId AND
       CAST(P.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) = 'OLD')

UNION

-- Source: @PublicationsXml for lastChange PubNo
SELECT
  CONVERT(varchar(MAX),P2.Loc.query('.')) AS result,
  TL.DisplayNo AS tickerOrder,
  P2.Loc.value('./@tickerRowOrder',  'INT') AS tickerRowOrder,
  P2.Loc.value('./@securityId',      'INT') AS securityId
FROM #TickerList TL
CROSS APPLY TL.LastChangeTickerTableXml.nodes('/CompanyFinancials/Eps/EpsRow') AS P2(Loc)
WHERE TL.SecurityId = CAST(P2.Loc.value('@securityId', 'INT') AS INT)
AND (TL.SourceLive = 'PXLAST' AND CAST(P2.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) != 'OLD')
     OR
   (TL.SourceOld = 'PXLAST'  AND
    CAST(P2.Loc.value('@securityId', 'INT') AS INT) = TL.SecurityId AND
    CAST(P2.Loc.value('@ticker', 'VARCHAR(MAX)') AS VARCHAR(MAX)) = 'OLD')

ORDER BY 2, 4, 3

SET @EpsHeaderRow = '<Eps company="' + [dbo].[fnCheckSpecialCharacters](@Company) + '"'
SET @EpsHeaderRow = @EpsHeaderRow + ' companyId="' + CONVERT(varchar, @CompanyId) + '"'
SET @EpsHeaderRow = @EpsHeaderRow + ' FY0="' + CONVERT(varchar, @BaseYear) + '"'
SET @EpsHeaderRow = @EpsHeaderRow + ' FY1="' + CONVERT(varchar, @BaseYear + 1) + '"'
SET @EpsHeaderRow = @EpsHeaderRow + ' FY2="' + CONVERT(varchar, @BaseYear + 2) + '"'
SET @EpsHeaderRow = @EpsHeaderRow + ' paramSecurityId="' + CONVERT(varchar, @SecurityId) + '">'

-- Combine individual ticker rows as one string
SELECT @CompanyFinancialXml = STUFF(
                        (SELECT CHAR(13) + result
                           FROM #CompanyFinancialXml
                            FOR XML PATH(''),type).value('.','NVARCHAR(MAX)'),1,1,'')
SELECT @CompanyFinancialXml = @EpsHeaderRow + CHAR(13) + @CompanyFinancialXml + CHAR(13) + '</Eps>'
SELECT CAST(@CompanyFinancialXml AS XML)

DROP TABLE #IndexList

SET NOCOUNT OFF

GO

ALTER PROCEDURE [dbo].[spGetCompanySecurities]
  @Style int,
  @CompanyId int = NULL,
  @AnalystId int = NULL,
  @Ticker varchar(15) = NULL,
  @UserId int = NULL
AS

/*
Styles
1 - All securities - By specified company (Security Administration)
2 - Launched and unlaunched securities - By all companies or specified company (Estimate Set Administration)
3 -
4 - Launched and unlaunched securities - By all analysts (not practical) or specified analyst
5 - Launched and unlaunched securities - By Ticker (based on parent Company)
6 - Launched and unlaunched (visibility restrictions) securities - By all analysts (not practical) or specified analyst
*/

SET NOCOUNT ON

-- All securities - By specified company
IF @Style = 1
BEGIN

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo
FROM Securities2 S
JOIN Companies C ON C.CompanyId = S.CompanyId
WHERE S.CompanyId = @CompanyId
ORDER BY S.IsPrimary DESC, S.OrdNo

END

-- Launched and unlaunched securities - By all companies or specified company
ELSE IF @Style = 2
BEGIN

DECLARE @Companies TABLE (CompanyId int)
IF ISNULL(@CompanyId, '') = ''
BEGIN
  INSERT @Companies
    SELECT C.CompanyId
    FROM ResearchCoverage RC
    JOIN Securities2 S on S.SecurityId = RC.SecurityId
    JOIN Companies C on C.CompanyId = S.CompanyId
    WHERE RC.DropDate IS NULL
END
ELSE
  INSERT @Companies SELECT @CompanyId

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.AnalystId, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN Companies C ON C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL
AND S.CompanyId IN (SELECT CompanyId FROM @Companies)
ORDER BY C.Company, S.IsPrimary DESC, S.OrdNo

END

-- Launched and unlaunched securities - By all analysts (not practical) or specified analyst
ELSE IF @Style = 4
BEGIN

DECLARE @Analysts TABLE (AnalystId int)
IF ISNULL(@AnalystId, '') = ''
  INSERT @Analysts SELECT AuthorId FROM Authors WHERE IsAnalyst = -1 AND IsActive = -1
ELSE
  INSERT @Analysts SELECT @AnalystId

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
JOIN Companies C on C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)
ORDER BY C.Company, S.OrdNo

END

-- Launched and unlaunched securities - By Ticker (based on parent Company)
ELSE IF @Style = 5
BEGIN

SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.AnalystId, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S ON S.SecurityId = RC.SecurityId
JOIN Companies C ON C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL
AND S.CompanyId IN (SELECT CompanyId FROM Securities2 WHERE Ticker = @Ticker)
ORDER BY C.Company, S.IsPrimary DESC, S.OrdNo

END

-- Launched and unlaunched (visibility restrictions) securities - By all analysts (not practical) or specified analyst
ELSE IF @Style = 6
BEGIN

IF ISNULL(@AnalystId, '') = ''
  INSERT @Analysts SELECT AuthorId FROM Authors WHERE IsAnalyst = -1 AND IsActive = -1
ELSE
  INSERT @Analysts SELECT @AnalystId

DECLARE @ShowUnlaunched CHAR(1)

-- Admin or Manager role
IF EXISTS(SELECT * FROM UserRoles WHERE RoleId IN (1, 2) AND UserId = @UserId)
  SET @ShowUnlaunched = 'Y'

-- Launched tickers (visible to all)
SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
JOIN Companies C on C.CompanyId = S.CompanyId
WHERE RC.LaunchDate IS NOT NULL AND RC.DropDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)

UNION

-- Unlaunched tickers (visible to Team Members, Admins, Managers)
SELECT C.CompanyId, C.Company, S.SecurityId, S.Ticker, S.IsPrimary, S.OrdNo, RC.CoverageId
FROM ResearchCoverage RC
JOIN Securities2 S on S.SecurityId = RC.SecurityId
JOIN Companies C on C.CompanyId = S.CompanyId
WHERE RC.DropDate IS NULL AND RC.LaunchDate IS NULL
AND RC.AnalystId IN (SELECT AnalystId FROM @Analysts)
AND (
      RC.AnalystId = @UserId
      OR
      RC.AnalystId IN (SELECT AnalystId FROM AnalystTeamMembers WHERE UserId = @UserId)
      OR
      @ShowUnlaunched = 'Y' -- Authorized roles only
     )

ORDER BY C.Company, S.OrdNo

END

SET NOCOUNT OFF

GO


-- DEBUG

/*
SELECT * FROM Securities2 WHERE Ticker IN ('CROMPTON.I', 'CROMPTON.IN')

UPDATE Securities2 SET Ticker = 'CROMPTON.I'  WHERE SecurityId = 1821   -- 11 characters
UPDATE Securities2 SET Ticker = 'CROMPTON.IN' WHERE SecurityId = 1821   -- 12 characters

sp_help Securities2
sp_help TickerTableSecurities
sp_help TickerTableSecuritiesOld

sp_helptext spSearchCoverage
sp_helptext spSearchSecurities
sp_helptext spSaveTickerTable
-- Estimates screen proc - fixed to use Ticker varchar(12) in PRD
sp_helptext spGetEstimatesSetEps
sp_helptext spGetEstimatesSetFinancials
sp_helptext spGetEstimatesSetValuations

-- alter proc to use Ticker Varchar(15)
http://institutional-dev.beehive.com/admin/securities.asp?sortcol=1&sortdir=d&pg=1&sz=5000
sp_helptext spSearchSecurities  -- uses Ticker varchar(10)

http://institutional-dev.beehive.com/admin/coverage.asp?sortcol=1&sortdir=d&pg=1&sz=5000
sp_helptext spSearchCoverage  -- uses Ticker varchar(10)


-- Identify database objects that use  [varchar(10)] with [Securities2], [Ticker]
SELECT * FROM sys.syscomments
WHERE id in ( SELECT object_id FROM sys.objects)
and text like '%Securities2%' and text like '%Ticker%' and text like '%varchar(10)%'

SELECT * FROM sys.objects where object_id in (SELECT referencing_id FROM sys.sql_expression_dependencies WHERE referenced_id = OBJECT_ID(N'Securities2')) ORDER BY 1


-- Notes:
?? Table 'Securities' has column RIC varchar(10)
?? Table TickerTableSecurities and TickerTableSecuritiesOld have Ticker varchar(10)
?? alter procs to use Securities2.RIC varchar(15)
?? alter procs to use TickerTableSecurities.RIC varchar(12) & TickerTableSecuritiesOld.RIC varchar(12)



*/