-- CoverageRollback.sql

-- 09/06/2012 
-- CoverageId for Thomas Siedl's three tickers(AZSEY,ZURVY,SSREY) ARE 1360,1361,1362 
delete from AnalystSettings where CoverageId in (1360,1361,1362)
go
delete  from ResearchCoverage where CoverageId in (1360,1361,1362)
go
delete from Securities2 where Ticker in ('AZSEY','ZURVY','SSREY') 
go

DELETE FROM BloombergPivotPricing WHERE Ticker IN ('AZSEY','ZURVY','SSREY') 
GO

/*

--DEBUG

SELECT * FROM BloombergPivotPricing WHERE Ticker IN ('AZSEY','ZURVY','SSREY') 

*/