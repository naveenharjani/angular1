-- Security.sql

select 'Research User' = CONVERT(char(20), name) from Research..sysusers     where islogin = 1 order by name

ALTER LOGIN [SCBIS_Guest] WITH PASSWORD = 'password';  -- PROD 09/15/2006

SELECT USER AS 'Logged On User'

/*

Perform logged on as?
--Logged on User		Message
--ac\nharja				Cannot alter the login 'SCBIS_Guest', because it does not exist or you do not have permission.
--SCBIS_Guest			Cannot alter the login 'SCBIS_Guest', because it does not exist or you do not have permission.

Need to know/provide old password? Yes, w/o CONTROL SERVER permission
								   No,  w/  CONTROL SERVER permission

Permissions Required:
- Requires ALTER ANY LOGIN permission
- If the login that is being changed is a member of the sysadmin fixed server role or a grantee of CONTROL SERVER permission, 
  also requires CONTROL SERVER permission when making the 'Resetting the password without supplying the old password.' change.
- If you add the user to the SysAdmin role, then it will be successful.

Usage: ALTER LOGIN @login WITH PASSWORD = @new_password OLD_PASSWORD = @old_password

--Change Password for a SQL Server Login
CREATE PROCEDURE [dbo].[spChangePassword]
	@Login			varchar(12),
	@OldPassword	varchar(12),
	@NewPassword	varchar(12)
AS 
ALTER LOGIN @Login WITH 
	  PASSWORD = @NewPassword
	  OLD_PASSWORD = @OldPassword;
	  
RETURN @@ERROR
GO

*/