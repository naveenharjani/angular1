-- AnalystTeamMembers.sql

use Research
go

-- Initial Load
-- - Active coverage analysts
-- - Latest Call
-- - All authors excluding analysts

--insert into AnalystTeamMembers(AnalystId, UserId, EditorId, EditDate)
select Analyst.AuthorId, U.UserId, 1126, getdate()
from Properties p
join ( -- Active analysts + most recent Call
select PropValue, max(Pr.PubNo) PubNo from Properties Pr join Publications P On Pr.PubNo = P.PubNo
where P.Type = 'Research Call' and PropId = 5
and PropValue in (select distinct a.Name from ResearchCoverage rc join Authors a on rc.AnalystId = a.AuthorId where launchdate is not null and dropdate is null)
group by propvalue) t on t.pubno = p.pubno
join Authors Assoc on p.propvalue = assoc.Name and Assoc.isanalyst = 0 and Assoc.isactive = -1
join Authors Analyst on t.propvalue = Analyst.name
left outer join Users U on Assoc.WindowsUserName = U.UserName
order by t.propvalue, Assoc.Name
go
