-- BloombergSecurities.sql
-- 11/19/2015

/*
-- DELETE FROM BloombergSecurities

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'AUDUSD', 'FXSEC', 'AUD to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'BRLUSD', 'FXSEC', 'BRL to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'CADUSD', 'FXSEC', 'CAD to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'CHFEUR', 'FXSEC', 'CHF to EUR', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'CHFUSD', 'FXSEC', 'CHF to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'CNYHKD', 'FXSEC', 'CNY to HKD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'CNYUSD', 'FXSEC', 'CNY to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'DKKUSD', 'FXSEC', 'DKK to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'EURCHF', 'FXSEC', 'EUR to CHF', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'EURGBp', 'FXSEC', 'EUR to GBp', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'EURHKD', 'FXSEC', 'EUR to HKD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'EURUSD', 'FXSEC', 'EUR to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'GBPHKD', 'FXSEC', 'GBP to HKD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'GBPUSD', 'FXSEC', 'GBP to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'GBPZAr', 'FXSEC', 'GBP to ZAr', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'IDRUSD', 'FXSEC', 'IDR to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'INRUSD', 'FXSEC', 'INR to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'JPYUSD', 'FXSEC', 'JPY to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'KRWUSD', 'FXSEC', 'KRW to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'NOKUSD', 'FXSEC', 'NOK to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'RUBUSD', 'FXSEC', 'RUB to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'SEKUSD', 'FXSEC', 'SEK to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'SGDUSD', 'FXSEC', 'SGD to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'THBUSD', 'FXSEC', 'THB to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'TWDUSD', 'FXSEC', 'TWD to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDAUD', 'FXSEC', 'USD to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDCAD', 'FXSEC', 'USD to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDCHF', 'FXSEC', 'USD to CHF', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDEUR', 'FXSEC', 'USD to EUR', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDGBP', 'FXSEC', 'USD to GBP', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDHKD', 'FXSEC', 'USD to HKD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDNOK', 'FXSEC', 'USD to NOK', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDRUB', 'FXSEC', 'USD to RUB', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDZAr', 'FXSEC', 'USD to ZAr', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'HKDCNY', 'FXSEC', 'HKD to CNY', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'HKDUSD', 'FXSEC', 'HKD to USD', 'Y', 1229, getdate()

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDCNY', 'FXSEC', 'USD to CNY', 'Y', 1229, getdate()


update BloombergSecurities 
set Identifier = 'USDGBP', Description = 'USD to GBP'
where Identifier = 'USDGBp'

update BloombergSecurities 
set Identifier = 'EURGBP', Description = 'EUR to GBP'
where Identifier = 'EURGBp'

update BloombergSecurities 
set Identifier = 'GBPZAR', Description = 'GBP to ZAR'
where Identifier = 'GBPZAr'

update BloombergSecurities 
set Identifier = 'USDZAR', Description = 'USD to ZAR'
where Identifier = 'USDZAr'

INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDTHB', 'FXSEC', 'USD to THB', 'Y', 1229, getdate()

-- Added 4/6/2016
-- THBEV.SP (Thai Beverage Public Company Limited) trades in SGD & reports in THD (part of unlaunched coverage by Euan McLeish)
INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'THBSGD', 'FXSEC', 'THB to SGD', 'Y', 1229, getdate()

-- Added 4/20/2016 - Paul Gates - European Metals and Mining
INSERT INTO BloombergSecurities(Identifier, SecurityTypeCode, Description, Active, EditorId, EditDate)
SELECT 'USDBRL', 'FXSEC', 'USD to BRL', 'Y', 1229, getdate()

 SELECT * FROM BloombergSecurities 
 --  WHERE Identifier = 'USDBRL'
   ORDER BY EditDate ASC

*/

-- 05/30/2017
-- Delete FXSEC rows from BloombergSecurities
DELETE FROM BloombergSecurities


