INSERT INTO Publications (PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorID, EditDate)  
SELECT PubNo, Date, Type, Title, FileName, Approver, ApprovedDate, PublishedDate, Version, Instructions, EditorID, EditDate FROM PublicationsLog WHERE PubNo = 87129  
  
INSERT INTO Documents (PubNo, DocNo, DocType, FileName, FileNameOrig)  
SELECT PubNo, DocNo, DocType, FileName, FileNameOrig FROM DocumentsLog WHERE PubNo = 87129  
  
INSERT INTO Properties (PubNo, PropID, PropValue)  
SELECT PubNo, PropID, PropValue FROM PropertiesLog WHERE PubNo = 87129  

INSERT INTO ProductGroupDocuments (ProductGroupId, PubNo)
SELECT 1,87129
INSERT INTO ProductGroupDocuments (ProductGroupId, PubNo)
SELECT 2,87129
INSERT INTO ProductGroupDocuments (ProductGroupId, PubNo)
SELECT 6,87129

UPDATE Publications SET FileSize = 3286393 WHERE PubNo = 87129

/*
Deleted files are moved into pubs\deleted folder and prefaced with "d" (d00179212.DOCX & d00179213.PDF)
Restore Pubs
copy \\researchfs\research\pubs\deleted\d00179212.DOCX \\researchfs\research\pubs\d00179212.DOCX 
copy \\researchfs\research\pubs\deleted\d00179212.PDF \\researchfs\research\pubs\d00179212.PDF 

Deleted files are moved into links\deleted folder and prefaced with "d" (d87129.pdf)
Restore Links
copy \\researchfs\research\links\deleted\d87129.PDF \\researchfs\research\links\87129.PDF
*/


select * from Publications where PubNo = 87129
select * from Documents where PubNo = 87129
select * from PublicationsLog where PubNo = 87129
select * from DocumentsLog where PubNo = 87129
select * from PropertiesLog where PubNo = 87129



