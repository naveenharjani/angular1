-- Exchanges.sql

select * from Exchanges order by ExchangeCode

select * from Currencies

select * from Securities2 where TickerType = 'INDEX'

select * from Countries

select * from Regions

select * from DistributionRegions

/*

-- 10/02/2009 
insert into Exchanges (ExchangeCode, Exchange, CurrencyCode, BenchmarkIndex, CountryCode, RegionId, EditorId, EditDate, ScheduleID)
values ('BZ', 'Brazil (Sao Paulo)', 'BRL', 'SPX', 'BR', 6, 1, getdate(), 1)

-- 06/14/2011
insert into Exchanges (ExchangeCode, Exchange, CurrencyCode, BenchmarkIndex, CountryCode, RegionId, EditorId, EditDate, ScheduleID)
values ('SP', 'Singapore', 'SGD', 'MXAPJ', 'SG', 4, 1229, getdate(), 2)

-- 09/28/2011
insert into Exchanges (ExchangeCode, Exchange, CurrencyCode, BenchmarkIndex, CountryCode, RegionId, EditorId, EditDate, ScheduleID)
values ('IJ', 'Indonesia', 'IDR', 'MXAPJ', 'ID', 4, 1, getdate(), 2)

-- 09/28/2011
insert into Exchanges (ExchangeCode, Exchange, CurrencyCode, BenchmarkIndex, CountryCode, RegionId, EditorId, EditDate, ScheduleID)
insert into Exchanges (ExchangeCode, Exchange, CurrencyCode, BenchmarkIndex, CountryCode, Regionid, EditorId, EditDate, ScheduleId)
values ('MK', 'Malaysia', 'MYR', 'MXAPJ', 'MY', 4, 1, getdate(), 2)

-- 06/14/2011 Typo corrections
update Exchanges set Exchange = 'Thailand (Bangkok)' where ExchangeCode = 'TB'
update Exchanges set Exchange = 'Ireland (Dublin)'   where ExchangeCode = 'ID'
update Exchanges set Exchange = 'Japan (Tokyo)'      where ExchangeCode = 'JP'
update Exchanges set BenchmarkIndex = 'MSDLE15' where ExchangeCode = 'ID'

-- 04/20/2012
insert into Exchanges (ExchangeCode, Exchange, CurrencyCode, BenchmarkIndex, CountryCode, RegionId, EditorId, EditDate, ScheduleID)
select 'ZA', 'South Africa (Johannesburg)', 'ZAR', 'MSDLE15', 'ZA', 3, 1126, getdate(), 2

-- 07/06/2012
insert into Exchanges (ExchangeCode, Exchange, CurrencyCode, BenchmarkIndex, CountryCode, RegionId, EditorId, EditDate, ScheduleID)
select 'RM', 'Russian Federation (Moscow)','RUB', 'MSDLE15', 'RU', 2, 1, getdate(), 2

--05/19/2017
update Exchanges
set ExchangeCode = 'SJ',CurrencyCode = 'ZAr'
where
ExchangeCode = 'ZA' 
*/
