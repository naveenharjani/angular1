-- JobSchedulerPDU.sql
-- 03/13/2013
-- 04/05/2014
-- 05/14/2014
-- 07/17/2014
-- 07/20/2015
-- 11/04/2015

SELECT * FROM Jobs          -- Requires PDU to initialize and bind job to .NET adapter
SELECT * FROM Schedules     -- Administer via UI
SELECT * FROM JobSchedules  -- Job queue - scheduled
SELECT * FROM JobActivity   -- Job queue - completed
GO

/*

PRD

-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - FX Prices',      1,      'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '8',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('XML Refresh - Disclosures',    1,      'Bernstein.IRS.RefreshXML', 'WriteXML',      'RefreshDisclosuresXML',   NULL, 1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('XML Refresh - SLX Blast Lists', 1,     'Bernstein.IRS.RefreshXML', 'WriteXML',      'RefreshBlastListsXML',    NULL, 1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('XML Refresh - RPTools',    1,      'Bernstein.IRS.RefreshXML', 'WriteXML',      'RefreshRptoolsXML',   NULL, 1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Library - Algo Links',    1,      'Bernstein.IRS.Library', 'Algo',      'GenerateEncryptedLinks',   NULL, 1229, getdate() )

-- Bloomberg jobs - Parameter = [BloombergRequests.RequestId]
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Pricing - US',   1,      'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '3',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Pricing - UK', 1,        'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '1',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Pricing - EUR',  1,      'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '2',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Pricing - Asia',  1,     'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '7',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Pricing - GR/MSDLE15', 1, 'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '10', 1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Close Price History', 1, 'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '4',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Split History',   1,     'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '5',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Ticker Status',  1,      'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '6',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('End of Day Pricing - India',  1,     'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '11',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Pricing - Canada',   1,      'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '12',  1229, getdate() )

*/

/*

DEV/QA

-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - FX Prices',      1,      'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '8',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('XML Refresh - Disclosures',    1,      'Bernstein.IRS.RefreshXML', 'WriteXML',      'RefreshDisclosuresXML',   NULL, 1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('XML Refresh - SLX Blast Lists', 1,     'Bernstein.IRS.RefreshXML', 'WriteXML',      'RefreshBlastListsXML',    NULL, 1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('XML Refresh - RPTools',    1,      'Bernstein.IRS.RefreshXML', 'WriteXML',      'RefreshRptoolsXML',   NULL, 1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Library - Algo Links',    1,      'Bernstein.IRS.Library', 'Algo',      'GenerateEncryptedLinks',   NULL, 1229, getdate() )

-- EOD - Pricing [US] is enabled in DEV/QA
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Pricing - US',   1,      'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '3',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Close Price History', 1, 'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '4',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Split History',   1,     'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '5',  1229, getdate() )
-- INSERT INTO Jobs (Description, Enabled, Assembly, Class, Method, Parameter, EditorId, EditDate) VALUES('Market Data - Ticker Status',  1,      'Bernstein.IRS.MarketData', 'BloombergJobs', 'ProcessMarketdata', '6',  1229, getdate() )

-- Add schedules via jobschedules.asp UI
-- Set EOD Not-US Bloomberg jobs to inactive via UI, as no data is downloaded in DEV for not-US EOD feeds
*/

-- exec spGetJobQueue

-- SELECT * FROM BloombergRequests