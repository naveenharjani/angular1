/*
Hi Krishna,

Apologies for the back and forth but we need to revert back to how things were previously. I made a mistake and the last reported year was originally correct and should be FY19 Actual. And the numbers that are currently showing as F21 in the beehive ($0.43) should actually show as F20E and the previous F20E EPS should be $0.34 which was in the database previously. Sorry for the confusion and thanks for all your help.

Best,

Elijah Crago, CFA
Research Associate
U.S. Restaurants | U.S. Softlines & Specialty Retail
T: +1 212 756 4117  |  M: +1 518 209 8538
Elijah.crago@bernstein.com
*/
--05/17/2020

delete from FinancialNumbers
where 
SecurityId = 1975 and
BaseYear = 2020

update FinancialCompanySettings
set BaseYear = 2019
where 
CompanyId = (select companyid from securities2 where SecurityId  = 1975)

