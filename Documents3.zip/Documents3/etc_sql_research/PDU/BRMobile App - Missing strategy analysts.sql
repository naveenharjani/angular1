--04/23/2018
--Strategy analysts Alla Harmsworth, Noah Weisberger, Mccarthy, Diver etc., 
--are missing from SCBMobile Watchlist available list
--Reason: Status = 0 for these analysts on the Author table row. Auto launch (LaunchDate & Status) is not happening for strategy launches
--Resolution: Update Status = 1 and EditDate = getdate() for these active strategy analysts

select A.* from Authors A join ResearchCoverage RC on A.AuthorId = RC.AnalystId
where 
RC.LaunchDate is not null and RC.DropDate is null and
isAnalyst = -1 and (Status is null or status = 0)



Update Authors
set Status = 1,EditDate = getdate()
from ResearchCoverage RC join Authors A on RC.AnalystId = A.AuthorId
where
RC.LaunchDate is not null and RC.DropDate is null and
isAnalyst = -1 and Status is null

--05/23/2018
--Philipp Szalek (U.S. Economist) was missing on BRMobile watch list.
Update Authors
set Status = 1,EditDate = getdate()
where
last like '%Carlsson-Szlezak%'

--12/09/2019
--Rupal Agarwal (Asia-Quant Strategy) was missing on BRMobile watch list
Update Authors
set Status = 1,EditDate = getdate(), EditorId = 1126
where
Name like '%Rupal Agarwal%'

