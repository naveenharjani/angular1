--03/03/2017
--Brightcove changed the viewer, player id & player key format
--Built new video streamer and this required us to historically update tabbed videos filename notation
update Publications 
set FileName = substring(FileName,1,charindex(' ',FileName) - 1) + ' T'
where type = 'Video' and
DATALENGTH(FileName) > 15 