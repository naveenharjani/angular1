--11/08/2020

--Role for pilot users to test new analyst blast template
insert into Roles(RoleBID,Role,EditorId,EditDate)
select 0,'Email Template Pilot',1126,getdate()


