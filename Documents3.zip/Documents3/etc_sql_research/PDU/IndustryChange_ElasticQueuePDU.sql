--04/13/2020

/*

04/13/2020 - Ronny Gal
- Step 1 - Rename Global Specialty Pharmaceuticals to U.S. Biopharmaceuticals
- Step 2 Realign Global BioTechnology to U.S.BioPharmaceuticals

*/

--Step 1a:
--Change industry name from Global Specialty Pharmaceuticals to U.S. Biopharmaceuticals using Industry Admin creen
--This propogates the name change to Properties table

--Step 1b:
--Global Specialty Pharmaceuticals was only covered by Ronny Gal. It was not previously covered by any other analyst
--Reindex all historical documents to reflect new industry

insert into ElasticQueue(PubNo,Operation,Queued,QueuedBy)
select P.PubNo,'I',getdate(),'ac\kjosyu' 
from Properties Pr join Publications P on Pr.PubNo = P.PubNo
where PropValue = 'U.S. Biopharmaceuticals' and PropId = 11
and P.Type not in ('Video','Podcast')

/*
Step 2a:
Global BioTechnology was previously covered by Geoff & Ronny
Realign Global BioTechnology to U.S.BioPharmaceuticals using Coverage Admin screen for all the tickers(unlaunched,active,dropped) covered by Ronny Gal
*/

--Step 2b:
--Update Properties table
--Reindex all historical documents with old industry to reflect new industry

--Retrieve all the documents Global BioTechnology (Some of the documents already have U.S.BioPharmaceuticals while other do not)
select distinct PubNo
into #tmpRealign
from Properties 
where PropValue = 'Aaron (Ronny) Gal, Ph.D.'
and PubNo in 
(select PubNo from Properties
where PropValue = 'Global BioTechnology' and PropId = 11)

--select * from Properties where pubno in (select PubNo from #tmpRealign) and PropId = 11 order by 1

--Documents with U.S.BioPharmaceuticals industry in properties table, should delete Global BioTechnology row
delete from Properties
where 
PropValue = 'Global BioTechnology' and PropId = 11 and
PubNo in 
(select  T.PubNo from #tmpRealign T join Properties P on T.PubNo  = P.PubNo
where P.PropValue = 'U.S. Biopharmaceuticals' and P.PropId = 11)

--Documents which do not have U.S.BioPharmaceuticals industry in properties table, should rename Global BioTechnology to U.S.BioPharmaceuticals
update Properties
set PropValue = 'U.S. Biopharmaceuticals'
where
PropValue = 'Global BioTechnology' and PropId = 11 
and PubNo in 
(select PubNo from #tmpRealign)


insert into ElasticQueue(PubNo,Operation,Queued,QueuedBy)
select P.PubNo,'I',getdate(),'ac\kjosyu' 
from #tmpRealign Pr join Publications P on Pr.PubNo = P.PubNo
where 
P.Type not in ('Video','Podcast')



/*--
Duplicate properties
select PubNo, PropId, PropValue,count(*)  from Properties
group by PubNo, PropId, PropValue
having count(PropValue) > 1
order by 1 desc
2020-04-13 15:25:33.980 
spgetscheduledelasticQueueitems

*/
