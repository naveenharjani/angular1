--TransferOfCoverage.sql
--06/27/2018

/*

Meike Becker will take over coverage of Iberdola IBE.SM & Enel ENEL.IM
She will also launch on ELE.SM which is currently setup in the system 

*/

/*
Steps to do implicit transfer of coverage from Deepa to Meike
1. After report for IBE.SM and ENEL.IM is published (with Meike as primary) set drop date for Deepa's coverage of IBE.SM & ENEL.IM
2. Create Meike Becker's new coverage for IBE.SM & ENEL.IM
3. Set launch date for the above tickers to the date of the report.
4. Run query below to update the CoverageId to Meike's coverageId
5. Admin: Open the latest published model for IBE.SM & ENEL.IM, click on refresh to display the new coverage Id
This will clear the live values on the tickersheet. Click on 'Submit R/T/E As Live' to insert live numbers for Meike.
Click on Submit to update the non-EPS values.
*/

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2318
where PubNo = 139410 and Ticker = 'IBE.SM'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2319
where PubNo = 139410 and Ticker = 'ENEL.IM'
go



-- 7/5/2018: Transfer of Coverage for BAYN.GR from Jeremy Redenius to Wimal Kapadia
-- Jeremy dropped coverage on 6/29/2018 for Industry "European Chemicals" except BAYN.GR
-- Added BAYN.GR and Wimal Kapadia to report PubNo: 135350 and resubmit
select * from PublicationFinancials where pubno = 139350 and ticker in ('BAYN.GR')

/*
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2317
where pubno = 139350 and ticker in ('BAYN.GR')
*/


/*
05/14/2019
Transfer of Coverage from 'Christian Laughlin' to 'Doug Harned'

Steps to do implicit transfer of coverage from Christian to Doug
1. Get last report published dates for each of the 6 tickers
2. Set dropped date for Christian's coverage for the 6 tickers
2. Create Doug's new coverage for the 6 tickers. Set launch date for the above tickers to the date of the report.
4. Run query below to update the CoverageId to Doug's coverageId and ActionTags as below
5. Admin: Open the latest published model for 6 tickers, click on refresh to display the new coverage Id
This will clear the live values on the tickersheet. Click on 'Submit R/T/E As Live' to insert live numbers for Doug.
Click on Submit to update the non-EPS values.
*/

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2489
where PubNo = 146472 and Ticker = 'BA/.LN'
go

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2490
where PubNo = 146409 and Ticker = 'MGGT.LN'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2491
where PubNo = 146409 and Ticker = 'MTX.GR'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2492
where PubNo = 146409 and Ticker = 'RR/.LN'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2493
where PubNo = 146409 and Ticker = 'SAF.FP'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2494
where PubNo = 146153 and Ticker = 'HO.FP'
go

/*
02/12/2020
Transfer of Coverage from 'Gunther Zechman' to 'Jonas Oxgaard' (Linde Plc)

Steps to do implicit transfer of coverage from Gunther to Jonas
1. Get last report published dates for LIN & LIN.GR
2. Set dropped date for Gunther's LIN & LIN.GR coverage 
2. Create Jonas's new coverage for LIN & LIN.GR. Set launch date to the date of the report.
4. Run query below to update the CoverageId to Jonas's coverageId and ActionTags as below
5. Admin: Open the latest published model LIN, click on refresh to display the new coverage Id
This will clear the live values on the tickersheet. Click on 'Submit R/T/E As Live' to insert live numbers for Jonas.
Click on Submit to update the non-EPS values.
*/

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2645
where PubNo = 151718 and Ticker = 'LIN'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2646
where PubNo = 151718 and Ticker = 'LIN.GR'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2645
where PubNo = 151802 and Ticker = 'LIN'

go

/*
09/16/2020
Transfer of Coverage from 'Doug Harned' to 'George Zhao' - Switch the name of the �covering� author to George for Rolls-Royce, Safran, Thales, MTU, BAE Systems, and Meggitt.

Steps to do implicit transfer of coverage from Doug to George
1. Get last report published dates for each of the 6 tickers
2. Set dropped date for Doug's coverage for the 6 tickers
2. Create George's new coverage for the 6 tickers. Set launch date for the above tickers to the date of the report.
4. Run query below to update the CoverageId to George's coverageId and ActionTags as below
5. Admin: Open the latest published model for 6 tickers, click on refresh to display the new coverage Id
This will clear the live values on the tickersheet. Click on 'Submit R/T/E As Live' to insert live numbers for Doug.
Click on Submit to update the non-EPS values.
*/

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2774
where PubNo = 156827 and Ticker = 'BA/.LN'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2775
where PubNo = 156926 and Ticker = 'MGGT.LN'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2776
where PubNo = 156825 and Ticker = 'MTX.GR'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2777
where PubNo = 156825 and Ticker = 'RR/.LN'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2778
where PubNo = 156825 and Ticker = 'SAF.FP'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2779
where PubNo = 156825 and Ticker = 'HO.FP'
go

/*
11/19/2020
Transfer of Coverage of six Asia Autos stocks from 'Robin Zhu' to 'Arndt Ellinghorst 
Switch coverage of below six stocks-	1958.HK (BAIC)
-	1114.HK (Brilliance)
-	175.HK (Geely)
-	2333.HK (Great Wall-H)
-	2238.HK (GAC)
-	600104.CH (SAIC)

Steps to do implicit transfer of coverage from Robin to Arndt
1. Get last report published date for each of the 6 tickers
2. Set dropped date for Robin's coverage for the 6 tickers
2. Create Arndt's new coverage for the 6 tickers. Set launch date for the above tickers to the date of the report.
4. Run query below to update the CoverageId to Arndt's coverageId and ActionTags as below
5. Admin: Open the latest published model for 6 tickers, click on refresh to display the new coverage Id
This will clear the live values on the tickersheet. Click on 'Submit R/T/E As Live' to insert live numbers for Arndt.
Click on Submit to update the non-EPS values.
*/
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2822
where PubNo >= 157679 and Ticker = '2238.HK'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2821
where PubNo >= 157679 and Ticker = '2333.HK'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2820
where PubNo >= 157679 and Ticker = '600104.CH'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2819
where PubNo >= 157679 and Ticker = '175.HK'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2818
where PubNo >= 157679 and Ticker = '1114.HK'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2817
where PubNo >= 157142 and Ticker = '1958.HK'
go
/*03/22/2021*/
/*Transfer of Coverage of Bayer (BAYN.GR) from 'Wimal Kapadia' to 'Gunther Zechmann' 

Steps to do implicit transfer of coverage from Robin to Arndt
1. Get last report published date for BAYN.GR for Wimal Kapadia
2. Set dropped date for Wimal's coverage of BAYN.GR
2. Create Gunther's new coverage for BAYN.GR. Set launch date for the above tickers to the date of the report.
4. Run query below to update the CoverageId to Gunther's coverageId and ActionTags as below
5. Admin: Open the latest published model for BAYN.GR, click on refresh to display the new coverage Id
Note: In order to get latest model for Wimal you will have to query "Models" table and get modelid. Retrieve file from \\researchfs\research\links\models\<modelid filename>
This will clear the live values on the tickersheet. Click on 'Submit R/T/E As Live' to insert live numbers for Arndt.
Click on Submit to update the non-EPS values.
*/
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2868
where PubNo >= 160414 and Ticker = 'BAYN.GR'
go

/*06/02/2021*/
update PublicationFinancials
set CoverageAction = 'Initiate', RatingAction = 'Initiate'
where pubno = 162256 and Ticker = 'TAP'


/*07/27/2021*/
/*Transfer of Coverage of 4 stocks from from Bob Brackett (Global Metals & Mining) to Danielle Chigumira 
Barrick Gold (ABX.CN)
Newmont Mining (NEM)
Anglo-American (AAL LN)
Antofagasta (ANTO LN)

Steps to do implicit transfer of coverage from Robin to Arndt
1. Get last report published date for 4 tickers for Bob Brackett
2. Set dropped date for Bob's coverage of 4 stocks
2. Create Danielle's new coverage for 4 stocks. Set launch date for the above tickers to the date of the report.
4. Run query below to update the CoverageId to Danielle's coverageId and ActionTags as below
5. Admin: Open the latest published model for 4 stocks, click on refresh to display the new coverage Id
Note: In order to get latest model for Wimal you will have to query "Models" table and get modelid. Retrieve file from \\researchfs\research\links\models\<modelid filename>
This will clear the live values on the tickersheet. Click on 'Submit EPS/TP/R As Live' to insert live numbers for Danielle.
Click on Submit to update the non-EPS values.
6. Send a request to Bloomberg Help Desk, to manually update and list these tickers on Bloomberg under the new analyst
*/

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2930
WHERE PubNo >= 163184 AND Ticker = 'ANTO.LN'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2928
WHERE PubNo >= 163184 AND Ticker = 'AAL.LN'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2931
WHERE PubNo >= 163184 AND Ticker = 'ABX.CN'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2936
WHERE PubNo >= 163184 AND Ticker = 'GOLD'

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2929
WHERE PubNo >= 163281 AND Ticker = 'NEM'
GO


/*07/28/2021*/
/*Coverage Transfer from Trevor Stirling (European & American Alcoholic Beverages) to Nadine Sarwat
Boston Beer (SAM)
Molson Coors (TAP)
Constellation Brands (STZ)

Steps to do implicit transfer of coverage from Robin to Arndt
1. Get last report published date for 4 tickers for Trevor Stirling
2. Set dropped date for Trevor Stirling's coverage of 4 stocks
3. Create Nadine's new coverage for 4 stocks. Set launch date for the above tickers to the date of the report.
4. Run query below to update the CoverageId to Nadine Sarwat's coverageId and ActionTags as below
5. Admin: Open the latest published model for 4 stocks, click on refresh to display the new coverage Id
Note: In order to get latest model for Nadine you will have to query "Models" table and get modelid. Retrieve file from \\researchfs\research\links\models\<modelid filename>
This will clear the live values on the tickersheet. Click on 'Submit EPS/TP/R As Live' to insert live numbers for Nadine Sarwat.
Click on Submit to update the non-EPS values.
6. Send a request to Bloomberg Help Desk, to manually update and list these tickers on Bloomberg under the new analyst
*/

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2935
WHERE PubNo >= 163273 AND Ticker = 'SAM'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2934
WHERE PubNo >= 163273 AND Ticker = 'TAP'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2932
WHERE PubNo >= 163273 AND Ticker = 'STZ'
GO


/*09/30/2021*/
/*Coverage Transfer from Daniel Roeska (European Transportation) to Alexander Irving
AF.FP
LHA.GR
DPW.GR
DSV.DC
EZJ.LN
IAG.LN
KNIN.SW
RMG.LN
RYA.ID
RYAAY
WIZZ.LN

Steps to do implicit transfer of coverage from Daniel Roeska to Alexandar Irving
1. Get last report published date for 11 tickers for Daniel Roeska
2. Set dropped date for Daniel Roeska's coverage of 11 stocks
3. Create Alexander Irving's new coverage for 11 stocks. Set launch date for the above tickers to the date of the report.
4. Run query below to update the CoverageId to Alexander Irving's coverageId and ActionTags as below
5. Admin: Open the latest published model for 11 stocks, click on refresh to display the new coverage Id
Note: In order to get latest model for Alex you will have to query "Models" table and get modelid. Retrieve file from \\researchfs\research\links\models\<modelid filename>
This will clear the live values on the tickersheet. Click on 'Submit EPS/TP/R As Live' to insert live numbers for Alex Irving.
Click on Submit to update the non-EPS values.
6. Send a request to Bloomberg Help Desk, to manually update and list these tickers on Bloomberg under the new analyst
*/

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2978
WHERE PubNo >= 164389 AND Ticker = 'AF.FP'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2979
WHERE PubNo >= 164389 AND Ticker = 'LHA.GR'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2980
WHERE PubNo >= 164389 AND Ticker = 'DPW.GR'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2981
WHERE PubNo >= 164389 AND Ticker = 'DSV.DC'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2982
WHERE PubNo >= 164389 AND Ticker = 'EZJ.LN'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2983
WHERE PubNo >= 164389 AND Ticker = 'IAG.LN'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2984
WHERE PubNo >= 164389 AND Ticker = 'KNIN.SW'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2985
WHERE PubNo >= 164389 AND Ticker = 'RMG.LN'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2986
WHERE PubNo >= 164389 AND Ticker = 'RYA.ID'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2987
WHERE PubNo >= 164389 AND Ticker = 'RYAAY'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 2988
WHERE PubNo >= 164389 AND Ticker = 'WIZZ.LN'
GO

/* get model id by security id 
SELECT * FROM Models WHERE SecurityId IN ( 2399,1917, 1916, 2337,1911, 1912, 1918, 1914, 1913, 1915) ORDER BY ModelId desc
SELECT * FROM Models WHERE AnalystId =  791 ORDER BY ModelId desc -- Daniel Roeska
SELECT * FROM Models WHERE AnalystId =  826 -- Irving, Alex
*/

/*11/23/2021
Could you please kindly help with the transfer of coverage on below names from Arndt to Eunice starting from next week?

Geely (175 HK)
Great Wall (2333 HK)
SAIC (600104 CH)
GAC (2238 HK)                                         

Steps to do implicit transfer of coverage from Arndt Ellinghorst to Eunice Lee
1. Get last report published date for 4 tickers for Arndt Ellinghorst
2. Set dropped date for Arndt Ellinghorst's coverage of 4 stocks
3. Create Eunice Lee's new coverage for 4 stocks. Set launch date for the above tickers to the date of the report.
4. Run query below to update the CoverageId to Eunicee Lee's coverageId and ActionTags as below
5. Admin: Open the latest published model for 4 stocks, click on refresh to display the new coverage Id
Note: In order to get latest model for Eunice you will have to query "Models" table and get modelid. Retrieve file from \\researchfs\research\links\models\<modelid filename>
This will clear the live values on the tickersheet. Click on 'Submit EPS/TP/R As Live' to insert live numbers for Eunice Lee.
Click on Submit to update the non-EPS values and refresh the live model.
*/

-- SELECT * FROM PublicationFinancials WHERE Ticker = '175.HK' ORDER BY PubNo desc

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 3047
WHERE PubNo >= 165560 AND Ticker = '175.HK'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 3046
WHERE PubNo >= 165560 AND Ticker = '2333.HK'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 3045
WHERE PubNo >= 165560 AND Ticker = '600104.CH'
GO
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 3044
WHERE PubNo >= 165560 AND Ticker = '2238.HK'
GO

/* get model id by security id 
SELECT * FROM Models WHERE SecurityId IN ( 1420, 1425, 1662, 1421) ORDER BY ModelId desc
SELECT * FROM Models WHERE AnalystId =  1031  ORDER BY ModelId desc -- Arndt Ellinghorst
SELECT * FROM Models WHERE AnalystId =  858 -- Eunice Lee
*/

/*
11/30/2021
Transfer of coverage from Danielle Chigumura to Bob Brackett as the Danielle is leaving the firm.

*/

update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 3052
WHERE PubNo = 165669 AND Ticker = 'ABX.CN'
go
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 3051
WHERE PubNo = 165669 AND Ticker = 'GOLD'
go
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 3050
WHERE PubNo = 165669 AND Ticker = 'NEM'
go
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 3048
WHERE PubNo = 165669 AND Ticker = 'AAL.LN'
go
update PublicationFinancials
set CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 3049
WHERE PubNo = 165669 AND Ticker = 'ANTO.LN'
go

