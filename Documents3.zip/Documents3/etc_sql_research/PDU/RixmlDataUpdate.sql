USE [Contribution]
GO
-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO


--Organization Id's
--Bloomberg
Update Sites 
Set 	RixmlOrgIdType = 'Bloomberg', 
	RixmlOrgId = 0420
Where
	SiteBID = 8192
--Reuters
Update Sites 
Set 	RixmlOrgIdType = 'Reuters',
	RixmlOrgId = 12345
Where
	SiteBID = 2048
--FirstCall
Update Sites 
Set 	RixmlOrgIdType = 'Thomson',
	RixmlOrgId = xxxx
Where
	SiteBID = 512
--Thomson Select
Update Sites 
Set 	RixmlOrgIdType = 'TFNSelect',
	RixmlOrgId = TFN1234
Where
	SiteBID = 64

--Entitlements & Keywords
--Bloomberg Research Calls
Update Subscriptions
Set	RixmlEntitlement = 'BLOOMBERG_CLASS=0051',
	RixmlKeyword = 'BLOOMBERG_MENU_CODE=42001'
Where 	SiteBID = 8192 and DocumentTypeId = 1

--Reuters Research Calls
Update Subscriptions
Set	RixmlEntitlement = 'Reuters1',
Where 	SiteBID = 2048 and DocumentTypeId = 1

--FirstCall Research Calls
Update Subscriptions
Set	RixmlEntitlement = 'Thomsonxxx1',
Where 	SiteBID = 512 and DocumentTypeId = 1

--Thomson Select Research Calls
Update Subscriptions
Set	RixmlEntitlement = 'BTA6'
Where 	SiteBID = 64 and DocumentTypeId = 1

--Thomson Select Research Notes
Update Subscriptions
Set	RixmlEntitlement = 'BTA7'
Where 	SiteBID = 64 and DocumentTypeId = 2

--Thomson Select White Books
Update Subscriptions
Set	RixmlEntitlement = 'BTA8'
Where 	SiteBID = 64 and DocumentTypeId = 6

--Thomson Select Black Books
--For Thomson Select there are two entitlement codes for blackbooks
--BTA9 (Single Company Blackbook)
--BTA10 (Industry Analysis Blackbook)
Update Subscriptions
Set	RixmlEntitlement = 'BTA9'
Where 	SiteBID = 64 and DocumentTypeId = 3

GO
