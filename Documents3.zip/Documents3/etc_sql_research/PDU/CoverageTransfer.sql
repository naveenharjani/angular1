-- CoverageTransfer.sql

--CHANGES APPLIED TO PRD ON 09/30/2009 FOR TRANSFER OF COVERAGE
--LISA BEDELL ASSUMED COVERAGE OF 'NOBN.VX' & 'STMN.SW'
--APPLIED SCRIPT RETROACTIVELY

--Transfer of Coverage Call
Update TickerTableSecurities
Set CoverageId = 925,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 68221 and
    Ticker = 'NOBN.VX'

--All calls after overage transfer Call    
Update TickerTableSecurities
Set CoverageId = 925
Where
    Pubno > 68221 and
    Ticker = 'NOBN.VX'
    
--Transfer of Coverage Call    
Update TickerTableSecurities
Set CoverageId = 924,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 68221 and
    Ticker = 'STMN.SW'

--All calls after overage transfer Call        
Update TickerTableSecurities
Set CoverageId = 924
Where
    Pubno > 68221 and
    Ticker = 'STMN.SW'
    
--CHANGES APPLIED TO PRD ON 09/30/2009 FOR TRANSFER OF COVERAGE
--Gruber, Scott ASSUMED COVERAGE OF Dell, Ben's Oil Stocks

Update TickerTableSecurities
Set CoverageId = 957,
    CoverageAction = NULL,
    RatingAction = 'Upgrade'
Where
    Pubno = 69918 and
    Ticker = 'BHI'
    
Update TickerTableSecurities
Set CoverageId = 958,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 69918 and
    Ticker = 'DO'

Update TickerTableSecurities
Set CoverageId = 959,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 69918 and
    Ticker = 'ESV'
    
Update TickerTableSecurities
Set CoverageId = 960,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 69918 and
    Ticker = 'HAL'

Update TickerTableSecurities
Set CoverageId = 961,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 69918 and
    Ticker = 'NBR'

Update TickerTableSecurities
Set CoverageId = 962,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 69918 and
    Ticker = 'NE'

Update TickerTableSecurities
Set CoverageId = 963,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 69918 and
    Ticker = 'PTEN'

Update TickerTableSecurities
Set CoverageId = 964,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 69918 and
    Ticker = 'RDC'

Update TickerTableSecurities
Set CoverageId = 965,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 69918 and
    Ticker = 'RIG'

Update TickerTableSecurities
Set CoverageId = 966,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 69918 and
    Ticker = 'SLB'

Update TickerTableSecurities
Set CoverageId = 967,
    CoverageAction = NULL,
    RatingAction = 'Reiterate'
Where
    Pubno = 69918 and
    Ticker = 'WFT'

--07/17/2012
--Jack Scannel left the firm.
--Drop call for the following tickers under his coverage is published
--MRK.GR, NOVOB.DC, NVO, SHP.LN, SHPGY
--Marked the dropdate to the date of the drop call for the above tickers using coverage admin.
--Roche Holding AG (RHHBY, ROG.VX) covered by Jack is transferred over to Tim Anderson
--TimAnderson published call on Roche Holding AG
--Mark dropdate on Jack's coverage of Roche to the last report date of Roche on which Jack is primary author.
--Create Roch coverage for Tim Anderson and set launch date to the report date of the call on which Tim is primary author.
--Run the below sql to update the CoverageId column in TickerTableSecurities table to Tim's Coverage Id's.
update TickerTableSecurities set CoverageId = 1353 where PubNo = 89118 and Ticker = 'RHHBY'
update TickerTableSecurities set CoverageId = 1354 where PubNo = 89118 and Ticker = 'ROG.VX'

--09/07/2012
--Doug Harned - Taking over the coverage of SAF.FP
--Set drop date of last call in which Gianluca is primary author for his coverage
--Create Doug's coverage row for SAF.FP
--Set Launch date for Doug's coverage to first call on which Doug's primary author
--Ran the below sql to updae the coverage id column in tickertablesecurities to Doug's coverage id
update TickerTableSecurities set CoverageId = 1363 where PubNo >= 89596 and Ticker = 'SAF.FP'




--01/17/2013
--Lucas Montgomery - Taking over the coverge of BK & NTRS from Brad Hintz
--Set drop date of last call on which Brad Hintz is primary author for his coverage
--Create Luke's coverage rows for BK, NTRS & STT
--Set Launch date for Luke's coverage to first call on which Luke's primary author
update TickerTableSecurities 
set CoverageAction = null, RatingAction = 'Reiterate',CoverageId = 1403
where pubno = 93079  and  ticker = 'BK'
  
update TickerTableSecurities 
set CoverageAction = null, RatingAction = 'Reiterate',CoverageId = 1404
where pubno = 93079  and  ticker = 'NTRS'

update TickerTableSecurities 
set CoverageAction = null, RatingAction = 'Reiterate',CoverageId = 1405
where pubno = 92947 and  ticker = 'STT'

--02/12/2013
--Neil Beveridge - Taking over the coverge of 135.HK (Kuhnlun Energy) from Mike Parker
--Set drop date of last call on which BMike Parker is primary author for his coverage
--Create Neil's coverage row for 135.HK
--Set Launch date for Niel's coverage to date of first call on which Niel authored on 135.HK
--Update tickertablesecurities table with Niel's coverageid (two reports were published by Neil and hence
--two rows are to be updated).
update TickerTableSecurities 
set CoverageAction = null, RatingAction = 'Reiterate',CoverageId = 1406
where pubno = 93372 and  ticker = '135.HK'
update TickerTableSecurities 
set CoverageAction = null, RatingAction = 'Reiterate',CoverageId = 1406
where pubno = 93595 and  ticker = '135.HK'


--10/03/2013
--Sara Senatore: Suspended coverage of 8 tickers (U.S.Restaurants) on 5/10/2013 by publishing a suspend coverage call(95883)
--She resumed coverage on the same 8 tickers on 9/11/2013 using a resuming coverage call(98455)
--STEPS PERFORMED
--Step1: Set drop date to suspend coverage call and drop indicator to 'S' using coverage admin screen
--Step2: Created new coverage rows for her 8 tickers and marked the launch date to resume coverage call, launch indicator to 'R' using coverage admin screen
--Step3: Ran the below sql to retroactively set CoverageAction, RatingAction & CoverageId appropriately

UPDATE Authors SET Status = 1,EditDate = getdate() FROM Authors where AuthorId = 326

UPDATE Industries SET Status = 1,EditDate = getdate() FROM Industries 
where IndustryId in (Select IndustryId from ResearchCoverage where AnalystId = 326 and LaunchDate is not null and DropDate is null)

UPDATE Securities2 SET Status = 1,EditDate = getdate() FROM Securities2 S 
Where SecurityId in (Select SecurityId from ResearchCoverage where AnalystId = 326 and LaunchDate is not null and DropDate is null)

update TTS
set CoverageAction = 'Suspend', RatingAction = 'Drop'
from  
  TickerTableSecurities TTS join Properties P on TTS.Pubno = P.Pubno 
  join Publications P1 on P.PubNo = P1.PubNo
where
  P1.Title like '%Suspending Coverage%' and
  P.PropValue like '%Senatore%' and P.PropId = 5 and
  Ticker <> 'SPX'

update TTS
set CoverageAction = 'Resume', RatingAction = 'Initiate'
from  
  TickerTableSecurities TTS join Properties P on TTS.Pubno = P.Pubno 
  join Publications P1 on P.PubNo = P1.PubNo
where
  P1.Title like '%Resuming Coverage%' and
  P.PropValue like '%Senatore%' and P.PropId = 5 and
  Ticker <> 'SPX'

update TickerTableSecurities
set CoverageId = 1509
where
  Pubno > 95883 and
  Ticker = 'CMG'

update TickerTableSecurities
set CoverageId = 1510
where
  Pubno > 95883 and
  Ticker = 'DRI'

update TickerTableSecurities
set CoverageId = 1511
where
  Pubno > 95883 and
  Ticker = 'EAT'

update TickerTableSecurities
set CoverageId = 1512
where
  Pubno > 95883 and
  Ticker = 'MCD'

update TickerTableSecurities
set CoverageId = 1513
where
  Pubno > 95883 and
  Ticker = 'PNRA'

update TickerTableSecurities
set CoverageId = 1514
where
  Pubno > 95883 and
  Ticker = 'SBUX'

update TickerTableSecurities
set CoverageId = 1515
where
  Pubno > 95883 and
  Ticker = 'WEN'

update TickerTableSecurities
set CoverageId = 1516
where
  Pubno > 95883 and
  Ticker = 'YUM'
--Sara Senatore's resume coverage script ends here

--10/11/2013
--Ali Dibadj - Taking over the coverge of DPS & CCE from Steve Powers who left the firm
--Using admin coverage screen, set drop date of last call on which Steve Powers is primary author for his coverage 
--Using admin coverage screen, create Ali's Coverage rows for DPS & CCE 
--Using admin coverage screen, set Launch date for Ali's coverage to date of first call on which Ali authored on DPS & CCE (09/25/2013) 
--Update tickertablesecurities CoverageAction & RatingAction for Steve's drop call to NULL & 'Reiterate' (So drop does not appear on price charts)
--Update tickertablesecurities rows with Ali's coverageid id's 

update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Drop'
    RatingAction = 'Reiterate'  --Changed from 'Drop'
where
  Pubno = 98624 and
  Ticker in ('DPS','CCE')

update TickerTableSecurities
set CoverageId = 1517
where
  Pubno > 98624 and
  Ticker = 'DPS'

update TickerTableSecurities
set CoverageId = 1518
where
  Pubno > 98624 and
  Ticker = 'CCE'


-- 04/04/2014
-- Per Doug Harned, for analyst landing page, adjust coverage for SAF.FP, RR/.LN, BA/.LN
--Christian Laughlin - Taking over the coverge of SAF.FP, RR/.LN & BA/.LN from Douglas Harned & Finbar Sheehy
--Using admin coverage screen, set drop dates(for Doug & Finbar) to last report date on which Doug is primary author for SAF.FP and Finbar is primary author for RR/.LN, BA/.LN
--Using admin coverage screen, create Chris's Coverage rows for SAF.FP, RR/.LN, BA/.LN
--Using admin coverage screen, set Launch date for Chris's coverage to date of first call on which he is the primary author
--Update tickertablesecurities CoverageAction & RatingAction for Doug & Finbar's drop call to NULL & 'Reiterate' (So drop does not appear on price charts)
--Update tickertablesecurities rows with Chris's coverageid id's 


update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Drop'
    RatingAction = 'Reiterate'  --Changed from 'Drop'
where
  Pubno = 101823 and
  Ticker in ('RR/.LN')


update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Drop'
    RatingAction = 'Reiterate'  --Changed from 'Drop'
where
  Pubno = 102008 and
  Ticker in ('BA/.LN')

update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Drop'
    RatingAction = 'Reiterate'  --Changed from 'Drop'
where
  Pubno = 102126 and
  Ticker in ('SAF.FP')

update TickerTableSecurities
set CoverageId = 1619
where
  Pubno >= 101823 and
  Ticker = 'RR/.LN'

update TickerTableSecurities
set CoverageId = 1620
where
  Pubno >= 102008 and
  Ticker = 'BA/.LN'

update TickerTableSecurities
set CoverageId = 1618
where
  Pubno >= 102126 and
  Ticker = 'SAF.FP'

--12/11/2014
--Per Ghislain, Robin Zhu already has started covering SAIC and Changan(Promotion to be official in Jan'2015).
--Using admin coverage screen, set drop dates(for Max Warburton) to last report date on which Max is primary author for SAIC (600104.CH) & Changan (200625.CH, 000625.CH)
--Using admin coverage screen, create coverage rows for Robin Zhu (600104.CH, 200625.CH & 000625.CH)
--Using admin coverage screen, set Launch date for Robin's coverage to date of first call on which he is the primary author
--Update tickertablesecurities CoverageAction & RatingAction for Max's drop call to NULL & 'Reiterate' (So drop does not appear on price charts)
--Update tickertablesecurities rows with Robin's coverageid id's 

update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Drop'
    RatingAction = 'Reiterate'  --Changed from 'Drop'
where
  Pubno = 107446 and
  Ticker in ('600104.CH')

update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Drop'
    RatingAction = 'Reiterate'  --Changed from 'Drop'
where
  Pubno = 107624 and
  Ticker in ('000625.CH')

update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Drop'
    RatingAction = 'Reiterate'  --Changed from 'Drop'
where
  Pubno = 107624 and
  Ticker in ('200625.CH')


update TickerTableSecurities
set CoverageId = 1749
where
  Pubno >= 107446 and
  Ticker in ('600104.CH')

update TickerTableSecurities
set CoverageId = 1750
where
  Pubno >= 107624 and
  Ticker in ('000625.CH')

update TickerTableSecurities
set CoverageId = 1751
where
  Pubno >= 107624 and
  Ticker in ('200625.CH')

--12/11/2014
--Per email from Cheryl, Robin Zhu will assume coverage of Chinese Autos (subsection of Asian Autos)
--He's already covering analyst on SAIC & Changan (setup on 12/11/2014)
--Now he will assume coverage of remaining chinese auto companies (Brilliance,GAC,Great Wall, Dongfeng & Geely)
--Using admin coverage screen, set drop dates(for Max Warburton) to last report date on which Max is primary author for above companies
--Using admin coverage screen, create Robin Zhu's coverage rows for above comanies
--Update tickertablesecurities CoverageAction & RatingAction for Max's drop call to NULL & 'Reiterate' (So drop does not appear on price charts)

update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Drop'
    RatingAction = 'Reiterate'  --Changed from 'Drop'
where
  Pubno = 111926 and
  Ticker in ('1114.HK','175.HK','2238.HK','2333.HK','489.HK')

--5/7/2015
--Robin Zhu's transfer of coverage report (pubno 112601) was sent in
--Turning of CoverageAction & RatingAction before distributing to portals.
update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Initiate'
    RatingAction = 'Reiterate'  --Changed from 'Initiate'
where
  Pubno = 112601 and
  Ticker = '175.HK'
  
update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Initiate'
    RatingAction = 'Downgrade'  --Changed from 'Initiate'
where
  Pubno = 112601 and
  Ticker = '2238.HK'

update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Initiate'
    RatingAction = 'Upgrade'  --Changed from 'Initiate'
where
  Pubno = 112601 and
  Ticker = '2333.HK'

update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Initiate'
    RatingAction = 'Reiterate'  --Changed from 'Initiate'
where
  Pubno = 112601 and
  Ticker = '489.HK'

update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Initiate'
    RatingAction = 'Reiterate'  --Changed from 'Initiate'
where
  Pubno = 112588 and
  Ticker = '1114.HK'

--11/30/2015
select * from TickerTableSecurities where pubno = 117041 and Ticker in ('TTM','TTMT.IN')

update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Drop'
    RatingAction = 'Reiterate'  --Changed from 'Drop'
where
  Pubno = 116281 and
  Ticker in ('TTM','TTMT.IN')


update TickerTableSecurities
set CoverageAction = null,      --Changed from 'Initiate'
    RatingAction = 'Upgrade'  --Changed from 'Initiate'
where
  Pubno = 117041 and
  Ticker in ('TTM','TTMT.IN')

update TickerTableSecurities
set CoverageId = 1855
where
  Pubno >= 117041 and
  Ticker = 'TTMT.IN'


update TickerTableSecurities
set CoverageId = 1856
where
  Pubno >= 117041 and
  Ticker = 'TTM'