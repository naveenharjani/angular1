-- LinkSourcesPDU.sql
-- 12/21/2016

/*

insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) Values( 0, 'Analyst Blast',                 '01/01/2007', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) Values( 1, 'Morning Summary',               '12/19/2007', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) Values( 2, 'Cart',                          '10/29/2007', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) Values( 3, 'Embed Link',                    '06/11/2010', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) Values( 4, 'Sales Alert',                   '12/06/2010', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) Values(10, 'BR.com',                        '02/11/2008', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) Values(11, 'BR.com - Investor Themes',      '02/02/2012', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) Values(20, 'Cube - 90000001.pdf (help)',    '04/19/2011', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorID, EditDate) values(21, 'Cube - Streamer',               '06/07/2013', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) Values(30, 'iPad',                          '09/13/2011', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) Values(31, 'iPhone',                        '09/13/2011', 1229, getdate() )

insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(32, 'Most Popular (Global Ed)',      '04/15/2014', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(33, 'Most Popular (US Ed)',          '04/15/2014', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(34, 'Most Popular (PE Ed)',          '04/15/2014', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(35, 'Most Popular (AP Ed)',          '04/15/2014', 1229, getdate() )

insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(36, 'Summary (Global Ed)',           '04/15/2014', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(37, 'Summary (US Ed)',               '04/15/2014', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(38, 'Summary (PE Ed)',               '04/15/2014', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(39, 'Summary (AP Ed)',               '04/15/2014', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(40, 'Summary (Emerging Markets Ed)', '04/15/2014', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(41, 'Summary (UK Ed)',               '04/15/2014', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(42, 'Summary (Mid and Small Ed)',    '04/15/2014', 1229, getdate() )
insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(43, 'Summary (Fanelli Ed)',          '04/15/2014', 1229, getdate() )

insert into LinkSources (SourceId, Source, SourceLaunchDate, EditorId, EditDate) values(44, 'Algo',                          '09/03/2014', 1229, getdate() )

insert into LinkProducts (ProductId, Product, SeqNo, EditorId, EditDate) values (1, 'Blast',        1, 1229, getdate())
insert into LinkProducts (ProductId, Product, SeqNo, EditorId, EditDate) values (2, 'Summary',      2, 1229, getdate())
insert into LinkProducts (ProductId, Product, SeqNo, EditorId, EditDate) values (3, 'BR.com',       3, 1229, getdate())
insert into LinkProducts (ProductId, Product, SeqNo, EditorId, EditDate) values (4, 'Misc',         4, 1229, getdate())
insert into LinkProducts (ProductId, Product, SeqNo, EditorId, EditDate) values (5, 'Integration',  5, 1229, getdate())
insert into LinkProducts (ProductId, Product, SeqNo, EditorId, EditDate) values (6, 'Mobile App',   6, 1229, getdate())
insert into LinkProducts (ProductId, Product, SeqNo, EditorId, EditDate) values (7, 'Most Popular', 7, 1229, getdate())

insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) values (45, 'Sector Specialist', 4, 5, 1, getdate())

insert into LinkProducts (ProductId, Product, SeqNo, EditorId, EditDate) values (8, 'Linkbacks',    8, 1,    getdate())
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 60, 'Linkback - Bloomberg',       1, 8, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 61, 'Linkback - Thomson Reuters', 2, 8, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 62, 'Linkback - CapitalIQ',       3, 8, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 63, 'Linkback - FactSet',         4, 8, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 64, 'Linkback - BlueMatrix',      5, 8, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 65, 'Linkback - ONEaccess',       6, 8, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 66, 'Linkback - RSRCHX',          7, 8, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 67, 'Linkback - Red Deer',        8, 8, 1, getdate()

insert into LinkProducts (ProductId, Product, SeqNo, EditorId, EditDate) values (9, 'Models', 9, 1, getdate())
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 50, 'BR.com - Company Page',       1, 9, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 51, 'BR.com - Models Page',        2, 9, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 52, 'Email Model Link',            3, 9, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 53, 'BR.com - Industry Page',      3, 9, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 54, 'BR.com - Analyst Page',       4, 9, 1, getdate()
update LinkSources set SeqNo = 1 where SourceId = 51 -- BR.com - Models Page
update LinkSources set SeqNo = 2 where SourceId = 50 -- BR.com - Company Page
update LinkSources set SeqNo = 5 where SourceId = 52 -- Email Model Link

insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 12, 'BR.com - Today''s Research',  2, 3, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 13, 'BR.com - Industry Page',      3, 3, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 14, 'BR.com - Analyst Page',       4, 3, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 15, 'BR.com - Company Page',       5, 3, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 16, 'BR.com - Featured Reports',   7, 3, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 17, 'BR.com - Best of Bernstein',  8, 3, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 18, 'BR.com - Search Results',     9, 3, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 19, 'BR.com - Related Research',  10, 3, 1, getdate()
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 25, 'BR.com - GQS',               11, 3, 1, getdate()
update LinkSources set SeqNo = 6 where SourceId = 11 -- Investor Themes

-- Cart
update LinkSources set Source = 'Cart - Links' where SourceId = 2
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 5, 'Cart - Highlights',  2, 4, 1, getdate()
update LinkSources set SeqNo = 3 where SourceId = 3 -- Embed Link
update LinkSources set SeqNo = 4 where SourceId = 4 -- Sales Alert
update LinkSources set SeqNo = 1 where SourceId = 5 -- Cart - Highlights
update LinkSources set SeqNo = 2 where SourceId = 2 -- Cart - Links

-- Bernstein University
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) select 26, 'BR.com - Bernstein University', 12, 3, 1, getdate()

-- Morning Meeting
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) values (46, 'Morning Meeting', 5, 5, 1, getdate())

-- Assets
insert into LinkSources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) values (47, 'Email Content Link', 3, 1, 1, getdate())

-- Analyst Blast Auto
insert into linksources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) values (6, 'Analyst Blast Auto', 2, 1, 1229, getdate())

-- DEV CRM - Daily Tailored
insert into LinkProducts (ProductId, Product, SeqNo, EditorId, EditDate) values (10, 'CRM', 10, 1, getdate())
insert into linksources (SourceId, Source, SeqNo, ProductId, EditorId, EditDate) values (55, 'CRM - Daily Tailored', 1, 10, 1, getdate())

-- Re-alignment
-- 6/18/2020
update LinkProducts set SeqNo = 3 where Product = 'Most Popular'
update LinkProducts set SeqNo = 4 where Product = 'BR.com'
update LinkProducts set SeqNo = 5 where Product = 'Misc'
update LinkProducts set SeqNo = 6 where Product = 'Integration'
update LinkProducts set SeqNo = 7 where Product = 'Mobile App'
update LinkProducts set SeqNo = 8 where Product = 'Linkbacks'
update LinkProducts set SeqNo = 9 where Product = 'Models'

update LinkSources set ProductId = 3, SeqNo = 13 where SourceId = 51
update LinkSources set ProductId = 1, SeqNo = 2 where SourceId = 52


*/

select * from LinkProducts order by SeqNo

select * from LinkSources order by SourceId

select * from RVLinkProducts

select * from RVLinkSources

select LP.Product, LS.Source, LS.ProductId, LS.SourceId, LS.SeqNo
from LinkSources LS
left outer join LinkProducts LP on LP.ProductId = LS.ProductId
order by LP.SeqNo, LS.SeqNo

-- Review by date created
select * from LinkSources order by EditDate --, SourceId

-- Review by product sequence
select * from LinkSources order by ProductId, SeqNo

exec spRenderLinkSources
exec spRenderGetLinkSources
exec spRenderSetLinkSources

-- CRM

select * from SlxExternal.dbo.RVLinkProducts

select * from SlxExternal.dbo.RVLinkSources

select LP.Product, LS.Source, LS.ProductId, LS.SourceId, LS.SeqNo
from SlxExternal.dbo.RVLinkSources LS
left outer join SlxExternal.dbo.RVLinkProducts LP on LP.ProductId = LS.ProductId
order by LP.SeqNo, LS.SeqNo

select count(*) from SlxExternal.dbo.ContentUsage

select count(*) from SlxExternal.dbo.Readership

select SourceId, count(*)
from SlxExternal.dbo.Readership
group by SourceId
order by UsageId desc


select top 500 * from SlxExternal.dbo.ContentUsage order by UsageId desc
-- Contains "SourceId"

select top 500 * from SlxExternal.dbo.Readership
-- Contains "Source"

select distinct Type from SlxExternal.dbo.Readership -- ResearchUsage, PortalUsage

-- Frank 06/18/2020
select * from Compass.dbo.Interactions
where ServiceType = 'Standard Model'
and IntegrationType In ('BR', 'Portal')
and StartDate >= '01/01/2020'
order by StartDate desc

-- Mitesh 06/18/2020
Select I.StartDate, I.IntegrationType, I.ServiceType, I.ServiceSubType, I.Notes,
    U.UserName, U.IsActive, U.Division, U.ProductRegion, AccountType = isNull(ICA.Type, CA.Type), AccountName = IsNull(ICA.AccountName, CA.AccountName), CC.ContactName 
From Compass.dbo.Interactions I  (nolock)
Left Join Compass.[dbo].[InteractionHost]  IH (nolock) On I.InteractionsID = IH.InteractionsID
Left Join Compass.dbo.Users  U (nolock)  On IH.HostID = U.UserID
Left Join Compass.dbo.InteractionAttendee IA (nolock) On I.InteractionsID = IA.InteractionsID
Left Join Compass.dbo.Contact CC (nolock)  On IA.ContactId = CC.ContactID
Left Join Compass.dbo.Account CA (nolock)  On CC.AccountID = CA.AccountID           
Left Join Compass.dbo.Account ICA (nolock)  On IA.AccountId = ICA.AccountID And CC.AccountID In (Select AccountID From Compass.dbo.Account (nolock) Where AccountName In ('SCB Personal Contacts','SCB Staff Alumni') )
Where I.ServiceType In ('Standard Model')
    And I.IntegrationType In ('BR', 'Portal') -- 'Logger', 'Allegro Interaction', 'Quant Service', 'Quant Site Activity'
    And Cast(I.StartDate As Date) Between '20200101' And '20200618'


*/
