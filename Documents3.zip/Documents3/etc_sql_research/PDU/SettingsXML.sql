--11/30/2016
--Settings.xml  
--Updated to cleanup unused groups.
--Added 'QA Group' to prevent QA users from accidentally using templates in production environment
select * from Settings

insert into Settings (Setting,EditorId,EditDate)
select 'QA Group',1126,getdate()

delete from UserSettings
where SettingId in 
  (select SettingId from Settings where Setting in ('LighterSideGroup','MediaBlastGroup','NoTTMove','ProductSpecialistGroup'))

delete from Settings
where Setting in ('LighterSideGroup','MediaBlastGroup','NoTTMove','ProductSpecialistGroup')


