--5/12/2011: Implicit coverage for Smith & Nephew SNN & SN/.LN
-- Coverage change from Jack Scanell to Lisa Clive Bedell

UPDATE TickerTableSecurities SET CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 1166
WHERE 
Pubno = 80319 and 
Ticker = 'SN/.LN'
GO
UPDATE TickerTableSecurities SET CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 1167
WHERE 
Pubno = 80319 and 
Ticker = 'SNN'
GO

--5/18/2011: Implicit coverage for Smith & Nephew FMS & FME.GR
-- Coverage change from Jack Scanell to Lisa Clive Bedell
UPDATE TickerTableSecurities SET CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 1164
WHERE 
Pubno = 80433 and 
Ticker = 'FME.GR'
GO
UPDATE TickerTableSecurities SET CoverageAction = null, RatingAction = 'Reiterate', CoverageId = 1165
WHERE 
Pubno = 80433 and 
Ticker = 'FMS'
GO

--10/16/2013
--Implicit target price change made on 08/02 for CLX from $88 to $87
--Subsequent calls published for CLX(about 25 reports) maintained TP of $87.
--To correct the implicit change and make it explicit
--1.Update the TargetPriceAction in TickerTableSecurities row as per below
--2.Update the old TargetPrice value in TickerTableSecuritiesOld row as per below. 
--  If there's no row in TickerTableSecuritiesOld then insert a row with the old value.
update TickerTableSecurities 
set TargetPriceAction = 'Decrease'
where
  PubNo = 97718 and
  Ticker = 'CLX'

update TickerTableSecuritiesOld 
set TargetPrice = '88.00'
where
  PubNo = 97718 and
  Ticker = 'CLX'

-- 11/12/2013
-- Explicit TP change from $90 to $85 for RIR on 09/16/2013 Pub#98533
-- All the subsequent calls till date used the old TP value $90.
-- Below sql to update the TP to $85(new value)
UPDATE TickerTableSecurities 
SET TargetPrice = '85.00' 
WHERE Ticker = 'RNR' and
PubNo > 98533

-- 11/12/2013
-- Implicit TP change from $45 to $60 made on 05/03/2013 Pub#95701
-- Below sql applied to update TickerTableSecuritiesOld with old value(explicit change)
-- Update the TargetPriceAction to 'Increase'
UPDATE TickerTableSecuritiesOld
SET TargetPrice = '45.00'
WHERE Ticker = 'AIG' and
PubNo = 95701
 
UPDATE TickerTableSecurities 
SET TargetPriceAction = 'Increase' 
WHERE Ticker = 'AIG' and
PubNo = 95701

