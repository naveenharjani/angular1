DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '11/20/2013'
SET @Title        = 'Video - ' + 'Mid-Cap Banks: The Yin-Yang of Credit and Net Interest Income'
SET @BrightCoveId = '2851893127001'
SET @Approver     = 'Kagda, Falaq'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="U.S. Banks/Mid-Cap" id="56" propId="11" />
  <Property name="Author" value="Kevin St. Pierre" id="159" propId="5" />
  <Property name="Author" value="Marty Winik" id="538" propId="5" />
  <Property name="Author" value="Brian B. Rudick, CFA" id="569" propId="5" />
  <Property name="Ticker" value="BBT" id="836" propId="13" />
  <Property name="Ticker" value="CMA" id="838" propId="13" />
  <Property name="Ticker" value="COF" id="139" propId="13" />
  <Property name="Ticker" value="FITB" id="839" propId="13" />
  <Property name="Ticker" value="HBAN" id="1151" propId="13" />
  <Property name="Ticker" value="KEY" id="840" propId="13" />
  <Property name="Ticker" value="MTB" id="1009" propId="13" />
  <Property name="Ticker" value="RF" id="844" propId="13" />
  <Property name="Ticker" value="SNV" id="1008" propId="13" />
  <Property name="Ticker" value="STI" id="499" propId="13" />
  <Property name="Ticker" value="ZION" id="1152" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="Over the last two years, improvement in provisions has overpowered anemic loan growth and NIM pressure, driving earnings growth. This note examines how long that might continue and whether normalizing provisions might offset future NII improvement." id="" propId="24" />
  <Property name="BulletB" value="Consensus expectations across our coverage show net interest income growing by 5% in 2014 and 8% in 2015. With modest total loan growth and continued net interest margin pressure, we believe those forecasts will prove optimistic." id="" propId="25" />
  <Property name="BulletC" value="Consensus calls for a 16% increase in loss provisions in 2014 and 47% in 2015. With a continued decline in NCOs and sluggish loan growth, these expectations could prove conservative, but we believe residential NCOs will stop short of their prior trough." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="100169" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)