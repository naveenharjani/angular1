DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '08/01/2013'
SET @Title        = 'Video - ' + 'China Banks: Q2 2013 Earning Preview; A Higher Hurdle May Lead Some Banks to Fall Short of Expectations'
SET @BrightCoveId = '2577193762001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="Chinese &amp; Hong Kong Banks" id="94" propId="11" />
  <Property name="Author" value="Mike Werner" id="222" propId="5" />
  <Property name="Author" value="Hua Cheng" id="546" propId="5" />
  <Property name="Author" value="Wangshu Qiu" id="492" propId="5" />
  <Property name="Ticker" value="1288.HK" id="1234" propId="13" />
  <Property name="Ticker" value="1398.HK" id="1154" propId="13" />
  <Property name="Ticker" value="3328.HK" id="1157" propId="13" />
  <Property name="Ticker" value="3968.HK" id="1158" propId="13" />
  <Property name="Ticker" value="3988.HK" id="1156" propId="13" />
  <Property name="Ticker" value="939.HK" id="1155" propId="13" />
  <Property name="Ticker" value="998.HK" id="1159" propId="13" />
  <Property name="Ticker" value="1988.HK" id="1493" propId="13" />
  <Property name="Ticker" value="MXAPJ" id="1132" propId="13" />
  <Property name="BulletA" value="The Chinese banks will report their Q2:13 earnings results during the final two weeks of August. We expect the group to narrowly beat consensus EPS as recent positive earnings revisions have raised the bar for the group." id="" propId="24" />
  <Property name="BulletB" value="We expect Q2:13 profit growth to come in at 9% YoY (down from 12% in Q1 ''13 and 15% in 2012) &amp; ROE to fall 260bp YoY. We forecast better trends at the Big 4 banks as their ROE will decline just 100bp YoY, less than the 360bp decline at the smaller banks." id="" propId="25" />
  <Property name="BulletC" value="We are adjusting our 2013-14 EPS estimates as we push out our timing expectations for further deposit interest rate reforms to early 2014 from mid-year 2013. We continue to prefer the large banks with BOC/CCB/ICBC rated OP." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="97654" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML