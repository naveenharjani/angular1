-- Porges_2013_07_22.sql

USE Research
GO

-- spPrepareVideo 97283 -- Related PubNo

DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '07/22/2013'
SET @Title        = 'Video - ' + 'ONXX: Summarizing the Outlook for Kyprolis - Reasonable to Expect Superiority vs Velcade, Near Term Trials Seem Safe'
SET @BrightCoveId = '2558966807001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="Global Biotechnology" id="58" propId="11" />
  <Property name="Author" value="Geoffrey C. Porges, MBBS" id="251" propId="5" />
  <Property name="Ticker" value="CELG" id="1001" propId="13" />
  <Property name="Ticker" value="ONXX" id="1394" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="Onyx is in an active auction and the key value driver for the company is Kyprolis; most investor questions concern our outlook for key trials and for the product long term, particularly vs Velcade. Here we review those trials and the product''s profile." id="" propId="24" />
  <Property name="BulletB" value="Updates from Kyprolis phase II studies at ASCO 2013 bode well for the outcomes of the FOCUS and ASPIRE phase III studies. We expect the Cytoxan effect to be modest in FOCUS, and anticipate a 30-40% PFS benefit in ASPIRE in early 2014." id="" propId="25" />
  <Property name="BulletC" value="As a second entrant to market Kyprolis needs to show differentiation from Velcade. Limited clinical head to head comparison data are available to date, but Kyprolis may have a leg up given lower rates of neuropathy, even compared to subQ Velcade." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="97283" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML
