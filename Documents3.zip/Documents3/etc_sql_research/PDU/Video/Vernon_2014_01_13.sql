DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '01/13/2014'
SET @Title        = 'Video - ' + 'Best of Bernstein: UNP: Improving Economy and Floor in Coal + Improving Returns = Rail to Own in 2014'
SET @BrightCoveId = '3038172901001'
SET @Approver     = 'Possavino, Regina'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="North American Transportation" id="104" propId="11" />
  <Property name="Author" value="David Vernon" id="511" propId="5" />
  <Property name="Author" value="Joshua Chuang" id="598" propId="5" />
  <Property name="Author" value="Trang Luong" id="630" propId="5" />
  <Property name="Ticker" value="UNP" id="1276" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="UNP is our Best of Bernstein pick for 2 reasons: 1) We believe UNP has increasing leverage to a strengthening NAFTA economy; and 2) We think the market is under appreciating UNPs ability to drive high rates of return even as the pricing story decelerates." id="" propId="24" />
  <Property name="BulletB" value="As coal headwinds abate, we see UNP as an excellent way to play the improving economy and expect the company to continue to improve returns despite the deceleration of the pricing story. Expect real pricing and productivity to result in sub 65 OR by 2015." id="" propId="25" />
  <Property name="BulletC" value="We have been surprised by the sustainability of returns at UNP, and as volume growth accelerates into even higher returns, we believe the stock will support a premium valuation. We rate UNP Outperform with a one year target price of $195." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="100983" />
</RelatedPublications>
</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML

