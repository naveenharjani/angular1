-- 09/05/2013

USE Research
GO

-- spPrepareVideo 98338 -- Related PubNo

DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '09/05/2013'
SET @Title        = 'Video - ' + 'Biotech: After Torrid 1st Half, a Dozen Higher Probability Take Out and Break Out Opportunities for the Rest of 2013'
SET @BrightCoveId = '2650548856001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="Global Biotechnology" id="58" propId="11" />
  <Property name="Author" value="Geoffrey C. Porges, MBBS" id="251" propId="5" />
  <Property name="Author" value="Raluca Pancratov, Ph.D." id="607" propId="5" />
  <Property name="Author" value="Wen Shi, Ph.D." id="606" propId="5" />
  <Property name="Ticker" value="ALXN" id="1181" propId="13" />
  <Property name="Ticker" value="AMGN" id="36" propId="13" />
  <Property name="Ticker" value="BIIB" id="816" propId="13" />
  <Property name="Ticker" value="CELG" id="1001" propId="13" />
  <Property name="Ticker" value="DNDN" id="1332" propId="13" />
  <Property name="Ticker" value="GILD" id="815" propId="13" />
  <Property name="Ticker" value="MDVN" id="1331" propId="13" />
  <Property name="Ticker" value="PCYC" id="1407" propId="13" />
  <Property name="Ticker" value="PTLA" id="1507" propId="13" />
  <Property name="Ticker" value="VRTX" id="819" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="Strong performance of the Biotech sector 2013 YTD has been driven by undervalued stocks re-pricing but also operatinal &amp; strategic success.  &quot;Takeouts&quot; and &quot;breakouts&quot;, i.e. M&amp;A and positive clinical newsflow, could offer further upside through year end." id="" propId="24" />
  <Property name="BulletB" value="Using screens and subjective assessment we identified 9 potential takeouts incl Portola(PTLA), Biomarin (BMRN), Seattle Genetics(SGEN), Incyte(INCY), Celldex(CLDX), Clovis(CLVS) and as well as Achillion (ACHN) and Ariad (ARIA), with dual potential." id="" propId="25" />
  <Property name="BulletC" value="We found 3 companies, Medivation (MDVN), Achillion (ACHN) and Ariad (ARIA) with major breakout potential from catalysts over the next 6-12 months. These appear to have a higher probability of event occurring, and potentially a high impact on stock price." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="98338" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML
