DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '08/12/2013'
SET @Title        = 'Video - ' + 'U.S. Multi-Industry: Landing on a Wing &amp; a Prayer - Stocks Up More than 2Q Results Warrant in Anticipation of Acceleration'
SET @BrightCoveId = '2600360132001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="U.S. Multi Industry &amp; Electrical Equipment" id="47" propId="11" />
  <Property name="Author" value="Steven E. Winoker" id="413" propId="5" />
  <Property name="Author" value="Yidong Xiang" id="576" propId="5" />
  <Property name="Author" value="Emma Carron" id="593" propId="5" />
  <Property name="Ticker" value="DHR" id="1060" propId="13" />
  <Property name="Ticker" value="EMR" id="1059" propId="13" />
  <Property name="Ticker" value="ETN" id="207" propId="13" />
  <Property name="Ticker" value="GE" id="757" propId="13" />
  <Property name="Ticker" value="HON" id="272" propId="13" />
  <Property name="Ticker" value="IR" id="292" propId="13" />
  <Property name="Ticker" value="MMM" id="1061" propId="13" />
  <Property name="Ticker" value="PNR" id="1438" propId="13" />
  <Property name="Ticker" value="ROK" id="1376" propId="13" />
  <Property name="Ticker" value="TYC" id="544" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="We believe there is still more relative upside coming for USMI stocks despite the run-up during this quarter''s results and guidance. USMI stocks are up &gt;400bp more than the S&amp;P YTD." id="" propId="24" />
  <Property name="BulletB" value="Growth expectations picked up in management commentary and leading indicators now that we are into the 2nd half. Despite slow growth, we believe they still have more room to run as earnings accelerate, especially for &quot;self help&quot; stories." id="" propId="25" />
  <Property name="BulletC" value="In this note, we summarize our thesis for each name, review macro &amp; end market trends, the quarter''s results &amp; guidance &amp; update our pricing charts as well as models. We also move our target prices 12 months out on the following 12 months earnings." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="97910" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML