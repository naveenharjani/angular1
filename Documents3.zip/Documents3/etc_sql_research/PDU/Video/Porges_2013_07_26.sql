-- Porges_2013_07_26.sql
-- 07/26/2013

USE Research
GO

spPrepareVideo 97467 -- Related PubNo

DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '07/26/2013'
SET @Title        = 'Video - ' + 'Biotech: A Quick Quarterly Round Up Video With a Summary of Our Outlook for Large Cap Growth Names'
SET @BrightCoveId = '2567633827001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="Global Biotechnology" id="58" propId="11" />
  <Property name="Author" value="Geoffrey C. Porges, MBBS" id="251" propId="5" />
  <Property name="Author" value="Wen Shi, Ph.D." id="606" propId="5" />
  <Property name="Author" value="Raluca Pancratov, Ph.D." id="607" propId="5" />
  <Property name="Ticker" value="GILD" id="815" propId="13" />
  <Property name="Ticker" value="VRTX" id="819" propId="13" />
  <Property name="Ticker" value="CELG" id="1001" propId="13" />
  <Property name="Ticker" value="ALXN" id="1181" propId="13" />
  <Property name="Ticker" value="BIIB" id="816" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="97502" />
  <RelatedPublication pubNo="97494" />
  <RelatedPublication pubNo="97490" />
  <RelatedPublication pubNo="97488" />
  <RelatedPublication pubNo="97467" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML
