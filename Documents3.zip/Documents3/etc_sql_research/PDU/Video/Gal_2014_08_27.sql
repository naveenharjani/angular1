﻿-- Gal_2014_08_27.sql
-- 08/27/2014

/*
Ronny deleted the Quick Take related to this video Video - Specialty Pharmaceuticals: A Look at Management Compensation Across the Sector (2014 Edition) 

The Call – PubNo 106480 – needs to be related instead (currently there’s no related research piece). 
When Krishna/Naveen/Frank, when you get a chance please can you do this – we can’t do it via the tool.
*/

-- select * from RelatedPublications where pubno = 106468

-- insert into RelatedPublications(PubNo, RelatedPubNo, EditorId, EditDate)
-- values(106468, 106480, 0, getdate())


