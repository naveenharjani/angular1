DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '10/21/2013'
SET @Title        = 'Video - ' + 'Allergan: Making the Bull Case - Likely to Win Lumigan, FDA May Revise Restasis Guidelines, Value of Consumer Business'
SET @BrightCoveId = '2753429819001'
SET @Approver     = 'Kagda, Falaq'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="U.S. Pharmaceuticals/Specialty" id="71" propId="11" />
  <Property name="Author" value="Aaron (Ronny) Gal, Ph.D." id="309" propId="5" />
  <Property name="Author" value="Alan Sonnenfeld" id="528" propId="5" />
  <Property name="Author" value="Alex Blanckley, CFA" id="391" propId="5" />
  <Property name="Ticker" value="AGN" id="19" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="Here, we analyze the Lumigan .01% trial, discuss the potential of FDA revising its Restasis guidance and argue Allergan CAGR and intrinsic value make the risk reward attractive. (i) Our read of the court transcript from the Lumi. .01% case suggests AGN..." id="" propId="24" />
  <Property name="BulletB" value="... has 75% chance of winning the case despite modest differentiation from the prior Lumigan version. (ii)  FDA decisions on complex GRx shows the agency considered innovator''s arguments ahead of GRx approval and modified its stance when convinced." id="" propId="25" />
  <Property name="BulletC" value="(iii) A pro forma model of a company made of AGN four ''perpetuity'' products (Botox, fillers, implants and refresh tears), suggests $2.2B rev. business with 8%+ rev CAGR and ''14 EPS of $4.46.  Fair value for this co. would be at least $80 (18x).  OP $105" id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="99242" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML