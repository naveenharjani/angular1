-- Video Pdu.sql

-- 06/20/2013 Add rows for Alexia Howards video call
spPrepareVideo 96672 -- Related PubNo

DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Date         = '06/20/2013'
SET @Type         = 'Video'
SET @Title        = 'Video - ' + 'U.S. Food: Volume Continues to Grow in U.S. Tracked Channels; HSY and MDLZ Post Strong Results'
SET @BrightCoveId = '2494957676001' 
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>' +
  '<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
  '/>' +
'<Properties>
  <Property name="Industry" value="U.S. Food" id="77" propId="11" />
  <Property name="Author" value="Alexia Howard" id="322" propId="5" />
  <Property name="Author" value="Gretchen Guo" id="550" propId="5" />
  <Property name="Author" value="Elyn Rodriguez" id="573" propId="5" />
  <Property name="Ticker" value="CAG" id="1099" propId="13" />
  <Property name="Ticker" value="CPB" id="148" propId="13" />
  <Property name="Ticker" value="DF" id="1032" propId="13" />
  <Property name="Ticker" value="GIS" id="241" propId="13" />
  <Property name="Ticker" value="HSH" id="1406" propId="13" />
  <Property name="Ticker" value="HSY" id="276" propId="13" />
  <Property name="Ticker" value="K" id="299" propId="13" />
  <Property name="Ticker" value="MKC" id="1173" propId="13" />
  <Property name="Ticker" value="MDLZ" id="983" propId="13" />
  <Property name="Ticker" value="SJM" id="1175" propId="13" />
  <Property name="Ticker" value="KRFT" id="1456" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="This report highlights branded and private label sales growth and share trends in U.S. Nielsen tracked channels, focusing on category-specific trends. In the latest 4 weeks, sales increased +0.4% on average, prices fell -0.6% and volumes increased +1.0%." id="" propId="24" />
  <Property name="BulletB" value="Hershey, Mondelez and Campbell Soup posted above or at group average sales growth. On the other hand, Kellogg, Smucker''s, General Mills, Hillshire Brands, McCormick, Kraft Foods Group, and ConAgra posted in-line or below average growth." id="" propId="25" />
  <Property name="BulletC" value="HSY gained share in chocolate and gum. MDLZ''s cookies volumes were strong. Chobani''s % sales on promotion remain elevated. KRFT and HSH saw weak sales in lunchmeats. SJM coffee sales were dragged by price declines. RTE cereals sales remain lackluster." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="96672" />
</RelatedPublications>' +
'</Research>'

-- NOTE: No Entry in Documents table

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML