DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '08/06/2013'
SET @Title        = 'Video - ' + 'Qualcomm: Might the Veto of the iPhone Ban &quot;Defang&quot; Their Standards-Essential IP and Create Risk? We Don''t Think So'
SET @BrightCoveId = '2587025600001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="U.S. Semiconductors" id="30" propId="11" />
  <Property name="Author" value="Stacy A. Rasgon, Ph.D." id="433" propId="5" />
  <Property name="Author" value="Ranjit Ramachandran, CFA" id="548" propId="5" />
  <Property name="Author" value="Garrett Marks" id="590" propId="5" />
  <Property name="Ticker" value="QCOM" id="437" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="A recent US ITC order found that AAPL had violated certain Standards-Essential Patents (SEPs) belonging to Samsung, and ordered an importation ban of older AAPL products that infringed. Over the weekend, however, the Obama administration vetoed the order." id="" propId="24" />
  <Property name="BulletB" value="The veto could suggest it will be more difficult to seek importation bans from the US ITC based on SEP infringement in the future. However, QCOM has not historically sought bans of this type. And, infringed parties are can still seek monetary redress." id="" propId="25" />
  <Property name="BulletC" value="We see no intermediate risk to QCOM. And if the value of SEPs in general was watered down, in the long term only new 4G-only licenses would in theory be impacted. But, QCOM already has 90 4G licensees, incl most handset vendors; we thus see minimal risk." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="97777" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML