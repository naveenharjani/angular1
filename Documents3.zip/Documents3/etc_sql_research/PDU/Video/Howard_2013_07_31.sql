DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '07/31/2013'
SET @Title        = 'Video - ' + 'Hershey and Mondelez: Hitting the Sweet Spot - Cocoa Yields Could Increase by 500% by 2020 Following Genome Mapping'
SET @BrightCoveId = '2575336390001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="U.S. Food" id="77" propId="11" />
  <Property name="Author" value="Alexia Howard" id="322" propId="5" />
  <Property name="Author" value="Gretchen Guo" id="550" propId="5" />
  <Property name="Author" value="Elyn Rodriguez" id="573" propId="5" />
  <Property name="Ticker" value="HSY" id="276" propId="13" />
  <Property name="Ticker" value="MDLZ" id="983" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="The longer term outlook for cocoa input costs for chocolate manufacturers looks benign based on the potential for boosting the yields of global cocoa crops by up to 500% over the next decade." id="" propId="24" />
  <Property name="BulletB" value="In turn, this has led most of the leading global chocolate companies to commit to 100% sustainably sourced cocoa by 2020. We believe that Hershey and Mondelez may be structurally advantaged on their input cost outlook relative to peers." id="" propId="25" />
  <Property name="BulletC" value="As a result, we are increasing our target price for Mondelez from $36 to $38 and reiterate our outperform rating and for Hershey from $86 to $99, with a market-perform rating due to valuation." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="97616" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML

