DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '07/31/2013'
SET @Title        = 'Video - ' + 'Broadcom: Separating Reason from Emotion, What to Do With the Stock? After Analysis, We''re Inclined to Stick With It'
SET @BrightCoveId = '2575505616001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="U.S. Semiconductors" id="30" propId="11" />
  <Property name="Author" value="Stacy A. Rasgon, Ph.D." id="433" propId="5" />
  <Property name="Author" value="Ranjit Ramachandran, CFA" id="548" propId="5" />
  <Property name="Author" value="Garrett Marks" id="590" propId="5" />
  <Property name="Ticker" value="BRCM" id="1100" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="BRCM''s recent report was, to put it mildly, disappointing. The reaction was extreme, down ~20% w/ multiple sell-side DGs. With shares at historically low multiples, questions of &quot;What is priced in?&quot; &quot;What is the downside?&quot; &amp; &quot;What to do?&quot; become paramount" id="" propId="24" />
  <Property name="BulletB" value="We use DCF analysis to determine what might be priced in at current levels, additionally correcting for cash needed to offset dilution as well as an acquisition strategy that is really &quot;outsourced&quot; R&amp;D. The analysis suggests current stock prices..." id="" propId="25" />
  <Property name="BulletC" value="...incorporate major top line deceleration w/ margins well below targets, &amp; even allowing wireless to dwindle to zero (highly unlikely) provides a ~ $24 floor. Therefore, despite lack of catalysts we are inclined to stick with it here. BRCM=OP; TP=$36" id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="97617" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML
