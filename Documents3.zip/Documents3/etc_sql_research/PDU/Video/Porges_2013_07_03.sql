DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Date         = '07/3/2013'
SET @Type         = 'Video'
SET @Title        = 'Video - ' + 'Portola: Antidote Showing Green Lights from Full Data Presentation, Full Speed Ahead to FDA Meeting Later in 2013'
SET @BrightCoveId = '2523686650001'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>' +
  '<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
  '/>' +
'<Properties>
  <Property name="Industry" value="Global Biotechnology" id="58" propId="11" />
  <Property name="Author" value="Geoffrey C. Porges, MBBS" id="251" propId="5" />
  <Property name="Author" value="Wen Shi, Ph.D." id="606" propId="5" />
  <Property name="Author" value="Raluca Pancratov, Ph.D." id="607" propId="5" />
  <Property name="Ticker" value="PTLA" id="1507" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="Yesterday Portola presented the complete data from the first stage of their ongoing phase IIa trial of PRT4445 (now andexanet), their antidote to factor Xa inhibitors. The data were consistent with SEC filings but add to our confidence in the program." id="" propId="24" />
  <Property name="BulletB" value="Specifically, the human responses to andexanet remain very consistent with the animal responses, which in turn showed significant reductions in bleeding in animals on antithrombotics. Investors should find consistency of effects and safety reassuring." id="" propId="25" />
  <Property name="BulletC" value="The reduction in clotting time, restoration of thrombin activity and removal of free apixaban were all dose dependent and very significant. The waning of effect seen within 30 mins of the bolus does suggest more than one dose may be needed. Outpfrm, $30." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="96897" />
</RelatedPublications>' +
'</Research>'

-- NOTE: No Entry in Documents table

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

-- EXEC spSavePublication @PublicationXML

EXEC spSavePublication2 @PublicationXML

