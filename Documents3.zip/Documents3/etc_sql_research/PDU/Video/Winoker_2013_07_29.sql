-- Video_PDU.sql
-- 05/03/2013
-- 06/04/2013
-- 07/03/2013

/*

OVERVIEW

* A video is published using new stored procedure spSavePublication2 @PublicationXML
* spSavePublication2 supercedes spSavePublication to simplify the xml payload by removing redundant PubNo attributes
* The xml payload or schema <Properties> section (input) conforms to the _analystblast.sql (output) format
* A video has no rows in Documents table

INSTRUCTIONS

- Call spPrepareVideo passing in specified related PubNo

- Update variables and XML:
* Replace variable @Date
* Replace variable @Title
* Replace variable @BrightCoveId
* Replace variable @Approver with video SA -- de Krei, Cheryl, Klose, Nina, Knowles, Ariel, Possavino, Regina
* Copy/replace xml <Properties> and <RelatedPublications> sections
* Replace xml <RelatedPublication> pubNo value(s)
* Escape strings with additional single quote as neded

- Run sql block

- Archive published video sql to \Etc\sql\Research\PDU\Video\Last_yyyy_mm_dd.sql

*/

USE Research
GO

spPrepareVideo 97529 -- Related PubNo

DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '07/29/2013'
SET @Title        = 'Video - ' + 'Bernstein Industrials and Transports: Global SCB Industrial Momentum Barometer Trending Higher with Pick-Up Ahead'
SET @BrightCoveId = '2572614759001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="U.S. Multi Industry &amp; Electrical Equipment" id="47" propId="11" />
  <Property name="Industry" value="North American Transportation" id="104" propId="11" />
  <Property name="Author" value="Steven E. Winoker" id="413" propId="5" />
  <Property name="Author" value="David Vernon" id="511" propId="5" />
  <Property name="Author" value="Yidong Xiang" id="576" propId="5" />
  <Property name="Author" value="Emma Carron" id="593" propId="5" />
  <Property name="Author" value="Joshua Chuang" id="598" propId="5" />
  <Property name="Author" value="Steven Wislo" id="452" propId="5" />
  <Property name="Ticker" value="CHRW" id="1279" propId="13" />
  <Property name="Ticker" value="CNI" id="1275" propId="13" />
  <Property name="Ticker" value="CSX" id="1277" propId="13" />
  <Property name="Ticker" value="DHR" id="1060" propId="13" />
  <Property name="Ticker" value="EMR" id="1059" propId="13" />
  <Property name="Ticker" value="ETN" id="207" propId="13" />
  <Property name="Ticker" value="FDX" id="1273" propId="13" />
  <Property name="Ticker" value="GE" id="757" propId="13" />
  <Property name="Ticker" value="HON" id="272" propId="13" />
  <Property name="Ticker" value="IR" id="292" propId="13" />
  <Property name="Ticker" value="JBHT" id="1280" propId="13" />
  <Property name="Ticker" value="MMM" id="1061" propId="13" />
  <Property name="Ticker" value="NSC" id="1278" propId="13" />
  <Property name="Ticker" value="PNR" id="1438" propId="13" />
  <Property name="Ticker" value="ROK" id="1376" propId="13" />
  <Property name="Ticker" value="TYC" id="544" propId="13" />
  <Property name="Ticker" value="UNP" id="1276" propId="13" />
  <Property name="Ticker" value="UPS" id="1274" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="This is the second monthly update of our global monthly SCB Industrial Momentum Barometers (SIMB), attempting to forecast industrial companies'' organic growth, consensus earnings growth and transportation shipment volume." id="" propId="24" />
  <Property name="BulletB" value="Our barometers measure more than 180 indicators. Correlations are all in the 70% range and lead by 2-3 months with history back ~13 years (for PMI indicators) and up to 3 quarters lead and 80% correlation for our covered companies'' organic growth." id="" propId="25" />
  <Property name="BulletC" value="In summary, at least for 3Q, these barometers suggest more improvement in PMIs coming vs. last month''s readings although still not a major surge." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="97529" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML


-- DEBUG

select * from Publications          where PubNo = @vPubNo
select * from Documents             where PubNo = @vPubNo
select * from Properties            where PubNo = @vPubNo
select * from RelatedPublications   where PubNo = @vPubNo
select * from TickerTables          where PubNo = @vPubNo
select * from TickerTableSecurities where PubNo = @vPubNo
select * from RVDocuments           where DocId = @vPubNo
select * from RVAltDocuments        where DocId = @vPubNo

select * from PublicationsLog       where PubNo = @vPubNo order by AuditNo Desc
select * from DocumentsLog          where PubNo = @vPubNo order by AuditNo Desc
select * from PropertiesLog         where PubNo = @vPubNo order by AuditNo Desc

GO

sp_help Publications
sp_help Documents
sp_help Properties
sp_helptext spCheckForResubmits
sp_helptext spReserveCounter
sp_helptext spDeletePublication2
sp_helptext spSavePublication
