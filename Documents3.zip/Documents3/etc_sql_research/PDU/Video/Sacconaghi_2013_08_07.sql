DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '08/07/2013'
SET @Title        = 'Video - ' + 'The Long View: The Used Smartphone Market, Part 1: What, Where and How Big?'
SET @BrightCoveId = '2589826596001'
SET @Approver     = 'Possavino, Regina'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="U.S. IT Hardware" id="25" propId="11" />
  <Property name="Author" value="A.M. (Toni) Sacconaghi, Jr." id="136" propId="5" />
  <Property name="Author" value="Jonathan Cofsky, CFA" id="352" propId="5" />
  <Property name="Author" value="Eric C. Garfunkel, CFA" id="255" propId="5" />
  <Property name="Ticker" value="AAPL" id="6" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="This is Part 1 of a deep dive into the used smartphone market. We examine how the mkt works, growth drivers and update our smartphone model with a detailed trade-in model. Part 2 focuses on the impact to Apple. iPhones are the most popular used devices" id="" propId="24" />
  <Property name="BulletB" value="Trade-ins are increasingly prevalent due to new carrier plans, retail and online outlets. The trade-in market is still in its infancy, ~12% of smartphones globally that were upgraded last year were sold/traded-in. ~70% went to emerging mkts, esp China" id="" propId="25" />
  <Property name="BulletC" value="The used mkt is poised to explode - growing from 53M to 257M over 2013-2018 and creating a ~100 bp annual headwind to new unit growth, with a revenue impact 2x units. This shadow mkt means smartphones are more penetrated than 3rd party data suggests" id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="97806" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML