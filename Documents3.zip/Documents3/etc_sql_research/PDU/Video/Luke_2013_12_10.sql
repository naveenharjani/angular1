DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '12/09/2013'
SET @Title        = 'Video - ' + 'T.Rowe Price: Three Bear Rejoinders to the Bull Case'
SET @BrightCoveId = '2915179577001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="U.S. Capital Markets" id="16" propId="11" />
  <Property name="Author" value="Luke Montgomery, CFA" id="439" propId="5" />
  <Property name="Author" value="Brad Hintz" id="186" propId="5" />
  <Property name="Author" value="Anojja Shah" id="615" propId="5" />
  <Property name="Author" value="Grant D''Avino" id="624" propId="5" />
  <Property name="Ticker" value="BEN" id="80" propId="13" />
  <Property name="Ticker" value="BLK" id="1366" propId="13" />
  <Property name="Ticker" value="IVZ" id="1367" propId="13" />
  <Property name="Ticker" value="TROW" id="536" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="We examine three objections to the TROW bull case: 1) the defined contribution industry has become competitively destabilized; 2) investors should severely discount TROWs cash in valuation; and 3) the institutional outflow controversy is undimensionable." id="" propId="24" />
  <Property name="BulletB" value="Despite DC industry evolution, the bundled providers should maintain share, especially in TROW''s core mid-market. We disagree that TROW''s cash has little value. We agree the outflow controversy is undimensionable, but that does not sink the bull case." id="" propId="25" />
  <Property name="BulletC" value="While the bears raise some legitimate concerns that deepen the dialogue around the stock, ultimately our analysis of these concerns increases our confidence in our Outperform thesis." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="100436" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML