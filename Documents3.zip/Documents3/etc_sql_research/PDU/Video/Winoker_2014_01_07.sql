DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '01/07/2014'
SET @Title        = 'Video - ' + 'U.S. Multi-Industry: Globally Synchronized Expansion in 2014 - Why Sit on the Sidelines?'
SET @BrightCoveId = '3023293659001'
SET @Approver     = 'de Krei, Cheryl'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="U.S. Multi Industry &amp; Electrical Equipment" id="47" propId="11" />
  <Property name="Author" value="Steven E. Winoker" id="413" propId="5" />
  <Property name="Author" value="Emma Carron" id="593" propId="5" />
  <Property name="Ticker" value="ALLE" id="1584" propId="13" />
  <Property name="Ticker" value="DHR" id="1060" propId="13" />
  <Property name="Ticker" value="EMR" id="1059" propId="13" />
  <Property name="Ticker" value="ETN" id="207" propId="13" />
  <Property name="Ticker" value="GE" id="757" propId="13" />
  <Property name="Ticker" value="HON" id="272" propId="13" />
  <Property name="Ticker" value="IR" id="292" propId="13" />
  <Property name="Ticker" value="MMM" id="1061" propId="13" />
  <Property name="Ticker" value="PNR" id="1438" propId="13" />
  <Property name="Ticker" value="ROK" id="1376" propId="13" />
  <Property name="Ticker" value="TYC" id="544" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="In this note, we review the global environment for our stock''s performance in 2014, including end markets, company performance, currency, price/cost and more. We update our forecasts and roll forward our valuation methodology." id="" propId="24" />
  <Property name="BulletB" value="In summary, we remain positive on our sector for 2014 &amp; expect stock appreciation slightly above earnings &amp; cash flow growth.  Organic growth should accelerate &amp; margin expansion should continue, even if decelerating, plus there is balance sheet upside." id="" propId="25" />
  <Property name="BulletC" value="The bottom line is that yes, we would still put money to work in the sector. We rank our stocks in the following order: Outperforms PNR, TYC, HON, DHR, ETN, IR and Market-performs ROK, EMR, ALLE, MMM and GE." id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="100855" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML