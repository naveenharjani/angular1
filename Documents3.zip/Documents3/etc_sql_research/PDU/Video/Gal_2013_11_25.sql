DECLARE
  @Date            varchar(10),
  @Type            varchar(31),
  @Title           varchar(255),
  @Approver        varchar(31),
  @BrightCoveId    varchar(30),
  @PubNo           int,
  @Version         int,
  @CounterValue    int,
  @ResubmitFlag    char,
  @NumDeleted      int,
  @EditorId        int,
  @EditDate        varchar(30),
  @PublicationXML  varchar(MAX),
  @vPubNo          varchar(10)

SET @Type         = 'Video'
SET @EditorId     = 0
SET @EditDate     = CONVERT(varchar, getdate(), 101)

-- *** UPDATE VARIABLES ***
SET @Date         = '11/26/2013'
SET @Title        = 'Video - ' + 'Novo Nordisk: A Bottom-Up Estimate of Insulin Manufacturing Costs and Margins; a Strategic Concern'
SET @BrightCoveId = '2866718218001'
SET @Approver     = 'Kagda, Falaq'

-- Checks if a resubmit document
EXEC spCheckForResubmits @Date, @Type, @Title, @PubNo OUTPUT, @Version OUTPUT

If @PubNo = 0
BEGIN
  SET @ResubmitFlag = 'N'
  -- Get ReserveCounter for PubNo
  EXEC [spReserveCounter] 'PubNo', @CounterValue OUTPUT
  --SELECT @CounterValue As 'CounterValue'
  SET @PubNo = @CounterValue
  SET @Version = 0
END
ELSE
  SET @ResubmitFlag = 'Y'

-- Increment Version Number
SET @Version = @Version + 1

SELECT @PubNo As 'PubNo', @Version As 'Version', @ResubmitFlag As 'ResubmitFlag'

SET @vPubNo = CONVERT(varchar, ISNULL(@PubNo, ''))   -- Convert int to char for xml save

DELETE FROM RelatedPublications WHERE PubNo = @vPubNo

EXEC spDeletePublication2 @PubNo, 'R', @EditorId, @NumDeleted OUTPUT

SELECT 'spDeletePublication2 [' + @vPubNo + '] Rows deleted: ' + CONVERT(varchar, @NumDeleted) AS spDeletePublication2Status

SET @PublicationXML = '<?xml version="1.0" encoding="ISO8859-1" ?>' + 
'<Research>
<Publications ' +
      'PubNo="'         + @vPubNo                     + '" ' +
      'Date="'          + @Date                       + '" ' +
      'Type="'          + @Type                       + '" ' +
      'Title="'         + @Title                      + '" ' +
      'FileName="'      + @BrightCoveId               + '" ' +
      'FileSize="'      + ''                          + '" ' +
      'Approver="'      + @Approver                   + '" ' +
      'ApprovedDate="'  + @EditDate                   + '" ' +
      'PublishedDate="' + @EditDate                   + '" ' +
      'Version="'       + CONVERT(varchar, @Version)  + '" ' +
      'Instructions="'  + '4'                         + '" ' +
      'EditorID="'      + CONVERT(varchar, @EditorId) + '" ' +
      'EditDate="'      + @EditDate                   + '" ' +
'/>

<Properties>
  <Property name="Industry" value="European Specialty Pharmaceuticals" id="123" propId="11" />
  <Property name="Author" value="Aaron (Ronny) Gal, Ph.D." id="309" propId="5" />
  <Property name="Author" value="Alex Blanckley, CFA" id="391" propId="5" />
  <Property name="Author" value="Alan Sonnenfeld" id="528" propId="5" />
  <Property name="Ticker" value="NOVOB.DC" id="974" propId="13" />
  <Property name="Ticker" value="NVO" id="973" propId="13" />
  <Property name="Ticker" value="MSDLE15" id="800" propId="13" />
  <Property name="Ticker" value="SPX" id="735" propId="13" />
  <Property name="BulletA" value="Some believe the insulin market is resistant to low-cost competition due to scale advantages for the incumbents. We conducted a series of interviews with consultants and entrants and here present data which contradicts this belief." id="" propId="24" />
  <Property name="BulletB" value="There is indeed a material ($500M) upfront cost to build a facility and develop biosimilars. However, ongoing manufacturing is relatively cheap: $2.50-$5 per unit. The profits in the US Insulin market are thus extreme at 95% gross margin." id="" propId="25" />
  <Property name="BulletC" value="Several entrants are currently building capacity and developing products. They will reasonably enter the US/EU market in ~2020. In the EU, low commercial barriers suggest the market will erode. In the US, it would depend on strength of commercial barriers" id="" propId="26" />
</Properties>
<RelatedPublications>
  <RelatedPublication pubNo="100258" />
</RelatedPublications>

</Research>'

SELECT 'PublicationXML' = CAST(@PublicationXML AS XML)

EXEC spSavePublication2 @PublicationXML