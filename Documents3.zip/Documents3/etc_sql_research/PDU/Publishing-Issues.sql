-- Publishing-Issues.sql
-- 04/27/2018

--One of the reports on PS server is stuck in the publishing queue in 'Processing' state.
--Canceled the item by running the below pdu sql.

-- 04/27/2018
UPDATE PublicationQueue
SET ProcessStatus = 'Canceled', ProcessEnded = GETDATE(), CanceledBy = 'ac\ssures1'
WHERE QueueId = 19452

/*
Fix:
Publishing queuue has been modified to display 'Cancel' link for items in Processing state (provided they are in that state for more than 5 minutes)
Clicking on 'Cancel' link runs the below stored procedure.

spCancelPublicationQueueItem @QueueId,@EditorId

Once this is done, Publishing service on the problem server needs to be restarted to resume publishing.
*/

--05/01/2018
--EAT report was stuck in 'Processing' state on PS server for more than 30 mins.
UPDATE PublicationQueue
SET ProcessStatus = 'Canceled', ProcessEnded = GETDATE(), CanceledBy = 'ac\kjosyu'
WHERE QueueId = 19599

UPDATE Securities2
SET Locked = 0
WHERE Ticker = 'EAT'

--05/03/2018
--IHG.LN report was stuck in 'Processing' state on PS server for more than 20 mins.
UPDATE PublicationQueue
SET ProcessStatus = 'Canceled', ProcessEnded = GETDATE(), CanceledBy = 'ac\kjosyu'
WHERE QueueId = 19682



--08/08/2019
-- select top 100 * from PublicationQueue where processstatus = 'Processing...' order by queueid desc
-- 'Quick Take - Inpex 2Q19: Earnings Beat. Ichthys ramp up exceeds expectations. Outperform JPY1900' was stuck in 'Processing' state on CL server
UPDATE PublicationQueue
SET ProcessStatus = 'Canceled', ProcessEnded = GETDATE(), CanceledBy = 'ac\nharja'
WHERE QueueId = 36813
