USE [Research]
GO

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

--====================================================================================================
--Script to update action tags and coverageid for historical data in tickertablesecurities
--====================================================================================================
--Initialize Values
UPDATE TickerTableSecurities SET coverageid = null,CoverageAction=null,RatingAction=null,TargetPriceAction=null,EstimateAction=null
GO
UPDATE  ResearchCoverage SET LaunchInd = 'I',DropInd = 'D'
GO
--Update CoverageId
UPDATE TTS  
SET CoverageId = RC.CoverageId  
FROM  
  TickerTableSecurities TTS 
  JOIN Publications P ON TTS.PubNo = P.PubNo  
  JOIN Securities2 S ON TTS.Ticker = S.Ticker  and S.TickerType = 'Stock'
  JOIN ResearchCoverage RC ON S.SecurityId = RC.SecurityId  
  JOIN Properties Pr ON P.PubNo = Pr.PubNo and Pr.PropId = 5
  JOIN Authors A ON Pr.PropValue = A.Name
WHERE  
  A.AuthorId = RC.AnalystId and
  P.date between RC.Launchdate and isnull(RC.DropDate,dateadd(d,365,getdate()))  
GO

--CoverageAction & RatingAction 
--Initiate
--Inner subquery is to determine the first call in case of multiple calls on the launch date
--Only the first call is tagged Initiate and subsequent calls are tagged Reiterate
SELECT min(TTS.Pubno) MIN_Pubno,max(TTS.Pubno) MAX_Pubno, TTS.Ticker,P.Date
INTO
    #Tmp_Duplicates
FROM
  TickerTableSecurities TTS
  JOIN Publications P on TTS.PubNo = P.PubNo
  JOIN ResearchCoverage RC on TTS.CoverageId = RC.CoverageId
WHERE
  P.Date = RC.LaunchDate 
GROUP BY TTs.Ticker,P.Date

  
UPDATE TTS  
SET CoverageAction = 'Initiate',
  RatingAction = 'Initiate'
FROM
  TickerTableSecurities TTS
  JOIN Publications P on TTS.PubNo = P.PubNo
  JOIN ResearchCoverage RC on TTS.CoverageId = RC.CoverageId
WHERE
  P.Date = RC.LaunchDate and
  TTS.PubNo in (SELECT MIN_Pubno FROM #Tmp_Duplicates)

GO
--CoverageAction & RatingAction 
--Drop
--Inner subquery is to detemine the last call in case of multiple calls on coverage drop date.
--Only the last call is tagged Drop and previous calls are tagged Reiterate
UPDATE TTS  
SET CoverageAction = 'Drop',
  RatingAction = 'Drop'
FROM
  TickerTableSecurities TTS
  JOIN Publications P on TTS.PubNo = P.PubNo
  JOIN ResearchCoverage RC on TTS.CoverageId = RC.CoverageId
WHERE
  P.date = RC.DropDate and
  TTS.PubNo in (SELECT MAX_Pubno FROM #Tmp_Duplicates)
GO
DROP TABLE #Tmp_Duplicates
GO
--RatingAction
--Upgrade
UPDATE TTS
SET RatingAction = 'Upgrade'
FROM
  TickerTableSecurities TTS left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
WHERE
  (TTSO.Rating = 'U' and TTS.Rating = 'M') OR
    (TTSO.Rating = 'U' and TTS.Rating = 'O') OR
    (TTSO.Rating = 'M' and TTS.Rating = 'O') 

GO
--RatingAction
--Downgrade

UPDATE TTS
SET RatingAction = 'Downgrade'
FROM
  TickerTableSecurities TTS left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
WHERE
  (TTSO.Rating = 'M' and TTS.Rating = 'U') OR
    (TTSO.Rating = 'O' and TTS.Rating = 'U') OR
    (TTSO.Rating = 'O' and TTS.Rating = 'M')

GO
--RatingAction
--Reiterate
UPDATE TTS
SET	RatingAction = 'Reiterate'
FROM
  TickerTableSecurities TTS
  join Securities2 S on TTS.Ticker = S.Ticker and S.TickerType = 'Stock'
WHERE
  TTS.RatingAction is null

GO

--TargetPriceAction
--Increase
UPDATE TTS
SET TargetPriceAction = 'Increase'
FROM
  TickerTableSecurities TTS left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
WHERE
    CONVERT(FLOAT,TTS.TargetPrice) > CONVERT(FLOAT,TTSO.TargetPrice) and
  TTSO.Targetprice is not null and TTSO.TargetPrice <> ''
GO

--TargetPriceAction
--Decrease
UPDATE TTS
SET TargetPriceAction = 'Decrease'
FROM
  TickerTableSecurities TTS left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
WHERE
    CONVERT(FLOAT,TTS.TargetPrice) < CONVERT(FLOAT,TTSO.TargetPrice) and
  TTSO.Targetprice is not null and TTSO.TargetPrice <> ''
GO

--TargetPriceAction
--Update
UPDATE TTS
SET TargetPriceAction = 'Update'
FROM
  TickerTableSecurities TTS
  join Securities2 S on TTS.Ticker = S.Ticker and S.TickerType = 'Stock'
WHERE
  TTS.TargetPriceAction is null
GO

--EstimateAction
--Upgrade
UPDATE TTS
SET EstimateAction = 'Upgrade'
FROM
  TickerTableSecurities TTS left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
WHERE
    CONVERT(FLOAT,TTS.EPSThisYear) > CONVERT(FLOAT,TTSO.EPSThisYear) and
  TTSO.EPSThisYear is not null and TTSO.EPSThisYear <> '' and TTSO.epsthisyear <> 'n/a' 
GO

--EstimateAction
--Downgrade
UPDATE TTS
SET EstimateAction = 'Downgrade'
FROM
  TickerTableSecurities TTS left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
WHERE
    CONVERT(FLOAT,TTS.EPSThisYear) < CONVERT(FLOAT,TTSO.EPSThisYear) and
  TTSO.EPSThisYear is not null and TTSO.EPSThisYear <> '' and TTSO.epsthisyear <> 'n/a'
GO

--EstimateAction
--Reiterate
UPDATE TTS
SET EstimateAction = 'Reiterate'
FROM
  TickerTableSecurities TTS
  join Securities2 s on TTS.Ticker = S.Ticker and S.TickerType = 'Stock'
WHERE
  TTS.EstimateAction is null
GO

--Fix Lehman & MS Suspend & Resume Tags
UPDATE	ResearchCoverage
SET		LaunchInd = 'R' 
WHERE	CoverageId in (593,616) and
    DropDate is null
go
UPDATE	ResearchCoverage
SET		DropInd = 'S' 
WHERE	CoverageId in (94,96) and
    DropDate is not null
go
UPDATE TickerTableSecurities
SET		CoverageAction = 'Suspend',
    RatingAction = 'Drop'
WHERE	PubNo in (38218,38219) and
    Ticker <> 'SPX'
go
UPDATE TickerTableSecurities
SET		CoverageAction = 'Resume',
    RatingAction = 'Initiate'
WHERE	PubNo in (47447,48382) and
    Ticker <> 'SPX'
go
