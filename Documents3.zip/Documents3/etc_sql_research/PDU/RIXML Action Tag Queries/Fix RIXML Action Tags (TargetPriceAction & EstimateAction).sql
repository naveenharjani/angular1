UPDATE TickerTableSecurities
SET TargetPriceAction = null, EstimateAction = null
GO

--TargetPriceAction
--Increase
UPDATE TTS
SET TargetPriceAction = 'Increase'
FROM
  TickerTableSecurities TTS left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
WHERE
    CONVERT(FLOAT,TTS.TargetPrice) > CONVERT(FLOAT,TTSO.TargetPrice) and
  TTSO.Targetprice is not null and TTSO.TargetPrice <> ''
GO

--TargetPriceAction
--Decrease
UPDATE TTS
SET TargetPriceAction = 'Decrease'
FROM
  TickerTableSecurities TTS left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
WHERE
    CONVERT(FLOAT,TTS.TargetPrice) < CONVERT(FLOAT,TTSO.TargetPrice) and
  TTSO.Targetprice is not null and TTSO.TargetPrice <> ''
GO

--TargetPriceAction
--Update
UPDATE TTS
SET TargetPriceAction = 'Update'
FROM
  TickerTableSecurities TTS
  join Securities2 S on TTS.Ticker = S.Ticker and S.TickerType = 'Stock'
WHERE
  TTS.TargetPriceAction is null
GO

--EstimateAction
--Upgrade
UPDATE TTS
SET EstimateAction = 'Upgrade'
FROM
  TickerTableSecurities TTS left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
WHERE
    CONVERT(FLOAT,TTS.EPSThisYear) > CONVERT(FLOAT,TTSO.EPSThisYear) and
  TTSO.EPSThisYear is not null and TTSO.EPSThisYear <> '' and TTSO.epsthisyear <> 'n/a' 
GO

--EstimateAction
--Downgrade
UPDATE TTS
SET EstimateAction = 'Downgrade'
FROM
  TickerTableSecurities TTS left outer join TickerTableSecuritiesOld TTSO on TTS.PubNo = TTSO.PubNo and TTS.Ticker = TTSO.Ticker
WHERE
    CONVERT(FLOAT,TTS.EPSThisYear) < CONVERT(FLOAT,TTSO.EPSThisYear) and
  TTSO.EPSThisYear is not null and TTSO.EPSThisYear <> '' and TTSO.epsthisyear <> 'n/a'
GO

--EstimateAction
--Reiterate
UPDATE TTS
SET EstimateAction = 'Reiterate'
FROM
  TickerTableSecurities TTS
  join Securities2 s on TTS.Ticker = S.Ticker and S.TickerType = 'Stock'
WHERE
  TTS.EstimateAction is null
GO
