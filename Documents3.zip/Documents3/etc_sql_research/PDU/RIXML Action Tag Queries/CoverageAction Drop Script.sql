USE Research
GO
--Apply CoverageAction & Ratingaction for terminating coverage calls
UPDATE TTS  
SET CoverageAction = 'Drop',
  RatingAction = 'Drop'
FROM
  TickerTableSecurities TTS
  JOIN Publications P on TTS.PubNo = P.PubNo
  JOIN ResearchCoverage RC on TTS.CoverageId = RC.CoverageId
WHERE
  P.date = RC.DropDate and
  RC.DropInd = 'D' and
  TTS.PubNo = (SELECT max(PubNo) FROM TickerTableSecurities TTS1 WHERE TTS1.Ticker = TTS.Ticker and TTS1.CloseDate = TTS.CloseDate)

GO
--Apply CoverageAction & Ratingaction for suspending coverage calls
UPDATE TTS  
SET CoverageAction = 'Suspend',
  RatingAction = 'Drop'
FROM
  TickerTableSecurities TTS
  JOIN Publications P on TTS.PubNo = P.PubNo
  JOIN ResearchCoverage RC on TTS.CoverageId = RC.CoverageId
WHERE
  P.date = RC.DropDate and
  RC.DropInd = 'S' and
  TTS.PubNo = (SELECT max(PubNo) FROM TickerTableSecurities TTS1 WHERE TTS1.Ticker = TTS.Ticker and TTS1.CloseDate = TTS.CloseDate)

GO