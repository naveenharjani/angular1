-- SecurityCheckboxTypes.sql

use Research
go

Update securitycheckboxtypes
set disclosure = 'Accounts over which Bernstein and/or their affiliates exercise investment discretion own more than 1% of the outstanding common stock of the following companies: (TICKERS).',
editorId = 1126,
editdate = getdate()
where
disclosureid = 1

Update securitycheckboxtypes
set disclosure = 'Bernstein currently makes a market in the following companies: (TICKERS).',
editorId = 1126,
editdate = getdate()
where
disclosureid = 2

Update securitycheckboxtypes
set disclosure = 'The following companies are or during the past twelve (12) months were clients of Bernstein, which provided non-investment banking-securities related services and received compensation for such services: (TICKERS).',
editorId = 1126,
editdate = getdate()
where
disclosureid = 3

Update securitycheckboxtypes
set disclosure = 'An affiliate of Bernstein received compensation for non-investment banking-securities related services from the following companies: (TICKERS).',
editorId = 1126,
editdate = getdate()
where
disclosureid = 4

Update securitycheckboxtypes
set disclosure = 'In the past twelve (12) months, Bernstein or an affiliate managed or co-managed a public offering of securities of: (TICKERS).',
editorId = 1126,
editdate = getdate()
where
disclosureid = 5

Update securitycheckboxtypes
set disclosure = 'In the past twelve (12) months, Bernstein or an affiliate received compensation for investment banking services from: (TICKERS).',
editorId = 1126,
editdate = getdate()
where
disclosureid = 6

Update securitycheckboxtypes
set disclosure = 'In the next three (3) months, Bernstein or an affiliate expects to receive or intends to seek compensation for investment banking services from: (TICKERS).',
editorId = 1126,
editdate = getdate()
where
disclosureid = 7
go
