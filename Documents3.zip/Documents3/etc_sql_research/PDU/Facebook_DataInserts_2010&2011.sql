--FaceBookTitles
--01/06/2010
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Manager',9999999,100,'Jan  6 2010 10:52AM'
--10/04/2010
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Strategy Analyst',9999999,100,'Oct  4 2010 11:41AM'
--05/26/2011
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Head of Singapore Sales',999999,100,'May 26 2011  3:13PM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Head of Asian Trading and Salestrading',999999,100,'May 26 2011  3:13PM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'COO & Head of Legal',999999,100,'May 26 2011  3:13PM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Head of Asian Sales',999999,100,'May 26 2011  3:13PM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Program Trader',999999,100,'May 26 2011  3:14PM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Middle Office Analyst',999999,100,'May 26 2011  3:14PM'
--06/22/2011
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Director of Corporate Access',999999,100,'Jun 22 2011 11:02AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Corporate Access & Marketing Events Associate',999999,100,'Jun 22 2011 11:02AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Co-Head of NY Metro Sales',999999,100,'Jun 22 2011 11:02AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Senior Marketing Associate',999999,100,'Jun 22 2011 11:03AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Co-Head of US Equities',999999,100,'Jun 22 2011 11:03AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Financial Controller',999999,100,'Jun 22 2011 11:03AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Equity Capital Markets Associate',999999,100,'Jun 22 2011 11:04AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Business Analytics Manager',999999,100,'Jun 22 2011 11:04AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Business Analyst',999999,100,'Jun 22 2011 11:04AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Project Manager',999999,100,'Jun 22 2011 11:04AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Chief Market Strategist',999999,100,'Jun 22 2011 11:05AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Director of Corporate Access & Marketing Events',999999,100,'Jun 22 2011 11:05AM'
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Head',999999,100,'Jun 22 2011 11:05AM'
--11/02/2011
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Director, Asia Product Manager',999999,100,'Nov  2 2011 10:30AM'

--FaceBookLocations
--02/25/2010
Insert Into FaceBookLocations(Location,EditorId,EditDate) Select 'HongKong',34,'Feb 25 2010  4:01PM'
--05/26/2011
Insert Into FaceBookLocations(Location,EditorId,EditDate) Select 'Singapore',34,'May 26 2011  3:15PM'

--FaceBookDepts
--02/25/2010
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Instl Rsrch - HongKong',34,'Feb 25 2010  4:05PM'
--05/26/2011
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Instl Sales � Singapore',34,'May 26 2011  3:11PM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Sales Trading � HK',34,'May 26 2011  3:11PM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Legal and Compliance � HK',34,'May 26 2011  3:11PM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Instl Rsrch � Singapore',34,'May 26 2011  3:11PM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Instl Sales � HK',34,'May 26 2011  3:11PM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Program Trading � HK',34,'May 26 2011  3:12PM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Brokerage Ops � HK',34,'May 26 2011  3:12PM'
--07/15/2011
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Instl Rsrch Services - ECM',34,'Jul 15 2011 11:39AM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'North American Portfolio Trading',34,'Jul 15 2011 11:39AM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Quantitative & Algorithmic Trading',34,'Jul 15 2011 11:39AM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Electronic Trading Sales',34,'Jul 15 2011 11:39AM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Electronic Trading',34,'Jul 15 2011 11:39AM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Front-Office Software Development',34,'Jul 15 2011 11:39AM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Portfolio Trading Strategy',34,'Jul 15 2011 11:39AM'
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'International Portfolio Trading',34,'Jul 15 2011 11:39AM'
--11/02/2011
Insert Into FaceBookDepts(Dept,EditorId,EditDate) Select 'Instl Sales � NY',34,'Nov  2 2011 10:32AM'