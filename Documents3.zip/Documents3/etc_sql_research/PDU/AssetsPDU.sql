-- AssetsPDU.sql
-- 06/25/2020

-- Declarative administration (no hard-coding)

select * from AssetTypes

-- PRD
insert AssetTypes select 'Deck',                     'PDF',   'NETAPP', 'application/pdf', 1
insert AssetTypes select 'Industry Model',           'EXCEL', 'NETAPP', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.template,application/vnd.ms-excel.sheet.macroEnabled.12,application/vnd.ms-excel.template.macroEnabled.12,application/vnd.ms-excel.addin.macroEnabled.12,application/vnd.ms-excel.sheet.binary.macroEnabled.12', 2
insert AssetTypes select 'Industry Model - Premium', 'EXCEL', 'NETAPP', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.template,application/vnd.ms-excel.sheet.macroEnabled.12,application/vnd.ms-excel.template.macroEnabled.12,application/vnd.ms-excel.addin.macroEnabled.12,application/vnd.ms-excel.sheet.binary.macroEnabled.12', 3


-- DEV
-- For BRIGHTCOVE the MimeType is NULL

-- insert AssetTypes select 'Video',           'VIDEO', 'BRIGHTCOVE', NULL, 4
-- insert AssetTypes select 'Video - Webinar', 'VIDEO', 'BRIGHTCOVE', NULL, 5
-- insert AssetTypes select 'Podcast',         'AUDIO', 'BRIGHTCOVE', NULL, 6
-- insert AssetTypes select 'Tear Sheet',      'PDF',    'NETAPP',   'application/pdf', 7
