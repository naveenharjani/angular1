-- DistributionPDU.sql

select * from DistributionSites where Active = -1 order by PdfLock, Site

-- 05/20/2014
-- update DistributionSites set PdfLock = 'N' where SiteId = 3 -- Bloomberg (SANB)

-- 06/04/2014
-- update DistributionSites set PdfLock = 'N' where SiteId = 11 -- CapitalIQ
-- update DistributionSites set PdfLock = 'N' where SiteId = 15 -- Bloomberg Daiwa
-- update DistributionSites set PdfLock = 'N' where SiteId = 10 -- Assentor

-- 06/11/2014
-- update DistributionSites set PdfLock = 'N' where SiteId = 12 -- FactSet
-- update DistributionSites set PdfLock = 'N' where SiteId = 7 -- EBSCO Publishing -- Agreement terminates 10/18/2014

-- *** DISTRIBUTION ADAPTERS

select * from DistributionAdapters

/*
Bernstein.IRS.Rixml.Research
Bernstein.IRS.VisibleAlpha.Model
Bernstein.IRS.RestrictedList.Research
*/

if not exists(select * from DistributionAdapters where Adapter = 'VAModels')
begin
  insert into DistributionAdapters(AdapterId, Adapter, ProgId, EditorId, EditDate)
  select 12,'VAModels','Bernstein.IRS.VisibleAlpha.Model',1,GETDATE()
end

if not exists(select * from DistributionAdapters where Adapter = 'RestrictedList')
begin
  insert into DistributionAdapters(AdapterId, Adapter, ProgId, EditorId, EditDate)
  select 13,'RestrictedList','Bernstein.IRS.RestrictedList.Research',1,GETDATE()
end

if not exists(select * from DistributionAdapters where Adapter = 'RIXML24')
begin
  insert into DistributionAdapters(AdapterId, Adapter, ProgId, EditorId, EditDate)
  select 14,'RIXML24','Bernstein.IRS.RIXML24.Research',1,GETDATE()
end

/*

Archive of DistributionAdapters table as of 07/17/2018
AdapterID	Adapter			ProgID							EditorID	EditDate
1			ResearchDirect	DEResearchDirect.CResearch		1			2009-09-03 11:55:41.850
2			Multex			DEMultex.CResearch				1			2009-09-03 11:55:41.850
3			Bloomberg		DEBloomberg.CResearch			1			2009-09-03 11:55:41.850
4			RIXML			DERIXML10.CResearch				1			2009-09-03 11:55:41.850
5			DMZ				DEDMZ.CResearch					1			2009-09-03 11:55:41.850
6			EBSCO			DEEBSCO.CResearch				1			2009-09-03 11:55:41.850
7			TFNSelect		DETFNSelect.CResearch			1			2009-09-03 11:55:41.850
8			RIXML21			DERIXML21.CResearch				1			2009-09-03 11:55:41.850
9			Assentor		Bernstein.IRS.Assentor.Research	1			2009-09-03 11:55:41.850
10			RIXML22			Bernstein.IRS.RIXML22.Research	1			2009-09-03 11:55:41.850
11			Symphony		Bernstein.IRS.Symphony.Research	1			2018-01-30 02:53:25.883
12			VAModels		Bernstein.IRS.VisibleAlpha.Model	1		2018-05-08 10:48:42.200
13			RestrictedList	Bernstein.IRS.RestrictedList.Research	1	2018-05-21 14:33:48.170
14			RIXML24			Bernstein.IRS.RIXML24.Research	1			2018-06-01 11:08:33.203

*/

-- *** DISTRIBUTION ENTITLEMENTS

select * from DistributionEntitlements order by SiteId, ProductGroupId

select
  DS.Site,
  PG.ProductGroupName 'Product Group',
  DE.RixmlEntitlement,
  DE.*
from DistributionEntitlements DE
join DistributionSites DS on DS.SiteId = DE.SiteId
left join ProductGroups PG on PG.ProductGroupId = DE.ProductGroupId
where DS.Active = -1
order by SiteId, ProductGroupId

-- spGetPropertiesXML_RX2 @PubNo, @SiteId
-- spGetPropertiesXML_RX2 163609, 3

/*

--CC# - 270786
--01/18/2018 New entitlement code QUANT created
--01/30/2018 New entitlement code MACRO created
--RIXMLEntitlement column removed from subscriptions table new All row added to DistributionEntitlements table

-- delete from DistributionEntitlements where EntitlementId in (62, 63, 64)

-- IX_DistributionEntitlements_SiteId_ProductGroupId

--Thomson Reuters
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 9,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 9,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 9,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 9,15,'QUANT'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 9,16,'MACRO'
go

--Blue Matrix
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 20,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 20,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 20,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 20,15,'QUANT'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 20,16,'MACRO'
go

-- Visible Alpha
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 21,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 21,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 21,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 21,15,'QUANT'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 21,16,'MACRO'
go

-- RSRCHXchange
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 22,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 22,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 22,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 22,15,'QUANT'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 22,16,'MACRO'
go

-- Red Deer
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 23,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 23,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 23,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 23,15,'QUANT'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 23,16,'MACRO'
go

-- American Century
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 24,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 24,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 24,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 24,15,'QUANT'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 24,16,'MACRO'
go

--Poulate "All Research" rows for all portals
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 3,null,'BLOOMBERG_CLASS=0051'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 9,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 11,null,'CIQ1'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 12,null,'FACTSET1'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 13,null,'TMC1'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 15,null,'BLOOMBERG_CLASS=0051'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 20,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 21,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 22,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 23,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 24,null,'ALL'
go

--05/23/2018
-- BlueMountain
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 26,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 26,1,'US'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 26,2,'PE'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 26,4,'AP'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 26,15,'QUANT'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 26,16,'MACRO'
go

--01/07/2020
--Bloomberg (Add QUANT,MACRO)
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 3,15,'BLOOMBERG_CLASS=0055'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 3,16,'BLOOMBERG_CLASS=0056'

--Factset (Add ALL,QUANT,MACRO)
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 12,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 12,15,'QUANT'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 12,16,'MACRO'

--update Factset RixmlEntitlements (work with Factset to update the codes on their end too)
update DistributionEntitlements set RixmlEntitlement = 'US' where SiteId = 12 and ProductGroupId = 1
update DistributionEntitlements set RixmlEntitlement = 'PE' where SiteId = 12 and ProductGroupId = 2
update DistributionEntitlements set RixmlEntitlement = 'AP' where SiteId = 12 and ProductGroupId = 4

--CapitalIQ
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 11,null,'ALL'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 11,15,'QUANT'
insert into DistributionEntitlements(SiteId,  ProductGroupId, RixmlEntitlement) select 11,16,'MACRO'

--update CapitalIQ RixmlEntitlements (work with Factset to update the codes on their end too)
update DistributionEntitlements set RixmlEntitlement = 'US' where SiteId = 11 and ProductGroupId = 1
update DistributionEntitlements set RixmlEntitlement = 'PE' where SiteId = 11 and ProductGroupId = 2
update DistributionEntitlements set RixmlEntitlement = 'AP' where SiteId = 11 and ProductGroupId = 4

--01/13/2020
--Subsequent to an email from Alex Torns (bloomberg contact), Quant and Macro entitlement codes updated to new numbers for bloomberg

update DistributionEntitlements set RixmlEntitlement = 'BLOOMBERG_CLASS=0058' where RixmlEntitlement = 'BLOOMBERG_CLASS=0056' --MACRO
update DistributionEntitlements set RixmlEntitlement = 'BLOOMBERG_CLASS=0059' where RixmlEntitlement = 'BLOOMBERG_CLASS=0055' --QUANT

*/

--11/12/2020
--Old ftp host sb_6872@ftp.reutersresearch.com
--As per email from ThomsonReuters changing the ftphost to reflect their new branding to REFINITIV

update DistributionSites
set FtpLogon = 'sb_6872@rscftp.research.refinitiv.com'
where Site = 'Thomson Reuters'


--01/06/2021
--As per email from Bloomberg
--BLOOMBERG_CLASS=0051 (All Research - Equity) is being removed as this is causing two NSN's on their end which
--creates entitlements issues for people who are not entitled to this class.
delete from DistributionEntitlements
where siteid = 3 and Productgroupid is null

--11/02/2021
insert into ModelDistributionQueue(ModelId,SiteId,Operation,Queued,Scheduled)
select 17907,32,'C',getdate(),getdate()