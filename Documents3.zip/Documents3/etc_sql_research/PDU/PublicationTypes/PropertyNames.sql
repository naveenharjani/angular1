--08/10/2017
--Added new property 'Thematic Tag'

insert into PropertyNames (PropId,PropName,ControlTypeCode,PropertyLabel,PropertyNotes,IsEditable)
select 41,'Thematictag','TXTB','Thematic Tag',NULL,'F'

go
insert into PropertySets(PublicationTypeID,PropID,SeqNo,Instancing,Required)
select 1,41,31,0,0
go

--07/30/2019
update PropertyNames
set PropName = 'ThematicTag'
where
PropName = 'Thematictag'