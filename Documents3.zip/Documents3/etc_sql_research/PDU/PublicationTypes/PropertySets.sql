-- Video_PropertySet.sql

/*

Brightcove Video Cloud - Id is 13 characters, e.g. 2088225478001
-> Overload FileName with Brightcove id

sp_help Publications
sp_help Documents

Alter column Publications.FileName    from varchar(12) to varchar(30)
Alter column PublicationsLog.FileName from varchar(12) to varchar(30)
Alter column Documents.FileName       from varchar(13) to varchar(30)

*/

USE Research
GO

-- ***
-- *** DEFINE "Video" Publication Type
-- ***

-- select * from PublicationTypes order by PublicationTypeId
-- delete from PropertySets where PublicationTypeId = 10
-- delete from PublicationTypes where PublicationTypeId = 10

insert into PublicationTypes
(
  PublicationTypeId,
  PublicationType,
  SeqNo,
  MeetingEligible,
  SummaryEligible,
  DistributionEligible,
  IsRepl,
  IsResearch,
  SalesAlertEligible,
  LinksEligible
)
select
  PublicationTypeId    = 10,       -- Not identity column.  Unique constraint.
  PublicationType      = 'Video',
  SeqNo                = 10,
  MeetingEligible      = 'N',
  SummaryEligible      = 'N',
  DistributionEligible = 'N',
  IsRepl               = 'Y',
  IsResearch           = 'Y',
  SalesAlertEligible   = 'N',
  LinksEligible        = 'Y'  -- DEV ONLY

-- update PublicationTypes set IsRepl     = 'Y' where PublicationTypeId = 10
-- update PublicationTypes set IsResearch = 'Y' where PublicationTypeId = 10

-- ***
-- *** DEFINE "Video" Property Set
-- ***

select * from PropertySets order by PublicationTypeId, SeqNo
-- delete from PropertySets where PublicationTypeId = 10

-- IX_PropertySets_Property
-- Video DEV 01/15/2013.  
-- Video QA  01/??/2013.  
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (10, 11,  1, -1, -1) -- Industry
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (10,  5,  2, -1, -1) -- Author
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (10, 13,  3, -1,  0) -- Security
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (10, 24,  4,  0,  0) -- BulletA
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (10, 25,  5,  0,  0) -- BulletB
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (10, 26,  6,  0,  0) -- BulletC

--09/10/2014 Added Keywords property(optional) to video type. This is to enable display of videos on br.com best of bernstein page.
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (10, 9,  7,  0,  0) -- Keywords

--11/18/2014
--Add property 'Ticker' (which was missing) to publication type 'Primer'
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 13  , 7  , -1  , -1 ) -- Primer        Category
