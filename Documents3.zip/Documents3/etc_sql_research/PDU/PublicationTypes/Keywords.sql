-- Keywords.sql

USE Research
GO

-- 07/17/2014
IF NOT EXISTS(SELECT * FROM Keywords WHERE Keyword = 'Featured Video')
BEGIN
  INSERT INTO Keywords(KeywordID, Keyword)
  SELECT 19, 'Featured Video'
END
GO

-- 11/14/2018
IF NOT EXISTS(SELECT * FROM Keywords WHERE Keyword = 'Greenbook')
BEGIN
  INSERT INTO Keywords(KeywordID, Keyword)
  SELECT 21,'Greenbook'
END
GO

-- 07/02/2019
IF NOT EXISTS(SELECT * FROM Keywords WHERE Keyword = 'Blast')
BEGIN
  INSERT INTO Keywords(KeywordId, Keyword)
  SELECT 22, 'Blast'
END
GO

IF NOT EXISTS(SELECT * FROM Keywords WHERE Keyword = 'China A-share')
BEGIN
  INSERT INTO Keywords(KeywordId, Keyword)
  SELECT 23, 'China A-share'
END
GO

--09/11/2019
IF NOT EXISTS(SELECT * FROM Keywords WHERE Keyword = 'Alphalytics')
BEGIN
  INSERT INTO Keywords(KeywordId, Keyword)
  SELECT 24, 'Alphalytics'
END
GO

select * from Keywords order by KeywordId
