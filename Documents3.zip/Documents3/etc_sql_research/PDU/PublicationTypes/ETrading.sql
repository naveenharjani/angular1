-- CC_ETrading.sql

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

--Step1: Create sector "Electronic Trading" using sector admin tool and mark as non-research sector.
--Step2: Create industry "Electronic Trading", map to "Electronic Trading" sector using industry admin tool and mark as non-research industry.
--Step3: Add "Electronic Trading" industry to U.S.Research, Pan-Euro Research & Asia-Pac Research product groups using product group admin tool.
--Step4: Create author "Natalia Bershova" using author admin tool and mark her as active & non-research author.
--Step5: Create coverage for the above two using coverage admin tool.
--Step6 & Step7: 
--       Execute sql below to create new publication type "Etrading".
--       Execute sql below to create property sets for the new publication type.


IF NOT EXISTS(SELECT * FROM Publicationtypes WHERE PublicationType = 'ETrading')
BEGIN
  INSERT INTO Publicationtypes(PublicationTypeID,PublicationType,SeqNo,MeetingEligible,SummaryEligible,DistributionEligible,IsRepl,IsResearch,SalesAlertEligible,LinksEligible)
  SELECT 12,'ETrading',12,'Y','Y','N','Y','N','N','Y'
END
GO
DELETE FROM PropertySets WHERE PublicationTypeId = 12
GO

IF NOT EXISTS(SELECT * FROM SYS.INDEXES WHERE NAME = 'IX_PropertySets_Property' AND OBJECT_ID = OBJECT_ID('PropertySets'))
ALTER TABLE [dbo].[PropertySets] ADD  CONSTRAINT [IX_PropertySets_Property] UNIQUE NONCLUSTERED 
(
	[PublicationTypeId],[PropId] ASC
)
GO

insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 8  , 4  , 0  , -1 ) -- Research Call        Category
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 11 , 5  , -1 , -1 ) -- Research Call        Industry
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 5  , 6  , -1 , -1 ) -- Research Call        Author
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 24 , 9  , 0  , 0  ) -- Research Call        BulletA
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 25 , 10 , 0  , 0  ) -- Research Call        BulletB
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 26 , 11 , 0  , 0  ) -- Research Call        BulletC
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 9  , 12 , -1 , 0  ) -- Research Call        Keywords ???
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 19 , 13 , 0  , 0  ) -- Research Call        RPTools Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 18 , 14 , 0  , 0  ) -- Research Call        Template Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 27 , 15 , 0  , 0  ) -- Research Call        Disclosure Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 20 , 16 , 0  , 0  ) -- Research Call        MSXML Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 21 , 17 , 0  , 0  ) -- Research Call        OS Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 22 , 18 , 0  , 0  ) -- Research Call        Office Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 23 , 19 , 0  , 0  ) -- Research Call        Computer Name
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 28 , 20 , 0  , 0  ) -- Research Call        Revision Number
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 31 , 23 , 0  , 0  ) -- Research Call        Pages
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (12  , 33 , 25 , 0  , 0  ) -- Research Call        Document Version
GO
