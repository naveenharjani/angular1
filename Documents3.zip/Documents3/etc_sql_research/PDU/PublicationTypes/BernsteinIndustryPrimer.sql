-- CC_BernsteinIndustryPrimer.sql
-- 02/03/2014

USE [Research]
GO

-- Set session settings to required values
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

-- 1. Execute sql below to create new publication type "Primer".
-- 2. Execute sql below to create property sets for the new publication type.


IF NOT EXISTS(SELECT * FROM Publicationtypes WHERE PublicationType = 'Primer')
BEGIN
  INSERT INTO Publicationtypes(PublicationTypeID,PublicationType,SeqNo,MeetingEligible,SummaryEligible,DistributionEligible,IsRepl,IsResearch,SalesAlertEligible)
  SELECT 11,'Primer',11,'Y','Y','N','Y','Y','Y'
END
GO

DELETE FROM PropertySets WHERE PublicationTypeId = 11
GO

IF NOT EXISTS(SELECT * FROM SYS.INDEXES WHERE NAME = 'IX_PropertySets_Property' AND OBJECT_ID = OBJECT_ID('PropertySets'))
ALTER TABLE [dbo].[PropertySets] ADD  CONSTRAINT [IX_PropertySets_Property] UNIQUE NONCLUSTERED 
(
	[PublicationTypeId],[PropId] ASC
)
GO

insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 8  , 4  , 0  , -1 ) -- Primer        Category
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 11 , 5  , -1 , -1 ) -- Primer        Industry
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 5  , 6  , -1 , -1 ) -- Primer        Author
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 24 , 9  , 0  , 0  ) -- Primer        BulletA
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 25 , 10 , 0  , 0  ) -- Primer        BulletB
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 26 , 11 , 0  , 0  ) -- Primer        BulletC
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 9  , 12 , -1 , 0  ) -- Primer        Keywords ???
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 19 , 13 , 0  , 0  ) -- Primer        RPTools Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 18 , 14 , 0  , 0  ) -- Primer        Template Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 27 , 15 , 0  , 0  ) -- Primer        Disclosure Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 20 , 16 , 0  , 0  ) -- Primer        MSXML Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 21 , 17 , 0  , 0  ) -- Primer        OS Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 22 , 18 , 0  , 0  ) -- Primer        Office Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 23 , 19 , 0  , 0  ) -- Primer        Computer Name
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 28 , 20 , 0  , 0  ) -- Primer        Revision Number
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 31 , 23 , 0  , 0  ) -- Primer        Pages
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 33 , 25 , 0  , 0  ) -- Primer        Document Version
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 32 , 26 , 0  , 0  ) -- Primer        InvestorTheme
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 34 , 27 , 0  , 0  ) -- Primer        BlastList
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 35 , 28 , 0  , 0  ) -- Primer        BlastTime
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 36 , 29 , 0  , 0  ) -- Primer        ReBlast
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 37 , 30 , 0  , 0  ) -- Primer        ExcludePressIndustry
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 38 , 31 , 0  , 0  ) -- Primer        BlastUser
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 39 , 32 , 0  , 0  ) -- Primer        ImmediateBlast
insert into PropertySets (PublicationTypeID, PropID, SeqNo, Instancing, Required) values (11  , 40 , 33 , 0  , 0  ) -- Primer        CCAuthors
GO

