--PublicationTypesPDU.sql

use Research
go

--07/26/2018 "Comment"
insert into PublicationTypes
(
	PublicationTypeId,
	PublicationType,
	SeqNo,MeetingEligible,
	SummaryEligible,
	DistributionEligible,
	IsRepl,
	IsResearch,
	SalesAlertEligible
)
select
	PublicationTypeId    = 12,       -- Not identity column.  Unique constraint.
	PublicationType      = 'Comment',
	SeqNo                = 12,
	MeetingEligible      = 'Y',
	SummaryEligible      = 'N',
	DistributionEligible = 'N',
	IsRepl               = 'Y',
	IsResearch           = 'Y',
	SalesAlertEligible   = 'Y'

insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12, 11,  1, -1, -1) -- Industry
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12,  5,  2, -1, -1) -- Author
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12, 13,  3, -1,  0) -- Security
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12,  9,  4,  0,  0) -- Keywords
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12, 34,  5, -1,  0) -- BlastList
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12, 35,  6,  0,  0) -- BlastTime
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12, 36,  7,  0,  0) -- ReBlast
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12, 37,  8,  0,  0) -- ExcludePressIndustry
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12, 38,  9,  0,  0) -- BlastUser
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12, 39, 10,  0,  0) -- ImmediateBlast
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (12, 40, 11,  0,  0) -- CCAuthors

select * from PublicationTypes

select * from PropertySets where publicationtypeid = 12

--01/10/2019
insert into PublicationTypes
(
	PublicationTypeId,
	PublicationType,
	SeqNo,MeetingEligible,
	SummaryEligible,
	DistributionEligible,
	IsRepl,
	IsResearch,
	SalesAlertEligible
)
select
	PublicationTypeId    = 13,       -- Not identity column.  Unique constraint.
	PublicationType      = 'Podcast',
	SeqNo                = 13,
	MeetingEligible      = 'Y',
	SummaryEligible      = 'N',
	DistributionEligible = 'N',
	IsRepl               = 'Y',
	IsResearch           = 'Y',
	SalesAlertEligible   = 'Y'

insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (13, 11,  1, -1, -1) -- Industry
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (13,  5,  2, -1, -1) -- Author
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (13, 13,  3, -1,  0) -- Security
insert into PropertySets (PublicationTypeId, PropId, SeqNo, Instancing, Required) values (13,  9,  4,  0,  0) -- Keywords

