-- CC_SearchCleanup.sql.sql
-- 07/01/2019

/*

*/

use Research
go

-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO


-- DELETE PublicationType 'Primer' ('Primer' is a keyword)

--List of all reports with type = Primer and do not have a keyword Primer
select PubNo from Publications where Type = 'Primer'
and PubNo not in (select PubNo from Properties where PropId = 9 and PropValue = 'Primer')
go

select * from PublicationTypes

select * from PropertySets

-- update Publications set Type = 'Research Call' where Type = 'Primer'

-- delete from DistributionSubscriptions where PublicationTypeId = 11 -- Primer

-- delete from PropertySets where PublicationTypeId = 11 -- Primer

-- delete from PublicationTypes where PublicationType = 'Primer'


-- DELETE Keyword 'Featured Video' ('Video' is a PublicationType

select PubNo from Properties PR where PropValue = 'Featured Video'

delete from Keywords where KeywordId = 19

-- Keywords

-- delete
-- select * 
from Properties where PropId = 9 and ltrim(rtrim(PropValue)) = '' -- Keywords 

-- delete
-- select * 
from Properties where PropId = 9 and PropValue = '--None--'

-- delete
-- select * 
from Properties where PropId = 9 and PropValue = 'Research Call'

-- delete PR
-- select PU.Date, PU.Type, PR.* 
from Properties PR join Publications PU on PU.PubNo = PR.PubNo
where PropId = 9 and PropValue not in (select Keyword from Keywords)

select * from Properties where PropId = 9 and PubNo in
(select PubNo from Properties where PropId = 9 and PropValue = 'The Long View')

-- update Properties set PropValue = 'Long View' where PropId = 9 and PropValue = 'The Long View'

select * from Properties where PropId = 9 and PubNo in
(select PubNo from Properties where PropId = 9 and PropValue = 'The Best of Bernstein')

-- update Properties set PropValue = 'Best of Bernstein' where PropId = 9 and PropValue = 'The Best of Bernstein'

-- Thematic Tag

-- delete
-- select * 
from Properties where PropId = 41 and ltrim(rtrim(PropValue)) = '' -- Thematictag
