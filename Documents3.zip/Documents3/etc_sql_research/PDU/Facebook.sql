-- Facebook.sql

select top 50 * from FacebookPersons order by EditDate desc -- UI
select top 50 * from FacebookTitles order by EditDate desc -- PDU

--04/13/2012
Update FaceBookLocations Set Location = 'London-Berkeley' Where Location = 'London-Berkley'
--04/12/2012
--FacebookLocations
Insert Into FaceBookLocations(Location, EditorId, EditDate) Select 'London-Berkley',1126,getdate()

--FacebookTitles
--SortId column is obsolete. 
--It was introducted initially for crystal report display order
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Global Head of Sales',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Sector Specialist',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Sector Trader',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Sales & Trading Associate',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Sr. Application Support Specialist',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Electronic Sales',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Quantitative Developer',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Sr. Software Developer',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Co-Head of European Trading',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Head of Asia Salestrading',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Head of Asia Program Trading',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Global Head of Trading',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Global Head of Electronic Trading',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Derivatives Trader',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Head of Derivatives Trading',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Head of Sector Trading & Sector Specialists',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Head of US Salestrading',999999,1126,getdate()
Insert Into FaceBookTitles(Title,SortId,EditorId,EditDate) Select 'Head of US Portfolio Strategy',999999,1126,getdate()

--FacebookDepts
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Inst. Trading - Asia Electronic Trading',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Inst. Trading - Asia Salestrading',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Inst. Trading - Derivatives',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Inst. Trading - Sector Specialist',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Inst. Trading - Sector Trading',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Inst. Trading - UK Electronic Trading',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Inst. Trading - UK Salestrading',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Inst. Trading - US Electronic Trading',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Inst. Trading - US Salestrading',1126,getdate()

--06/20/2012
insert into facebooktitles(title,sortid,editorid,editdate) select 'Head of Derivatives Sales & Trading',999999,1126,getdate()
insert into facebooktitles(title,sortid,editorid,editdate) select 'Derivatives Salestrader',999999,1126,getdate()

--04/13/2018
/*
Email from Laura Cantrell dated 04/13/2018
With all the recent management changes globally, we need some titles created in the beehive�s Facebook. Once these are created, I�ll apply them to the individual profiles in the system. Let me know if you need anything else, thanks, Laura 

Beth Ann Day Global Associate Director of Research & CTO
Bob Brackett Deputy Director of US Research 
Michael Parker Director of Asian Research
Natalie Cheung Director of Asian Research Associate Programs 
Sebastian Lewis Director of European Research
Alexandra Perricone European Associate Director of Research & CTO
Marie Freier UK Head of Sales
Raj Samarasinhe Head of Asian Sales for Europe
*/

insert into FaceBookTitles(Title,SortId,EditorId,EditDate)
select 'Global Associate Director of Research & CTO',999999,1126,getdate()

insert into FaceBookTitles(Title,SortId,EditorId,EditDate)
select 'Deputy Director of US Research ',999999,1126,getdate()

insert into FaceBookTitles(Title,SortId,EditorId,EditDate)
select 'Director of Asian Research',999999,1126,getdate()

insert into FaceBookTitles(Title,SortId,EditorId,EditDate)
select 'Director of Asian Research Associate Programs ',999999,1126,getdate()

insert into FaceBookTitles(Title,SortId,EditorId,EditDate)
select 'Director of European Research',999999,1126,getdate()

insert into FaceBookTitles(Title,SortId,EditorId,EditDate)
select 'European Associate Director of Research & CTO',999999,1126,getdate()

insert into FaceBookTitles(Title,SortId,EditorId,EditDate)
select 'UK Head of Sales',999999,1126,getdate()

insert into FaceBookTitles(Title,SortId,EditorId,EditDate)
select 'Head of Asian Sales for Europe',999999,1126,getdate()

--04/04/2019
insert into FacebookLocations
select 'Mumbai',1126,getdate()

--04/02/2020
insert into FacebookTitles(Title,SortId,EditorId,EditDate)
select 'Global Head of Investor Access and Alternative Content',999999,1126,getdate() 

insert into FacebookTitles(Title,SortId,EditorId,EditDate)
select 'Co-Head of European Sales',999999,1126,getdate() 

--Add autonomous departments
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Instl Rsrch � Autonomous U.S.',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Instl Rsrch � Autonomous Europe',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Instl Sales � Autonomous U.S.',1126,getdate()
Insert Into FacebookDepts(Dept,EditorId,EditDate) Select 'Instl Rsrch � Autonomous Europe',1126,getdate()

--06/17/2020
insert into FacebookTitles(Title,SortId,EditorId,EditDate)
select 'Sales Associate',999999,1126,getdate() 

