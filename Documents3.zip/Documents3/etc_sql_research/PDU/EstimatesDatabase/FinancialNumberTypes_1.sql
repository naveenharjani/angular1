-- Admin.sql
-- 

-- FinancialPeriods
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0','Y',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1','Y',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2','Y',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY3','Y',1126,GETDATE())
--NumberUnits
insert into NumberUnits(NumberUnitCode,NumberUnitLabel,UnitMultiplier,EditorId,EditDate)
select 'K','Thousands (K)',1000,1126,getdate()
insert into NumberUnits(NumberUnitCode,NumberUnitLabel,UnitMultiplier,EditorId,EditDate)
select 'M','Millions (M)',1000000,1126,getdate()
insert into NumberUnits(NumberUnitCode,NumberUnitLabel,UnitMultiplier,EditorId,EditDate)
select 'B','Billions (B)',1000000000,1126,getdate()
insert into NumberUnits(NumberUnitCode,NumberUnitLabel,UnitMultiplier,EditorId,EditDate)
select 'T','Trillions (T)',1000000000000,1126,getdate()

/*

insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_Q1','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_Q2','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_Q3','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_Q4','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_Q1','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_Q2','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_Q3','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_Q4','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_Q1','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_Q2','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_Q3','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_Q4','Q',1126,GETDATE())

insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_S1','S',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_S2','S',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_S1','S',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_S2','S',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_S1','S',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_S2','S',1126,GETDATE())

*/

-- FinancialNumberTypes

/*

select * from FinancialNumberTypes

sp_helptext spSaveFinancialNumberTypes

select * from FinancialNumberTypes where financialnumbertypecat = 'A' order by financialnumbertypecatord

*/

--Analyst data types
exec spSaveFinancialNumberTypes 'A', 'RATING','Rating',1,1129
exec spSaveFinancialNumberTypes 'A', 'TARGETPRICE','Target Price',2,1129

--Estimates types
exec spSaveFinancialNumberTypes 'E', 'EPSRPT', 'EPS Reported', 1,1129
exec spSaveFinancialNumberTypes 'E', 'EPSADJ', 'EPS Adjusted',2,1129

exec spSaveFinancialNumberTypes 'E', 'SALES', 'Revenues',3,1129
exec spSaveFinancialNumberTypes 'E', 'EBIT', 'EBIT',4,1129
exec spSaveFinancialNumberTypes 'E', 'EBITDA', 'EBITDA',5,1129
exec spSaveFinancialNumberTypes 'E', 'EBITA', 'EBITA',6,1129
exec spSaveFinancialNumberTypes 'E', 'EBT', 'Pre-Tax Earnings',7,1129
exec spSaveFinancialNumberTypes 'E', 'NI', 'Net Earnings',8,1129
exec spSaveFinancialNumberTypes 'E', 'OCF', 'CFO',9,1129
exec spSaveFinancialNumberTypes 'E', 'FCF', 'FCF',10,1129
exec spSaveFinancialNumberTypes 'E', 'DCF', 'DCF',11,1129
exec spSaveFinancialNumberTypes 'E', 'BV', 'Book Value',12,1129
exec spSaveFinancialNumberTypes 'E', 'ROIC', 'ROIC',13,1129
exec spSaveFinancialNumberTypes 'E', 'ROE', 'ROE',14,1129
exec spSaveFinancialNumberTypes 'E', 'ROCE', 'ROCE',15,1129
exec spSaveFinancialNumberTypes 'E', 'CAPEX', 'CapEx',16,1129
exec spSaveFinancialNumberTypes 'E', 'DIVPAYOUTRATIO', 'Dividend Payout Ratio',17,1129
exec spSaveFinancialNumberTypes 'E', 'CE', 'CE',19,1129

-- Estimates - Per Share Data Items
exec spSaveFinancialNumberTypes 'E', 'SALESPS', 'Revenue/Share',20,1129
exec spSaveFinancialNumberTypes 'E', 'OCFPS', 'CFO/Share',21,1129
exec spSaveFinancialNumberTypes 'E', 'BVPS', 'BV/Share',22,1129
exec spSaveFinancialNumberTypes 'E', 'TBVPS', 'TB/Share',23,1129
exec spSaveFinancialNumberTypes 'E', 'DIVPS', 'Dividend/Share',24,1129
exec spSaveFinancialNumberTypes 'E', 'FCFPS', 'FCF/Share',25,1129
exec spSaveFinancialNumberTypes 'E', 'EPSGROWTH', 'EPS Growth/Share',26,1129

-- Colin's additions
exec spSaveFinancialNumberTypes 'E','NII','Net Interest Income', 3, 1129
exec spSaveFinancialNumberTypes 'E','NONINTINC','Non-Interest Income',4, 1129
exec spSaveFinancialNumberTypes 'E','NETWRITTENPREM','Net Written Premium',5, 1129
exec spSaveFinancialNumberTypes 'E','NETEARNPREM','Net Earned Premium',6, 1129
exec spSaveFinancialNumberTypes 'E','COGS','Cost of Goods Sold',8, 1129
exec spSaveFinancialNumberTypes 'E','GROSSPROFIT','Gross Profit',9, 1129
exec spSaveFinancialNumberTypes 'E','EXP','Total Expenses',10, 1129
exec spSaveFinancialNumberTypes 'E','PPNR','Pre-Provision Net Revenue',11, 1129
exec spSaveFinancialNumberTypes 'E','PROV','Total Provision',12, 1129
exec spSaveFinancialNumberTypes 'E','NETLOSS','Net Losses',13, 1129
exec spSaveFinancialNumberTypes 'E','UNDERWRITEINC','Underwriting Income',14, 1129
exec spSaveFinancialNumberTypes 'E','NETINVESTINC','Net Investment Income',15, 1129
exec spSaveFinancialNumberTypes 'E','OPEARN','Operating Earnings',16, 1129
exec spSaveFinancialNumberTypes 'E','PROFBEFOREITEMS','Net Profit before Non-Recurring Items',21,1129
exec spSaveFinancialNumberTypes 'E','GM','Gross Margin',23,1129
exec spSaveFinancialNumberTypes 'E','EBITDAMARGIN','EBITDA Margin',24,1129
exec spSaveFinancialNumberTypes 'E','OM','Operating Margin',25,1129
exec spSaveFinancialNumberTypes 'E','NETMARGIN','Net Income Margin',26,1129
exec spSaveFinancialNumberTypes 'E','CET1','T1 Common Equity',31,1129
exec spSaveFinancialNumberTypes 'E','NIM','Net Interest Margin',32,1129
exec spSaveFinancialNumberTypes 'E','LOANGROW','Loan Growth',33,1129
exec spSaveFinancialNumberTypes 'E','DEPOSITGROW','Deposit Growth',34,1129
exec spSaveFinancialNumberTypes 'E','NETCHARGEOFF','Net Charge-off Rate',35,1129
exec spSaveFinancialNumberTypes 'E','COMBINEDRATIO','Combined Ratio',36,1129
exec spSaveFinancialNumberTypes 'E','ROTA','ROTA',39,1129
exec spSaveFinancialNumberTypes 'E','ROTCE','ROTCE',41,1129
exec spSaveFinancialNumberTypes 'E','TOTPAYOUTRATIO','Total Payout Ratio',44,1129

-- Valuations / Ratios
exec spSaveFinancialNumberTypes 'V', 'P/EPSRPT', 'P/E Reported',1,1129
exec spSaveFinancialNumberTypes 'V', 'P/EPSADJ', 'P/E Adjusted',2,1129
exec spSaveFinancialNumberTypes 'V', 'REL_EPSRPT', 'REL P/E Reported',3,1129
exec spSaveFinancialNumberTypes 'V', 'REL_EPSADJ', 'REL P/E Adjusted',4,1129
exec spSaveFinancialNumberTypes 'V', 'PEG', 'PEG',5,1129
exec spSaveFinancialNumberTypes 'V', 'P/BV', 'P/B',6,1129
exec spSaveFinancialNumberTypes 'V', 'P/TBV', 'P/TB',7,1129
exec spSaveFinancialNumberTypes 'V', 'P/OCF', 'P/CFO',8,1129
exec spSaveFinancialNumberTypes 'V', 'P/SALES', 'P/Sales',9,1129
exec spSaveFinancialNumberTypes 'V', 'EV/SALES', 'EV/Sales',10,1129
exec spSaveFinancialNumberTypes 'V', 'EV/EBITDA', 'EV/EBITDA',11,1129
exec spSaveFinancialNumberTypes 'V', 'EV/EBITA', 'EV/EBITA',12,1129
exec spSaveFinancialNumberTypes 'V', 'EV/EBIT', 'EV/EBIT',13,1129
exec spSaveFinancialNumberTypes 'V', 'EV/CE', 'EV/CE',14,1129
exec spSaveFinancialNumberTypes 'V', 'DIVYIELD', 'Div Yield',15,1129
exec spSaveFinancialNumberTypes 'V', 'FCFYIELD', 'FCF Yield',16,1129
exec spSaveFinancialNumberTypes 'V', 'CAPEX/SALES', 'CapEx / Sales',17,1129
exec spSaveFinancialNumberTypes 'V', 'NETDEBT/EBITDA', 'Net Debt / EBITDA',18,1129
exec spSaveFinancialNumberTypes 'V','P/FCF','P/FCF',10,1129 -- 07/27/2015
exec spSaveFinancialNumberTypes 'V','EV/FCF','EV/FCF',16,1129 -- 07/27/2015


-- Market data types
exec spSaveFinancialNumberTypes 'M', 'CLOSEDATE', 'Close Date',1,1129
exec spSaveFinancialNumberTypes 'M', 'CLOSEPRICE', 'Close Price',2,1129
exec spSaveFinancialNumberTypes 'M', 'CRNCY', 'Currency',3,1129
exec spSaveFinancialNumberTypes 'M', 'FXRATE', 'FX Rate',4,1129
exec spSaveFinancialNumberTypes 'M', 'DIVPERSH', 'Div Per Share',5,1129
exec spSaveFinancialNumberTypes 'M', 'EV', 'EV',6,1129
exec spSaveFinancialNumberTypes 'M', 'NETDEBT', 'Net Debt',7,1129
exec spSaveFinancialNumberTypes 'M', '52_WEEK_LOW', '52-Week Low',8,1129
exec spSaveFinancialNumberTypes 'M', '52_WEEK_HIGH', '52-Week High',9,1129
exec spSaveFinancialNumberTypes 'M', 'EQY_FISCAL_YR_END', 'FYE',10,1129
exec spSaveFinancialNumberTypes 'M', 'EQY_DVD_YLD_IND', 'Dividend Yield',11,1129
exec spSaveFinancialNumberTypes 'M', 'CUR_MKT_CAP',       'Market Cap',12,1129
exec spSaveFinancialNumberTypes 'M', 'CHG_PCT_1M',        'Perf 1M',13,1129
exec spSaveFinancialNumberTypes 'M', 'CHG_PCT_3M',        'Perf 3M',14,1129
exec spSaveFinancialNumberTypes 'M', 'CHG_PCT_6M',        'Perf 6M',15,1129
exec spSaveFinancialNumberTypes 'M', 'CHG_PCT_1YR',       'Perf 1Yr',16,1129
exec spSaveFinancialNumberTypes 'M', 'CHG_PCT_YTD',       'Perf YTD',17,1129
exec spSaveFinancialNumberTypes 'M', 'EQY_FUND_CRNCY',    'Fund Currency',18,1129



/*

select * from FinancialNumberTypes order by FinancialNumberTypeCat, FinancialNumberTypeCatOrd

Test: Enforce / test unique Financial Number Type
IX_FinancialNumberTypes_FinancialNumberType
insert into FinancialNumberTypes (FinancialNumberType, FinancialNumberTypeCat, FinancialNumberTypeCatOrd) values ('OPEARN','E',16)

Test: Enforce / test unique category order
IX_FinancialNumberTypes_FinancialNumberTypeCat_FinancialNumberTypeCatOrd
insert into FinancialNumberTypes (FinancialNumberType, FinancialNumberTypeCat, FinancialNumberTypeCatOrd) values ('XYZTEST','E',16)

allow passing null for ord to spSave

select * from sysobjects order by name

*/

--Formulae
update FinancialNumberTypes set Formula = '[CLOSEPRICE]/[EPSRPT]' where FinancialNumberType = 'P/EPSRPT'
update FinancialNumberTypes set Formula = '[CLOSEPRICE]/[EPSADJ]' where FinancialNumberType = 'P/EPSADJ'
update FinancialNumberTypes set Formula = '[P/EPSRPT]/[IDX!P/EPSRPT]' where FinancialNumberType = 'REL_EPSRPT'
update FinancialNumberTypes set Formula = '[P/EPSADJ]/[IDX!P/EPSADJ]' where FinancialNumberType = 'REL_EPSADJ'
update FinancialNumberTypes set Formula = '[P/EPSRPT]/[EPSGROWTH]' where FinancialNumberType = 'PEG'
update FinancialNumberTypes set Formula = '[CLOSEPRICE]/[BVPS]' where FinancialNumberType = 'P/BV'
update FinancialNumberTypes set Formula = '[CLOSEPRICE]/[TBVPS]' where FinancialNumberType = 'P/TBV'
update FinancialNumberTypes set Formula = '[CLOSEPRICE]/[OCFPS]' where FinancialNumberType = 'P/OCF'
update FinancialNumberTypes set Formula = '[CLOSEPRICE]/[SALESPS]' where FinancialNumberType = 'P/SALES'
update FinancialNumberTypes set Formula = '[EV]/[SALES]' where FinancialNumberType = 'EV/SALES'
update FinancialNumberTypes set Formula = '[EV]/[EBITDA]' where FinancialNumberType = 'EV/EBITDA'
update FinancialNumberTypes set Formula = '[EV]/[EBITA]' where FinancialNumberType = 'EV/EBITA'
update FinancialNumberTypes set Formula = '[EV]/[EBIT]' where FinancialNumberType = 'EV/EBIT'
update FinancialNumberTypes set Formula = '[EV]/[CE]' where FinancialNumberType = 'EV/CE'
update FinancialNumberTypes set Formula = '[DIVPS]/[CLOSEPRICE]' where FinancialNumberType = 'DIVYIELD'
update FinancialNumberTypes set Formula = '[FCFPS]/[CLOSEPRICE]' where FinancialNumberType = 'FCFYIELD'
update FinancialNumberTypes set Formula = '[CAPEX]/[SALES]' where FinancialNumberType = 'CAPEX/SALES'
update FinancialNumberTypes set Formula = '[NETDEBT]/[EBITDA]' where FinancialNumberType = 'NETDEBT/EBITDA'
update FinancialNumberTypes set Formula = '[CLOSEPRICE]/[FCFPS]' where FinancialNumberType = 'P/FCF' -- 07/27/2015
update FinancialNumberTypes set Formula = '[EV]/[FCF]' where FinancialNumberType = 'EV/FCF' -- 07/27/2015

--select 'update FinancialNumberTypes set Formula = ''' + Formula + ''' where FinancialNumberType = ''' + FinancialNumberType + '''' from FinancialNumberTypes where FinancialNumberTypeCat = 'V' order by FinancialNumberTypeId

-- IsPerShare
update FinancialNumberTypes set IsPerShare = 0

update FinancialNumberTypes set IsPerShare = 1
where FinancialNumberType in ('TARGETPRICE','EPSRPT','EPSADJ','SALESPS','OCFPS','BVPS','TBVPS','DIVPS','FCFPS','EPSGROWTH')

-- IsPercent
update FinancialNumberTypes set IsPercent = 0

update FinancialNumberTypes set IsPercent = 1, Format='%'
where FinancialNumberType in ('ROIC','ROE','ROCE','DIVPAYOUTRATIO','DIVYIELD','FCFYIELD','CET1','NIM','LOANGROW','DEPOSITGROW','NETCHARGEOFF','COMBINEDRATIO','ROTA','ROTCE','TOTPAYOUTRATIO','EPSGROWTH','EQY_DVD_YLD_IND','CHG_PCT_1M','CHG_PCT_3M','CHG_PCT_6M','CHG_PCT_1YR','CHG_PCT_YTD','GM','EBITDAMARGIN','OM','NETMARGIN','NIM')

-- IsRequiredSet & IsRequiredReport
update FinancialNumberTypes set IsRequiredSet = 1, IsRequiredReport = 1
where FinancialNumberType in ('SALES')

-- Format
update FinancialNumberTypes set Format = 'x'
where FinancialNumberType in ('P/EPSRPT', 'P/EPSADJ', 'REL_EPSRPT', 'REL_EPSADJ', 'P/BV', 'P/TBV', 'P/OCF', 'P/SALES', 'EV/SALES', 'EV/EBITDA', 'EV/EBITA', 'EV/EBIT', 'EV/CE', 'NETDEBT/EBITDA')

-- UnitMultiplier
update FinancialNumberTypes set UnitMultiplier = 1000000
where FinancialNumberType in ('EV','NETDEBT','CUR_MKT_CAP')

--FormulaPassNo
update FinancialNumberTypes set FormulaPassNo = 1 
where FinancialNumberTypeCat = 'V'

update FinancialNumberTypes set FormulaPassNo = 2
where FinancialNumberType in ('REL_EPSRPT','REL_EPSADJ','PEG')

-- ShortName
update FinancialNumberTypes set ShortName = substring(FullName,1,30)
-- Definition
update FinancialNumberTypes set Definition = FullName
/*

select * from FinancialPeriods

-- Instances in use
select FNT.FinancialNumberTypeId, FNT.FinancialNumberType, count(*) as Num
from FinancialNumbers FN
join FinancialNumberTypes FNT on FNT.FinancialNumberTypeId = FN.FinancialNumberTypeId
group by FNT.FinancialNumberTypeId, FNT.FinancialNumberType


Cascade Order
Insert Row
Update Ord
- Move up
- Move down


update SeqNo = +1 where Type and SeqNo > @SeqNo

*/
