-- FinancialNumberTypes_8.sql

sp_helptext spSaveFinancialNumberTypes

-- spSaveFinancialNumberTypes @FinancialNumberTypeCat, @FinancialNumberType, @FullName, @Display, @Statement, @FinancialNumberTypeCatOrd

-- 07/18/2016
-- Metrics added for Linda Sun-Mattison / Asian Insurance

select FinancialNumberTypeCat, 'LastOrd' = max(FinancialNumberTypeCatOrd) from FinancialNumberTypes group by FinancialNumberTypeCat order by 1

exec spSaveFinancialNumberTypes 'E','ASSETS/BV',    'Assets/Book Value', 'Assets/Book Value', 'BS',45,1
exec spSaveFinancialNumberTypes 'E','EMBED_VAL_PS', 'Embedded Value/Sh', 'Embedded Value/Sh', 'BS',81,1
exec spSaveFinancialNumberTypes 'E','VONB_PS',      'VoNB/Sh',           'VoNB/Sh',           'BS',82,1
exec spSaveFinancialNumberTypes 'V','P/EMBED_VAL',  'P/Embedded Value',  'P/Embedded Value',  'Valuation',21,1
exec spSaveFinancialNumberTypes 'V','P/VONB',       'P/VoNB',            'P/VoNB',            'Valuation',22,1

-- Re-order
exec spSaveFinancialNumberTypes 'E','EMBED_VAL_PS', 'Embedded Value/Sh', 'Embedded Value/Sh', 'BS',43,1
exec spSaveFinancialNumberTypes 'E','VONB_PS',      'VoNB/Sh',           'VoNB/Sh',           'BS',44,1

-- Re-order
exec spSaveFinancialNumberTypes 'E','EMBED_VAL_PS', 'Embedded Value/Sh', 'Embedded Value/Sh', 'Ratio/Other',83,1
exec spSaveFinancialNumberTypes 'E','VONB_PS',      'VoNB/Sh',           'VoNB/Sh',           'Ratio/Other',84,1

-- Re-order
exec spSaveFinancialNumberTypes 'E','ASSETS/BV',    'Assets/Book Value', 'Assets/Book Value', 'BS',81,1

-- Correct statement (re-order incorrectly resets statement)
update FinancialNumberTypes set Statement = 'Ratio/Other'
where FinancialNumberType in ('ASSETS/BV', 'EMBED_VAL_PS', 'VONB_PS')

update FinancialNumberTypes set Definition = FullName , IsPerShare = 0, IsPercent = 0
where FinancialNumberType in ('ASSETS/BV', 'P/EMBED_VAL', 'P/VONB')

update FinancialNumberTypes set Definition = FullName , IsPerShare = 1, IsPercent = 0
where FinancialNumberType in ('EMBED_VAL_PS', 'VONB_PS')

-- Valuation
update FinancialNumberTypes set Format = 'x', FormulaPassNo = 1, Formula = '[CLOSEPRICE]/[EMBED_VAL_PS]'
where FinancialNumberType = 'P/EMBED_VAL'

update FinancialNumberTypes set Format = 'x', FormulaPassNo = 1, Formula = '[CLOSEPRICE]/[VONB_PS]'
where FinancialNumberType = 'P/VONB'

-- Correct from enterprise value to per share ratio
-- Types with Format of x have Value = UnitValue x UnitMultiplier saved on Submit
update FinancialNumberTypes set Format = 'x', IsPerShare = 1
where FinancialNumberType = 'ASSETS/BV'

-- Restore Value to UnitValue to undo unit multiplier effect for previously submitted estimates
-- update FinancialNumbers set Value = UnitValue where FinancialNumberTypeId = 134 -- 'ASSETS/BV'

update FinancialNumberTypes set Comments = 'Insurance'
where FinancialNumberType in ('ASSETS/BV', 'EMBED_VAL_PS', 'VONB_PS', 'ASSETS/BV', 'P/EMBED_VAL', 'P/VONB')

-- Populate FinancialSetExclusions for the new FinancialNumberTypes that are added
select FinancialNumberTypeId,FinancialNumberType
into #Tmp_FinancialTypeAdditions
from FinancialNumberTypes
where FinancialNumberType in
('ASSETS/BV', 'EMBED_VAL_PS', 'VONB_PS', 'P/EMBED_VAL', 'P/VONB')

insert into FinancialSetExclusions(CompanyId, FinancialNumberTypeId, EditorId, EditDate)
select distinct CompanyId, T.FinancialNumberTypeId, 1126, GETDATE()
from FinancialCompanySettings FN cross join #Tmp_FinancialTypeAdditions T

drop table #Tmp_FinancialTypeAdditions
go

update FinancialNumberTypes set FullName = 'Implied VoNB Multiple', ShortName = 'Implied VoNB Multiple', Definition = 'Implied VoNB Multiple'
where FinancialNumberType = 'P/VONB' -- P/VoNB

update FinancialNumberTypes set FullName = 'P/VoNB', ShortName = 'P/VoNB', Definition = 'P/VoNB'
where FinancialNumberType = 'P/VONB'

update FinancialNumberTypes set FullName = 'VoNB Multiple', ShortName = 'VoNB Multiple', Definition = 'VoNB Multiple'
where FinancialNumberType = 'P/VONB'
