--5/17/2017
--Ticker SOON.VX (Sonova Holding AG) 
--Analyst Suspended coverage(materity leave) for the ticker on Aug 25 2016 - with 2015A
--She resumed coverage (coming back from maternity leave) for the ticker on March 2nd 2017 - with 2016A (peformed a rollover)
--Company reported 2017A in May 2017 and the system does not allow rollover if there was one performed in last 90 days
--This script removes the check (as it is an exception) and rolls over the ticker to 2017 A.


    DECLARE @CompanyId int
    DECLARE @EditDate datetime
    DECLARE @LastRolloverDate datetime
    DECLARE @UserId int
    DECLARE @FinancialPeriodId int
    DECLARE @BaseYear char(4), @BaseQuarter char(2)

    SELECT @EditDate = GETDATE()
    SELECT @UserId = 1126
    SELECT @CompanyId = 1087
    SELECT @BaseYear = BaseYear, @BaseQuarter = BaseQuarter FROM FinancialCompanySettings WHERE CompanyId = @CompanyId

    DELETE FROM dbo.FinancialNumbers
    WHERE SecurityId IN (SELECT SecurityId FROM Securities2 WHERE CompanyId = @CompanyId)
    AND IsDraft = 1
    --Mark current year as actuals
    --Rollover current year
    SELECT @FinancialPeriodId = FinancialPeriodId FROM FinancialPeriods WHERE FinancialPeriod = 'FY1'

    UPDATE vFinancialNumbersLatest
    SET IsEstimate = 0
    WHERE SecurityId IN (SELECT SecurityId FROM Securities2 WHERE CompanyId = @CompanyId)
    AND FinancialPeriodId = @FinancialPeriodId

    SELECT  SecurityId INTO #tmp_Securities FROM Securities2 WHERE CompanyId = @CompanyId

    INSERT INTO dbo.FinancialNumbers(SecurityId,FinancialNumberTypeId,FinancialPeriodId,PeriodYear,BaseYear,Date,Value,UnitValue,UnitMultiplier,CurCode,IsDraft,IsEstimate,PubNo,CoverageId,Source,EditorId,EditDate)
    SELECT V.SecurityId,V.FinancialNumberTypeId,CASE VFP.FinancialNumberTypeCat WHEN 'A' THEN V.FinancialPeriodId WHEN 'E' THEN V.FinancialPeriodId-1 END,V.PeriodYear,Convert(varchar(4),Convert(int,@BaseYear) + 1) ,@EditDate,V.Value,V.UnitValue,V.UnitMultiplier,V.CurCode,IsDraft,IsEstimate,null,VFP.CoverageId,'RollOver',@UserId,@EditDate
    FROM vFinancialNumbersLatest V
    JOIN #tmp_Securities S ON V.SecurityId = S.SecurityId
    JOIN vEstimateSets VFP ON V.SecurityId = VFP.SecurityId AND V.FinancialNumberTypeId = VFP.FinancialNumberTypeId
    JOIN FinancialPeriods FP ON V.FinancialPeriodId = FP.FinancialPeriodId
    AND FP.FinancialPeriodCat = 'Y' AND FP.FinancialPeriod <> 'FY0'

    UPDATE FinancialCompanySettings
    SET BaseYear = BaseYear + 1, BaseQuarter = 'Q4', EditorId = @UserId, EditDate = @EditDate
    WHERE CompanyId = @CompanyId


