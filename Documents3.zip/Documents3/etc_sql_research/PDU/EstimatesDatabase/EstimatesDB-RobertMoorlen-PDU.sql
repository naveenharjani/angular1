--03/15/2015
--Refer to 03/15/2016 email from Robert Moorlen (Jamie Merriman's associate) 

--Comp Store Sales Growth was accidentally omitted from Colin's master list(with new additions)
--Reinitialize IsPershare value for the financial type
update FinancialNumberTypes
set IsPerShare = 0 ,Statement = 'Ratio/Other'
where FinancialNumberType in ('ORGSALESGROWTH','COMPSTORESALESGROWTH')

--CAPEXSALES should be percentage
update FinancialNumberTypes
set IsPercent = 1,Format = '%'
where FinancialNumberType = 'CAPEXSALES' AND
FinancialNumberTypeCat = 'E'

--Robert noted that PEG Adjusted (part of their valuation set) is displayed blank on Estimates & Company Financials screens
--This is because IsPershare, IsPercent & Format are not properly initialized in the table for certain valuations.
--spRevaluate looks for specific values (fails if it is null) for IsPercent column
update FinancialNumberTypes
set IsPerShare = 0, IsPercent = 0,Format = 'x'
where FinancialNumberType in ('PEGADJ','EV/FCF_UNLEV','PEG','P/FCF','EV/FCF','CAPEX/SALES') AND
FinancialNumberTypeCat = 'V'