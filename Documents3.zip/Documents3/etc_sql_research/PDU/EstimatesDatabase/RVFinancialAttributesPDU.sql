--11/22/2016
--RVFinancialAttributes is used to display perioicity for Bernstein Estimates on company landing page
--Currently RVFinancialAttributes uses AnalystSettings table which is not updated during spSaveCoverage or Estimates Rollover
--Below query is a one time update to update EstimatePeriodId column in AnalystSettings table based on Base Year data in FinancialCompanySettings table
--update EpsTypeId & ValuationTypeId columns in AnalystSettings table based on values in FinancialCompanySettings table
--Post migration RVFinancials & RVFinancialAttributes need to be retrofitted to point to new tables

update AST
set AST.EstimatePeriodId = EP.EstimatePeriodId
from
AnalystSettings AST join ResearchCoverage RC on AST.CoverageId = RC.CoverageId
join Securities2 S on RC.SecurityId = S.SecurityId
join FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
join EstimatesPeriods EP on FCS.BaseYear + 'A' = EP.EstimatePeriodDisplay 

--update AST EpsTypeId to 'GAAP EPS' if FCS TickerTableEpsId is 'EPS Reported'
update AST
set AST.EpsTypeId = 1
from
AnalystSettings AST join ResearchCoverage RC on AST.CoverageId = RC.CoverageId
join Securities2 S on RC.SecurityId = S.SecurityId
join FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
where
FCS.TickerTableEpsId = 3

--update AST EpsTypeId to 'CASH EPS' if FCS TickerTableEpsId is 'EPS Adjusted'
update AST
set AST.EpsTypeId = 2
from
AnalystSettings AST join ResearchCoverage RC on AST.CoverageId = RC.CoverageId
join Securities2 S on RC.SecurityId = S.SecurityId
join FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
where
FCS.TickerTableEpsId = 4

--update AST ValuationTypeId to 'P/E' if FCS TickerTableValuationId is 'P/E Reported' OR 'P/E Adusted'
update AST
set AST.MetricsTypeId = 1
from
AnalystSettings AST join ResearchCoverage RC on AST.CoverageId = RC.CoverageId
join Securities2 S on RC.SecurityId = S.SecurityId
join FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
where
FCS.TickerTableValuationId in (55,56)

--update AST ValuationTypeId to 'P/B' if FCS TickerTableValuationId is 'P/BV'
update AST
set AST.MetricsTypeId = 2
from
AnalystSettings AST join ResearchCoverage RC on AST.CoverageId = RC.CoverageId
join Securities2 S on RC.SecurityId = S.SecurityId
join FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
where
FCS.TickerTableValuationId in (60)

--update AST ValuationTypeId to 'EV/EBITDA' if FCS TickerTableValuationId is 'EV/EBITDA'
update AST
set AST.MetricsTypeId = 3
from
AnalystSettings AST join ResearchCoverage RC on AST.CoverageId = RC.CoverageId
join Securities2 S on RC.SecurityId = S.SecurityId
join FinancialCompanySettings FCS on FCS.CompanyId = S.CompanyId
where
FCS.TickerTableValuationId in (65)

