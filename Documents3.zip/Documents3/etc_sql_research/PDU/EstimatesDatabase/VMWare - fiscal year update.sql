--1/30/2017
--VMW - VMWare updated their fiscal calendar.
--Company announced thier 2016 earnings on Jan 26th of 2017
--Jan 1 2017 to Feb 3rd 2017 is stub month which does not align to any fiscal year.
--As a result the company will not have fiscal 2017 at all.
--Starting Feb 4th 2017 their calendar will be aligned to Dell's (ticker is private) fiscal 2018.


--Mark Moerdler's franchise used tickersheet to rollover from baseyear 2015 to 2016.
--Ran below sql to change period headers to 2017A, 2018E, 2019E & 2020E.
--Team is footnoting the reports on first page of company report and ticker table to specify that 2017A is for 2016.

insert into FinancialNumbers
(  
  SecurityId,
  FinancialNumberTypeId,
  BaseYear,
  FinancialPeriodId,
  PeriodYear,
  Value,
  UnitValue,
  UnitMultiplier,
  CurCode,
  IsDraft,
  IsEstimate,
  Date,
  PubNo,
  CoverageId,
  Source,
  EditorId,
  EditDate
)
select  
  SecurityId,
  FinancialNumberTypeId,
  2017,
  FinancialPeriodId,
  PeriodYear,
  Value,
  UnitValue,
  UnitMultiplier,
  CurCode,
  IsDraft,
  IsEstimate,
  Date,
  PubNo,
  CoverageId,
  'RollOver',
  1126,
  getdate()
from vFinancialNumbersLatest
where
securityid = 1023


