--11/28/2016
/*
Hi Evgenia,

Is there any way we can manually insert the EPS estimates into our ticker table? 

I accidentally rolled over the FY when we weren�t ready yet. 

Best,
Nataliya Nedzhvetskaya
Research Associate
U.S. Media
T +1 212 823 2795    

Below script was run to undo the rollover and update the base year back to 2015
for Disney (DIS) - SecurityId = 174
*/

delete from FinancialNumbers
where 
SecurityId = 174 and
BaseYear = 2016

update FinancialCompanySettings
set BaseYear = 2015
where 
CompanyId = (select companyid from securities2 where securityid  = 174)


