--EstimatesDB-PDU.sql
--01/19/2016

--BP 
update FinancialNumbers
set IsDraft = 0
where FinancialNumberId = 178326 and
FinancialNumberTypeId = 2

update FinancialNumbers
set Value = 2.40, UnitValue = 2.40, isdraft = 0
where FinancialNumberId = 139035 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 2

update FinancialNumbers
set Value = 2.28, UnitValue = 2.28, isdraft = 0
where FinancialNumberId = 178327 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 3

--BP/.LN
update FinancialNumbers
set IsDraft = 0
where FinancialNumberId = 178311 and
FinancialNumberTypeId = 2

update FinancialNumbers
set Value = 0.40, UnitValue = 0.40, isdraft = 0
where FinancialNumberId = 139032 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 2

update FinancialNumbers
set Value = 0.38, UnitValue = 0.38, isdraft = 0
where FinancialNumberId = 178312 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 3

--pmo.ln
update FinancialNumbers
set IsDraft = 0
where FinancialNumberId = 172509 and
FinancialNumberTypeId = 2

--cne.ln
update FinancialNumbers
set Value = 203.00, UnitValue = 203.00
where FinancialNumberId = 74097 and
FinancialNumberTypeId = 2

update FinancialNumbers
set IsDraft = 0
where FinancialNumberId = 139077 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 3


--tlw.ln
update FinancialNumbers
set Value = 270.00, UnitValue = 270.00
where FinancialNumberId = 74095 and
FinancialNumberTypeId = 2

update FinancialNumbers
set Value = -0.05, UnitValue = -0.05, isdraft = 0
where FinancialNumberId = 138974 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 2

update FinancialNumbers
set Value = 0.01, UnitValue = 0.01,isdraft = 0
where FinancialNumberId = 138975 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 3

--BG/.ln
update FinancialNumbers
set IsDraft = 0
where FinancialNumberId = 148717 and
FinancialNumberTypeId = 2

update FinancialNumbers
set Value = 0.5132, UnitValue = 0.5132, isdraft = 0
where FinancialNumberId = 148718 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 2

update FinancialNumbers
set Value = 0.79, UnitValue = 0.79, isdraft = 0
where FinancialNumberId = 148719 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 3

--RDSB Tickers
--RDS/B
update FinancialNumbers
set IsDraft = 0 
where FinancialNumberId = 178777 and
FinancialNumberTypeId = 2 

--RDSB.LN
update FinancialNumbers
set IsDraft = 0 
where FinancialNumberId = 178774 and
FinancialNumberTypeId = 2

--RDSB.NA
update FinancialNumbers
set IsDraft = 0 
where FinancialNumberId = 178780 and
FinancialNumberTypeId = 2

