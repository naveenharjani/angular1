-- FinancialNumberTypes_2.sql
-- 11/10/2015

select 'update FinancialNumberTypes set Statement = ''Income Statement'' where FullName = ''' + FullName + ''''
from FinancialNumberTypes
where FinancialNumberTypeCat = 'E'
order by FinancialNumberTypeCat, FinancialNumberTypeCatOrd

update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'EPS Reported'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'EPS Adjusted'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Net Interest Income'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Non-Interest Income'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Net Written Premium'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Net Earned Premium'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Revenues'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Cost of Goods Sold'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Gross Profit'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Operating Expenses'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Pre-Provision Net Revenue'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Total Provision'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Net Losses'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Underwriting Income'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Net Investment Income'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Operating Earnings'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'EBIT'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'EBITDA'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'EBITA'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Pre-Tax Earnings'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Net Profit before Non-Recurring Items'
update FinancialNumberTypes set Statement = 'Income Statement' where FullName = 'Net Earnings'
