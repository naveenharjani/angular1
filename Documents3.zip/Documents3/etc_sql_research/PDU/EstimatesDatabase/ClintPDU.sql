select S.Ticker,S.CompanyId,V.* from vFinancialNumbersLatest V
join ResearchCoverage RC on V.SecurityId = RC.SecurityID
join Securities2 S on RC.SecurityID = S.SecurityID
where
RC.LaunchDate is not null and 
RC.DropDate is null and
RC.AnalystID = 301 and
V.FinancialNumberTypeId in (2,4) and
V.FinancialPeriodId in (1,2,3) and
IsDraft = 0
order by CompanyId,S.Ticker,FinancialNumberTypeId,FinancialPeriodId,IsDraft

drop table #tmp1_Fin
drop table #tmp_TTS

select S.Ticker,S.CompanyId,V.* 
into #tmp1_Fin
from vFinancialNumbersLatest V
join ResearchCoverage RC on V.SecurityId = RC.SecurityID
join Securities2 S on RC.SecurityID = S.SecurityID
where
RC.LaunchDate is not null and 
RC.DropDate is null and
RC.AnalystID = 301 and
V.FinancialNumberTypeId in (4) and
V.FinancialPeriodId in (3) and
IsDraft = 0
order by CompanyId,S.Ticker,FinancialNumberTypeId,FinancialPeriodId,IsDraft

select pubno,ticker,EPSNextYear 
into #tmp_TTS
from TickerTableSecurities
where pubno = 118293 

select b.ticker,a.securityid,value,EPSNextYear
from #tmp1_Fin a join #tmp_TTS b on a.Ticker = b.Ticker

select * from vFinancialNumbersLatest where securityid = 906
and financialnumbertypeid = 4 and financialperiodid = 2 and isdraft = 1

select * from vFinancialNumbersLatest where securityid = 906
and financialnumbertypeid = 4 and financialperiodid = 3 and isdraft = 1

--Target Price Corrections
--GALP.PL
update FinancialNumbers 
set Value = 12.60,UnitValue = 12.60
where SecurityId = 1081 and
FinancialNumberTypeId = 2 and 
FinancialNumberId = 74076
--STL.NO
update FinancialNumbers 
set Value = 160.00,UnitValue = 160.00
where SecurityId = 1018 and
FinancialNumberTypeId = 2 and 
FinancialNumberId = 47863
--STO
update FinancialNumbers 
set Value = 18.24,UnitValue = 18.24
where SecurityId = 1017 and
FinancialNumberTypeId = 2 and 
FinancialNumberId = 47698
--ENI.IM
update FinancialNumbers 
set Value = 17.50,UnitValue = 17.50
where SecurityId = 829 and
FinancialNumberTypeId = 2 and 
FinancialNumberId = 30792
--E
update FinancialNumbers 
set Value = 38.85,UnitValue = 38.85
where SecurityId = 187 and
FinancialNumberTypeId = 2 and 
FinancialNumberId = 6742
--FP.FP
update FinancialNumbers 
set Value = 49.00,UnitValue = 49.00
where SecurityId = 789 and
FinancialNumberTypeId = 2 and 
FinancialNumberId = 29343
--TOT
update FinancialNumbers 
set Value = 54.39,UnitValue = 54.39
where SecurityId = 530 and
FinancialNumberTypeId = 2 and 
FinancialNumberId = 14895
--REP.SM
update FinancialNumbers 
set Value = 13.00,UnitValue = 13.00
where SecurityId = 1281 and
FinancialNumberTypeId = 2 and 
FinancialNumberId = 60025

--EPS Last Year
--BG/.LN
update FinancialNumbers 
set Value = 0.72,UnitValue = 0.72
where SecurityId = 827 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 1 and
FinancialNumberId = 148713

--EPS This Year
--GALP.PL
update FinancialNumbers 
set Value = 0.71,UnitValue = 0.71
where SecurityId = 1081 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 138916
--STL.NO
update FinancialNumbers 
set Value = 6.98,UnitValue = 6.98
where SecurityId = 1018 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 139428
--STO
update FinancialNumbers 
set Value = 0.87,UnitValue = 0.87
where SecurityId = 1017 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 139434
--ENI.IM
update FinancialNumbers 
set Value = 0.45,UnitValue = 0.45
where SecurityId = 829 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 139531
--E
update FinancialNumbers 
set Value = 1.00,UnitValue = 1.00
where SecurityId = 187 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 139525
--FP.FP
update FinancialNumbers 
set Value = 4.22,UnitValue = 4.22
where SecurityId = 789 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 139611
--TOT
update FinancialNumbers 
set Value = 4.22,UnitValue = 4.22
where SecurityId = 530 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 139614
--REP.SM
update FinancialNumbers 
set Value = 1.14,UnitValue = 1.14
where SecurityId = 1281 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 139350

--RDS/B
update FinancialNumbers 
set IsDraft = 0
where SecurityId = 908 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 186324

--RDSB.LN
update FinancialNumbers 
set IsDraft = 0
where SecurityId = 904 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 186322

--RDSB.NA
update FinancialNumbers 
set IsDraft = 0
where SecurityId = 906 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 2 and
FinancialNumberId = 186326

--EPS Next Year
--GALP.PL
update FinancialNumbers 
set Value = 0.59,UnitValue = 0.59
where SecurityId = 1081 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 138917
--STL.NO
update FinancialNumbers 
set Value = 7.55,UnitValue = 7.55
where SecurityId = 1018 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 139429
--STO
update FinancialNumbers 
set Value = 0.94,UnitValue = 0.94
where SecurityId = 1017 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 139435
--ENI.IM
update FinancialNumbers 
set Value = 0.72,UnitValue = 0.72
where SecurityId = 829 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 139532
--E
update FinancialNumbers 
set Value = 1.60,UnitValue = 1.60
where SecurityId = 187 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 139526
--FP.FP
update FinancialNumbers 
set Value = 4.18,UnitValue = 4.18
where SecurityId = 789 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 139612
--TOT
update FinancialNumbers 
set Value = 4.18,UnitValue = 4.18
where SecurityId = 530 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 139615
--REP.SM
update FinancialNumbers 
set Value = 0.96,UnitValue = 0.96
where SecurityId = 1281 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 139351

--RDS/B
update FinancialNumbers 
set IsDraft = 0
where SecurityId = 908 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 186325

--RDSB.LN
update FinancialNumbers 
set IsDraft = 0
where SecurityId = 904 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 186323

--RDSB.NA
update FinancialNumbers 
set IsDraft = 0
where SecurityId = 906 and
FinancialNumberTypeId = 4 and 
FinancialPeriodId = 3 and
FinancialNumberId = 186327
--01/26/2016
--BG/.LN


--Novatek.LI
update FinancialNumbers
set Value = 5.6, UnitValue = 5.6
where
SecurityId = 1087 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 2 and
IsDraft = 0 and
FinancialNumberId = 139254

update FinancialNumbers
set Value = 5.9, UnitValue = 5.9
where
SecurityId = 1087 and
FinancialNumberTypeId = 4 and
FinancialPeriodId = 3 and
IsDraft = 0 and
FinancialNumberId = 139255