-- FinancialNumberTypes_Master.sql
-- 10/23/2015

-- FinancialPeriods
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0','Y',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1','Y',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2','Y',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY3','Y',1126,GETDATE())

--NumberUnits
insert into NumberUnits(NumberUnitCode,NumberUnitLabel,UnitMultiplier,EditorId,EditDate)
select 'K','Thousands (K)',1000,1126,getdate()
insert into NumberUnits(NumberUnitCode,NumberUnitLabel,UnitMultiplier,EditorId,EditDate)
select 'M','Millions (M)',1000000,1126,getdate()
insert into NumberUnits(NumberUnitCode,NumberUnitLabel,UnitMultiplier,EditorId,EditDate)
select 'B','Billions (B)',1000000000,1126,getdate()
insert into NumberUnits(NumberUnitCode,NumberUnitLabel,UnitMultiplier,EditorId,EditDate) values ('T','Trillions (T)',1000000000000,1126,getdate() )

/*

insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_Q1','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_Q2','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_Q3','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_Q4','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_Q1','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_Q2','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_Q3','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_Q4','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_Q1','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_Q2','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_Q3','Q',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_Q4','Q',1126,GETDATE())

insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_S1','S',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY0_S2','S',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_S1','S',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY1_S2','S',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_S1','S',1126,GETDATE())
insert into FinancialPeriods(FinancialPeriod,FinancialPeriodCat,EditorId,EditDate) values('FY2_S2','S',1126,GETDATE())

*/

-- FinancialNumberTypes

/*

select * from FinancialNumberTypes

sp_helptext spSaveFinancialNumberTypes

select * from FinancialNumberTypes where financialnumbertypecat = 'A' order by financialnumbertypecatord

*/

/*

select * from FinancialNumberTypes order by FinancialNumberTypeCat, FinancialNumberTypeCatOrd

Test: Enforce / test unique Financial Number Type
IX_FinancialNumberTypes_FinancialNumberType
insert into FinancialNumberTypes (FinancialNumberType, FinancialNumberTypeCat, FinancialNumberTypeCatOrd) values ('OPEARN','E',16)

Test: Enforce / test unique category order
IX_FinancialNumberTypes_FinancialNumberTypeCat_FinancialNumberTypeCatOrd
insert into FinancialNumberTypes (FinancialNumberType, FinancialNumberTypeCat, FinancialNumberTypeCatOrd) values ('XYZTEST','E',16)

allow passing null for ord to spSave

select * from sysobjects order by name

*/

--select 'update FinancialNumberTypes set Formula = ''' + Formula + ''' where FinancialNumberType = ''' + FinancialNumberType + '''' from FinancialNumberTypes where FinancialNumberTypeCat = 'V' order by FinancialNumberTypeId

/*

select * from FinancialPeriods

-- Instances in use
select FNT.FinancialNumberTypeId, FNT.FinancialNumberType, count(*) as Num
from FinancialNumbers FN
join FinancialNumberTypes FNT on FNT.FinancialNumberTypeId = FN.FinancialNumberTypeId
group by FNT.FinancialNumberTypeId, FNT.FinancialNumberType


Cascade Order
Insert Row
Update Ord
- Move up
- Move down


update SeqNo = +1 where Type and SeqNo > @SeqNo

*/


select * from FinancialNumberTypes

select
--  FinancialNumberTypeId,
  'BERN DESC' = FullName,
  'BERN CODE' = FinancialNumberType,
  'Type' = FinancialNumberTypeCat,
--FinancialNumberTypeCatOrd,
  'Short Name' = case when ShortName = FullName then '' else ShortName end,
  'Definition' = case when Definition = FullName then '' else Definition end,
  Comments,
  Statement,
  'IsPerShare' = case when IsPerShare = 1 then 'Y' when IsPerShare = 0 then '' when IsPerShare is null then '' end, -- else IsPerShare 
  'IsPercent' = case when IsPercent = 1 then 'Y' when IsPercent = 0 then '' end,
  'IsRequiredSet' = case when IsRequiredSet = 1 then 'Y' when IsRequiredSet = 0 then '' end,
  'IsRequiredReport' = case when IsRequiredReport = 1 then 'Y' when IsRequiredReport = 0 then '' end,
  Format
--  UnitMultiplier,
--  Formula,
--  FormulaPassNo,
--  EditorId,
--  EditDate
from FinancialNumberTypes
order by FinancialNumberTypeCat, FinancialNumberTypeCatOrd

