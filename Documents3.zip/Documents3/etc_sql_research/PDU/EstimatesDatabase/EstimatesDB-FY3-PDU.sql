--03/11/2016
--FY3 numbers wired by franchises are not published numbers. 
--Since financial web screens (containing FY3 numbers on Estimates screen) are being made public internally, franchises 
--request to delete the incorrect FY3 live numbers from database.

USE Research
GO

/*
-- Make sure that all of the session settings are set properly
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spDeleteFinancialNumbersByPeriod]') AND type in (N'P'))
  DROP PROCEDURE [dbo].[spDeleteFinancialNumbersByPeriod]
GO

create proc dbo.spDeleteFinancialNumbersByPeriod @Ticker varchar(30), @PeriodId int = null
as
begin
declare @SecurityId int
  if @PeriodId is null 
  select @PeriodId = FinancialPeriodId from FinancialPeriods where FinancialPeriod = 'FY3'

  select @SecurityId = SecurityId from Securities2 where Ticker = @Ticker

  if @SecurityId is not null
  begin
    delete from FinancialNumbers 
    where
    SecurityId = @SecurityId and
    FinancialPeriodId = @PeriodId

    delete from Valuations
    where
    SecurityId = @SecurityId and
    FinancialPeriodId = @PeriodId
  end
end

GO
GRANT EXECUTE ON [dbo].[spDeleteFinancialNumbersByPeriod]                TO PowerUsers, DE_IIS
GO


--Luke Montgomery 
--delete from FinancialNumbers
--select * from FinancialNumbers
where
  SecurityId in (select SecurityId from Securities2 where Ticker in ('BK','NTRS','STT','APO','BX','KKR','OMAM','BEN','BLK','IVZ','TROW')) and
  FinancialPeriodId = (select FinancialPeriodId from FinancialPeriods where FinancialPeriod = 'FY3')

--delete from Valuations
--select * from Valuations
where
  SecurityId in (select SecurityId from Securities2 where Ticker in ('BK','NTRS','STT','APO','BX','KKR','OMAM','BEN','BLK','IVZ','TROW')) and
  FinancialPeriodId = (select FinancialPeriodId from FinancialPeriods where FinancialPeriod = 'FY3')

--John McDonald 
--delete from FinancialNumbers
--select * from FinancialNumbers
where
  SecurityId in (select SecurityId from Securities2 where Ticker in ('BAC','C','JPM','WB','WFC','USB','PNC','AXP','BBT','RF','STI')) and
  FinancialPeriodId = (select FinancialPeriodId from FinancialPeriods where FinancialPeriod = 'FY3')

--delete from Valuations
--select * from Valuations
where
  SecurityId in (select SecurityId from Securities2 where Ticker in ('BAC','C','JPM','WB','WFC','USB','PNC','AXP','BBT','RF','STI')) and
  FinancialPeriodId = (select FinancialPeriodId from FinancialPeriods where FinancialPeriod = 'FY3')
*/