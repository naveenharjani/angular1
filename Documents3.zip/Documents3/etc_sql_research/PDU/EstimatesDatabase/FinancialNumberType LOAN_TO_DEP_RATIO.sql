--07/23/2019
--Request to add new FinancialNumberType LOAN_TO_DEP_RATION (Loan to Deposit ratio) from India Financials team (Gautam Chuggani and Kevin Kwek).

exec spSaveFinancialNumberTypes 'E','LOAN_TO_DEP_RATIO','Loan to Deposit ratio', 'Loan to Deposit ratio', 'Ratio/Other',103,1126

update FinancialNumberTypes set Definition = FullName , IsPerShare = 0, IsPercent = 0, Format = NULL
where FinancialNumberType in ('LOAN_TO_DEP_RATIO')

--Populate FinancialSetExclusions table to remove this new type from estimate set of all companies.
declare @FinancialNumberTypeId int
select @FinancialNumberTypeId = FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'LOAN_TO_DEP_RATIO'

insert into FinancialSetExclusions(CompanyId, FinancialNumberTypeId, EditorId, EditDate)
select distinct CompanyId, @FinancialNumberTypeId, 1126, GETDATE()
from Securities2 S join ResearchCoverage RC on S.SecurityID = RC.SecurityID
where
RC.DropDate is not null



