--6/16/2016
--Kevin's franchise launched (Pub# 122639) with new research template.
--SPX (2014A) data did not align with Ticker data (2015A).

--Step1: Update SPX base year to 2015A to fix the alignment issue
--Step2: Using SPX tickersheet enter data for 2015, 2016, 2017 & 2018 which populates rows in FinancialNumbers with 2015 base year.

--Company Id of SPX = 1012

update FinancialCompanySettings
set BaseYear = 2015
where CompanyId = 1012

--6/17/2016
--Evgenia found that there's 2014 hardcoding for indices on the current templates
--SPX 2015A will not work for the teams using current templates
--Reverting back to 2014 base year for SPX and handling the code to return 2015, 2016 & 2017 data in TickerTable Api

--Company Id of SPX = 1012

update FinancialCompanySettings
set BaseYear = 2014
where CompanyId = 1012

