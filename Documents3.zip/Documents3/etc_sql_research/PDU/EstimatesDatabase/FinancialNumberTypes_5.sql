-- FinancialNumberTypes_5.sql
-- 02/17/2016 04/06/2016

select * from FinancialNumberTypes order by FinancialNumberTypeCat, FinancialNumberTypeCatOrd

-- Rename existing mnemonics
-- Rename CET1 to CET1_PCT (CET1 initially supplied as percent.  Additionally capture CET1 as non-percent)
update FinancialNumbertypes set FinancialNumberType = 'CET1_PCT' where FinancialNumberType = 'CET1'

-- Re-classify existing mnemonics from Valuation to Estimate
-- Add CAPEXSALES, drop (eventually) CAPEX/SALES

--Teams who have CAPEX/SALES valuation as part of their estimate set
select Last, Ticker, Company
from ResearchCoverage RC
join Authors A on RC.AnalystId = A.AuthorId
join Securities2 S on RC.SecurityId = S.SecurityId
where CompanyId in
(select distinct CompanyId from FinancialSetExclusions
where companyid not in
(select CompanyId from FinancialSetExclusions
where FinancialNumberTypeId = (select FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'capex/sales')))
and RC.LaunchDate is not null and RC.DropDate is null


/*
Stacy A. Rasgon, Ph.D.
Jeremy Redenius, Ph.D. 
Alberto Moel, ScD
Mark Li (Already added capexsales to the estimate set)
Phil Roseberg
David Vernon
Todd Juenger
Paul Gait
Chris Lane
Paul de Sa, D.Phil.
Christian A. Laughlin
Jay Huang, Ph.D.
Lisa D. Ellis
Cosma Panzacchi
Anne-Charlotte Windal
Jonas Oxgaard, Ph.D.
Douglas S. Harned
Trevor Stirling
Ali Dibadj
Alexia Howard
Lisa Bedell Clive (Already added capexsales to the estimate set)
Andrew Wood
*/

--ADD/ADJUST FinancialNumberTypes
exec spSaveFinancialNumberTypes 'E','EPSRPT','EPS Reported','EPS Reported','IS',1,1126
exec spSaveFinancialNumberTypes 'E','EPSADJ','EPS Adjusted','EPS Adjusted','IS',2,1126
exec spSaveFinancialNumberTypes 'E','EPS_ALT','EPS (Pricing Cur)','EPS (Pricing Cur)','IS',3,1126
exec spSaveFinancialNumberTypes 'E','NII','Net Interest Income','Net Interest Income','IS',4,1126
exec spSaveFinancialNumberTypes 'E','NONINTINC','Non-Interest Income','Non-Interest Income','IS',5,1126
exec spSaveFinancialNumberTypes 'E','NETWRITTENPREM','Net Written Premium','Net Written Premium','IS',6,1126
exec spSaveFinancialNumberTypes 'E','NETEARNPREM','Net Earned Premium','Net Earned Premium','IS',7,1126
exec spSaveFinancialNumberTypes 'E','MGMT_FEE','Management Fee','Management Fee','IS',8,1126
exec spSaveFinancialNumberTypes 'E','NET_REAL_PERF_FEE','Net Realized Performance Fee','Net Real Perf Fee','IS',9,1126
exec spSaveFinancialNumberTypes 'E','SALES','Revenues','Revenues','IS',10,1126
exec spSaveFinancialNumberTypes 'E','COGS','Cost of Goods Sold','Cost of Goods Sold','IS',11,1126
exec spSaveFinancialNumberTypes 'E','GROSSPROFIT','Gross Profit','Gross Profit','IS',12,1126
exec spSaveFinancialNumberTypes 'E','NETLOSS','Net Losses','Net Losses','IS',13,1126
exec spSaveFinancialNumberTypes 'E','SGA','SG&A','SG&A','IS',14,1126
exec spSaveFinancialNumberTypes 'E','RD','R&D','R&D','IS',15,1126
exec spSaveFinancialNumberTypes 'E','CREDIT_COST','Credit Cost (%)','Credit Cost (%)','IS',16,1126
exec spSaveFinancialNumberTypes 'E','EXP','Operating Expenses','Operating Expenses','IS',17,1126
exec spSaveFinancialNumberTypes 'E','PPNR','Pre-Provision Net Revenue','Pre-Prov Net Rev','IS',18,1126
exec spSaveFinancialNumberTypes 'E','UNDERWRITEINC','Underwriting Income','Underwriting Income','IS',19,1126
exec spSaveFinancialNumberTypes 'E','NETINVESTINC','Net Investment Income','Net Investment Inc','IS',20,1126
exec spSaveFinancialNumberTypes 'E','OPEARN','Operating Earnings','Operating Earnings','IS',21,1126
exec spSaveFinancialNumberTypes 'E','PROV','Total Provision','Total Provision','IS',22,1126
exec spSaveFinancialNumberTypes 'E','FEE_REL_EARN','Fee Related Earnings','Fee Related Earnings','IS',23,1126
exec spSaveFinancialNumberTypes 'E','EBITDA','EBITDA','EBITDA','IS',24,1126
exec spSaveFinancialNumberTypes 'E','EBITA','EBITA','EBITA','IS',25,1126
exec spSaveFinancialNumberTypes 'E','EBIT','EBIT','EBIT','IS',26,1126
exec spSaveFinancialNumberTypes 'E','EBT','Pre-Tax Earnings','Pre-Tax Earnings','IS',27,1126
exec spSaveFinancialNumberTypes 'E','PROFBEFOREITEMS','Net Profit Before Non-Recurring Items','Net Prof Be NR Items','IS',28,1126
exec spSaveFinancialNumberTypes 'E','NI','Net Earnings','Net Earnings','IS',29,1126
exec spSaveFinancialNumberTypes 'E','DIST_EARN','Distributable Earnings','Distributable Earn','IS',30,1126
exec spSaveFinancialNumberTypes 'E','DIST_PS','Distribution/Share','Distribution/Sh','IS',31,1126
exec spSaveFinancialNumberTypes 'E','FEE_REL_EPS','Fee Related Earnings/Share','Fee Related Earn/Sh','IS',32,1126
exec spSaveFinancialNumberTypes 'E','NET_REAL_PERF_FEE_PS','Net Realized Performance Fee/Share','Net Real Perf Fee/Sh','IS',33,1126
exec spSaveFinancialNumberTypes 'E','ECON_NET_INC_PS','Economic Net Income/Share','Economic Net Inc/Sh','IS',34,1126
exec spSaveFinancialNumberTypes 'E','SALESPS','Revenue/Share','Revenue/Sh','IS',35,1126
exec spSaveFinancialNumberTypes 'E','NON_PERF_LOAN','Non-Performing Loan','Non-Perf Loan','BS',36,1126
exec spSaveFinancialNumberTypes 'E','NETDEBT_EST','Net Debt (Cash)','Net Debt','BS',37,1126
exec spSaveFinancialNumberTypes 'E','BV','Book Value','Book Value','BS',38,1126
exec spSaveFinancialNumberTypes 'E','CET1','CE T1','CE T1','BS',39,1126
exec spSaveFinancialNumberTypes 'E','CE','Common Equity','Common Equity','BS',40,1126
exec spSaveFinancialNumberTypes 'E','BVPS','BV/Share','BV/Sh','BS',41,1126
exec spSaveFinancialNumberTypes 'E','TBVPS','TB/Share','TB/Sh','BS',42,1126
exec spSaveFinancialNumberTypes 'E','DA','D&A','D&A','CF',43,1126
exec spSaveFinancialNumberTypes 'E','OCF','CFO','CFO','CF',44,1126
exec spSaveFinancialNumberTypes 'E','CAPEX','CapEx','CapEx','CF',45,1126
exec spSaveFinancialNumberTypes 'E','FCF','FCF','FCF','CF',46,1126
exec spSaveFinancialNumberTypes 'E','FCF_UNLEV','FCF Unlevered','FCF Unlevered','CF',47,1126
exec spSaveFinancialNumberTypes 'E','OCFPS','CFO/Share','CFO/Sh','CF',48,1126
exec spSaveFinancialNumberTypes 'E','DIVPS','Dividend/Share','Dividend/Sh','CF',49,1126
exec spSaveFinancialNumberTypes 'E','FCFPS','FCF/Share','FCF/Sh','CF',50,1126
exec spSaveFinancialNumberTypes 'E','GM','Gross Margin','Gross Margin','Ratio/Other',51,1126
exec spSaveFinancialNumberTypes 'E','EBITDAMARGIN','EBITDA Margin','EBITDA Margin','Ratio/Other',52,1126
exec spSaveFinancialNumberTypes 'E','OM','Operating Margin','Operating Margin','Ratio/Other',53,1126
exec spSaveFinancialNumberTypes 'E','NET_REV_YIELD','Net Revenue Yield','Net Revenue Yield','Ratio/Other',54,1126
exec spSaveFinancialNumberTypes 'E','ADJ_OPER_MARGIN','Adjusted Operating Margin','Adj. Op. Margin','Ratio/Other',55,1126
exec spSaveFinancialNumberTypes 'E','NIM','Net Interest Margin','Net Interest Margin','Ratio/Other',56,1126
exec spSaveFinancialNumberTypes 'E','NETCHARGEOFF','Net Charge-off Rate','Net Charge-off Rate','Ratio/Other',57,1126
exec spSaveFinancialNumberTypes 'E','COMBINEDRATIO','Combined Ratio','Combined Ratio','Ratio/Other',58,1126
exec spSaveFinancialNumberTypes 'E','NETMARGIN','Net Income Margin','Net Income Margin','Ratio/Other',59,1126
exec spSaveFinancialNumberTypes 'E','CET1_PCT','CE T1','CE T1','Ratio/Other',60,1126
exec spSaveFinancialNumberTypes 'E','ROIC','ROIC','ROIC','Ratio/Other',61,1126
exec spSaveFinancialNumberTypes 'E','ROIC_EX_INTANG','ROIC Excluding Goodwill and Intangibles','ROIC ex. Intangibles','Ratio/Other',62,1126
exec spSaveFinancialNumberTypes 'E','ROA','ROA ','ROA ','Ratio/Other',63,1126
exec spSaveFinancialNumberTypes 'E','ROTA','ROTA','ROTA','Ratio/Other',64,1126
exec spSaveFinancialNumberTypes 'E','ROE','ROE','ROE','Ratio/Other',65,1126
exec spSaveFinancialNumberTypes 'E','ROCE','ROCE','ROCE','Ratio/Other',66,1126
exec spSaveFinancialNumberTypes 'E','ROTCE','ROTCE','ROTCE','Ratio/Other',67,1126
exec spSaveFinancialNumberTypes 'E','LOCAL_CUR_SALES_GROWTH','Local Currency Sales Growth','FX-Neut Rev Grwth','Ratio/Other',68,1126
exec spSaveFinancialNumberTypes 'E','ORGSALESGROWTH','Organic Sales Growth','Organic Sales Grwth','Ratio/Other',69,1126
exec spSaveFinancialNumberTypes 'E','LFL_SALES_GROWTH','Like-For-Like Sales Growth','Comp Sales Growth','Ratio/Other',70,1126
exec spSaveFinancialNumberTypes 'E','EPSGROWTH','EPS Growth','EPS Growth','Ratio/Other',71,1126
exec spSaveFinancialNumberTypes 'E','LOANGROW','Loan Growth','Loan Growth','Ratio/Other',72,1126
exec spSaveFinancialNumberTypes 'E','DEPOSITGROW','Deposit Growth','Deposit Growth','Ratio/Other',73,1126
exec spSaveFinancialNumberTypes 'E','BV_GROWTH','Book Value Growth','Book Value Growth','Ratio/Other',74,1126
exec spSaveFinancialNumberTypes 'E','CAPEXSALES','CapEx/Sales','CapEx/Sales','Ratio/Other',75,1126
exec spSaveFinancialNumberTypes 'E','NETDEBTEBITDA','Net Debt/EBITDA','Net Debt/EBITDA','Ratio/Other',76,1126
exec spSaveFinancialNumberTypes 'E','NETDEBTEQUITY','Net Debt/Equity','Net Debt/Equity','Ratio/Other',77,1126
exec spSaveFinancialNumberTypes 'E','DCF','DCF','DCF','Ratio/Other',78,1126
exec spSaveFinancialNumberTypes 'E','DIVPAYOUTRATIO','Dividend Payout Ratio','Div Payout Ratio','Ratio/Other',79,1126
exec spSaveFinancialNumberTypes 'E','TOTPAYOUTRATIO','Total Payout Ratio','Total Payout Ratio','Ratio/Other',80,1126
exec spSaveFinancialNumberTypes 'E','NON_PERF_LOAN_PCT','Non-Performing Loan','Non-Perf. Loan','Ratio/Other',81,1126
exec spSaveFinancialNumberTypes 'E','AUM','AUM','AUM','Ratio/Other',82,1126
exec spSaveFinancialNumberTypes 'E','AUM_FEE_PAY','Fee Paying AUM','Fee Paying AUM','Ratio/Other',83,1126
exec spSaveFinancialNumberTypes 'E','AUM_FEE_PAY_GROWTH','Fee Paying AUM Growth','Fee Pay AUM Grwth','Ratio/Other',84,1126
exec spSaveFinancialNumberTypes 'E','FEE_RATE','Fee Rate','Fee Rate','Ratio/Other',85,1126
exec spSaveFinancialNumberTypes 'E','NET_FLOWS','Net Flows','Net Flows','Ratio/Other',86,1126
exec spSaveFinancialNumberTypes 'E','EFF_RATIO','Efficiency Ratio','Efficiency Ratio','Ratio/Other',87,1126
exec spSaveFinancialNumberTypes 'E','SOLV_RATIO','Solvency Ratio','Solvency Ratio','Ratio/Other',88,1126
go

--Valuations
exec spSaveFinancialNumberTypes 'V','P/EPSRPT','P/E Reported','P/E Reported','Valuation',1,1126
exec spSaveFinancialNumberTypes 'V','P/EPSADJ','P/E Adjusted','P/E Adjusted','Valuation',2,1126
exec spSaveFinancialNumberTypes 'V','REL_EPSRPT','REL P/E Reported','REL P/E Reported','Valuation',3,1126
exec spSaveFinancialNumberTypes 'V','REL_EPSADJ','REL P/E Adjusted','REL P/E Adjusted','Valuation',4,1126
exec spSaveFinancialNumberTypes 'V','PEG','PEG Reported','PEG Reported','Valuation',5,1126
exec spSaveFinancialNumberTypes 'V','PEGADJ','PEG Adjusted','PEG Adjusted','Valuation',6,1126
exec spSaveFinancialNumberTypes 'V','P/BV','P/B','P/B','Valuation',7,1126
exec spSaveFinancialNumberTypes 'V','P/TBV','P/TB','P/TB','Valuation',8,1126
exec spSaveFinancialNumberTypes 'V','P/OCF','P/CFO','P/CFO','Valuation',9,1126
exec spSaveFinancialNumberTypes 'V','P/SALES','P/Sales','P/Sales','Valuation',10,1126
exec spSaveFinancialNumberTypes 'V','P/FCF','P/FCF','P/FCF','Valuation',11,1126
exec spSaveFinancialNumberTypes 'V','EV/SALES','EV/Sales','EV/Sales','Valuation',12,1126
exec spSaveFinancialNumberTypes 'V','EV/EBITDA','EV/EBITDA','EV/EBITDA','Valuation',13,1126
exec spSaveFinancialNumberTypes 'V','EV/EBITA','EV/EBITA','EV/EBITA','Valuation',14,1126
exec spSaveFinancialNumberTypes 'V','EV/EBIT','EV/EBIT','EV/EBIT','Valuation',15,1126
exec spSaveFinancialNumberTypes 'V','EV/CE','EV/CE','EV/CE','Valuation',16,1126
exec spSaveFinancialNumberTypes 'V','EV/FCF','EV/FCF','EV/FCF','Valuation',17,1126
exec spSaveFinancialNumberTypes 'V','EV/FCF_UNLEV','EV/FCF (Unlevered)','EV/FCF (Unlevered)','Valuation',18,1126
exec spSaveFinancialNumberTypes 'V','DIVYIELD','Div Yield','Div Yield','Valuation',19,1126
exec spSaveFinancialNumberTypes 'V','FCFYIELD','FCF Yield','FCF Yield','Valuation',20,1126
go

-- UPDATE ADDITIONAL FIELDS FOR NEW MNEMONICS

-- Formula
update FinancialNumberTypes set Formula = '[EV]/[FCF_UNLEV]' where FinancialNumberType = 'EV/FCF_UNLEV'
GO

--Initialize IsPerShare & IsPercent
update FinancialNumberTypes set IsPerShare = 0, IsPercent = 0 where FinancialNumberType in
('MGMT_FEE',
'NET_REAL_PERF_FEE',
'SGA',
'RD',
'CREDIT_COST',
'FEE_REL_EARN',
'DIST_EARN',
'DIST_PS',
'FEE_REL_EPS',
'NET_REAL_PERF_FEE_PS',
'ECON_NET_INC_PS',
'NON_PERF_LOAN',
'CET1',
'DA',
'FCF_UNLEV',
'NET_REV_YIELD',
'ADJ_OPER_MARGIN',
'ROIC_EX_INTANG',
'ROA',
'LOCAL_CUR_SALES_GROWTH',
'LFL_SALES_GROWTH',
'BV_GROWTH',
'CAPEXSALES',
'NETDEBTEQUITY',
'NON_PERF_LOAN_PCT',
'AUM',
'AUM_FEE_PAY',
'AUM_FEE_PAY_GROWTH',
'FEE_RATE',
'NET_FLOWS',
'EFF_RATIO',
'SOLV_RATIO',
'EV/FCF_UNLEV')

--4/4/2016
update FinancialNumberTypes set IsPerShare = 0, IsPercent = 0
where FinancialNumberType = 'NETDEBT_EST' 

update FinancialNumberTypes set IsPerShare = 1, IsPercent = 0
where FinancialNumberType = 'EPS_ALT' 

-- IsPerShare
update FinancialNumberTypes set IsPerShare = 1
where FinancialNumberType in
('DIST_PS',
'FEE_REL_EPS',
'NET_REAL_PERF_FEE_PS',
'ECON_NET_INC_PS')

-- IsPercent
update FinancialNumberTypes set IsPercent = 1, Format = '%'
where FinancialNumberType in
('NET_REV_YIELD',
'LOCAL_CUR_SALES_GROWTH',
'LFL_SALES_GROWTH',
'BV_GROWTH',
'NON_PERF_LOAN_PCT',
'AUM_FEE_PAY_GROWTH',
'EFF_RATIO')

-- Format
update FinancialNumberTypes set Format = 'x'
where FinancialNumberType in
('ADJ_OPER_MARGIN',
'ROIC_EX_INTANG',
'ROA',
'CAPEXSALES',
'NETDEBTEQUITY',
'EV/FCF_UNLEV')

-- FormulaPassNo
update FinancialNumberTypes set FormulaPassNo = 1
where FinancialNumberType = 'EV/FCF_UNLEV'

--Definition
-- select * from FinancialNumberTypes where isnull(Definition,'') <> isnull(FullName,'') 
update FinancialNumberTypes set Definition = FullName
update FinancialNumberTypes set Definition = 'Operating Cash Flow' where FinancialNumberType = 'OCF'

-- Populate FinancialSetExclusions for the new FinancialNumberTypes that are added
select FinancialNumberTypeId,FinancialNumberType
into #Tmp_FinancialTypeAdditions
from FinancialNumberTypes
where FinancialNumberType in
('MGMT_FEE',
'NET_REAL_PERF_FEE',
'SGA',
'RD',
'CREDIT_COST',
'FEE_REL_EARN',
'DIST_EARN',
'DIST_PS',
'FEE_REL_EPS',
'NET_REAL_PERF_FEE_PS',
'ECON_NET_INC_PS',
'NON_PERF_LOAN',
'CET1',
'DA',
'FCF_UNLEV',
'NET_REV_YIELD',
'ADJ_OPER_MARGIN',
'ROIC_EX_INTANG',
'ROA',
'LOCAL_CUR_SALES_GROWTH',
'LFL_SALES_GROWTH',
'BV_GROWTH',
'CAPEXSALES',
'NETDEBTEQUITY',
'NON_PERF_LOAN_PCT',
'AUM',
'AUM_FEE_PAY',
'AUM_FEE_PAY_GROWTH',
'FEE_RATE',
'NET_FLOWS',
'EFF_RATIO',
'SOLV_RATIO',
'EV/FCF_UNLEV')

insert into FinancialSetExclusions(CompanyId, FinancialNumberTypeId, EditorId, EditDate)
select distinct CompanyId, T.FinancialNumberTypeId, 1126, GETDATE()
from FinancialCompanySettings FN cross join #Tmp_FinancialTypeAdditions T

drop table #Tmp_FinancialTypeAdditions
go

