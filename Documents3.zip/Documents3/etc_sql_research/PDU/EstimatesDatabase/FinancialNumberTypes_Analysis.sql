-- FinancialNumberTypes_Analysis.sql
-- 06/24/2016


/*

ShortName must fit in grid

Word column width:     0.930"
Word column indent:  - 0.930"
Excel column width:  = 0.874"
Excel rounds down to:  0.86"

To test in Excel:
Paste ShortName query results
Set column font:  Theinhardt Regular 
Set column width: 10.57

*/

select * from FinancialNumberTypes

select len(FullName), FullName, * from FinancialNumberTypes order by 1 desc

select top 50 len(ShortName), ShortName, * from FinancialNumberTypes order by 1 desc

select top 50 len(ShortName), ShortName + isnull(Format, ''), * from FinancialNumberTypes order by 1 desc

-- Financials
select top 20
  len(ShortName + ' (M)' + case when Format is not null then ' (' + Format + ')' else '' end) as 'len(Text)',
  ShortName + ' (M)' + case when Format is not null then ' (' + Format + ')' else '' end as Text,
  FinancialNumberType,
  *
from FinancialNumberTypes 
where FinancialNumberTypeCat = 'E'
order by 1 desc

-- Valuations
select top 20 
  len(ShortName +  case when Format is not null then ' (' + Format + ')' else '' end) as 'len(Text)',
  ShortName + case when Format is not null then ' (' + Format + ')' else '' end as Text
from FinancialNumberTypes 
where FinancialNumberTypeCat = 'V'
order by 1 desc

-- FullName <> ShortName
select FinancialNumberType, FinancialNumberTypeCat, FinancialNumberTypeCatOrd, FullName, ShortName from FinancialNumberTypes
where FullName <> ShortName order by FinancialNumberTypeCat, FinancialNumberTypeCatOrd

select FinancialNumberType, FullName, Definition from FinancialNumberTypes
where FullName <> Definition

--

select * from FinancialNumberTypes where FinancialNumberType = 'EPS_ALT' -- EPS (Pricing Cur)

--

select * from FinancialNumberTypes
--order by FinancialNumberTypeCatOrd
order by FinancialNumberTypeCat, IsPerShare, FinancialNumberTypeCatOrd

-- Format x only relevant to Valuations an Per Share estimates
-- Estimate submissions where Format is x are not assumed to be enterprise value
select * from FinancialNumberTypes where Format = 'x'
order by FinancialNumberTypeCat, IsPerShare, FinancialNumberTypeCatOrd

-- Financials with /
select * from FinancialNumberTypes
where FinancialNumberTypeCat = 'E' and ShortName like '%/%'
order by FinancialNumberTypeCat, IsPerShare, FinancialNumberTypeCatOrd

select * from FinancialNumberTypes
where FullName like'%Assets%'


--order by FinancialNumberTypeCatOrd
order by FinancialNumberTypeCat, IsPerShare, FinancialNumberTypeCatOrd

exec sp_helptext spGetFinancialSettings
go

declare
--  @SecurityId             int,
  @IsModelTicker          char(1),
  @BaseYear               char(4),
  @EpsId                  int,
  @ValuationId            int,
  @ExchangeCurCode        varchar(20),
  @ModelCurCode           varchar(20),
  @NumberUnitCode         varchar(20),
  @UnitMultiplier         varchar(20),
  @OnReportFinancialCount int,
  @OnReportValuationCount int

exec spGetFinancialSettings
  1458, -- 2628.HK
  @IsModelTicker,
  @BaseYear,
  @EpsId,
  @ValuationId,
  @ExchangeCurCode,
  @ModelCurCode,
  @NumberUnitCode,
  @UnitMultiplier,
  @OnReportFinancialCount,
  @OnReportValuationCount

