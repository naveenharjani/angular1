--Part of Estimate Set (capex/sales)
select Last, Ticker, Company
into #tmpESCapexSalesVal
from ResearchCoverage RC
join Authors A on RC.AnalystId = A.AuthorId
join Securities2 S on RC.SecurityId = S.SecurityId
where CompanyId in
(select distinct CompanyId from FinancialSetExclusions
where companyid not in
(select CompanyId from FinancialSetExclusions
where FinancialNumberTypeId = (select FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'capex/sales')))
and RC.LaunchDate is not null and RC.DropDate is null
order by Ticker

--Part of Report Set (capex/sales)
select Last, Ticker, Company
into #tmpRSCapexSalesVal
from ResearchCoverage RC
join Authors A on RC.AnalystId = A.AuthorId
join Securities2 S on RC.SecurityId = S.SecurityId
where CompanyId in
(select distinct CompanyId from FinancialReportSettings
where FinancialNumberTypeId = (select FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'capex/sales'))
and RC.LaunchDate is not null and RC.DropDate is null
order by Ticker

--Part of Estimate Set (capexsales)
select Last, Ticker, Company
into #tmpESCapexSalesEst
from ResearchCoverage RC
join Authors A on RC.AnalystId = A.AuthorId
join Securities2 S on RC.SecurityId = S.SecurityId
where CompanyId in
(select distinct CompanyId from FinancialSetExclusions
where companyid not in
(select CompanyId from FinancialSetExclusions
where FinancialNumberTypeId = (select FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'capexsales')))
and RC.LaunchDate is not null and RC.DropDate is null
order by Ticker

--Part of Report Set (capexsales)
select Last, Ticker, Company
into #tmpRSCapexSalesEst
from ResearchCoverage RC
join Authors A on RC.AnalystId = A.AuthorId
join Securities2 S on RC.SecurityId = S.SecurityId
where CompanyId in
(select distinct CompanyId from FinancialReportSettings
where FinancialNumberTypeId = (select FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'capexsales'))
and RC.LaunchDate is not null and RC.DropDate is null
order by Ticker

--Ticker with both capex/sales and capexsales as part of estimate set
select * 
into #tmpESCapexSalesPresent
from #tmpESCapexSalesVal
where ticker in (select ticker from #tmpESCapexSalesEst)

select * from #tmpESCapexSalesPresent

declare @FinancialNumberTypeId int
select @FinancialNumberTypeId = FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'capexsales'

/*
declare @FinancialNumberTypeId int
select @FinancialNumberTypeId = FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'capexsales'

select FS.*
from FinancialSetExclusions FS join Securities2 S on  FS.CompanyId = S.CompanyId
join #tmpESCapexSalesVal T  on S.Ticker = T.Ticker 
where FinancialNumberTypeId = @FinancialNumberTypeId

*/
--add capexsales estimate to estimate set for the teams who had capex/sales in report set.
delete FinancialSetExclusions
from FinancialSetExclusions FS join Securities2 S on  FS.CompanyId = S.CompanyId
join #tmpESCapexSalesVal T  on S.Ticker = T.Ticker 
where FinancialNumberTypeId = @FinancialNumberTypeId

--add capexsales estimate to report set for the teams who had capex/sales in report set.
insert into FinancialReportSettings(CompanyId,FinancialNumberTypeId,EditorId,EditDate)
select CompanyId,@FinancialNumberTypeId,1126,getdate()
from #tmpRSCapexSalesVal T join Securities2 S on T.Ticker = S.Ticker 

--Remove capex/sales valuation from the system
select * from FinancialSetExclusions where financialnumbertypeid = 71
select * from FinancialReportSettings where financialnumbertypeid = 71
select * from Valuations where financialnumbertypeid = 71
select * from FinancialNumberTypes where financialnumbertypeid = 71

delete from FinancialSetExclusions where FinancialNumberTypeId = (select FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'capex/sales')
delete from FinancialReportSettings where FinancialNumberTypeId = (select FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'capex/sales')
delete from Valuations where FinancialNumberTypeId = (select FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'capex/sales')
delete from FinancialNumberTypes where FinancialNumberType = 'capex/sales'
