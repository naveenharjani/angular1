-- 11/29/2016
-- Metrics added for Katrina Fu / China & Hong Kong Property
select FinancialNumberTypeCat, 'LastOrd' = max(FinancialNumberTypeCatOrd) from FinancialNumberTypes group by FinancialNumberTypeCat order by 1

/*
Total Debt � millions , reporting curr
Total Equity - millions , reporting curr
NAV/Sh � Per share 

Net Gearing (%)
Contracted Sales Value - mn, reporting currency �operational data
Land Bank Coverage Years (x) � operation data
Interest Coverage (x) - 
Asset Turnover (x)
*/

exec spSaveFinancialNumberTypes 'E','TOTAL_DEBT','Total Debt','Total Debt', 'BS',45,1126
exec spSaveFinancialNumberTypes 'E','TOTAL_EQUITY','Total Equity','Total Equity','BS',46,1126

exec spSaveFinancialNumberTypes 'E','NAVPS','Nav/Share','Nav/Sh','Ratio/Other',97,1126
exec spSaveFinancialNumberTypes 'E','NET_GEARING','Net Gearing', 'Net Gearing', 'Ratio/Other',98,1126
exec spSaveFinancialNumberTypes 'E','CONTRACTED_SALES_VALUE', 'Contracted Sales Value', 'Contracted Sales Value', 'Ratio/Other',99,1126
exec spSaveFinancialNumberTypes 'E','LAND_BANK_COVERAGE_YEARS', 'Land Bank Coverage Years', 'Land Bank Coverage Years', 'Ratio/Other',100,1126
exec spSaveFinancialNumberTypes 'E','INTEREST_COVERAGE', 'Interest Coverage', 'Interest Coverage', 'Ratio/Other',101,1126
exec spSaveFinancialNumberTypes 'E','ASSET_TURNOVER', 'Asset Turnover', 'Asset Turnover', 'Ratio/Other',102,1126

update FinancialNumberTypes set Definition = FullName , IsPerShare = 0, IsPercent = 0
where FinancialNumberType in ('TOTAL_DEBT','TOTAL_EQUITY','CONTRACTED_SALES_VALUE')

update FinancialNumberTypes set Definition = FullName , IsPerShare = 0, IsPercent = 1, Format = '%'
where FinancialNumberType in ('NET_GEARING')

update FinancialNumberTypes set Definition = FullName , IsPerShare = 1, IsPercent = 0, Format = 'x'
where FinancialNumberType in ('INTEREST_COVERAGE','ASSET_TURNOVER','LAND_BANK_COVERAGE_YEARS')

update FinancialNumberTypes set Definition = FullName , IsPerShare = 1, IsPercent = 0
where FinancialNumberType in ('NAVPS')

-- Populate FinancialSetExclusions for the new FinancialNumberTypes that are added
select FinancialNumberTypeId,FinancialNumberType
into #Tmp_FinancialTypeAdditions
from FinancialNumberTypes
where FinancialNumberType in
('TOTAL_DEBT','TOTAL_EQUITY','CONTRACTED_SALES_VALUE','NET_GEARING','INTEREST_COVERAGE','ASSET_TURNOVER','NAVPS')

insert into FinancialSetExclusions(CompanyId, FinancialNumberTypeId, EditorId, EditDate)
select distinct CompanyId, T.FinancialNumberTypeId, 1126, GETDATE()
from FinancialCompanySettings FN cross join #Tmp_FinancialTypeAdditions T

drop table #Tmp_FinancialTypeAdditions
go

-- 01/09/2017
-- Min Zhou / Katrina Fu
-- Shorten to fit

select * from FinancialNumberTypes
where FinancialNumberType in ('CONTRACTED_SALES_VALUE', 'LAND_BANK_COVERAGE_YEARS')

update FinancialNumberTypes
set FullName = 'Contracted Sales', ShortName = 'Contracted Sales' where FinancialNumberType = 'CONTRACTED_SALES_VALUE'

update FinancialNumberTypes
set FullName = 'Land Bank Cov Yrs', ShortName = 'Land Bank Cov Yrs' where FinancialNumberType = 'LAND_BANK_COVERAGE_YEARS'

