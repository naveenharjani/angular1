--04/17/2018
/*
From: Zheng, Jimmy 
Sent: 17 April 2018 10:05
To: ISTG-Research <ISTG-Research@alliancebernstein.com>
Subject: Mistakenly rollover the model

HI team,

Apologies that for model 384 HK, I mistakenly rolled over the financials �report FY as actual�. Could you please help to reverse that? (should be 2016A and 2017E) Sorry for inconvenience caused.

Regards,

Jimmy Zheng
Research Associate
T +852 2918 5279
jimmy.zheng@bernstein.com
*/

/*
Steps: 
1. Delete rows from FinancialNumbers for BaseYear 2017
2. Update BaseYear in FinancialCompanySettings to 2016

select * from FinancialNumbers
where
SecurityId = 1988 and
BaseYear = 2017

delete from FinancialNumbers
where
SecurityId = 1988 and
BaseYear = 2017

update FinancialCompanySettings
set BaseYear = 2016
where
CompanyId in (select CompanyId from Securities2 where SecurityId = 1988)
*/