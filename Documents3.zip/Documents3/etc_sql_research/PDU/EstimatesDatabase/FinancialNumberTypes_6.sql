-- FinancialNumberTypes_6.sql

select * from FinancialNumberTypes where FinancialNumberTypeCat = 'M'
order by FinancialNumberTypeCatOrd

-- 06/06/2016
update FinancialNumberTypes set FullName = 'Indicated Div Yield', ShortName ='Indicated Div Yield', Definition = 'Indicated Div Yield'
where FinancialNumberType = 'EQY_DVD_YLD_IND' -- Formerly Dividend Yield

-- 06/06/2016
update FinancialNumberTypes set FullName = 'Perf 12M', ShortName ='Perf 12M', Definition = 'Perf 12M'
where FinancialNumberType = 'CHG_PCT_1YR' --  Formerly Perf 1Yr

-- 06/06/2015
update FinancialNumberTypes set IsPerShare = 1 where FinancialNumberType = 'NETDEBTEQUITY'

/*

-- Convert data to IsPerShare

select * from FinancialNumberTypes where FinancialNumberType = 'NETDEBTEQUITY'

select * from FinancialNumbers where FinancialNumberTypeId = 122 -- NETDEBTEQUITY

update FinancialNumbers set Value = UnitValue, UnitMultiplier = 1 where FinancialNumberTypeId = 122

*/

-- 06/21/2016
-- Metrics added for Deepa Venkateswaran / European Utilities

exec spSaveFinancialNumberTypes 'E','REG_ASSET_BASE','Regulated Asset Base','Regulated Asset Base','BS',43,1126
exec spSaveFinancialNumberTypes 'E','ECON_NET_DEBT','Economic Net Debt','Economic Net Debt','BS',44,1126

update FinancialNumberTypes set Definition = FullName , IsPerShare = 0, IsPercent = 0
where FullName in ('Regulated Asset Base','Economic Net Debt') 

-- Populate FinancialSetExclusions for the new FinancialNumberTypes that are added
select FinancialNumberTypeId,FinancialNumberType
into #Tmp_FinancialTypeAdditions
from FinancialNumberTypes
where FinancialNumberType in
('REG_ASSET_BASE',
'ECON_NET_DEBT')

insert into FinancialSetExclusions(CompanyId, FinancialNumberTypeId, EditorId, EditDate)
select distinct CompanyId, T.FinancialNumberTypeId, 1126, GETDATE()
from FinancialCompanySettings FN cross join #Tmp_FinancialTypeAdditions T

drop table #Tmp_FinancialTypeAdditions
go

-- TBD
update FinancialNumberTypes set FullName = 'ROIC ex Intan', ShortName ='ROIC ex Intan', Definition = 'ROIC Excluding Goodwill and Intangibles'
where FinancialNumberType = 'ROIC_EX_INTANG'

update FinancialNumberTypes set FullName = 'Comp Sales Growth', ShortName ='Comp Sales Growth', Definition = 'Like-For-Like Sales Growth'
where FinancialNumberType = 'LFL_SALES_GROWTH'

update FinancialNumberTypes set FullName = 'Comp Stor Sale Grw', ShortName ='Comp Stor Sale Grw', Definition = 'Comp Store Sales Growth'
where FinancialNumberType = 'COMPSTORESALESGROWTH'
