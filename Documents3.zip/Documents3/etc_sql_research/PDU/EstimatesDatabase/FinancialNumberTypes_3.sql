--FinancialNumberTypesPDU.sql
-- 11/10/2015
select * from FinancialNumberTypes where FinancialNumberType = 'NETDEBT_EST'
--Rename EPS Growth/Share to EPS Growth
--update FinancialNumberTypes set FullName = 'EPS Growth', ShortName = 'EPS Growth', Definition = 'EPS Growth'
--where FinancialNumberType = 'EPSGROWTH'

--Rename PEG to PEG Reported
--update FinancialNumberTypes set FullName = 'PEG Reported', ShortName = 'PEG Reported', Definition = 'PEG Reported'
--where FinancialNumberType = 'PEG'

--Add PEG Adjusted
--exec spSaveFinancialNumberTypes 'V', 'PEGADJ', 'PEG Adjusted',6,1129

--update FinancialNumberTypes set FullName = 'PEG Adjusted', ShortName = 'PEG Adjusted', Definition = 'PEG Adjusted', Formula='[P/EPSADJ]/[EPSGROWTH]', FormulaPassNo = 2 
--where FinancialNumberType = 'PEGADJ' 

--Rename CE to Common Equity
--update FinancialNumberTypes set FullName = 'Common Equity', ShortName = 'Common Equity', Definition = 'Common Equity'
--where FinancialNumberType = 'CE' 

--Add two financial codes "Organic Sales Growth" & "Comp Store Sales Growth"
--exec spSaveFinancialNumberTypes 'E', 'ORGSALESGROWTH', 'Organic Sales Growth',37,1129
--exec spSaveFinancialNumberTypes 'E', 'COMPSTORESALESGROWTH', 'Comp Store Sales Growth',38,1129

--update FinancialNumberTypes set FullName = 'Organic Sales Growth', ShortName = 'Organic Sales Growth', Definition = 'Organic Sales Growth', IsPercent = 1, Format = '%'
--where FinancialNumberType = 'ORGSALESGROWTH' 

--update FinancialNumberTypes set FullName = 'Comp Store Sales Growth', ShortName = 'Comp Store Sales Growth', Definition = 'Comp Store Sales Growth', IsPercent = 1, Format = '%'
--where FinancialNumberType = 'COMPSTORESALESGROWTH' 

--Rename "Total Expenses" to "Operating Expenses"
--update FinancialNumberTypes set FullName = 'Operating Expenses', ShortName = 'Operating Expenses', Definition = 'Operating Expenses'
--where FinancialNumberType = 'EXP' 

--Add "Net Debt" estimate ("Net Debt" as a market data element exists already)
--exec spSaveFinancialNumberTypes 'E', 'NETDEBT_EST', 'Net Debt',23,1129

--update FinancialNumberTypes set FullName = 'Net Debt', ShortName = 'Net Debt', Definition = 'Net Debt'
--where FinancialNumberType = 'NETDEBT_EST' 

--Add "Net Debt/EBITDA" estimate 
--exec spSaveFinancialNumberTypes 'E', 'NETDEBTEBITDA', 'Net Debt',24,1129

--update FinancialNumberTypes set FullName = 'Net Debt/EBITDA', ShortName = 'Net Debt/EBITDA', Definition = 'Net Debt/EBITDA'
--where FinancialNumberType = 'NETDEBTEBITDA' 

--12/10/2015
--Updated NetDebt/Ebitda estimate as pershare. Otherwise it is treated as an enterprise value and is stored in millions.
--That should not be the case with this estimate as this is a ratio.
--update FinancialNumberTypes set IsPerShare = 1, IsPercent=0, Format = 'x'
--where FinancialNumberType = 'NETDEBTEBITDA'

--Delete 'Net Debt/EBITDA' valuation
/*
declare @FinancialNumberTypeId int
select @FinancialNumberTypeId = FinancialNumberTypeId from FinancialNumberTypes where FinancialNumberType = 'NETDEBT/EBITDA'

delete Valuations where FinancialNumberTypeId = @FinancialNumberTypeId
delete FinancialSetExclusions where FinancialNumberTypeId = @FinancialNumberTypeId
delete FinancialReportSettings where FinancialNumberTypeId = @FinancialNumberTypeId
delete FinancialSecurityOverrideSettings where FinancialNumberTypeId = @FinancialNumberTypeId
delete from FinancialNumberTypes where FinancialNumberTypeId = @FinancialNumberTypeId
*/



