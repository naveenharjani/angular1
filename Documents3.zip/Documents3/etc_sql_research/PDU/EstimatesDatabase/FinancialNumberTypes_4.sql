-- FinancialNumberTypes_4.sql
-- 02/26/2016

--Definition

select * from FinancialNumberTypes where isnull(Definition,'') <> isnull(FullName,'')

select * from FinancialNumberTypes where FinancialNumberType like '%&%'

-- update FinancialNumberTypes set Definition = FullName

-- update FinancialNumberTypes set Definition = '' where FinancialNumberType = ''

update FinancialNumberTypes set Definition = 'Operating Cash Flow' where FinancialNumberType = 'OCF'
update FinancialNumberTypes set Definition = 'Common Equity Tier 1' where FinancialNumberType = 'CET1'
update FinancialNumberTypes set Definition = 'Common Equity Tier 1 Ratio' where FinancialNumberType = 'CET1_PCT'
update FinancialNumberTypes set Definition = 'Return On Assets' where FinancialNumberType = 'ROA'
update FinancialNumberTypes set Definition = 'Return On Total Assets' where FinancialNumberType = 'ROTA'
update FinancialNumberTypes set Definition = 'Return On Equity' where FinancialNumberType = 'ROE'
update FinancialNumberTypes set Definition = 'Return On Common Equity' where FinancialNumberType = 'ROCE' -- Return On Capital Employed
update FinancialNumberTypes set Definition = 'Return On Tangible Common Equity' where FinancialNumberType = 'ROTCE'
update FinancialNumberTypes set Definition = 'Selling, General And Administrative Expenses' where FinancialNumberType = 'SGA'
update FinancialNumberTypes set Definition = 'Discounted Cash Flow' where FinancialNumberType = 'DCF'
update FinancialNumberTypes set Definition = 'Free Cash Flow' where FinancialNumberType = 'FCF'
update FinancialNumberTypes set Definition = 'Depreciation And Amortization' where FinancialNumberType = 'DA'
update FinancialNumberTypes set Definition = 'Research And Development' where FinancialNumberType = 'RD'
