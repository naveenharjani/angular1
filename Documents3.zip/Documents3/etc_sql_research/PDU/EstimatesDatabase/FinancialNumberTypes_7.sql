--07/14/2016

--Grant D'avino (John McDonald's associate) pointed that ROA is displayed as ROA(x)(M) on financial grid for JPM
--This is because it is not marked as pershare item in the database.
--Updating ROA & ROIC_EX_INTANG as IsPerShare  1
update FinancialNumberTypes 
set IsPerShare = 1
where FinancialNumberType in ('ROIC_EX_INTANG','ROA')

--ROA should be expressed in %
update FinancialNumberTypes 
set IsPercent = 1, Format = '%'
where FinancialNumberType in ('ROA')