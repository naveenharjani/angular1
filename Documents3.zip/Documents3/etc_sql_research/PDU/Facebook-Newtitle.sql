--06/06/2017
--Request to add new title to Beehive facebook & Author Titles  
--new economist Philipp Carlsson-Szlezak

insert into FacebookTitles(Title,SortId,EditorId,EditDate)
select 'Chief U.S. Economist',99999,1126,getdate()

insert into AuthorTitles(Title,EditorId,EditDate)
select 'Chief U.S. Economist',1126,getdate()

