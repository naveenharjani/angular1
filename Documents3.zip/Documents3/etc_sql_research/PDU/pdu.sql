-- pdu.sql

-- 05/20/2011 Manual split adjustment for citigroup
update TickerTableSecurities set TargetPrice = '58.00' where Pubno = 80253 and Ticker = 'C'

-- 10/06/2011 Distribution: Update PdfLock attribute for Reuters
UPDATE DistributionSites SET PdfLock = 'N' WHERE Site = 'Reuters'

-- 10/14/2011 Expand meeting eligibility
update PublicationTypes set MeetingEligible = 'Y' where PublicationType in ('Black Book', 'White Book')
update PublicationTypes set MeetingEligible = 'N' where PublicationType in ('Flash') -- Legacy Flash retired

-- 02/08/2012 Assign LastName of SYSTEM to system id's
-- Looks better in Team Member Administration pop-up form
update Users set LastName = 'SYSTEM' where UserId = 0
update Users set LastName = 'SYSTEM' where UserName = 'ac\lonblp7'
update Users set LastName = 'SYSTEM' where UserName = 'ac\bloomberg15common'
update Users set LastName = 'SYSTEM' where UserName = 'ac\instuser1'
update Users set LastName = 'SYSTEM' where UserName = 'ac\scb morning call'
update Users set LastName = 'SYSTEM' where UserName = 'ac\webhost_svc'
update Users set LastName = 'SYSTEM' where UserName = 'ac\hkg_ss_marketdata'

select * from Users where LastName is null and Active = -1

--02/10/2012 Error notifications record for TickerSheetLoader Service
Insert into eventlognotifications(source,type,emailto,emailsubject)
select 'TickerSheetLoader Service','E','Krishna.Josyula@allianebernstein.com','SYSALERT ON PROD: TickerSheetLoader Service'

--03/14/2013 Added 2013A (as one of the companies) reported 2013 earnings to estimates periods table
insert into EstimatesPeriods(EstimatePeriod,EstimatePeriodDisplay,Active,EditorId,EditDate)
select '2012A/2013A/2014E/2015E/2016E','2013A',-1,1126,getdate()

--05/30/2013 SDC guide book not showing on iPad app. Permissions adjusted and refresh date updated 
--so it flows down to the device as part of research delta
update Publications set PublishedDate = getdate() where PubNo = 96224

--06/14/2013
--Insert related publication row for Max's chinese auto launch video
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 93834,93946,1126,getdate()

--06/20/2013
--Updated max's video to new brightcove id (transition from Tiffany's account to ours)
--to play with our new player id
--2165668091001 (old brightcove id)
update Publications set Filename = '2495195665001' where PubNo = 93834

-- 06/25/2013
-- Keywords - Switch from 'The Best of Bernstein' to 'Best of Bernstein'
select * from PropertyNames
select * from Keywords
select * from Properties where PropId = 9 and PropValue = 'The Best of Bernstein'
select * from Properties where PropId = 9 and PropValue = 'Best of Bernstein'
-- update Properties set PropValue = 'Best of Bernstein' where PropId = 9 and PropValue = 'The Best of Bernstein'
-- update Keywords set Keyword = 'Best of Bernstein' where Keyword = 'The Best of Bernstein'

--09/23/2013
/*
select * from properties where PropValue = 'VALE5.BZ'
SELECT * FROM TICKERTABLESECURITIES WHERE TICKER = 'VALE5.BZ'
select * from AnalystSettings where coverageid = (select coverageid from researchcoverage where securityid = (SELECT SECURITYID FROM Securities2 WHERE Ticker = 'VALE5.BZ'))
SELECT * FROM RESEARCHCOVERAGE WHERE SecurityID = (SELECT SECURITYID FROM Securities2 WHERE Ticker = 'VALE5.BZ')
go
select * from ResearchCoverage
where SecurityId = (select securityid from securities2 where ticker = 'TLSN.SS')  and 
AnalystId = (select authorid from Authors where name like '%Bienenstock%')
go
*/

--VALE5.BZ was never formally launched. It was accidentally included in Materials Blasts.
--Hence removing from related tables and dropping the coverage row.

DELETE FROM Properties where PropValue = 'VALE5.BZ'
go
DELETE FROM TickerTableSecurities WHERE Ticker = 'VALE5.BZ'
go
DELETE FROM AnalystSettings WHERE CoverageId = (select coverageid from researchcoverage where securityid = (SELECT SECURITYID FROM Securities2 WHERE Ticker = 'VALE5.BZ'))
go
DELETE FROM ResearchCoverage WHERE SecurityID = (SELECT SECURITYID FROM Securities2 WHERE Ticker = 'VALE5.BZ')
go

--TLSN.SS was never launched by Robin Bienenstock. It has a laundate(mysteriously) in researchcoverage table.
--Setting the launchdate to null so it does not appear on client reports.
--It was previously covered by O'Neill and was dropped on 03/26/2008

UPDATE ResearchCoverage SET LaunchDate = null 
where SecurityId = (select securityid from securities2 where ticker = 'TLSN.SS')  and 
AnalystId = (select authorid from Authors where name like '%Bienenstock%')
go

--10/14/2013
--GAZP.RM, LKOH.RM, NVTK.RM, ROSN.RM were not launched by Oswald Clint. They were accidentally included
--in the joint call 98816 and no analyst data(rating/tp/estimates) provided.
--Unlaunching the tickers by setting launch date to null using coverage administration tool
--Removing tickers from properties table using property editor tool.
--Deleting from tickertablesecurities table using the sql script below.

DELETE FROM TickerTableSecurities WHERE Ticker in ('GAZP.RM','LKOH.RM','NVTK.RM','ROSN.RM')

--10/15/2013
--TTMT/A.IN was not launched by Max Warburton. It was accidentally included
--in the joint call 98723 and no analyst data(rating/tp/estimates) provided.
--Unlaunching the tickers by setting launch date to null using coverage administration tool
--Removing tickers from properties table using property editor tool.
--Deleting from tickertablesecurities table using the sql script below.

DELETE FROM TickerTableSecurities WHERE Ticker in ('TTMT/A.IN')

--11/19/2013
--TTMT/A.IN was not launched by Max Warburton. It was accidentally included
--in the joint call 100137 and no analyst data(rating/tp/estimates) provided.
--Unlaunching the tickers by setting launch date to null using coverage administration tool
--Removing tickers from properties table using property editor tool.
--Deleting from tickertablesecurities table using the sql script below.
DELETE FROM TickerTableSecurities WHERE Ticker in ('TTMT/A.IN')

--11/19/2013
--SNGS.RM was not launched by Oswald Clint. It was accidentally included
--in the joint call 100089 and no analyst data(rating/tp/estimates) provided.
--Unlaunching the tickers by setting launch date to null using coverage administration tool
--Removing tickers from properties table using property editor tool.
--Deleting from tickertablesecurities table using the sql script below.
DELETE FROM TickerTableSecurities WHERE Ticker in ('SNGS.RM')

-- 12/03/2013
-- Updated Industry property for Ronny Gal reports after moving from 2 industries to 1 new global industry

-- SELECT * FROM Properties WHERE PropID = 11 AND PropValue = 'European Specialty Pharmaceuticals'
-- UPDATE Properties SET PropValue = 'Global Specialty Pharmaceuticals' WHERE PropID = 11 AND PropValue = 'European Specialty Pharmaceuticals'

-- SELECT * FROM Properties WHERE PropID = 11 AND PropValue = 'U.S. Pharmaceuticals/Specialty'
-- UPDATE Properties SET PropValue = 'Global Specialty Pharmaceuticals' WHERE PropID = 11 AND PropValue = 'U.S. Pharmaceuticals/Specialty'

--12/12/2013
--Pubno #97155 BT/A.LN & TALK.LN TargetPriceAction & EstimateAction not recorded in the database.
--Hence incorrect TP being displayed on the coverage screen for these two tickers.
UPDATE TickerTableSecurities SET TargetPriceAction = 'Increase' WHERE Ticker = 'BT/A.LN' and Pubno = 97155
UPDATE TickerTableSecurities SET TargetPriceAction = 'Increase', EstimateAction='Downgrade' WHERE Ticker = 'TALK.LN' and Pubno = 97155

--12/12/2013
--Analyst provided pre split targetprice after split effective date. Reverting back to post split target price.
UPDATE TickerTableSecurities Set TargetPrice = '1250.00' WHERE Ticker = '1605.JP' and Pubno = 99062 --Formerly 500000.00
--Analyst provided split adjusted targetprice and targetpriceaction before effective date. Reverting back to pre-split target price & action.
UPDATE TickerTableSecurities Set TargetPrice = '60.00', TargetPriceAction='Update' WHERE Ticker = 'BEN' and Pubno = 97491  --Formerly 20.00

--1/15/2014
--Split effective date for the ticker 1/9/2014 (adjustment factor 5.0)
--Analyst published call on 1/6/2014 with split adjusted price (37.00)
--spApplySplitActions applied the adustment factor again on this call to make the value 37/5 = 7.40
--Below pdu is to revert the value back
--As a followup to this, generated the price chart for the ticker and the master disclosures
UPDATE TickerTableSecurities set TargetPrice = TargetPriceOrig, TargetPriceOrig = NULL
WHERE
Ticker = 'NVO' and PubNo = 100840


--3/14/2014
--As per user feedback reduced the email buffer to 5 minutes(from 15 minutes)
--in case of immediate blast.
update Configuration set Value = 5 where Name = 'AnalystEmailBlastDelayMinutes'

--5/7/2014
--Dan Dowd not visible under available analyss on iPad app watch list screen.
--This is because status column is set to inactive ('0').
update Authors set status = 1,EditDate = getdate() where name like '%Daniel Dowd%'

--11/06/2014
--SNN stock split on 10/15/2014 with an adjustment factor of 2.5. 
--This was applied to db on 10/17/2014 and updated target price(historically) to $97/2.5 = $38.80
--But franchise wants to use post split $39.50 as TP due to ADR fx ratio on the split date.
--Updating TickerTableSecurities to set TargetPrice to $39.50 (historically)
--Updating the adjustment factor in SplitActions table to 2.4556

update TickerTableSecurities
set TargetPrice = '39.50'
where Ticker = 'SNN' and TargetPrice = '38.80'
and CloseDate <= '2014-10-15 00:00:00.000'

update SplitActions 
set AdjustmentFactor = 2.4556
where ticker = 'SNN' and SplitActionId = 713

--11/24/2014
--Asian Capital Goods - Due to opening of new Chinese exchange, china listed tickers (A-shares) of HongKong companies are 
--added to tickertable for the first time. 
--Updating TickerTableSecurities to revert auto initiation.
--SECONDARY LISTING - Set initial Coverage (NULL) and Rating (Reiterate) action tags
-- ACTION TAG RULE OVER-RIDE
update TickerTableSecurities
set CoverageAction = NULL, RatingAction = 'Reiterate'
where PubNo = 108691 and Ticker in ('000157.CH','600875.CH','601727.CH')


update TickerTableSecurities
set CoverageAction = NULL, RatingAction = 'Reiterate'
where PubNo = 108701 and Ticker in ('600050.CH')


--11/25/2014
-- Luke Montgomery published two reports one for BlackRock (BLK) & the other for Franklin (BEN) on 11/20/2014.
-- He included both the tickers with exactly same rating/tp/estimate changes on both the reports.
-- Publishing engine allows only one change per ticker per day.
-- Updating BEN to reiterate on Blackrock report & BLK to reiterate on Franklin resources report.
-- MULTIPLE REPORTS FOR DAY WITH SAME CHANGE
-- ACTION TAG RULE OVER-RIDE
update TickerTableSecurities 
set RatingAction = 'Reiterate', TargetPriceAction = 'Update'
where Pubno = 108661 and Ticker = 'BEN'

update TickerTableSecurities
set RatingAction = 'Downgrade',TargetPriceAction = 'Decrease'
where Pubno = 108662 and Ticker = 'BEN'

--01/08/2015
--As per Richard Wagner's email dated 1/6/2015 regarding 12-Month rating history disclosures
--Update Rating & RatingAction for ADR to match the value of primary ticker. This is to correct clerical error on franchise part.
update TickerTableSecurities set Rating = 'O', RatingAction = 'Upgrade' where PubNo = 62143 and Ticker = 'NOVN.VX'

--RHHBY & ROG.VX had coverage transfer from Jack Scannel to Tim Anderson on 7/17/2012
--Inorder for this change to appear under 12-month rating history mark the ratingchange as 'Initiate'
update TickerTableSecurities set RatingAction = 'Initiate' where PubNo = 89118 and Ticker in ('RHHBY','ROG.VX')

--Adding 2015A to the estimate period drop down.
insert into EstimatesPeriods(EstimatePeriod,EstimatePeriodDisplay,Active,EditorId,EditDate)
select '2014A/2015A/2016E/2017E/2018E','2015A',-1,1126,getdate()

-- 08/17/2015: Jamie Merriman video - link to blackbook
UPDATE RelatedPublications
SET RelatedPubNo = 115134 -- [New BlackBookId]
WHERE PubNo =  115135     -- [New VideoId]

 -- 08/17/2015 - Steve Winoker - Fix Brightcove Id
UPDATE Publications 
SET FileName = '4421198990001 AQ~~,AAAB_76joXk~,qoMsJf4kpT7QfntRqY09MyF-BE4qZINl 4421172112001'
where pubno = 115138

--change linked call to from August 5th
UPDATE RelatedPublications
SET RelatedPubNo = 114857 -- [Call]
WHERE PubNo =  115138     -- [New VideoId]

-- Auto blast was sent out to only the first item in the Blast List(s) in the document
-- Fix Instancing: multi(-1) for PublicationType=Primer & Property=BlastList
update propertysets set instancing = -1 where publicationtypeid = 11 and propid = 34

--09/22/2015
--Add new author title for a new european strategist
INSERT INTO AuthorTitles(Title,EditorID,EditDate)
SELECT 'Global Quantitative and European Equity Strategist',1126,GETDATE()

--11/02/2015
--Data cleanup. Delete inactive industry(never launched) "Directors Nuggets" from coverage and industries table.
DELETE FROM ResearchCoverage WHERE IndustryId in (select IndustryId from Industries WHERE IndustryName like '%Directors Nuggets%')
DELETE FROM Industries WHERE IndustryName like '%Directors Nuggets%'

--11/02/2015
--HPQ/HPE Spinoff on 11/02/2015. Bloomberg did not provide with the HPQ split adjustment factor. So manually inserted into SplitActions table
INSERT INTO SplitActions(LoadDate, Ticker,SecurityId, EffectiveDate, AdjustmentFactor, AppliedStatus, AppliedDate)
SELECT getdate(), 'HPQ', 279, '2015-11-02 00:00:00.000', 2.2026, 'N', NULL

--11/12/2015
--Realigned ULVR.LN & UL under primary company Univlever NV (UNA.NA) using security admin screen
--This updated the company id and also changed the company name in securities table to "Unileverl NV"
--Reverting the company in securities table back to "Unilever PLC" as london listing has a  different company name
UPDATE Securities2 SET Company = 'Unilever PLC' WHERE Ticker in ('ULVR.LN', 'UL')


--12/08/2015
--Realigned BHP.AU & BHP under primary company  (BHBHP Billiton PLCP.LN) using security admin screen
--This updated the company id and also changed the company name in securities table to "BHP Billiton PLC"
--Reverting the company in securities table back to "BHP Billiton Ltd" as australian listing has a different company name
UPDATE Securities2 SET Company = 'BHP Billiton Ltd' WHERE Ticker in ('BHP.AU', 'BHP')


--12/04/2015
--200625.CH (Chongqing Changan Automobile Co Ltd) trades in shanghai exchange(.CH) in HKD
--currencly the system maps every ticker traded in .CH exchange to CNY currency code
--Manual override to set the price currency for this ticker to HKD
update Securities2 set CurrencyCode = 'HKD' where Ticker = '200625.CH'
update FSS set CurCode = 'HKD' 
from FinancialSecuritySettings FSS join Securities2 S on FSS.SecurityId = S.SecurityID
where S.Ticker = '200625.CH'

--12/14/2015
--Realigned REN.NA under primary company  (Reed Elsevier PLC REL.LN) using security admin screen
--This updated the company id and also changed the company name in securities table to "Reed Elsevier PLC"
--Reverting the company in securities table back to "Reed Elsevier NV" as dutch listing has a different company name
UPDATE Securities2 SET Company = 'Reed Elsevier NV' WHERE Ticker in ('REN.NA')

--12/17/2015
--Previously Revenues(SALES) was a required field for estimate set and report set.
--During migrations realized that revenue is not applicable for some sectors.
--Updated the setting to IsRequired = false
update FinancialNumberTypes set IsRequiredSet = 0, IsRequiredReport = 0
where FinancialNumberType = 'sales'

-- 05/12/2016 - iPad RVDocBullets Highlights test (006400.KS)

select * from Properties where PubNo = 121453 and PropId in (24, 25, 26)

update Properties set PropValue = '<p><span>On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document. </span></p>'
where PropNo = 2611486 and PubNo = 121453

update Properties set PropValue = 'Samsung SDI Q1''16 numbers missed all estimates on large one-time items including provisions for a new early retirement program, and a revaluation of an old EV battery line. However, adjusted OP came inline with our earlier estimates.'
where PropNo = 2611486 and PubNo = 121453

--09/26/2016
--Use special characters in Company name - Nestl� (NESN.VX)
--Do not re-save in UI!  Characters will be replaced
update Companies   set Company = 'Nestl�' where Company = 'Nestle'
update Securities2 set Company = 'Nestl�' where Company = 'Nestle'
update Companies   set EditDate = getdate() where Company = 'Nestl�'
update Securities2 set EditDate = getdate() where Company = 'Nestl�'

--09/26/2016
--Use special characters in Company name - L'or�al (OR.FP)
--Do not re-save in UI!  Characters will be replaced
update Companies   set Company = 'L''or�al' where Company = 'L''oreal'
update Securities2 set Company = 'L''or�al' where Company = 'L''oreal'
update Companies   set EditDate = getdate() where Company = 'L''or�al'
update Securities2 set EditDate = getdate() where Company = 'L''or�al'

-- 10/24/2016
--Use special characters in Company name - R�my Cointreau SA (RCO.FP)
--Do not re-save in UI!  Characters will be replaced
update Companies   set Company = 'R�my Cointreau SA', EditDate = getdate() where Company = 'Remy Cointreau SA'
update Securities2 set Company = 'R�my Cointreau SA', EditDate = getdate() where Company = 'Remy Cointreau SA'

-- 07/12/2017: 
-- Analyst Settings Administration: Missing rows on this page for new Analyst 'Vincent Chen'
update MigratedAnalysts set editorid = 1229 where analystid = 697

--04/02/2019
-- Change base year for '6324.JP' to 2017
update financialcompanysettings set baseyear = 2017 where companyid = 1806

--04/04/2019
-- Change base year for 002251.CH and 603708.CH to 2017 (Melinda Hu)
update financialcompanysettings set baseyear = 2017 where companyid = 1819  -- 002251.CH
update financialcompanysettings set baseyear = 2017 where companyid = 1820  -- 603708.CH 


--04/25/2019
--Update report type Primer to Research Call.
update Publications set Type = 'Research Call' where Type = 'Primer'
go

--Retain Keyword 'Primer' and delete Publication Type 'Primer' 
delete from DistributionSubscriptions where PublicationTypeId = 11
delete from PropertySets where PublicationTypeId = 11
delete from PublicationTypes where PublicationType = 'Primer'

--Retain Publication Type 'Video' and delete keyword 'Featured Video'
delete from Keywords where Keyword = 'Featured Video'
go

-- Fix data issue:, 2 tickers mapped(DD, DD-OLD) to same SecurityId, causing both tickers to show up in vFinancialsLatest report callers
update PublicationFinancials
set SecurityId = 166 
where
SecurityId = 1994 and
PubNo >= 132470 and PubNo <= 146939
go


/*08/28/2019*/
/*
Ticker: WORK -  launch call missing rating
Reason: Team did not enter rating draft in the tickersheet before submitting numbers to the database.
Outcome: Rating missing on the br.com company landing page and financials page and all client reports

Fix: 
1. Enter rating draft value in the published model and use "Save R/T/E as Live" to promote the draft rating to live.
2. Update rating in PublicationFinancials table using below sql
*/
update PublicationFinancials
set Rating = 'M'
where 
PubNo = 148531 and
ticker = 'Work'


-- 08/28/2020 -- Insert relevant links to Podcast
-- Podcast Title: Weekend@Bernstein: If we drink enough Moutai, we can solve anything, a conversation with Euan McLeish - 28 Aug
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 156734, 156641, 1229, getdate()
union
select 156734, 156604, 1229, getdate()
union
select 156734, 156443, 1229, getdate()
union
select 156734, 156382, 1229, getdate()
union
select 156734, 156160, 1229, getdate()

--02/10/2021 --Index videos & podcasts to elastic search (after the bug fix for indexing videos/podcasts)
insert into ElasticQueue(PubNo,Operation,Queued,QueuedBy)
select PubNo,'I',getdate(),'ac\kjosyu'
from Publications where type in ('Video','Podcast')

--01/28/2021 --Set Chimigura Danielle status to 'Active' to enable her row appear for research reads & Decks+
update authors set status = 1 where name like '%chimigura%'

--02/17/2021 --Set Zhihan Ma status to 'Active' to enable her row appear for research reads & Decks+
update authors set status = 1 where name like '%zhihan%'

--03/11/2021
--Related publications for podcast
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 160579,160382,1126,getdate()
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 160579,160252,1126,getdate()
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 160579,160125,1126,getdate()
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 160579,160110,1126,getdate()
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 160579,160010,1126,getdate()

--03/24/2021
--Two deleted documents & one document with blank distribution list
update AnalystBlastQueue
set Cancelled = getdate(), CancelledByUserId = 1126
where BlastId in (28899,27426,25497)

--05/06/2021
--Related publications for podcast
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 161875,160580,1126,getdate()
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 161875,160281,1126,getdate()
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 161875,159981,1126,getdate()

--05/25/2021
--Trevor stirling's initiation report on beer failed to publish.
--Security settings missing for launch ticker TAP (Molson Coors Beverage Company) 
insert into FinancialSecuritySettings(SecurityId,CurCode,UnitMultiPlier,EditorId,EditDate)
select 457,'USD',1000000,1126,getdate()


--07/21/2021
--(NVDA) starts trading post a 4-1 stock split on 07/20/2021. Bloomberg did not provide with the NVDA split adjustment factor. So manually inserted into SplitActions table
INSERT INTO SplitActions(LoadDate, Ticker,SecurityId, EffectiveDate, AdjustmentFactor, AppliedStatus, AppliedDate)
SELECT getdate(), 'NVDA', 1962, '2021-07-20 00:00:00.000', 4, 'N', NULL
-- [spApplySplitActions] 1962 -- @SecurityId

-- Stacy Rasgon asked to update live values (rounding post split)
SELECT * FROM FinancialNumbers WHERE SecurityId = 1962  -- NVDA
AND FinancialNumberTypeId IN (2, 4)  -- , EPSADJ
ORDER BY FinancialNumberTypeId asc, BaseYear desc, FinancialPeriodId
-- NVDA: Update TARGETPRICE to 181.00 from 181.25
SELECT * FROM FinancialNumbers WHERE FinancialNumberId = 2531670 AND SecurityId = 1962 AND FinancialNumberTypeId = 2
-- update FinancialNumbers SET Value = 181.00, UnitValue = 181.00 WHERE FinancialNumberId = 2531670
-- NVDA: Update EPSADJ FY2024 to 4.66 from 4.67
SELECT * FROM FinancialNumbers WHERE FinancialNumberId = 2531676 AND SecurityId = 1962 AND FinancialNumberTypeId = 4
-- update FinancialNumbers SET Value = 4.66, UnitValue = 4.66 WHERE FinancialNumberId = 2531676

--08/26/2021
--Related publications for podcast ("Podcast � Weekend@Bernstein � Sachet-Sizing the Banks� Gautam Chhugani on Paytm � 20 Aug")
-- SELECT * from RelatedPublications WHERE PubNo = 163919  
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 163919,163827,0,getdate()
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 163919,163534,0,getdate()
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 163919,163053,0,getdate()
insert into RelatedPublications(PubNo,RelatedPubNo,EditorId,EditDate)
select 163919,162994,0,getdate()


