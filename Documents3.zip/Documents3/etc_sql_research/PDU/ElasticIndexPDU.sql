--04/17/2020
--Historical re-index of all the documents in Publications table

--Total # of documents to be reindexed - 120346 
--Indexing rate - 2 docs/sec=7200/hr. At this rate it should take approx 18 hrs to reindex the whole repository
select count(*) from Publications where 
type not in ('Video','Podcast','Research Summary','Flash')
go

insert into ElasticQueue(PubNo,Operation,Queued,QueuedBy)
select PubNo,'I',getdate(),'ac\kjosyu'
from Publications
where 
type not in ('Video','Podcast','Research Summary')
order by PubNo
go

--Index start time --2020-04-17 15:05:05.537
--Index end time -- 2020-04-18 11:06:38.983

--spgetscheduledelasticqueueitems
--06/19/2020
insert into ElasticQueue(PubNo,Operation,Queued,QueuedBy)
select PubNo,'I',getdate(),'ac\kjosyu'
from Publications
where 
type not in ('Research Summary')
and date >= '04/17/2020'
order by PubNo
go


