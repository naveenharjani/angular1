-- Jobs.sql
-- 07/22/2020

-- update jobs table to change assembly info
SELECT * FROM Jobs Where Class IN ('WriteXML', 'Algo', 'ServiceManager', 'BloombergJobs')
GO

-- New
UPDATE Jobs SET Assembly = 'Bernstein.IRS.Jobs' Where Class = 'WriteXML'
UPDATE Jobs SET Assembly = 'Bernstein.IRS.Jobs' Where Class = 'Algo'
UPDATE Jobs SET Assembly = 'Bernstein.IRS.Jobs' Where Class = 'ServiceManager'
UPDATE Jobs SET Assembly = 'Bernstein.IRS.Jobs' Where Class = 'BloombergJobs'
GO

-- Rollback
/*
UPDATE Jobs SET Assembly = 'Bernstein.IRS.RefreshXML' Where Class = 'WriteXML'
UPDATE Jobs SET Assembly = 'Bernstein.IRS.Library'    Where Class = 'Algo'
UPDATE Jobs SET Assembly = 'Bernstein.IRS.JobAdapter' Where Class = 'ServiceManager'
UPDATE Jobs SET Assembly = 'Bernstein.IRS.MarketData' Where Class = 'BloombergJobs'
GO
*/

-- DEBUG
SELECT * FROM Jobs ORDER BY Assembly, Class, Method
GO
SELECT * FROM EventLog Where Source IN ('JobController', 'JobService', 'Marketdata')
ORDER BY TimeStamp DESC
SELECT * FROM EventLog Where Message = 'Job: Service Controller library ran successfully.'
ORDER BY TimeStamp DESC

/*
spGetJobQueue
GO

select * from jobschedules where jobid = 11

update jobSchedules Set NextRunTime = getdate(), retrycount = 0 where JobId = 11 and scheduleid = 18
*/

/*
Bernstein.IRS.Jobs.dll
WriteXml.cs
ServiceManager.cs
Algo.cs
Trefis.cs
BloombergJobs.cs

Others:
18	Prices Charts - 3 yrs close price	1	Bernstein.IRS.Web.Charts	C3PriceChart	ExecutePriceChartBatchJob	NULL	0	2019-08-29 14:19:01.790
17	BlueCurve							1	Bernstein.IRS.FileLoader	FileLoader		ProcessOutFile				NULL	0	2019-03-22 16:45:34.930

Retired:
15	Revaluate Ticker Table XML			1	Bernstein.IRS.RevaluateTickerTable	RevaluateTickerTableXMLLib	RevaluateTickerTableXML	NULL	1229	2015-10-26 15:13:50.277
*/
