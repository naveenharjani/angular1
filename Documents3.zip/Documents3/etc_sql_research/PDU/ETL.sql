-- ETL.sql
-- 12/01/2018
-- 02/05/2019

/*

-- 12/1/2018
INSERT INTO FileProcessingConfig VALUES ('Holdings', '\PRDCTL\in\Holdings\', '\PRDCTL\in\Holdings\Processed')
INSERT INTO FileProcessingConfig VALUES ('VisibleAlpha','\PRDCTL\in\VisibleAlpha\Readership\','\PRDCTL\in\VisibleAlpha\Readership\Processed')

-- 02/05/2019
INSERT INTO FileProcessingConfig VALUES('Bloomberg','\PRDCTL\in\Bloomberg\Readership\','\PRDCTL\in\Bloomberg\Readership\Processed')
INSERT INTO FileProcessingConfig VALUES('Factset','\PRDCTL\in\Factset\Readership\','\PRDCTL\in\Factset\Readership\Processed')
INSERT INTO FileProcessingConfig VALUES('TR','\PRDCTL\in\TR\Readership\','\PRDCTL\in\TR\Readership\Processed')
INSERT INTO FileProcessingConfig VALUES('CIQ','\PRDCTL\in\CIQ\Readership\','\PRDCTL\in\CIQ\Readership\Processed')
GO

-- AnalystHoldings - daily
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('Holdings', 'AnalystHoldings', 'DAT', 'DAILY',  'POST')
-- Visible Alpha - daily
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('VisibleAlpha', 'VA-SanfordBernstein-VAI_Model_Download-T-30', 'CSV', 'DAILY',  'POST')

-- Activate 1d files 
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('Bloomberg', 'dlyN2SCB', 'CSV', 'DAILY',  'PRE')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('Factset', 'L_1_DAYS', 'CSV', 'DAILY',  'PRE')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('TR', 'Daily - Trailing Yesterday - Pre Embargo', 'CSV', 'DAILY',  'PRE')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('CIQ', 'ResearchActivity', 'TXT', 'DAILY',  'MIXED')
GO

-- 2/7/2019
-- Activate 30d files
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('Bloomberg', 'dlyU2SCB', 'CSV', 'DAILY',  'POST30')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('Factset', 'L_31_DAYS', 'CSV', 'DAILY',  'POST30')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('TR', 'Daily - Trailing Yesterday - Post Embargo', 'CSV', 'DAILY',  'POST30')
GO

-- 2/13/2019
-- Activate Visible Alpha - T-120 model download
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('VisibleAlpha', 'VA-SanfordBernstein-VAI_Model_Download-T-120', 'CSV', 'DAILY',  'POST')
-- Deactivate Visible Alpha - T-30 model download
-- DELETE FROM FileLoadInstructions Where FileLoadInstructionId = 3
GO

-- 2/28/2019
-- Activate VA model clicks
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('VisibleAlpha', 'VA-SanfordBernstein-Model_Data_Usage-T-90', 'CSV', 'DAILY',  'MIXED')
-- Activate readership history files
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('Bloomberg', 'rpt1SCB', 'CSV', 'MANUAL',  'POST')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('Factset', 'FactSet_Hist', 'CSV', 'MANUAL',  'POST')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('TR', 'TR_Hist', 'CSV', 'MANUAL',  'POST')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('CIQ', 'CIQ_Hist', 'CSV', 'MANUAL',  'POST')

--03/25/2019
--Activate Autonomous Coverage import file
insert into FileProcessingConfig(DataStore,SourceFilePath,BackupFilePath) values('BlueCurve','\PRDCTL\in\BlueCurve\','\PRDCTL\in\BlueCurve\Processed')
insert into FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) values('BlueCurve','BC_Coverage','XML','DAILY','POST')

--04/03/2019
--VisibleAlpha - change file watcher folder
UPDATE FileProcessingConfig SET SourceFilePath = '\PRDCTL\in\VisibleAlpha\', BackupFilePath = '\PRDCTL\in\VisibleAlpha\Processed' WHERE DataStore = 'VisibleAlpha'

--04/03/2019
--Bloomberg - daily 90day post embargo
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('Bloomberg', 'dlyU90SCB','CSV', 'DAILY',  'POST90')

--04/04/2019
--Factset - daily 90day post embargo
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('Factset', 'L_91_DAYS','CSV', 'DAILY',  'POST90')
--ThomsonReuters - daily
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle) VALUES('TR', 'Daily - Trailing Yesterday - Post 90Day Embargo', 'CSV', 'DAILY',  'POST90')

--05/02/2019
-- remove /readership folder
UPDATE FileProcessingConfig SET SourceFilePath = '\PRDCTL\in\Bloomberg\', BackupFilePath = '\PRDCTL\in\Bloomberg\Processed' WHERE DataStore = 'Bloomberg'
UPDATE FileProcessingConfig SET SourceFilePath = '\PRDCTL\in\Factset\', BackupFilePath = '\PRDCTL\in\Factset\Processed' WHERE DataStore = 'Factset'
UPDATE FileProcessingConfig SET SourceFilePath = '\PRDCTL\in\TR\', BackupFilePath = '\PRDCTL\in\TR\Processed' WHERE DataStore = 'TR'
UPDATE FileProcessingConfig SET SourceFilePath = '\PRDCTL\in\CIQ\', BackupFilePath = '\PRDCTL\in\CIQ\Processed' WHERE DataStore = 'CIQ'

-- Store EditDate, EditorId when DataStore was activated
UPDATE FileProcessingConfig SET EditorId = 1229, EditDate = '12/3/2018' WHERE DataStore = 'Holdings'
UPDATE FileProcessingConfig SET EditorId = 1229, EditDate = '12/3/2018' WHERE DataStore = 'VisibleAlpha'

UPDATE FileProcessingConfig SET EditorId = 1229, EditDate = '02/05/2019' WHERE DataStore = 'Bloomberg'
UPDATE FileProcessingConfig SET EditorId = 1229, EditDate = '02/05/2019' WHERE DataStore = 'Factset'
UPDATE FileProcessingConfig SET EditorId = 1229, EditDate = '02/05/2019' WHERE DataStore = 'TR'
UPDATE FileProcessingConfig SET EditorId = 1229, EditDate = '02/05/2019' WHERE DataStore = 'CIQ'

UPDATE FileProcessingConfig SET EditorId = 1229, EditDate = '03/25/2019' WHERE DataStore = 'BlueCurve'

-- Store EditDate, EditorId when a FileFragment was activated
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '12/3/2018' WHERE DataStore = 'Holdings' AND FileFragment = 'AnalystHoldings'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '12/3/2018' WHERE DataStore = 'VisibleAlpha' AND FileFragment = 'VA-SanfordBernstein-VAI_Model_Download-T-120'

UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/05/2019' WHERE DataStore = 'Bloomberg' AND FileFragment = 'dlyN2SCB'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/05/2019' WHERE DataStore = 'Factset' AND FileFragment = 'L_1_DAYS'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/05/2019' WHERE DataStore = 'TR' AND FileFragment = 'Daily - Trailing Yesterday - Pre Embargo'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/05/2019' WHERE DataStore = 'CIQ' AND FileFragment = 'ResearchActivity'

UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/07/2019' WHERE DataStore = 'Bloomberg' AND FileFragment = 'dlyU2SCB'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/07/2019' WHERE DataStore = 'Factset' AND FileFragment = 'L_31_DAYS'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/07/2019' WHERE DataStore = 'TR' AND FileFragment = 'Daily - Trailing Yesterday - Post Embargo'

UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/28/2019' WHERE DataStore = 'VisibleAlpha' AND FileFragment = 'VA-SanfordBernstein-Model_Data_Usage-T-90'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/28/2019' WHERE DataStore = 'Bloomberg' AND FileFragment = 'rpt1SCB'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/28/2019' WHERE DataStore = 'Factset' AND FileFragment = 'FactSet_Hist'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/28/2019' WHERE DataStore = 'TR' AND FileFragment = 'TR_Hist'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '02/28/2019' WHERE DataStore = 'CIQ' AND FileFragment = 'CIQ_Hist'

UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '03/25/2019' WHERE DataStore = 'BlueCurve' AND FileFragment = 'BC_Coverage'

UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '04/03/2019' WHERE DataStore = 'Bloomberg' AND FileFragment = 'dlyU90SCB'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '04/05/2019' WHERE DataStore = 'Factset' AND FileFragment = 'L_91_DAYS'
UPDATE FileLoadInstructions SET EditorId = 1229, EditDate = '04/05/2019' WHERE DataStore = 'TR' AND FileFragment = 'Daily - Trailing Yesterday - Post 90Day Embargo'

-- 05/02/2019
-- Activate 4 Minor Portals 
INSERT INTO FileProcessingConfig(DataStore,SourceFilePath,BackupFilePath, EditorId, EditDate) VALUES('OneAccess','\PRDCTL\in\ONEaccess\','\PRDCTL\in\ONEaccess\Processed', 1229, '05/02/2019')
INSERT INTO FileProcessingConfig(DataStore,SourceFilePath,BackupFilePath, EditorId, EditDate) VALUES('RedDeer','\PRDCTL\in\RedDeer\','\PRDCTL\in\RedDeer\Processed', 1229, '05/02/2019')
INSERT INTO FileProcessingConfig(DataStore,SourceFilePath,BackupFilePath, EditorId, EditDate) VALUES('BlueMatrix','\PRDCTL\in\BlueMatrix\','\PRDCTL\in\BlueMatrix\Processed', 1229, '05/02/2019')
INSERT INTO FileProcessingConfig(DataStore,SourceFilePath,BackupFilePath, EditorId, EditDate) VALUES('RSRCHX','\PRDCTL\in\RSRCHX\','\PRDCTL\in\RSRCHX\Processed', 1229, '05/02/2019')

INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle, EditorId, EditDate) VALUES('OneAccess', 'Bernstein_Readership', 'CSV', 'DAILY', 'MIXED', 1229, '05/02/2019')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle, EditorId, EditDate) VALUES('RedDeer', 'Red Deer Readership', 'CSV', 'DAILY', 'MIXED', 1229, '05/02/2019')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle, EditorId, EditDate) VALUES('BlueMatrix', 'BM_ABReads', 'CSV', 'DAILY', 'POST', 1229, '05/02/2019')
INSERT INTO FileLoadInstructions(DataStore, FileFragment, FileType, FileFrequency, EmbargoStyle, EditorId, EditDate) VALUES('RSRCHX', 'RSRCHX', 'CSV', 'DAILY', 'POST', 1229, '05/02/2019')

*/

-- DEBUG

SELECT * FROM FileProcessingConfig ORDER BY ConfigId
SELECT * FROM FileLoadInstructions ORDER BY FileLoadInstructionId
GO
