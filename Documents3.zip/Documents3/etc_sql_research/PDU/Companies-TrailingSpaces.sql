--3/2/2017
--There were about 49 rows with trailing spaces in company column
--Trim trailing spaces in company column of Securities2 and Companies table
--Trim trailing spaces in Last, First & Name column of Authors table

update Securities2
set Company = rtrim(Company)

update Securities2
set Ticker = rtrim(Ticker)

update Companies
set Company = rtrim(Company)

update Authors
set Last = rtrim(Last), First = rtrim(First), Name = rtrim(Name)


