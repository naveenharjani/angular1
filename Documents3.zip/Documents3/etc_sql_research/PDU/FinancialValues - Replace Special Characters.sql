--02/24/2017
--Remove $,comma characters in the financial values 
--Financial values are stored with decimals ranging between 2 and 4 digits
--vFinancials & VfinancialsLatest & RVFinancials applies rounding to 2 digits after decimal logic
--Cast to decimal(18,2) fails if $ or comma encountered
update FinancialNumbers
set Value = Replace(Replace(Value,',',''),'$',''), UnitValue = replace(replace(value,',',''),'$','')

update PublicationFinancials
set TargetPrice = Replace(Replace(TargetPrice,',',''),'$',''), EpsFY0 = replace(replace(EpsFY0,',',''),'$',''), EpsFY1 = replace(replace(EpsFY1,',',''),'$',''), EpsFY2 = replace(replace(EpsFY2,',',''),'$','')
