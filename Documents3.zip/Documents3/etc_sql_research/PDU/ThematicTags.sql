-- ThematicTags.sql
-- 08/14/2017

declare @ThematicTagId int

-- 08/14/2017
-- exec spSaveThematicTag @ThematicTagId output, 'Artificial Intelligence', 1, 1126

-- 08/18/2017
-- exec spSaveThematicTag @ThematicTagId output, 'Consumer Disrupted', 1, 1

-- 08/18/2017
-- exec spSaveThematicTag @ThematicTagId output, 'ESG', 1, 1

-- 08/23/2017
-- exec spSaveThematicTag @ThematicTagId output, 'Big Data', 1, 1

-- 08/23/2017
-- exec spSaveThematicTag @ThematicTagId output, 'Thematic Research', 1, 1

-- 09/01/2017
 --exec spSaveThematicTag @ThematicTagId output, 'Automation', 1, 1126

--09/04/2017
--exec spSaveThematicTag @ThematicTagId output, 'Electric Revolution', 1, 1126

--09/21/2017
--exec spSaveThematicTag @ThematicTagId output, 'China Aboard', 1, 1

--11/15/2017
--exec spSaveThematicTag @ThematicTagId output, 'AI in China', 1, 1126

--11/22/2017
--exec spSaveThematicTag @ThematicTagId output, 'The New Mainstream', 1, 1126

--12/05/2017
--exec spSaveThematicTag @ThematicTagId output, 'Autonomous Vehicles', 1, 1126

--01/25/2019 - Bruno Monteyne
--exec spSaveThematicTag @ThematicTagId output, 'Debt Sustainability', 1, 1229

--03/06/2019
--exec spSaveThematicTag @ThematicTagId output, 'Pre-IPO Research', 1, 1

--10/21/2019
--exec spSaveThematicTag @ThematicTagId output, 'Procensus', 1, 1126
go

-- UNIQUE KEY constraint 'IX_ThematicTags_ThematicTag' prevents duplicate ThematicTag fields.

-- BR.com Investor Themes are separate and not necessarily related

-- !!! Refresh rptools.xml to take effect

select  * from ThematicTags order by ThematicTagId
