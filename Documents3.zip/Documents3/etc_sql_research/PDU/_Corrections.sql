_Corrections.sql

-- *** CHANGES APPLIED TO PRD ***

-- ***
-- *** 07/14/2009 - Best of Bernstein Blackbook - TickerTable record for 'BSX'
-- ***
-- Review prior report
select * from Publications             where PubNo = 68430 -- 68347
select * from TickerTables             where PubNo = 68430 -- 68347
select * from TickerTableSecurities    where PubNo = 68430 -- 68347
select * from TickerTableSecuritiesOld where PubNo = 68430 -- 68347

-- Review report
select * from Publications             where PubNo = 68547 -- 68348
select * from TickerTables             where PubNo = 68547 -- 68348
select * from TickerTableSecurities    where PubNo = 68547 -- 68348
select * from TickerTableSecuritiesOld where PubNo = 68547 -- 68348

/*
insert into tickertables(pubno,epstype,metrictype,displayclosedate,lastyear,thisyear,nextyear)
select 68547,'GAAP','P/E','7/1/2009','2008A','2009E','2010E'

insert into tickertablesecurities(pubno,ticker,rating,currency,closedate,closeprice,targetprice,ytdrelperf,epslastyear,epsthisyear,epsnextyear,metriclastyear,metricthisyear,metricnextyear,yield,tickerorder,targetpriceorig,coverageid,coverageaction,ratingaction,targetpriceaction,estimateaction)
select 68547,'BSX','O','USD','7/1/2009','10.11','12.00','23.1%','0.51','0.59','0.75','18.6','16.1','12.7','NA',1,NULL,798,NULL,'Reiterate','Increase','Reiterate'

insert into tickertablesecuritiesold(pubno,ticker,targetprice)
select 68547,'BSX','11.00'
select 68547,'BSX',11
*/

-- ***
-- *** 07/14/2009 : Big Think Delete rows from TickerTable tables & Properties table
-- ***
select tts.* from tickertables tts join publications p on tts.pubno = p.pubno
where p.title LIKE '%big think%' 
order by pubno

select tts.* from tickertablesecurities tts join publications p on tts.pubno = p.pubno
where p.title LIKE '%big think%' 
order by pubno

select ttso.* from tickertablesecuritiesold ttso join publications p on ttso.pubno = p.pubno
where p.title LIKE '%big think%' 

/*
select 'Ticker' = convert(varchar(10), PR.PropValue), PU.*
from Publications PU join Properties PR on PR.PubNo = PU.PubNo and PR.PropID = 13
join securities2 s on pr.propvalue = s.ticker
where PU.Title like '%big think%' and
s.tickertype = 'stock'
order by pubno

delete pr
from
properties pr join publications pu on pr.pubno = pu.pubno and pr.propid = 13
join securities2 s on pr.propvalue = s.ticker
where
pu.title like '%big think%' and
s.tickertype = 'stock'

delete tts
from
tickertablesecurities tts join publications p on tts.pubno = p.pubno
where p.title LIKE '%big think%' 

delete ttso
from
tickertablesecuritiesold ttso join publications p on ttso.pubno = p.pubno
where p.title LIKE '%big think%' 

delete tt
from
tickertables tt join  publications p on tt.pubno = p.pubno
where p.title LIKE '%big think%' 
*/

--Corrections to fix implicit rating changes
/*
NOT APPLIED
-- Update TickerTableSecurities set Rating = 'M' where Rating = 'U' and Pubno = 65719 and Ticker = 'OR.FP'
Update TickerTableSecurities set Rating = 'M' where Rating = 'O' and Pubno = 47672 and Ticker = 'ALU.FP'   -- Typo
Update TickerTableSecurities set Rating = 'O' where Rating = 'M' and Pubno = 51998 and Ticker = 'NOK1V.FH' 
Update TickerTableSecurities set Rating = 'M' where Rating = 'O' and Pubno = 61212 and Ticker = 'BG/.LN'   -- Typo, multi-industry report
Update TickerTableSecurities set Rating = 'O' where Rating = 'M' and Pubno = 62280 and Ticker = 'WYE' 
Update TickerTableSecurities set Rating = 'M' where Rating = 'O' and Pubno = 63350 and Ticker = 'DGE.LN' 
Update TickerTableSecurities set Rating = 'M' where Rating = 'O' and Pubno = 63511 and Ticker = 'NWS'      -- Typo, multi-industry report
Update TickerTableSecurities set Rating = 'M' where Rating = 'O' and Pubno = 63511 and Ticker = 'NWSA'     -- Typo, multi-industry report
Update TickerTableSecurities set Rating = 'M' where Rating = 'O' and Pubno = 65832 and Ticker = 'E' 
Update TickerTableSecurities set Rating = 'O' where Rating = 'M' and Pubno = 65832 and Ticker = 'ENI.IM' 
Update TickerTableSecurities set Rating = 'U' where Rating = 'M' and Pubno = 66118 and Ticker = 'DO'       -- Typo, multi-industry report
Update TickerTableSecurities set Rating = 'O' where Rating = 'M' and Pubno = 68070 and Ticker = 'CELG'     -- Typo, multi-industry report
Update TickerTableSecurities set Rating = 'O' where Rating = 'M' and Pubno = 55487 and Ticker = 'OMC' 
Update TickerTableSecurities set Rating = 'O' where Rating = 'M' and Pubno = 54753 and Ticker = 'OMC' 
*/

-- Ticker table / ticker sheet has empty values

select * from TickerTableSecurities where Rating ='' and Ticker not in (select Ticker from Securities2 where TickerType = 'INDEX')

-- 08/20/2009 - Joint Call
select * from TickerTableSecurities    where PubNo = 69375 and Ticker = 'ABB.SS'
select * from TickerTableSecuritiesOld where PubNo = 69375 and Ticker = 'ABB.SS'
-- delete from TickerTableSecurities    where PubNo = 69375 and Ticker = 'ABB.SS'
-- delete from TickerTableSecuritiesOld where PubNo = 69375 and Ticker = 'ABB.SS'

-- 04/04/2011
-- Analysis of adding action tags where report exists for primary ticker listing, but report does not exist for secondary ticker listing
-- One form of implicit changes

--insert into tickertables(pubno,epstype,metrictype,displayclosedate,lastyear,thisyear,nextyear)
--select 68547,'GAAP','P/E','7/1/2009','2008A','2009E','2010E'

insert into tickertablesecurities(pubno,ticker,rating,currency,closedate,closeprice,targetprice,ytdrelperf,epslastyear,epsthisyear,epsnextyear,metriclastyear,metricthisyear,metricnextyear,yield,tickerorder,targetpriceorig,coverageid,coverageaction,ratingaction,targetpriceaction,estimateaction)
select 68547,'BSX','O','USD','7/1/2009','10.11','12.00','23.1%','0.51','0.59','0.75','18.6','16.1','12.7','NA',1,NULL,798,NULL,'Reiterate','Increase','Reiterate'

insert into tickertablesecuritiesold(pubno,ticker,targetprice)
select 68547,'BSX','11.00'
select 68547,'BSX',11

-- The TickerTables row already exists for primary ticker

insert into TickerTableSecurities(
PubNo,
Ticker,
Rating,
Currency,
CloseDate,   -- Use same close date of primary ticker,
ClosePrice
TargetPrice, -- GET FROM ANALYST
-- YTDRelPerf,
-- EPSLastYear,
-- EPSThisYear,
-- EPSNextYear,
-- MetricLastYear,
-- MetricThisYear,
-- MetricNextYear,
-- Yield,
TickerOrder,
-- TargetPriceOrig,
CoverageId,
CoverageAction,
RatingAction,
TargetPriceAction,
EstimateAction,
select 68547,'BSX','O','USD','7/1/2009','10.11','12.00',1,NULL,798,NULL,'Reiterate','Increase','Reiterate'

insert into TickerTableSecuritiesOld(
PubNo,
Ticker,
Rating,
TargetPrice,
--EPSThisYear,
--EPSNextYear,
--TargetPriceOrig,
select 68547,'BSX','11.00'


--09/8/2015
--Rating change made on primary ticker ANTO.LN from M to O. 
--On the same report implicit rating change made for secondary ANFGY
--This corrects the implicit change and updates action tags.
insert into TickerTableSecuritiesOld(PubNo,Ticker,Rating,TargetPrice,EPSThisYear,EPSNextYear,TargetPriceOrig)
select 108757,Ticker,Rating,TargetPrice,EPSThisYear,EPSNextYear,null
from TickerTableSecurities
where
PubNo = 108700 and Ticker = 'anfgy'

update TickerTableSecurities
set RatingAction='Upgrade', TargetPriceAction='Increase', EstimateAction='Downgrade',EstimateNextYearAction='Downgrade'
where PubNo = 108757 and Ticker = 'anfgy'

sp_help TickerTableSecurities
sp_help TickerTableSecuritiesOld

*/
