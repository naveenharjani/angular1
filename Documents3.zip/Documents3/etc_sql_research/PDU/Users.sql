-- Users.sql
-- 11/01/2016

select * from Users where Active = -1

-- ***
-- *** ACTIVE FLAG
-- ***

select * from Departments

-- Review inactive research staff
select
  U.UserId,
  X.LastLogon,
  U.LastName + ', ' + U.FirstName + ' (' + U.UserName + ')' [User],
  U.DepartmentId
--  U.*
from Users U
left join (select UserId, max(EditDate) as LastLogon from SessionLog group by UserId) X on X.UserId = U.UserId
where X.LastLogon is not null
--and U.DepartmentId in (1)
--and U.DepartmentId in (2, 3)
and U.Active = -1
and datediff(dd, X.LastLogon, getdate()) > 360
order by 4, 2

-- Mark inactive research staff
-- Performed 11/01/2016 - Inactive Research > 90 days + Inactive Sales, Trading > 360 days
-- Performed 03/04/2021 - Inactive Research > 90 days + Inactive Sales, Trading > 360 days
update Users set
  Active = 0,
  EditorId = 0,
  EditDate = getdate()
where UserId in
(
select U.UserId
from Users U
left join (select UserId, max(EditDate) as LastLogon from SessionLog group by UserId) X on X.UserId = U.UserId
where X.LastLogon is not null
and U.Active = -1
and U.DepartmentId in (1) and datediff(dd, X.LastLogon, getdate()) > 90
--and U.DepartmentId in (2, 3) and datediff(dd, X.LastLogon, getdate()) > 360
)

-- ***
-- *** Roles
-- ***

select * from Roles

select * from UserRoles

select
U.LastName + ', ' + U.FirstName [User],
U.UserName,
R.Role,
U.Active,
X.LastLogon
--UR.*, U.*, R.*
from UserRoles UR
join Users U on U.UserId = UR.UserId
join Roles R on R.RoleId = UR.RoleId
left join (select UserId, max(EditDate) as LastLogon from SessionLog group by UserId) X on X.UserId = U.UserId
--where U.Active <> -1
order by UR.RoleId, 5

-- Remove roles from 
select * from UserRoles
--delete from UserRoles
where RoleId not in (1, 2)
and UserId in
(
select UserId from Users where Active <> -1
)


-- Delete UserRoles row where User is inactive

-- ***
-- *** Name
-- ***

select Active,   LastName + ', ' + FirstName + ' (' + UserName + ')', * from Users where Active = -1 order by 1, 2

-- ***
-- *** Email
-- ***

select Email, * from Users order by UserId

select * from Authors order by AuthorId

select lower(Email), * from Users order by 1

-- Performed 11/04/2016, 01/27/2017
update Users set Email = lower(Email)

-- Email required for all active users
select Active, Email, * from Users where Active = -1 and Email is null order by 1

-- 01/27/2017 Disable inactive users with no email (blocked by system)
select * from Users where UserId in (337, 777, 959, 1332, 1333, 1334, 1342)
update Users set Active = 0 where UserId in (337, 777, 959, 1332, 1333, 1334, 1342)

select DepartmentId, * from Users where Active = -1 and Email like '%alliancebernstein.com' order by 1

-- ***
-- *** Watermark
-- ***

select WatermarkText, U.* from Users U where WatermarkText is not null order by 1 desc
