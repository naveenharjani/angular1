/*
--12/05/2019
identify & delete disclosures for dropped tickers (Bernstein & Autonomous)
*/
select 'Bernstein' Type, SCD.SecurityID,Ticker,Company,SCD.DisclosureID,Disclosure 
from SecurityCheckboxDisclosures SCD join Securities2 S on SCD.SecurityID = S.SecurityID
join SecurityCheckboxTypes SCT on SCD.DisclosureID = SCT.DisclosureID
where 
S.TypeId = 1 and
SCD.SecurityId not in 
(--launched & unlaunched tickers
select SecurityId from ResearchCoverage where DropDate is null and securityid is not null)
union
select 'Autonomous' Type, SCD.SecurityID,Ticker,Company,SCD.DisclosureID,Disclosure 
from SecurityCheckboxDisclosures SCD join Securities2 S on SCD.SecurityID = S.SecurityID
join SecurityCheckboxTypes SCT on SCD.DisclosureID = SCT.DisclosureID
where SCD.SecurityId in 
(--Dropped Autonomous Tickers
select SecurityId from Securities2 where TypeId= 2 and IsActive = 0)
order by 3

/*
delete SecurityCheckboxDisclosures
from SecurityCheckboxDisclosures SCD join Securities2 S on SCD.SecurityID = S.SecurityID
join SecurityCheckboxTypes SCT on SCD.DisclosureID = SCT.DisclosureID
where 
S.TypeId = 1 and
SCD.SecurityId not in 
(--launched & unlaunched bernstein tickers
select SecurityId from ResearchCoverage where DropDate is null and securityid is not null)

delete SecurityCheckboxDisclosures
from SecurityCheckboxDisclosures SCD join Securities2 S on SCD.SecurityID = S.SecurityID
join SecurityCheckboxTypes SCT on SCD.DisclosureID = SCT.DisclosureID
where SCD.SecurityId in 
(--Dropped Autonomous Tickers
select SecurityId from Securities2 where TypeId= 2 and IsActive = 0)
*/