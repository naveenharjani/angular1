-- PortalUsageModelFix.sql
-- 05/06/2020

-- compassdb,16083; Database=SlxExternal; User ID=research_db_svc

/*
1. Use RVSecurities.SecurityId to join with RVPortalUsage.ContentId
-- RVModels     -- shows tickers under active coverage and StateId in (1, 2) -- Active, Archived 
-- RVSecurities -- shows all tickers
If you join with RVModels, it will filter out dropped tickers

2. For RVPortalUsage.ReadDate >= '2019-10-01' - BackFill RVPortalUsage.ContentId with SecurityId
It currently has ContentId. Max SecurityId (RVSecurities) is 2416 (PRD)
*/


-- before pdu
-- non-matching RVSecurities.SecurityId   -- 1217 rows (ContentId)
SELECT * FROM  RVPortalUsage WHERE ContentType = 'M' AND SiteId = 27 -- Visible Alpha
and ContentId NOT IN (SELECT SecurityId FROM RVSecurities)
ORDER BY ReadDate DESC

-- matching RVSecurities.SecurityId   -- 423 rows (ContentId)
SELECT * FROM  RVPortalUsage WHERE ContentType = 'M' AND SiteId = 27 -- Visible Alpha
and ContentId IN (SELECT SecurityId FROM RVSecurities)
ORDER BY ReadDate DESC

-- pdu
-- UPDATE PortalUsage
-- SET ContentId = M.SecurityId
SELECT M.SecurityId, PU.*
FROM PortalUsage PU
JOIN Models M ON M.ModelId = PU.ContentId
WHERE ContentType = 'M' AND SiteId = 27 -- Visible Alpha
and ContentId NOT IN (SELECT SecurityId FROM RVSecurities)

-- after pdu - non-matching RVSecurities.SecurityId   -- xx rows (ContentId)
SELECT * FROM  RVPortalUsage WHERE ContentType = 'M' AND SiteId = 27 -- Visible Alpha
and ContentId NOT IN (SELECT SecurityId FROM RVSecurities)
ORDER BY ReadDate DESC

/* -- CRM
SELECT * FROM  SlxExternal.dbo.RVPortalUsage WHERE ContentType = 'M' AND SiteId = 27 -- Visible Alpha
and ContentId IN (SELECT SecurityId FROM SlxExternal.dbo.RVSecurities)
ORDER BY ReadDate DESC

SELECT * FROM  SlxExternal.dbo.RVPortalUsage WHERE ContentType = 'M' AND SiteId = 27 -- Visible Alpha
and ContentId NOT IN (SELECT SecurityId FROM SlxExternal.dbo.RVSecurities)
ORDER BY ReadDate DESC
*/


SELECT * FROM  PortalUsage WHERE ContentType = 'M'
and ContentId NOT IN (SELECT SecurityId FROM RVSecurities)
AND (ISNULL(ContentId,'') = '' OR ISNULL(ContentId, 0) = 0)
ORDER BY ReadDate DESC
