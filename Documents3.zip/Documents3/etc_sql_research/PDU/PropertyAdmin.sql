-- PropertyAdmin.sql
-- 04/20/2018

-- Currently SAs cannot change keywords on published docs via the properties form on Beehive. It�s an option for Admins but not SAs.
-- The below SQL grants Role �Manager�[RoleId=2] edit access to Property �Keywords�[PropId=9].
insert into PropertyEntitlementRoles(TypeId, PropId, RoleId) Values(0, 9, 2)
go

-- 08/09/2019
-- Allow Research Manager access to edit authors, Industry, Tickers in Properties edit page
insert into [PropertyEntitlementRoles](TypeId, PropId, RoleId)
SELECT 0, 5, 2
UNION
SELECT 0, 11, 2
UNION
SELECT 0, 13, 2
