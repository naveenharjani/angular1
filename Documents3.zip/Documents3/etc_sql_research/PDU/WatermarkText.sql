-- WatermarkText.sql
-- 2/1/2017

--Set WatermarkType to Global for all the rows in users table
--update Global water mark text in Bernstein.IRS.Common.Assembly.Config to "Provided by $FIRST $LAST for exclusive use on $DATE

update Users set WatermarkTypeId = 4

update Users set WatermarkText = null where WatermarkText = ''

/*

select * from WatermarkTypes

select WatermarkTypeId, WatermarkText, * from Users

select WatermarkTypeId, WatermarkText, * from Users where WatermarkTypeId = 1 and WatermarkText is not null

*/
