-- disclosures.sql
-- 09/25/2014

-- Fix Disclosures Property tag manually to a value
-- Below reports were sent to Publishing using incorrect toolset by Nina, causing not updated Property value

select * from properties
 where propid = 27
  and PubNo IN (101680, 105417, 105418, 105419, 105420, 105421, 105424, 105434, 105435, 101680)

/*
INSERT INTO Properties (PubNo, PropID, PropValue) VALUES(101680, 27, '9.02')
GO
INSERT INTO Properties (PubNo, PropID, PropValue) VALUES(105417, 27, '9.02')
GO
INSERT INTO Properties (PubNo, PropID, PropValue) VALUES(105418, 27, '9.02')
GO
INSERT INTO Properties (PubNo, PropID, PropValue) VALUES(105419, 27, '9.02')
GO
INSERT INTO Properties (PubNo, PropID, PropValue) VALUES(105420, 27, '9.02')
GO
INSERT INTO Properties (PubNo, PropID, PropValue) VALUES(105421, 27, '9.02')
GO
INSERT INTO Properties (PubNo, PropID, PropValue) VALUES(105424, 27, '9.02')
GO
INSERT INTO Properties (PubNo, PropID, PropValue) VALUES(105434, 27, '9.02')
GO
INSERT INTO Properties (PubNo, PropID, PropValue) VALUES(105435, 27, '9.02')
GO
*/