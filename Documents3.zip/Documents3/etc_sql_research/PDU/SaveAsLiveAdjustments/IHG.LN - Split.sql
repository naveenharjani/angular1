--Ticker = IHG.LN
--Adjustment Factor  0.957400
--Franchise was approached and they did not want the split to be applied to current live target price and historical data.
--This is due to the fact that split is close to 1.0 and there was dividend paid out on the same day and
--analyst target price is accounted for that.
--So, updating the status on the split to 'Y'

update SplitActions
set AppliedStatus = 'Y',AppliedDate = getdate()
where
SplitActionId = 912