--03/16/2017
--BHE.IN (Bharat Heavy Electricals) had a stock split of 2.0 effective 01/18/2017
--spApplySplitActions was executed on the ticker which adjusted the target price historically prior to the effective date
--This script adjusted latest EPS (Reported & Adjusted) values by the same factor 
--This will enable the franchise to not have to make eps change for stock split.

select FinancialNumberId,SecurityId,FinancialNumberTypeId,BaseYear,FinancialPeriodId,PeriodYear,Value,pubno
from vFinancialNumbersLatest
where securityid = 1815 and
FinancialNumberTypeId in (3,4) and
FinancialPeriodId in (1,2,3,4) and
BaseYear = 2016
order by FinancialNumberTypeId,FinancialPeriodId 

/*
Data before applying the split adjustment factor(2.0) for EPS Reported values

FinancialNumberId	SecurityId	FinancialNumberTypeId	BaseYear	FinancialPeriodId	PeriodYear	Value	pubno
385750	          1815	      3	                    2016	    1	                2016	      58.0972	NULL
663412	          1815	      3	                    2016	    2	                2017	      65.9138	127719
663413	          1815	      3	                    2016	    3	                2018	      72.1988	127719
663414	          1815	      3	                    2016	    4	                2019	      88.1148	127719

385754	          1815	      4	                    2016	    1	                2016	      58.0972	NULL
663415	          1815	      4	                    2016	    2	                2017	      65.9138	127719
663416	          1815	      4	                    2016	    3	                2018	      72.1988	127719
663417	          1815	      4	                    2016	    4	                2019	      88.1148	127719
*/
--EPS Reported
--1. Update valueorig to value before applying the split
--2. Adjust value and unitvalue to the split adjusted values
Update FinancialNumbers
Set ValueOrig = Value
Where SecurityId = 1815
and FinancialNumberTypeId = 3
and IsDraft = 0
and ValueOrig is null
and FinancialNumberId in (385750,663412,663413,663414)

Update FinancialNumbers
SET Value  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),Value) / 10.0))),
    UnitValue  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),UnitValue) / 10.0)))
Where SecurityId = 1815
and FinancialNumberTypeId = 3
and IsDraft = 0
and FinancialNumberId in (385750,663412,663413,663414)

--EPS Adjusted
--1. Update valueorig to value before applying the split
--2. Adjust value and unitvalue to the split adjusted values

Update FinancialNumbers
Set ValueOrig = Value
Where SecurityId = 1815
and FinancialNumberTypeId = 4
and IsDraft = 0
and ValueOrig is null
and FinancialNumberId in (385754,663415,663416,663417)

Update FinancialNumbers
SET Value  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),Value) / 10.0))),
    UnitValue  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),UnitValue) / 10.0)))
Where SecurityId = 1815
and FinancialNumberTypeId = 4
and IsDraft = 0
and FinancialNumberId in (385754,663415,663416,663417)