--07/05/2016
--DHR post-spin off from Fortiv 
--Target price and EPS are adjusted by analyst and franchise does not want to show as change on report
--spsaveEPSAsLive exists and is done through tickersheet button click
--spSaveTargetriceAsLive does not exist yet and so the below update statement promotes the draft values to live.

  update FinancialNumbers
  set IsDraft = 0, Date = getdate()
  where 
  SecurityId = 1060 and
  FinancialNumberTypeId = 2 and
  FinancialPeriodId = 2 and
  IsDraft = 1
  