--01/19/2017
--6861.jp (Keyence) had a stock split of 2.0 effective 01/18/2017
--spApplySplitActions was executed on the ticker which adjusted the target price historically prior to the effective date
--This script adjusted latest EPS (Reported & Adjusted) values by the same factor 
--This will enable the franchise to not have to make eps change for stock split.

select FinancialNumberId,SecurityId,FinancialNumberTypeId,BaseYear,FinancialPeriodId,PeriodYear,Value,ValueOrig 
from FinancialNumbers
where securityid = 1819 and
FinancialNumberTypeId in (3,4) and
FinancialPeriodId in (1,2,3,4) and
BaseYear = 2016
order by FinancialNumberTypeId,FinancialPeriodId 

/*
Data before applying the split adjustment factor(2.0) for EPS Reported values

FinancialNumberId	SecurityId	FinancialNumberTypeId	BaseYear	FinancialPeriodId	PeriodYear	Value	    ValueOrig
355924	          1819	      3	                    2016	    1	                2016	      2262.0200	NULL
365853	          1819	      3	                    2016	    2	                2017	      2529.32	  NULL
365854	          1819	      3	                    2016	    3	                2018	      2985.23	  NULL
365855	          1819	      3	                    2016	    4	                2019	      3548.8824	NULL

355928	          1819	      4	                    2016	    1	                2016	      2262.0200	NULL
365856	          1819	      4	                    2016	    2	                2017	      2529.3638	NULL
365857	          1819	      4	                    2016	    3	                2018	      2985.2781	NULL
365858	          1819	      4	                    2016	    4	                2019	      3548.9437	NULL
*/
--EPS Reported
--1. Update valueorig to value before applying the split
--2. Adjust value and unitvalue to the split adjusted values
Update FinancialNumbers
Set ValueOrig = Value
Where SecurityId = 1819
and FinancialNumberTypeId = 3
and IsDraft = 0
and ValueOrig is null
and FinancialNumberId in (365855,365854,365853,355924)

Update FinancialNumbers
SET Value  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),Value) / 2.0))),
    UnitValue  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),UnitValue) / 2.0)))
Where SecurityId = 1819
and FinancialNumberTypeId = 3
and IsDraft = 0
and FinancialNumberId in (365855,365854,365853,355924)

--EPS Adjusted
--1. Update valueorig to value before applying the split
--2. Adjust value and unitvalue to the split adjusted values

Update FinancialNumbers
Set ValueOrig = Value
Where SecurityId = 1819
and FinancialNumberTypeId = 4
and IsDraft = 0
and ValueOrig is null
and FinancialNumberId in (355928,365856,365857,365858)

Update FinancialNumbers
SET Value  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),Value) / 2.0))),
    UnitValue  = convert(varchar(10),convert(decimal(18,2),(convert(decimal(18,2),UnitValue) / 2.0)))
Where SecurityId = 1819
and FinancialNumberTypeId = 4
and IsDraft = 0
and FinancialNumberId in (355928,365856,365857,365858)