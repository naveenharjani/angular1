-- SaveAsLive.sql

--04/21/2017 CCRI.IN
--CCRI.IN Container Corporation of India has issued bonus shares in 1:4 ratio
--Target price and EPS are adjusted by analyst and franchise does not want to show as change on report
--spsaveEPSAsLive exists and is done through tickersheet button click
--spSaveTargetriceAsLive does not exist yet and so the below update statement promotes the draft target price value to live.

/*
update FinancialNumbers set IsDraft = 0, Date = getdate() where SecurityId = 1818 and FinancialNumberTypeId = 2
and FinancialPeriodId = 2 and IsDraft = 1
*/

-- 07/14/2017 LT.IN
-- Larsen & Toubro (LT.IN) has issued bonus share in 1:2 ratio
-- Accordingly target price as well as EPS need be updated on the system
-- values have been adjusted by 2/3 factor (1:2 bonus share) - as provided by franchise

-- Save EPS as Live via Ticker Sheet
-- Save TP as Live via PDU

select * from securities2 where ticker = 'LT.IN'
select * from financialnumbers where securityid = 1808 and financialnumbertypeid = 2 and isdraft = 1
select * from financialnumbers where financialnumberid = 872593

/*
update financialnumbers set isDraft = 0, Date = getdate() where financialnumberid = 872593
*/




