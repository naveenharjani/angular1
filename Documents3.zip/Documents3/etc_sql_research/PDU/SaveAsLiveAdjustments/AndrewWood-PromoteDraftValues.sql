--2/6/2017
/*
Team published a TP/Eps change industry report (Pubno: 127745). 
Ticker table on the report has Feb 2nd 2017 market data. 
When the report was originally published SA tools refreshed ticker table with latest market data unless  SA click's on "Do not update market data". 
Team wanted to delete the report as resubmit would insert "Revised" watermark which analyst did not want. 
When the report was published again after deleting the first version, there were no drafts in the database to promote (all the data was deleted as part of deleting originally published report). 
Team wanted to write another note and they did not get the new values.

Resolution:
Asked franchise to resubmit draft values to database.
Run below pdu script to promote draft values to live and map the previously published report to these values.
*/
  --BEI.GR
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = 127745, Date = '2/6/2017 2:10:39 AM'
    FROM FinancialNumbers FN
    WHERE FN.IsDraft = 1 and FN.SecurityId = 880

    --BN.FP
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = 127745, Date = '2/6/2017 2:10:39 AM'
    FROM FinancialNumbers FN
    WHERE FN.IsDraft = 1 and FN.SecurityId = 92

    --HEN.GR
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = 127745, Date = '2/6/2017 2:10:39 AM'
    FROM FinancialNumbers FN
    WHERE FN.IsDraft = 1 and FN.SecurityId = 882

        --HEN3.FP
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = 127745, Date = '2/6/2017 2:10:39 AM'
    FROM FinancialNumbers FN
    WHERE FN.IsDraft = 1 and FN.SecurityId = 895

    --NESN.VX
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = 127745, Date = '2/6/2017 2:10:39 AM'
    FROM FinancialNumbers FN
    WHERE FN.IsDraft = 1 and FN.SecurityId = 363

    --OR.FP
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = 127745, Date = '2/6/2017 2:10:39 AM'
    FROM FinancialNumbers FN
    WHERE FN.IsDraft = 1 and FN.SecurityId = 885

--ORK.NO
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = 127745, Date = '2/6/2017 2:10:39 AM'
    FROM FinancialNumbers FN
    WHERE FN.IsDraft = 1 and FN.SecurityId = 1877

--RB/.LN
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = 127745, Date = '2/6/2017 2:10:39 AM'
    FROM FinancialNumbers FN
    WHERE FN.IsDraft = 1 and FN.SecurityId = 886

--UNA.NA
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = 127745, Date = '2/6/2017 2:10:39 AM'
    FROM FinancialNumbers FN
    WHERE FN.IsDraft = 1 and FN.SecurityId = 550

--ULVR.LN
    UPDATE FinancialNumbers
    SET IsDraft = 0, PubNo = 127745, Date = '2/6/2017 2:10:39 AM'
    FROM FinancialNumbers FN
    WHERE FN.IsDraft = 1 and FN.SecurityId = 716








    select * from FinancialNumbers
    where securityid = 880 and PUBNO = 127745