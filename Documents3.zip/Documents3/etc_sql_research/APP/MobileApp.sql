-- MobileApp.sql
-- 12/9/2019

/*

New analysts
Authors.Status must be 1
Authors.EditDate must be refresh date must be greater than watch list date

*/

select * from RVAnalysts order by RefreshDate and 



select * from Authors where IsAnalyst = -1 and IsActive = -1
and TypeId = 1
order by Last

update Authors set Status = 1 where AuthorId = 987	

select * from Exchanges order by EditDate

select * from Currencies -- SAR

select * from Countries -- SA


sp_helptext RVAnalysts

