select * from researchcoverage where analystid in (select authorid from authors where last like '%Analyst1%')
delete from analystsettings where coverageid in (select coverageid from researchcoverage where analystid in (select authorid from authors where last like '%Analyst1%'))
delete from analystsettings where coverageid in (select coverageid from researchcoverage where analystid in (select authorid from authors where last like '%Analyst2%'))
delete from analystsettings where coverageid in (select coverageid from researchcoverage where analystid in (select authorid from authors where last like '%Analyst3%'))
delete from analystsettings where coverageid in (select coverageid from researchcoverage where analystid in (select authorid from authors where last like '%Analyst4%'))
delete from analystsettings where coverageid in (select coverageid from researchcoverage where analystid in (select authorid from authors where last like '%Analyst5%'))
delete from researchcoverage where analystid in (select authorid from authors where last like '%Analyst1%')
delete from researchcoverage where analystid in (select authorid from authors where last like '%Analyst2%')
delete from researchcoverage where analystid in (select authorid from authors where last like '%Analyst3%')
delete from researchcoverage where analystid in (select authorid from authors where last like '%Analyst4%')
delete from researchcoverage where analystid in (select authorid from authors where last like '%Analyst5%')
go
delete from securities2 where TICKER like '%TICKER1%'
delete from authors where last like '%Analyst1%'
delete from industries where industryname like '%industry1%'
delete from securities2 where TICKER like '%TICKER2.LN%'
delete from authors where last like '%Analyst2%'
delete from industries where industryname like '%industry2%'
delete from securities2 where TICKER like '%TICKER3.HK%'
delete from authors where last like '%Analyst3%'
delete from industries where industryname like '%industry3%'
delete from securities2 where TICKER like '%TICKER4%'
delete from authors where last like '%Analyst4%'
delete from industries where industryname like '%industry4%'
delete from securities2 where TICKER like '%TICKER5%'
delete from authors where last like '%Analyst5%'
delete from industries where industryname like '%industry5%'
go
--Industry1/TICKER1/Analyst1
--US
--Add Company/Ticker using security administration screen. Do not use the insert statement below to add row as this will
--not add row to company table

/*
insert into Companies(Company)
select 'Company1'
insert into securities2 (TICKER, TICKERType,Company,Ric,IsActive,ExchangeCode,CurrencyCode,BenchmarkIndex,CountryCode,RegionId,CompanyId,IsPrimary,OrdNo,EditorId,EditDate)
select 'TICKER1','STOCK','Company1','TICKER1.N',-1,'NYSE','USD','SPX','US',CompanyId,1,1,1,1126,getdate()
from Companies where Company = 'Company1'
*/

insert into authors(Name,Last,First,Phone,IntEmail,ExtEmail,IsAnalyst,IsActive,EditorId,EditDate,TitleId,RegionId,IsResearch,MetricsEligible)
select 'QA Analyst1','Analyst1','QA','+111-111-1111','qaanal1','QA.Analyst1@bernstein.com',-1,-1,1126,getdate(),1,1,'Y','T'

insert into Industries(IndustryName,SectorId,EditorId,EditDate,IsResearch)
Select 'Industry1',7,1126,getdate(),'Y'
go
--Industry2/TICKER2/Analyst2
--PE
--Add Company/Ticker using security administration screen. Do not use the insert statement below to add row as this will
--not add row to company table
/*
insert into securities2 (TICKER, TICKERType,Company,Ric,IsActive,ExchangeCode,CurrencyCode,BenchmarkIndex,CountryCode,RegionId,EditorId,EditDate)
select 'TICKER2.LN','STOCK','Company2','TICKER2.L',-1,'LN','GBP','MSDLE15','GB',2,1126,getdate()
*/

insert into authors(Name,Last,First,Phone,IntEmail,ExtEmail,IsAnalyst,IsActive,EditorId,EditDate,TitleId,RegionId,IsResearch,MetricsEligible)
select 'QA Analyst2','Analyst2','QA','+40-111-1111','qaanal2','QA.Analyst2@bernstein.com',-1,-1,1126,getdate(),1,2,'Y','T'

insert into Industries(IndustryName,SectorId,EditorId,EditDate,IsResearch)
Select 'Industry2',7,1126,getdate(),'Y'
go
--Industry3/TICKER3/Analyst3
--AP
--Add Company/Ticker using security administration screen. Do not use the insert statement below to add row as this will
--not add row to company table
/*
insert into securities2 (TICKER, TICKERType,Company,Ric,IsActive,ExchangeCode,CurrencyCode,BenchmarkIndex,CountryCode,RegionId,EditorId,EditDate)
select 'TICKER3.HK','STOCK','Company3','TICKER3.HK',-1,'NYSE','HKD','MXAPJ','HK',4,1126,getdate()
*/
insert into authors(Name,Last,First,Phone,IntEmail,ExtEmail,IsAnalyst,IsActive,EditorId,EditDate,TitleId,RegionId,IsResearch,MetricsEligible)
select 'QA Analyst3','Analyst3','QA','+111-111-1111','qaanal3','QA.Analyst3@bernstein.com',-1,-1,1126,getdate(),4,1,'Y','T'

insert into Industries(IndustryName,SectorId,EditorId,EditDate,IsResearch)
Select 'Industry3',7,1126,getdate(),'Y'
go
--Industry4/TICKER4/Analyst4
--US
--Add Company/Ticker using security administration screen. Do not use the insert statement below to add row as this will
--not add row to company table
/*
insert into securities2 (TICKER, TICKERType,Company,Ric,IsActive,ExchangeCode,CurrencyCode,BenchmarkIndex,CountryCode,RegionId,EditorId,EditDate)
select 'TICKER4','STOCK','Company4','TICKER4.N',-1,'NYSE','USD','SPX','US',1,1126,getdate()
*/
insert into authors(Name,Last,First,Phone,IntEmail,ExtEmail,IsAnalyst,IsActive,EditorId,EditDate,TitleId,RegionId,IsResearch,MetricsEligible)
select 'QA Analyst4','Analyst4','QA','+111-111-1111','qaanal4','QA.Analyst4@bernstein.com',-1,-1,1126,getdate(),1,1,'Y','T'

insert into Industries(IndustryName,SectorId,EditorId,EditDate,IsResearch)
Select 'Industry4',7,1126,getdate(),'Y'
go
--Industry5/TICKER5/Analyst5
--US
insert into securities2 (TICKER, TICKERType,Company,Ric,IsActive,ExchangeCode,CurrencyCode,BenchmarkIndex,CountryCode,RegionId,EditorId,EditDate)
select 'TICKER5','STOCK','Company5','TICKER5.N',-1,'NYSE','USD','SPX','US',1,1126,getdate()

insert into authors(Name,Last,First,Phone,IntEmail,ExtEmail,IsAnalyst,IsActive,EditorId,EditDate,TitleId,RegionId,IsResearch,MetricsEligible)
select 'QA Analyst5','Analyst1','QA','+111-111-1111','qaanal5','QA.Analyst5@bernstein.com',-1,-1,1126,getdate(),1,1,'Y','T'

insert into Industries(IndustryName,SectorId,EditorId,EditDate,IsResearch)
Select 'Industry5',7,1126,getdate(),'Y'
go
/*--

US                EU                AP
TICKER1         TICKER2           TICKER3
TICKER4
TICKER5


Coverage
TICKER1 - Analyst1  - Industry1 - US
TICKER4 - Analyst4  - Industry1 - US
TICKER5 - Analyst5  - Industry5 - US

TICKER2 - Analyst2  - Industry2 - EU

TICKER3 - Analyst3  - Industry3 - AP

*/

select * from securities2 where ticker = 'ticker1'

select * from researchcoverage where securityid = 1308
select * from authors where authorid = 542