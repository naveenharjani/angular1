-- ipad.sql

select * from RVResearchCoverage where LaunchDate is not null and DropDate is null

-- WatchList
create table WatchList
(
  UserId int,
  WatchListTypeId int,  1 = Company, 2 = Industry, 3 = Analyst
  WatchListValueId int
  EditorId
  EditDate
)

insert into WatchList () values


-- Research & Commentary - Latest
declare @AsOfDate date
set @AsOfDate = dateadd(dd,-15,getdate())
select *
  RVD.Date,
  RVD.Title,
  'CompanyIds' = '',
  'IndustryIds' = '',
  'AnalystIds' = ''
from RVDocuments
where 
  RVD.Date >= @AsOfDate
Union
select *
  RVD.Date,
  RVD.Title,
  'CompanyIds' = '',
  'IndustryIds' = '',
  'AnalystIds' = ''
from RVAltDocuments
where 
  RVD.Date >= @AsOfDate


-- Research & Commentary - Watched
declare @AsOfDate date
set @AsOfDate = dateadd(dd,-15,getdate())
--Reports for companies in watchlist
select *
  RVD.DocId
  RVD.Date,
  RVD.Title,
  W.WatchListTypeId 1,
  W.WatchListValue
from RVDocuments RVD join RVDocIndustries RVDI on RVD.DocId = RVDI.DocId
join WatchList W on RVDI.IndustryId = W.WatchListValue
where 
  RVD.Date >= @AsOfDate and
  W.WatchListType = 1
Union
--Reports for industries in watchlist
select *
  RVD.DocId
  RVD.Date,
  RVD.Title,
  W.WatchListTypeId 2,
  W.WatchListValue
from RVDocuments RVD join RVDocIndustries RVDI on RVD.DocId = RVDI.DocId
join WatchList W on RVDI.IndustryId = W.WatchListValue
where 
  RVD.Date >= @AsOfDate and
  W.WatchListType = 2
Union
----Reports for securities in watchlist
select *
  RVD.DocId
  RVD.Date,
  RVD.Title,
  W.WatchListTypeId 3,
  W.WatchListValue
from RVDocuments RVD join RVDocIndustries RVDI on RVD.DocId = RVDI.DocId
join WatchList W on RVDI.IndustryId = W.WatchListValue
where 
  RVD.Date >= @AsOfDate and
  W.WatchListType = 3
  
  
  
  
-- Company coverage listing
select RVRC.*, RVS.*, RVF.*
from RVResearchCoverage RVRC
join RVSecurities RVS on RVS.SecurityId = RVRC.SecurityId
join RVFinancials RVF on RVF.SecurityId = RVRC.SecurityId
where RVRC.LaunchDate is not null and RVRC.DropDate is null

select * from RVFinancialsLatest

-- Industry coverage listing
select distinct
  RVI.Industry,
  RVI.IndustryId,
  RVA.Name,
  RVA.AnalystId
  -- RVRC.*,
  -- RVI.*
from RVResearchCoverage RVRC
join RVIndustries RVI on RVI.IndustryId = RVRC.IndustryId
join RVAnalysts RVA on RVA.AnalystId = RVRC.AnalystId
where RVRC.LaunchDate is not null and RVRC.DropDate is null
order by RVI.Industry, RVA.Name

-- Analyst coverage listing
select distinct
  RVA.Name,
  RVA.AnalystId,
  RVA.Phone,
  RVA.Email
  -- RVRC.*,
  -- RVI.*
from RVResearchCoverage RVRC
join RVAnalysts RVA on RVA.AnalystId = RVRC.AnalystId
where RVRC.LaunchDate is not null and RVRC.DropDate is null
order by RVA.Name




select * from RVIndustries -- 101
select * from RVAnalysts -- 146
select * from RVSecurities -- 1083

declare @RefreshDate datetime

--select @RefreshDate = '1/1/2003'
select @RefreshDate = '1/1/2010'

select '@RefreshDate' = @RefreshDate

-- **** Master Coverage Lists
-- Industries - All (95)
select distinct RVRC.IndustryId, RVI.Industry, 'Active' = 'Y' -- , RVI.EditDate,
from RVResearchCoverage RVRC
join RVIndustries RVI on RVI.IndustryId = RVRC.IndustryId
where RVI.EditDate > @RefreshDate
-- Authors - All (105)
select distinct RVRC.AnalystId, RVA.Last, RVA.First, RVA.Phone, RVA.Email, 'Active' = 'Y' -- , RVA.EditDate
from RVResearchCoverage RVRC
join RVAnalysts RVA on RVA.AnalystId = RVRC.AnalystId
where RVA.EditDate > @RefreshDate
-- Companies - All (1072)
select distinct RVRC.AnalystId, RVS.Ticker, RVS.Company, 'Rating' = 'O', 'Target' = '450.00', 'Currency' = 'USD', 'ActionTag' = 'Upgrade', 'Active' = 'Y' -- , RVS.EditDate
from RVResearchCoverage RVRC
join RVSecurities RVS on RVS.SecurityId = RVRC.SecurityId
where RVS.EditDate > @RefreshDate

-- **** Reports

select top 50 * from RVDocuments
select top 50 * from Publications order by PubNo desc


declare @RefreshDate datetime

select @RefreshDate = dateadd(d, -14, getdate())
select @RefreshDate

-- Latest
select DocId, Date, DocTypeId, Title --, 'ApprovedDate' = getdate(), 'PublishedDate' = getdate()
from RVDocuments
where Date > @RefreshDate
union
select DocId, Date, DocTypeId, Title --, 'ApprovedDate' = getdate(), 'PublishedDate' = getdate()
from RVAltDocuments
where Date > @RefreshDate
order by DocId desc

-- ***** alter RVDocuments to include PublishedDate (rename), FileSize, Version
-- ***** New RVDeletedDocuments
-- ***** New RVAltDeletedDocuments
-- ***** alter RVIndustries, RVAnalysts, RVSecurities to include Status
