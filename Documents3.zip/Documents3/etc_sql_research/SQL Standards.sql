-- SQL Standards.sql

Note:  
ANSI_NULLS is one of seven SET options that must be set to required values when dealing with indexes on computed columns or indexed views.
The options ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, and CONCAT_NULL_YIELDS_NULL must also be set to ON,
and NUMERIC_ROUNDABORT must be set to OFF. 

-- Make sure that all of the session settings are set properly 
IF sessionproperty('ARITHABORT')              = 0 SET ARITHABORT ON 
IF sessionproperty('CONCAT_NULL_YIELDS_NULL') = 0 SET CONCAT_NULL_YIELDS_NULL ON 
IF sessionproperty('QUOTED_IDENTIFIER')       = 0 SET QUOTED_IDENTIFIER ON 
IF sessionproperty('ANSI_NULLS')              = 0 SET ANSI_NULLS ON 
IF sessionproperty('ANSI_PADDING')            = 0 SET ANSI_PADDING ON 
IF sessionproperty('ANSI_WARNINGS')           = 0 SET ANSI_WARNINGS ON 
IF sessionproperty('NUMERIC_ROUNDABORT')      = 1 SET NUMERIC_ROUNDABORT OFF 
GO

-- BEGIN GEORGE

-- Settable database options:
EXEC sp_dboption

-- The following options are set (ON):      
EXEC sp_dboption 'Research'

-- Retrieve the individual settings
EXEC sp_dboption 'Research', 'quoted identifier'
EXEC sp_dboption 'Research', 'ANSI nulls'

-----------------
-- ANSI_NULLS  --
-----------------
-- DEFINITION: Specify SQL-92 compliant behavior when comparson operators (=) and (<>) are used with null values.
--    ANSI_NULLS = ON:  a SELECT statement using "WHERE column_name = NULL" returns 0 rows even if there are NULL values in column_name
--                      a SELECT statement using "WHERE column_name <> NULL" returns 0 rows even if there are non-NULL values in column_name
--    ANSI_NULLS = OFF: a SELECT statement using "WHERE column_name = NULL" returns rows with NULL values in column_name
--                      a SELECT statement using "WHERE column_name <> NULL" returns rows with non-NULL values in column_name

-- SCOPE: Database
--   DEFAULT: OFF
-- SCOPE: Session (SQL Query Analyzer, ODBC, or OLEDB connection)
--   DEFAULT: ON

-- SETTING: OFF

------------------------
-- QUOTED_IDENTIFIER  --
------------------------
-- DEFINITION: Specify SQL-92 compliant behavior regarding to quotation mark delimiting indentifiers and literal strings. 
--             Identifiers delimited by double quotation marks can be reserved keywords or characters not usually allowed by TSQL syntax
--   QUOTED_IDENTIFIER = ON: CREATE TABLE "select" ("identity" int IDENTITY, "order" int) is valid
--                         : If literal string contains single quotation mark, it needs to be represented by two single quotation marks
--                         : I.E. 'It''s a sunny day"

--   QUOTED_IDENTIFIER = OFF: CREATE TABLE "select" ("identity" int IDENTITY, "order" int) is not valid
--                          : Literal strings can be delimited bu single or double quotation mark.  If literal string is 
--                          : delimited by double quotation mark, the literal string can contain embedded single quotation marks
--                          : I.E. "It's a sunny day"

-- SCOPE: Database
--   DEFAULT: OFF
-- SCOPE: Session (SQL Query Analyzer, ODBC, or OLEDB connection)
--   DEFAULT: ON 

-- SETTING: OFF


SELECT SESSIONPROPERTY ('QUOTED_IDENTIFIER') -- DEFAULT IS ON(1), OFF is (0)
SELECT SESSIONPROPERTY ('ANSI_NULLS')        -- DEFAULT IS ON(1), OFF is (0)


-- THE SET OPTIONS PRECEDING THE SP REFLECT THE OPTIONS WHEN CREATING THE SP
SET QUOTED_IDENTIFIER [ON|OFF]
GO
SET ANSI_NULLS [ON|OFF]
GO

-- ***
-- *** SCRIPTING STANDARDS - ARE THESE PER OBJECT OVERRIDES?
-- ***

-- WHAT ARE THE DATABASE SETTINGS?  ALL OUR SCRIPTS WILL INHERIT
-- NO ACCESS TO PRODUCTION (AC2KAMA240-SCBIS_PRD1) DATABASE TO GET THE SETTINGS

-- BEFORE SP CREATION
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


-- # of Occurrences of SET QUOTED_IDENTIFIER ON = 1
-- None

--
-- TEST: SP that uses '= NULL'
-- NONE

--
-- TEST: SP that uses ""
-- NONE

--
-- TEST: SP that uses 'SELECT *'
-- NONE

--
-- TEST: SP that uses 'INSERT' with out explicit column name
-- spAddEventLog

--
-- TEST:  Review SP usage of
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO


-- NO EMBEDDED SQL!

