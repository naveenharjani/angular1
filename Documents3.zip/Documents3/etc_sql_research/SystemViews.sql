-- SystemViews.sql

/*

USE Master
GO

-- ***
-- *** LOGINS
-- ***

select * from master..syslogins

-- DE_IIS   iIS00!#$
-- DE_MTS   mTS00!#$
-- DE_AddIn aDD00!#$

-- CREATE LOGIN PortfolioTrading WITH PASSWORD = 'Alliance1';

-- EXEC sp_droplogin 'DE_AddIn'

-- When transferring databases, the logins, groups and users are transferred.
-- However, if they did not exist on destination server, you must reset passwords from null using ISQL_w
sp_password null,           'instsa'       -- Execute using ISQL_w login: sa
sp_password null,           'mTS00!#$'     -- Execute using ISQL_w login: DE_MTS
sp_password null,           'iIS00!#$'     -- Execute using ISQL_w login: DE_IIS
sp_password null,           'aDD00!#$'     -- Execute using ISQL_w login: DE_Addin
sp_password 'changeme',     'iIS00!#$'     -- Execute using ISQL_w login: CS_IIS
sp_password 'instsa',       'instsa!#$'    -- Execute using ISQL_w login: sa
sp_password 'instsa!#$',    'instsa'       -- Execute using ISQL_w login: sa
sp_password 'a11iance',     'slx!#$'       -- DEV Saleslogix database 01/19/2006
sp_password 'sales0601',    'sales0601!#$' -- PROD Saleslogix database 09/14/2006
sp_password 'sales0601!#$', 'slx!#$'       -- PROD Saleslogix database 09/15/2006
sp_password 'alliance1',    'ab!#$'        -- Frank 10/11/2006
sp_password 'alliance9',    'ab!#$'        -- FusilloFP 09/26/2008

*/

USE Research
GO

-- ***
-- *** PRINCIPALS
-- ***

select * from sys.database_principals where type in ('S', 'U') order by type, name

/*

select * from sys.database_principals order by type, name

-- CREATE USER PortfolioTrading FOR LOGIN PortfolioTrading; 

*/

-- ***
-- *** ROLES AND MEMBERS
-- ***

SELECT
  'Role' = CONVERT(char(20), R.name),
  'Member' = CONVERT(char(20), M.name)
FROM sys.database_role_members RM
JOIN sys.database_principals R ON R.principal_id = RM.role_principal_id
JOIN sys.database_principals M ON M.principal_id = RM.member_principal_id
ORDER BY 1, 2

/*

select * from sys.database_role_members

select * from sys.database_principals order by 3

db_owner             SCBIS_BG
db_securityadmin     SCBIS_Admin
db_securityadmin     SCBIS_Admin2
PowerUsers           SCBIS_Admin
PowerUsers           SCBIS_Admin2

-- Members of the db_securityadmin fixed database role can add users to any user-defined role.

*/

-- ***
-- *** PERMISSIONS
-- ***

select
  P.permission_name,
  O.name,
  U.name
from sys.database_permissions P
join sys.objects O on O.object_id = P.major_id
join sys.database_principals U on U.principal_id = P.grantee_principal_id
where U.name not in ('PowerUsers', 'DE_IIS', 'DE_MTS', 'SCBIS_Reports')
order by 1, 3, 2
--order by 3, 2, 1

-- All sp's not granted EXECUTE to PowerUsers
select * from sys.objects where type = 'P' and name not in
(
-- All sp's granted EXECUTE to PowerUsers
select O.name
from sys.objects O
join sys.database_permissions P on P.major_id = O.object_id
join sys.database_principals U on U.principal_id = P.grantee_principal_id
where P.permission_name = 'EXECUTE' and U.name = 'PowerUsers'
--order by 1
)
order by name

/*

select * from sys.database_permissions
select * from sys.objects
select * from sys.database_principals


-- GRANT UPDATE  ON ResearchCoverage       TO   DE_IIS
-- GRANT UPDATE  ON ResearchCoverage       TO   PowerUsers
-- GRANT UPDATE  ON Securities2            TO   SCBIS_Reports  -- 10/09/2009 GICS updates from XLS
-- GRANT EXECUTE ON spGetImplicitChanges   to "ac\sjoyce"      -- 09/04/2014

-- REVOKE UPDATE  ON ResearchCoverage               TO DE_IIS         -- 10/19/2009
-- REVOKE SELECT  ON DistributionFiles              TO DE_MTS         -- 10/19/2009
-- REVOKE UPDATE  ON ResearchCoverage               TO PowerUsers     -- 10/19/2009
-- REVOKE EXECUTE ON spGetImplicitChanges           TO "ac\sjoyce"    -- 09/28/2016

*/

-- ***
-- *** SQL OBJECTS
-- ***

select * from sys.objects where type in ('PK', 'UQ', 'F') order by type, name

/*

select * from sys.objects order by type, name

select * from sys.objects where is_ms_shipped = 0 and type in ('D', 'F', 'PK', 'UQ') order by type, name
select type, type_desc, name from sys.objects where is_ms_shipped = 0 and type in ('D', 'F', 'PK', 'UQ') order by type, name

select '# Tables' = count(*) from sysobjects where type = 'U'
select '# SPs'    = count(*) from sysobjects where type = 'P'

select * from sys.databases

*/
