-- CRM.sql
-- 02/21/2017

/*
DEV : W05d0043\salgx_dev6
QA  : W05D0012\SALGX_QA12
PRD : SLXPRDDB,16083

Database=SlxExternal;
User ID=research_db_svc;
*/

-- No longer exists

select * from SalesLogix.sysdba.CONTACT

select * from SalesLogix.sysdba.ACCOUNT

select * from SalesLogix.sysdba.SCB_WEB_USAGE

select * from SalesLogix.sysdba.SCB_USAGE_LOGSHIPPER

select * FROM SalesLogix.SCB_UNIQUE_READERS

select * from SlxExternal.dbo.vwUniqueReaders -- Not used since 9/3/2019

select * from SlxExternal.dbo.vwWebUsage      -- Not used since 9/3/2019

select * from SlxExternal.dbo.vwReadDetails   -- Not used since 9/3/2019

select * from SlxExternal.dbo.vw_Readership   -- Not used since 9/3/2019

exec SlxExternal.dbo.GetReadSummary           -- Not used since 9/3/2019

-- Exists

SELECT top 100 * FROM SlxExternal.dbo.vwContentUsage ORDER BY USAGETIME DESC -- Based on SlxExternal UsageLogshipper

-- Active

select top 500 * from Compass.dbo.ACCOUNT

select top 500 * from Compass.dbo.CONTACT

select top 1000 * from SlxExternal.dbo.ContentUsage order by UsageId desc -- Research, Models, Decks+ 

select top 1000 * from SlxExternal.dbo.WebUsage order by WebUsageId desc -- Legacy Research Last 2018-11-19

select top 1000 * from SlxExternal.dbo.UsageLogshipper order by UsageId desc -- Events

select top 1000 * from SlxExternal.dbo.WSGSiteActivity order by DateTimeStamp desc -- GQS

-- Warehouse
select top 100 * from SlxExternal.dbo.Readership order by ReadDate desc

select top 500 * from slxexternal.dbo.Readership
where Type = 'PortalUsage'
order by ReadershipID desc

select distinct Type from slxexternal.dbo.Readership
-- ResearchUsage, PortalUsage

select distinct AccountType from slxexternal.dbo.Readership
-- Investor, Other

select Type, Source, count(*) as Num from slxexternal.dbo.Readership
group by Type, Source
order by 1, 2

-- Volumes - 12/2018
select count(*) Num from SlxExternal.dbo.ContentUsage -- .58M
select count(*) Num from SlxExternal.dbo.WebUsage -- 16.0M
select count(*) Num from SlxExternal.dbo.UsageLogshipper -- .36M
select count(*) Num from SlxExternal.dbo.WSGSiteActivity -- .34M

-- Events
select ContentType, count(*) Num from SlxExternal.dbo.UsageLogshipper group by ContentType

-- GQS
select top 1000 * from SlxExternal.dbo.WSGSiteActivity order by DateTimeStamp desc

select Msg, count(*) Num from SlxExternal.dbo.WSGSiteActivity group by Msg order by 1


-- 08/01/2019 Racine
-- 01/01/2019 to 06/30/2019
-- Num unique clients (investors)
-- Num unique contacts (investors)

DECLARE @SinceDate DATE, @UntilDate DATE
SET @SinceDate = '01/01/2017'
SET @UntilDate = '12/31/2017'

SELECT
'SinceDate' = @SinceDate, 
'UntilDate' = @UntilDate,
'Num unique clients (investors)'      = (SELECT COUNT(DISTINCT AccountId) FROM [SlxExternal].[dbo].[Readership] WHERE Type = 'ResearchUsage' AND AccountType =  'Investor' AND ReadDate BETWEEN @SinceDate AND @UntilDate),
'Num unique contacts (investors)'     = (SELECT COUNT(DISTINCT ContactId) FROM [SlxExternal].[dbo].[Readership] WHERE Type = 'ResearchUsage' AND AccountType =  'Investor' AND ReadDate BETWEEN @SinceDate AND @UntilDate),
'Num unique clients (non-investors)'  = (SELECT COUNT(DISTINCT AccountId) FROM [SlxExternal].[dbo].[Readership] WHERE Type = 'ResearchUsage' AND AccountType <> 'Investor' AND ReadDate BETWEEN @SinceDate AND @UntilDate),
'Num unique contacts (non-investors)' = (SELECT COUNT(DISTINCT ContactId) FROM [SlxExternal].[dbo].[Readership] WHERE Type = 'ResearchUsage' AND AccountType <> 'Investor' AND ReadDate BETWEEN @SinceDate AND @UntilDate)
