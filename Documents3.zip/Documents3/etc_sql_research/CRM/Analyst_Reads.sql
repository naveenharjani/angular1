-- Analyst_Reads.sql
-- 06/19/2019

/*
Industry: U.S. Portfolio Strategy
Noah Weisberger
Alex Timcenko
Chris Brigham
*/

-- CRM: SLXPRDDB,16083 | research_db_svc
SELECT LoginId, 'Year' = Year(AccessDate), 'Month' = Month(AccessDate), 'Clicks' = Count(*)
FROM slxexternal.dbo.ContentUsage w
WHERE LoginId IN ('noah.weisberger@bernstein.com', 'aleksandar.timcenko@bernstein.com','christopher.brigham@bernstein.com')
GROUP BY LoginId, Year(AccessDate), Month(AccessDate)
ORDER BY Count(*) desc, Year(AccessDate), Month(AccessDate)

SELECT LoginId, ContentId, AccessDate, UserHost, ContentTypeId, Status
FROM slxexternal.dbo.ContentUsage w
WHERE LoginId IN ('noah.weisberger@bernstein.com', 'aleksandar.timcenko@bernstein.com','christopher.brigham@bernstein.com')
and year(AccessDate) = 2019
ORDER BY w.AccessDate DESC

/*
SELECT WU.Access_Email_Addr, WU.PUBNO, WU.ACCESSDATE, WU.SOURCEID, WU.USER_AGENT
FROM SlxExternal.dbo.WebUsage WU
WHERE Access_Email_Addr = 'noah.weisberger@bernstein.com' 
ORDER BY WU.ACCESSDATE DESC

SELECT Email, Site, PubNo, ReadDate, ContentType
FROM SlxExternal.dbo.RVPortalUsage
WHERE Email = 'noah.weisberger@bernstein.com'

SELECT * FROM SlxExternal.dbo.RVAnalysts Where name like '%weisberger%'
*/


-- Research: beehivedb, 16102

SELECT * FROM Research.dbo.CartLog WHERE UserId IN (773, 803, 983) ORDER BY EditDate DESC

SELECT * FROM Research.dbo.ViewLog WHERE UserId IN (773, 803, 983) ORDER BY EditDate DESC

-- SELECT * FROM Authors Where name like '%weisberger%' or name like '%Timcenko%' or name like '%Brigham%'
