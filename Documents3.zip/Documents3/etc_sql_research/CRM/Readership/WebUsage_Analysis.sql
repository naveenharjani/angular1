-- WebUsage_Analysis.sql
-- 10/26/2017

/* 
SLXPRDDB,16083 | research_db_svc  
*/

-- Get Web Usage used by Bloomberg.com email
-- 10/26/2017
SELECT WU.PUBNO, WU.ACCESSDATE, WU.ACCESS_EMAIL_ADDR, 
       RLS.Source,
       RVD.Title, CONVERT(varchar, RVD.Date, 101) AS Date
FROM SlxExternal.dbo.WebUsage WU
JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = WU.PUBNO
JOIN SlxExternal.dbo.RVLinkSources RLS ON RLS.SourceId = WU.SOURCEID
WHERE WU.ACCESS_EMAIL_ADDR LIKE '%@bloomberg.com'
-- AND RLS.SourceId = 45  -- Sector Specialist
ORDER BY WU.ACCESSDATE DESC


-- Get Web Usage on Blackberry devices - Check USER_AGENT
-- 11/07/2017
SELECT WU.PUBNO, WU.ACCESSDATE, WU.ACCESS_EMAIL_ADDR, WU.USER_AGENT, RLS.Source, WU.STATUS, WU.FILEFOUND
FROM SlxExternal.dbo.WebUsage WU
JOIN SlxExternal.dbo.RVLinkSources RLS ON RLS.SourceId = WU.SOURCEID
WHERE (USER_AGENT like '%BlackBerry%' OR USER_AGENT like '%BB10%' OR USER_AGENT like '%BBB100%')
AND  WU.ACCESS_EMAIL_ADDR in ('steven.miller@bernstein.com',
                              'michael.chang@alliancebernstein.com',
  				              'michael.chang@abglobal.com')
ORDER BY WU.ACCESSDATE DESC

-- SELECT distinct USER_AGENT FROM SlxExternal.dbo.WebUsage
