-- McKinseyReads.sql
-- 01/31/2018
-- SLXPRDDB,16083 | research_db_svc

-- Colin(01/31/2018)
-- Can someone provide me with readership statistics for Louise Ponsones at McKinsey for last year, please?

SELECT
  RVD.Title, C.Email, 'ReadDate' = VW.Read_Date,
  VW.PubNo, 'ReportDate' = RVD.Date,
  C.FirstName, C.LastName
FROM SlxExternal.dbo.vwUniqueReaders VW
JOIN Compass.dbo.Contact C ON C.SLXContactID = VW.CONTACTID
JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = VW.PUBNO
WHERE C.Email = 'louise_ponsones@mckinsey.com'
  AND VW.READ_DATE BETWEEN '01/01/2017' AND '12/31/2017'
ORDER BY VW.READ_DATE ASC