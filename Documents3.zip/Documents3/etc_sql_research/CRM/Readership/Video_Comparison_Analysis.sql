-- Video_Comparison_Analysis.sql
-- 03/24/2014

-- 03/24/2014 - Dan Dowd
-- 09/10/2014 - Chris Hogbin

-- SLXPRDDB\SALGX_PRD,16083

-- ***
-- *** BEGIN - Analysis for 1 video
-- ***

USE SlxExternal
GO

DECLARE @VideoId INT
DECLARE @ReportId INT

SET @VideoId = 102515
SET @VideoId = 101816

-- Get last published related call
SET @ReportId = (select MAX(RelatedDocId) FROM RVRelatedDocuments WHERE DocId = @VideoId)

-- Read research vs. Watched video - Compare at contact level
-- These are people counts, not click counts!
SELECT
  'VideoId' = @VideoId,
  'ReportId' = @ReportId,
  'ReadReport'       = ( SELECT COUNT(DISTINCT CONTACTID) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @ReportId ),
  'WatchedVideo'     = ( SELECT COUNT(DISTINCT CONTACTID) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @VideoId ),
  'ReadReportOnly'   = ( SELECT COUNT(DISTINCT CONTACTID) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PUBNO = @ReportId
                         AND CONTACTID NOT IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @VideoId) ),
  'WatchedVideoOnly' = ( SELECT COUNT(DISTINCT CONTACTID) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PUBNO = @VideoId
                         AND CONTACTID NOT IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @ReportId) ),
  'ReadAndWatched'   = ( SELECT COUNT(DISTINCT CONTACTID) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @ReportId
                         AND CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @VideoId) ),
  'Date'  = (select Date from RVDocuments where DocId = @ReportId),
  'Title' = (select Title from RVDocuments where DocId = @ReportId)

-- To compare first read vs. first watch timestamp is needed
-- Not in SCB_UNIQUE_READERS so use non-view base table SCB_WEB_USAGE
-- Re-apply filter used by view (achieved by SCB_UNIQUE_READERS sub query)
-- Beware read-watch-view and watch-read-watch and use only first-read vs. first-watch, i.e. MIN(ACCESSDATE)

/*

-- First report read
SELECT SWU_R.CONTACTID, MIN(SWU_R.ACCESSDATE)
FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_R
WHERE SWU_R.PubNo = @ReportId
AND SWU_R.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @ReportId)
GROUP BY SWU_R.CONTACTID

-- First video watch
SELECT SWU_V.CONTACTID, MIN(SWU_V.ACCESSDATE)
FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_V 
WHERE SWU_V.PubNo = @VideoId
AND SWU_V.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @VideoId)
GROUP BY SWU_V.CONTACTID

*/

SELECT 'VideoAfterReport' = COUNT(DISTINCT SWU_V.CONTACTID) 
FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_V 
JOIN SalesLogix.sysdba.SCB_WEB_USAGE SWU_R ON SWU_R.ContactId = SWU_V.ContactId AND SWU_R.PubNO = @ReportId
JOIN
( -- First report read
  SELECT SWU_R.CONTACTID, MIN(SWU_R.ACCESSDATE) AS ACCESSDATE
  FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_R
  WHERE SWU_R.PubNo = @ReportId
  AND SWU_R.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @ReportId)
  GROUP BY SWU_R.CONTACTID
) VR ON VR.CONTACTID = SWU_R.CONTACTID
JOIN
( -- First video watch
  SELECT SWU_V.CONTACTID, MIN(SWU_V.ACCESSDATE) AS ACCESSDATE
  FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_V 
  WHERE SWU_V.PubNo = @VideoId
  AND SWU_V.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @VideoId)
  GROUP BY SWU_V.CONTACTID
) VV ON VV.CONTACTID = SWU_V.CONTACTID
WHERE SWU_V.PubNo = @VideoId
AND SWU_V.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @VideoId)
AND VV.ACCESSDATE > VR.ACCESSDATE

SELECT 'ReportAfterVideo' = COUNT(DISTINCT SWU_R.CONTACTID) 
FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_R 
JOIN SalesLogix.sysdba.SCB_WEB_USAGE SWU_V ON SWU_V.ContactId = SWU_R.ContactId AND SWU_V.PubNO = @VideoId
JOIN
( -- First report read
  SELECT SWU_R.CONTACTID, MIN(SWU_R.ACCESSDATE) AS ACCESSDATE
  FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_R
  WHERE SWU_R.PubNo = @ReportId
  AND SWU_R.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @ReportId)
  GROUP BY SWU_R.CONTACTID
) VR ON VR.CONTACTID = SWU_R.CONTACTID
JOIN
( -- First video watch
  SELECT SWU_V.CONTACTID, MIN(SWU_V.ACCESSDATE) AS ACCESSDATE
  FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_V 
  WHERE SWU_V.PubNo = @VideoId
  AND SWU_V.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @VideoId)
  GROUP BY SWU_V.CONTACTID
) VV ON VV.CONTACTID = SWU_V.CONTACTID
WHERE SWU_R.PubNo = @ReportId
AND SWU_R.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = @ReportId)
AND VR.ACCESSDATE > VV.ACCESSDATE

-- ***
-- *** END - Analysis for 1 video
-- ***

-- ***
-- *** BEGIN - Analysis for all videos (users not clicks!)
-- ***

USE SlxExternal
GO

SET NOCOUNT ON

-- Virtual table to store the Video-Last Publication link
DECLARE	@VideoReports TABLE (VideoId INT, ReportId INT)

INSERT	@VideoReports(VideoId, ReportId)
SELECT 'VideoId'  = RVD.DocId,
       'ReportId' = (SELECT MAX(RelatedDocId) FROM RVRelatedDocuments WHERE DocId = RVD.DocId)
 FROM RVDocuments RVD WHERE RVD.DocTypeId = 10   -- Videos only
--SELECT * FROM @VideoReports

-- Virtual table to store Video info - Read research vs. Watched video - Compare at contact level [not read click counts]
DECLARE	@WatchedVideo TABLE ([Date]               DATETIME, 
                              VideoId             INT, 
                              ReportId            INT, 
                              Title               VARCHAR(255),
                              Analyst             VARCHAR(100),
                              ReadReport          INT, 
                              WatchedVideo        INT, 
                              ReadReportOnly      INT, 
                              WatchedVideoOnly    INT, 
                              ReadAndWatched      INT,
                              VideoAfterReport    INT, 
                              ReportAfterVideo    INT)

INSERT	@WatchedVideo ([Date],
                      VideoId, 
                      ReportId,
                      Title,
                      Analyst,
                      ReadReport, 
                      WatchedVideo, 
                      ReadReportOnly, 
                      WatchedVideoOnly, 
                      ReadAndWatched)
SELECT
  'Date'              = ( SELECT Date from RVDocuments where DocId = VR.ReportId),
  'VideoId'           = VR.VideoId,
  'ReportId' = VR.ReportId,
  'Title'             = ( SELECT Title from RVDocuments where DocId = VR.ReportId),
  'Analyst'           = ( SELECT TOP 1 Last as [text()] FROM RVDocAnalysts where DocId = VR.ReportId order by OrdinalId),
  'ReadReport'        = ( SELECT COUNT(DISTINCT CONTACTID) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VR.ReportId ),
  'WatchedVideo'      = ( SELECT COUNT(DISTINCT CONTACTID) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VR.VideoId ),
  'ReadReportOnly'    = ( SELECT COUNT(DISTINCT CONTACTID) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PUBNO = VR.ReportId
                         AND CONTACTID NOT IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VR.VideoId) ),
  'WatchedVideoOnly'  = ( SELECT COUNT(DISTINCT CONTACTID) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PUBNO = VR.VideoId
                         AND CONTACTID NOT IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VR.ReportId) ),
  'ReadAndWatched'           = ( SELECT COUNT(DISTINCT CONTACTID) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VR.ReportId
                         AND CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VR.VideoId) )
FROM @VideoReports VR
--SELECT * FROM @WatchedVideo

-- To get VideoAfterReport and ReportAfterVideo values, use date timestamp in base table SCB_WEB_USAGE, timestamp missing in SCB_UNIQUE_READERS
UPDATE @WatchedVideo
SET VR.VideoAfterReport = ( SELECT 'VideoAfterReport' = COUNT(DISTINCT SWU_V.CONTACTID) 
                            FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_V 
                            JOIN SalesLogix.sysdba.SCB_WEB_USAGE SWU_R ON SWU_R.ContactId = SWU_V.ContactId AND SWU_R.PubNO = VRP.ReportId
                            JOIN
                             ( -- First report read
                               SELECT SWU_R.CONTACTID, MIN(SWU_R.ACCESSDATE) AS ACCESSDATE
                               FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_R
                               WHERE SWU_R.PubNo = VRP.ReportId
                               AND SWU_R.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VRP.ReportId)
                               GROUP BY SWU_R.CONTACTID
                             ) VR ON VR.CONTACTID = SWU_R.CONTACTID
                            JOIN
                             ( -- First video watch
                               SELECT SWU_V.CONTACTID, MIN(SWU_V.ACCESSDATE) AS ACCESSDATE
                               FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_V 
                               WHERE SWU_V.PubNo = VRP.VideoId
                               AND SWU_V.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VRP.VideoId)
                               GROUP BY SWU_V.CONTACTID
                             ) VV ON VV.CONTACTID = SWU_V.CONTACTID
                         WHERE SWU_V.PubNo = VRP.VideoId
                         AND SWU_V.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VRP.VideoId)
                         AND VV.ACCESSDATE > VR.ACCESSDATE)
FROM @VideoReports VRP
JOIN @WatchedVideo VR ON VR.VideoId = VRP.VideoId
WHERE VR.VideoId = VRP.VideoId


UPDATE @WatchedVideo
SET VR.ReportAfterVideo = ( SELECT 'ReportAfterVideo' = COUNT(DISTINCT SWU_R.CONTACTID) 
                            FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_R 
                            JOIN SalesLogix.sysdba.SCB_WEB_USAGE SWU_V ON SWU_V.ContactId = SWU_R.ContactId AND SWU_V.PubNO = VRP.VideoId
                            JOIN
                            ( -- First report read
                              SELECT SWU_R.CONTACTID, MIN(SWU_R.ACCESSDATE) AS ACCESSDATE
                              FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_R
                              WHERE SWU_R.PubNo = VRP.ReportId
                              AND SWU_R.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VRP.ReportId)
                              GROUP BY SWU_R.CONTACTID
                            ) VR ON VR.CONTACTID = SWU_R.CONTACTID
                            JOIN
                            ( -- First video watch
                              SELECT SWU_V.CONTACTID, MIN(SWU_V.ACCESSDATE) AS ACCESSDATE
                              FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU_V 
                              WHERE SWU_V.PubNo = VRP.VideoId
                              AND SWU_V.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VRP.VideoId)
                              GROUP BY SWU_V.CONTACTID
                            ) VV ON VV.CONTACTID = SWU_V.CONTACTID
                            WHERE SWU_R.PubNo = VRP.ReportId
                            AND SWU_R.CONTACTID IN (SELECT CONTACTID FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = VRP.ReportId)
                            AND VR.ACCESSDATE > VV.ACCESSDATE)
FROM @VideoReports VRP
JOIN @WatchedVideo VR ON VR.VideoId = VRP.VideoId
WHERE VR.VideoId = VRP.VideoId

--SELECT * FROM @WatchedVideo

-- Numbers represent people not clicks!
SELECT 
       'Date' = CONVERT(varchar, Date,101),
       convert(varchar(30), Analyst) Analyst,
       VideoId, 
       ReportId, 
       ReadReport, 
       WatchedVideo, 
       ReadReportOnly,
       'ReadReportOnly%'    = CONVERT( DECIMAL(10,2),
                                      CONVERT( DECIMAL(10,2), (ReadReportOnly * 100))/CONVERT( DECIMAL(10,2), (ReadReportOnly + WatchedVideoOnly + ReadAndWatched))
                                ),
       WatchedVideoOnly,
       'WatchedVideoOnly%'    = CONVERT( DECIMAL(10,2),
                                      CONVERT( DECIMAL(10,2), (WatchedVideoOnly * 100))/CONVERT( DECIMAL(10,2), (ReadReportOnly + WatchedVideoOnly + ReadAndWatched))
                                ),
       ReadAndWatched,
       'ReadAndWatched%'    = CONVERT( DECIMAL(10,2),
                                      CONVERT( DECIMAL(10,2), (ReadAndWatched * 100))/CONVERT( DECIMAL(10,2), (ReadReportOnly + WatchedVideoOnly + ReadAndWatched))
                                ),
       VideoAfterReport,
       'VideoAfterReport%'    = CONVERT( DECIMAL(10,2),
                                      CONVERT( DECIMAL(10,2), (VideoAfterReport * 100))/CONVERT( DECIMAL(10,2), (VideoAfterReport + ReportAfterVideo))
                                ),
       ReportAfterVideo,
       'ReportAfterVideo%'    = CONVERT( DECIMAL(10,2),
                                      CONVERT( DECIMAL(10,2), (ReportAfterVideo * 100))/CONVERT( DECIMAL(10,2), (VideoAfterReport + ReportAfterVideo))
                                ),
       Title
FROM @WatchedVideo
ORDER BY VideoId ASC

SET NOCOUNT OFF

-- ***
-- *** END - Analysis for all videos (users not clicks!)
-- ***
