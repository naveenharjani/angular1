-- VideoReads.sql
-- SLXPRDDB\SALGX_PRD,16083

-- Total Unique and Raw Reads for Video and RelatedPublications
SELECT
  RVD.DocId,
  'UniqueReads' = ( SELECT count(*) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = RVD.DocId),
  'RawReads'    = ( SELECT count(*) FROM sysdba.SCB_WEB_USAGE SWU WHERE PubNo = RVD.DocId),
  RVD.Date,
  'Type' = RVT.DocType,
  RVD.Title,
  'Author' = RVDA.Last,
  'RelatedDocId' = ( SELECT MIN(RelatedDocId) FROM SlxExternal.dbo.RVRelatedDocuments  WHERE DocId = RVD.DocId)
FROM SlxExternal.dbo.RVDocuments RVD
INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId
-- Primary analyst indicated by ordinal value
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = RVD.DocId
  AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
WHERE  (RVD.DocTypeId = 10 OR    -- Video
        RVD.DocId IN (SELECT RelatedDocId FROM SlxExternal.dbo.RVRelatedDocuments))  -- Related Document
ORDER BY Type desc


-- Raw Reads for Video and RelatedPublications
SELECT
  SWU.PUBNO,
  SWU.ACCESSDATE,
  SWU.ACCESS_EMAIL_ADDR,
  RVD.Title AS Title
FROM sysdba.SCB_WEB_USAGE SWU
INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.docid = SWU.PUBNO
WHERE (RVD.DocTypeId = 10 OR    -- Video
       RVD.DocId IN (SELECT RelatedDocId FROM SlxExternal.dbo.RVRelatedDocuments))  -- Related Document
       --AND RVD.DocId = 96989
ORDER BY SWU.PUBNO desc


-- 01/19/2016
-- Chris Hogbin
-- Total Reads for Video and RelatedPublications
SELECT
  'Type' = RVT.DocType,
  'Date' = CONVERT(varchar(12), RVD.Date, 101),
  RVD.Title,
  'Author' = RVDA.Last,
  'VideoViews'      = (SELECT count(*) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = RVD.DocId),
  'RelatedReads' = (SELECT count(*) FROM SlxExternal.dbo.SCB_UNIQUE_READERS WHERE PubNo = 
                        (SELECT MIN(RelatedDocId) FROM SlxExternal.dbo.RVRelatedDocuments  WHERE DocId = RVD.DocId)
                      ),
  'RelatedTitle'   = (SELECT RVD2.Title FROM SlxExternal.dbo.RVDocuments RVD2
                      WHERE RVD2.DocId = ( SELECT MIN(RelatedDocId) FROM SlxExternal.dbo.RVRelatedDocuments  WHERE DocId = RVD.DocId))
   --'VideoId'     = RVD.DocId,
   --'RelatedId'   = (SELECT MIN(RelatedDocId) FROM SlxExternal.dbo.RVRelatedDocuments  WHERE DocId = RVD.DocId)
FROM SlxExternal.dbo.RVDocuments RVD
INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId
-- Primary analyst indicated by ordinal value
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = RVD.DocId
  AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
WHERE RVD.DocTypeId = 10    -- Video
  AND Year(RVD.Date) = 2015
  --AND RVD.DocId = 109326 -- 109304
ORDER BY RVD.Date ASC


--Video Views data
SELECT
  'Type' = RVT.DocType,
  'Date' = CONVERT(varchar(12), RVD.Date, 101),
  RVD.Title,
  'Author' = RVDA.Last,
  'VideoViewDate' = CONVERT(varchar(12), UR.READ_DATE, 101),
  'ClientEmail' = C.Email,
  C.Account
  --'VideoId'     = RVD.DocId
FROM SlxExternal.dbo.RVDocuments RVD
INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId
INNER JOIN SlxExternal.dbo.SCB_UNIQUE_READERS UR ON UR.PUBNO = RVD.DocId
INNER JOIN SalesLogix.sysdba.CONTACT C ON C.CONTACTID = UR.CONTACTID
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = RVD.DocId
  AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
WHERE RVD.DocTypeId = 10    -- Video
  AND Year(RVD.Date) = 2015
  --AND RVD.DocId = 109702  --109326  -- 109304
ORDER BY RVD.DocId ASC, CAST(UR.READ_DATE AS DATETIME) ASC

-- Call Reads data
SELECT
  'Type' = RVT.DocType,
  'Date' = CONVERT(varchar(12), RVD.Date, 101),
  RVD.Title,
  'Author' = RVDA.Last,
  'CallReadDate' = CONVERT(varchar(12), UR.READ_DATE, 101),
  'ClientEmail' = C.Email,
  C.Account,
  'RelatedTitle'   = (SELECT RVD2.Title FROM SlxExternal.dbo.RVDocuments RVD2
                      WHERE RVD2.DocId = ( SELECT MIN(RelatedDocId) FROM SlxExternal.dbo.RVRelatedDocuments  WHERE DocId = RVD.DocId))
  --'VideoId'     = RVD.DocId,
  --'RelatedId'   = (SELECT MIN(RelatedDocId) FROM SlxExternal.dbo.RVRelatedDocuments  WHERE DocId = RVD.DocId)
FROM SlxExternal.dbo.RVDocuments RVD
INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId
INNER JOIN SlxExternal.dbo.SCB_UNIQUE_READERS UR ON UR.PUBNO = (SELECT MIN(RelatedDocId) FROM SlxExternal.dbo.RVRelatedDocuments  WHERE DocId = RVD.DocId)
INNER JOIN SalesLogix.sysdba.CONTACT C ON C.CONTACTID = UR.CONTACTID
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = RVD.DocId
  AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
WHERE RVD.DocTypeId = 10    -- Video
  AND Year(RVD.Date) = 2015
  --AND RVD.DocId = 109702  --109326 -- 109304
ORDER BY RVD.Date ASC, CAST(UR.READ_DATE AS DATETIME) ASC

-- SELECT top 10 * FROM SlxExternal.dbo.SCB_UNIQUE_READERS
-- SELECT top 10 ContactId, EMAIL, Account FROM SalesLogix.sysdba.CONTACT
-- select * from SlxExternal.dbo.RVTypes
-- select * from SlxExternal.dbo.RVDocuments where docid = 109299

