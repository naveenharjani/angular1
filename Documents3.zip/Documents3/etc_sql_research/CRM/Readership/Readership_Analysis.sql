-- Readership_Analysis.sql
-- 08/22/2017

USE SlxExternal
GO

/*

Q: How are clicks and reads defined?
A: "Click" - Raw.
   "Read"  - Filtered.  One read per report per contact per day per channel (LinkSources for Bernstein and Site for portals)

Q: Compare Bernstein channel readership from vwUniqueReaders (old) and vw_readership (new)
A: vw_Readership returns 10+% more Bernstein reads compared to vwUniqueReaders

Q: Compare portal channel readership from RVPortalUsage (old) and vw_readership (new)
A: vw_Readership returns 5-% lower Portal reads compared to RVPortalUsage

Q: Does RVPortalUsage contain duplicate reads?
A: Yes, portals report raw clicks not filtered reads, i.e. RVPortalUsage can contain multiple clicks for report on same day by contact

Q: Is a report read on multiple portals?
A: Yes

Q: Can we analyze reads to observe embargoes?
A: Yes.  See sql

Action Items:

vw_readership needs to be fixed:
- filter double count reads by a 'Portal Contact Id' for a contact across portals (one email is mapped to 2 contactId)
- portal usage - filter multiple clicks same day to count one "read" per day per contact per portal

vw_readership shows reads per day by report by contact, however it accounts for each source.
Approach would be to count one read per day and attribute it to only one source (one for link source and one for portal) as per some logic.
The logic could be first read or last read or max reads by source or portal.

Use a single data store (vw_readership) for bernstein and for portal reads

*/



-- **Compare clicks vs reads in vw_portalusage for any duplicate reads
PRINT '-- *** Verify if the portals are reporting duplicate clicks same read date by report for a account. (RVPortalUsage) - Yes'  -- Yes
select 'ReadDate' = CONVERT(date, ReadDate), 
       ContactId, Contact, AccountId, Account, SiteID, PubNo, count(*) as 'MultipleReadCount'
from slxexternal.dbo.RVPortalUsage
where year(ReadDate) = 2017  -- @Year
and ContactId NOT IN ('Unattributed','***','Restricted') -- do not count unattributed reads
group by CONVERT(date, ReadDate), ContactId, Contact, AccountId, Account, SiteID, PubNo
having count(*) > 1  -- counting multiple reads for a report on a day by contact
order by CONVERT(date, ReadDate) asc

/*
-- verify raw reads for portals (RVPortalUsage)
select top 100 ReadDate, ContactId, Contact, AccountId, Account, Site, PubNo
from slxexternal.dbo.RVPortalUsage RVP
where YEAR(ReadDate) = 2017
--and Convert(date, ReadDate) = '2017-01-01' and ContactId = '17442002'  -- 2 reads
and Convert(date, ReadDate) = '2017-02-13' and ContactId = '17644574' and PubNo = 127926   -- 35 reads
ORDER BY Contact, PubNo, ReadDate desc
*/

PRINT '-- *** Verify if there are any duplicate Bernstein reads counted same read date by report for a account (vw_Readership) - No'  -- No
select 'ReadDate' = CONVERT(date, AccessDate),
       C.ContactId, C.LastName, A.AccountId, A.Account, Source, PubNo, count(*) as 'MultipleReadCount'
from Saleslogix.sysdba.vw_Readership VWR
inner join saleslogix.sysdba.account A on A.AccountID = VWR.AccountID
inner join saleslogix.sysdba.contact C on C.ContactId = VWR.ContactId
where VWR.Type = 'RESEARCHUSAGE'       -- Bernstein Usage
and YEAR(VWR.ACCESSDATE) = 2017
--and AccessDate = '2017-09-05 00:00:00.000'
group by CONVERT(date, AccessDate), C.ContactId, C.LastName, A.AccountId, A.Account, Source, PubNo
having count(*) > 1


PRINT '-- *** Verify if the portals are reporting duplicate clicks same read date by report for a account (vw_Readership)'  -- Yes
select 'ReadDate' = CONVERT(date, AccessDate),
--       C.ContactId, C.LastName, A.AccountId, A.Account, Source, PubNo, count(*) as 'MultipleReadCount'
       C.ContactId, Source, PubNo, count(*) as 'MultipleReadCount'
from Saleslogix.sysdba.vw_Readership VWR
inner join saleslogix.sysdba.account A on A.AccountID = VWR.AccountID
inner join saleslogix.sysdba.contact C on C.ContactId = VWR.ContactId
where VWR.Type = 'PORTALUSAGE'       -- Portal Usage
and YEAR(VWR.ACCESSDATE) = 2017
--group by CONVERT(date, AccessDate), C.ContactId, C.LastName, A.AccountId, A.Account, Source, PubNo
group by CONVERT(date, AccessDate), C.ContactId, Source, PubNo
having count(*) > 1

/*
-- get raw reads for portals (vw_Readership)
select top 100 * -- AccessDate, C.ContactId, C.LastName, A.AccountId, A.Account, Source, PubNo
from Saleslogix.sysdba.vw_Readership VWR
inner join saleslogix.sysdba.account A on A.AccountID = VWR.AccountID
inner join saleslogix.sysdba.contact C on C.ContactId = VWR.ContactId
where VWR.Type = 'PORTALUSAGE'       -- Portal Usage
and YEAR(VWR.ACCESSDATE) = 2017
--and AccessDate = '2017-09-05 00:00:00.000'
ORDER BY AccessDate, PubNo desc
*/


--**Is a report read on multiple portals? - Yes
PRINT '-- *** Check for a report that was read same day across multiple sites by a contact (RVPortalUsage)'
-- Sites:  3 Bloomberg (SANB), 9 Reuters, 11 CapitalIQ, 12 FactSet
select CONVERT(date, ReadDate) as ReadDate, Pubno, Email, contact, contactId
       count(distinct siteId) as NumSitesRead, count(readdate) as TotalReads
from slxexternal.dbo.RVPortalUsage
where ContactId NOT IN ('Unattributed','***','Restricted') -- do not count unattributed reads
  and isnull(PubNo, 0) <> 0    -- do not count anonymous report reads
  and isnull(Email, '') <> ''  -- attributed contacts only
  --and year(ReadDate) = 2017
group by CONVERT(date, ReadDate), pubno, Email, contact, contactId
having count(distinct siteId) > 1
order by CONVERT(date, ReadDate) desc

/*
-- raw reads - same report read by a contact on same date on multiple portals
select * from slxexternal.dbo.RVPortalUsage where CONVERT(date, ReadDate) = '2017-06-29' and pubno = 130949 and Email = 'steve.foundos@artisanpartners.com'
select * from slxexternal.dbo.RVPortalUsage where CONVERT(date, ReadDate) = '2012-02-28' and pubno = 86214 and Email = 'blester@manning-napier.com'
select * from slxexternal.dbo.RVPortalUsage where CONVERT(date, ReadDate) = '2015-10-16' and pubno = 115913 and Email = 'vitaly@meritagegroup.com'
*/


--**Can we analyze reads to observe embargoes?
DECLARE @CurrentMonth INT
SET @CurrentMonth = 9

PRINT '-- *** Get Accounts with 30 day embargo, based on last-2 month (RVPortalUsage)'
select distinct ltrim(Account) as Account from slxexternal.dbo.RVPortalUsage
where year(ReadDate) = 2017 and month(ReadDate) = @CurrentMonth - 2   -- reads in 30 days
-- do not count unattributed reads
and ( ContactId NOT IN ('Unattributed','***','Restricted', '') or AccountId NOT IN ('Unattributed','***','Restricted', ''))
order by ltrim(Account) asc

PRINT '-- *** Get Accounts with 90 day embargo, based on last-3 and last-4 month (RVPortalUsage)'
select distinct ltrim(Account) as Account from slxexternal.dbo.RVPortalUsage RVP
where year(ReadDate) = 2017 and (month(ReadDate) = @CurrentMonth - 4 or month(ReadDate) = @CurrentMonth - 3) -- reads in 60, 90 days
-- do not count unattributed reads
and ( ContactId NOT IN ('Unattributed','***','Restricted', '') or AccountId NOT IN ('Unattributed','***','Restricted', ''))
-- no attributed reads in 30 days
and Account NOT IN (SELECT distinct Account FROM slxexternal.dbo.RVPortalUsage
	   		        WHERE Account = RVP.Account and year(readdate) = 2017 and month(readDate) = @CurrentMonth - 2 )
order by ltrim(Account) asc

PRINT '-- *** Show unattributed Reads > 90 days - perpetual embargo (RVPortalUsage)'
select distinct ltrim(Account) as Account, Site, Count(*) as TotalReads
from slxexternal.dbo.RVPortalUsage
-- perpetual embargo
where ((year(ReadDate) = 2017 and month(ReadDate) <= 4) or year(ReadDate) < 2017)
-- count unattributed reads only
and ( ContactId IN ('Unattributed','***','Restricted', '') or AccountId IN ('Unattributed','***','Restricted', ''))
group by ltrim(Account), Site
order by ltrim(Account) asc


PRINT '-- *** List Accounts read on the 4 portals - with 0, 30, 90 day embargo (based on last 4 months reads)'
select V.Account,
       'Bloomberg' = (CASE WHEN Bloomberg0 = 'Y' THEN 0 WHEN Bloomberg30 = 'Y' THEN 30 WHEN Bloomberg90 = 'Y' THEN 90 ELSE NULL END),
	   'Factset'   = (CASE WHEN Factset0 = 'Y' THEN 0 WHEN Factset30 = 'Y' THEN 30 WHEN Factset90 = 'Y' THEN 90 ELSE NULL END),
	   'CapitalIQ' = (CASE WHEN CapitalIQ0 = 'Y' THEN 0 WHEN CapitalIQ30 = 'Y' THEN 30 WHEN CapitalIQ90 = 'Y' THEN 90 ELSE NULL END),
	   'Reuters'   = (CASE WHEN Reuters0 = 'Y' THEN 0 WHEN Reuters30 = 'Y' THEN 30 WHEN Reuters90 = 'Y' THEN 90 ELSE NULL END)
from 
(
	select distinct ltrim(RVP.Account) as Account,
	  -- 3 Bloomberg (SANB)
	 'Bloomberg0' = (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 3 AND year(PUF.readdate) = 2017 AND month(PUF.readdate) = 8),
	 'Bloomberg30'= (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 3 AND year(PUF.readdate) = 2017 AND month(PUF.readdate) = 7
					and PUF.Account NOT IN (SELECT distinct Account FROM slxexternal.dbo.RVPortalUsage WHERE Account = PUF.Account AND SiteId = 3  and year(readdate) = 2017 and month(readDate) in (8))),
	 'Bloomberg90'= (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 3 and year(PUF.readdate) = 2017 and month(PUF.readDate) in (5,6)
   					  and PUF.Account NOT IN (SELECT distinct Account FROM slxexternal.dbo.RVPortalUsage WHERE Account = PUF.Account AND SiteId = 3 and year(readdate) = 2017 and month(readDate) in (7,8))),
	 -- 12 Factset
	 'Factset0'  = (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 12 AND year(PUF.readdate) = 2017 AND month(PUF.readdate) = 8),
	 'Factset30' = (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 12 AND year(PUF.readdate) = 2017 AND month(PUF.readdate) = 7
					and PUF.Account NOT IN (SELECT distinct Account FROM slxexternal.dbo.RVPortalUsage WHERE Account = PUF.Account AND SiteId = 12  and year(readdate) = 2017 and month(readDate) in (8))),
	 'Factset90'= (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 12 and year(PUF.readdate) = 2017 and month(PUF.readDate) in (5,6)
					and PUF.Account NOT IN (SELECT distinct Account FROM slxexternal.dbo.RVPortalUsage WHERE Account = PUF.Account AND SiteId = 12  and year(readdate) = 2017 and month(readDate) in (7,8))),
	-- 11 CapitalIQ
	 'CapitalIQ0' = (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 11 AND year(PUF.readdate) = 2017 AND month(PUF.readdate) = 8),
	 'CapitalIQ30'= (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 11 AND year(PUF.readdate) = 2017 AND month(PUF.readdate) = 7
					and PUF.Account NOT IN (SELECT distinct Account FROM slxexternal.dbo.RVPortalUsage WHERE Account = PUF.Account AND SiteId = 11  and year(readdate) = 2017 and month(readDate) in (8))),
	 'CapitalIQ90'= (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 11 and year(PUF.readdate) = 2017 and month(PUF.readDate) in (5,6)
   					  and PUF.Account NOT IN (SELECT distinct Account FROM slxexternal.dbo.RVPortalUsage WHERE Account = PUF.Account AND SiteId = 11 and year(readdate) = 2017 and month(readDate) in (7,8))),
	-- 9 Reuters
	 'Reuters0'  = (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 9 AND year(PUF.readdate) = 2017 AND month(PUF.readdate) = 8),
	 'Reuters30' = (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 9 AND year(PUF.readdate) = 2017 AND month(PUF.readdate) = 7
					and PUF.Account NOT IN (SELECT distinct Account FROM slxexternal.dbo.RVPortalUsage WHERE Account = PUF.Account AND SiteId = 9  and year(readdate) = 2017 and month(readDate) in (8))),
	 'Reuters90' = (SELECT (CASE WHEN count(distinct Account) = 1 THEN 'Y' ELSE '' END) FROM slxexternal.dbo.RVPortalUsage PUF WHERE PUF.Account = RVP.Account AND PUF.SiteId = 9 and year(PUF.readdate) = 2017 and month(PUF.readDate) in (5,6)
   					  and PUF.Account NOT IN (SELECT distinct Account FROM slxexternal.dbo.RVPortalUsage WHERE Account = PUF.Account AND SiteId = 9 and year(readdate) = 2017 and month(readDate) in (7,8)))
	from slxexternal.dbo.RVPortalUsage RVP
	where year(RVP.ReadDate) = 2017 and month(RVP.ReadDate) IN (5,6,7,8)   -- last 4 months reads
	-- do not count unattributed reads
	and (RVP.ContactId NOT IN ('Unattributed','***','Restricted', '') or AccountId NOT IN ('Unattributed','***','Restricted', ''))
	--and RVP.SiteId = 3 -- 12  --11  -- 3  --12
) V
order by ltrim(V.Account) asc