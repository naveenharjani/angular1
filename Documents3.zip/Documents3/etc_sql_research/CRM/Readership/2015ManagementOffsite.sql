-- 2015ManagementOffsite.sql
-- 01/13/2015


-- For the last 18 months � so starting on July 1, 2013 � what are the regional numbers for:
-- �	Average reads of initiation calls
-- �	Average reads of any call
-- �	Average reads of any single-stock calls � that is where only one ticker (doesn�t matter which) is present in a given call

DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)

SET @vSinceDate = '01/01/2013'
SET @vUntilDate = '01/13/2015'    --  getdate()

print '*** Period from ' + CONVERT(VARCHAR(12), @vSinceDate, 101) + ' to ' + CONVERT(VARCHAR(12), @vUntilDate, 101)
print '*** By Region - All Calls/Tickers'

SELECT DISTINCT
    'Region' = RVAR.Region,
    'DocId'  = RVD.DocId,
    'Type'   = RVT.DocType,
    'Reads'  = v1.read_count,
    'Initiate' = ( CASE WHEN EXISTS(SELECT V.DocId FROM SlxExternal.dbo.RVFinancials V 
                                     WHERE (CoverageAction IN ('INITIATE') OR RatingAction IN ('INITIATE'))
                                       AND DocId = RVD.DocId) THEN 'Y'
                        ELSE 'N'
                   END ),
    'SingleTicker' = ( CASE WHEN EXISTS(
                            SELECT DocId, COUNT(*) FROM SlxExternal.dbo.RVDocSecurities 
                            WHERE DocId = RVD.DocId
                            GROUP BY DocId HAVING COUNT(*) = 1
                            ) THEN 'Y'
                        ELSE 'N'
                   END )
INTO #Tmp_Output
  FROM ( SELECT PUBNO, 'read_count' = count(*) FROM SlxExternal.dbo.SCB_UNIQUE_READERS GROUP BY PUBNO ) AS v1
  INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = v1.PUBNO
  INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId
  INNER JOIN SlxExternal.dbo.RVDocAnalystRegions RVDAR ON RVDAR.DocId = RVD.DocId
  INNER JOIN SlxExternal.dbo.RVAnalystRegions RVAR ON RVAR.RegionId = RVDAR.RegionId
  WHERE RVD.Date BETWEEN @vSinceDate AND @vUntilDate
    AND RVD.DocTypeId IN (1)    -- Research Calls only

-- SELECT * FROM #Tmp_Output WHERE Initiate = 'Y' ORDER BY DocId DESC
-- SELECT * FROM #Tmp_Output WHERE SingleTicker = 'Y' ORDER BY DocId DESC

-- By Regions
SELECT
  'Region'      = TMP.Region,
  'Type'        = 'Initiate',
  'NumReports'  = COUNT(DISTINCT TMP.DocId),
  'Reads'       = SUM(TMP.Reads),
  'AvgReads'    = SUM(TMP.Reads)/COUNT(DISTINCT TMP.DocId)
FROM #Tmp_Output TMP
WHERE Initiate = 'Y'
GROUP BY TMP.Region
UNION
SELECT
  'Region'      = TMP.Region,
  'Type'        = 'AnyCall',
  'NumReports'  = COUNT(DISTINCT TMP.DocId),
  'Reads'       = SUM(TMP.Reads),
  'AvgReads'    = SUM(TMP.Reads)/COUNT(DISTINCT TMP.DocId)
FROM #Tmp_Output TMP
GROUP BY TMP.Region
UNION
SELECT
  'Region'      = TMP.Region,
  'Type'        = 'SingleTicker',
  'NumReports'  = COUNT(DISTINCT TMP.DocId),
  'Reads'       = SUM(TMP.Reads),
  'AvgReads'    = SUM(TMP.Reads)/COUNT(DISTINCT TMP.DocId)
FROM #Tmp_Output TMP
WHERE SingleTicker = 'Y'
GROUP BY TMP.Region
UNION
-- Global
SELECT
  'Region'         = 'Global',
  'Type'           = 'Initiate',
  'AllNumReports'  = COUNT(DISTINCT TMP.DocId),
  'AllReads'       = SUM(TMP.Reads),
  'AllAvgReads'    = SUM(TMP.Reads)/COUNT(DISTINCT TMP.DocId)
FROM #Tmp_Output TMP
WHERE Initiate = 'Y'
UNION
SELECT
  'Region'         = 'Global',
  'Type'           = 'AnyCall',
  'AllNumReports'  = COUNT(DISTINCT TMP.DocId),
  'AllReads'       = SUM(TMP.Reads),
  'AllAvgReads'    = SUM(TMP.Reads)/COUNT(DISTINCT TMP.DocId)
FROM #Tmp_Output TMP
UNION
SELECT
  'Region'         = 'Global',
  'Type'           = 'SingleTicker',
  'AllNumReports'  = COUNT(DISTINCT TMP.DocId),
  'AllReads'       = SUM(TMP.Reads),
  'AllAvgReads'    = SUM(TMP.Reads)/COUNT(DISTINCT TMP.DocId)
FROM #Tmp_Output TMP
WHERE SingleTicker = 'Y'
ORDER BY 1, 2


-- In addition, attached is a list of stocks/tickers. Can you provide:
-- �	The reads for the initiation calls for each of those tickers
-- �	The reads for any calls where those tickers were present
-- �	The reads for calls where only one of those tickers are present

-- Ticker List
-- '1251.HK', '1623.HK', 'IOC', 'CIE', '220.HK', '2319.HK', 'WIN', 'FTR', 'RKUS', 'ARUN', 'UBNT', 'STM.FP', 'FFIV', 'OTIC', 'AKSO.NO', 'SBMO.NA', 'VK.FP', 'PFC.LN', 'SUBC.NO', 'SPM.IM', 'TEC.FP', '1988.HK', 'STJ.LN', 'HL/.LN', 'WWAV', '1133.HK', '1072.HK', '3339.HK', '1157.HK', '2727.HK', '042670.KS', '034020.KS', '728.HK', 'CSTM', 'AWC.AU', 'MTX.GR', 'MGGT.LN', '3034.TT', 'ASC.LN', 'TVPT', 'SABR', 'MRW.LN', 'SBRY.LN', 'MEO.GR', 'CO.FP', 'APO', '006400.KS', 'FMI', 'ALDR', 'BEZ.LN', 'HSX.LN', 'CGL.LN', 'AML.LN', 'RSA.LN', 'PNRA', '1336.HK', 'DRX.LN', 'SVT.LN', 'UU/.LN', 'ALLE', '200625.CH'

print '*** By Ticker - Specified Tickers'

-- Get Distinct reads by PubNo
SELECT DISTINCT Tmp.DocId, Tmp.Reads, Tmp.Initiate, Tmp.SingleTicker,
       RVDS.Ticker, RVDS.Company
INTO #Tmp_Output2
FROM #Tmp_Output Tmp
 -- Get Publications with specified Tickers
INNER JOIN SlxExternal.dbo.RVDocSecurities RVDS ON RVDS.DocId = Tmp.DocId
 AND TICKER IN ('1251.HK', '1623.HK', 'IOC', 'CIE', '220.HK', '2319.HK', 'WIN', 'FTR', 'RKUS', 'ARUN', 'UBNT', 'STM.FP', 'FFIV', 'OTIC', 'AKSO.NO', 'SBMO.NA', 'VK.FP', 'PFC.LN', 'SUBC.NO', 'SPM.IM', 'TEC.FP', '1988.HK', 'STJ.LN', 'HL/.LN', 'WWAV', '1133.HK', '1072.HK', '3339.HK', '1157.HK', '2727.HK', '042670.KS', '034020.KS', '728.HK', 'CSTM', 'AWC.AU', 'MTX.GR', 'MGGT.LN', '3034.TT', 'ASC.LN', 'TVPT', 'SABR', 'MRW.LN', 'SBRY.LN', 'MEO.GR', 'CO.FP', 'APO', '006400.KS', 'FMI', 'ALDR', 'BEZ.LN', 'HSX.LN', 'CGL.LN', 'AML.LN', 'RSA.LN', 'PNRA', '1336.HK', 'DRX.LN', 'SVT.LN', 'UU/.LN', 'ALLE', '200625.CH')
-- Get Tickers in those publications
WHERE RVDS.Ticker IN ('1251.HK', '1623.HK', 'IOC', 'CIE', '220.HK', '2319.HK', 'WIN', 'FTR', 'RKUS', 'ARUN', 'UBNT', 'STM.FP', 'FFIV', 'OTIC', 'AKSO.NO', 'SBMO.NA', 'VK.FP', 'PFC.LN', 'SUBC.NO', 'SPM.IM', 'TEC.FP', '1988.HK', 'STJ.LN', 'HL/.LN', 'WWAV', '1133.HK', '1072.HK', '3339.HK', '1157.HK', '2727.HK', '042670.KS', '034020.KS', '728.HK', 'CSTM', 'AWC.AU', 'MTX.GR', 'MGGT.LN', '3034.TT', 'ASC.LN', 'TVPT', 'SABR', 'MRW.LN', 'SBRY.LN', 'MEO.GR', 'CO.FP', 'APO', '006400.KS', 'FMI', 'ALDR', 'BEZ.LN', 'HSX.LN', 'CGL.LN', 'AML.LN', 'RSA.LN', 'PNRA', '1336.HK', 'DRX.LN', 'SVT.LN', 'UU/.LN', 'ALLE', '200625.CH')
ORDER BY Tmp.DocId

-- SELECT * FROM #Tmp_Output2

-- By Specified Tickers
SELECT
  'Ticker'      = TMP.Ticker,
  'Type'        = 'Initiate',
  'NumReports'  = COUNT(DISTINCT TMP.DocId),
  'Reads'       = SUM(TMP.Reads),
  'AvgReads'    = SUM(TMP.Reads)/COUNT(DISTINCT TMP.DocId)
FROM #Tmp_Output2 TMP
WHERE Initiate = 'Y'
GROUP BY TMP.Ticker
UNION
SELECT
  'Region'      = TMP.Ticker,
  'Type'        = 'AnyCall',
  'NumReports'  = COUNT(DISTINCT TMP.DocId),
  'Reads'       = SUM(TMP.Reads),
  'AvgReads'    = SUM(TMP.Reads)/COUNT(DISTINCT TMP.DocId)
FROM #Tmp_Output2 TMP
GROUP BY TMP.Ticker
UNION
SELECT
  'Ticker'      = TMP.Ticker,
  'Type'        = 'SingleTicker',
  'NumReports'  = COUNT(DISTINCT TMP.DocId),
  'Reads'       = SUM(TMP.Reads),
  'AvgReads'    = SUM(TMP.Reads)/COUNT(DISTINCT TMP.DocId)
FROM #Tmp_Output2 TMP
WHERE SingleTicker = 'Y'
GROUP BY TMP.Ticker
ORDER BY 1, 2

DROP TABLE #Tmp_Output
DROP TABLE #Tmp_Output2

SET NOCOUNT OFF
GO



/*
-- Verify read counts
SELECT PUBNO, 'read_count' = count(*) FROM SlxExternal.dbo.SCB_UNIQUE_READERS 
WHERE PUBNO = 104701  -- 810    -- 006400.KS Initiate Call
-- WHERE PUBNO = 102024  -- 406  -- 034020.KS Initiate Call
-- WHERE PUBNO in (109450, 109417, 109346, 108891) -- WWAV All Calls

GROUP BY PUBNO

SELECT PUBNO, 'read_count' = count(*) FROM SlxExternal.dbo.SCB_UNIQUE_READERS 
GROUP BY PUBNO

-- Inititate calls
SELECT V.DocId FROM SlxExternal.dbo.RVFinancials V 
WHERE (CoverageAction IN ('INITIATE') OR RatingAction IN ('INITIATE'))

-- Single Ticker calls
SELECT DocId, COUNT(*) FROM SlxExternal.dbo.RVDocSecurities GROUP BY DocId 
HAVING COUNT(*) = 1 
Order by docid desc

SELECT * FROM SlxExternal.dbo.RVDocSecurities
SELECT * FROM SlxExternal.dbo.RVAnalystRegions
SELECT * FROM SlxExternal.dbo.RVDocAnalystRegions 
SELECT * FROM SlxExternal.dbo.RVFinancials
*/