-- Primer_Reads.sql
-- 12/2/2016
-- Compass PRD: SLXPRDDB,16083 (research_db_svc)

-- Can someone pull for me the clients that have read the Ethylene primer to data (ID 126423). Need name, firm, date read pls. 
-- append the Tier and location (city) to the list

SELECT
  VR.ACCESS_EMAIL_ADDR AS Email,
  C.ContactName AS Contact,
  VR.ACCOUNT AS Account,
  VR.ACCESSDATE AS ReadDate,
  A.USTier,
  A.EUTier,
  A.APTier,
  A.AccountRegion
FROM SlxExternal.dbo.vwReadDetails VR
JOIN Compass.dbo.Contact C ON C.Email = VR.ACCESS_EMAIL_ADDR
JOIN Compass.dbo.Account A ON A.AccountName = VR.ACCOUNT
WHERE VR.PUBNO = 126423
ORDER BY ACCESSDATE ASC


-- DEBUG
/*
SELECT * FROM SlxExternal.dbo.RVDocuments where docid = 126423
SELECT * FROM Compass.dbo.Account
SELECT * FROM Compass.dbo.Contact
*/