-- Models_Analysis.sql
-- 07/14/2017

select * from Counters

select * from ModelActions

select * from ModelStates

select * from Models

select * from ModelDeletions

select * from vModels

select * from vModelsLatest

select * from PublicationFinancials

-- Models repository - SHOULD have
select RC.*, S.*
from ResearchCoverage RC
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null and S.IsPrimary = 'Y'

-- Models repository - ACTUALLY have
-- select * from Models where StateId = 1 order by ModelId desc -- Active.  Not accurate.  Includes dropped.

select VM.EditDate, * from vModels VM where StateId = 1 order by ModelId desc -- Active

select U.LastName + ', ' + U.FirstName + ' (' + U.UserName + ')' as 'User', VM.EditDate, *
from vModels VM
left join Users U on U.UserId = VM.EditorId
where StateId = 1 order by ModelId desc -- Active

select count(*) from Models where StateId = 1 -- Active
select count(*) from vModels where StateId = 1 -- Active

-- Model counts - By Region
select
  Region,
  'NumModelsEligible' = COUNT(*),
  'NumModelsCollected'  = (SELECT COUNT(*) FROM vModelsLatest WHERE Region = V.Region AND StateId = 1), -- Active
  'NumModelsMissing' = (SELECT COUNT(*) FROM vModelsLatest WHERE Region = V.Region AND StateId IS NULL),
  '%' = ROUND((SELECT CAST(COUNT(*) AS FLOAT) FROM vModelsLatest WHERE Region = V.Region AND StateId = 1) / CAST(COUNT(*) AS FLOAT), 2)
from vModelsLatest V
group by Region
order by NumModelsCollected desc

-- Model counts
select
  Analyst,
  Region,
  'NumModelsEligible' = COUNT(*),
  'NumModelsCollected'  = (SELECT COUNT(*) FROM vModelsLatest WHERE Analyst = V.Analyst AND StateId = 1), -- Active
  'NumModelsMissing' = (SELECT COUNT(*) FROM vModelsLatest WHERE Analyst = V.Analyst AND StateId IS NULL)
from vModelsLatest V
group by Analyst, Region
order by NumModelsCollected desc, Analyst

-- Model counts - Versions
select S.Ticker, count(*) as ModelCount
from ResearchCoverage RC
join Models M on M.CoverageId = RC.CoverageId
join Securities2 S on S.SecurityId = RC.SecurityId
where RC.LaunchDate is not null and RC.DropDate is null and S.IsPrimary = 'Y'
group by S.Ticker
order by 2 desc, 1

-- Model Distribution flag
select ModelDistribution, count(*) as Num from ResearchCoverage group by ModelDistribution

-- Logging
select top 100 * from ViewLog order by ViewId desc
select top 100 * from ViewLog where FileName like '%xls%'
select * from BeehiveViewSources

-- Beehive downloads
select top 500
  VL.EditDate as 'Date',
  U.LastName + ', ' + U.FirstName  + ' (' + U.UserName + ')' as 'User',
  VM.Company,
  VM.Ticker,
  VM.Analyst
--  VL.*,
--  U.*
from ViewLog VL
join vModels VM on VM.FileName = VL.FileName
join Users U on U.UserId = VL.UserId
where VL.FileName like '%xl%'
order by ViewId desc

select BVS.SourceId, BVS.Source, count(*) from ViewLog VL left join BeehiveViewSources BVS on BVS.SourceId = VL.SourceId
group by BVS.SourceId, BVS.Source

-- Deletions
select * from ModelDeletions

select * from Models where StateId = 3

-- BR.com downloads

SELECT
  RVM.Company,
  RVM.Ticker AS Model,
  RVM.Analyst
FROM SlxExternal.dbo.ContentUsage C
JOIN SlxExternal.dbo.RVModels RVM on C.ContentId = RVM.ModelId
WHERE AccessDate >= dateadd(dd, -7, getdate())   -- last 7 days
-- GROUP BY RVM.Ticker, RVM.Company, RVM.Analyst
ORDER BY RVM.Company ASC

SELECT distinct
  CONVERT(DATE, CU.AccessDate) as 'Download Date',
  RVLS.Source,
  CU.LoginId AS Contact,
  A.AccountName AS Account,
  A.USTier, EUTier, APTier,
  RVM.Ticker AS Model,
  RVM.Company,
  RVM.Analyst,
  RVM.ModelDate AS 'Model Date'
FROM SlxExternal.dbo.ContentUsage CU
JOIN SlxExternal.dbo.RVModels RVM on RVM.ModelId = CU.ContentId
JOIN SlxExternal.dbo.RVLinkSources RVLS WITH (nolock) ON RVLS.SourceId = CU.SOURCEID
JOIN Compass.dbo.Contact C ON C.SLXContactId = CU.ContactId
JOIN Compass.dbo.Account A ON A.AccountId = C.AccountId
where CU.LoginId not like '%bernstein.com%'
and CU.LoginId not like '%abglobal.com'
ORDER BY Account, Contact

