-- LongviewReadAverage.sql
-- 02/09/2017

-- The average readership of longviews, calls & blackbooks over the last 3 years.

-- 02/09/2017 - Colin Request - 2017 Long View Schedule (2014-2016 period)

/*
Server   : SLXPRDDB,16083
Database : SlxExternal
Login    : research_db_svc
*/

USE SlxExternal
GO

DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)

SET @vSinceDate = '01/01/2014'
SET @vUntilDate = '12/31/2016'

PRINT '*** Period from ' + CONVERT(VARCHAR(12), @vSinceDate, 101) + ' to ' + CONVERT(VARCHAR(12), @vUntilDate, 101)

SELECT
  'DocId' = RVD.DocId,
  'Type'  = (CASE WHEN CHARINDEX('the long view', RVD.Title) > 0 THEN 'LongView' ELSE RVT.DocType END),
  'Reads' = v1.read_count,
  'Date'  = RVD.Date
INTO #Tmp_Reads
  FROM ( SELECT PUBNO, 'read_count' = COUNT(*) FROM vwUniqueReaders 
  --WHERE READ_DATE BETWEEN @vSinceDate AND @vUntilDate   -- report read filter
  GROUP BY PUBNO ) AS v1
  INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = v1.PUBNO
  INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId
  WHERE RVD.Date BETWEEN @vSinceDate AND @vUntilDate  -- report publish filter
    AND RVD.DocTypeId IN (1, 3)  -- Research Call (incl 'The Long View'), Blackbooks

SELECT
  'Since'     = @vSinceDate, 
  'Until'     = @vUntilDate,
  'Type'      = TR.Type,
  'AvgReads'  = SUM(TR.Reads)/COUNT(DISTINCT TR.DocId)
FROM #Tmp_Reads TR
GROUP BY TR.Type
ORDER BY Type

DROP TABLE #Tmp_Reads

SET NOCOUNT OFF
GO

/*
SELECT TOP 10 * FROM vwUniqueReaders where read_date BETWEEN '01/01/2014' AND '12/31/2016'
SELECT * FROM SlxExternal.dbo.RVTypes
*/