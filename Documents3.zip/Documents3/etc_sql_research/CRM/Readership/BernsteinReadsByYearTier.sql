-- BernsteinReadsByYearTier.sql

USE SlxExternal
GO

-- Bernstein Reads by YEAR per Account Tier
SELECT
  YEAR(READ_DATE)                                         AS [Year],
  SUM(CASE WHEN AE.TIER =  'TIER 1' THEN 1 ELSE 0 END)   	AS [Tier1],
  SUM(CASE WHEN AE.TIER =  'TIER 2' THEN 1 ELSE 0 END)   	AS [Tier2],
  SUM(CASE WHEN AE.TIER =  'TIER 3' THEN 1 ELSE 0 END)   	AS [Tier3],
  SUM(CASE WHEN AE.TIER =  'TIER 4' THEN 1 ELSE 0 END)   	AS [Tier4],
  SUM(CASE WHEN AE.TIER =  'TIER 5' THEN 1 ELSE 0 END)   	AS [Tier5],
  SUM(CASE WHEN AE.TIER NOT IN ('TIER 1', 'TIER 2', 'TIER 3', 'TIER 4', 'TIER 5') 
                                    THEN 1 ELSE 0 END)    AS [Other],
  count(*)                                                AS [Total]
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
INNER JOIN Saleslogix.sysdba.contact CN         ON CN.ContactId = UR.ContactId
INNER JOIN Saleslogix.sysdba.inf_account_ext AE ON AE.AccountId = CN.AccountId
WHERE YEAR(READ_DATE) >= 2010
GROUP BY YEAR(READ_DATE)
ORDER BY YEAR(READ_DATE)

--Distinct Tier values
-- Use TIER to get Account Tier for a US Analyst
SELECT distinct TIER FROM Saleslogix.sysdba.inf_account_ext
-- Use PANEUROTIER to get Account Tier for a PE Analyst
SELECT distinct PANEUROTIER FROM Saleslogix.sysdba.inf_account_ext
-- Use ASIATIER to get Account Tier for an Asian Analyst
SELECT distinct ASIATIER FROM Saleslogix.sysdba.inf_account_ext
