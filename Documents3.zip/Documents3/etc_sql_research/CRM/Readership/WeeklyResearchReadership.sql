-- WeeklyResearchReadership.sql
-- 05/06/2014

/*

For Matt Richmond

SSRS report "Research Call Readership" - Embedded SQL

*DataSet 1 [Report Date Range]:
SELECT  DATEADD(wk, DATEDIFF(wk, 6, GETDATE()), 0) AS SinceDate,
        DATEADD(wk, DATEDIFF(wk, 6, GETDATE()), 6) AS UntilDate

*DataSet 2 [Research Readership]: [report parameter uses default since/until date values from above dataset]

To run retroactively remove comment to enable READ_DATE range
04/10/2015 Matt Jan 2014
04/10/2015 Matt Feb 2014
04/10/2015 Matt Mar 2014
04/10/2015 Matt Apr 2014
04/10/2015 Matt May 2014

*/

USE Saleslogix
GO

DECLARE @vSinceDate VARCHAR(12)
DECLARE @vUntilDate VARCHAR(12)

SET @vSinceDate = '05/01/2014'
SET @vUntilDate = '05/31/2014'

DECLARE @PubReads TABLE (AnalystId INT, PubNo INT, Reads INT)

INSERT @PubReads
  SELECT RVDA.AnalystId,
         UR.PubNo,
         'Reads' = Count(*)
    FROM SlxExternal.dbo.SCB_Unique_Readers UR
    JOIN SlxExternal.dbo.RVDocuments RVD  on RVD.Docid = UR.pubno
    JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = RVD.DocId
         --AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
   WHERE RVD.date >= @vSinceDate AND RVD.date <= @vUntilDate
--     AND UR.READ_DATE >= @vSinceDate AND UR.READ_DATE <= @vUntilDate
     AND RVD.DocTypeId = 1        -- Research Calls only
   GROUP BY RVDA.AnalystId, UR.PubNo

-- Avg readership by date range
SELECT 'Analyst'      = RVDA.Last + ', ' + RVDA.First,
       'SumReads'     = COUNT(UR.Pubno),
       'AverageReads' = COUNT(UR.Pubno)/COUNT(DISTINCT RVD.Docid),
       'Min'          = (SELECT MIN(Reads) FROM @PubReads WHERE AnalystId = RVDA.AnalystId),
       'Max'          = (SELECT MAX(Reads) FROM @PubReads WHERE AnalystId = RVDA.AnalystId),
       'Count'        = COUNT(DISTINCT RVD.Docid),
       'SinceDate'    = @vSinceDate,
       'UntilDate'    = @vUntilDate 
FROM SlxExternal.dbo.RVDocuments RVD
INNER JOIN SlxExternal.dbo.SCB_Unique_Readers UR on RVD.Docid = UR.pubno
-- Primary analyst indicated by ordinal value
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = RVD.DocId
  --AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
WHERE RVD.date >= @vSinceDate AND RVD.date <= @vUntilDate
--  AND UR.READ_DATE >= @vSinceDate AND UR.READ_DATE <= @vUntilDate
  AND RVD.DocTypeId = 1 -- Research Calls only
GROUP BY RVDA.Last, RVDA.First, RVDA.AnalystId
ORDER BY 1 ASC
GO

/*

-- DEBUG

SELECT top 10 * FROM SlxExternal.dbo.SCB_Unique_Readers
SELECT top 100 * FROM SlxExternal.dbo.RVAnalysts

*/
