-- Client_Readership.sql
-- 06/04/2018

-- Colin: can I get a file with readership at the FIRM level for all reports that Philipp Carlsson-Szlezak has published to date. I know this is still within our embargo period, so I will treat accordingly.  
-- Ideally, for each note, would like a list of firms and number of readers at each firm.

DECLARE
 @vSinceDate		VARCHAR(100),
 @vUntilDate		VARCHAR(100),
 @vAnalystId		VARCHAR(100)

SET @vSinceDate = '01/01/2018'
SET @vUntilDate = getdate()
SET @vAnalystId = 805   --Philipp Carlsson-Szlezak, Ph.D.

-- Show summary at Account Level with NumReaders, NumReads
SELECT v1.PubNo as ID, CONVERT(varchar, RVD.Date, 101) as [Date],
'Type' = CASE RVT.DocType 
			  WHEN 'Research Note' THEN 'Note' 
			  WHEN 'Black Book' THEN 'Blackbook' 
			  WHEN 'White Book' THEN 'Whitebook'
			  WHEN 'Research Call' THEN (CASE substring(RVD.Title, 1, 10) 
			  WHEN 'Quick Take' THEN 'Flash' ELSE 'Call' END)
			  ELSE RVT.DocType
		  END,
RVD.Title, 'PrimaryAuthor' = RVDA.Last, 
A.AccountName as Client, COUNT(Distinct V1.ContactId) as NumReaders, SUM(Reads) as NumReads
FROM (SELECT PubNo, ContactId, 'Reads' = COUNT(*) FROM SlxExternal.dbo.vwUniqueReaders with (nolock) GROUP BY PubNo, ContactId) AS v1
INNER JOIN SlxExternal.dbo.RVDocuments RVD with (nolock) ON RVD.DocId = v1.PubNo
INNER JOIN SlxExternal.dbo.RVTypes RVT with (nolock) ON RVT.DocTypeId = RVD.DocTypeId
-- Primary analyst indicated by ordinal value
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA with (nolock) on RVDA.DocId = v1.PubNo
AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts with (nolock) WHERE DocId = RVDA.DocId)
LEFT JOIN Compass.dbo.Contact C with (nolock) ON C.ContactId = v1.ContactId
LEFT JOIN Compass.dbo.Account A ON  A.AccountId = C.AccountId
WHERE Date BETWEEN @vSinceDate AND @vUntilDate
AND RVDA.AnalystId = @vAnalystId
GROUP BY v1.PubNo, RVD.Date, RVT.DocType, RVD.Title, RVDA.Last, A.AccountName
ORDER BY v1.PubNo desc, A.AccountName


-- Show summary at Account, Contact level with NumReads
SELECT v1.PubNo as ID, CONVERT(varchar, RVD.Date, 101) as [Date],
'Type' = CASE RVT.DocType 
			  WHEN 'Research Note' THEN 'Note' 
			  WHEN 'Black Book' THEN 'Blackbook' 
			  WHEN 'White Book' THEN 'Whitebook'
			  WHEN 'Research Call' THEN (CASE substring(RVD.Title, 1, 10) 
			  WHEN 'Quick Take' THEN 'Flash' ELSE 'Call' END)
			  ELSE RVT.DocType
		  END,
RVD.Title,
  'PrimaryAuthor' = RVDA.Last,
  A.AccountName as Client,
  C.ContactName,
  Reads as NumReads
FROM (SELECT PubNo, ContactId, 'Reads' = COUNT(*) FROM SlxExternal.dbo.vwUniqueReaders with (nolock) GROUP BY PubNo, ContactId) AS v1
INNER JOIN SlxExternal.dbo.RVDocuments RVD with (nolock) ON RVD.DocId = v1.PubNo
INNER JOIN SlxExternal.dbo.RVTypes RVT with (nolock) ON RVT.DocTypeId = RVD.DocTypeId
-- Primary analyst indicated by ordinal value
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA with (nolock) on RVDA.DocId = v1.PubNo
AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts with (nolock) WHERE DocId = RVDA.DocId)
LEFT JOIN Compass.dbo.Contact C with (nolock) ON C.ContactId = v1.ContactId
LEFT JOIN Compass.dbo.Account A ON  A.AccountId = C.AccountId
WHERE Date BETWEEN @vSinceDate AND @vUntilDate
AND RVDA.AnalystId = @vAnalystId
--GROUP BY v1.PubNo, RVD.Date, RVT.DocType, RVD.Title, RVDA.Last, A.AccountName
ORDER BY v1.PubNo desc, A.AccountName, C.ContactName
