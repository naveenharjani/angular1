-- ResearchLinks_Activity_Warren_Email.sql

-- 2010/09/13 - Andy Weinstein / @warren-news.com ResearchLinks readership inquiry

-- Get IP Info:  http://www.hcidata.info/host2ip.cgi

-- SLXPRDDB\SALGX_PRD,16083

--see ResearchLinks activity for @warren-new.com email addresses. Please include the analyst last name of the report.
SELECT distinct convert(varchar(30), ACCESS_EMAIL_ADDR) AS EMAIL_ADDRESS, PUBNO, ACCESSDATE, 
RDA.Last AS LAST, DOMAIN_NAME, STATUS, FILEFOUND
--RDA.Name, RDA.AnalystId, , SERVER_NAME, SOURCE_INTERNAL
FROM    sysdba. SCB_WEB_USAGE
INNER JOIN SlxExternal.dbo.RVDocAnalysts RDA ON RDA.DocId = PubNo
--Selected analyst is primary author[Primary analyst indicated by ordinal value]
AND RDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RDA.DocId)
WHERE access_email_addr like '%@warren-news%'
-- AND isnull(STATUS, 'F') = 'T'
-- AND isnull(FILEFOUND, 'N') = 'Y'
-- ORDER BY ACCESSDATE DESC
ORDER BY convert(varchar(30), ACCESS_EMAIL_ADDR), DOMAIN_NAME, ACCESSDATE DESC
