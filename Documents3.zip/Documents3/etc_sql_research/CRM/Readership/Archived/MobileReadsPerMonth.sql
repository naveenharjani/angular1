-- MobileReadsPerMonth.sql

--SLX PRODUCTION: SLXPRDDB\SALGX_PRD,16083

USE SALESLOGIX     --sysdba.SCB_WEB_USAGE
GO
  
-- NON-FILTERED Reads per month
SELECT
  YEAR(ACCESSDATE)                                          AS ReadYear,
  MONTH(ACCESSDATE)                                         AS ReadMonth,
  DATENAME(mm, ACCESSDATE) + ' ' + DATENAME(yy, ACCESSDATE) AS ReadMonth,
  COUNT(*)                                                  AS TotalReads,
  SUM(CASE WHEN SOURCEID =  30 THEN 1 ELSE 0 END)           AS iPad,
  SUM(CASE WHEN SOURCEID =  31 THEN 1 ELSE 0 END)           AS iPhone,
  COUNT(DISTINCT ContactId)					                        AS NumUsers
FROM sysdba.SCB_WEB_USAGE SWU
WHERE ACCESSDATE >= '01/01/2011'                            -- [iPad App Release Date: 09/13/2011]
--WHERE ACCESSDATE >= '03/06/2012'                          -- [iPad App Release Date: 09/13/2011]
  AND SourceId IN (30, 31)
  --AND SWU.Access_Email_Addr  LIKE '%@bernstein.com'
  --AND SWU.Access_Email_Addr  NOT LIKE '%@bernstein.com'
GROUP BY
  YEAR(ACCESSDATE),
  MONTH(ACCESSDATE),
  DATENAME(mm, ACCESSDATE) + ' ' + DATENAME(yy, ACCESSDATE)
ORDER BY 1, 2


USE SlxExternal   --SlxExternal.dbo.SCB_UNIQUE_READERS
GO
-- FILTERED Reads per month
SELECT
  YEAR(READ_DATE)                                          AS ReadYear,
  MONTH(READ_DATE)                                         AS ReadMonth,
  DATENAME(mm, READ_DATE) + ' ' + DATENAME(yy, READ_DATE)  AS ReadMonth,
  COUNT(*)                                                 AS TotalReads,
  SUM(CASE WHEN SOURCEID =  30 THEN 1 ELSE 0 END)          AS iPad,
  SUM(CASE WHEN SOURCEID =  31 THEN 1 ELSE 0 END)          AS iPhone,
  COUNT(DISTINCT ContactId)					                       AS NumUsers
FROM SlxExternal.dbo.SCB_UNIQUE_READERS
WHERE READ_DATE >= '01/01/2011'                            -- [iPad App Release Date: 09/13/2011]
  AND SourceId IN (30, 31)
  --AND SWU.Access_Email_Addr  LIKE '%@bernstein.com'
  --AND SWU.Access_Email_Addr  NOT LIKE '%@bernstein.com'
GROUP BY
  YEAR(READ_DATE),
  MONTH(READ_DATE),
  DATENAME(mm, READ_DATE) + ' ' + DATENAME(yy, READ_DATE)
ORDER BY 1, 2

/*
SELECT TOP 100 * FROM SlxExternal.dbo.SCB_UNIQUE_READERS

SELECT TOP 100 * FROM sysdba.SCB_WEB_USAGE SWU
*/

