--Reads_per_pubno_within30days.sql 

--Database: SLXPRDDB\SALGX_PRD,16083

USE SlxExternal
GO

-- Report takes ~80 seconds for 2 1/2 years of data

DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)
DECLARE @vReadDays		INT 

SET @vSinceDate = '01/01/2009'
SET @vUntilDate = '05/31/2011'
SET @vReadDays = 30

SET NOCOUNT ON

-- Get the Total reads in the first x days a call is published, for al active coverage analysts.
DECLARE	@Reads TABLE 
  (PubNo                    INT, 
   ReadDate                 VARCHAR(20),
   SourceId                 INT,
   ReadDateMonth		    VARCHAR(30), 
   PubDate                  VARCHAR(20),
   DocTypeId                INT,
   Title                    VARCHAR(250),
   ContactId                VARCHAR(100),
   ReadYear                 VARCHAR(4), 
   ReadMonth                VARCHAR(4) )

INSERT	@Reads
    Select distinct
		UR.PubNo,
		CONVERT( varchar(10), UR.Read_Date, 101) AS ReadDate, 
		UR.SourceId, 
		DATENAME(mm, UR.READ_DATE) + '-' + DATENAME(yy, UR.READ_DATE) AS ReadMonthText,
		CONVERT( varchar(10), RVD.date, 101) AS PubDate,
		RVD.DocTypeId, 
		RVD.Title,
		UR.ContactId,
		CONVERT(varchar, DATEPART(yy, UR.READ_DATE)) AS ReadYear,
		Right('00' + CONVERT(varchar(2), DATEPART(mm, UR.READ_DATE)), 2) AS ReadMonth
    From SlxExternal.dbo.SCB_UNIQUE_READERS UR
    INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = UR.PUBNO
    WHERE RVD.date BETWEEN @vSinceDate AND @vUntilDate		-- Research published for the specified date range
	AND UR.READ_DATE <= RVD.date + @vReadDays				-- Use the reads per Research that happened in the first 30 days when a Call is published, to provide a more consistent sampling period.
	AND UR.SourceId IN (0)
	--AND RVD.DocTypeId IN (1,8)
    --AND RVD.DocId = 80653

--Verify the Total Reads at the PubNo level
--SELECT * FROM @Reads
--ORDER BY ReadYear asc, ReadMonth asc, PubNo asc
----------------------------------------------------------------------------------------------------


PRINT '------------------------------------------------------------------------------------------------------'
PRINT 'DISPLAY THE Reads per PubNo By each month [within 30 days of Publication]' 
PRINT 'Source: Analyst Blast; Research DocTypes: Research Call[1], External Flash[8]' 
PRINT '------------------------------------------------------------------------------------------------------'

-- Get the Total Reads per PubNo for a month
SELECT	PubDate, PubNo, 
		'30dayReads' = Count(*),
		DocTypeId, Title, SourceId
FROM @Reads
GROUP BY PubNo,  PubDate, DocTypeId, Title, SourceId
ORDER BY PubNo asc

SET NOCOUNT OFF