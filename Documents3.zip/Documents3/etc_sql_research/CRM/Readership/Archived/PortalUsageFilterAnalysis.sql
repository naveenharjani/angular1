-- PortalUsageFilterAnalysis.sql
-- 05/05/2014

/*
-- View Definition (SCB_UNIQUE_READERS)
-- as of 05/05/2014

SELECT DISTINCT SWU.PUBNO, SWU.CONTACTID,  DATEADD(day, 0, DATEDIFF(day, 0, ACCESSDATE ))  AS READ_DATE, SOURCEID
FROM         SalesLogix.sysdba.SCB_WEB_USAGE SWU with (NOLOCK)  INNER JOIN
                      SalesLogix.sysdba.CONTACT C ON C.CONTACTID = SWU.CONTACTID AND SWU.FILEFOUND IN ('Y', 'T') INNER JOIN
                      SalesLogix.sysdba.ACCOUNT A ON C.ACCOUNTID = A.ACCOUNTID 
                                    AND ISNULL(A.TYPE, '') NOT LIKE '%press%' 
                                    AND ISNULL(A.TYPE, '') NOT LIKE '%Industry%' 
                                    AND ISNULL(A.TYPE, '') NOT LIKE '%Internal%'
                                    --AND ISNULL(A.STATUS, '') ='ACTIVE'
*/

-- Bernstein Usage Analysis
-- READS EXCLUDED
-- Staff (internal), press and industry reads data are excluded
PRINT '-- ***'
PRINT '-- *** Bernstein Usage'
PRINT '-- ***'

-- SLX database
SELECT
    A.Type,
    A.Account,
    'Reads' = Count(*)
FROM SalesLogix.sysdba.scb_web_usage SWU
INNER JOIN Saleslogix.sysdba.contact CN ON CN.Email = SWU.ACCESS_EMAIL_ADDR
INNER JOIN Saleslogix.sysdba.inf_account_ext AE ON AE.AccountId = CN.AccountId
INNER JOIN Saleslogix.sysdba.Account A ON A.AccountId = AE.AccountId
WHERE SWU.ACCESSDATE  BETWEEN '01/01/2013' AND '12/31/2013'
AND SWU.CONTACTID  NOT IN (SELECT distinct CONTACTID FROM slxexternal.dbo.SCB_UNIQUE_READERS)
GROUP BY A.Type, A.Account
ORDER BY 3 DESC, 1,2

-- Non-Client Types: e.g. Press, Industry, Internal
-- Client Type:      e.g. Client, Private Client, Private Equity, Hard Dollar, Prospect

-- PORTAL READS INCLUDED
-- A sampling of Bloomberg reads by *bernstein* staff included in portal reads data.
-- Portal Usage Analysis
PRINT '-- ***'
PRINT '-- *** Portal Usage'
PRINT '-- ***'

-- Research database
select Account, count(*) NumReads from PortalUsage
where account like '%Bernstein%'
and year(readdate) = 2013
and SiteId = 3 -- Bloomberg
group by account
order by 2 desc

select Account, Contact, count(*) NumReads from PortalUsage
where account like '%Bernstein%'
and year(readdate) = 2013
and SiteId = 3
--and account = 'ALLIANCEBERNSTEIN L.P.'
group by account, contact
order by 3 desc, 1,2

select * from PortalUsage
where account like '%Bernstein%'
and year(readdate) = 2013
and SiteId = 3
--group by account
order by account, contact


/*

--DEBUG
SELECT top 100 * FROM  slxexternal.dbo.SCB_UNIQUE_READERS order by read_date desc
SELECT top 100 * FROM  SalesLogix.sysdba.scb_web_usage order by accessdate desc
SELECT top 100 * FROM  Saleslogix.sysdba.contact
Select top 100 * FROM  Saleslogix.sysdba.account where type = 'CLIENT'

*/