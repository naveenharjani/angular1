-- analyst_readership.sql

--SLX PROD: SLXPRDDB\SALGX_PRD,16083
--Custom Readership Report: Josh Stirling, a new analyst who is taking over Todd Bault's coverage would like to look at his readership stats to get a feel for what clients read.
--The system only shows active analysts. He would like a custom report going back to when we first started tracking readership and containing the following:
--Fields: Title, Date, Doc Type, No. Reads

DECLARE @vAnalystId		VARCHAR(100)
DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)

SET @vAnalystId = 150           --Todd Bault
SET @vSinceDate = '01/01/2000'
SET @vUntilDate = '09/30/2010'

SET NOCOUNT ON

SELECT DocId AS PUBNO INTO #TmpSearch FROM SlxExternal.dbo.RVDocuments WHERE 1 = 2

-- All primary authors for specified date range
IF @vAnalystId = ''
  BEGIN
    -- Research
    INSERT INTO #TmpSearch
    SELECT DISTINCT DocId
      FROM SlxExternal.dbo.RVDocuments
      WHERE Date BETWEEN @vSinceDate AND @vUntilDate
        AND DocTypeId NOT IN (5)   --Exclude Research Summary Calls
    UNION
    -- Non-research
    SELECT DISTINCT DocId
      FROM SlxExternal.dbo.RVAltDocuments
      WHERE Date BETWEEN @vSinceDate AND @vUntilDate
        AND DocTypeId NOT IN (5)   --Exclude Research Summary Calls
  END

-- Specified primary author for specified date range
ELSE IF @vAnalystId <> ''
  BEGIN
    INSERT INTO #TmpSearch
    -- Research
    SELECT DISTINCT D.DocId 
      FROM SlxExternal.dbo.RVDocuments D 
      INNER JOIN  SlxExternal.dbo.RVDocAnalysts A on A.docid = D.docid AND A.AnalystId = @vAnalystId
      --The line below limits results to reports where selected analyst is primary author
      --and A.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = A.DocId)
      WHERE Date BETWEEN @vSinceDate AND @vUntilDate
        AND DocTypeId NOT IN (5)   --Exclude Research Summary Calls
    UNION
    -- Non-research
    SELECT DISTINCT D.DocId 
      FROM SlxExternal.dbo.RVAltDocuments D 
      INNER JOIN  SlxExternal.dbo.RVAltDocAnalysts A on A.docid = D.docid AND A.AnalystId = @vAnalystId
      --The line below limits results to reports where selected analyst is primary author
      --and A.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = A.DocId)
      WHERE Date BETWEEN @vSinceDate AND @vUntilDate
        AND DocTypeId NOT IN (5)   --Exclude Research Summary Calls
  END

-- Research
SELECT
  'ID' = v1.PUBNO,
  'Date' = CONVERT(varchar, RVD.Date,101),
  'Type' = -- Document type alias
    CASE RVT.DocType
      WHEN 'Research Note' THEN 'Note'
      WHEN 'Black Book' THEN 'Blackbook'
      WHEN 'White Book' THEN 'Whitebook'
      WHEN 'Research Call' THEN (CASE substring(RVD.Title, 1, 10) WHEN 'Quick Take' THEN 'Flash' ELSE 'Call' END)
      ELSE RVT.DocType
    END,
  'Title' = RVD.Title,
  'Primary Author' = RVDA.Last,
  'Reads' = v1.read_count
FROM
(
  --Use the SLX VIEW to calculate unique clicks for each research document.
  SELECT PUBNO, 'read_count' = count(*) 
  FROM SlxExternal.dbo.SCB_UNIQUE_READERS
  GROUP BY PUBNO
) AS v1
INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = v1.PUBNO
INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId
-- Primary analyst indicated by ordinal value
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = v1.PUBNO
  AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
WHERE v1.PUBNO in (SELECT PubNo FROM #TmpSearch)

ORDER BY RVD.Date DESC, V1.PubNo DESC

DROP TABLE #TmpSearch
