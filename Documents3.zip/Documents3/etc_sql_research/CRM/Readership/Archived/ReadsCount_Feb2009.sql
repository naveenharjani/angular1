-- ReadsCount_Feb2009.sql

USE Saleslogix
go
----------------------------------------------------------------------------------------------------
DECLARE @vSinceDate_BR		VARCHAR(12)
DECLARE @vUntilDate_BR		VARCHAR(12)
DECLARE @vSinceDate_LS		VARCHAR(12)

SET @vSinceDate_BR = '02/06/2009'
SET @vUntilDate_BR = '02/27/2009'
SET @vSinceDate_LS = '02/28/2009'
  
SELECT V1.ProgramSource AS 'Program Source', 
       V1.DateRange AS 'Date Range', 
       V1.Gross_Reads_Totals AS '#Gross Reads [Incl. Bernstein.com email reads]', 
       V2.Gross_Reads_Clients AS '#Gross Reads [Clients reads only]' 
       --V3.Unique_Reads_Clients AS '#Unique Reads', 
       --CONVERT( DECIMAL(10,4), V3.Unique_Reads_Clients)/CONVERT( DECIMAL(10,4), V2.Gross_Reads_Clients) * 100 AS '%Unique Reads'
FROM
(
  SELECT 'BR.com' AS ProgramSource,
         @vSinceDate_BR + ' - ' + @vUntilDate_BR AS DateRange,
         count(*) AS Gross_Reads_Totals     --'GROSS_READS [incl. bernstein.com]'
  FROM   sysdba.SCB_WEB_USAGE
  WHERE  accessdate between @vSinceDate_BR AND @vUntilDate_BR
  AND    sourceid = 10
) V1,
(
  SELECT count(*) AS Gross_Reads_Clients    -- 'GROSS_READS [excl. bernstein.com]'
  FROM   sysdba.SCB_WEB_USAGE
  WHERE  accessdate between @vSinceDate_BR AND @vUntilDate_BR
  AND    sourceid = 10
  AND    access_email_addr NOT LIKE '%bernstein.com%'
) V2
--,(
--  SELECT count(*) AS Unique_Reads_Clients   --'UNIQUE_READS'
--  FROM   SlxExternal.dbo.SCB_UNIQUE_READERS UR
--  WHERE  read_date between @vSinceDate_BR AND @vUntilDate_BR
--) V3
UNION
SELECT V1.ProgramSource, V1.DateRange, 
       V1.Gross_Reads_Totals AS '#Gross Reads [Incl. Bernstein.com reads]', 
       V2.Gross_Reads_Clients AS '#Gross Reads [Clients reads only]' 
--       V3.Unique_Reads_Clients AS '#Unique Reads',
--       CONVERT( DECIMAL(10,4), V3.Unique_Reads_Clients)/CONVERT( DECIMAL(10,4), V2.Gross_Reads_Clients) * 100 AS '%Unique Reads'
FROM
(
  SELECT 'LogShipper' AS ProgramSource,
         @vSinceDate_LS AS DateRange,
         count(*) AS Gross_Reads_Totals    --'GROSS_READS [incl. bernstein.com]'
  FROM   sysdba.SCB_WEB_USAGE
  WHERE  convert(varchar(20), accessdate, 101) = @vSinceDate_LS
) V1,
(
  SELECT count(*) AS Gross_Reads_Clients    -- 'GROSS_READS [excl. bernstein.com]'
  FROM   sysdba.SCB_WEB_USAGE
  WHERE  convert(varchar(20), accessdate, 101) = @vSinceDate_LS
  AND    access_email_addr NOT LIKE '%bernstein.com%'
) V2
--,(
--  SELECT count(*) AS Unique_Reads_Clients   --'UNIQUE_READS'
--  FROM   SlxExternal.dbo.SCB_UNIQUE_READERS UR
--  WHERE  convert(varchar(20), read_date, 101) = @vSinceDate_LS
--) V3
UNION
SELECT V1.ProgramSource, V1.DateRange, 
       V1.Gross_Reads_Totals AS '#Gross Reads [Incl. Bernstein.com reads]', 
       V2.Gross_Reads_Clients AS '#Gross Reads [Clients reads only]' 
--       V3.Unique_Reads_Clients AS '#Unique Reads',
--       CONVERT( DECIMAL(10,4), V3.Unique_Reads_Clients)/CONVERT( DECIMAL(10,4), V2.Gross_Reads_Clients) * 100 AS '%Unique Reads'
FROM
(
  SELECT 'Total' AS ProgramSource,
         @vSinceDate_BR + ' - ' + @vSinceDate_LS AS DateRange,
         count(*) AS Gross_Reads_Totals    --'GROSS_READS [incl. bernstein.com]'
  FROM   sysdba.SCB_WEB_USAGE
  WHERE  accessdate between @vSinceDate_BR AND @vSinceDate_LS
) V1,
(
  SELECT count(*) AS Gross_Reads_Clients    -- 'GROSS_READS [excl. bernstein.com]'
  FROM   sysdba.SCB_WEB_USAGE
  WHERE  accessdate between @vSinceDate_BR AND @vSinceDate_LS
  AND    access_email_addr NOT LIKE '%bernstein.com%'
) V2
--,(
--  SELECT count(*) AS Unique_Reads_Clients   --'UNIQUE_READS'
--  FROM   SlxExternal.dbo.SCB_UNIQUE_READERS UR
--  WHERE  read_date between @vSinceDate_BR AND @vSinceDate_LS
--) V3

GO
