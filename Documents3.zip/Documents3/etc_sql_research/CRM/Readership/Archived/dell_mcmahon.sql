-- BenDell_NeilBeveridge_analyst_readership.sql

--SLX PROD: SLXPRDDB\SALGX_PRD,16083
--Custom Readership Report: 
--Bob is taking over Ben Dell's coverage and he'd like to read the reports written by Ben and/or Neil Mcmahon that have the highest readership.
--Can he get a report of previous research written by both those analysts similar to the one we ran for Todd Sterling?
--The system only shows active analysts. He would like a custom report going back to when we first started tracking readership and containing the following:
--Fields: Title, Date, Doc Type, No. Reads

--DECLARE @vAnalystId		VARCHAR(100)
DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)

-- select * from SlxExternal.dbo.RVAnalysts where Last like '%dell%'
--SET @vAnalystId = 237           --Neil McMahon, Ph.D.
--SET @vAnalystId = 248           --Ben P. Dell

--SET @vAnalystId = 431           --Neil Beveridge, Ph.D.
SET @vSinceDate = '01/01/2005'
SET @vUntilDate = '12/31/2010'

SET NOCOUNT ON

SELECT DocId AS PUBNO INTO #TmpSearch FROM SlxExternal.dbo.RVDocuments WHERE 1 = 2

INSERT INTO #TmpSearch
-- Research
SELECT DISTINCT D.DocId 
  FROM SlxExternal.dbo.RVDocuments D 
  INNER JOIN  SlxExternal.dbo.RVDocAnalysts A on A.docid = D.docid AND A.AnalystId IN (237, 248)
  --The line below limits results to reports where selected analyst is primary author
  --and A.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = A.DocId)
  WHERE Date BETWEEN @vSinceDate AND @vUntilDate
    AND DocTypeId NOT IN (5)   --Exclude Research Summary Calls
UNION
-- Non-research
SELECT DISTINCT D.DocId 
  FROM SlxExternal.dbo.RVAltDocuments D 
  INNER JOIN  SlxExternal.dbo.RVAltDocAnalysts A on A.docid = D.docid AND A.AnalystId IN (237, 248)
  --The line below limits results to reports where selected analyst is primary author
  --and A.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = A.DocId)
  WHERE Date BETWEEN @vSinceDate AND @vUntilDate
    AND DocTypeId NOT IN (5)   --Exclude Research Summary Calls


-- Research
SELECT
  'ID' = v1.PUBNO,
  'Date' = CONVERT(varchar, RVD.Date,101),
  'Type' = -- Document type alias
    CASE RVT.DocType
      WHEN 'Research Note' THEN 'Note'
      WHEN 'Black Book' THEN 'Blackbook'
      WHEN 'White Book' THEN 'Whitebook'
      WHEN 'Research Call' THEN (CASE substring(RVD.Title, 1, 10) WHEN 'Quick Take' THEN 'Flash' ELSE 'Call' END)
      ELSE RVT.DocType
    END,
  'Title' = RVD.Title,
  'Primary Author' = RVDA.Last,
  'Reads' = v1.read_count
FROM
(
  --Use the SLX VIEW to calculate unique clicks for each research document.
  SELECT PUBNO, 'read_count' = count(*) 
  FROM SlxExternal.dbo.SCB_UNIQUE_READERS
  GROUP BY PUBNO
) AS v1
INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = v1.PUBNO
INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId
-- Primary analyst indicated by ordinal value
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = v1.PUBNO
  AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
WHERE v1.PUBNO in (SELECT PubNo FROM #TmpSearch)

ORDER BY RVD.Date DESC, V1.PubNo DESC

DROP TABLE #TmpSearch
