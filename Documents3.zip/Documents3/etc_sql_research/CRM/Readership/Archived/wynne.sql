-- readinfo.sql

--For an analyst, get the reads data as per email id, last read date, # of reads, source = analyst blast
--SLXPRDDB\SALGX_PRD,16083

USE Saleslogix
GO

----------------------------------------------------------------------------------------------------
--Filter by Analyst Id and Source Id
DECLARE @iAnalystId		    INT
DECLARE @iSourceId		    INT

-- SELECT * FROM SlxExternal.dbo.RVAnalysts where Last like '%wynn%'
-- SELECT * FROM sysdba.SCB_WEB_USAGE where ACCESS_EMAIL_ADDR = ''
-- SELECT * FROM sysdba.CONTACT where contactid = 'C6UJ9A000AKJ'
-- SELECT * FROM sysdba.CONTACT where ACCOUNT = 'Lehman ARB'

SET @iAnalystId = 204   --280  --204
SET @iSourceId  = 0       -- Analyst Blast

SET NOCOUNT ON
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------  
-- Get the readership data by analyst.
----------------------------------------------------------------------------------------------------  
DECLARE @TotalReads TABLE   
(  
   Analyst                  VARCHAR(100),
   AccessDate               DATETIME,
   AccessEmailAddr          VARCHAR(255),
   Account                  VARCHAR(255),  
   Source                   VARCHAR(50),
   SourceId                 INT,
   AnalystId                INT,
   ContactId                VARCHAR(200),
   ContactEmail             VARCHAR(100)
)  

----Get the Filtered Analyst list as per the parameters specified  
INSERT @TotalReads 
SELECT 
  'Analyst' = RVDA.Last + ', ' + RVDA.First,
  SWU.ACCESSDATE,
  SWU.ACCESS_EMAIL_ADDR,
  C.ACCOUNT,
  CASE SWU.SOURCEID
    WHEN 0  THEN 'Analyst Blast'
    WHEN 1  THEN 'Morning Summary'
    WHEN 2  THEN 'Cart'
    WHEN 10 THEN 'bernsteinresearch.com'
    ELSE 'Other' 
  END
  AS SOURCE,
  SWU.SOURCEID,
  'AuthorId' = RVDA.AnalystId,
  SWU.CONTACTID,
  C.Email
from sysdba.SCB_WEB_USAGE SWU
INNER JOIN sysdba.CONTACT C on C.CONTACTID = SWU.CONTACTID
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = SWU.PUBNO
       and RVDA.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = RVDA.DocId) 
WHERE SWU.STATUS = 'T'
  AND NOT SWU.ACCESS_EMAIL_ADDR like '%@bernstein.com'
  AND NOT SWU.ACCESS_EMAIL_ADDR = '' 
  AND RVDA.AnalystId = @iAnalystId
--  AND SWU.SOURCEID = @iSourceId
ORDER BY ACCESSDATE desc

--SELECT * FROM @TotalReads

PRINT '------------------------------------------------------------------------------------------------------'
PRINT 'REPORT : DISPLAY THE "First Read Date, Last Read Date, Total Reads Clicks for an Email Account" BY Analyst' 
PRINT '------------------------------------------------------------------------------------------------------'

SELECT DISTINCT
  'Analyst' = V1.Analyst,
  'Email (current)' = ISNULL(V1.ContactEmail,''),
  'Email (logged)'  = V1.AccessEmailAddr,
  'Account' = V1.Account,
  'First Read Date' = V2.FirstReadDate,
  'Last Read Date' = V2.LastReadDate, 
  'Clicks (non-filterd)' = V2.Reads
  --V1.ContactId
FROM @TotalReads V1, (SELECT AccessEmailAddr, 
                             CAST(MIN(accessdate) AS Datetime) AS FirstReadDate,
                             CAST(MAX(accessdate) AS Datetime) AS LastReadDate, 
                             Count(*) AS Reads
                        FROM @TotalReads V2 
                       WHERE V2.AnalystId = @iAnalystId
                       GROUP BY AccessEmailAddr) V2
WHERE V1.AccessEmailAddr = V2.AccessEmailAddr                      
ORDER BY 2
