-- Multi-Analyst Report Metrics - SLX.sql

--Server Info:  SLXPRDDB\SALGX_PRD,16083
--Database: SlxExternal
--Table: scb_unique_readers
--UID: researchsvc

-- Bernstein Commodities and Power
-- Weekly Commodities and Power Blast

/*

-- Details
select date,p.docid,p.title,r.pubno,r.contactid
from
  rvdocuments p join scb_unique_readers r on p.docid = r.pubno
where
  p.docid in 
        (select p.docid from rvdocuments p 
          join rvdocanalysts a on p.docid = a.docid
          where
              p.doctypeid = 1 and                   -- Research Call
              title not like '%media blast%' and
              title not like '%Commodities and Power%' and
              date between '01/01/2007' and '12/31/2008' 
          group by
                p.docid
          having count(*) > 1)
order by p.docid          

*/

--
print 'Average num reads - Calls w/ more than one senior analyst excluding media and energy blasts'
select Year = datepart(yy,date),CallCount = count(distinct p.docid), readcount = count(r.pubno),average = count(r.pubno)/count(distinct p.docid)
from
  rvdocuments p left outer join scb_unique_readers r on p.docid = r.pubno
where
  p.docid in 
        (select p.docid from rvdocuments p 
          join rvdocanalysts a on p.docid = a.docid
          where
              p.doctypeid = 1 and                   -- Research Call
              date between '01/01/2007' and '12/31/2008' 
          group by
                p.docid
          having count(*) > 1)
group by
  datepart(yy,date)
order by 1 desc

--
print 'Average num reads - Calls w/ more than one senior analyst excluding media and energy blasts'
select Year = datepart(yy,date),CallCount = count(distinct p.docid), readcount = count(r.pubno),average = count(r.pubno)/count(distinct p.docid)
from
  rvdocuments p left outer join scb_unique_readers r on p.docid = r.pubno
where
  p.docid in 
        (select p.docid from rvdocuments p 
          join rvdocanalysts a on p.docid = a.docid
          where
              p.doctypeid = 1 and                   -- Research Call
              title not like '%media blast%' and
              title not like '%Commodities and Power%' and
              date between '01/01/2007' and '12/31/2008' 
          group by
                p.docid
          having count(*) > 1)
group by
  datepart(yy,date)
order by 1 desc

--
print 'Average num reads - media blast'
select Year = datepart(yy,date),CallCount = count(distinct p.docid), readcount = count(r.pubno),average = count(r.pubno)/count(distinct p.docid)
from
  rvdocuments p left outer join scb_unique_readers r on p.docid = r.pubno
where
  p.docid in 
        (select p.docid from rvdocuments p 
          join rvdocanalysts a on p.docid = a.docid
          where
              p.doctypeid = 1 and                   -- Research Call
              title  like '%media blast%' and
              date between '01/01/2007' and '12/31/2008' 
          group by
                p.docid
          having count(*) > 1)
group by
  datepart(yy,date)
order by 1 desc

--
print 'Average num reads - energy blast'
select Year = datepart(yy,date),CallCount = count(distinct p.docid), readcount = count(r.pubno),average = count(r.pubno)/count(distinct p.docid)
from
  rvdocuments p left outer join scb_unique_readers r on p.docid = r.pubno
where
  p.docid in 
        (select p.docid from rvdocuments p 
          join rvdocanalysts a on p.docid = a.docid
          where
              p.doctypeid = 1 and                   -- Research Call
              title  like '%Commodities and Power%' and
              date between '01/01/2007' and '12/31/2008' 
          group by
                p.docid
          having count(*) > 1)
group by
  datepart(yy,date)
order by 1 desc
