-- Adhoc_SLX.sql

-- SLXPRDDB\SALGX_PRD,16083

-- 10/03/2011 - Mike Tedesco - Filtered reads for Janet Luby

SELECT
  'PubNo' = v1.PUBNO,
  'Read Date' = CONVERT(varchar, v1.READ_DATE,101),
  'Author' = RVDA.Last,
  'Report Date' = CONVERT(varchar, RVD.Date,101),
  'Report Title' = RVD.Title
FROM SlxExternal.dbo.SCB_UNIQUE_READERS v1
INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = v1.PUBNO
-- Primary analyst indicated by ordinal value
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = v1.PUBNO
  and RVDA.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = RVDA.DocId)
  --Filter by Sales CONTACTID
  and v1.ContactId IN (select ContactId from Saleslogix.sysdba.contact where firstname = 'Janet' and lastname = 'Luby')
ORDER BY 2, 1 -- RVD.Date DESC, V1.PubNo DESC

/*

Sara Senatore - Account list reads for CEO Unplugged / Transcript

*** Exclude "Reads" column from xlsx

*/

-- SLXPRDDB,16083 | research_db_svc

USE SlxExternal
GO

DECLARE @PubNo INT
set @PubNo = 102013 -- 02/18/2014 - U.S. Restaurants - CEO Unplugged:...
set @PubNo = 105956 -- 08/01/2014 - Call U.S. Restaurants: CEO Unplugged...
set @PubNo = 106521 -- 08/29/2014 - Call U.S. Restaurants: CEO Unplugged...
set @PubNo = 108964 -- 12/09/2015 - U.S. Restaurants ... [Transcript]...
set @PubNo = 108964 -- 12/09/2015 - U.S. Restaurants ... [Transcript]...
set @PubNo = 115884 -- 09/28/2015 (09/22/2015) - U.S. Restaurants ... [Transcript]...
set @PubNo = 102013 -- 09/28/2015 (2/18/2014) - U.S. Restaurants ... [Transcript]...
set @PubNo = 127546 -- 01/30/2017 (1/30/2017) - U.S. Restaurants ... [Transcript]...
set @PubNo = 130172 -- 05/22/2017 (5/18/2017) - U.S. Restaurants ... [Transcript]...

/*
-- OLD

SELECT
  A.Account,
  'Reads' = COUNT(*)
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
INNER JOIN Saleslogix.sysdba.CONTACT C ON C.CONTACTID = UR.CONTACTID
INNER JOIN Saleslogix.sysdba.ACCOUNT A ON A.ACCOUNTID = C.ACCOUNTID
WHERE UR.PubNo = @PubNo
GROUP BY A.Account
ORDER BY 1

*/

SELECT
  'Account' = convert(varchar(50), A.AccountName)
--  'Reads' = COUNT(*)
FROM SlxExternal.dbo.vwUniqueReaders UR
INNER JOIN Compass.dbo.CONTACT C ON C.SLXCONTACTID = UR.CONTACTID
INNER JOIN Compass.dbo.ACCOUNT A ON A.ACCOUNTID = C.ACCOUNTID
WHERE UR.PubNo = @PubNo
GROUP BY A.AccountName
ORDER BY 1

