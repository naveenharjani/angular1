-- Reads_Per_Month.sql

--1. Get the Total reads Count by read month
--2. Get the Total reads percent by read month

--SLX PRODUCTION: SLXPRDDB\SALGX_PRD,16083

USE SlxExternal
GO

----------------------------------------------------------------------------------------------------
--Filters
DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)

SET @vSinceDate = '01/01/2009'
SET @vUntilDate = getdate()

SET NOCOUNT ON
----------------------------------------------------------------------------------------------------

-- Get the Absolute Report Usage Reads data in a Month
DECLARE	@AbsoluteReadsInaMonth TABLE 
  (
   ReadMonthText            VARCHAR(30), 
   ReadYear                 VARCHAR(4), 
   ReadMonth                VARCHAR(4),
   ReadDate                 datetime,
   PubNo                    INT,
   ContactID                VARCHAR(100),
   SourceId                 INT
   )

INSERT	@AbsoluteReadsInaMonth
    SELECT distinct
           DATENAME(month, UR.READ_DATE) + '-' + DATENAME(yy, UR.READ_DATE) AS ReadMonthText,
           CONVERT(varchar, DATEPART(yy, UR.READ_DATE)) AS ReadYear,
           Right('00' + CONVERT(varchar(2), DATEPART(mm, UR.READ_DATE)), 2) AS ReadMonth,
           UR.READ_DATE, UR.PUBNO, UR.CONTACTID, UR.SOURCEID
    FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
    WHERE UR.READ_DATE BETWEEN @vSinceDate AND @vUntilDate

--SELECT * FROM @AbsoluteReadsInaMonth
----------------------------------------------------------------------------------------------------

DECLARE	@ReadsBySourceInaMonth TABLE 
  (
   ReadYear                 VARCHAR(4), 
   ReadMonth                VARCHAR(4),
   ReadMonthText            VARCHAR(30), 
   ReadsTotal               INT,
   ReadsBlast               INT,
   ReadsSummary             INT,
   ReadsCart                INT,
   ReadsBR                  INT,
   ReadsEmbed               INT,
   ReadsSales               INT
   )

----------------------------------------------------------------------------------------------------
PRINT '------------------------------------------------------------------------------------------------------'
PRINT 'REPORT 1: DISPLAY THE "Total Reads Per Product" BY EACH READ MONTH' 
PRINT '------------------------------------------------------------------------------------------------------'
--Display the Absolute READS data - column wise PIVOT structure
INSERT @ReadsBySourceInaMonth
SELECT
    ReadYear, ReadMonth, ReadMonthText,
		COUNT(*)		                                        AS [Total],
		SUM(CASE WHEN SourceId =  0 THEN 1 ELSE 0 END)			AS [Blast],
		SUM(CASE WHEN SourceId =  1 THEN 1 ELSE 0 END)			AS [Summary],
		SUM(CASE WHEN SourceId =  2 THEN 1 ELSE 0 END)			AS [Cart],
		SUM(CASE WHEN SourceId = 10 THEN 1 ELSE 0 END)			AS [BR.com],
		SUM(CASE WHEN SourceId = 3 THEN 1 ELSE 0 END)			AS [Embed],
		SUM(CASE WHEN SourceId = 4 THEN 1 ELSE 0 END)			AS [Sales]
FROM		 @AbsoluteReadsInaMonth
GROUP BY ReadYear, ReadMonth, ReadMonthText

SELECT * FROM @ReadsBySourceInaMonth

PRINT '------------------------------------------------------------------------------------------------------'
PRINT 'DISPLAY THE "Absolute Reads Percent Per Product" BY EACH READ MONTH' 
PRINT '------------------------------------------------------------------------------------------------------'
SELECT
    ReadYear, ReadMonth, ReadMonthText,
	CONVERT( DECIMAL(10,4),
                           CONVERT( DECIMAL(10,2), (ReadsBlast))/CONVERT( DECIMAL(10,2), (ReadsTotal))
                           )    AS [BlastPercent],
	CONVERT( DECIMAL(10,4),
                           CONVERT( DECIMAL(10,2), (ReadsSummary))/CONVERT( DECIMAL(10,2), (ReadsTotal))
                           )    AS [SummaryPercent],
	CONVERT( DECIMAL(10,4),
                           CONVERT( DECIMAL(10,2), (ReadsCart))/CONVERT( DECIMAL(10,2), (ReadsTotal))
                           )    AS [CartPercent],
	CONVERT( DECIMAL(10,4),
                           CONVERT( DECIMAL(10,2), (ReadsBR))/CONVERT( DECIMAL(10,2), (ReadsTotal))
                           )    AS [BRPercent],
	CONVERT( DECIMAL(10,4),
                           CONVERT( DECIMAL(10,2), (ReadsEmbed))/CONVERT( DECIMAL(10,2), (ReadsTotal))
                           )    AS [EmbedPercent],
	CONVERT( DECIMAL(10,4),
                           CONVERT( DECIMAL(10,2), (ReadsSales))/CONVERT( DECIMAL(10,2), (ReadsTotal))
                           )    AS [SalesPercent]
FROM	@ReadsBySourceInaMonth
