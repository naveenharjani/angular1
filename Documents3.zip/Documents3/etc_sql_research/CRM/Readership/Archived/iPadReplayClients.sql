-- iPadReplayClients.sql
-- 03/18/2013

-- SLX PRD: SLXPRDDB\SALGX_PRD,16083

select * from SlxExternal.dbo.RVLinkSources

-- iPad / iPhone app users that have played audio replays
SELECT DISTINCT RVLS.Source, U.ACCESS_EMAIL_ADDR, COUNT(*)
FROM sysdba.SCB_USAGE_LOGSHIPPER U
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE (CHARINDEX('.MP3', UPPER(U.CONTENT_SOURCE)) > 0 OR CHARINDEX('.MP4', UPPER(U.CONTENT_SOURCE)) > 0)
AND U.SourceId IN (30, 31)
--AND U.SourceId IN (10)
AND U.ACCESS_EMAIL_ADDR NOT LIKE '%bernstein.com'
GROUP BY RVLS.Source, U.ACCESS_EMAIL_ADDR
ORDER BY 3 DESC

-- Content Usage - Get Email Address lists for Audio
SELECT DISTINCT RVLS.Source, U.ACCESS_EMAIL_ADDR
FROM sysdba.SCB_USAGE_LOGSHIPPER U
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE (CHARINDEX('.MP3', UPPER(U.CONTENT_SOURCE)) > 0 OR CHARINDEX('.MP4', UPPER(U.CONTENT_SOURCE)) > 0)
AND U.SourceId IN (30, 31)
--AND U.SourceId IN (10)
AND U.ACCESS_EMAIL_ADDR NOT LIKE '%bernstein.com'
--AND U.ACCESS_EMAIL_ADDR NOT LIKE '%bogdanrb@aol.com'
ORDER BY RVLS.Source

-- Content Usage - Email Count
SELECT 'Type' = 'ContentUsage', RVLS.Source, 'EmailCount' = COUNT(DISTINCT U.ACCESS_EMAIL_ADDR), U.SOURCEID
FROM sysdba.SCB_USAGE_LOGSHIPPER U
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE (CHARINDEX('.MP3', UPPER(U.CONTENT_SOURCE)) > 0 OR CHARINDEX('.MP4', UPPER(U.CONTENT_SOURCE)) > 0)
AND U.SourceId IN (30, 31)
AND U.ACCESS_EMAIL_ADDR NOT LIKE '%bernstein.com' 
GROUP BY U.SOURCEID, RVLS.Source
ORDER BY U.SOURCEID




-- Web Usage - Get Email Address lists for Video calls
SELECT DISTINCT 'Type' = 'WebUsage', RVLS.Source, U.ACCESS_EMAIL_ADDR, U.SOURCEID
FROM sysdba.scb_web_usage U
INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = U.PUBNO
INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId AND RVT.DocTypeId IN (10)     -- Filter by video calls
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE U.ACCESS_EMAIL_ADDR NOT LIKE '%bernstein.com'
ORDER BY U.SOURCEID

-- Web Usage - Email Count for Video calls
SELECT TOP 5000 'Type'       = 'WebUsage', RVLS.Source, 'EmailCount' = COUNT(DISTINCT U.ACCESS_EMAIL_ADDR), U.SOURCEID
FROM sysdba.scb_web_usage U
INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = U.PUBNO
INNER JOIN SlxExternal.dbo.RVTypes RVT ON RVT.DocTypeId = RVD.DocTypeId AND RVT.DocTypeId IN (10)     -- Filter by video calls
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE U.ACCESS_EMAIL_ADDR NOT LIKE '%bernstein.com'
GROUP BY U.SOURCEID, RVLS.Source
ORDER BY U.SOURCEID

