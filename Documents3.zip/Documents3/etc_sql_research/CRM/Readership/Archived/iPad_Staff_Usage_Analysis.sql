-- iPad_Staff_Usage_Analysis.sql
-- 05/08/2014

select * from RVLinkSources

-- RAW

-- Derived from \sqlxml\webusage.sql

-- Detail
SELECT TOP 5000
  U.PUBNO,
  U.ACCESSDATE, -- Date Accessed
  CONVERT(varchar, U.ACCESSDATE, 101) AS AccessDate2, -- Date Accessed  dd/mm/yyyy
  U.ACCESS_EMAIL_ADDR,
--  U.SOURCEID,
  RVLS.Source,
--  U.STATUS,
  RVD.Date, 
  RVD.Title
FROM sysdba.scb_web_usage U
INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = U.PUBNO
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE U.SOURCEID IN (30, 31)
AND ACCESS_EMAIL_ADDR LIKE '%@bernstein.com'
ORDER BY ACCESSDATE DESC

-- Summary
SELECT TOP 5000
  CAST(CONVERT(varchar, U.ACCESSDATE, 101) AS DATETIME) AS AccessDate2, -- Date Accessed  dd/mm/yyyy
  U.ACCESS_EMAIL_ADDR,
  RVLS.Source, 
  COUNT(*)
FROM sysdba.scb_web_usage U
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE U.SOURCEID IN (30, 31)
AND ACCESS_EMAIL_ADDR LIKE '%@bernstein.com'
GROUP BY CAST(CONVERT(varchar, U.ACCESSDATE, 101) AS DATETIME), U.ACCESS_EMAIL_ADDR, RVLS.Source
HAVING COUNT(*) > 5
ORDER BY 1 DESC

-- 05/09/2014
colin.mcgranahan@bernstein.com
steven.fanelli@bernstein.com
tracy.hampton@bernstein.com
peter.agresta@bernstein.com
kenny.lane@bernstein.com
will.hyland@bernstein.com
sebastian.lewis@bernstein.com
david.henkel@bernstein.com
robert.browning@bernstein.com
brian.downey@bernstein.com
robert.vanbrugge@bernstein.com
stanley.ho@bernstein.com

