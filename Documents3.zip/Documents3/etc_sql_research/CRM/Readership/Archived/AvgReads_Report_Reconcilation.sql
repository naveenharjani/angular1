-- AvgReads_Report_Reconcilation.sql
USE Saleslogix
go
----------------------------------------------------------------------------------------------------
DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)
DECLARE @vReadDays    SMALLINT 

DECLARE @vAnalystId		VARCHAR(100)

SET @vSinceDate = '01/01/2008'  --'01/01/2007'
SET @vUntilDate = '12/31/2008'  --getdate()
SET @vReadDays = 5        --MAX Value for TINYINT is 255

--SET @vAnalystId = '150' --A.M. (Toni) Sacconaghi, Jr.
SET @vAnalystId = '204' --Hugh N. Wynne

SET NOCOUNT ON

----------------------------------------------------------------------------------------------------
--Verify the Total Reads at the DocId level
PRINT '------------------------------------------------------------------------------------------------------'
PRINT 'REPORT 1: OUR SQL REPORT "AVG READS PER CALL" FOR AN ANALYST' 
PRINT '------------------------------------------------------------------------------------------------------'

-- Get the Total reads in the first 5 days a call is published, for al active coverage analysts.
Select
       RVD.DocId,
       RVDA.Last,
       --Publication date
       DATENAME(mm, RVD.date) + ' ' + DATENAME(yy, RVD.date) AS CallsPublishedMonthYear,
       CONVERT(varchar, DATEPART(yy, RVD.date)) AS PubYear,
       Right('00' + CONVERT(varchar(2), DATEPART(mm, RVD.date)), 2) AS PubMonth,
       RVD.date AS PubDate,
       --Read date
       DATENAME(mm, UR.READ_DATE) + ' ' + DATENAME(yy, UR.READ_DATE) AS CallsReadMonthYear,
       CONVERT(varchar, DATEPART(yy, UR.READ_DATE)) AS ReadYear,
       Right('00' + CONVERT(varchar(2), DATEPART(mm, UR.READ_DATE)), 2) AS ReadMonth,
       UR.READ_DATE,
       --Other PubNo/Read/Analyst info
       RVD.title, RVDA.Name AS FullName, RVDA.ANALYSTID, UR.PUBNO, UR.CONTACTID
From SlxExternal.dbo.SCB_UNIQUE_READERS UR
INNER JOIN SlxExternal.dbo.RVDocuments RVD 
    ON RVD.DocId = UR.PUBNO 
    AND RVD.DocTypeId = 1   --Only the Research Calls

INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA 
    ON RVDA.DocID = UR.PubNo
   --Selected analyst is primary author[Primary analyst indicated by ordinal value]
   --AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
   --Active Coverage - Consider Analysts with Active Ticker Coverage as of today from the ResearchCoverage Table
   AND RVDA.AnalystId IN ( SELECT DISTINCT ANALYSTID FROM SlxExternal.dbo.RVResearchCoverage RVRC WHERE DROPDATE IS NULL)

   AND RVDA.AnalystId = @vAnalystId  --Filter on the Analyst for TESTING
   
WHERE RVD.date BETWEEN @vSinceDate AND @vUntilDate -- All reads for the specified date range
  --AND UR.READ_DATE <= RVD.date + @vReadDays        -- Use the average reads per Call in first 5 days when a Call is published, to provide a more consistent sampling period.

go
----------------------------------------------------------------------------------------------------
DECLARE @region		    VARCHAR(100)
DECLARE @user_title		VARCHAR(100)
DECLARE @fromDate     VARCHAR(12) 
DECLARE @toDate       VARCHAR(12) 

DECLARE @vAnalystId		VARCHAR(100)

SET @region = 'New York'
SET @user_title = 'Senior Analyst'
SET @fromDate = '1/1/2008'
SET @toDate = '12/31/2008'

SET @vAnalystId = 204  --Hugh N. Wynne
--SET @vAnalystId = '150' --A.M. (Toni) Sacconaghi, Jr.


PRINT '------------------------------------------------------------------------------------------------------'
PRINT 'REPORT 1: MAO''s SQL REPORT "AVG READS PER CALL" FOR AN ANALYST' 
PRINT '------------------------------------------------------------------------------------------------------'

--Show All records --No grouping
--select U.UserID, count(w.pubno) as link_readership 
select distinct U.UserID, U.USERNAME, sa.Rsch_analystID, RD.AnalystID, w.pubno, w.contactid, w.read_date
--count(w.pubno) as link_readership 
from saleslogix.sysdba.SCB_Analyst sa 
inner join saleslogix.sysdba.userinfo u on  u.userid = sa.userid and u.region = @region and u.title like '%'+ @user_title + '%'
inner join SLXExternal.dbo.RVDocAnalysts RD on sa.Rsch_analystID = RD.AnalystID
inner join SLXExternal.dbo.RVDocuments R   on RD.DocID = R.DocID and R.docTypeID = 1
inner join SLXExternal.dbo.SCB_UNIQUE_READERS W  on W.pubNo = R.DocID 
--and W.Read_date >= @fromDate and read_date < @toDate
and R.date >= @fromDate and R.date < @toDate
and RD.AnalystId = @vAnalystId
--group by u.userid, U.USERNAME, sa.Rsch_analystID, RD.AnalystID, w.pubno 
--group by u.userid
go

