-- LinkSources_Analysis.sql
-- 02/21/2014

/*

LinkProducts
LinkSources
RVLinkProducts
RVLinkSources
spRenderGetLinkSources
spRenderSetLinkSources
spGetLinks

*/

use Research
go

select * from LinkProducts

select * from LinkSources

select LP.*, LS.* from LinkSources LS left join LinkProducts LP on LP.ProductId = LS.ProductId
order by LP.SeqNo, LS.SeqNo

select * from RVLinkSources


exec spRenderLinkSources
go

select * from LinkSources order by SourceLaunchDate
go

select * from BeehiveViewSources order by SourceLaunchDate
go

select top 100 * from RVPortalUsage

select * from RVLinkSources order by 1

select distinct Site, SiteId from RVPortalUsage order by 1

sp_helptext spRenderLinkSources
go

sp_helptext RVLinkSources
go

sp_help LinkSources
go


use 
go

select * from SlxExternal.dbo.SCB_UNIQUE_READERS where SOURCEID = 32

-- SLX readership retrieved by SCB_GET_CONTACT_READERSHIP

-- SLX "Readership Source" picklist - which is manually populated by slx admins with source text and id

-- Link Source history - Filtered
SELECT
  UR.SourceId,
  LS.Source,
  'FirstReadDate' = CONVERT(VARCHAR(10), MIN(UR.READ_DATE), 102),
  'LastReadDate' = CONVERT(VARCHAR(10), MAX(UR.READ_DATE), 102),
  'NumReads' = COUNT(*)
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
LEFT JOIN SlxExternal.dbo.RVLinkSources LS ON UR.SourceId = LS.SourceId
GROUP BY UR.SourceId, LS.Source
ORDER BY 3

-- Link Source history - Raw
SELECT
  WU.SourceId,
  LS.Source,
  'FirstReadDate' = CONVERT(VARCHAR(10), MIN(WU.ACCESSDATE), 102),
  'LastReadDate' = CONVERT(VARCHAR(10), MAX(WU.ACCESSDATE), 102),
  'NumReads' = COUNT(*)
FROM SlxExternal.dbo.WebUsage WU
LEFT JOIN SlxExternal.dbo.RVLinkSources LS ON WU.SourceId = LS.SourceId
GROUP BY WU.SourceId, LS.Source
ORDER BY 3

-- Client, i.e. filtered, reads by Source per day - Summary(36-43) and Top Reads(32-35) editions
SELECT
  'ReadDate' = CONVERT(VARCHAR(10), UR.READ_DATE, 102),
  'Day'      = DATENAME(weekday, UR.READ_DATE),
  'SourceId' = UR.SOURCEID,
  'Source'   = LS.Source,
  'Reads'    = COUNT(*)
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
LEFT JOIN SlxExternal.dbo.RVLinkSources LS ON LS.SourceId = UR.SOURCEID
WHERE (UR.SOURCEID >= 32 OR UR.SOURCEID = 1)
  AND UR.READ_DATE >= '04/15/2014'   -- Summary Link Source Activate Date
GROUP BY
  CONVERT(VARCHAR(10), READ_DATE, 102),
  DATENAME(weekday, READ_DATE),
  UR.SOURCEID,
  LS.Source
ORDER BY UR.SOURCEID, 1
GO

-- Get Total Count by Source for a date range
SELECT
  'SourceId' = UR.SOURCEID,
  'Source'   = LS.Source,
  'Reads'    = COUNT(*)
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
LEFT JOIN SlxExternal.dbo.RVLinkSources LS ON LS.SourceId = UR.SOURCEID
WHERE (UR.SOURCEID >= 32 OR UR.SOURCEID = 1)
  AND UR.READ_DATE >= '04/15/2014'   -- Summary Link Source Activate Date
GROUP BY
  UR.SOURCEID,
  LS.Source
ORDER BY UR.SOURCEID
GO

-- Get Count by Source by week
SELECT
  'WeekStarting' = convert(varchar, DATEADD(dd, -(DATEPART(dw, UR.READ_DATE)-1), UR.READ_DATE),101),
  'SourceId' = UR.SOURCEID,
  'Source'   = LS.Source,
  'Reads'    = COUNT(*)
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
LEFT JOIN SlxExternal.dbo.RVLinkSources LS ON LS.SourceId = UR.SOURCEID
--WHERE (UR.SOURCEID >= 32 OR UR.SOURCEID = 1) AND UR.READ_DATE >= '04/15/2014'   -- Summary Link Source Activate Date
--WHERE UR.SOURCEID in (1, 36, 37, 37, 39, 40, 41, 42, 43) AND UR.READ_DATE >= '04/15/2014'   -- Summary Link Source Activate Date
  WHERE UR.SOURCEID in (36, 43)         AND UR.READ_DATE >= '06/12/2014'  -- Global vs. FanelliSummary
--WHERE UR.SOURCEID in (32, 33, 34, 35) AND UR.READ_DATE >= '04/15/2014'  -- Most Popular
GROUP BY
  DATEADD(dd, -(DATEPART(dw, UR.READ_DATE)-1), UR.READ_DATE),
  UR.SOURCEID,
  LS.Source
ORDER BY 1, 2, 4 desc
GO

-- Get Count by Source by month
SELECT
  'Year'     = year(UR.READ_DATE),
  'Month'    = month(UR.READ_DATE),
--'Month'    = DATENAME(mm, UR.READ_DATE) + ' ' + DATENAME(yy, UR.READ_DATE),
  'SourceId' = UR.SOURCEID,
  'Source'   = LS.Source,
  'Reads'    = COUNT(*)
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
LEFT JOIN SlxExternal.dbo.RVLinkSources LS ON LS.SourceId = UR.SOURCEID
--WHERE (UR.SOURCEID >= 32 OR UR.SOURCEID = 1) AND UR.READ_DATE >= '04/15/2014'   -- Summary Link Source Activate Date
--WHERE UR.SOURCEID in (1, 36, 37, 37, 39, 40, 41, 42, 43) AND UR.READ_DATE >= '04/15/2014'   -- Summary Link Source Activate Date
  WHERE UR.SOURCEID in (32, 33, 34, 35)                    AND UR.READ_DATE >= '04/15/2014'   -- Most Popular
GROUP BY
  year(UR.READ_DATE),
  month(UR.READ_DATE),
  DATENAME(mm, UR.READ_DATE) + ' ' + DATENAME(yy, UR.READ_DATE),
  UR.SOURCEID,
  LS.Source
ORDER BY 1, 2, 5 desc-- 1, 2, UR.SOURCEID
GO

-- Fanelli Edition penetration
SELECT
  'WeekStarting'     = convert(varchar, DATEADD(dd, -(DATEPART(dw, UR.READ_DATE)-1), UR.READ_DATE),101),
  'Global Ed Reads'  = SUM(CASE WHEN UR.SOURCEID = 36 THEN 1 ELSE 0 END),
  'Fanelli Ed Reads' = SUM(CASE WHEN UR.SOURCEID = 43 THEN 1 ELSE 0 END)
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
LEFT JOIN SlxExternal.dbo.RVLinkSources LS ON LS.SourceId = UR.SOURCEID
--WHERE (UR.SOURCEID >= 32 OR UR.SOURCEID = 1) AND UR.READ_DATE >= '04/15/2014'   -- Summary Link Source Activate Date
--WHERE UR.SOURCEID in (1, 36, 37, 37, 39, 40, 41, 42, 43) AND UR.READ_DATE >= '04/15/2014'   -- Summary Link Source Activate Date
  WHERE UR.SOURCEID in (36, 43)         AND UR.READ_DATE >= '06/12/2014'  -- Global vs. FanelliSummary
--WHERE UR.SOURCEID in (32, 33, 34, 35) AND UR.READ_DATE >= '04/15/2014'  -- Most Popular
GROUP BY
  DATEADD(dd, -(DATEPART(dw, UR.READ_DATE)-1), UR.READ_DATE)
ORDER BY 1
GO

SELECT top 25 UR.READ_DATE,
   'WeekNum'    = DATENAME(wk, UR.READ_DATE),
   'WeekdayNum' = DATEPART(dw, UR.READ_DATE),
   'WeekStart'  = DATEADD(dd, -(DATEPART(dw, UR.READ_DATE)-1), UR.READ_DATE),
   'WeekEnd'    = DATEADD(dd, 7-(DATEPART(dw, UR.READ_DATE)), UR.READ_DATE)
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
order by UR.READ_DATE desc







-- 04/15/2014

use Research
go


select * from LinkSources
select * from RVLinkSources

exec spRenderLinkSources

/*  SLX PRD query - SLXPRDDB\SALGX_PRD,16083  */

-- ***
-- *** SOURCE ID ANALYSIS
-- ***

use SlxExternal
go

select * from RVLinkSources

-- Raw
select * from SalesLogix.sysdba.SCB_WEB_USAGE where SOURCEID not in (select SourceId from SlxExternal.dbo.RVLinkSources)

-- Filtered
select * from SlxExternal.dbo.SCB_UNIQUE_READERS where SOURCEID not in (select SourceId from SlxExternal.dbo.RVLinkSources)

-- SCB_WEB_USAGE
SELECT
  'SourceId' = SWU.SOURCEID,
  LS.Source,
  'Total Reads' = COUNT(*),
  'Earliest AccessDate' = MIN(SWU.AccessDate),
  'Lastest AccessDate'  = MAX(SWU.AccessDate)
FROM SalesLogix.sysdba.SCB_WEB_USAGE SWU
LEFT JOIN SlxExternal.dbo.RVLinkSources LS ON LS.SourceId = SWU.SOURCEID
-- WHERE ACCESS_EMAIL_ADDR NOT LIKE '%@alliancebernstein.com' AND ACCESS_EMAIL_ADDR NOT LIKE '%@bernstein.com'
GROUP BY SWU.SOURCEID, LS.Source
--ORDER BY 4
ORDER BY 1
GO

-- SCB_USAGE_LOGSHIPPER
SELECT
  'SourceId' = SOURCEID,
  'Source' =
    CASE ISNULL(SOURCEID, -1)
      WHEN -1 THEN 'Analyst Blast 1.0' -- Analyst Blast, Morning Summary, Cart
      WHEN  0 THEN 'Analyst Blast'
      WHEN  1 THEN 'Morning Summary'
      WHEN  2 THEN 'Cart'
      WHEN  3 THEN 'Embed Link'
      WHEN  4 THEN 'Sales Alert'
      WHEN 10 THEN 'BR.com - *** TO DO - Demo'
      WHEN 11 THEN 'BR.com - Investor Themes'
      WHEN 20 THEN 'Cube - 90000001.pdf (help)'
      WHEN 21 THEN 'Cube - Streamer'
      WHEN 30 THEN 'iPad - *** TO DO Event Replay (MP3 or PDF?)'
      WHEN 31 THEN 'iPhone'
      ELSE 'Other'
    END,
  'Total Reads' = COUNT(*),
  'Earliest AccessDate' = MIN(USAGETIME),
  'Lastest AccessDate'  = MAX(USAGETIME)
FROM SalesLogix.sysdba.SCB_USAGE_LOGSHIPPER
-- WHERE ACCESS_EMAIL_ADDR NOT LIKE '%@alliancebernstein.com' AND ACCESS_EMAIL_ADDR NOT LIKE '%@bernstein.com'
GROUP BY SOURCEID
ORDER BY 1
GO


-- As of 02/14/2012, there were 327,792 rows logged with null SOURCEID with ACCESSDATE range from 2006-09-15 to 2007-10-05
select * from sysdba.scb_web_usage where SOURCEID is null order by ACCESSDATE
select top 500 * from sysdba.scb_web_usage where SOURCEID = 1 order by ACCESSDATE

select top 1000 SCB_WEB_USAGEID
 ,CONTACTID
 ,SOURCEID
 ,ACCESSDATE
 ,CONTENT_SOURCE
 ,USER_AGENT
 ,ACCESS_EMAIL_ADDR
from SalesLogix.sysdba.SCB_WEB_USAGE
order by ACCESSDATE desc

/* schema additions

CONTENT_SOURCE
USER_AGENT
INFO

*/

--
--Test Event Replays logging from BR.com and iPad Sources
SELECT * FROM   sysdba.SCB_USAGE_LOGSHIPPER SWL
where sourceid in (10, 30)
and access_email_addr in ('naveen.harjani@alliancebernstein.com', 'frank.fusillo@alliancebernstein.com')
and USAGETIME > '2012-03-21 14:08:44.000'
ORDER BY SWL.USAGETIME DESC

select top 30000 * from SalesLogix.sysdba.SCB_WEB_USAGE where PUBNO = 99999999 order by ACCESSDATE desc

select top 500 * from SalesLogix.sysdba.SCB_WEB_USAGE


/*  SLX QA query - AC03AMA0848\SALGX_DEV1,16073  */
use SLX_QA
go

select top 500 * from sysdba.SCB_USAGE_LOGSHIPPER order by USAGETIME desc

select top 500 * from SalesLogix.sysdba.SCB_USAGE_LOGSHIPPER order by USAGETIME desc

select distinct SOURCEID from SalesLogix.sysdba.SCB_USAGE_LOGSHIPPER

select count(*) from sysdba.SCB_USAGE_LOGSHIPPER

-- *** SEE _contentusage.sql

-- CONTENT_ID, SOURCEID, Analyst[Host], Sector info
SELECT
  -- Source
  SUL.SourceId,
  (CASE
    WHEN SUL.SOURCEID = '10' THEN 'BR.com'
    WHEN SUL.SOURCEID = '21' THEN 'Cube Streamer'
    WHEN SUL.SOURCEID = '30' THEN 'iPad'
    WHEN SUL.SOURCEID = '31' THEN 'iPhone'
    ELSE 'Other'
  END) AS Source,
  -- Content (parsed)
  SUBSTRING(SUL.Content_Source, 14, 100),
  -- Log
  SUL.Content_Type, SUL.Content_Source,
  SUL.Access_Email_Addr, SUL.UsageTime, SUL.User_Host, SUL.User_Agent, SUL.FileFound, SUL.Source_Internal,
  SUL.UsageId, SUL.ContactId, SUL.Content_Id,
  -- Event
  E.Event_Type, E.Subject, E.Name, E.Location, E.Event_Datetime,
  -- Contact
  CN.Account, CN.LastName, CN.FirstName --CN.Email,
  -- Host
--  UI.Title, UI.UserName, UI.Region, UI.Division, UI.Email, ES.AnalystId
  -- Sector
--   S.Sector_Name, ES.SectorId
FROM sysdba.SCB_USAGE_LOGSHIPPER SUL
LEFT JOIN Saleslogix.sysdba.SCB_EVENT E ON E.SCB_EventId = SUL.Content_Id
LEFT JOIN Saleslogix.sysdba.CONTACT CN ON CN.ContactId = SUL.ContactId
--LEFT JOIN Saleslogix.sysdba.SCB_EVENT_SECTOR ES ON ES.SCB_EventId = E.SCB_EventId
--LEFT JOIN Saleslogix.sysdba.USERINFO UI ON UI.USERID = ES.AnalystId
--LEFT JOIN Saleslogix.sysdba.INF_SECTORS S ON S.INF_SECTORSID = ES.SECTORID
WHERE SUL.CreateDate >= '01/10/2012'
  --AND SWL.SourceId IN (10, 30, 31)
ORDER BY 1, SUL.CreateDate DESC

SELECT TOP 5000 SUL.SourceId,
  SUBSTRING(SUL.Content_Source, 14, 100) AS Content,
  SUL.Content_Type, SUL.UsageTime, SUL.Access_Email_Addr, SUL.STATUS, SUL.FileFound, SUL.SERVER_NAME, SUL.Source_Internal,
  E.Event_Type, E.Name, CN.Account,
  SUL.User_Host
FROM sysdba.SCB_USAGE_LOGSHIPPER SUL
LEFT JOIN Saleslogix.sysdba.SCB_EVENT E ON E.SCB_EventId = SUL.Content_Id
LEFT JOIN Saleslogix.sysdba.CONTACT CN ON CN.ContactId = SUL.ContactId
ORDER BY SUL.CreateDate DESC

/*
SELECT TOP 10 * FROM sysdba.SCB_USAGE_LOGSHIPPER SUL
SELECT TOP 50 * FROM sysdba.CONTACT where ContactId = 'C6UJ9A000Z55'                --Get Contact info
SELECT TOP 50 * FROM sysdba.SCB_EVENT where scb_eventId = 'Q6UJ9A4MZ4GR'            --Get Event info
SELECT TOP 50 * FROM sysdba.SCB_EVENT_SECTOR  where scb_eventId = 'Q6UJ9A4MZ4GR'    --Get Sector and Analyst info for an Event
SELECT TOP 50 * FROM sysdba.USERINFO WHERE USERID = 'U6UJ9A00002A'                  --Get Analyst info detail
SELECT TOP 50 * FROM sysdba.INF_SECTORS WHERE INF_SECTORSID = 'Q6UJ9A0001ZL'        --Get Sector info detail
SELECT TOP 50 * FROM sysdba.INF_INDUSTRIES WHERE INF_INDUSTRIESID = 'Q6UJ9A00026D'  --Get Industry info detail
SELECT TOP 50 * FROM sysdba.SCB_EVENT_MANAGER WHERE SCB_EVENTID = 'Q6UJ9A4MZ4GR'    --Get Event Manager info
SELECT TOP 50 * FROM sysdba.SV_EVENT  where eventId = 'Q6UJ9A4MZ4GR'                --Get Event info [same as SCB_EVENT]
*/
