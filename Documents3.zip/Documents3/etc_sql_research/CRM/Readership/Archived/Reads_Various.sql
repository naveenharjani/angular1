-- 06/08/2011

-- 1) Reads Per Report
-- 2) Readership by Num Accounts Per Tier for a specified product e.g. All, Analyst Blast---'
-- 3) Readership by Num Accounts and Num Contacts

--Total_Readership_By_PubNo_Source_Acct.sql
--SLX PRODUCTION: SLXPRDDB\SALGX_PRD,16083
--This query takes about 30 seconds to run.

USE SlxExternal
GO

----------------------------------------------------------------------------------------------------
--This is a Published Date Filters, not a Read Date
DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)

SET @vSinceDate = '01/01/2009'
SET @vUntilDate = getdate()

SET NOCOUNT ON
----------------------------------------------------------------------------------------------------

-- Get the Absolute Report Usage Reads data in a Month
DECLARE	@AbsoluteReadsInaMonth TABLE 
  (
   PubDate                  VARCHAR(20),
   PubNo                    INT,
   Title                    VARCHAR(255),
   DocType                  VARCHAR(50),
   DocTypeId                INT,
   AnalystLast              VARCHAR(60),
   SourceId                 INT,
   ReadDate                 datetime,
   ContactID                VARCHAR(100),
   AccountID                VARCHAR(100),
   AccountTier              VARCHAR(30),
   ReadMonthText            VARCHAR(30), 
   ReadYear                 VARCHAR(4), 
   ReadMonth                VARCHAR(4)
   )

INSERT	@AbsoluteReadsInaMonth
    SELECT distinct
		   CONVERT( varchar(10), RD.Date, 101),
		   UR.PUBNO, RD.Title,
           TYP.DocType, RD.DocTypeId,
           A.Last,
		   UR.SOURCEID,
           UR.READ_DATE,  UR.CONTACTID, CN.AccountId,
           AE.Tier, 
           DATENAME(month, UR.READ_DATE) + '-' + DATENAME(yy, UR.READ_DATE) AS ReadMonthText,
           CONVERT(varchar, DATEPART(yy, UR.READ_DATE)) AS ReadYear,
           Right('00' + CONVERT(varchar(2), DATEPART(mm, UR.READ_DATE)), 2) AS ReadMonth
    FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
    INNER JOIN SlxExternal.dbo.RVDocuments RD ON RD.DocId = UR.PubNo
    INNER JOIN SlxExternal.dbo.RVTypes TYP ON TYP.DocTypeId = RD.DocTypeId
    INNER JOIN  SlxExternal.dbo.RVDocAnalysts A on A.docid = RD.docid
          and A.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = A.DocId)
	INNER JOIN Saleslogix.sysdba.contact CN ON CN.ContactId = UR.ContactId
	INNER JOIN Saleslogix.sysdba.inf_account_ext AE ON AE.AccountId = CN.AccountId
	WHERE RD.Date  BETWEEN @vSinceDate AND @vUntilDate
--    WHERE UR.READ_DATE BETWEEN @vSinceDate AND @vUntilDate
	ORDER BY PubNo desc

--SELECT * FROM @AbsoluteReadsInaMonth
--WHERE pubno = 79656
--ORDER BY PubNo desc
----------------------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------------------
PRINT '---------------------------------------------------------------------'
PRINT '---Report I: Get Raw Usage Data at PubNo level e.g. Date PubNo, Reads By Source---'
PRINT '---------------------------------------------------------------------'
--Read Usage Reports:
--1>. For Analyst Blast: 
--Get Date PubNo, Reads for each month from Jan-09 till date
SELECT PubDate, PubNo, Title, DocType, AnalystLast AS [Last],
		Count(*)										  AS [TotalReads],
		SUM(CASE WHEN SourceId =  0 THEN 1 ELSE 0 END)    AS [Blast],
		SUM(CASE WHEN SourceId =  1 THEN 1 ELSE 0 END)    AS [Summary],
		SUM(CASE WHEN SourceId =  2 THEN 1 ELSE 0 END)    AS [Cart],
		SUM(CASE WHEN SourceId = 10 THEN 1 ELSE 0 END)    AS [BR.com],
		SUM(CASE WHEN SourceId = 3 THEN 1 ELSE 0 END)     AS [Embed],
		SUM(CASE WHEN SourceId = 4 THEN 1 ELSE 0 END)     AS [Sales]
FROM @AbsoluteReadsInaMonth 
GROUP BY PubNo, Title, PubDate, DocType, AnalystLast
ORDER BY PubNo desc
----------------------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------------------
PRINT '---------------------------------------------------------------------'
PRINT '---Report II: Readership by Num Accounts Per Tier for a specified product e.g. All, Analyst Blast---'
PRINT '---------------------------------------------------------------------'
--2>. For Analyst Blast, Summary, BR.com
--	Get Read Month  TotalReads    T1 T2 T3 T4 [Tier Accounts]
SELECT ReadMonthText AS [MonthReads], 'All' AS [Source],
		Count(*)														AS [TotalTiers],
		SUM(CASE WHEN AccountTier = 'TIER 1' THEN 1 ELSE 0 END)			AS [Tier1],
		SUM(CASE WHEN AccountTier = 'TIER 2' THEN 1 ELSE 0 END)			AS [Tier2],
		SUM(CASE WHEN AccountTier = 'TIER 3' THEN 1 ELSE 0 END)			AS [Tier3],
		SUM(CASE WHEN AccountTier = 'TIER 4' THEN 1 ELSE 0 END)			AS [Tier4],
		SUM(CASE WHEN AccountTier = 'TIER 5' THEN 1 ELSE 0 END)			AS [Tier5],
		SUM(CASE WHEN ISNULL(AccountTier,'') = '' THEN 1 ELSE 0 END)	AS [NoTier],
		ReadYear, ReadMonth
FROM @AbsoluteReadsInaMonth
GROUP BY ReadYear, ReadMonth, ReadMonthText

SELECT ReadMonthText AS [MonthReads], 'Analyst Blast' AS [Source],
		Count(*)														AS [TotalTiers],
		SUM(CASE WHEN AccountTier = 'TIER 1' THEN 1 ELSE 0 END)			AS [Tier1],
		SUM(CASE WHEN AccountTier = 'TIER 2' THEN 1 ELSE 0 END)			AS [Tier2],
		SUM(CASE WHEN AccountTier = 'TIER 3' THEN 1 ELSE 0 END)			AS [Tier3],
		SUM(CASE WHEN AccountTier = 'TIER 4' THEN 1 ELSE 0 END)			AS [Tier4],
		SUM(CASE WHEN AccountTier = 'TIER 5' THEN 1 ELSE 0 END)			AS [Tier5],
		SUM(CASE WHEN ISNULL(AccountTier,'') = '' THEN 1 ELSE 0 END)	AS [NoTier],
		ReadYear, ReadMonth
FROM @AbsoluteReadsInaMonth
WHERE SourceId = 1  --AnalystBlast
GROUP BY ReadYear, ReadMonth, ReadMonthText

SELECT ReadMonthText AS [MonthReads], 'Summary' AS [Source],
		Count(*)														AS [TotalTiers],
		SUM(CASE WHEN AccountTier = 'TIER 1' THEN 1 ELSE 0 END)			AS [Tier1],
		SUM(CASE WHEN AccountTier = 'TIER 2' THEN 1 ELSE 0 END)			AS [Tier2],
		SUM(CASE WHEN AccountTier = 'TIER 3' THEN 1 ELSE 0 END)			AS [Tier3],
		SUM(CASE WHEN AccountTier = 'TIER 4' THEN 1 ELSE 0 END)			AS [Tier4],
		SUM(CASE WHEN AccountTier = 'TIER 5' THEN 1 ELSE 0 END)			AS [Tier5],
		SUM(CASE WHEN ISNULL(AccountTier,'') = '' THEN 1 ELSE 0 END)	AS [NoTier],
		ReadYear, ReadMonth
FROM @AbsoluteReadsInaMonth
WHERE SourceId = 2  --Summary
GROUP BY ReadYear, ReadMonth, ReadMonthText

SELECT ReadMonthText AS [MonthReads], 'BR.com' AS [Source],
		Count(*)														AS [TotalTiers],
		SUM(CASE WHEN AccountTier = 'TIER 1' THEN 1 ELSE 0 END)			AS [Tier1],
		SUM(CASE WHEN AccountTier = 'TIER 2' THEN 1 ELSE 0 END)			AS [Tier2],
		SUM(CASE WHEN AccountTier = 'TIER 3' THEN 1 ELSE 0 END)			AS [Tier3],
		SUM(CASE WHEN AccountTier = 'TIER 4' THEN 1 ELSE 0 END)			AS [Tier4],
		SUM(CASE WHEN AccountTier = 'TIER 5' THEN 1 ELSE 0 END)			AS [Tier5],
		SUM(CASE WHEN ISNULL(AccountTier,'') = '' THEN 1 ELSE 0 END)	AS [NoTier],
		ReadYear, ReadMonth
FROM @AbsoluteReadsInaMonth
WHERE SourceId = 10  --BR.com
GROUP BY ReadYear, ReadMonth, ReadMonthText
----------------------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------------------
PRINT '---------------------------------------------------------------------'
PRINT '---Report III: Get Readership by Account/Contact---'
PRINT '---------------------------------------------------------------------'
--3>. For each source
--	Get Read Month, TotalReads, NumAccounts read in that month
SELECT ReadMonthText AS [MonthReads],
		Count(*)					AS [TotalReads],
        Count(distinct AccountID)	AS [NumAccounts],
        Count(distinct ContactID)	AS [NumContacts],
		ReadYear, ReadMonth
FROM @AbsoluteReadsInaMonth
GROUP BY ReadYear, ReadMonth, ReadMonthText
----------------------------------------------------------------------------------------------------

/* 
-- Diagnostics
sp_helptext SCB_UNIQUE_READERS

select * from SlxExternal.dbo.RVDocuments D
      INNER JOIN  SlxExternal.dbo.RVDocAnalysts A on A.docid = D.docid
      and A.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = A.DocId)
order by D.docid desc

select * from SlxExternal.dbo.RVDocAnalysts 

SELECT * FROM SlxExternal.dbo.RVDocuments Where DocId = 79656
SELECT TOP 20 * FROM SlxExternal.dbo.SCB_UNIQUE_READERS
Fields: PUBNO       CONTACTID    READ_DATE               SOURCEID

select distinct Tier from Saleslogix.sysdba.inf_account_ext 
Values: TIER 2, TIER 4, NULL, TIER 3, , TIER 1, TIER 5

select accountid, Tier, paneurotier, asiatier
from Saleslogix.sysdba.inf_account_ext
where accountid IN (Select accountid from Saleslogix.sysdba.account where type = 'CLIENT')

select * from Saleslogix.sysdba.account    --account, accountid
where type = 'CLIENT'

select * from Saleslogix.sysdba.contact   -- contactid, accountid
select * from SlxExternal.dbo.RVDocuments
select * from SlxExternal.dbo.RVTypes
*/