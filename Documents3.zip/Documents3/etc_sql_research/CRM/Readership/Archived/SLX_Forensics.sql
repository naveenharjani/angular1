--SLX PRD query - SLXPRDDB\SALGX_PRD,16083

--Latest reads by "gfigroup"
SELECT TOP 1000 * FROM sysdba.SCB_WEB_USAGE 
WHERE ACCESS_EMAIL_ADDR LIKE '%gfigroup%'
ORDER BY ACCESSDATE desc
--No Reads found matching gfigroup

--Latest "Unrecognized email" conditions
SELECT TOP 1000 * FROM sysdba.SCB_WEB_USAGE 
WHERE STATUS = 'F'
ORDER BY ACCESSDATE desc




SELECT TOP 1000 * FROM sysdba.SCB_WEB_USAGE 
WHERE DOMAIN_NAME LIKE '216.203%'
ORDER BY ACCESSDATE desc
--No Reads found matching gfigroup

SELECT TOP 1000 * FROM sysdba.SCB_WEB_USAGE 
WHERE ACCESS_EMAIL_ADDR LIKE '%kirjner%'
ORDER BY ACCESSDATE desc


SELECT TOP 1000 S.SOURCEID, S.PUBNO, SUBSTRING(S.DOMAIN_NAME, 1, 15), RVD.Title, * FROM sysdba.SCB_WEB_USAGE S
JOIN slxexternal..RVDocuments RVD on RVD.DocId = S.PUBNO
WHERE ACCESS_EMAIL_ADDR LIKE '%kirjner%'
AND SOURCE_INTERNAL <> 'T'
ORDER BY ACCESSDATE desc

select * from RVDocuments
