--Ipad_Reads.sql
USE SALESLOGIX
GO
SET NOCOUNT ON
GO

/* Database: SLX PRODUCTION - SLXPRDDB\SALGX_PRD,16083 */

/*  Read Start Date = '09/13/2011'
	SourceId = 30, Source = "iPad"
    SourceId = 31, Source = "iPhone" */


--I. Get Unique Client Reads - FILTERED READS 
--Get the list of email address with the account names accessing iPad apps starting from 09/13/2011
SELECT distinct
	UR.PubNo, UR.Read_Date, 
	CN.Email, CN.Account, AE.Tier,
	UR.SourceId,
	(CASE WHEN UR.SourceId = '30' THEN 'iPad' 
	      WHEN UR.SourceId = '31' THEN 'iPhone' 
	      ELSE 'Other' END)				AS [Source],
	'Client Mobile Reads [Filtered]'	AS [Type]
	--UR.CONTACTID, CN.AccountId
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
INNER JOIN Saleslogix.sysdba.contact CN ON CN.ContactId = UR.ContactId
INNER JOIN Saleslogix.sysdba.inf_account_ext AE ON AE.AccountId = CN.AccountId
WHERE UR.Read_Date BETWEEN '09/13/2011' AND getdate()
  AND UR.SourceId IN (30, 31)
ORDER BY UR.Read_Date DESC


--II. Get Raw Usage Reads - NOT FILTERED READS
--Get the list of email address with the account names accessing iPad apps starting from 09/13/2011
SELECT SWU.PubNo, SWU.AccessDate, SWU.Access_Email_Addr, 
	CN.Email, CN.Account, AE.Tier,
	SWU.SourceId, 
	(CASE WHEN SWU.SOURCEID = '30' THEN 'iPad' 
          WHEN SWU.SOURCEID = '31' THEN 'iPhone' 
	      ELSE 'Other' END)				AS [Source],
	'Raw Mobile Reads [Not Filtered]'	AS [Type]
	--CN.AccountId, SWU.ContactId
FROM    sysdba. SCB_WEB_USAGE SWU
INNER JOIN Saleslogix.sysdba.contact CN ON CN.ContactId = SWU.ContactId
INNER JOIN Saleslogix.sysdba.inf_account_ext AE ON AE.AccountId = CN.AccountId
WHERE SWU.SourceId IN (30, 31)
  AND SWU.AccessDate >= '09/13/2011'
ORDER BY SWU.AccessDate DESC



--III. Get the "Reads per day" Count for clients reads - FILTERED READS
--     Get the [NumClientReads] and [NumClientContacts]
SELECT CONVERT(VARCHAR(10), Read_Date, 102)			    AS [Read Date],
	   DATENAME(weekday, Read_Date)					    AS [Day],
	   SUM(CASE WHEN SourceId =  30 THEN 1 ELSE 0 END)  AS [iPad],
	   SUM(CASE WHEN SourceId =  31 THEN 1 ELSE 0 END)  AS [iPhone],
       Count(*)										    AS [NumClientReads],
       Count(DISTINCT ContactId)					    AS [NumClientContacts],
	   'Client Mobile Reads per day [Filtered]'		    AS [Type]
FROM SlxExternal.dbo.SCB_UNIQUE_READERS
WHERE Read_Date >= '09/13/2011'
  AND SourceId IN (30, 31)
GROUP BY
  CONVERT(VARCHAR(10), Read_Date, 102),
  DATENAME(weekday, Read_Date)
ORDER BY 1


--IV. Get the "Reads per day" Count for internal Bernstein reads - NOT FILTERED READS
--    Get the [NumBernsteinReads] and [NumBernsteinContacts]
SELECT CONVERT(varchar(10), SWU.AccessDate, 102)		AS [Read Date],
	   DATENAME(weekday, SWU.AccessDate)				AS [Day],
	   SUM(CASE WHEN SourceId =  30 THEN 1 ELSE 0 END)  AS [iPad],
	   SUM(CASE WHEN SourceId =  31 THEN 1 ELSE 0 END)  AS [iPhone],
       Count(*)										    AS [NumBernsteinReads],
       Count(DISTINCT ContactId)					    AS [NumBernsteinContacts],
	   'Bernstein Mobile Reads per day [Not Filtered]'	AS [Type]
FROM sysdba. SCB_WEB_USAGE SWU
WHERE SWU.AccessDate >= '09/13/2011'
  AND SWU.SourceId IN (30, 31)
  AND SWU.Access_Email_Addr  LIKE '%@bernstein.com'
GROUP BY
  CONVERT(VARCHAR(10), SWU.AccessDate, 102),
  DATENAME(weekday, SWU.AccessDate)
ORDER BY 1


--V. Get the Total [NumUsers] & [TotalReads] for clients [FILTERED READS] and Bernstein [NOT FILTERED READS] reads
SELECT 'Client - Mobile [Filtered]'						AS [UserType],
       Count(DISTINCT ContactId)					    AS [NumUsers],
       Count(*)										    AS [TotalReads],
	   SUM(CASE WHEN SourceId =  30 THEN 1 ELSE 0 END)  AS [iPad],
	   SUM(CASE WHEN SourceId =  31 THEN 1 ELSE 0 END)  AS [iPhone]
FROM SlxExternal.dbo.SCB_UNIQUE_READERS
WHERE Read_Date >= '09/13/2011'
  AND SourceId IN (30, 31)
UNION

-- NON-FILTERED READS BY USER BASE
SELECT 'Bernstein Staff'				                AS [UserType],
       Count(DISTINCT ContactId)						AS [NumUsers],
       Count(*)										    AS [TotalReads],
       SUM(CASE WHEN SourceId =  30 THEN 1 ELSE 0 END)  AS [iPad],
       SUM(CASE WHEN SourceId =  31 THEN 1 ELSE 0 END)  AS [iPhone]
FROM sysdba. SCB_WEB_USAGE SWU
WHERE SWU.AccessDate >= '09/13/2011'
  AND SWU.SourceId IN (30, 31)
  AND SWU.Access_Email_Addr  LIKE '%@bernstein.com'
UNION
SELECT 'Bernstein Clients'								AS [UserType],
       Count(DISTINCT ContactId)					    AS [NumUsers],
       Count(*)										    AS [TotalReads],
       SUM(CASE WHEN SourceId =  30 THEN 1 ELSE 0 END)  AS [iPad],
       SUM(CASE WHEN SourceId =  31 THEN 1 ELSE 0 END)  AS [iPhone]
FROM sysdba. SCB_WEB_USAGE SWU
WHERE SWU.AccessDate >= '09/13/2011'
  AND SWU.SourceId IN (30, 31)
  AND SWU.Access_Email_Addr  NOT LIKE '%@bernstein.com'

--V1. Get Total BR.com Reads info #Users/Reads
SELECT 'Bernstein Clients'								AS [UserType],
       Count(DISTINCT ContactId)					    AS [NumUsers],
       Count(*)										    AS [TotalBRReads]
FROM sysdba. SCB_WEB_USAGE SWU
WHERE SWU.AccessDate >= '09/13/2011'
  AND SWU.SourceId IN (10)
  AND SWU.Access_Email_Addr  NOT LIKE '%@bernstein.com'

/* 
select top 10 * from Saleslogix.sysdba.contact
select top 10 * from Saleslogix.sysdba.inf_account_ext
select top 10 * FROM SlxExternal.dbo.SCB_UNIQUE_READERS

SELECT SWU.* FROM sysdba. SCB_WEB_USAGE SWU
WHERE SWU.ACCESSDATE >= '09/13/2011' AND SWU.SOURCEID IN (30, 31) AND SWU.ACCESS_EMAIL_ADDR  LIKE '%@bernstein.com'
*/