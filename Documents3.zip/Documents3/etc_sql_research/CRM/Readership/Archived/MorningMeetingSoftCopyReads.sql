-- MorningMeetingSoftCopyReads.sql
-- 12/18/2012

--SLX PRODUCTION: SLXPRDDB\SALGX_PRD,16083

/*

WiFi was installed on 1345/15 on 12/3/2012.  Did iPad usage increase during morning meeting?

Base query of raw @bernstein.com reads for mobile and BR.com.  Add filters:
* Reads during US morning meeting
* Summary
* Detail

*/

-- Filter @bernstein.com RAW reads during US Morning Meetings [7:30-8:00am] - for Mobile and BR.com reads only
SELECT
  SWU.PUBNO,
  SWU.ACCESSDATE AS ACCESSDATE_Orig,
  CAST(CONVERT(char(11), SWU.ACCESSDATE, 113) as datetime) AS ACCESSDATE,   --Remove time component from 'datetime' datatype
  SUBSTRING(SWU.ACCESS_EMAIL_ADDR, 1, 30)                  AS 'ACCESS_EMAIL_ADDR',
  SUBSTRING(C.ACCOUNT, 1, 30)                              AS 'ACCOUNT',
  SUBSTRING(D.Title, 1, 30)                                AS 'Title',
  SWU.SOURCEID,
  CASE SWU.SOURCEID
    WHEN 10 THEN 'BR.com'
    WHEN 11 THEN 'BR.com - Investor Themes'
    WHEN 30 THEN 'iPad'
    WHEN 31 THEN 'iPhone'
    ELSE 'Other'
  END AS SOURCE
INTO #MobileBernsteinReads
FROM sysdba.SCB_WEB_USAGE SWU
INNER JOIN sysdba.CONTACT C on C.CONTACTID = SWU.CONTACTID
INNER JOIN SlxExternal.dbo.RVDocuments D ON D.docid = SWU.PUBNO
WHERE SWU.SourceId IN (10, 11, 30, 31)                    --Mobile/BR Reads
  AND SWU.ACCESS_EMAIL_ADDR LIKE '%@bernstein.com'        --Filter by Bernstein Reads
  AND SWU.ACCESSDATE BETWEEN '11/01/2012' AND getdate()   --Filter by date range
  --Reads during US Morning Meetings
  AND SWU.ACCESSDATE - CAST(FLOOR(CAST(SWU.ACCESSDATE AS float)) AS datetime) >= '06:30'  -- Strips the date/time value of its fractional component
  AND SWU.ACCESSDATE - CAST(FLOOR(CAST(SWU.ACCESSDATE AS float)) AS datetime) <= '08:15'
  --AND (
  --     ( DATEPART(HOUR, SWU.ACCESSDATE) = 6 AND DATEPART(minute, SWU.ACCESSDATE) >= 30)
  --     OR
  --     ( DATEPART(HOUR, SWU.ACCESSDATE) = 8 AND DATEPART(minute, SWU.ACCESSDATE) <= 15)
  --    )
ORDER BY SWU.ACCESSDATE DESC
GO

--SELECT * FROM #MobileBernsteinReads
--GO

-- *** SUMMARY ***

-- Monthly reads
SELECT
  'Monthly'                                                AS 'Period ',
  YEAR(ACCESSDATE)                                         AS 'Year',
  MONTH(ACCESSDATE)                                        AS 'Month',
  SUM(CASE WHEN SOURCEID IN (30, 31) THEN 1 ELSE 0 END)    AS 'Mobile',
  SUM(CASE WHEN SOURCEID IN (10, 11) THEN 1 ELSE 0 END)    AS 'BR.com'
FROM #MobileBernsteinReads
GROUP BY YEAR(ACCESSDATE), MONTH(ACCESSDATE)
ORDER BY 2 DESC, 3 DESC
GO

-- Weekly reads
SELECT
  'Weekly'                                                 AS 'Period ',
  YEAR(ACCESSDATE)                                         AS 'Year',
  MONTH(ACCESSDATE)                                        AS 'Month',
  DATEPART(wk, ACCESSDATE)                                 AS 'Week',
  DATEADD(dd, 7-(DATEPART(dw, ACCESSDATE)), ACCESSDATE)    AS 'WeekEnding',
  SUM(CASE WHEN SOURCEID IN (30, 31) THEN 1 ELSE 0 END)    AS 'Mobile',
  SUM(CASE WHEN SOURCEID IN (10, 11) THEN 1 ELSE 0 END)    AS 'BR.com'
FROM #MobileBernsteinReads
GROUP BY YEAR(ACCESSDATE), MONTH(ACCESSDATE), DATEPART(wk, ACCESSDATE), DATEADD(dd, 7-(DATEPART(dw, ACCESSDATE)), ACCESSDATE)
ORDER BY 2 DESC, 3 DESC, 4 DESC
GO

-- Daily Reads
SELECT
  'Daily'                                                  AS 'Period ',
  ACCESSDATE                                               AS 'Date',
  DATENAME(weekday, ACCESSDATE)                            AS 'Day',
  SUM(CASE WHEN SOURCEID IN (30, 31) THEN 1 ELSE 0 END)    AS 'Mobile',
  SUM(CASE WHEN SOURCEID IN (10, 11) THEN 1 ELSE 0 END)    AS 'BR.com'
FROM #MobileBernsteinReads
GROUP BY ACCESSDATE
ORDER BY ACCESSDATE DESC
GO

-- *** USER DETAIL ***

-- Gross
SELECT
  TOP 20
  'Gross'                                                  AS 'Period ',
  SUBSTRING(ACCESS_EMAIL_ADDR, 1, 30)                      AS 'ACCESS_EMAIL_ADDR',
  SUM(CASE WHEN SOURCEID IN (30, 31) THEN 1 ELSE 0 END)    AS 'Mobile',
  SUM(CASE WHEN SOURCEID IN (10, 11) THEN 1 ELSE 0 END)    AS 'BR.com'
FROM #MobileBernsteinReads
GROUP BY ACCESS_EMAIL_ADDR
ORDER BY 3 DESC, 4 DESC
GO

-- Monthly
SELECT
  TOP 20
  'Monthly'                                                AS 'Period ',
  YEAR(ACCESSDATE)                                         AS 'Year',
  MONTH(ACCESSDATE)                                        AS 'Month',
  SUBSTRING(ACCESS_EMAIL_ADDR, 1, 30)                      AS 'ACCESS_EMAIL_ADDR',
  SUM(case when SOURCEID IN (30, 31) then 1 else 0 end)    AS 'Mobile',
  SUM(case when SOURCEID IN (10, 11) then 1 else 0 end)    AS 'BR.com'
FROM #MobileBernsteinReads
GROUP BY YEAR(ACCESSDATE), MONTH(ACCESSDATE), ACCESS_EMAIL_ADDR
ORDER BY 2 DESC, 3 DESC, 5 DESC, 6 DESC
GO

-- Daily
SELECT
  TOP 20
  'Daily'                                                  AS 'Period ',
  ACCESSDATE                                               AS 'Date',
  DATENAME(weekday, ACCESSDATE)                            AS 'Day',
  SUBSTRING(ACCESS_EMAIL_ADDR, 1, 30)                      AS 'ACCESS_EMAIL_ADDR',
  SUM(CASE WHEN SOURCEID IN (30, 31) THEN 1 ELSE 0 END)    AS 'Mobile',
  SUM(CASE WHEN SOURCEID IN (10, 11) THEN 1 ELSE 0 END)    AS 'BR.com'
FROM #MobileBernsteinReads
GROUP BY ACCESSDATE, ACCESS_EMAIL_ADDR
ORDER BY 2 DESC, 3 DESC, 5 DESC, 6 DESC
GO

DROP TABLE #MobileBernsteinReads
GO
