-- Metrics.sql

-- Research..spRptAnalystMetrics
----------------------------------------------------------------------------------------------------
--Database: Research DEV [ACX3AMA0510\SCBIS_DEV6]
--Stored Procedure: [spRptAnalystMetrics] 
----------------------------------------------------------------------------------------------------
USE Research
GO

DECLARE @vStartDate		VARCHAR(12)
DECLARE @vEndDate		VARCHAR(12)
DECLARE @vRegionCode	  	VARCHAR(12)

SET @vStartDate = '01/01/2009'
SET @vEndDate = '06/30/2009'
--SET @vStartDate = '07/01/2007'
--SET @vEndDate = '12/31/2007'
SET @vRegionCode = 'US'  --Region param values: US, UK,  ALL [This would include all Author Regions]

exec [spRptAnalystMetrics] @vStartDate, @vEndDate--, @vRegionCode

--@vRegionCode is optional parameter, defaults to ALL
--exec [spRptAnalystMetrics] @vStartDate, @vEndDate

-- Visibility.xls
-- Calls SLX sp get_Analyst_Matrix to get total reads per analyst (link_readership)
--  Filtered clicks for Calls with publication between start and end date
--  Filtered clicks are attributes reads to co-authors

-- Calls Research database dynamic SQL to get Num Calls in date range per analyst.
-- Excel calculates avg Calls in period.
-- Excel calculates avg reads per call

use SlxExternal
go

---- US analyst data
--exec sysdba.get_Analyst_Matrix  '01/01/2008', '12/31/2008', 'New York', 'Senior Analyst'
--exec sysdba.get_Analyst_Matrix  '01/01/2008', '10/31/2008', 'New York', 'Senior Analyst'
--exec sysdba.get_Analyst_Matrix  '10/31/2007', '10/31/2008', 'New York', 'Senior Analyst'
--
---- Pan-Euro analyst data
--exec sysdba.get_Analyst_Matrix  '1/1/2008', '10/1/2008', 'London', 'London Senior Analyst'


-- Visibility.xls
-- Calls SLX sp get_Analyst_Matrix to get total reads per analyst (link_readership)
--  Filtered clicks for Calls with publication between start and end date
--  Filtered clicks are attributes reads to co-authors

-- Calls Research database dynamic SQL to get Num Calls in date range per analyst.
-- Excel calculates avg Calls in period.
-- Excel calculates avg reads per call

use SlxExternal
go

----------------------------------------------------------------------------------------------------
DECLARE @vStartDate		  VARCHAR(12)
DECLARE @vEndDate		    VARCHAR(12)
DECLARE @vAsOfDate		  VARCHAR(12)
--DECLARE @iAnalystId		  INT

DECLARE @vAvgDaysInaMonth  VARCHAR(12)
DECLARE @vNumMonths        VARCHAR(12)

SET @vStartDate = '01/01/2008'
SET @vEndDate = '12/31/2008'
SET @vAsOfDate = '01/31/2009'
--SET @iAnalystId = 150         --A.M. (Toni) Sacconaghi, Jr.

--Get the Avg Days in a Month
SET @vAvgDaysInaMonth = CONVERT( DECIMAL(10,2),
                                 CONVERT( DECIMAL(10,4), (365))/CONVERT( DECIMAL(10,4), (12))
                                )      
--Get the Number of Months as per the date range
SET @vNumMonths = CONVERT( DECIMAL(10,2),
                                   CONVERT( DECIMAL(10,4), datediff(day, @vStartDate,@vEndDate))/ @vAvgDaysInaMonth
                             )
SET NOCOUNT ON

----------------------------------------------------------------------------------------------------
-- Get the Total reads by analyst, for all active coverage analysts.
-- Declare AuthorReads Table 
DECLARE	@AuthorReads TABLE 
  (DocId                    INT, 
   LastName                 VARCHAR(50), 
   PubDate                  datetime,
   ReadDate                 datetime,
   --Other PubNo/Read/Analyst info
   Title                    VARCHAR(250),
   FullName                 VARCHAR(60), 
   AnalystId                INT,
   PubNo                    INT,
   ContactID                VARCHAR(100),
   Account                  varchar(128),
   Email                    varchar(128) 
   )

--Get the author Reads
INSERT	@AuthorReads
    SELECT
           RVD.DocId, RVDA.Last, RVD.date AS PubDate, UR.READ_DATE,
           --Other PubNo/Read/Analyst info
           RVD.title, RVDA.Name AS FullName, RVDA.ANALYSTID, UR.PUBNO, UR.CONTACTID, C.ACCOUNT, C.EMAIL
    FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
    INNER JOIN SlxExternal.dbo.RVDocuments RVD 
        ON RVD.DocId = UR.PUBNO 
        AND RVD.DocTypeId = 1   --Only the Research Calls
        
    INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA 
        ON RVDA.DocID = UR.PubNo
       --Selected analyst is primary author[Primary analyst indicated by ordinal value]
       AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
       --Active Coverage - Consider Analysts with Active Ticker Coverage as of today from the ResearchCoverage Table
       AND RVDA.AnalystId IN (SELECT DISTINCT ANALYSTID FROM SlxExternal.dbo.RVResearchCoverage RVRC WHERE DROPDATE IS NULL)
       --Filter on the Analyst for TESTING
       --AND RVDA.AnalystId = @iAnalystId
       
    LEFT JOIN saleslogix.sysdba.CONTACT C ON C.CONTACTID = UR.CONTACTID   
    
    WHERE RVD.date BETWEEN @vStartDate AND @vEndDate     -- All Pub Dates for the specified date range
      AND UR.READ_DATE <= @vAsOfDate                     -- All Reads that occured until the specified "vAsOfDate"

--Verify the Total Reads at the DocId level
--SELECT * FROM @AuthorReads
--Order by lastname asc, PubDate asc, ReadDate asc

PRINT '------------------------------------------------------------------------------------------------------'
PRINT 'REPORT    : Display the Avg Read Metrics by an Analyst [ACTIVE COVERAGE]'
PRINT 'PARAMETERS: Report Range From: ' +  @vStartDate + ' Until: ' + @vEndDate
PRINT '            Report Reads As Of Date: ' + @vAsOfDate
PRINT '------------------------------------------------------------------------------------------------------'

SELECT
   V1.AnalystId, V1.LastName, 
  'NumReads' = V1.NumReads,
  'NumCalls' = V2.NumCallsPub,
  'AvgReadsPerCall' = CONVERT( DECIMAL(10,1),
                                   CONVERT( DECIMAL(10,4), V1.NumReads)/CONVERT( DECIMAL(10,4), V2.NumCallsPub)
                             ),
       --'AvgReadsPerCallRound' = V1.NumReads/V2.NumCallsPub,

--       --#Calls Read
--       '#CallsRead' = V1.NumCallsRead,
--       'AvgReads' = CONVERT( DECIMAL(10,1),
--                                   CONVERT( DECIMAL(10,4), V1.NumReads)/CONVERT( DECIMAL(10,4), V1.NumCallsRead)
--                                  ),
--       'AvgReadsRound' = V1.NumReads/V1.NumCallsRead,
   'NumMonths' = @vNumMonths,
   'AvgReadsPerMonth' = CONVERT( DECIMAL(10,1),
                                 CONVERT( DECIMAL(10,4), V1.NumReads)/CONVERT( DECIMAL(10,4), @vNumMonths)
                                ),
  --NumBlackbooks (published during the period)
  'NumBlackbooks' = V3.NumBlackBooks,

  'Region' = 'US',
  'Title' = 'Sr. Analyst',
  'UserName' = 'ac\jdoe'
  --Report Parameters Info 
--  'Start Date' = @vStartDate, 
--  'End Date' = @vEndDate,
--  'Report As Of Date' = @vAsOfDate
FROM
(
    SELECT AnalystId, LastName, 
           Count(Distinct PubNo) AS NumCallsRead,
           Count(*) AS NumReads
    FROM @AuthorReads
    GROUP BY AnalystId, LastName
) V1,
(
    SELECT RDA.AnalystId,
           Count(*) AS NumCallsPub
    FROM SlxExternal.dbo.RVDocuments RVD
    INNER JOIN SlxExternal.dbo.RVDocAnalysts RDA ON RDA.DocId = RVD.DocId
    WHERE RVD.DocTypeId = 1 --Research Calls only
      AND RVD.Date BETWEEN @vStartDate AND @vEndDate
    GROUP BY RDA.AnalystId
) V2,
(
    SELECT RDA.AnalystId,
           Count(*) AS NumBlackBooks
    FROM SlxExternal.dbo.RVDocuments RVD
    INNER JOIN SlxExternal.dbo.RVDocAnalysts RDA ON RDA.DocId = RVD.DocId
    WHERE RVD.DocTypeId =  3 --Black Books only
      AND RVD.Date BETWEEN @vStartDate AND @vEndDate
    GROUP BY RDA.AnalystId
) V3
WHERE V1.AnalystId = V2.AnalystId
  AND V1.AnalystId = V3.AnalystId
ORDER BY AvgReadsPerCall DESC -- V1.LastName


--use Research
--go
--
---- Visibility.xls dynamic SQL
---- Num Calls (rolling 12 months)
---- All authors on Call, i.e. primary and non-primary authors
--select count(p.pubno) researchcall
--from publications p
--join properties pr on p.pubno = pr.pubno
--join authors a on pr.propvalue = a.name
--where pr.propid = 5
--and a.isanalyst = -1
--and pr.propvalue = 'Craig Moffett'
--and  date >= '01/01/2008' and date < '12/31/2008'
--and type in ('research call')
--group by propvalue
--order by count(p.pubno)
--
--
--select count(p.pubno) / 12 researchcall
--from publications p join properties pr on p.pubno = pr.pubno 
--join authors a on pr.propvalue = a.name
--where pr.propid = 5 and a.isanalyst = -1
--and pr.propvalue = 'Craig Moffett'
--and  date >= '01/01/2008' and date < '12/31/2008'
----and  date >= '01/01/2008' and date < '10/31/2008'
----and  date >= '10/31/2007' and date < '10/31/2008'
--and type in ('research call') 
--group by propvalue order by count(p.pubno)