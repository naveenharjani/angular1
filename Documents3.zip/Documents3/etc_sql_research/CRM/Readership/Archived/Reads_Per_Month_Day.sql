-- Reads_Per_Month_Day.sql

--SLX PRODUCTION: SLXPRDDB\SALGX_PRD,16083

USE SlxExternal
GO

-- Reads per month
select
  year(READ_DATE)                                         AS 'Sort Year',
  month(READ_DATE)                                        AS 'Sort Month',
  DATENAME(mm, READ_DATE) + ' ' + DATENAME(yy, READ_DATE) AS 'Read Month',
  count(*)                                                AS 'Total',
  sum(case when SOURCEID =  0 then 1 else 0 end)          AS 'Blast',
  sum(case when SOURCEID =  1 then 1 else 0 end)          AS 'Summary',
  sum(case when SOURCEID =  2 then 1 else 0 end)          AS 'Cart',
  sum(case when SOURCEID IN (10, 11) then 1 else 0 end)   AS 'BR.com',
  sum(case when SOURCEID =  3 then 1 else 0 end)          AS 'Embed Link',
  sum(case when SOURCEID =  4 then 1 else 0 end)          AS 'Sales Alert',
  sum(case when SOURCEID IN (30, 31) then 1 else 0 end)   AS 'Mobile',
  sum(case when SOURCEID NOT IN (0,1,2,3,4,10,11,30,31) then 1 else 0 end)       
                                                          AS 'Other'
from SlxExternal.dbo.SCB_UNIQUE_READERS
Where year(READ_DATE) = 2010
group by
  year(READ_DATE),
  month(READ_DATE),
  DATENAME(mm, READ_DATE) + ' ' + DATENAME(yy, READ_DATE)
order by 1, 2

-- Reads per day
select
  convert(varchar(10), READ_DATE, 102)                    AS 'Read Date',
  datename(weekday, READ_DATE)                            AS 'Day',
  count(*)                                                AS 'Total',
  sum(case when SOURCEID =  0 then 1 else 0 end)          AS 'Blast',
  sum(case when SOURCEID =  1 then 1 else 0 end)          AS 'Summary',
  sum(case when SOURCEID =  2 then 1 else 0 end)          AS 'Cart',
  sum(case when SOURCEID = 10 then 1 else 0 end)          AS 'BR.com',
  sum(case when SOURCEID =  3 then 1 else 0 end)          AS 'Embedded Link',
  sum(case when SOURCEID =  4 then 1 else 0 end)          AS 'Sales Alert',
  sum(case when SOURCEID is null then 1 else 0 end)       AS 'Other' -- Legacy
from SlxExternal.dbo.SCB_UNIQUE_READERS
group by
  convert(varchar(10), READ_DATE, 102),
  datename(weekday, READ_DATE)
order by 1
