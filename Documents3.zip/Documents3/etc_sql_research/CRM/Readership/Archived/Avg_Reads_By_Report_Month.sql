-- AvgReadsPerAnalystPerMonth.sql

USE SlxExternal
GO

-- Report takes approximately 50 seconds

----------------------------------------------------------------------------------------------------
DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)
DECLARE @vReadDays    INT 

--DECLARE @vAnalystId		VARCHAR(100)

SET @vSinceDate = '01/01/2007'  --'01/01/2007'
SET @vUntilDate = getdate()     --'12/31/2008'
--SET @vReadDays = 5
SET @vReadDays = 30

--SET @vAnalystId = '150' --A.M. (Toni) Sacconaghi, Jr.
--SET @vAnalystId = '204' --

SET NOCOUNT ON

----------------------------------------------------------------------------------------------------
-- Get the Total reads in the first x days a call is published, for al active coverage analysts.
-- Declare AuthorReads Table 
DECLARE	@AuthorReads TABLE 
  (DocId                    INT, 
   LastName                 VARCHAR(50), 
   --Publication date
   CallsPublishedMonthYear  VARCHAR(30), 
   PubYear                  VARCHAR(4), 
   PubMonth                 VARCHAR(4), 
   PubDate                  datetime,
   --Read date
   CallsReadMonthYear       VARCHAR(30), 
   ReadYear                 VARCHAR(4), 
   ReadMonth                VARCHAR(4),
   ReadDate                 datetime,
   --Other PubNo/Read/Analyst info
   Title                    VARCHAR(250),
   FullName                 VARCHAR(60), 
   AnalystId                INT,
   PubNo                    INT,
   ContactID                VARCHAR(100) 
   )

--Get the author Reads
INSERT	@AuthorReads
    Select
           RVD.DocId,
           RVDA.Last,
           --Publication date
           DATENAME(mm, RVD.date) + ' ' + DATENAME(yy, RVD.date) AS CallsPublishedMonthYear,
           CONVERT(varchar, DATEPART(yy, RVD.date)) AS PubYear,
           Right('00' + CONVERT(varchar(2), DATEPART(mm, RVD.date)), 2) AS PubMonth,
           RVD.date AS PubDate,
           --Read date
           DATENAME(mm, UR.READ_DATE) + ' ' + DATENAME(yy, UR.READ_DATE) AS CallsReadMonthYear,
           CONVERT(varchar, DATEPART(yy, UR.READ_DATE)) AS ReadYear,
           Right('00' + CONVERT(varchar(2), DATEPART(mm, UR.READ_DATE)), 2) AS ReadMonth,
           UR.READ_DATE,
           --Other PubNo/Read/Analyst info
           RVD.title, RVDA.Name AS FullName, RVDA.ANALYSTID, UR.PUBNO, UR.CONTACTID
    From SlxExternal.dbo.SCB_UNIQUE_READERS UR
    INNER JOIN SlxExternal.dbo.RVDocuments RVD 
        ON RVD.DocId = UR.PUBNO 
        AND RVD.DocTypeId = 1   --Only the Research Calls
    INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA 
        ON RVDA.DocID = UR.PubNo
       --Selected analyst is primary author[Primary analyst indicated by ordinal value]
       AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
       --Active Coverage - Consider Analysts with Active Ticker Coverage as of today from the ResearchCoverage Table
       AND RVDA.AnalystId IN (SELECT DISTINCT ANALYSTID FROM SlxExternal.dbo.RVResearchCoverage RVRC WHERE DROPDATE IS NULL)
       --Filter on the Analyst for TESTING
       --AND RVDA.AnalystId = @vAnalystId
       
    WHERE RVD.date BETWEEN @vSinceDate AND @vUntilDate -- All reads for the specified date range
      AND UR.READ_DATE <= RVD.date + @vReadDays        -- Use the average reads per Call in first x days when a Call is published, to provide a more consistent sampling period.

--Verify the Total Reads at the DocId level
--SELECT * FROM @AuthorReads
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
-- Get the Average Read Count for a month, by an Analyst.
-- Declare ReportReads Table
DECLARE	@ReportReads TABLE 
  (LastName               VARCHAR(50), 
   CallsPublishedMonthYear  VARCHAR(30), 
   CallsReadMonthYear       VARCHAR(30), 
   CallsReadCount           INT, 
   CallsPublishedCount      INT, 
   AvgReadsPerCall          INT,
   PubYear                  VARCHAR(4), 
   PubMonth                 VARCHAR(4), 
   ReadYear                 VARCHAR(4), 
   ReadMonth                VARCHAR(4),
   FullName                 VARCHAR(50), 
   AnalystId                INT
   )

INSERT	@ReportReads
SELECT
    V.LastName,
    V.CallsPublishedMonthYear,
    V.CallsReadMonthYear,
    Count(*) AS CallsReadCount, 
    Count(distinct V.PubNo) AS CallsPublishedCount,
    Count(*)/Count(distinct V.PubNo) AS AvgReadsPerCall,
    V.PubYear, 
    V.PubMonth, 
    V.ReadYear, 
    V.ReadMonth,
    V.FullName, 
    V.AnalystId
FROM @AuthorReads V
WHERE V.PubYear = V.ReadYear 
  AND V.PubMonth = V.ReadMonth
GROUP BY
  V.LastName, 
  V.CallsPublishedMonthYear, V.CallsReadMonthYear, V.PubYear, V.PubMonth, V.ReadYear, V.ReadMonth,
  V.FullName, V.AnalystId  
ORDER BY PubYear desc, PubMonth desc

--Display the READS data - row wise
--SELECT * 
--FROM @ReportReads
--ORDER BY PubYear desc, PubMonth desc

PRINT '------------------------------------------------------------------------------------------------------'
PRINT 'REPORT 1: DISPLAY THE "AVG READS PER CALL" FOR AN ANALYST BY EACH MONTH [ALL ACTIVE COVERAGE ANALYSTS]' 
PRINT '------------------------------------------------------------------------------------------------------'

----Display the READS data - column wise PIVOT structure
SELECT
    'Author' = LastName,
    --2009
		SUM(CASE WHEN PubYear = '2009' AND PubMonth = '03' THEN AvgReadsPerCall ELSE 0 END) AS [Mar-2009],
		SUM(CASE WHEN PubYear = '2009' AND PubMonth = '02' THEN AvgReadsPerCall ELSE 0 END) AS [Feb-2009],
		SUM(CASE WHEN PubYear = '2009' AND PubMonth = '01' THEN AvgReadsPerCall ELSE 0 END) AS [Jan-2009],
    --2008
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '12' THEN AvgReadsPerCall ELSE 0 END) AS [Dec-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '11' THEN AvgReadsPerCall ELSE 0 END) AS [Nov-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '10' THEN AvgReadsPerCall ELSE 0 END) AS [Oct-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '09' THEN AvgReadsPerCall ELSE 0 END) AS [Sep-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '08' THEN AvgReadsPerCall ELSE 0 END) AS [Aug-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '07' THEN AvgReadsPerCall ELSE 0 END) AS [Jul-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '06' THEN AvgReadsPerCall ELSE 0 END) AS [Jun-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '05' THEN AvgReadsPerCall ELSE 0 END) AS [May-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '04' THEN AvgReadsPerCall ELSE 0 END) AS [Apr-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '03' THEN AvgReadsPerCall ELSE 0 END) AS [Mar-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '02' THEN AvgReadsPerCall ELSE 0 END) AS [Feb-2008],
		SUM(CASE WHEN PubYear = '2008' AND PubMonth = '01' THEN AvgReadsPerCall ELSE 0 END) AS [Jan-2008],
    --2007
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '12' THEN AvgReadsPerCall ELSE 0 END) AS [Dec-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '11' THEN AvgReadsPerCall ELSE 0 END) AS [Nov-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '10' THEN AvgReadsPerCall ELSE 0 END) AS [Oct-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '09' THEN AvgReadsPerCall ELSE 0 END) AS [Sep-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '08' THEN AvgReadsPerCall ELSE 0 END) AS [Aug-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '07' THEN AvgReadsPerCall ELSE 0 END) AS [Jul-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '06' THEN AvgReadsPerCall ELSE 0 END) AS [Jun-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '05' THEN AvgReadsPerCall ELSE 0 END) AS [May-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '04' THEN AvgReadsPerCall ELSE 0 END) AS [Apr-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '03' THEN AvgReadsPerCall ELSE 0 END) AS [Mar-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '02' THEN AvgReadsPerCall ELSE 0 END) AS [Feb-2007],
		SUM(CASE WHEN PubYear = '2007' AND PubMonth = '01' THEN AvgReadsPerCall ELSE 0 END) AS [Jan-2007]
FROM		@ReportReads
GROUP BY	LastName
ORDER BY	LastName

----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
-- Get the TOTAL Monthly Average Read Count.
-- Declare @ReportReadsTotalAvg Table
DECLARE	@ReportReadsTotalAvg TABLE 
  (CallsPublishedMonthYear  VARCHAR(30), 
   CallsReadCount           INT, 
   CallsPublishedCount      INT, 
   AvgReadsPerCall          INT,
   PubYear                  VARCHAR(4), 
   PubMonth                 VARCHAR(4)
   )
   
INSERT	@ReportReadsTotalAvg
  (CallsPublishedMonthYear, 
   CallsReadCount, 
   CallsPublishedCount, 
   AvgReadsPerCall,
   PubYear, 
   PubMonth)
SELECT
    V.CallsPublishedMonthYear,
    Count(*) AS CallsReadCount, 
    Count(distinct V.PubNo) AS CallsPublishedCount,
    Count(*)/Count(distinct V.PubNo) AS AvgReadsPerCall,
    V.PubYear, 
    V.PubMonth 
FROM @AuthorReads V
WHERE V.PubYear = V.ReadYear 
  AND V.PubMonth = V.ReadMonth
GROUP BY
  V.CallsPublishedMonthYear, V.PubYear, V.PubMonth
ORDER BY PubYear desc, PubMonth desc

PRINT '----------------------------------------------------------------------------------------'
PRINT 'REPORT 2: DISPLAY THE TOTAL "AVG READS PER CALL" BY MONTH [ALL ACTIVE COVERAGE ANALYSTS]' 
PRINT '----------------------------------------------------------------------------------------'

--Get the TOTAL Monthly Average Read Count Data
SELECT 
    CallsPublishedMonthYear AS CallPublishedMonth, 
    AvgReadsPerCall AS AverageReads,
    CallsReadCount, 
    CallsPublishedCount--, 
    --PubYear, 
    --PubMonth
FROM		@ReportReadsTotalAvg

----------------------------------------------------------------------------------------------------
SET NOCOUNT OFF
