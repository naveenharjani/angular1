-- BlackRockReadership.sql
-- 02/14/2017

/*
PRD : SLXPRDDB,16083
Database=SlxExternal;
User ID=research_db_svc;
*/

USE SlxExternal
GO

/*

Below sql is embedded in SSRS - "BlackRock Readership" report that is sent out daily 2am 

*/

DECLARE
  @SinceDate  varchar(20),
  @UntilDate  varchar(20)

SET @SinceDate = CONVERT(date, getdate() - 1, 101)
SET @UntilDate = CONVERT(date, getdate(), 101)

-- Raw Reads
SELECT
  'FileContributor' = 'BERNSTEIN',
  'Broker' = 'BERNSTEIN',
  -- Blackrock contact
  'BRFirstName' = C.FIRSTNAME,
  'BRLastName' = C.LASTNAME,
  'BREmail' = VW.ACCESS_EMAIL_ADDR,
  'OtherEmail' = C.AltEmail,
  'BrokerClientId' = '',
  'BrokerResearchDocId' = VW.PUBNO,
  'VendorDocId' = '',
  'PublishDateTime' = RVD.Date,
  'DocTitle' = RVD.Title,
  'PrimaryAnalyst' = RVDA.Last + ', ' + RVDA.First,
  'ReadTimeStamp' = VW.ACCESSDATE,
  'Channel' = CASE 
                WHEN RVL.SourceId IN (0,1,2,3,4,32,33,34,35,36,37,38,39,40,41,42,43) THEN 'Email'
                WHEN RVL.SourceId IN (10,11,30,31) THEN 'Broker Portal'
                ELSE 'Other'
              END,        
  'FileTimeStamp' = '',
  'PrimaryStock' = RVDS.Ticker,
  ISNULL(STUFF((SELECT ',' + convert(varchar(30),S1.Ticker) 
                     FROM SlxExternal.dbo.RVDocSecurities S1 WITH(NOLOCK)
                     WHERE DocId = RVD.DocId ORDER BY OrdinalId FOR XML PATH('')), 1, 1, ''), '') AS TickerList
FROM SlxExternal.dbo.vwWebUsage VW
JOIN Compass.dbo.Contact  C     ON C.EMAIL   = VW.ACCESS_EMAIL_ADDR
JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = VW.PUBNO
-- Primary Author
JOIN SlxExternal.dbo.RVDocAnalysts RVDA ON RVDA.DocId = VW.PUBNO
       and RVDA.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = RVDA.DocId) 
-- Primary Stock
JOIN SlxExternal.dbo.RVDocSecurities RVDS ON RVDS.DocId = VW.PUBNO
       and RVDS.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocSecurities where DocId = RVDS.DocId)
-- Sources
JOIN SlxExternal.dbo.RVLinkSources RVL ON RVL.Source = VW.Source
WHERE VW.ACCESS_EMAIL_ADDR LIKE '%blackrock.com%'          -- BlackRock reads
-- reports read in last 1day
  AND VW.ACCESSDATE BETWEEN @SinceDate AND DateAdd("d", 1, @UntilDate)
  --AND VW.ACCESSDATE BETWEEN @SinceDate AND @UntilDate      -- reports read in last 1 day
ORDER BY VW.ACCESSDATE DESC



-- Filtered Reads
SELECT
  'FileContributor' = 'BERNSTEIN',
  'Broker' = 'BERNSTEIN',
  -- Blackrock contact
  'BRFirstName' = C.FIRSTNAME,
  'BRLastName' = C.LASTNAME,
  'BREmail' = C.Email,
  'OtherEmail' = C.AltEmail,
  'BrokerClientId' = '',
  'BrokerResearchDocId' = VW.PUBNO,
  'VendorDocId' = '',
  'PublishDateTime' = RVD.Date,
  'DocTitle' = RVD.Title,
  'PrimaryAnalyst' = RVDA.Last + ', ' + RVDA.First,
  'ReadTimeStamp' = VW.READ_DATE,
  'Channel' = CASE 
                WHEN RVL.SourceId IN (0,1,2,3,4,32,33,34,35,36,37,38,39,40,41,42,43) THEN 'Email'
                WHEN RVL.SourceId IN (10,11,30,31) THEN 'Broker Portal'
                ELSE 'Other'
              END,        
  'FileTimeStamp' = '',
  'PrimaryStock' = RVDS.Ticker,
  ISNULL(STUFF((SELECT ',' + convert(varchar(30),S1.Ticker) 
                     FROM SlxExternal.dbo.RVDocSecurities S1 WITH(NOLOCK)
                     WHERE DocId = RVD.DocId ORDER BY OrdinalId FOR XML PATH('')), 1, 1, ''), '') AS TickerList
FROM SlxExternal.dbo.vwUniqueReaders VW
JOIN Compass.dbo.Contact  C     ON C.SLXContactID = VW.CONTACTID
JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = VW.PUBNO
-- Primary Author
JOIN SlxExternal.dbo.RVDocAnalysts RVDA ON RVDA.DocId = VW.PUBNO
       and RVDA.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocAnalysts where DocId = RVDA.DocId) 
-- Primary Stock
JOIN SlxExternal.dbo.RVDocSecurities RVDS ON RVDS.DocId = VW.PUBNO
       and RVDS.OrdinalId = (select MIN(OrdinalId) from SlxExternal.dbo.RVDocSecurities where DocId = RVDS.DocId)
-- Sources
JOIN SlxExternal.dbo.RVLinkSources RVL ON RVL.SourceId = VW.SOURCEID
WHERE C.Email LIKE '%blackrock.com%'          -- BlackRock reads
-- reports read in last 1day
  AND VW.READ_DATE BETWEEN @SinceDate AND DateAdd("d", 1, @UntilDate)
  --AND VW.READ_DATE BETWEEN @SinceDate AND @UntilDate      -- reports read in last 1 day
ORDER BY VW.READ_DATE DESC


/*
-- DEBUG

SELECT TOP 100 * FROM vwWebUsage
SELECT TOP 100 * FROM Compass.dbo.ACCOUNT where AccountName like '%blackrock%'
SELECT TOP 100 * FROM Compass.dbo.CONTACT where email like '%blackrock%'
SELECT TOP 100 * FROM SlxExternal.dbo.RVDocuments ORDER BY DocId DESC
SELECT TOP 100 * FROM SlxExternal.dbo.RVDocAnalysts   ORDER BY DocId DESC  -- where docid = 118408
SELECT TOP 100 * FROM SlxExternal.dbo.RVDocSecurities ORDER BY DocId DESC  -- where docid = 118408

SELECT ISNULL(STUFF((SELECT ',' + convert(varchar(30),S1.Ticker) 
                     FROM SlxExternal.dbo.RVDocSecurities S1 WITH(NOLOCK)
                     WHERE DocId = 128055 FOR XML PATH('')), 1, 1, ''), '') AS TickerList

*/