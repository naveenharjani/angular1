-- 2015AnalystOffsite.sql
-- 06/08/2015

-- Matt
-- 06/08/2015
-- 06/15/2015

USE SlxExternal
GO

DECLARE
@vStartDate  VARCHAR(12),
@vEndDate    VARCHAR(12)

SET @vStartDate = '01/01/2013'
SET @vEndDate   = '06/11/2015'

--SET @vStartDate = '01/01/2008'
--SET @vEndDate   = '06/11/2010'

SET NOCOUNT ON

DECLARE @DocumentSet TABLE (DocId  INT, AnalystCount INT)

/*
Review filtered Blackbook titles (the compendium books get very high reads)

SELECT RVD.DocId, RVD.TITLE, 'NumReads' = COUNT(*)
FROM RVDocuments  RVD
JOIN SCB_UNIQUE_READERS UR ON UR.PUBNO = RVD.DocId
WHERE RVD.Date BETWEEN @vStartDate AND @vEndDate
AND  (RVD.DocTypeId = 3 AND RVD.Title NOT LIKE '%Strategic Decisions Conference%'
                         AND RVD.Title NOT LIKE '%SDC%'
                         AND RVD.Title NOT LIKE '%The Best of Bernstein%'
                         AND RVD.Title NOT LIKE '%The Long View%'
                         AND RVD.Title NOT LIKE '%Quantitative Handbook%'
                         AND RVD.Title NOT LIKE '%Quantitative Strategy%')
GROUP BY RVD.DocId, RVD.TITLE
ORDER BY COUNT(*) DESC

*/

INSERT @DocumentSet
SELECT RVD.DocId, 'AnalystCount' = ISNULL(Count(*),0)
  FROM RVDocuments  RVD
 INNER JOIN RVDocAnalysts RVDA ON RVDA.DocId = RVD.DocId
 WHERE RVD.Date BETWEEN @vStartDate AND @vEndDate
-- Blackbook filter exclusions
AND ( (RVD.DocTypeId = 3 AND RVD.Title NOT LIKE '%Strategic Decisions Conference%'
                         AND RVD.Title NOT LIKE '%SDC%'
                         AND RVD.Title NOT LIKE '%The Best of Bernstein%'
                         AND RVD.Title NOT LIKE '%The Long View%'
                         AND RVD.Title NOT LIKE '%Quantitative Handbook%'
                         AND RVD.Title NOT LIKE '%Quantitative Strategy%')
       OR
       RVD.DocTypeId <> 3)
--GROUP BY RVD.DocId                     -- All
GROUP BY RVD.DocId HAVING Count(*) > 1    -- JointOnly
--GROUP BY RVD.DocId HAVING Count(*) = 1 -- Solo

-- SELECT * FROM @DocumentSet

SELECT DISTINCT
  RVDA.Last, 
  RVDA.First,
  'Year'       = YEAR(RVD.date),
  'Month'      = MONTH(RVD.date),
  
  'Calls'         = SUM(CASE WHEN RVD.DocTypeId = 1 THEN 1 ELSE 0 END),
  'CallReads'     = SUM(CASE WHEN RVD.DocTypeId = 1 THEN UR.ReadCount ELSE 0 END),

  'LongView'      = SUM(CASE WHEN RVD.Title LIKE '%Long View:%' THEN 1 ELSE 0 END),
  'LongViewReads' = SUM(CASE WHEN RVD.Title LIKE '%Long View:%' THEN UR.ReadCount ELSE 0 END),

  'Blast'         = SUM(CASE WHEN RVD.Title LIKE '%Blast:%' THEN 1 ELSE 0 END),
  'BlastReads'    = SUM(CASE WHEN RVD.Title LIKE '%Blast:%' THEN UR.ReadCount ELSE 0 END),

  'Flashes'       = SUM(CASE WHEN RVD.DocTypeId = 8 THEN 1 ELSE 0 END),
  'FlashReads'    = SUM(CASE WHEN RVD.DocTypeId = 8 THEN UR.ReadCount ELSE 0 END),

  'Blackbooks'    = SUM(CASE WHEN RVD.DocTypeId = 3 THEN 1 ELSE 0 END),
  'BlacbookReads' = SUM(CASE WHEN RVD.DocTypeId = 3 THEN UR.ReadCount ELSE 0 END),

  'Whitebooks'    = SUM(CASE WHEN RVD.DocTypeId = 6 THEN 1 ELSE 0 END),
  'WhitebookReads'= SUM(CASE WHEN RVD.DocTypeId = 6 THEN UR.ReadCount ELSE 0 END),

  'Videos'        = SUM(CASE WHEN RVD.DocTypeId = 10 THEN 1 ELSE 0 END),
  'VideoReads'    = SUM(CASE WHEN RVD.DocTypeId = 10 THEN UR.ReadCount ELSE 0 END)

FROM @DocumentSet DS
INNER JOIN ( SELECT PUBNO, 'ReadCount' = COUNT(*) 
             FROM SCB_UNIQUE_READERS
             -- exclude readership after the end of period
             WHERE READ_DATE <= @vEndDate
             GROUP BY PUBNO ) UR ON UR.PUBNO = DS.DocId
INNER JOIN RVDocuments RVD    ON RVD.DocId = DS.DocId
INNER JOIN RVDocAnalysts RVDA ON RVDA.DocId = DS.DocId
GROUP BY
  RVDA.Last,
  RVDA.First,
  YEAR(RVD.Date),
  MONTH(RVD.Date)
ORDER BY 1, 2, 3, 4

/*

SELECT * FROM RVAnalysts
SELECT * FROM RVAnalystRegions
SELECT * FROM RVDocAnalysts
SELECT * FROM RVDocAnalystRegions
SELECT * FROM RVTypes
SELECT DocId, Count(*) FROM RVDocAnalystRegions GROUP BY DocId order by 2 desc

SELECT PUBNO, 'read_count' = count(*) FROM SCB_UNIQUE_READERS GROUP BY PUBNO
SELECT TOP 100 * FROM SCB_UNIQUE_READERS WHERE READ_DATE <= '05/31/2015'

SELECT * FROM RVDocAnalysts where docid = 112624  -- joint call
SELECT * FROM RVDocAnalysts where docid = 112669  -- single analyst call

SELECT DocId, 
       ISNULL(Count(*),0),
       'JointCallFlag' = CASE WHEN ISNULL(Count(*),0) = 0 THEN 'N' ELSE 'Y' END
FROM RVDocAnalysts
GROUP BY DocId
--HAVING Count(*) > 1
ORDER BY DocId desc

*/
