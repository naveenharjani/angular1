-- FundFlow_Reads.sql
-- 07/18/2016

-- 7/18/2016 : Provide list of external and internal readers of the reports  for Luke Montgomery
-- 7/26/2016 : Ronny Gal - 2016/2015 reports
-- 01/04/2017: Ronny Gal - 2016 reports

-- Compass:  (Server: SLXPRDDB,16083; Login: research_db_svc)

-- Unique Reads
SELECT 
  DISTINCT
  D.DocId AS PubNo,
  CONVERT(VARCHAR, D.Date, 101) AS Date,
  RT.DocType AS Type,
  D.Title AS Title,
  A.AccountName AS Account,
  C.FirstName + ' ' + C.MiddleName + ' ' + C.LASTNAME AS Contact,
  C.Email as Email
--FROM sysdba.SCB_WEB_USAGE SWU
FROM SlxExternal.dbo.vwUniqueReaders SWU
INNER JOIN SlxExternal.dbo.RVDocuments D ON D.DocId = SWU.PUBNO
INNER JOIN SlxExternal.dbo.RVTypes RT on RT.DocTypeId = D.DocTypeId
INNER JOIN Compass.dbo.CONTACT C on C.SLXContactId = SWU.CONTACTID
INNER JOIN Compass.dbo.ACCOUNT A on A.ACCOUNTID = C.ACCOUNTID
-- Rony Gal - 2016 reports
WHERE SWU.PUBNO IN (SELECT RD.DocId FROM SlxExternal.dbo.RVDocuments RD
                    JOIN SlxExternal.dbo.RVDocAnalysts RDA ON RD.DocId = RDA.DocId
                    WHERE RDA.AnalystId = 309 AND Year(RD.Date) = 2016)
ORDER BY 1, 5, 6

-- DEBUG
/*
-- Compass
-- Aaron (Ronny) Gal, Ph.D.
SELECT TOP 100 * FROM SlxExternal.dbo.RVAnalysts where analystid = 309
SELECT TOP 100 * FROM SlxExternal.dbo.vwUniqueReaders
SELECT TOP 100 * FROM SlxExternal.dbo.vwReadDetails VR

SELECT * FROM Compass.dbo.CONTACT C
SELECT * FROM Compass.dbo.ACCOUNT A

*/


/*
-- Saleslogix

-- All Reads
SELECT DISTINCT
  D.DocId AS PubNo,
  CONVERT(VARCHAR, D.Date, 101) AS Date,
  RT.DocType AS Type,
  D.Title AS Title,
  A.Account,
  C.FirstName + ' ' + C.MiddleName + ' ' + C.LASTNAME AS Contact,
  SWU.ACCESS_EMAIL_ADDR AS Email
FROM sysdba.SCB_WEB_USAGE SWU
INNER JOIN SlxExternal.dbo.RVDocuments D ON D.DocId = SWU.PUBNO
INNER JOIN SlxExternal.dbo.RVTypes RT on RT.DocTypeId = D.DocTypeId
INNER JOIN sysdba.CONTACT C on C.CONTACTID = SWU.CONTACTID
INNER JOIN sysdba.ACCOUNT A on A.ACCOUNTID = C.ACCOUNTID
-- Luke Montgomery tickers
--WHERE SWU.PUBNO IN (121663,121118,120921, 120745, 120563,120449,120273, 120115,119781, 119598, 119400,
--                    119173,118926, 118708, 118535,118372)
-- Rony Gal - 2016 reports
WHERE SWU.PUBNO IN (SELECT RD.DocId FROM SlxExternal.dbo.RVDocuments RD
                    JOIN SlxExternal.dbo.RVDocAnalysts RDA ON RD.DocId = RDA.DocId
                    WHERE RDA.AnalystId = 309 AND Year(RD.Date) = 2015)
ORDER BY 1, 5, 6


-- Client Reads
SELECT DISTINCT
  D.DocId AS PubNo,
  CONVERT(VARCHAR, D.Date, 101) AS Date,
  RT.DocType AS Type,
  D.Title AS Title,
  A.Account,
  C.FirstName + ' ' + C.MiddleName + ' ' + C.LASTNAME AS Contact,
  C.EMAIL
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
INNER JOIN SlxExternal.dbo.RVDocuments D ON D.DocId = UR.PUBNO
INNER JOIN SlxExternal.dbo.RVTypes RT on RT.DocTypeId = D.DocTypeId
INNER JOIN sysdba.CONTACT C on C.CONTACTID = UR.CONTACTID
INNER JOIN sysdba.ACCOUNT A on A.ACCOUNTID = C.ACCOUNTID
WHERE UR.PUBNO IN (121663,121118,120921, 120745, 120563,120449,120273, 120115,119781, 119598, 119400,
                   119173,118926, 118708, 118535,118372)

ORDER BY 1, 5, 6

*/

-- DEBUG
/*

--Saleslogix
SELECT * FROM sysdba.ACCOUNT 
SELECT * FROM sysdba.CONTACT
SELECT top 10 * FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
SELECT *  FROM sysdba.SCB_WEB_USAGE SWU order by swu.pubno desc

-- Rony Gal - 2016 reports
SELECT RD.DocId, RDA.AnalystId, RDA.Gal FROM SlxExternal.dbo.RVDocuments RD
JOIN SlxExternal.dbo.RVDocAnalysts RDA ON RD.DocId = RDA.DocId
WHERE RDA.AnalystId = 309 AND Year(RD.Date) = 2016  -- Rony Gal

*/