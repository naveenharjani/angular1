-- Pershing.sql
-- 02/09/2015

-- SLXPRDDB,16083

USE Saleslogix
GO

-- **Detail

-- Raw Reads
SELECT U.PUBNO, U.ACCESS_EMAIL_ADDR, U.ACCESSDATE, RVLS.Source
FROM sysdba.scb_web_usage U
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE U.ACCESS_EMAIL_ADDR Like '%@persq.com'
ORDER BY U.ACCESSDATE DESC

-- Unique Reads
SELECT UR.PUBNO, C.EMAIL, UR.READ_DATE, RVLS.Source --, C.CONTACTID
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
INNER JOIN SalesLogix.sysdba.CONTACT C        ON C.CONTACTID   = UR.CONTACTID
 LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = UR.SOURCEID
WHERE C.EMAIL Like '%@persq.com'
ORDER BY UR.READ_DATE DESC

-- **By Year

-- Raw Reads
SELECT YEAR(U.ACCESSDATE) AS 'Year',
       COUNT(*)           AS 'RawReads'
       --, U.ACCESS_EMAIL_ADDR, 
FROM sysdba.scb_web_usage U
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE U.ACCESS_EMAIL_ADDR Like '%@persq.com'
GROUP BY YEAR(U.ACCESSDATE) --, U.ACCESS_EMAIL_ADDR
ORDER BY 1 DESC

-- Unique Reads
SELECT YEAR(UR.READ_DATE) AS 'Year',
       COUNT(*)           AS 'UniqueReads'
       --, C.EMAIL
FROM SlxExternal.dbo.SCB_UNIQUE_READERS UR
INNER JOIN SalesLogix.sysdba.CONTACT C        ON C.CONTACTID   = UR.CONTACTID
 LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = UR.SOURCEID
WHERE C.EMAIL Like '%@persq.com'
GROUP BY YEAR(UR.READ_DATE) --, U.ACCESS_EMAIL_ADDR
ORDER BY 1 DESC

-- **By Person

-- Raw Reads
SELECT U.ACCESS_EMAIL_ADDR, COUNT(*) AS 'RawReads'
FROM sysdba.scb_web_usage U
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE U.ACCESS_EMAIL_ADDR Like '%@persq.com'
AND U.ACCESSDATE > '01/01/2015'
GROUP BY U.ACCESS_EMAIL_ADDR
ORDER BY 2 DESC

