-- Password_Migration_Analysis.sql
-- 05/30/2018

/* 
PRD : SLXPRDDB,16083 | Database=Compass | User ID=research_db_svc 

List Contacts that read in last 90 days - summary count and detail listing
-	by Authentication (Email, Password) 
-	by Link Product (Blast, Summary, Most Popular, Mobile...)
*/

DECLARE @SinceDate    DATE
DECLARE @UntilDate    DATE
DECLARE @SinceDays    INT

SET @SinceDays = 1
SET @UntilDate = getdate() -- '06/6/2018'
SET @SinceDate = DATEADD(d, -@SinceDays, @UntilDate)

SELECT @SinceDays AS SinceDays, @SinceDate AS SinceDate, @UntilDate AS UntilDate

-- raw reads listing detail - map to LinkProduct and AuthType
SELECT ContactId, PubNo, Read_Date, RVL.SourceId, RVL.Source,
  RVP.Product as LinkProduct,
  (CASE WHEN RVP.Product IN ('BR.com') THEN 'Password' ELSE 'Email' END) AS AuthType
INTO #TmpWebUsage
FROM SlxExternal.dbo.vwUniqueReaders U
JOIN SlxExternal.dbo.RVLinkSources RVL ON RVL.SourceId = U.SOURCEID
JOIN SlxExternal.dbo.RVLinkProducts RVP ON RVP.ProductId = RVL.ProductId
WHERE READ_DATE BETWEEN @SinceDate AND @UntilDate

--SELECT * FROM #TmpWebUsage

-- Get Contacts LastRead - by 'AuthType'
SELECT ContactId, AuthType, MAX(READ_DATE)  AS LastSourceReadDate INTO #TmpAuthType FROM #TmpWebUsage GROUP BY ContactId, AuthType

-- Get Contacts LastRead - by 'LinkProduct'
SELECT ContactId, LinkProduct, MAX(READ_DATE)  AS LastSourceReadDate INTO #TmpLinkProduct FROM #TmpWebUsage GROUP BY ContactId, LinkProduct

-- Get Contacts LastRead - by 'Source'
SELECT ContactId, SourceId, Source, MAX(READ_DATE)  AS LastSourceReadDate INTO #TmpSource FROM #TmpWebUsage GROUP BY ContactId, SourceId, Source

SELECT 'Email' = C.Email,
       'Account' = convert(varchar(50), A.AccountName),
       'Contact' = convert(varchar(50), C.ContactName),
		TSC.LastSourceReadDate AS EmailLast,
		TSC2.LastSourceReadDate AS PasswordLast,
		TSP.LastSourceReadDate AS BlastLast,
		TSP2.LastSourceReadDate AS SummaryLast,
		TSP3.LastSourceReadDate AS MostPopularLast,
		TS.LastSourceReadDate AS SummaryLegacyLast,
		TS1.LastSourceReadDate AS SummarySalesLast,
		TS2.LastSourceReadDate AS CartLast,
		TS3.LastSourceReadDate AS EmbedLinkLast,
		TS4.LastSourceReadDate AS SalesAlertLast,
		TS5.LastSourceReadDate AS AlgoLast,
		TS6.LastSourceReadDate AS SpecialistLast
INTO #TmpContactLastRead
FROM Compass.dbo.Account A
INNER JOIN Compass.dbo.Contact C with (nolock) ON  A.AccountId = C.AccountId
LEFT JOIN #TmpAuthType TSC     ON  C.CONTACTID = TSC.CONTACTID  AND TSC.AuthType = 'Email'
LEFT JOIN #TmpAuthType TSC2    ON  C.CONTACTID = TSC2.CONTACTID AND TSC2.AuthType = 'Password'
LEFT JOIN #TmpLinkProduct TSP  ON  C.CONTACTID = TSP.CONTACTID  AND TSP.LinkProduct = 'Blast'
LEFT JOIN #TmpLinkProduct TSP2 ON  C.CONTACTID = TSP2.CONTACTID AND TSP2.LinkProduct = 'Summary'
LEFT JOIN #TmpLinkProduct TSP3 ON  C.CONTACTID = TSP3.CONTACTID AND TSP3.LinkProduct = 'Most Popular'
LEFT JOIN #TmpSource TS ON C.ContactID = TS.ContactID AND TS.SourceId IN (1, 36, 37, 38, 39, 40, 41, 42)  -- Daily Summary
LEFT JOIN #TmpSource TS1 ON C.ContactID = TS1.ContactID AND TS1.Source = 'Summary (Fanelli Ed)'
LEFT JOIN #TmpSource TS2 ON C.ContactID = TS2.ContactID AND TS2.Source = 'Cart'
LEFT JOIN #TmpSource TS3 ON C.ContactID = TS3.ContactID AND TS3.Source = 'Embed Link'
LEFT JOIN #TmpSource TS4 ON C.ContactID = TS4.ContactID AND TS4.Source = 'Sales Alert'
LEFT JOIN #TmpSource TS5 ON C.ContactID = TS5.ContactID AND TS5.Source = 'Algo'
LEFT JOIN #TmpSource TS6 ON C.ContactID = TS6.ContactID AND TS6.Source = 'Sector Specialist'
WHERE TSC.AuthType IS NOT NULL OR TSC2.AuthType IS NOT NULL OR TSP.LinkProduct IS NOT NULL OR TSP2.LinkProduct IS NOT NULL OR TSP3.LinkProduct IS NOT NULL 
   OR TS.Source IS NOT NULL OR TS2.Source IS NOT NULL OR TS3.Source IS NOT NULL OR TS4.Source IS NOT NULL
   OR TS5.Source IS NOT NULL OR TS6.Source IS NOT NULL
ORDER BY 2, 1

PRINT 'List Contacts summary count with Last Read by AuthType(Email, Password) and Link Product(Blast, Summary, Most Popular, Mobile...)'
-- Get Total Contacts by various criteria
SELECT
  'NumReadDays'     = @SinceDays,
  'NumContacts'     = (SELECT COUNT(*) FROM #TmpContactLastRead),
--  'BR and Links'    = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE PasswordLast IS NOT NULL AND EmailLast IS NOT NULL),
--  'BR Only'         = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE PasswordLast IS NOT NULL AND EmailLast IS NULL),
  'Password'        = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE PasswordLast IS NOT NULL),
  'No password'     = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE PasswordLast IS NULL AND EmailLast IS NOT NULL),
  -- Contacts using following product who have not used BR.com
  'Blast'           = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE BlastLast         IS NOT NULL AND PasswordLast IS NULL),
  'Summary - Leg'   = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE SummaryLegacyLast IS NOT NULL AND PasswordLast IS NULL),
  'Summary - Fan'   = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE SummarySalesLast  IS NOT NULL AND PasswordLast IS NULL),
  'Summary - All'   = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE SummaryLast       IS NOT NULL AND PasswordLast IS NULL),
  'Cart'            = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE CartLast   IS NOT NULL AND PasswordLast IS NULL),
  'Embed'           = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE EmbedLinkLast     IS NOT NULL AND PasswordLast IS NULL),
  'Sales'           = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE SalesAlertLast    IS NOT NULL AND PasswordLast IS NULL),
  'Algo'            = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE AlgoLast          IS NOT NULL AND PasswordLast IS NULL),
  'Spec'            = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE SpecialistLast    IS NOT NULL AND PasswordLast IS NULL),
  'Pop'             = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE MostPopularLast   IS NOT NULL AND PasswordLast IS NULL)
  -- Contacts using following product and used Links and BR.com	
--  'Blast - BR_L'    = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE BlastLast IS NOT NULL),
--  'Summary - BR_L'  = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE SummaryLast IS NOT NULL),
--  'Pop - BR_L'      = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE MostPopularLast IS NOT NULL)

-- Contacts using multilple link products who have not used BR.com
SELECT
  'NumReadDays'         = @SinceDays, 'No BR.com cookie' as Type,
  'Blast'               = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE BlastLast IS NOT NULL AND PasswordLast IS NULL),
  'Blast + Summary Leg' = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE BlastLast IS NOT NULL AND SummaryLegacyLast IS NOT NULL AND PasswordLast IS NULL),
  'Blast + Summary Fan' = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE BlastLast IS NOT NULL AND SummarySalesLast IS NOT NULL AND PasswordLast IS NULL),
  'Blast + Cart'        = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE BlastLast IS NULL AND CartLast IS NOT NULL AND PasswordLast IS NULL),
  'Blast + Embed'       = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE BlastLast IS NULL AND EmbedLinkLast IS NOT NULL AND PasswordLast IS NULL),
  'Blast + Sales'       = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE BlastLast IS NULL AND SalesAlertLast IS NOT NULL AND PasswordLast IS NULL),
  'Blast + Pop'         = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE BlastLast IS NULL AND MostPopularLast IS NOT NULL AND PasswordLast IS NULL),
  'Blast + Spec'        = (SELECT COUNT(*) FROM #TmpContactLastRead WHERE BlastLast IS NULL AND SpecialistLast IS NOT NULL AND PasswordLast IS NULL)


PRINT 'List Contacts details with Last Read info by AuthType(Email, Password) and Link Product(Blast, Summary, Most Popular, Mobile...)'
--SELECT * FROM #TmpContactLastRead ORDER BY 2 ASC, 1 ASC


-- Get Contacts listing by Tier level by region
;With CTESummary AS 
(	
	SELECT 'Email' = C.Email,
		   'Account' = convert(varchar(50), A.AccountName),
		   'Contact' = convert(varchar(50), C.ContactName),
			A.USTier, A.EUTier, A.APTier,
			TLP.LastSourceReadDate AS SummaryLast,
			TLS.LastSourceReadDate AS SummaryLegacyLast,
			TLS2.LastSourceReadDate AS SummarySalesLast,
   			TA.LastSourceReadDate AS PasswordLast
	FROM Compass.dbo.Account A
	INNER JOIN Compass.dbo.Contact C with (nolock) ON  A.AccountId = C.AccountId
	LEFT JOIN #TmpLinkProduct TLP ON  C.CONTACTID = TLP.CONTACTID AND TLP.LinkProduct = 'Summary'                -- Summary - All
	LEFT JOIN #TmpSource TLS ON C.ContactID = TLS.ContactID AND TLS.SourceId IN (1, 36, 37, 38, 39, 40, 41, 42)  -- Summary - Legacy
	LEFT JOIN #TmpSource TLS2 ON C.ContactID = TLS2.ContactID AND TLS2.Source = 'Summary (Fanelli Ed)'           -- Summary - Fanelli
	LEFT JOIN #TmpAuthType TA    ON  C.CONTACTID = TA.CONTACTID AND TA.AuthType = 'Password'                     -- BR.com
	WHERE TLP.LinkProduct IS NOT NULL OR TLS.Source IS NOT NULL OR TLS2.Source IS NOT NULL OR TA.AuthType IS NOT NULL
)

-- Get #Contacts by Tier level by region - Summary source
SELECT 'US' AS Region, 
'SummaryTier1' = SUM(CASE WHEN USTier = 'TIER 1' THEN 1 ELSE 0 END),
'SummaryTier2' = SUM(CASE WHEN USTier = 'TIER 2' THEN 1 ELSE 0 END),
'SummaryTier3' = SUM(CASE WHEN USTier = 'TIER 3' THEN 1 ELSE 0 END),
'SummaryTier4' = SUM(CASE WHEN USTier = 'TIER 4' THEN 1 ELSE 0 END),
'SummaryTier5' = SUM(CASE WHEN USTier = 'TIER 5' THEN 1 ELSE 0 END)
FROM CTESummary WHERE SummaryLast IS NOT NULL AND PasswordLast IS  NULL -- No BR.com password
UNION
SELECT 'EU' AS Region, 
'SummaryTier1' = SUM(CASE WHEN EUTier = 'TIER 1' THEN 1 ELSE 0 END),
'SummaryTier2' = SUM(CASE WHEN EUTier = 'TIER 2' THEN 1 ELSE 0 END),
'SummaryTier3' = SUM(CASE WHEN EUTier = 'TIER 3' THEN 1 ELSE 0 END),
'SummaryTier4' = SUM(CASE WHEN EUTier = 'TIER 4' THEN 1 ELSE 0 END),
'SummaryTier5' = SUM(CASE WHEN EUTier = 'TIER 5' THEN 1 ELSE 0 END)
FROM CTESummary WHERE SummaryLast IS NOT NULL AND PasswordLast IS  NULL -- No BR.com password
UNION
SELECT 'AP' AS Region, 
'SummaryTier1' = SUM(CASE WHEN APTier = 'TIER 1' THEN 1 ELSE 0 END),
'SummaryTier2' = SUM(CASE WHEN APTier = 'TIER 2' THEN 1 ELSE 0 END),
'SummaryTier3' = SUM(CASE WHEN APTier = 'TIER 3' THEN 1 ELSE 0 END),
'SummaryTier4' = SUM(CASE WHEN APTier = 'TIER 4' THEN 1 ELSE 0 END),
'SummaryTier5' = SUM(CASE WHEN APTier = 'TIER 5' THEN 1 ELSE 0 END)
FROM CTESummary WHERE SummaryLast IS NOT NULL AND PasswordLast IS  NULL -- No BR.com password
ORDER BY Region

/*
SELECT * FROM #TmpWebUsage ORDER BY Read_Date DESC
SELECT * FROM #TmpAuthType WHERE AuthType = 'Email' ORDER BY LastSourceReadDate DESC
SELECT * FROM #TmpLinkProduct  ORDER BY LastSourceReadDate DESC
SELECT * FROM #TmpSource ORDER BY LastSourceReadDate DESC

select * from SlxExternal.dbo.RVLinkSources where productid = 2
select * from SlxExternal.dbo.RVLinkProducts

select LP.*, LS.*
from SlxExternal.dbo.RVLinkSources LS
join SlxExternal.dbo.RVLinkProducts LP on LP.ProductId = LS.ProductId
order by LP.SeqNo, LS.SeqNo
*/

DROP TABLE #TmpWebUsage
DROP TABLE #TmpSource
DROP TABLE #TmpLinkProduct
DROP TABLE #TmpAuthType
DROP TABLE #TmpContactLastRead
GO