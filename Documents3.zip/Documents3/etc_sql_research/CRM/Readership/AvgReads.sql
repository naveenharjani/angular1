-- AvgReads.sql
-- 02/19/2013
-- 06/28/2016

--SLX PROD: SLXPRDDB\SALGX_PRD,16083

--Average reads during period for single / joint authored calls /blackbooks

USE SlxExternal
GO

DECLARE @vSinceDate		VARCHAR(12)
DECLARE @vUntilDate		VARCHAR(12)

-- Run date 02/19/2013
SET @vSinceDate = '01/01/2012'
SET @vUntilDate = '12/31/2012'

-- Run date 06/28/2016
SET @vSinceDate = '06/27/2015'
SET @vUntilDate = '12/31/2016'

SET NOCOUNT ON

--By PubNo listing - Get the Sr Analyst Count [i.e. multiple Senior Analysts as author] and Total Reads for a PubNo
--Filters applied  - By calls and blackbooks, for 2012 research, excluding 'Best of Bernstein'
SELECT 'PubNo' = D.DocId, D.Title, 'Date' = CONVERT(varchar(12), D.date, 101), T.DocType,
       'SrAnalystCount' = (SELECT Count(*) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = D.DocId GROUP BY DocId),
       'TotalReads'     = (SELECT Count(*) FROM SLXExternal.dbo.SCB_UNIQUE_READERS WHERE pubNo = D.DocID),
       D.DocTypeId, A.AnalystId
INTO #PubReads
FROM  SlxExternal.dbo.RVDocuments D
INNER JOIN SlxExternal.dbo.RVTypes T       ON T.DocTypeId = D.DocTypeId
INNER JOIN SlxExternal.dbo.RVDocAnalysts A ON D.DocId     = A.DocId
WHERE D.DocTypeId in (1,3)                         -- Filter by calls and blackbooks
  AND D.date BETWEEN @vSinceDate AND @vUntilDate   -- Filter by 2012 research
  AND D.Title NOT LIKE 'The Best of Bernstein%'    -- Exclude 'Best of Bernstein' titles
ORDER BY D.Docid ASC

--SELECT * FROM #PubReads

--By Analyst listing - Get Calls/Blackbook Count and Total Reads Count, 
--Use SrAnalystCount to identify Calls Count and Total Reads per below: Filter by [SrAnalystCount = 1] and [SrAnalystCount > 1]
SELECT A.AnalystId, A.Last, A.First,
       -- Calls - Total Count
       'CallsCountOneSr'    = SUM(CASE WHEN P.DocTypeId = 1 AND P.SrAnalystCount = 1 THEN 1 ELSE 0 END),
       'CallsCountMultiSr'  = SUM(CASE WHEN P.DocTypeId = 1 AND P.SrAnalystCount > 1 THEN 1 ELSE 0 END),
       'CallsCountTotal'    = SUM(CASE WHEN P.DocTypeId = 1                          THEN 1 ELSE 0 END),
       -- Blackbooks - Total Count
       'BBCountOneSr'       = SUM(CASE WHEN P.DocTypeId = 3 AND P.SrAnalystCount = 1 THEN 1 ELSE 0 END),
       'BBCountMultiSr'     = SUM(CASE WHEN P.DocTypeId = 3 AND P.SrAnalystCount > 1 THEN 1 ELSE 0 END),
       'BBCountTotal'       = SUM(CASE WHEN P.DocTypeId = 3                          THEN 1 ELSE 0 END),
       -- Calls - Total Reads
       'CallsReadsOneSr'    = SUM(CASE WHEN P.DocTypeId = 1 AND P.SrAnalystCount = 1 THEN TotalReads ELSE 0 END),
       'CallsReadsMultiSr'  = SUM(CASE WHEN P.DocTypeId = 1 AND P.SrAnalystCount > 1 THEN TotalReads ELSE 0 END),
       'CallsReadsCount'    = SUM(CASE WHEN P.DocTypeId = 1                          THEN TotalReads ELSE 0 END),
       -- Blackbooks - Total Reads
       'BBReadsOneSr'       = SUM(CASE WHEN P.DocTypeId = 3 AND P.SrAnalystCount = 1 THEN TotalReads ELSE 0 END),
       'BBReadsMultiSr'     = SUM(CASE WHEN P.DocTypeId = 3 AND P.SrAnalystCount > 1 THEN TotalReads ELSE 0 END),
       'BBReadsCount'       = SUM(CASE WHEN P.DocTypeId = 3                          THEN TotalReads ELSE 0 END)
INTO #AnalystTotals
FROM #PubReads P 
INNER JOIN RVAnalysts A ON P.AnalystId = A.AnalystId
GROUP BY A.AnalystId, A.Last, A.First
ORDER BY A.Last, A.First

--SELECT * FROM #AnalystTotals

--For 2012 - Get Avg Reads for Calls/Blackbooks - joint vs individual calls averages
SELECT
  'Start' = @vSinceDate,
  'End' = @vUntilDate,
  -- Calls - Avg Reads
  'AvgReadsSingleCalls' = ( CASE WHEN SUM(CallsCountOneSr) = 0   THEN 0 ELSE SUM(CallsReadsOneSr)/SUM(CallsCountOneSr) END),
  'AvgReadsJointCalls'  = ( CASE WHEN SUM(CallsCountMultiSr) = 0 THEN 0 ELSE SUM(CallsReadsMultiSr)/SUM(CallsCountMultiSr) END),
  'AvgReadsCalls'       = ( CASE WHEN SUM(CallsCountTotal) = 0   THEN 0 ELSE SUM(CallsReadsCount)/SUM(CallsCountTotal) END),
  -- Blackbooks - Avg Reads
  'AvgReadsSingleBlackbooks' = ( CASE WHEN SUM(BBCountOneSr) = 0      THEN 0 ELSE SUM(BBReadsOneSr)/SUM(BBCountOneSr) END),
  'AvgReadsJointBlackbooks'  = ( CASE WHEN SUM(BBCountMultiSr) = 0    THEN 0 ELSE SUM(BBReadsMultiSr)/SUM(BBCountMultiSr) END),
  'AvgReadsBlackbooks'       = ( CASE WHEN SUM(BBCountTotal) = 0      THEN 0 ELSE SUM(BBReadsCount)/SUM(BBCountTotal) END)
FROM #AnalystTotals A

DROP Table #PubReads
DROP Table #AnalystTotals
GO

/*
-- DEBUG

SELECT TOP 100 * FROM RVDocuments ORDER BY Date DESC
SELECT TOP 100 * FROM RVTypes
SELECT TOP 300 * FROM RVAnalysts

SP_HELP RVDocuments

--By Analyst - Get Avg Reads for Calls/Blackbooks - joint vs individual calls averages
SELECT A.Last, A.First,
       -- Calls - Avg Reads
       'AvgReadsSingleCalls' = ( CASE WHEN CallsCountOneSr = 0   THEN 0 ELSE CallsReadsOneSr/CallsCountOneSr END),
       'AvgReadsJointCalls'  = ( CASE WHEN CallsCountMultiSr = 0 THEN 0 ELSE CallsReadsMultiSr/CallsCountMultiSr END),
       'AvgReadsCalls'       = ( CASE WHEN CallsCountTotal = 0   THEN 0 ELSE CallsReadsCount/CallsCountTotal END),
       -- Blackbooks - Avg Reads
       'AvgReadsSingleBlackbooks'  = ( CASE WHEN BBCountOneSr = 0      THEN 0 ELSE BBReadsOneSr/BBCountOneSr END),
       'AvgReadsJointBlackbooks'   = ( CASE WHEN BBCountMultiSr = 0    THEN 0 ELSE BBReadsMultiSr/BBCountMultiSr END),
       'AvgReadsBlackbooks'        = ( CASE WHEN BBCountTotal = 0      THEN 0 ELSE BBReadsCount/BBCountTotal END),
       A.AnalystId
FROM #AnalystTotals A

*/
