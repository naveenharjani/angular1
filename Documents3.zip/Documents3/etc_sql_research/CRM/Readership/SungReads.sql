-- SungReads.sql
-- 07/05/2017

-- SLXPRDDB,16083: research_db_svc

-- 07/05/2017: McGranahan, Colin
-- Could someone pull readership data for the final 24 months� of Derrick�s published research?

DECLARE @vAnalystId		VARCHAR(100)
DECLARE @vSinceDate		VARCHAR(100)
DECLARE @vUntilDate		VARCHAR(100)

SET @vAnalystId = 412			-- 'Derrick Sung'
SET @vSinceDate = '04/10/2013'  -- final 24 months
SET @vUntilDate = '04/10/2015'  -- date of last published research

SET NOCOUNT ON

EXEC SlxExternal.[dbo].[GetReadSummary] @vAnalystId, @vSinceDate, @vUntilDate


/*
USE SlxExternal
GO
SELECT * FROM RVAnalysts where name like '%Derrick%'
SELECT * FROM RVDocAnalysts WHERE AnalystId = 412 ORDER BY DocId DESC
SELECT * FROM RVDocuments WHERE DocId = 111729
GO
*/