-- a.martin@mwam.com.sql
-- 05/13/2020

-- compassdb, 16083 | research_db_svc

-- identify what the user 'a.martin@mwam.com.sql' user might be doing when accessing research
-- 1. using link products such as summary or cart to get multiple links and use script/bot to attempt 
-- access a report, as multiple read attempts occuring in a few minutes time 
-- 2. identify read activity for success vs failure reads
-- 3. identify link products used each day by the user
-- 4. user does not have product group access for certain industry/region e.g. Pan-Euro

USE SlxExternal
GO

-- Reads summary by user email - then by year, month, success/failure
select
  C.LoginId,
  YEAR(C.AccessDate) AS Year,
  MONTH(C.AccessDate) AS Month,
  COUNT(*) AS Reads,
  SUM(CASE WHEN RVL.StatusId IN (100, 101) THEN 1 ELSE 0 END) AS Success,
  SUM(CASE WHEN RVL.StatusId NOT IN (100, 101) THEN 1 ELSE 0 END) AS Failure,
  SUM(CASE WHEN RVL.StatusId = 21 THEN 1 ELSE 0 END) AS ProductGroupAccessError,
  SUM(CASE WHEN RVL.StatusId = 63 THEN 1 ELSE 0 END) AS FileStreamingError
from SlxExternal.dbo.ContentUsage C
join SlxExternal.dbo.RVLinkStatus RVL on C.Status = RVL.StatusId
where LoginId = 'a.martin@mwam.com'
group by LoginId, YEAR(C.AccessDate), MONTH(C.AccessDate)
order by 1, 2, 3

-- Reads summary by user email - then by day, source
select
  C.LoginId,
  CAST(C.AccessDate AS DATE) AS AccessDate,
  RVS.Source,
  COUNT(*) AS Reads
from SlxExternal.dbo.ContentUsage C
join SlxExternal.dbo.RVLinkStatus RVL on C.Status = RVL.StatusId
join SlxExternal.dbo.RVLinkSources RVS on C.SourceId = RVS.SourceId
where LoginId = 'a.martin@mwam.com'
AND CAST(C.AccessDate AS DATE) >= '04/01/2020'
group by LoginId, CAST(C.AccessDate AS DATE), RVS.Source
order by 1, 2 desc, 3


/*

-- detail rows for failures
select distinct C.LoginId, C.AccessDate, RVL.Status, C.Status, C.ContentId, C.ContentTypeId, RVS.Source, RVP.Product
from SlxExternal.dbo.ContentUsage C
join SlxExternal.dbo.RVLinkStatus RVL on C.Status = RVL.StatusId
join SlxExternal.dbo.RVLinkSources RVS on C.SourceId = RVS.SourceId
join SlxExternal.RVLinkProducts RVP on RVS.ProductId = RVP.ProductId
where LoginId = 'a.martin@mwam.com' and C.Status NOT IN (100, 101)
and C.Status = 21 -- Product Group access error
ORDER by C.LoginId, C.AccessDate

-- Check activity logging in ContentUsage
select  * from SlxExternal.dbo.ContentUsage where LoginId = 'a.martin@mwam.com' ORDER By AccessDate desc

*/
