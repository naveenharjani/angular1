-- MobileReads.sql
-- 04/11/2018

-- Colin: 
-- Mobile Reads for 2017 - Client Filtered Reads vs Staff Clicks - provide breakdown

USE SlxExternal
GO

SELECT year(READ_DATE) AS 'Year', 
       COUNT(Distinct A.AccountId) as 'NumClients', 
       COUNT(Distinct vu.ContactId) as 'NumContacts',
	   COUNT(*) AS 'NumReadsClient'
--SELECT top 100 vu.READ_DATE, PUBNO, Source, vu.ContactId, A.AccountId
FROM vwUniqueReaders vu
JOIN SalesLogix.sysdba.Contact C ON C.ContactId = vu.SLXContactID
JOIN SalesLogix.sysdba.ACCOUNT A ON A.AccountId = C.AccountId
WHERE year(READ_DATE) = 2017 AND Source IN ('iPad', 'iPhone')
GROUP BY year(READ_DATE)


-- Filtered reads - Client
SELECT year(READ_DATE) AS 'Year', COUNT(*) AS 'NumReadsClient', COUNT(Distinct ContactId) as 'NumClients'
FROM vwUniqueReaders
WHERE year(READ_DATE) = 2017 AND Source IN ('iPad', 'iPhone')
GROUP BY year(READ_DATE)

-- Raw clicks - Staff
SELECT year(ACCESSDATE) AS 'Year', COUNT(*) AS 'NumClicksStaff', COUNT(Distinct ACCESS_EMAIL_ADDR) as 'NumStaff' 
FROM WebUsage
WHERE year(ACCESSDATE) = 2017 AND SourceId IN (30,31)
AND (ACCESS_EMAIL_ADDR like '%bernstein%' OR ACCESS_EMAIL_ADDR like '%abglobal%')
GROUP BY year(ACCESSDATE)

-- Raw clicks - Client
SELECT year(ACCESSDATE) AS 'Year', COUNT(*) AS 'NumClicksClient'
FROM WebUsage
WHERE year(ACCESSDATE) = 2017 AND SourceId IN (30,31)
AND (ACCESS_EMAIL_ADDR not like '%bernstein%' AND ACCESS_EMAIL_ADDR not like '%abglobal%')
GROUP BY year(ACCESSDATE)
