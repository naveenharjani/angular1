-- Sector_Firm_Reports.sql
-- Database: SLXPRDDB\SALGX_PRD,16083 | ResearchSvc

USE SlxExternal
GO


-- Sector reads summary
SELECT DISTINCT
'Sector'   = convert(varchar(30), RVS.Sector),
'Account'  = convert(varchar(40), A.Account),
'Tier'     = convert(varchar(40), AE.Tier),
'Reads'    = COUNT(*),
'Reports'  = COUNT(DISTINCT PubNo)
FROM dbo.SCB_UNIQUE_READERS UR
INNER JOIN RVDocuments RVD ON RVD.DocId = UR.PubNo
INNER JOIN RVDocIndustries RVDI ON RVDI.DocId = RVD.DocId AND RVDI.OrdinalId = (SELECT MIN(ORDINALID) FROM RVDocIndustries WHERE DocId = RVDI.DocId)
INNER JOIN RVIndustries RVI ON RVI.IndustryId = RVDI.IndustryId
INNER JOIN RVSectors RVS ON RVS.SectorId = RVI.SectorId
INNER JOIN SalesLogix.sysdba.CONTACT AS C ON C.CONTACTID = UR.CONTACTID
INNER JOIN SalesLogix.sysdba.ACCOUNT AS A ON C.ACCOUNTID = A.ACCOUNTID
INNER JOIN Saleslogix.sysdba.inf_account_ext AE ON AE.AccountId = A.AccountId
WHERE UR.Read_Date >= getdate() - 7
GROUP BY RVS.Sector, A.Account, AE.Tier
ORDER BY 1, 4 desc


-- Sector reads detail
SELECT DISTINCT 
'Sector'  = convert(varchar(30), RVS.Sector),
'Account' = convert(varchar(40), A.Account),
'Date'    = CONVERT(varchar, RVD.Date,101),
'Title'   = convert(varchar(80), RVD.Title),
'Tickers' = STUFF(( 
                   SELECT ', ' + Ticker AS [text()] FROM SlxExternal.dbo.RVDocSecurities WHERE DocId = RVD.DocId
                   ORDER BY OrdinalId
                   FOR XML PATH('')
                   ), 1, 1, '' ),
'Reads'   = COUNT(*),
RVD.DocId,
RVD.Date
FROM dbo.SCB_UNIQUE_READERS UR
INNER JOIN RVDocuments RVD ON RVD.DocId = UR.PubNo
INNER JOIN RVDocIndustries RVDI ON RVDI.DocId = RVD.DocId AND RVDI.OrdinalId = (SELECT MIN(ORDINALID) FROM RVDocIndustries WHERE DocId = RVDI.DocId)
INNER JOIN RVIndustries RVI ON RVI.IndustryId = RVDI.IndustryId
INNER JOIN RVSectors RVS ON RVS.SectorId = RVI.SectorId
INNER JOIN SalesLogix.sysdba.CONTACT AS C ON C.CONTACTID = UR.CONTACTID
INNER JOIN SalesLogix.sysdba.ACCOUNT AS A ON C.ACCOUNTID = A.ACCOUNTID
WHERE UR.Read_Date >= getdate() - 7
GROUP BY RVS.Sector, A.Account, RVD.Date, RVD.Title, RVD.DocId
ORDER BY 1, 2, COUNT(*) DESC, RVD.Date DESC


/*
--Get Distinct Research Sectors
SELECT        SectorId, Sector         FROM       dbo.RVSectors  WHERE        (SectorId > 0)

--Get Distinct SLX Accounts
SELECT        ACCOUNTID, ACCOUNT, TYPE
FROM            SalesLogix.sysdba.ACCOUNT
ORDER BY ACCOUNT

--Accts with reads in last n days
SELECT DISTINCT A.ACCOUNTID, A.ACCOUNT, A.TYPE
FROM dbo.SCB_UNIQUE_READERS UR
INNER JOIN SalesLogix.sysdba.CONTACT AS C ON C.CONTACTID = UR.CONTACTID
INNER JOIN SalesLogix.sysdba.ACCOUNT AS A ON C.ACCOUNTID = A.ACCOUNTID
WHERE UR.Read_Date >= getdate() - 7       -- Last 7 Days
ORDER BY A.Account


-- Sector, Account, Report Title, PubNo listing [Detailed Reads View]
SELECT --TOP 100
  RVS.Sector,
  A.Account,
  RVD.Title,
  UR.PubNo
-- A.Type, C.Email, UR.Read_Date, RVDI.Industry, C.LastName, C.FirstName, RVD.Date, RVD.Title, RVD.DocTypeId, UR.SourceId, UR.ContactId
FROM dbo.SCB_UNIQUE_READERS UR
INNER JOIN RVDocuments RVD ON RVD.DocId = UR.PubNo
INNER JOIN RVDocIndustries RVDI ON RVDI.DocId = RVD.DocId AND RVDI.OrdinalId = (SELECT MIN(ORDINALID) FROM RVDocIndustries WHERE DocId = RVDI.DocId)
INNER JOIN RVIndustries RVI ON RVI.IndustryId = RVDI.IndustryId
INNER JOIN RVSectors RVS ON RVS.SectorId = RVI.SectorId
INNER JOIN SalesLogix.sysdba.CONTACT AS C ON C.CONTACTID = UR.CONTACTID
INNER JOIN SalesLogix.sysdba.ACCOUNT AS A ON C.ACCOUNTID = A.ACCOUNTID
WHERE UR.Read_Date >= getdate() - 7       -- Last 7 Days
ORDER BY RVS.Sector, A.Account, UR.READ_DATE DESC

*/