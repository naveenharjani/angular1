use SlxExternal
go

select top 500 * from vwUniqueReaders
where READ_DATE >= '6/16/2018'

select *
from ContentUsage
where ContentTypeId = 'R'
and SourceInternal = 0
order by SourceId, UsageId


-- Summary
select LS.Source, count(*) as 'Num Clicks'
from ContentUsage CU
join RVLinkSources LS on LS.SourceId = CU.SourceId
where ContentTypeId = 'R'
and SourceInternal = 0
group by LS.Source

-- Detail
select LS.Source, CU.*
from ContentUsage CU
join RVLinkSources LS on LS.SourceId = CU.SourceId
where ContentTypeId = 'R'
--and SourceInternal = 0
order by 1, 2

-- Error messages

select * from RVLinkStatus

-- Summary
select CU.Status, LS.Status, count(*) as 'Num Messages'
from ContentUsage CU
join RVLinkStatus LS on LS.StatusId = CU.Status
where ContentTypeId = 'R'
and SourceInternal = 0
group by CU.Status, LS.Status

-- Detail
select LS.Status, *
from ContentUsage CU
join RVLinkStatus LS on LS.StatusId = CU.Status
where CU.ContentTypeId = 'R' and CU.Status <> 100
-- and CU.SourceInternal = 0
order by CU.UsageId

-- How many contacts entered bad password followed by good password?

select distinct LoginId from ContentUsage CU where CU.Status = 100
and ContactId in (select ContactId from ContentUsage CU where CU.Status = 12)

select distinct LoginId from ContentUsage CU where CU.Status = 12
and ContactId not in (select ContactId from ContentUsage CU where CU.Status = 100)

select distinct LoginId from ContentUsage CU where CU.Status <> 100
and ContactId not in (select ContactId from ContentUsage CU where CU.Status = 100)

--
select * from ContentUsage CU where CU.Status = 12 order by UsageId desc

select * from ContentUsage CU where CU.UserHost = '63.232.239.4'

select top 500 * from vwUniqueReaders order by READ_DATE desc

select top 500 * from vwUniqueReadersOrig order by READ_DATE desc

select * from RVLinkProducts
select * from RVLinkSources

select *
from vwUniqueReaders UR
join RVLinkSources RVLS on RVLS.SourceId = UR.SourceId
where PubNo >= 139281
and (RVLS.ProductId in (7, 2) or UR.SourceId in (45))
order by UR.SourceId

--

-- Migrated
-- ProductId
-- 3 BR.com
-- 7 Most Popular
-- 2 Summary
-- SourceId
-- 45 Sector Specialist
-- 5  Cart - Highlights
-- 2  Cart - Links
-- 3  Embed Link
-- 44  Algo

select
  'Total' = COUNT(*),
  'OldStreamer' = SUM(CASE WHEN RVLS.ProductId NOT IN (3, 7, 2) AND UR.SourceId NOT IN (45, 2, 3, 5, 44) THEN 1 ELSE 0 END),
  'NewStreamer' = SUM(CASE WHEN RVLS.ProductId IN (3, 7, 2) OR UR.SourceId IN (45, 2, 3, 5, 44) THEN 1 ELSE 0 END)
from SlxExternal.dbo.vwUniqueReaders UR
join SlxExternal.dbo.RVLinkSources RVLS on RVLS.SourceId = UR.SourceId
where PubNo >= (select min(DocId) from RVDocuments where Date = '07/27/2018')
and RVLS.ProductId <> 9
-- where PubNo >= 139281 -- 7/2/2018

select RVLP.Product, count(*) as 'Reads'
from SlxExternal.dbo.vwUniqueReaders UR
join SlxExternal.dbo.RVLinkSources RVLS on RVLS.SourceId = UR.SourceId
join SlxExternal.dbo.RVLinkProducts RVLP on RVLP.ProductId = RVLS.ProductId
where PubNo >= (select min(DocId) from RVDocuments where Date = '07/16/2018')
group by RVLP.Product
with rollup
order by 2 desc

select min(DocId) from RVDocuments where Date = '07/02/2018'
select min(DocId) from RVDocuments where Date = '07/16/2018'

select * from RVLinkSources
select * from RVLinkProducts

select top 500 * from SlxExternal.dbo.vwUniqueReaders

-- Stacy

select * from ContentUsage

select * from RVLinkStatus

select * from ContentUsage CU where CU.Status <> 100 and ContentId in (139903, 139905)

select distinct CU.LoginId, RVLS.Status
from ContentUsage CU
join SlxExternal.dbo.RVLinkStatus RVLS on RVLS.StatusId = CU.Status
where CU.Status <> 100
and ContentId in (139903, 139905)
-- and ContactId not in (select ContactId from ContentUsage CU where CU.Status = 100 and ContentId in (139903, 139905))
order by 2

select distinct CU.ContentId, CU.LoginId, RVLS.Status
from ContentUsage CU
join SlxExternal.dbo.RVLinkStatus RVLS on RVLS.StatusId = CU.Status
where CU.Status = 100
and ContentId in (139903, 139905)
order by 3

-- Stacy
select * from ContentUsage
where LoginId in ('dkanter@realworldtech.com', 'alexander.straub@bmw.de', 'dan.gallagher@wsj.com')

select * from WebUsage
where ACCESS_EMAIL_ADDR in ('dkanter@realworldtech.com', 'alexander.straub@bmw.de', 'dan.gallagher@wsj.com')
order by ACCESSDATE desc

--

--List of all publications along with their email blast type (auto/manual)
--This query needs to be run in Research db
select P.PubNo, P.Title, P.Date ReportDate,P.PublishedDate, case when ABQ.Pubno is not null then 1 else 0 end IsAuto
from Publications P left outer join AnalystBlastQueue ABQ on P.Pubno = ABQ.Pubno
where 
P.PubNo >= (select min(DocId) from RVDocuments where Date >= '08/23/2018') 
--and ABQ.Completed is not null and ABQ.Cancelled is null
order by P.PubNo desc


-- Bruno
select * from ContentUsage
where LoginId in ('dkanter@realworldtech.com', 'alexander.straub@bmw.de', 'dan.gallagher@wsj.com')

select * from WebUsage
where ACCESS_EMAIL_ADDR in ('dkanter@realworldtech.com', 'alexander.straub@bmw.de', 'dan.gallagher@wsj.com')
order by ACCESSDATE desc

-- Andrew

select * from ContentUsage


select top 500 RVLS.Source, * from ContentUsage CU join RVLinkSources RVLS on RVLS.SourceId = CU.SourceId
where LoginId like '%unilever%'


order by 1


select count(*) from WebUsage
