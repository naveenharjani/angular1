-- Read_Analysis.sql
-- 06/05/2019

/*
PRD : SLXPRDDB,16083 | Database=Compass | User ID=research_db_svc

- List Contacts with most reads by date
- List Contacts with most reads by month
- List Contacts with most reads in a date range
- Identify if any high reads by '@allianzgi.com' contacts
*/

DECLARE
 @vSinceDate		VARCHAR(100),
 @vUntilDate		VARCHAR(100)

SET @vSinceDate = '01/01/2019'
SET @vUntilDate = getdate()

-- List contacts with most reads by date
SELECT C.ContactName, C.Email, v1.Date, v1.Reads, A.AccountName, C.ContactId
FROM 
    (SELECT ContactId, 'Date' = CAST(READ_DATE AS DATE), 'Reads' = COUNT(*) FROM SlxExternal.dbo.vwUniqueReaders with (nolock)
     WHERE READ_DATE BETWEEN @vSinceDate AND @vUntilDate
     GROUP BY ContactId, CAST(READ_DATE AS DATE)) AS v1
LEFT JOIN Compass.dbo.Contact C with (nolock) ON C.ContactId = v1.ContactId
LEFT JOIN Compass.dbo.Account A ON  A.AccountId = C.AccountId
WHERE v1.Reads > 100  -- #reads in last n days
ORDER BY v1.Reads DESC

/*
-- Contacts with most reads by date
Email                                 Date          Reads
stephanie.luong@asia.bnpparibas.com	  2019-03-05	  410
ksaberwal@rwbaird.com.x	              2019-03-24	  331
ksaberwal@rwbaird.com.x	              2019-03-23	  289
david.sun@abglobal.com	              2019-02-23	  285
saiqi@avcadvisors.com	                2019-02-20	  249
ksaberwal@rwbaird.com.x	              2019-03-26	  233
saiqi@avcadvisors.com	                2019-03-01	  220
fs@veritasinvestment.co.uk	          2019-02-13	  219
dario.popadic@investecmail.com	      2019-01-23	  209
ksaberwal@rwbaird.com.x	              2019-03-27	  202


SELECT LoginId, ContentId, AccessDate, UserHost FROM slxexternal.dbo.ContentUsage w
WHERE LoginId = 'stephanie.luong@asia.bnpparibas.com' AND CAST(AccessDate as DATE) = '2019-03-05'
ORDER BY w.AccessDate DESC

SELECT LoginId, ContentId, AccessDate, UserHost FROM slxexternal.dbo.ContentUsage w
WHERE LoginId = 'ksaberwal@rwbaird.com.x'
ORDER BY w.AccessDate DESC

SELECT LoginId, ContentId, AccessDate, UserHost FROM slxexternal.dbo.ContentUsage w
WHERE LoginId = 'saiqi@avcadvisors.com' AND CAST(AccessDate as DATE) IN ('2019-02-20', '2019-03-01')
ORDER BY w.AccessDate DESC

SELECT LoginId, ContentId, AccessDate, UserHost FROM slxexternal.dbo.ContentUsage w
WHERE LoginId = 'fs@veritasinvestment.co.uk' AND CAST(AccessDate as DATE) IN ('2019-02-13')
ORDER BY w.AccessDate DESC
*/

-- Identify if any high reads by '@allianzgi.com' contacts (Allianz Global Investors California)
SELECT LoginId, ContentId, AccessDate, UserHost FROM slxexternal.dbo.ContentUsage w
WHERE LoginId like '%allianzgi.com' 
--WHERE LoginId = 'kimberlee.millar@allianzgi.com' 
--WHERE LoginId like '%allianzgi.com'
ORDER BY w.AccessDate DESC

SELECT Access_Email_Addr, 'Clicks' = COUNT(*) FROM SlxExternal.dbo.WebUsage
WHERE Access_Email_Addr like '%allianzgi.com'
--AND Year(ACCESSDATE) = 2018
GROUP BY Access_Email_Addr
ORDER BY COUNT(*) DESC

SELECT * FROM SlxExternal.dbo.WebUsage
WHERE Access_Email_Addr like '%allianzgi.com'
--WHERE Access_Email_Addr = 'Kimberlee.Millar@allianzgi.com'
--WHERE Access_Email_Addr = 'rahul.bengani@allianzgi.com'
--AND Year(ACCESSDATE) = 2018
ORDER BY ACCESSDATE DESC

/*
-- List contacts with most reads by month
SELECT C.ContactName, C.Email, v1.Year, v1.Month, v1.Reads, A.AccountName
FROM 
    (SELECT ContactId, 'Year' = Year(READ_DATE), 'Month' = Month(READ_DATE), 'Reads' = COUNT(*) FROM SlxExternal.dbo.vwUniqueReaders with (nolock)
     WHERE READ_DATE BETWEEN @vSinceDate AND @vUntilDate
     GROUP BY ContactId, Year(READ_DATE), Month(READ_DATE)) AS v1
LEFT JOIN Compass.dbo.Contact C with (nolock) ON C.ContactId = v1.ContactId
LEFT JOIN Compass.dbo.Account A ON  A.AccountId = C.AccountId
WHERE v1.Reads > 100  -- #reads in last n days
ORDER BY v1.Reads DESC

-- List contacts with most reads in a date range
SELECT C.ContactName, C.Email, v1.Reads, A.AccountName
FROM 
    (SELECT ContactId, 'Reads' = COUNT(*) FROM SlxExternal.dbo.vwUniqueReaders with (nolock)
     WHERE READ_DATE BETWEEN @vSinceDate AND @vUntilDate
     GROUP BY ContactId) AS v1
LEFT JOIN Compass.dbo.Contact C with (nolock) ON C.ContactId = v1.ContactId
LEFT JOIN Compass.dbo.Account A ON  A.AccountId = C.AccountId
WHERE v1.Reads > 200  -- #reads in last n days
AND A.AccountName like '%Allianz%'
ORDER BY v1.Reads DESC

SELECT * FROM Account WHERE accountName like '%allianz%'  -- Allianz Global Investors California

SELECT * FROM Contact WHERE AccountId = 'A000000000007425'


*/