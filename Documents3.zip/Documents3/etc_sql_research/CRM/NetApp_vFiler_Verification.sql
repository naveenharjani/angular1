-- NetApp_vFiler_Verification.sql
-- 09/22/2014

-- During the 10 minute window when maintenance is performed on researchfs vfiler, 
-- The program uses try/catch to use researchfs [R/W] /researchfs2 [R/O mirroring] share

SELECT TOP 5000
  U.PUBNO,
  U.ACCESSDATE,
  U.CREATEDATE,
  U.ACCESS_EMAIL_ADDR,
  U.SOURCEID,
  RVLS.Source,
  U.STATUS,
  U.FILEFOUND,
  U.SERVER_NAME,
  U.CONTENT_SOURCE,
  U.SOURCE_INTERNAL,
  RVD.Date, 
  RVD.Title
FROM sysdba.scb_web_usage U
INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId = U.PUBNO
LEFT JOIN SlxExternal.dbo.RVLinkSources RVLS ON RVLS.SourceId = U.SOURCEID
WHERE ACCESS_EMAIL_ADDR = 'naveen.harjani@alliancebernstein.com'
 --AND CONTENT_SOURCE LIKE 'links2%'        -- uses researchfs  vfiler [R/W]
 --AND CONTENT_SOURCE LIKE 'links%'         -- uses researchfs2 vfiler [R/O]
 --AND CONTENT_SOURCE LIKE 'cache%'         -- uses local cache
ORDER BY ACCESSDATE DESC