-- Distribution2_0.sql
-- 09/21/2017

USE SlxExternal
GO

-- Existing usage tables

select top 100 * from dbo.WebUsage order by WebUsageId desc

select top 100 * from dbo.UsageLogshipper order by UsageId desc

select top 100 * from dbo.RVPortalUsage order by UsageId desc

select top 100 * from [SlxExternal].[dbo].[WSGSiteActivity] order by DateTimeStamp desc

select STATUS, count(*) from dbo.WebUsage group by STATUS -- T, F
select * from dbo.WebUsage where STATUS = 'F'  order by WebUsageId desc

select FILEFOUND, count(*) from dbo.WebUsage group by FILEFOUND -- T, F, U
select * from dbo.WebUsage where FILEFOUND = 'U'  order by WebUsageId desc

select CONTENT_SOURCE, count(*) from SlxExternal.dbo.WebUsage group by CONTENT_SOURCE  -- All "ADMIN"

select SOURCE_INTERNAL, count(*) from dbo.WebUsage group by SOURCE_INTERNAL -- T, F, NULL
select * from dbo.WebUsage where SOURCE_INTERNAL = 'T'  order by WebUsageId desc

select NUMOFACCESS, count(*) from dbo.WebUsage group by NUMOFACCESS -- All 1
select INFO from dbo.WebUsage                                      -- All null?
select CREATEUSER, count(*) from dbo.WebUsage group by CREATEUSER  -- All "ADMIN"
select MODIFYUSER, count(*) from dbo.WebUsage group by MODIFYUSER  -- All "ADMIN"
select MODIFYDATE, count(*) from SlxExternal.dbo.WebUsage group by MODIFYDATE

-- New Usage table

select top 10 * from dbo.WebUsage order by WebUsageId desc

-- Existing WebUsage - columns reordered, renamed or excluded

select top 10
  WebUsageId          as UsageId,
  ACCESS_EMAIL_ADDR   as LogonId,
  1                   as ContentType,
  PUBNO               as ContentId,
  SOURCEID            as LinkSourceId,
  ACCESSDATE          as AccessDate,
  CREATEDATE          as LogDate,
  CONTACTID           as ContactId,
  STATUS              as Status,
  FILEFOUND           as FileFound,
  SOURCE_INTERNAL     as SourceInternal,
  CONTENT_SOURCE      as ContentSource,
  SERVER_NAME         as ServerName,
  DOMAIN_NAME         as UserHost,
  USER_AGENT          as UserAgent,
  ''                  as 'NOT USED',
  NUMOFACCESS,
  INFO,
  CREATEUSER,
  MODIFYUSER,
  MODIFYDATE
from SlxExternal.dbo.WebUsage order by WebUsageId desc

-- ***
-- *** READERSHIP VIEW
-- ***

-- Master "Reads" view - Current
select top 10 * from Saleslogix.sysdba.vw_Readership order by ACCESSDATE desc

-- Master "Reads" view - Proposed
select top 10
  'Research' as TYPE,
  PUBNO as ID,
  'Links' as PLATFORM,
  LP.Product,
  R.SOURCE,
  ACCESSDATE,
  CONTACTID,
  ACCOUNTID
from Saleslogix.sysdba.vw_Readership R 
join SlxExternal.dbo.RVLinkSources LS on R.SOURCE = LS.Source
join SlxExternal.dbo.RVLinkProducts LP on LP.ProductId = LS.ProductId
where Type = 'RESEARCHUSAGE'

union

select top 10
  'Research' as TYPE,
  PUBNO   as ContentId,
  'Portal' as PLATFORM,
  SOURCE,
  SOURCE,
  ACCESSDATE,
  CONTACTID,
  ACCOUNTID
from Saleslogix.sysdba.vw_Readership where Type = 'PORTALUSAGE'

union select 'Model', 999, 'BR.com', '?', 'BR.com', getdate(), 'ABC', 'XYZ'
union select 'Deck', 999, 'BR.com', '?', 'Links', getdate(), 'ABC', 'XYZ'

union select 'Research', 999, 'Portal', '?', 'AlphaSense', getdate(), 'ABC', 'XYZ'
union select 'Model', 999, 'Portal', '?', 'visible alpha', getdate(), 'ABC', 'XYZ'
union select 'Deck', 999, 'Portal', '?', '', getdate(), 'ABC', 'XYZ'

order by ACCESSDATE desc

--

select count(*) Num from Saleslogix.sysdba.vw_Readership

select Type, count(*) Num from Saleslogix.sysdba.vw_Readership group by Type with rollup

select SOURCE, count(*) Num from Saleslogix.sysdba.vw_Readership group by SOURCE with rollup order by Num

-- Existing WebUsage
select top 10 * from SlxExternal.dbo.WebUsage order by WebUsageId desc

-- Proposed ContentUsage
select top 10
  WebUsageId          as UsageId,
  ACCESS_EMAIL_ADDR   as LogonId,
  'R'                 as ContentType,
  PUBNO               as ContentId,
  1                   as AuthenticationCheck,
  1                   as EntitlementCheck,
  1                   as QuotaCheck,
  SOURCEID            as LinkSourceId,
  ACCESSDATE          as AccessDate,
  CREATEDATE          as LogDate,
  0                   as Status,
  CONTACTID           as ContactId,
  'ce6922bb270f62daaf51bc11aa63f1408b08248184c9e083443ca9cf83ad4db5' as EncryptedPayload,
  'R,127662,1,1,1,0'  as DecryptedPayload,
  SOURCE_INTERNAL     as SourceInternal,
  CONTENT_SOURCE      as ContentSource,
  SERVER_NAME         as ServerName,
  DOMAIN_NAME         as UserHost,
  USER_AGENT          as UserAgent
from SlxExternal.dbo.WebUsage order by WebUsageId desc

