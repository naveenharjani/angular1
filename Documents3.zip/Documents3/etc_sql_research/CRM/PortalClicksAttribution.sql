-- PortalClicksAttribution.sql
-- 04/01/2019

-- CRM
-- PRD: SLXPRDDB,16083
-- DEV: D05UE0100\COMPASSDEV
-- QA:  D05UE0100\COMPASSQA

-- Orphan analysis - Clicks and embargo
-- Join Condition:  Slxexternal..RVPortalUsage.ContactId = Compass.dbo.ContactServices.ServiceID

-- 2016-2018
DECLARE @SinceDate DATETIME,
        @UntilDate DATETIME,
        @SiteId    INT
SET @SinceDate = '01/01/2016'
SET @UntilDate = '12/31/2018'
SET @SiteId = 3 -- Bloomberg

-- Get Portal clicks group count by portal - attributed, unattributed, null contactId
SELECT V.Clicks, 
       '#ClicksAttributed'     = V.ClicksAttributed,
       '%ClicksAttributed'     = CONVERT(numeric(10,2), (V.ClicksAttributed * 100.0 / V.Clicks)),
       '#ClicksUnattributed'   = V.ClicksUnattributed,   
       '%ClicksUnattributed'   = CONVERT(numeric(10,2), (V.ClicksUnattributed * 100.0 / V.Clicks)),
       '#ClicksNullContactIds' = V.ClicksNullContactIds,
       '%ClicksNullContactIds' = CONVERT(numeric(10,2), (V.ClicksNullContactIds * 100.0 / V.Clicks))
FROM
(
SELECT 'Clicks'               = (SELECT COUNT(*) FROM SlxExternal..RVPortalUsage
                                 WHERE ReadDate BETWEEN @SinceDate AND @UntilDate
                                 AND SiteId = @SiteId
                                 ),
       'ClicksAttributed'     = (SELECT COUNT(*) FROM SlxExternal..RVPortalUsage
                                 WHERE ReadDate BETWEEN @SinceDate AND @UntilDate
                                   AND ContactId IN (SELECT DISTINCT CS.ServiceID FROM Compass.dbo.ContactServices CS 
                                                     WHERE CS.ServiceId IS NOT NULL AND CS.ServiceType = 'PortalEntitlement') 
                                   AND SiteId = @SiteId 
                                   ),
       'ClicksUnattributed'   = (SELECT COUNT(*) FROM SlxExternal..RVPortalUsage
                                 WHERE ReadDate BETWEEN @SinceDate AND @UntilDate
                                   AND ContactId NOT IN (SELECT DISTINCT CS.ServiceID FROM Compass.dbo.ContactServices CS 
                                                         WHERE CS.ServiceId IS NOT NULL AND CS.ServiceType = 'PortalEntitlement') 
                                   AND SiteId = @SiteId 
                                   ),
       'ClicksNullContactIds' = (SELECT COUNT(*) FROM SlxExternal..RVPortalUsage
                                 WHERE (ReadDate BETWEEN @SinceDate AND @UntilDate)
                                   AND ContactId IS NULL 
                                   AND SiteId = @SiteId
                                   )
) V


-- ContactId in RVPortalUsage Not found not in ContactServices
SELECT DISTINCT RVPU.Site, RVPU.ContactId
FROM Slxexternal..RVPortalUsage RVPU
WHERE RVPU.ContactId NOT IN (SELECT DISTINCT CS.ServiceID FROM Compass.dbo.ContactServices CS
                             WHERE CS.ServiceId IS NOT NULL
                             AND CS.ServiceType = 'PortalEntitlement')
ORDER BY 1, 2


-- Portal ContactId (PortalUsage) with matching/non-matching ServiceId in CRM (e.g. Bloomberg)
SELECT
       Pu.ReadDate, Pu.PubNo, Pu.Site, Pu.Email, Pu.ContactId, Pu.Contact, Pu.AccountId, Pu.Account,
       cs.ServiceType, cs.ServiceName, cs.ServiceID, cs.ServiceStatus,
       c.ContactId, C.AccountId, C.LastName, C.FirstName
FROM slxexternal.dbo.RVPortalUsage Pu with (nolock) 
LEFT OUTER JOIN Compass.dbo.ContactServices cs with (nolock)
                ON cs.ServiceType = 'PortalEntitlement' and cs.ServiceName = 'Bloomberg' and cs.ServiceID = pu.ContactId
LEFT OUTER JOIN compass.dbo.contact c with (nolock) on cs.ContactID = c.ContactID
WHERE YEAR(Pu.ReadDate) = 2018 
AND Pu.SiteId = 3 -- Bloomberg
AND cs.ServiceID is null
ORDER BY Pu.ReadDate

/*
SELECT top 50000 * FROM SlxExternal..RVPortalUsage WHERE Site = 'Thomson Reuters' ORDER BY ReadDate desc
SELECT top 50000 * FROM SlxExternal..RVPortalUsage WHERE Site = 'Bloomberg (SANB)' ORDER BY ReadDate desc
SELECT top 50000 * FROM SlxExternal..RVPortalUsage WHERE Site = 'Factset' ORDER BY ReadDate desc
SELECT top 50000 * FROM SlxExternal..RVPortalUsage WHERE Site = 'CapitalIQ' ORDER BY ReadDate desc
*/