-- Colin.sql

-- Read Summary - 2013, 2012, 2011

-- Research
SELECT 
    'Year' = Year(RVD.Date), 
    'ID' = v1.PubNo, 
    RVD.Date,
    'Type' = -- Document type alias
    CASE
      WHEN  RVD.Title LIKE '%The Long View:%'              THEN 'LongView'
      WHEN  RVD.Title LIKE '%Best of Bernstein:%'          THEN 'BoB'
      WHEN (RVD.Title LIKE '%Weekend Media Blast:%'                 OR 
            RVD.Title LIKE '%Bernstein Commodities & Power Blast:%' OR
            RVD.Title LIKE '%U.S. Semiconductors Blast%'            OR
            RVD.Title LIKE '%Bernstein Semiconductor Blast%'        OR
            RVD.Title LIKE '%Bernstein Materials Blast:%') THEN 'Blast'
      WHEN  RVT.DocType = 'Research Note'                  THEN 'Note'
      WHEN  RVT.DocType = 'Black Book'                     THEN 'Blackbook'
      WHEN  RVT.DocType = 'White Book'                     THEN 'Whitebook'
      WHEN  RVT.DocType = 'Research Call'                  THEN 'Call'
      WHEN  RVT.DocType = 'External Flash'                 THEN 'Flash'
      ELSE  RVT.DocType
    END,
  RVD.Title,
  'Primary Author' = RVDA.Last,
  'Num Authors'   = (SELECT COUNT(*) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVD.DocId),
  'Rating Change' = (SELECT COUNT(*) FROM SlxExternal.dbo.RVFinancials  WHERE DocId = RVD.DocId AND RatingAction   IN ('Upgrade','Downgrade')),
  'Initiation'    = (SELECT COUNT(*) FROM SlxExternal.dbo.RVFinancials  WHERE DocId = RVD.DocId AND CoverageAction IN ('Initiate')),
  'Reads'        = v1.Read_Count
FROM
( SELECT PUBNO, 'Read_Count' = count(*) FROM SlxExternal.dbo.SCB_UNIQUE_READERS GROUP BY PUBNO ) AS v1
INNER JOIN SlxExternal.dbo.RVDocuments RVD ON RVD.DocId     = v1.PUBNO
INNER JOIN SlxExternal.dbo.RVTypes RVT     ON RVT.DocTypeId = RVD.DocTypeId
-- Primary analyst indicated by ordinal value
INNER JOIN SlxExternal.dbo.RVDocAnalysts RVDA on RVDA.DocId = v1.PUBNO
  AND RVDA.OrdinalId = (SELECT MIN(OrdinalId) FROM SlxExternal.dbo.RVDocAnalysts WHERE DocId = RVDA.DocId)
WHERE RVD.Date BETWEEN '01/01/2011' AND '12/31/2013'
  AND RVD.DocTypeId NOT IN (5)   --Exclude Research Summary Calls
  AND v1.PUBNO = RVD.DocId
ORDER BY RVD.Date DESC, V1.PubNo DESC
