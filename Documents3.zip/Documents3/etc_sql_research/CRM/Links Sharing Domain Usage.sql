Use SalesLogix
go
drop table #tmp_usage_share
go
--Inner Query - Returns All the valid email addresses with more than one domain usage
--Outer Query - For all the email addresses returned by the inner query, outputs domain name and the domain usage count
select access_email_addr,domain_name,count(*) Usage_Count
Into #tmp_usage_share
from
sysdba.scb_web_usage
where
access_email_addr in (select access_email_addr from sysdba.scb_web_usage where access_email_addr like '%@%' group by access_email_addr having count(distinct domain_name) > 1)
group by access_email_addr,domain_name
order by 
access_email_addr,count(*) desc

--Detail
select access_email_addr Access_Email,Domain_Name,Usage_Count 
from #tmp_usage_share
order by 1, 2

--Summary
select access_email_addr,count(domain_name) Domain_Count
from
#tmp_usage_share
group by access_email_addr
-- order by access_email_addr
order by 2 desc, 1
