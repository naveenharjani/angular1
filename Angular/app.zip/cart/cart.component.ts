import { Component, OnInit, ComponentFactoryResolver, ViewChild, ViewContainerRef } from '@angular/core';
import { DataService } from '../shared/data.service';
import { GridOptions, GridApi } from 'ag-grid-community';
import { BeehivePageHeaderComponent } from '../beehive-page-header/beehive-page-header.component';
import { BeehiveCookiesService } from '../shared/cookies.service';
import { CartOptionsComponent } from './cart-options/cart-options.component';
import { UtilityService } from '../shared/utility.service';
import { MatSnackBar } from '@angular/material';
import { BeehiveMessageService } from '../shared/message-service';
import { DatePipe } from '@angular/common';
import { CalendarUtility } from '../shared/calendar-utility';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  @ViewChild('container', { read: ViewContainerRef }) container: ViewContainerRef;
  @ViewChild('outlookintegration', { read: ViewContainerRef }) outlookintegration: ViewContainerRef;
  gridOptions: GridOptions;
  style: { width: string; height: string; theme: string; };
  columnDefs: any;
  beehivePageName: string;
  childComponent: BeehivePageHeaderComponent;
  rowData: any;
  pageSize: any = '500';
  hideHeaderButtons: boolean = true;
  gridApiParams: GridApi;
  calendarUtility: CalendarUtility = new CalendarUtility();
  constructor(private snackBar: MatSnackBar, private service: BeehiveMessageService, private dataService: DataService,
    private resolver: ComponentFactoryResolver, private datePipe: DatePipe,private cookiesService: BeehiveCookiesService) { }

  ngOnInit() {
    this.passValuestoGrid();
    if (this.cookiesService.GetUserID()) {
      this.dataService.getCart(this.cookiesService.GetUserID()).subscribe((data: any) => {
        if (data) {
          this.pageHeader();
          this.rowData = data;
          let fileNames = this.rowData.filter((data: any) => data.Content === 'Research').map((data: any) => data.FileName);
          let list = '';
          fileNames.forEach((data: any) => {
            list += data + '-';
          });
        }
      });
    }
  }


  passValuestoGrid() {
    this.style = { width: '100%', height: '400px', theme: 'ag-theme-balham my-grid' };
    this.columnDefs = [
      {
        headerName: 'Content',
        field: 'ContentType',
        width: 80
      },
      {
        headerName: 'Date',
        field: 'Date',
        width: 120,
        valueFormatter: function (params: any) {
         // return params.value == undefined ? '' : new UtilityService().LocalDateDisplayFormat(params.value);
         return params.value == undefined ? '' :self.datePipe.transform(self.calendarUtility.formatDate(params.value), 'dd-MMM-yyyy');
        }
      },
      {
        headerName: 'Type',
        field: 'Type',
        width: 150
      },
      {
        headerName: 'Title',
        field: 'Title',
        width: 430
      },
      {
        headerName: "Option", field: "id", width: 80, cellRendererFramework: CartOptionsComponent
      }
    ];
    var self = this;
    this.gridOptions = <GridOptions>{
      context: { componentParent: self },
    }
  }

  ngAfterContentInit() {
    let factory = this.resolver.resolveComponentFactory(BeehivePageHeaderComponent);
    let component = this.container.createComponent(factory);
    this.childComponent = component.instance;
    this.childComponent.beehivePageName = 'CART ';
    this.childComponent.onButtonClick.subscribe((buttonText: any) => {
      if (buttonText === 'remove all') {
        this.dataService.deleteCart(this.cookiesService.GetUserID()).subscribe(() => {
          this.gridOptions.rowData = [];
          this.gridApiParams.setRowData([]);
          this.service.changeMessage({ 'itemRemovedAll': true });
        });
      }
      if (buttonText === 'highlights') {
        if (this.gridOptions.rowData.length === 0) {
          this.snackBar.open('Highlights not available', 'Close', {
            duration: 2000
          });
        }
        else {
          let url = '/research/email.aspx?type=cart&id=' + this.cookiesService.GetUserID();
          //window.open(url.toString(), 'FORM', 'width=800,height=600,left=50,top=25,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=no', true);        
          window.open(url.toString(), 'FORM', 'left=50,top=50,width=1000,height=750,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
          return false;
        }
      }
      if (buttonText === 'links') {
        if (this.gridOptions.rowData.length === 0) {
          this.snackBar.open('Links not available', 'Close', {
            duration: 2000
          });
        }
        else {
          let url = '/research/email.aspx?type=cartlinks&id=' + this.cookiesService.GetUserID();
          window.open(url.toString(), 'FORM', 'left=50,top=50,width=1000,height=750,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
          return false;
        }
      }
      if (buttonText === 'batch print') {
        console.log(this.rowData);
        if (this.gridOptions.rowData.length > 0) {
          let fileNames = this.gridOptions.rowData.map((data: any) => data.FileName);
          let list = '';
          fileNames.forEach((data) => {
            list += data + '|';
          });
          let url = '/research/batchprint.aspx?Cart=' + (list.substr(0, (list.length - 1)));
          window.open(url.toString(), 'FORM', 'left=50,top=50,width=1000,height=750,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
          return false;
        }
      }
      if (buttonText === 'attachments') {
        if (this.gridOptions.rowData.length === 0) {
          this.snackBar.open('Attachments not available', 'Close', {
            duration: 2000
          });
        }
        else {
          let url = '/research/email.aspx?type=cartattachments&id=' + this.cookiesService.GetUserID();
          window.open(url.toString(), 'FORM', 'left=50,top=50,width=1000,height=750,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
          return false;
        }
      }
    });
  }

  pageHeader() {
    this.childComponent.buttonList = [{ text: 'Remove All', isRoleNeeded: false },
    { text: 'Batch Print', isRoleNeeded: false }, { text: 'Attachments', isRoleNeeded: false },
    { text: 'Links', isRoleNeeded: false }, { text: 'Highlights', isRoleNeeded: false }];
  }

  refresh(data: any) {
    let item = this.gridOptions.rowData.filter(v => v.ContentId === data.ContentId && v.ContentType === data.ContentType && v.Title === data.Title);
    this.gridOptions.rowData = this.gridOptions.rowData.filter((v) => v.ContentId !== item[0].ContentId);
    this.gridOptions.api.setRowData(this.gridOptions.rowData);
    this.service.changeMessage({ 'itemRemoved': true });
  }

  getDataSource(params: GridApi) {
    this.gridApiParams = params;
    if (this.rowData && this.rowData.length == 0) {
      this.gridOptions.rowData = [];
      this.gridOptions.api.setRowData([]);
    }
  }

}
