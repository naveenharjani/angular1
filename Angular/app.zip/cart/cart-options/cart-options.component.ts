import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BeehiveCookiesService } from '../../shared/cookies.service';
import { DataService } from '../../shared/data.service';

@Component({
  selector: 'app-cart-options',
  templateUrl: './cart-options.component.html',
  styleUrls: ['./cart-options.component.css']
})
export class CartOptionsComponent implements OnInit {

  constructor(private router: Router, private cookiesService: BeehiveCookiesService, private dataService: DataService) { }

  params: any;

  ngOnInit() {
  }

  agInit(params: any): void {
    this.params = params;
  }

  clickEmail() {
    let url = this.router.createUrlTree(['/email'], { queryParams: { style: 1, type: this.params.data.Type, id: this.params.data.ItemID } });
    window.open('#' + url.toString(), 'FORM', 'width=800,height=600,left=50,top=25,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
  }

  clickDelete() {
    let row = this.params.data;
    if (row.ContentType === 'Other') {
      row.ContentType = 'Asset';
    }
    let payload = {
      UserId: this.cookiesService.GetUserID(),
      ContentType: row.ContentType,
      ContentId: row.ContentId,
      Selected: false
    }
    this.dataService.saveCart(payload).subscribe((val) => {
      this.params.context.componentParent.refresh(this.params.data);
    });
  }

}
