import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { MatSnackBarModule } from '@angular/material';
import { CartComponent } from './cart.component';
import { AbGridModule } from '../ab-grid/ab-grid.module';
import { BeehiveCommonModule } from '../beehive-components.module';
import { BeehivePageHeaderModule } from '../beehive-page-header/beehive-page-header.module';
import { CartOptionsComponent } from './cart-options/cart-options.component';
import { MaterialModule } from '../material.module';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
    declarations: [CartComponent, CartOptionsComponent],
    imports: [AbGridModule, BeehiveCommonModule, CommonModule, BeehivePageHeaderModule, MatSnackBarModule, MaterialModule, ReactiveFormsModule],
    providers: [],
    entryComponents: [],
    exports: [CartComponent],
    bootstrap: [CartComponent]
})
export class CartModule {

}
