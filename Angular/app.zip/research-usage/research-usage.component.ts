import { Component, OnInit, ElementRef, Inject, ViewChild } from '@angular/core';
import { DataService } from '../shared/data.service';
import { UtilityService } from '../shared/utility.service';
import { Observable } from 'rxjs';
import {
    //Window,
    WINDOW_TOKEN
} from '../shared/active-xobject.service';


@Component({
    selector: 'app-research-usage',
    templateUrl: './research-usage.component.html',
    styleUrls: ['./research-usage.component.css']
})
export class ResearchUsageComponent implements OnInit {

    private gridApi;
    private gridColumnApi;
    rowData: any[];
    gridheight: boolean;
    paging = true;
    virtualRows: any;
    intrId: any;
    SinceDate: any;
    UntilDate: any;


    constructor(private dataService: DataService, private utility: UtilityService, private elementRef: ElementRef,
        @Inject(WINDOW_TOKEN) private windowToken: any) {
        //, private window: Window, @Inject(ACTIVEX_TOKEN) private activex: any
        this.gridheight = this.elementRef.nativeElement.getAttribute('gridheight');
    }

    ngOnInit() {

    }

    columnDefs = [
        {
            headerName: 'PubNo', field: 'PUBNO', width: 50, suppressSizeToFit: false, enableRowGroup: true,
            pinned: "left",
            lockPinned: true,
            cellClass: "lock-pinned", filter: "agNumberColumnFilter"
        },
        {
            headerName: 'Date Accessed', field: 'ACCESSDATE', width: 50, enableRowGroup: true, filter: "agDateColumnFilter",
            valueFormatter: function (params) {
                return params.value == undefined ? '' : new UtilityService().LocalDateDisplayFormat(params.value).toLocaleString();
            },
            filterParams: {
                comparator: function (filterLocalDateAtMidnight, cellValue) {
                    return new UtilityService().LocalDateComparator(filterLocalDateAtMidnight, cellValue);
                },
                browserDatePicker: true
            }
        },
        {
            headerName: 'Date Logged', field: 'CREATEDATE', width: 50, enableRowGroup: true, filter: "agDateColumnFilter",
            valueFormatter: function (params) {
                return params.value == undefined ? '' : new UtilityService().LocalDateDisplayFormat(params.value).toLocaleString();
            },
            filterParams: {
                comparator: function (filterLocalDateAtMidnight, cellValue) {
                    return new UtilityService().LocalDateComparator(filterLocalDateAtMidnight, cellValue);
                },
                browserDatePicker: true
            }
        },
        { headerName: 'Email', field: 'ACCESS_EMAIL_ADDR', width: 100, enableRowGroup: true, filter: "agTextColumnFilter" },
        { headerName: 'Source Product', field: 'Source', width: 100, enableRowGroup: true },
        { headerName: 'Status', field: 'STATUS', width: 100, enableRowGroup: true},
        { headerName: 'Server Name', field: 'SERVER_NAME', width: 50, enableRowGroup: true },
        { headerName: 'Content Source', field: 'CONTENT_SOURCE', width: 50, enableRowGroup: true, filter: "agTextColumnFilter" },
        { headerName: 'Source Internal', field: 'SOURCE_INTERNAL', width: 50, enableRowGroup: true},
        {
            headerName: 'RVD Date', field: 'Date', width: 50, enableRowGroup: true, hide: true, filter: "agDateColumnFilter",
            valueFormatter: function (params) {
                return params.value == undefined ? '' : new UtilityService().LocalDateDisplayFormat(params.value).toLocaleString();
            },
            filterParams: {
                comparator: function (filterLocalDateAtMidnight, cellValue) {
                    return new UtilityService().LocalDateComparator(filterLocalDateAtMidnight, cellValue);
                },
                browserDatePicker: true
            }
        },
        { headerName: 'Title', field: 'Title', width: 150, enableRowGroup: true }
        //{
        //    headerName: "Option", field: "id", width: 50,
        //    cellRenderer: function (params) {
        //        return "<a href='mailto:REPLACE WITH CLIENT EMAIL ADDRESS WHEN READY TO SEND...?Subject=BERNSTEIN * " + params.data.Ticker + " Model&Body=" + params.data.Ticker + " / " + params.data.Company + "' >Email</a>";
        //    }
        //}

    ];

    autoGroupColumnDef = {
        headerName: 'PubNo',
        field: 'PUBNO',
        cellRenderer: 'agGroupCellRenderer',
        cellRendererParams: {
            checkbox: true
        }
    };

    handleFilterChange(filter) {

        //this.gridApi.setRowData(this.rowData.filter((item) => (filter.AnalystId == 0 || item.AnalystId == filter.AnalystId)
        //    && (filter.TickerId == 0 || item.Ticker == filter.TickerId)
        //));

    }


    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        params.api.sizeColumnsToFit();
        this.gridApi.setGridAutoHeight(false);
        this.onRefreshClick();
        //this.dataService.GetResearchUsage(this.SinceDate, this.UntilDate).subscribe(
        //    rData => {
        //        // the initial full set of data
        //        // note that we don't need to un-subscribe here as it's a one off data load
        //        this.rowData = rData;
        //        params.api.setRowData(rData);
        //        //this.gridheight = rData.length * 29;
        //        this.intrId = setInterval(() => {
        //            this.autoSizeAll();
        //        }, 2000);
        //    }
        //);
        //if (this.gridheight == '' || this.gridheight == 0)

        //window.screen.height

    }

    onRefreshClick() {
        var SinceDate1 = typeof this.SinceDate == "string" ? new Date(this.SinceDate) : this.SinceDate;
        var UntilDate1 = typeof this.UntilDate == "string" ? new Date(this.UntilDate) : this.UntilDate;
        this.dataService.GetResearchUsage(SinceDate1, UntilDate1).subscribe(
            rData => {
                // the initial full set of data
                // note that we don't need to un-subscribe here as it's a one off data load
                //this.rowData = rData;
                this.gridApi.setRowData(rData);
                //this.gridheight = rData.length * 29;
                this.intrId = setInterval(() => {
                    this.autoSizeAll();
                }, 2000);
            }
        );

    }


    autoSizeAll() {
        var allColumnIds = [];
        this.gridColumnApi.getAllColumns().forEach(function (column) {
            allColumnIds.push(column.colId);
        });
        this.gridColumnApi.autoSizeColumns(allColumnIds);
        clearInterval(this.intrId);
    }


    onBtExport() {
        this.gridApi.exportDataAsExcel();
    }

    printPending = false;
    onAnimationQueueEmpty(event) {
        if (this.printPending) {
            this.printPending = false;
            this.windowToken.print();
            this.setNormal(event.api);
        }
    }


    onBtPrint() {
        this.setPrinterFriendly(this.gridApi);
        this.printPending = true;
        if (this.gridApi.isAnimationFrameQueueEmpty()) {
            this.onAnimationQueueEmpty({ api: this.gridApi });
        }
    }

    setPrinterFriendly(api) {
        var eGridDiv = document.querySelector(".my-grid");
        var preferredWidth = api.getPreferredWidth();
        preferredWidth += 2;
        eGridDiv.setAttribute("width", preferredWidth);
        eGridDiv.setAttribute("height", "");
        api.paginationSetPageSize(this.gridApi.paginationGetRowCount());
        api.suppressPaginationPanel = true;
        api.setGridAutoHeight(true);
    }
    setNormal(api) {
        var eGridDiv = document.querySelector(".my-grid");
        eGridDiv.setAttribute("width", "400px");
        eGridDiv.setAttribute("height", "200px");
        api.paginationSetPageSize(100);
        api.suppressPaginationPanel = false;
        api.setGridAutoHeight(false);
    }

}
