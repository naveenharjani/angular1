import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResearchUsageComponent } from './research-usage.component';

describe('ResearchUsageComponent', () => {
  let component: ResearchUsageComponent;
  let fixture: ComponentFixture<ResearchUsageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResearchUsageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResearchUsageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
