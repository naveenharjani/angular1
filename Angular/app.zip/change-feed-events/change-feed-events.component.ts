import {Component, Inject, OnInit} from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { DataService } from '../shared/data.service';
import { ColDef, ColGroupDef, GridOptions, GridApi } from 'ag-grid-community';
import { DatePipe,DecimalPipe  } from '@angular/common';
import { CalendarUtility } from '../shared/calendar-utility';
import { ChartOptions } from 'chart.js';
import { XmlViewerComponent} from './xml-viewer/xml-viewer.component';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-change-feed-events',
  templateUrl: './change-feed-events.component.html',
  styleUrls: ['./change-feed-events.component.css']
})
export class ChangeFeedEventsComponent implements OnInit {

  changeFeedEventsData: any;
  columnDefs: (ColDef | ColGroupDef)[];
  style: { width: string, height: string, theme: string };
  gridOptions: GridOptions;
  pageSize: any = '1000';
  gridName: string = 'CHANGE FEED EVENTS';
  buttonList: { text: string; }[];
  dataLoading: boolean = false;
  gridApi: GridApi;
  gridColumnApi;
  frameworkComponents: any;
  calendarUtility: CalendarUtility = new CalendarUtility();
  endDate;
  startDate;
  maxDate = new Date();

  constructor(private dataService: DataService, private datePipe:DatePipe, public dialog: MatDialog) {
  }

  ngOnInit() {
    this.setDefaultFromAndToDate();
    this.gridCustomize();
    this.buttonList = [{ text: 'Excel' }];
    
  }


  setDefaultFromAndToDate(){
    this.endDate= new FormControl(new Date());
    let today = new Date();
    let last30Days = new Date();
    last30Days.setDate(today.getDate()-30);
    this.startDate = new FormControl(last30Days);
  }


  getDataSource(params: GridApi) {
    this.gridApi = params;
    this.dataService.getChangeFeedEvents(this.startDate.value.toLocaleDateString(),this.endDate.value.toLocaleDateString()).subscribe((data: any) => {
      this.changeFeedEventsData = data;  
      this.gridApi && this.gridApi.setRowData(this.changeFeedEventsData); 
    });
  }

  ViewReport(){
    if (this.startDate.value != undefined && this.endDate.value !=undefined ){
      let dates = this.getDatesBetweenDates(this.startDate.value,this.endDate.value);
      if(dates.length > 30){
        alert("The range dates between Since and Until should not be more than 30 days")
      }
      else{
        this.dataService.getChangeFeedEvents(new Date(this.startDate.value).toLocaleDateString(),new Date(this.endDate.value).toLocaleDateString()).subscribe((data: any) => {
          this.changeFeedEventsData = data;  
          this.gridApi && this.gridApi.setRowData(this.changeFeedEventsData); 
        });
      }
    }else{
      alert("Please select valid since and until date");
    }
  }

  getDatesBetweenDates = (startDate, endDate) => {
    let dates = []
    //to avoid modifying the original date
    const theDate = new Date(startDate)
    while (theDate < endDate) {
      dates = [...dates, new Date(theDate)]
      theDate.setDate(theDate.getDate() + 1)
    }
    return dates
  }

  onViewClicked(params: any) {
    const eDiv = document.createElement('div');
    const eventId = params.data.EventId;
    const urlObject = {
      Url:params.data.Url,
      FeedName:params.data.FeedName,
    };
    eDiv.innerHTML = '<a style="cursor: pointer;border-bottom: 1px solid blue">' + params.data.EventId + '</a>';
    eDiv.addEventListener('click', () => {
      this.openDialog(urlObject);
    });
    return eDiv;
  }

  onRetryClicked(params: any) {
    const eDiv = document.createElement('div');
    const eventId = params.data.EventId;
    const status = params.data.Status;
    const urlObject = {
      Url:params.data.Url,
      FeedName:params.data.FeedName,
    };
    if (status=="FAILURE"){
      eDiv.innerHTML = '<a style="cursor: pointer;border-bottom: 1px solid blue">' + params.data.Status + '</a>';
      eDiv.addEventListener('click', () => {
        alert("under construction");
      });
    }
    else{
      eDiv.innerHTML = '<a>' + params.data.Status + '</a>';
    }
    return eDiv;
  }
  
  openDialog(urlObject) {
    this.dataService.getChangeFeedXml(urlObject).subscribe((data: any) => {
      let blob = new Blob([data], {type: 'text/xml'});
      let url = URL.createObjectURL(blob);
      window.open(url,"xml viewer","height=400px, width:900px,modal=yes,alwaysRaised=yes");
      URL.revokeObjectURL(url);
    });
  }

  gridCustomize(){
    this.style = { width: '100%', height: '624px', theme: 'ag-theme-balham my-grid' };
    var self = this;
    this.gridOptions = <GridOptions>{
      suppressContextMenu: true,
      floatingFilter: true,
      rowGroupPanelShow: "onlyWhenGrouping",
      context: { componentParent: this },
      
  getRowStyle : function(params) {
      if (params.node.data.Status === "N/A") {
          return { color: 'gray' };
      }
      else if (params.node.data.Status === "FAILURE") {
        return { color: 'red' };
      }
    },
    onCellValueChanged: function(params)  {
      self.dataService.updateChangeFeedEventStatus(params.data.EventId,params.data.Status).subscribe((data: any) => {
        if (data){
          alert("Status modified successfully");
        }
        else{
          alert("Error while updating the status. Please contact administrator");
        }
      });
    },
  }
      this.columnDefs = [
        {
          headerName: "Event Id",
          field: "EventId",     
          width: 100,
          filter:'agTextColumnFilter',
          sortable:true,
          cellRenderer: this.onViewClicked.bind(this),
        },
        {
          headerName: "Status",
          field: "Status",
          width: 100,
          sortable:true,
          editable:true,
          filter:'agSetColumnFilter',
          //cellRenderer: this.onRetryClicked.bind(this),
          cellEditor: 'agSelectCellEditor',
          cellEditorParams: {
            values: ['FAILURE', 'N/A', 'SUCCESS', 'CANCEL'],
          },
        },
        {
          headerName: 'Feed Name',
          field: 'FeedName',
          width: 120,
          sortable:true,
          filter:'agSetColumnFilter'
        },
        {
          headerName: 'Change Type',
          field: 'ChangeType',
          width: 100,
          filter: 'agSetColumnFilter',
          sortable:true
        },
        {
          headerName: 'Id',
          field: 'Parameter',
          width: 100,
          filter: 'agTextColumnFilter',
          sortable:true
        },
        {
          headerName: "Name",
          field: "Name",
          width: 250,
          filter: 'agTextColumnFilter',
          sortable:true,
          // cellRenderer: function (params: any) {
          //   if (params.data.Name) {
          //       let href =  params.data.FeedName + "/" + params.data.Id;
          //       return "<a style='cursor: pointer;border-bottom: 1px solid blue' target='HISTORICALASSET' href=" + href + " > " + params.data.Name + "</a>";
          //   }
          // }
        },
        {
          headerName: 'Edited By',
          field: 'UserName',
          width: 200,
          filter: 'agSetColumnFilter',
          sortable:true
        },
        {
          headerName: "Edited On",
          field: "EditDate",
          width: 180,
          sortable:true,
          filter:'agTextColumnFilter',
          valueFormatter: function (params: any) {
            return params.value == undefined ? '' : self.datePipe.transform(params.value, 'dd-MMM-yyyy h:mm:ss a');
          }
        },
        {
          headerName: "Event Date",
          field: "EventDate",
          width: 180,
          sortable:true,
          filter:'agSetColumnFilter',
          valueFormatter: function (params: any) {
            return params.value == undefined ? '' : self.datePipe.transform(params.value, 'dd-MMM-yyyy h:mm:ss a');
          }
        },
        {
          headerName: "Download Date",
          field: "DownloadDate",
          width: 180,
          sortable:true,
          filter:'agSetColumnFilter',
          valueFormatter: function (params: any) {
            return params.value == undefined ? '' : self.datePipe.transform(params.value, 'dd-MMM-yyyy h:mm:ss a');
          }
        },
        {
          headerName: "Process Date",
          field: "ProcessDate",
          width: 180,
          sortable:true,
          filter:'agSetColumnFilter',
          valueFormatter: function (params: any) {
            return params.value == undefined ? '' : self.datePipe.transform(params.value, 'dd-MMM-yyyy h:mm:ss a');
          }
        },
        {
          headerName: "Count",
          field: "Count",
          width: 100,
          sortable:true,
          filter:'agSetColumnFilter'
        },
       
        {
          headerName: "Url",
          field: "Url",
          width: 380,
          sortable:true,
          filter: 'agTextColumnFilter',
        },
        {
          headerName: "Remarks",
          field: "Message",
          width: 150,
          sortable:true,
          filter: 'agTextColumnFilter',
        },
        
      ];
      this.gridApi && this.gridApi.setColumnDefs(this.columnDefs);
      this.dataLoading = false;
   
  }

  onExcelExport() {
    this.dataLoading = true;
    setTimeout(() => {
      this.gridApi.exportDataAsExcel({
        fileName: this.gridName,
        sheetName: this.gridName
      })
    }, 0)
    setTimeout(() => {
      this.dataLoading = false;
    }, 2000)
  }
  
}
