import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeFeedEventsComponent } from './change-feed-events.component';

describe('ChangeFeedEventsComponent', () => {
  let component: ChangeFeedEventsComponent;
  let fixture: ComponentFixture<ChangeFeedEventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeFeedEventsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeFeedEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
