import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import * as vkbeautify from 'vkbeautify';


@Component({
  selector: 'app-xml-viewer',
  templateUrl: './xml-viewer.component.html',
  styleUrls: ['./xml-viewer.component.css']
})
export class XmlViewerComponent implements OnInit {
  inputXmlString = "";
  gridName: string = 'XML Viewer';
  buttonList = [{ text: 'Close'},{text:'Copy to clipboard' }];

  constructor(public dialogRef: MatDialogRef<XmlViewerComponent>,@Inject(MAT_DIALOG_DATA) public dialogData: any,) { 
    this.inputXmlString = vkbeautify.xml(this.dialogData.xmlString);
  }

  ngOnInit() {
  }

  onButtonClick(text: any) {
    if (text === 'copy to clipboard') {
     this.copyText(this.inputXmlString);
    }
    if (text === 'close') {
        this.dialogRef.close();
    }
  }

    copyText(val: string){
      let selBox = document.createElement('textarea');
        selBox.style.position = 'fixed';
        selBox.style.left = '0';
        selBox.style.top = '0';
        selBox.style.opacity = '0';
        selBox.value = val;
        document.body.appendChild(selBox);
        selBox.focus();
        selBox.select();
        document.execCommand('copy');
        document.body.removeChild(selBox);
      }

}
