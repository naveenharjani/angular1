import { Component, OnInit, ElementRef, Inject, ViewChild, ViewContainerRef, ComponentFactoryResolver } from '@angular/core';
import { DataService } from '../shared/data.service';
import { UtilityService } from '../shared/utility.service';
import { DetailCellRendererComponent } from '../detail-cell-renderer/detail-cell-renderer.component';

import { Observable } from 'rxjs';
import {
    //Window,
    WINDOW_TOKEN
} from '../shared/active-xobject.service';
import { FormGroup, FormControl } from '@angular/forms';
import { BeehivePageHeaderComponent } from '../beehive-page-header/beehive-page-header.component';

@Component({
    selector: 'app-masterdetailview',
    templateUrl: './masterdetailview.component.html',
    styleUrls: ['./masterdetailview.component.css']
})
export class MasterdetailviewComponent implements OnInit {

    filtersForm: FormGroup;
    private gridApi;
    private gridColumnApi;
    rowData: any[];
    contentType: string;
    paging = true;
    virtualRows: any;
    intrId: any;
    getContextMenuItems;
    columnDefs;
    displayForm = true;
    detailRowHeight;
    detailCellRenderer;
    frameworkComponents;
    @ViewChild('container', { read: ViewContainerRef }) container: ViewContainerRef;
    childComponent: BeehivePageHeaderComponent;
    gridID: string = '';
    gridName: string = '';
    buttonClicked: string;



    constructor(private dataService: DataService, private utility: UtilityService, private elementRef: ElementRef
        , @Inject(WINDOW_TOKEN) private windowToken: any, private resolver: ComponentFactoryResolver) {

        this.contentType = "Quota";
        this.getContextMenuItems = function getContextMenuItems(params) {
            return ["autoSizeAll", "expandAll", "contractAll", "copy", "toolPanel", "resetColumns", "excelExport"];
        };


    }

    ngOnInit() {
        //this.SinceDate.setDate(this.SinceDate.getDate() - 14);
        this.filtersForm = new FormGroup({
            filterTypes: new FormControl('')
        });
        this.filtersForm.get('filterTypes').valueChanges.subscribe((value: any) => {
            this.onRefreshClick(value);
        });
        this.loadClientData();
        this.loadColDef();
    }

    ngAfterContentInit() {
        let factory = this.resolver.resolveComponentFactory(BeehivePageHeaderComponent);
        let component = this.container.createComponent(factory);
        this.childComponent = component.instance;
        this.childComponent.beehivePageName = 'QUOTA ';
        this.childComponent.buttonList = [{ text: 'Print', isRoleNeeded: false }, { text: 'Excel', isRoleNeeded: false }];
        this.childComponent.onButtonClick.subscribe((buttonText: any) => {
            if (buttonText === 'excel') {
                this.onBtExport();
            }
            else if (buttonText === 'print') {
                this.onBtPrint();
            }
        })
    }

    loadColDef() {


        this.displayForm = false;
        this.detailRowHeight = 350;
        this.detailCellRenderer = "myDetailCellRenderer";
        this.frameworkComponents = { myDetailCellRenderer: DetailCellRendererComponent };

        this.columnDefs = [
            {
                field: "Product",
                cellRenderer: "agGroupCellRenderer", width: 200
            },
            { headerName: 'Quota', field: 'Quota', type: "numericColumn", width: 200, valueFormatter: this.utility.formatNumber },
            { headerName: 'Period', field: 'YTD', type: "numericColumn", width: 200, valueFormatter: this.utility.formatNumber }
            //{ headerName: 'Client', field: 'Client', filter: "agTextColumnFilter" }
        ];


    }



    defaultGroupSortComparator = function (nodeA, nodeB) {
        if (nodeA.allLeafChildren != undefined && nodeB.allLeafChildren != undefined)
            if (nodeA.allLeafChildren.length > nodeB.allLeafChildren.length) {
                return -1;
            } else if (nodeA.allLeafChildren.length < nodeB.allLeafChildren.length) {
                return 1;
            } else {
                return 0;
            }
    };


    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        //params.api.sizeColumnsToFit();
        this.gridApi.setGridAutoHeight(false);
        this.gridApi.setRowData();
        // this.onRefreshClick('');
    }

    onRefreshClick(client: string) {
        this.gridApi.showLoadingOverlay();
        client = client == '' ? this.selectedClient : client;
        client = "and SVC.ACCOUNTID='" + client + "'";

        this.dataService.GetDataFromDataSource("slx", "_quota_master", "file", client, false).subscribe(
            rData => {
                // the initial full set of data
                // note that we don't need to un-subscribe here as it's a one off data load
                this.rowData = rData;
                //this.rowData.shift();
                this.gridApi.setRowData(rData);
                this.gridApi.hideOverlay();
            }
        );

    }



    //autoSizeAll() {
    //    var allColumnIds = [];
    //    this.gridColumnApi.getAllColumns().forEach(function (column) {
    //        allColumnIds.push(column.colId);
    //    });
    //    this.gridColumnApi.autoSizeColumns(allColumnIds);
    //    clearInterval(this.intrId);
    //}


    onBtExport() {
        this.gridApi.exportDataAsExcel();
    }

    printPending = false;
    onAnimationQueueEmpty(event) {
        if (this.printPending) {
            this.printPending = false;
            this.windowToken.print();
            this.setNormal(event.api);
        }
    }


    onBtPrint() {
        this.setPrinterFriendly(this.gridApi);
        this.printPending = true;
        if (this.gridApi.isAnimationFrameQueueEmpty()) {
            this.onAnimationQueueEmpty({ api: this.gridApi });
        }
    }

    setPrinterFriendly(api) {
        var eGridDiv = document.querySelector(".my-grid");
        var preferredWidth = api.getPreferredWidth();
        preferredWidth += 2;
        eGridDiv.setAttribute("width", preferredWidth);
        eGridDiv.setAttribute("height", "");
        api.paginationSetPageSize(this.gridApi.paginationGetRowCount());
        api.suppressPaginationPanel = true;
        api.setGridAutoHeight(true);
    }
    setNormal(api) {
        var eGridDiv = document.querySelector(".my-grid");
        eGridDiv.setAttribute("width", "400px");
        eGridDiv.setAttribute("height", "200px");
        api.paginationSetPageSize(100);
        api.suppressPaginationPanel = false;
        api.setGridAutoHeight(false);
    }


    // ddl Region
    Clients: any[];
    selectedClient: any = "-1";


    loadClientData() {

        this.dataService.GetDataFromDataSource("slx", "_quota_picklist", "file", "", false).subscribe(
            rData => {
                this.Clients = rData;
            }
        );

    }

    onClientSelect(client) {
        this.onRefreshClick(client);
    }




}

