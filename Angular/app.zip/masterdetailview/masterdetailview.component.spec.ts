import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterdetailviewComponent } from './masterdetailview.component';

describe('MasterdetailviewComponent', () => {
  let component: MasterdetailviewComponent;
  let fixture: ComponentFixture<MasterdetailviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasterdetailviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterdetailviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
