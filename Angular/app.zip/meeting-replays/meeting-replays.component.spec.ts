import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeetingReplaysComponent } from './meeting-replays.component';

describe('MeetingReplaysComponent', () => {
  let component: MeetingReplaysComponent;
  let fixture: ComponentFixture<MeetingReplaysComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MeetingReplaysComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeetingReplaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
