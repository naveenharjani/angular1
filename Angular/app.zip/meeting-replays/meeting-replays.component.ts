import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { DataService } from '../shared/data.service';
import { GridOptions, ColDef, ColGroupDef, GridApi } from 'ag-grid-community';
import { Router } from '@angular/router';
import {MatDialog, MAT_DIALOG_DATA, MatDialogConfig} from '@angular/material'; 
import { DatePipe,DecimalPipe  } from '@angular/common';
import { CalendarUtility } from '../shared/calendar-utility';

@Component({
  selector: 'app-meeting-replays',
  templateUrl: './meeting-replays.component.html',
  styleUrls: ['./meeting-replays.component.css']
})
export class MeetingReplaysComponent implements OnInit {
    rowData: any;
    columnDefs: (ColDef | ColGroupDef)[];
    style: { width: string, height: string, theme: string };
    gridOptions: GridOptions;
    pageSize: any = '1000';
    gridName: string = 'MEETING REPLAYS'; 
    dataLoading: boolean = false;
    gridApi: GridApi;
    calendarUtility: CalendarUtility = new CalendarUtility();
  constructor(private dataService: DataService, private router: Router,  public dialog: MatDialog, private datePipe:DatePipe) { }

  ngOnInit() {
    this.passValuestoGrid();
    this.fetchData();   
  }
 
  fetchData() {
    this.dataService.getMeetingReplays().subscribe((data: any) => {
      if (data) {
        this.rowData = data;
      }
    });
  }

  passValuestoGrid() {
    this.style = { width: '100%', height: '624px', theme: 'ag-theme-balham my-grid' };
    var self = this;
    this.gridOptions = <GridOptions>{
      rowGroupPanelShow: "onlyWhenGrouping",
      context: { componentParent: this },
      masterDetail: true,
      suppressContextMenu:true,
      sideBar:{
        toolPanels: [
          {
            id: 'columns',
            labelDefault: 'Columns',
            labelKey: 'columns',
            iconKey: 'columns',
            toolPanel: 'agColumnsToolPanel',
            toolPanelParams: {
              suppressRowGroups: true,
              suppressValues: true,
              suppressPivots: true,
              suppressPivotMode: true,
              suppressSideButtons: true,
              suppressColumnFilter: true,
              suppressColumnSelectAll: true,
              suppressColumnExpandAll: true,
            },
          },
        ],
        defaultToolPanel: 'columns',
      },
      detailCellRendererParams: {
        detailGridOptions: {
          columnDefs: [               
            {
                headerName: 'File', field: 'File', width: 200, sortable: true, resizable: true, hide:true,
                cellRenderer: function (params: any) {
                    if (params.data) {
                        let href = "/files/content/av/" + params.data.File;
                        let fileName=params.data.File.substr(params.data.File.lastIndexOf("/") +1 ,params.data.File.Length);
                        return  "<a style='cursor: pointer;border-bottom: 1px solid blue' target='#' href=" + href + " > " + fileName + "</a>";
                    }
                }
            },
            {
                headerName: 'Recording Date', field: 'Recording_Date', width: 200, sortable: true, resizable: true,
                cellRenderer: function (params: any) {    
                    let href = "/files/content/av/" + params.data.File;
                    let fileName=params.data.File.substr(params.data.File.lastIndexOf("/") +1 ,params.data.File.Length);       
                    //return  params.value == undefined || params.value == 'Not Available' ? '' : self.datePipe.transform(self.calendarUtility.formatDate(params.value), 'dd-MMM-yyyy');
                    return  "<a style='cursor: pointer;border-bottom: 1px solid blue' target='_blank' href=" + href + " > " + params.data.Recording_Date + "</a>";
                }
            },
            { headerName: 'Size',field: 'Size',width: 150, type: "number",  cellClass: 'rightAlignIssueFix', }
           
          ],
          onFirstDataRendered: function (params: any) {
            params.api.sizeColumnsToFit();
          }
        },
        getDetailRowData: function (params: any) {
            console.log(params);
          self.dataService.getMeetingReplaysHistorial(params.data.Meeting).subscribe((data: any) => {
            params.data.callRecords = data;
            params.successCallback(params.data.callRecords);
          });
        }
      },
   
      isFullWidthCell: function () {
        return false;
      }
    };
    this.columnDefs = [
    //   {  headerName: "ID", field: "Id", width: 80, hide:true, type: "number",  },
      {
        headerName: "Meeting",
        field: "Meeting",        
        width: 1600,
        cellClass: 'lock-pinned ',
        lockPinned:true,
        pinned:'left',
       cellRenderer: "agGroupCellRenderer",
        // cellRenderer: function (params: any) {
        //     if (params.data) {
        //         let href = "/files/content/av" + params.data.File;
        //         let fileName=params.data.File.substr(params.data.File.lastIndexOf("/") +1 ,params.data.File.Length);
        //         return  "<a style='cursor: pointer;border-bottom: 1px solid blue' target='_blank' href=" + href + " > " + params.data.Meeting + "</a>";
        //     }
        // }
       // cellRenderer: 'group',
    //     cellRendererParams: function (params: any) {
    //            if (params.data) {
    //             let href = "/files/content/av" + params.data.File;
    //             let fileName=params.data.File.substr(params.data.File.lastIndexOf("/") +1 ,params.data.File.Length);
    //             console.log("data",params.data);
    //             return  "<a style='cursor: pointer;border-bottom: 1px solid blue' target='_blank' href=" + href + " > " + params.data.Meeting + "</a>";
    //     }
    // }
      },
      {
        headerName: 'File', field: 'File', width: 300, sortable: true, resizable: true,  hide:true,
        cellRenderer: function (params: any) {
            if (params.data) {
                let href = "/files/content/av" + params.data.File;
                let fileName=params.data.File.substr(params.data.File.lastIndexOf("/") +1 ,params.data.File.Length);
                return  "<a style='cursor: pointer;border-bottom: 1px solid blue' target='_blank' href=" + href + " > " + fileName + "</a>";
            }
        }
    },
    {
        headerName: 'Recording Date', field: 'Recording_Date', width: 220, sortable: true, resizable: true,hide:true,
        cellRenderer: function (params: any) {           
            //return  params.value == undefined || params.value == 'Not Available' ? '' : self.datePipe.transform(self.calendarUtility.formatDate(params.value), 'dd-MMM-yyyy');
            let href = "/files/content/av" + params.data.File;
            let fileName=params.data.File.substr(params.data.File.lastIndexOf("/") +1 ,params.data.File.Length);
            console.log(params.value);
            return  "<a style='cursor: pointer;border-bottom: 1px solid blue' target='_blank' href=" + href + " > " + params.data.Recording_Date + "</a>";
        }
    },
    { headerName: 'Size',field: 'Size', width: 150, type: "number", hide:true,cellClass: 'rightAlignIssueFix', }
    ];
  }

  getDataSource(params: any) {
    this.gridApi = params;
  }

}
