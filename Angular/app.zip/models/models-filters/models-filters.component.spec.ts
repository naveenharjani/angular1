import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelsFiltersComponent } from './models-filters.component';

describe('ModelsFiltersComponent', () => {
  let component: ModelsFiltersComponent;
  let fixture: ComponentFixture<ModelsFiltersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelsFiltersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelsFiltersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
