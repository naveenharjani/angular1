import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-models-filters',
  templateUrl: './models-filters.component.html',
  styleUrls: ['./models-filters.component.css']
})
export class ModelsFiltersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
