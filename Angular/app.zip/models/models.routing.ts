import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmailFormComponent } from '../email-form/email-form.component';


const appRoutes: Routes = [
  { path: 'email', component: EmailFormComponent }
];


@NgModule({
  imports: [RouterModule.forChild(appRoutes)],
  exports: [RouterModule]
})
export class EmailRoutingModule {


}


