import { Component, OnInit } from '@angular/core';
import { DataService } from '../../shared/data.service';
import { Role } from '../../beehive-page-header/permissions.enums';
import { GlobaldataService } from '../../shared/globaldata.service';
 

@Component({
  selector: 'app-model-option',
  templateUrl: './model-option.component.html',
  styleUrls: ['./model-option.component.css']
})
export class ModelOptionComponent implements OnInit {

  params: any;
  isAdmin: boolean = false; //this._globaldataSerice.isInRoleValue;
  isDeleted: boolean = false;
  isCalled: boolean=false;

  constructor(private dataService: DataService, private _globaldataSerice:GlobaldataService) { }

  ngOnInit() {   
   // this.isAdmin=this._globaldataSerice.getIsInRole();  
   this.dataService.IsInRole(Role.deManager).subscribe((val: any) => {
    val ? this.isAdmin = true : this.isAdmin = false;
  }); 
  }

  agInit(params: any): void {
    this.params = params;
    this.params && this.params.data && this.params.data.Status === "Not Available" ? (this.isDeleted = true) : this.isDeleted = false;
  }

  exportCart() {
    let url = '/research/email.aspx?type=model&id=' + this.params.data.SecurityId + '&ticker=' + this.params.data.Ticker;
    //window.open(url, 'POP', 'left=50,top=50,width=1000,height=750,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes');
    window.open(url.toString(), 'FORM', 'left=50,top=50,width=1000,height=750,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
    return false;
    // console.log(this.params.data);    
    // if(this.params && this.params.context && this.params.context.componentParent){
    //   this.params.context.componentParent.exportCart(this.params.data);
    // }
  }

  deleteModel() {
    this.isDeleted = true;
    this.params.context.componentParent.modelDelete(this.params.data);
  }
}
