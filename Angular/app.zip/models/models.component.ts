import { Component, OnInit } from '@angular/core';
import { DataService } from '../shared/data.service';
import { UtilityService } from '../shared/utility.service';
import { TooltipComponent } from '../tooltip/tooltip.component';
import { GridOptions, ColDef, ColGroupDef, GridApi, RowNode } from 'ag-grid-community';
import { BeehiveCookiesService } from '../shared/cookies.service';
import { ModelOptionComponent } from './model-option/model-option.component';
import { Router, ActivatedRoute } from '@angular/router';
import { ModelsRegionFilter } from './models-region-filter.component';
import { BeehiveMessageService } from '../shared/message-service';
import { DatePipe } from '@angular/common'; 
import { AgGridCheckboxComponent } from '../shared/checkbox-renderer/checkbox-renderer.component';
import { Role } from '../beehive-page-header/permissions.enums';


@Component({
    selector: 'app-models',
    templateUrl: './models.component.html',
    styles: ['./models.component.scss']
})
export class ModelsComponent implements OnInit {

    private gridApi: GridApi;
    cartArray: any;
    franchiseList = [];
    rowData = [];
    columnDefs: (ColDef | ColGroupDef)[];
    style: { width: string, height: string, theme: string };
    gridOptions: GridOptions;
    pageSize: any = '1000';
    gridName: string = 'MODELS';
    roleList: boolean = false;
    frameworkComponents: any;
    ticker: string = '';
    dataLoading: boolean;
    buttonList: { text: string; }[];
    cartData: any;

    constructor(private service: BeehiveMessageService, private dataService: DataService,
        private activatedRoute: ActivatedRoute, private cookiesService: BeehiveCookiesService, private datePipe: DatePipe,private router: Router) {
    }

    ngOnInit() {       
        this.passValuestoGrid();
        this.fetchData();
        this.buttonList = [{ text: 'Excel' }];
        var _franchiseList=this.cookiesService.GetFranchiseList();
        if(_franchiseList!=undefined &&_franchiseList!=null && _franchiseList!="")
        {
            this.franchiseList = this.cookiesService.GetFranchiseList().split(',');
        }
        
        //this.roleList = (this.cookiesService.GetRoleList().split(',').indexOf('1') >= 0) ) ? true : false;
        //Administrator & Approver can see the Model History
       // this.roleList = ((this.cookiesService.GetRoleList().split(',').indexOf('1') >= 0) || (this.cookiesService.GetRoleList().split(',').indexOf('3') >= 0)) ? true : false;
       this.dataService.IsInRole(Role.deApprover).subscribe((val: any) => {
        val ? this.roleList = true : this.roleList = false;
      }); 
        this.activatedRoute.queryParams.subscribe((params) => {
            this.ticker = params.ticker;
        });
        this.cartData = this.rowData;
    }


    getDataSource(params: any) {
        this.gridApi = params;
        this.activatedRoute.queryParams.subscribe(params => {
            this.ticker = params['ticker'];
        });
        setTimeout(() => {
            if (this.ticker) {
                this.filterData(this.ticker);
            }
        }, 1000);
    }

    setSelectedRows(deletedTickerId?: any) {
                    let records = [];
                    records = this.rowData.filter((data: any) => data.IsInCart === true).map((v:any) => v.SecurityId);
                    if (deletedTickerId && records.indexOf(deletedTickerId) >= 0) {
                        this.service.changeMessage({ 'itemRemoved': true, 'itemID': deletedTickerId, 'type': 'model' });
                    }
                   
    }
   
    fetchData() {
        if (this.cookiesService.GetUserID()){
            this.dataService.GetModelData(this.cookiesService.GetUserID()).subscribe(
                data => {
                    this.rowData = data;
                    this.gridApi && this.gridApi.setRowData(this.rowData);                                     
                }
            );
        }
        if (this.ticker) {
            this.filterData(this.ticker);
        }
    }


    filterData(ticker: string) {
        let filterComponent = this.gridApi && this.gridApi.getFilterInstance('Ticker');
        filterComponent.setModel({
            type: 'contains',
            filter: ticker && ticker.toUpperCase()
        });
        this.gridApi.onFilterChanged();
    }

    exportCart(rowData?: any) {
        let url = this.router.createUrlTree(['/email'], { queryParams: { style: 1, type: 'model', id: rowData.SecurityId, mailType: this.cookiesService.GetUserID() } });
        window.open('#' + url.toString(), 'FORM', 'width=800,height=600,left=50,top=25,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
    }


    passValuestoGrid() {
        this.style = { width: '100%', height: '624px', theme: 'ag-theme-balham my-grid' };
        var self = this;
        this.gridOptions = <GridOptions>{
            floatingFilter: true,
            rowGroupPanelShow: "onlyWhenGrouping",
            context: { componentParent: this },
            masterDetail: true,
            detailCellRendererParams: {
                detailGridOptions: {
                    columnDefs: [
                        {
                            field: 'Date',
                            headerName: 'Date',
                            cellRenderer: function (params: any) {
                              const date = new Date(params.value);
                               let dateFormat = date.toLocaleDateString('en-GB', {day: 'numeric', month: 'short', year: 'numeric'}).replace(/ /g, '-');
                                 var formattedDate=params.value == undefined ? '' : dateFormat; 
                                if (params.data) {
                                    let href = "/research/viewmodel.aspx?f=" + params.data.FileName + "&ticker=" + (params.data.Ticker.indexOf('.') > 0 ? params.data.Ticker.replace(".", "_") : params.data.Ticker);
                                    return "<a style='cursor: pointer;border-bottom: 1px solid blue' href=" + href + " > " + formattedDate + "</a>";
                                }
                            }
                        },
                        { field: 'Analyst' },
                        { field: 'Action' },
                        { field: 'Editor' }
                    ],
                    onFirstDataRendered: function (params: any) {
                        params.api.sizeColumnsToFit();
                    }
                },
                getDetailRowData: function (params: any) {
                    self.dataService.modelsHistory(params.data.Ticker).subscribe((data: any) => {
                        params.data.callRecords = data;
                        params.successCallback(params.data.callRecords);
                    });
                }
            },
            isRowMaster: function (dataItem) {
                return (self.roleList ||
                    (self.franchiseList.indexOf(dataItem.AnalystId && dataItem.AnalystId.toString()) != -1)) ? true : false;
            },
            isFullWidthCell: function () {
                return false;
            },
            rowClassRules: {
                'dropped': function (params) { return params.data && params.data.Status === 'Not Available' }
            }
        };
        this.columnDefs = [
            {
                headerName: 'Company', field: 'Company',
                width: 250, suppressSizeToFit: false,
                enableRowGroup: true,
                pinned: "left",
                lockPinned: true,
                cellClass: "lock-pinned", filter: "agTextColumnFilter",
                cellRendererSelector: function (params) {
                    var groupRenderer = {
                        component: 'agGroupCellRenderer'
                    };

                    if (params.data.Status !== 'Not Available')
                        return groupRenderer;
                    else
                        return null;

                }
            },
            {
                headerName: 'Model', field: 'Ticker', width: 120, enableRowGroup: true, filter: "agTextColumnFilter",

                cellRenderer: function (params) {
                    if (params.data) {
                        let href = "/research/viewmodel.aspx?f=" + params.data.FileName + "&ticker=" + (params.data.Ticker.indexOf('.') > 0 ? params.data.Ticker.replace(".", "_") : params.data.Ticker);
                        return params.data.Status === 'Not Available' ? params.data.Ticker : "<a style='cursor: pointer;border-bottom: 1px solid blue' href=" + href + "> " + params.data.Ticker + "</a>";
                    }
                }
            },
            { headerName: 'Analyst', field: 'Analyst', width: 150, enableRowGroup: true, filter: "agTextColumnFilter" },
            {
                headerName: 'Region',
                field: 'Region',
                width: 90,
                // filter: "agTextColumnFilter",
                // floatingFilterComponent: "sliderFloatingFilter",
                // floatingFilterComponentParams: {
                //     value: 'All',
                //     suppressFilterButton: true
                // },
                suppressMenu: true,
                filter: 'agSetColumnFilter'
            },
            {
                headerName: 'Date', field: 'Date', width: 110, enableRowGroup: true,
                valueFormatter: function (params) {
                    //return params.value == undefined ? '' : new UtilityService().LocalDateDisplayFormat(params.value);                     
                    const date = new Date(params.value);
                               let dateFormat = date.toLocaleDateString('en-GB', {day: 'numeric', month: 'short', year: 'numeric'}).replace(/ /g, '-');
                                 var formattedDate=params.value == undefined ? '' : dateFormat; 
                                 return params.value == undefined ? '' :  formattedDate; 
                }
                // ,
                // filterParams: {
                //     comparator: function (filterLocalDateAtMidnight, cellValue) {
                //         return new UtilityService().LocalDateComparator(filterLocalDateAtMidnight, cellValue);
                //     },
                //     browserDatePicker: true
                // }
            },
            { headerName: 'Action', field: 'Action', width: 260, enableRowGroup: true, cellRendererFramework: TooltipComponent, filter: 'agSetColumnFilter' },
            { headerName: 'Status', field: 'Status', width: 100, enableRowGroup: true, filter: 'agSetColumnFilter' },
            { headerName: 'ModelFileName', field: 'ModelFileName', width: 100, enableRowGroup: true, hide: true, filter: "agTextColumnFilter" },
            { headerName: 'Region', field: 'Region', width: 100, enableRowGroup: true, hide: true },
            {
                headerName: "Option", field: "id", width: 75,
                cellRendererFramework: ModelOptionComponent
            },
            {
                headerName: "Cart",
                width: 100,
                field: 'IsInCart',
                cellRendererFramework: AgGridCheckboxComponent,
            }
        ];
        this.frameworkComponents = { sliderFloatingFilter: ModelsRegionFilter };
    }

    modelDelete(data: any) {
        let row = this.rowData.find((row) => row.ModelId === data.ModelId);
        if (row) {
            row.Date = null;
            row.Status = "Not Available";
            row.Action = "";
        }
        this.gridApi.setRowData(this.rowData);
        this.setSelectedRows(data.SecurityId);
        setTimeout(() => {
            this.dataService.deleteModel(data.ModelId.toString(), this.cookiesService.GetUserID().toString()).subscribe();
            let payload = {
                UserId: this.cookiesService.GetUserID(),
                ContentType: 'Model',
                ContentId: row.SecurityId,
                Selected: false
            }
            this.dataService.saveCart(payload).subscribe(() => { });
        }, 0);
    }

    onButtonClick(text: any) {
        if (text === 'excel') {
            this.onBtExport();
        }
    }

    onBtExport() {
        this.dataLoading = true;
        let params = {};
        params = {
            fileName: this.gridName,
            sheetName: this.gridName,
            columnKeys: this.columnDefs.filter((data: any) => data.hide !== true).map((params: any) => params.field)
        }
        setTimeout(() => {
            this.gridApi.exportDataAsExcel(params);
        }, 0)
        setTimeout(() => {
            this.dataLoading = false;
        }, 2000)
    }
}
