import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { ModelsComponent } from './models.component';
import { AbGridModule } from '../ab-grid/ab-grid.module';
import { ModelOptionComponent } from './model-option/model-option.component';
import { EmailFormModule } from '../email-form/email-form.module';
import { MaterialModule } from '../material.module';
import { ModelsRegionFilter } from './models-region-filter.component';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule } from '@angular/forms';
import { MatProgressSpinnerModule } from '@angular/material';
import { BeehivePageHeaderModule } from '../beehive-page-header/beehive-page-header.module';


@NgModule({
    declarations: [ModelsComponent, ModelOptionComponent, ModelsRegionFilter],
    imports: [CommonModule, AbGridModule, EmailFormModule, MaterialModule, FormsModule,
        AgGridModule.withComponents([ModelsRegionFilter]), MatProgressSpinnerModule, BeehivePageHeaderModule],
    providers: [],
    entryComponents: [ModelsComponent],
    exports: [ModelsComponent],
    bootstrap: [ModelsComponent]
})
export class ModelsModule {

}