import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BeehiveCookiesService } from '../../../shared/cookies.service';
import { DataService } from '../../../shared/data.service';
import { BeehiveMessageService } from '../../../shared/message-service';
import { EnvService } from '../../../../env.service';

@Component({
  selector: 'app-options-template',
  templateUrl: './options-template.component.html',
  styleUrls: ['./options-template.component.css']
})
export class OptionsTemplateComponent implements OnInit {

  constructor(private environment: EnvService,private dataService: DataService, private router: Router, private cookiesService: BeehiveCookiesService, private service: BeehiveMessageService) { }

  params: any;
  isAdmin: boolean;
  isManager:boolean;
  siteurl:any;
  ngOnInit() {
    
  }

  agInit(params: any): void {
    this.params = params;
    this.isAdmin = params.isAdmin();
    this.isManager=params.isManager();
  }

  clickProperties() {
    let url = '/edit/edit.aspx?pubno=' + this.params.data.pubId;
    window.open(url, 'FORM', 'width=1000,height=750,left=25,top=25,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);

  }
  clickEmail() {
    this.siteurl= this.environment.SiteUrl;
   // let url =  this.siteurl+'research/email.aspx?type=research&id='+this.params.data.pubId+'';
    let url= window.location.protocol + "//" + window.location.hostname +'research/email.aspx?type=research&id='+this.params.data.pubId+'';
    //let url = this.router.createUrlTree(['research/email'], { queryParams: { style: 1, type: 'research', id: this.params.data.pubId, mailType: this.cookiesService.GetUserID() } });
    //let url = this.router.navigate([this.siteurl +'/research/email'+'\0'], { queryParams: { style: 1, type: 'research', id: this.params.data.pubId, mailType: this.cookiesService.GetUserID() } });
   console.log(url);
    window.open( url.toString(), 'FORM', 'width=800,height=600,left=50,top=25,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
  } 
  clickNewEmail() {
    this.siteurl= this.environment.SiteUrl;
    let url =  this.siteurl+'research/email.aspx?type=analystblast&id='+this.params.data.pubId+'';
    
    //let url = this.router.createUrlTree(['research/email'], { queryParams: { style: 1, type: 'research', id: this.params.data.pubId, mailType: this.cookiesService.GetUserID() } });
    //let url = this.router.navigate([this.siteurl +'/research/email'+'\0'], { queryParams: { style: 1, type: 'research', id: this.params.data.pubId, mailType: this.cookiesService.GetUserID() } });
   console.log(url);
    window.open(  url.toString(), 'FORM', 'width=800,height=600,left=50,top=25,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
  } 

  clickDistribution() {
    let url = '/distribution/detail.asp?pubno=' + this.params.data.pubId;
    window.open(url, 'FORM', 'width=800,height=600,left=50,top=25,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
  }

  clickDelete() {
    this.popDelete(this.params.data.pubId);
  }

  popDelete(PubNo: string) {
    this.siteurl= this.environment.SiteUrl;
    var msg1 = "\n\nRe-submitted research is now automatically overlayed and no longer requires a delete.";
    var msg2 = "\n\nDeleted research will result in broken web links emailed to clients.";
    if (confirm("Are you sure you want to delete all versions of publication " + PubNo + "?" + msg1 + msg2)) {
      window.document.activeElement.setAttribute('backgroundColor', "red");
      var url = this.siteurl +'research/save.aspx?op=dp&pubno=' + PubNo;
      window.open(url.toString(), 'SAVE', 'width=500,height=200,left=500,top=25,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
    }
  }


}
