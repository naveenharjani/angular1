import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OptionsTemplateComponent } from './options-template.component';

describe('OptionsTemplateComponent', () => {
  let component: OptionsTemplateComponent;
  let fixture: ComponentFixture<OptionsTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OptionsTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OptionsTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
