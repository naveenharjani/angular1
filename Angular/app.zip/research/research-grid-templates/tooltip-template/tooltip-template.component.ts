import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tooltip-template',
  templateUrl: './tooltip-template.component.html',
  styleUrls: ['./tooltip-template.component.css']
})
export class TooltipTemplateComponent implements OnInit {

  constructor() { }

  data : Array<any>;
  params : any;
  field : string;

  ngOnInit() {
  }

  displayValues(values, take : number){
    if(values){
      if(take == null)
        return values.map(x=>x[this.field]).join(', ');
      else
        return values.map(x=>x[this.field]).slice(0,3).join(', ');
    }

  }



  agInit(params: any){
    this.params = params;
    this.data = this.params.data[params.field]
    this.field = params.subField;
  }

}
