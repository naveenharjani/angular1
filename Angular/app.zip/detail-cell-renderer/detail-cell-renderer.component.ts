import { Component, OnInit, ElementRef, Inject, } from '@angular/core';
import { ICellRendererAngularComp } from "ag-grid-angular";
import { DataService } from '../shared/data.service';
import { UtilityService } from '../shared/utility.service';
import { Observable } from 'rxjs';
import {
    //Window,
    WINDOW_TOKEN
} from '../shared/active-xobject.service';

@Component({
    selector: 'app-detail-cell-renderer',
    templateUrl: './detail-cell-renderer.component.html',
    styleUrls: ['./detail-cell-renderer.component.css']
})
export class DetailCellRendererComponent implements ICellRendererAngularComp {

    private gridApi;
    private gridColumnApi;
    rowData: any[];
    contentType: string;
    paging = true;
    intrId: any;
    getContextMenuItems;
    columnDefs;
    autoGroupColumnDef;
    params;
    masterGridApi;
    masterRowIndex;

    constructor(private dataService: DataService, private utility: UtilityService, private elementRef: ElementRef
        , @Inject(WINDOW_TOKEN) private windowToken: any) {


        this.getContextMenuItems = function getContextMenuItems(params) {
            return ["autoSizeAll", "expandAll", "contractAll", "copy", "toolPanel", "resetColumns", "excelExport"];
        };
    }

    // called on init
    agInit(params: any): void {
        this.params = params;

        this.masterGridApi = params.api;
        this.masterRowIndex = params.rowIndex;

        this.columnDefs = [
                   //{ field: "Account_grp" },
                   //{ field: "Product_grp" },                   
           
            {
                headerName: 'Title', field: 'Title_grp', width: 80, enableRowGroup: true, filter: "agTextColumnFilter", rowGroup: true, rowGroupIndex: 0, hide: true
            },
            {
                headerName: 'Contact', field: 'Contact_grp', width: 80, enableRowGroup: true, filter: "agTextColumnFilter", rowGroup: true, rowGroupIndex: 1, hide: true
            },
            {
                headerName: 'Year', field: 'Year_piv', width: 100, enableRowGroup: true, pivot: true, enablePivot: true
            },
            {
                headerName: 'Month', field: 'Month_piv', width: 100, enableRowGroup: true, pivot: true, enablePivot: true
            },
            {
                headerName: "Reads",
                field: "Reads_sum",
                width: 110,
                aggFunc: "sum",
                enableValue: true,
                type: "numericColumn",
                valueFormatter: this.utility.formatNumber
            }
        ]
        let sWhere = '';
        if (params.data.Product == 'Models')
            sWhere = "and SVC.ACCOUNTID= '" + params.data.Client  +"' and CU.ContentTypeId = 'M'";
        else if (params.data.Product == 'Books')
            sWhere = "and SVC.ACCOUNTID= '" + params.data.Client +"' and RVD.DocTypeId IN (3, 6)";
        else
            sWhere = "and SVC.ACCOUNTID= '" + params.data.Client +"' and RVD.DocTypeId NOT IN (3, 6)";

        this.dataService.GetDataFromDataSource("slx", "_quota_detail", "file", sWhere , false).subscribe(
            rData => {
                this.rowData = rData;
            }
        );

        this.autoGroupColumnDef = {
            headerName: 'Group',
            width: 400,
            pinned: "left", lockPinned: true, cellClass: "lock-pinned",
            cellRendererParams: {
                suppressCount: true
            }
        }

    }

    // called when the cell is refreshed
    refresh(params: any): boolean {
        return false;
    }

    onGridReady(params) {
        var detailGridId = "detail_" + this.masterRowIndex;

        var gridInfo = {
            id: detailGridId,
            api: params.api,
            columnApi: params.columnApi
        };

        //console.log("adding detail grid info with id: ", detailGridId);
        this.masterGridApi.addDetailGridInfo(detailGridId, gridInfo);
    }

    ngOnDestroy(): void {
        var detailGridId = "detail_" + this.masterRowIndex;

        // ag-Grid is automatically destroyed

        //console.log("removing detail grid info with id: ", detailGridId);
        this.masterGridApi.removeDetailGridInfo(detailGridId);
    }

}
