import { Component, OnInit } from '@angular/core';
import { DataService } from '../shared/data.service';
import { ColDef, ColGroupDef, GridOptions, GridApi } from 'ag-grid-community';
import { UtilityService } from '../shared/utility.service';
import { DecksRegionFilter } from './decks-region-filter.component';
import { DecksOptionComponent } from './decks-option/decks-option.component';
import { BeehiveCookiesService } from '../shared/cookies.service';
import { BeehiveMessageService } from '../shared/message-service';

@Component({
    selector: 'app-decks',
    templateUrl: './decks.component.html',
    styleUrls: ['./decks.component.css']
})
export class DecksComponent implements OnInit {

    rowData = [];
    columnDefs: (ColDef | ColGroupDef)[];
    style: { width: string, height: string, theme: string };
    gridOptions: GridOptions;
    pageSize: any = '1000';
    gridName: string = 'DECKS';
    roleList: boolean = false;
    frameworkComponents: any;
    gridApi: GridApi;
    cartArray: any;
    buttonList: { text: string; }[];
    dataLoading: boolean = false;

    constructor(private dataService: DataService, private cookiesService: BeehiveCookiesService, private service: BeehiveMessageService) { }

    ngOnInit() {
        this.passValuestoGrid();
        this.fetchData();
        this.buttonList = [{ text: 'Excel' }];
    }

    getDataSource(params: any) {
        this.gridApi = params;
        this.setSelectedRows();
    }

    fetchData() {
        this.dataService.getDecks().subscribe((data: any) => {
            if (data) {
                this.rowData = data;
                this.gridApi && this.gridApi.setRowData(this.rowData);
                this.setSelectedRows();
            }
        });
    }

    passValuestoGrid() {
        this.style = { width: '100%', height: '624px', theme: 'ag-theme-balham my-grid' };
        var self = this;
        this.gridOptions = <GridOptions>{
            floatingFilter: true,
            rowGroupPanelShow: "onlyWhenGrouping",
            context: { componentParent: self },
            // masterDetail: true,
            // detailCellRendererParams: {
            //     detailGridOptions: {
            //         columnDefs: [
            //             {
            //                 field: 'Date',
            //                 headerName: 'Date',
            //                 cellRenderer: function (params: any) {
            //                     let formattedDate = params.value == undefined ? '' : new UtilityService().LocalDateDisplayFormat(params.value);
            //                     if (params.data) {
            //                         let href = "/research/viewmodel.aspx?f=" + params.data.FileName + "&ticker=" + (params.data.Ticker.indexOf('.') > 0 ? params.data.Ticker.replace(".", "_") : params.data.Ticker);
            //                         return "<a style='cursor: pointer;border-bottom: 1px solid blue' href=" + href + " > " + formattedDate + "</a>";
            //                     }
            //                 }
            //             },
            //             { field: 'Analyst' },
            //             { field: 'Action' },
            //             { field: 'Editor' }
            //         ],
            //         onFirstDataRendered: function (params: any) {
            //             params.api.sizeColumnsToFit();
            //         }
            //     },
            //     getDetailRowData: function (params: any) {
            //         self.dataService.modelsHistory(params.data.Ticker).subscribe((data: any) => {
            //             params.data.callRecords = data;
            //             params.successCallback(params.data.callRecords);
            //         });
            //     }
            // },
            // isRowMaster: function (dataItem) {
            //     return (self.roleList ||
            //         (self.franchiseList.indexOf(dataItem.AnalystId && dataItem.AnalystId.toString()) != -1)) ? true : false;
            // },
            // isFullWidthCell: function () {
            //     return false;
            // },
            rowClassRules: {
                'dropped': function (params) { return params.data && params.data.Status === 'Not Available' || params.data.Status === 'Expired' }
            }
        };
        this.columnDefs = [
            {
                headerName: 'Analyst', field: 'Analyst',
                width: 250, suppressSizeToFit: false, enableRowGroup: true, pinned: "left", lockPinned: true, cellClass: "lock-pinned", filter: "agTextColumnFilter"
            },
            { headerName: 'Industry', field: 'Industry', width: 250, enableRowGroup: true, filter: "agTextColumnFilter" },
            {
                headerName: 'Region',
                field: 'Region',
                width: 90,
                filter: "agTextColumnFilter",
                floatingFilterComponent: "sliderFloatingFilter",
                floatingFilterComponentParams: {
                    value: 'All',
                    suppressFilterButton: true
                },
                suppressMenu: true
            },
            {
                headerName: 'Effective', field: 'EffectiveDate', width: 120, enableRowGroup: true,
                valueFormatter: function (params) {
                    return params.value == undefined ? '' : new UtilityService().LocalDateDisplayFormat(params.value);
                },
                filterParams: {
                    comparator: function (filterLocalDateAtMidnight, cellValue) {
                        return new UtilityService().LocalDateComparator(filterLocalDateAtMidnight, cellValue);
                    },
                    browserDatePicker: true
                }
            },
            {
                headerName: 'Expiry', field: 'ExpiryDate', width: 120, enableRowGroup: true,
                valueFormatter: function (params) {
                    return params.value == undefined ? '' : new UtilityService().LocalDateDisplayFormat(params.value);
                },
                filterParams: {
                    comparator: function (filterLocalDateAtMidnight, cellValue) {
                        return new UtilityService().LocalDateComparator(filterLocalDateAtMidnight, cellValue);
                    },
                    browserDatePicker: true
                }
            },
            { headerName: 'Status', field: 'Status', width: 100, enableRowGroup: true },
            {
                headerName: "Option", field: "id", width: 75,
                cellRendererFramework: DecksOptionComponent
            },
            {
                headerName: "Cart",
                width: 100,
                checkboxSelection: true,
                cellStyle: params =>
                    ((params.data.Status === 'Not Available') || (params.data.Status === 'Expired')) ?
                        { 'pointer-events': 'none' }
                        : ''
            }
        ];
        this.frameworkComponents = { sliderFloatingFilter: DecksRegionFilter };
    }

    decksExpire(data: any) {
        this.fetchData();
        this.service.changeMessage({ 'itemRemoved': true, 'itemID': data.DeckId, 'type': 'Decks' });

        this.gridApi.forEachNode((node: any) => {
            if (node.selected === true)
                console.log(node.data.Industry);
        });
        let payload = {
            UserId: this.cookiesService.GetUserID(),
            ContentType: 'Decks',
            ContentId: data.DeckId,
            Selected: false
        }
        this.dataService.saveCart(payload).subscribe(() => { });
    }

    decksUpdate() {
        this.fetchData();
        this.setSelectedRows();
    }

    download(ID: string) {
        const http$ = this.dataService.downloadDecks(ID);

        http$.subscribe(
            result => {
                const a = document.createElement('a');
                a.href = URL.createObjectURL(result);
                a.download = ID + ".PDF";
                document.body.appendChild(a);
                a.click();
            }),
            err => {
                console.log('HTTP Error', err)
            },
            () => console.log('HTTP request completed.');
        return false;
    }

    onRowSelected(event: any) {
        if (this.cookiesService.GetUserID()) {
            this.dataService.getCart(this.cookiesService.GetUserID()).subscribe((data: any) => {
                if (data) {
                    this.cartArray = data;
                    let row = event.data;
                    let selected = event.node.selected;
                    let payload = {
                        UserId: this.cookiesService.GetUserID(),
                        ContentType: 'Decks',
                        ContentId: row.DeckId,
                        Selected: selected
                    }
                    if (selected) {
                        let item = this.cartArray.filter((v: any) => v.ContentId === event.node.data.DeckId && v.ContentType === 'Decks');
                        if (item.length == 0) {
                            this.service.changeMessage({ 'itemAdded': true, 'itemID': event.node.data.DeckId, 'type': 'Decks' });
                            payload['Selected'] = true;
                            this.dataService.saveCart(payload).subscribe(() => { });
                        }
                    }
                    else {
                        let item = this.cartArray.filter((v: any) => v.ContentId === event.node.data.DeckId && v.ContentType === 'Decks');
                        if (item.length == 1) {
                            this.service.changeMessage({ 'itemRemoved': true, 'itemID': event.node.data.DeckId, 'type': 'Decks' });
                            payload['Selected'] = false
                            this.dataService.saveCart(payload).subscribe(() => { });
                        }
                    }
                }
            });
        }
    }

    setSelectedRows(expiredDeckId?: any) {
        if (this.cookiesService.GetUserID()) {
            this.dataService.getCart(this.cookiesService.GetUserID()).subscribe(
                (val) => {
                    let records = [];
                    records = val.map((data: any) => data.ContentId);
                    // if (expiredDeckId && records.indexOf(expiredDeckId) >= 0) {
                    //     this.service.changeMessage({ 'itemRemoved': true, 'itemID': expiredDeckId, 'type': 'Decks' });
                    // }
                    this.gridApi && this.gridApi.forEachNode((node: any) => {
                        if (records.indexOf(node.data.DeckId) >= 0 && (expiredDeckId !== node.data.DeckId)) {
                            node.setSelected(true);
                        }
                    });
                });
        }
    }


    onButtonClick(text: any) {
        if (text === 'excel') {
            this.onBtExport();
        }
    }

    onBtExport() {
        this.dataLoading = true;
        let params = {};
        params = {
            fileName: this.gridName,
            sheetName: this.gridName,
            columnKeys: this.columnDefs.filter((data: any) => data.hide !== true).map((params: any) => params.field)
        }
        setTimeout(() => {
            this.gridApi.exportDataAsExcel(params);
        }, 0)
        setTimeout(() => {
            this.dataLoading = false;
        }, 2000)
    }

}
