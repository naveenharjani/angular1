import { Component, OnInit, Inject, ComponentFactoryResolver, ViewChild, ViewContainerRef } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../../shared/data.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { BeehivePageHeaderComponent } from '../../beehive-page-header/beehive-page-header.component';
import { BeehiveCookiesService } from '../../shared/cookies.service';

@Component({
  selector: 'app-decks-form',
  templateUrl: './decks-form.component.html',
  styleUrls: ['./decks-form.component.css']
})
export class DecksFormComponent implements OnInit {

  @ViewChild('container', { read: ViewContainerRef }) container: ViewContainerRef;
  progress: number;
  decksForm: FormGroup;
  file: any;
  childComponent: BeehivePageHeaderComponent;
  Analysts: any = [];
  base64File: string = null;
  filename: string = null;
  analystId: number;
  industryId: number;
  fileSize: any;

  constructor(private snackBar: MatSnackBar, private formBuilder: FormBuilder, private dataService: DataService, public dialogRef: MatDialogRef<DecksFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private resolver: ComponentFactoryResolver, private cookiesService: BeehiveCookiesService) { }

  ngOnInit() {
    this.industryId = this.data.industryId;
    this.analystId = this.data.analystId;
    this.createForm();
    this.dataService.getAnalyst().subscribe((author: any) => {
      this.Analysts = (author);
      this.decksForm.patchValue({
        Analysts: this.analystId ? this.analystId : ''
      });
    });
  }

  ngAfterContentInit() {
    let factory = this.resolver.resolveComponentFactory(BeehivePageHeaderComponent);
    let component = this.container.createComponent(factory);
    this.childComponent = component.instance;
    this.childComponent.beehivePageName = `Upload Decks`;
    this.childComponent.buttonList = [{ text: 'Close' }, { text: 'Upload' }];
    this.childComponent.isPopUp = true;
    this.childComponent.onButtonClick.subscribe((buttonText: any) => {
      if (buttonText === 'upload') {
        this.upload();
      }
      else if (buttonText === 'close') {
        this.close();
      }
    })
  }

  close() {
    this.dialogRef.close();
  }

  createForm() {
    this.decksForm = this.formBuilder.group({
      Analysts: new FormControl('', Validators.required),
      FileUpload: new FormControl('', Validators.required)
    });
    this.decksForm.controls['Analysts'].disable();
  }

  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      if ((e.target.files[0].name.split('.')[1]).toUpperCase() === 'PDF') {
        const fReader = new FileReader();
        fReader.readAsDataURL(file)
        fReader.onloadend = (_event: any) => {
          this.filename = file.name;
          this.fileSize = file.size;
          this.base64File = _event.target.result;
          this.decksForm.patchValue({
            FileUpload: this.filename
          });
        }
      }
      else {
        window.alert('The uploaded file needs to be Portable Document Format!');
      }
    } catch (error) {
      this.filename = null;
      this.base64File = null;
      console.log('no file was selected...');
    }
  }

  upload() {
    if (this.decksForm.valid) {
      let formData = {
        AnalystId: this.decksForm.controls['Analysts'].value,
        IndustryId: this.industryId,
        FileStream: this.base64File,
        FileName: this.decksForm.controls['FileUpload'].value,
        FileSize: this.fileSize,
        EditorId: this.cookiesService.GetUserID()
      };
      this.dataService.uploadDecks(formData).subscribe((message: any) => {
        if (message) {
          this.snackBar.open(message, 'Close', {
            duration: 2000
          });
        }
        this.close();
      });
    }
    else {
      window.alert('Please select a proper Portable Document Format')
    }

  }

  clearFile() {
    this.decksForm.patchValue({
      FileUpload: null
    });
    this.base64File = null;
  }

}
