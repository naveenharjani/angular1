import { Component, OnInit } from '@angular/core';
import { BeehiveCookiesService } from '../../shared/cookies.service';
import { DataService } from '../../shared/data.service';
import { Role } from '../../beehive-page-header/permissions.enums';
import { MatDialog, MatSnackBar } from '@angular/material';
import { DecksFormComponent } from '../decks-form/decks-form.component';

@Component({
  selector: 'app-decks-option',
  templateUrl: './decks-option.component.html',
  styleUrls: ['./decks-option.component.css']
})
export class DecksOptionComponent implements OnInit {

  params: any;
  isAdmin: boolean = false;
  isDisabled: boolean = false;

  constructor(private snackBar: MatSnackBar, private dataService: DataService, public dialog: MatDialog, private cookiesService: BeehiveCookiesService) { }

  ngOnInit() {
    this.dataService.IsInRole(Role.deManager).subscribe((val: any) => {
      val ? this.isAdmin = true : this.isAdmin = false;
    });
  }

  agInit(params: any): void {
    this.params = params;
    this.params && this.params.data && (this.params.data.Status === 'Expired' || this.params.data.Status === 'Not Available') ? (this.isDisabled = true) : this.isDisabled = false;
  }

  exportCart() {
    let url = '/research/email.aspx?type=model&id=' + this.params.data.SecurityId + '&ticker=' + this.params.data.Ticker;
    window.open(url.toString(), 'FORM', 'left=50,top=50,width=1000,height=750,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
    return false;
  }

  expireDecks() {
    this.dataService.expireDecks(this.params.data.DeckId, this.cookiesService.GetUserID()).subscribe((message: any) => {
      if (message) {
        this.snackBar.open(message, 'Close', {
          duration: 2000
        });
        this.params.context.componentParent.decksExpire(this.params.data);
      }
    });
  }

  uploadDecks() {
    const dialogRef = this.dialog.open(DecksFormComponent, {
      height: '400px',
      width: '600px',

      hasBackdrop: false,
      data: { industryId: this.params.data.IndustryId, analystId: this.params.data.AnalystId }
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.isDisabled = false;
      this.params.context.componentParent.decksUpdate(this.params.data);
    });
  }

  downloadDecks() {
    this.params.context.componentParent.download(this.params.data.DeckId);
  }

}
