import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DecksOptionComponent } from './decks-option.component';

describe('DecksOptionComponent', () => {
  let component: DecksOptionComponent;
  let fixture: ComponentFixture<DecksOptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DecksOptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DecksOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
