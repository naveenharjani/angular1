import { NgModule } from '@angular/core';
import 'ag-grid-enterprise';
import { CommonModule } from '@angular/common';
import { AbGridModule } from '../ab-grid/ab-grid.module';
import { EmailFormModule } from '../email-form/email-form.module';
import { MaterialModule } from '../material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DecksComponent } from './decks.component';
import {
    MatFormFieldModule, MatInputModule, MatSelectModule, MatCardModule, MatChipsModule, MatIconModule, MatDatepickerModule,
    MatDialogModule, MatSnackBarModule, MatButtonModule, MatTooltipModule, MatProgressSpinnerModule
} from '@angular/material';
import { AgGridModule } from 'ag-grid-angular';
import { DecksRegionFilter } from './decks-region-filter.component';
import { DecksOptionComponent } from './decks-option/decks-option.component';
import { DecksFormComponent } from './decks-form/decks-form.component';
import { BeehivePageHeaderModule } from '../beehive-page-header/beehive-page-header.module';

let materialInputs = [MatFormFieldModule, MatInputModule, MatSelectModule, MatCardModule, MatChipsModule, MatTooltipModule,
    MatIconModule, MatDatepickerModule, MatDialogModule, MatSnackBarModule, MatButtonModule, MatProgressSpinnerModule];

@NgModule({
    declarations: [DecksComponent, DecksOptionComponent, DecksRegionFilter, DecksFormComponent],
    imports: [CommonModule, AbGridModule, EmailFormModule, MaterialModule, BeehivePageHeaderModule,
        AgGridModule.withComponents([DecksRegionFilter]), ReactiveFormsModule, ...materialInputs, FormsModule],
    providers: [],
    entryComponents: [DecksComponent, DecksOptionComponent, DecksFormComponent],
    exports: [DecksComponent],
    bootstrap: [DecksComponent]
})
export class DecksModule {

}
