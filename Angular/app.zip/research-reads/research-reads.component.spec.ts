import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResearchReadsComponent } from './research-reads.component';

describe('ResearchReadsComponent', () => {
  let component: ResearchReadsComponent;
  let fixture: ComponentFixture<ResearchReadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResearchReadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResearchReadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
