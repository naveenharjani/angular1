import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { DataService } from '../shared/data.service';
import { Observable, Subject } from 'rxjs';
import { ColDef, ColGroupDef, GridApi, GridOptions } from 'ag-grid-community';
import { UtilityService } from '../shared/utility.service';
import { Router, ActivatedRoute, RouterEvent, NavigationEnd } from '@angular/router';
import { ResearchReadDetailsComponent } from './research-read-details/research-read-details.component';
import { filter, takeUntil } from 'rxjs/operators';
import { CalendarUtility } from '../shared/calendar-utility';
import { DatePipe } from '@angular/common';
import { Role } from '../beehive-page-header/permissions.enums';
import { EnvService } from '../../env.service'; 

@Component({
  selector: 'app-research-reads',
  templateUrl: './research-reads.component.html',
  styleUrls: ['./research-reads.component.css']
})
export class ResearchReadsComponent implements OnInit {

  gridApi: GridApi;
  filtersForm: FormGroup;
  Analysts$: Observable<any[]>;
  rowData = [];
  style: { width: string, height: string, theme: string };
  pageSize: any = '1000';
  gridName: string = 'RESEARCH READS';
  columnDefs: (ColDef | ColGroupDef)[];
  buttonList: { text: string; }[];
  dataLoading: boolean = false;
  enableDetail: any;
  gridOptions: GridOptions;
  destroyed = new Subject<any>();
  calendarUtility: CalendarUtility = new CalendarUtility();

  constructor(private dataService: DataService, private router: Router, private route: ActivatedRoute, private datePipe: DatePipe, private environment: EnvService) { }

  ngOnInit() {
    this.buildForm();
    this.loadPage();
  }

  loadPage() {
    this.gridOptions = <GridOptions>{
      floatingFilter: true,
      context: { componentParent: this }
    }

    if (this.filtersForm.controls['rangeDatePickerTo'].value === "" && this.filtersForm.controls['rangeDatePickerFrom'].value === "") {
      console.log('Initial Load');
      let sinceDate = new Date();
      sinceDate.setDate(sinceDate.getDate() - this.environment.DownloadsFromDays);
      this.filtersForm.patchValue({
        rangeDatePickerTo: new Date(),
        rangeDatePickerFrom: sinceDate
      });
      let to = new Date(this.filtersForm.controls['rangeDatePickerTo'].value);
      let from = new Date(this.filtersForm.controls['rangeDatePickerFrom'].value);
      this.router.navigate(['/research-reads'], { queryParams: { 'analystid': 0, 'from': this.datePipe.transform(this.calendarUtility.formatDate(from), 'MM-dd-yyyy').toString(), 'to': this.datePipe.transform(this.calendarUtility.formatDate(to), 'MM-dd-yyyy').toString() } });
    }

    this.filtersForm.controls['Analysts'].valueChanges.subscribe((analystid: any) => {
      if (this.filtersForm.valid) {
        if (analystid !== undefined && analystid !== parseInt(this.route.snapshot.queryParams.analystid)) {
          let to = new Date(this.filtersForm.controls['rangeDatePickerTo'].value) ? new Date(this.filtersForm.controls['rangeDatePickerTo'].value) : this.route.snapshot.queryParams.to;
          let from = new Date(this.filtersForm.controls['rangeDatePickerFrom'].value) ? new Date(this.filtersForm.controls['rangeDatePickerFrom'].value) : this.route.snapshot.queryParams.from;
          this.router.navigate(['/research-reads'], { queryParams: { 'analystid': analystid, 'from': this.datePipe.transform(this.calendarUtility.formatDate(from), 'MM-dd-yyyy').toString(), 'to': this.datePipe.transform(this.calendarUtility.formatDate(to), 'MM-dd-yyyy').toString() } });
        }
      }
    });

    this.router.events.pipe(
      filter((event: RouterEvent) => event instanceof NavigationEnd),
      takeUntil(this.destroyed)
    ).subscribe((val: any) => {
      const to = val.url.split('?')[1].split('&')[2].split('=')[1] ? new Date(val.url.split('?')[1].split('&')[2].split('=')[1]) : '';
      const from = val.url.split('?')[1].split('&')[1].split('=')[1] ? new Date(val.url.split('?')[1].split('&')[1].split('=')[1]) : '';
      const analystid = val.url.split('?')[1].split('&')[0].split('=')[1] ? val.url.split('?')[1].split('&')[0].split('=')[1] : '';
      let routeParams = { to: to, from: from, 'analystid': analystid };
      this.fetchData(routeParams);
      this.patchValue(routeParams);
    });
  }

  ngOnDestroy(): void {
    this.destroyed.next();
    this.destroyed.complete();
  }

  buildForm() {
    this.buttonList = [{ text: 'Excel' }, { text: 'Refresh' }];
    this.filtersForm = new FormGroup({
      rangeDatePickerTo: new FormControl(''),
      rangeDatePickerFrom: new FormControl(''),
      Analysts: new FormControl('')
    });
    this.Analysts$ = this.dataService.getAnalyst();
  }

  patchValue(routeParams: any) {
    this.filtersForm.patchValue({
      rangeDatePickerTo: new Date(routeParams.to),
      rangeDatePickerFrom: new Date(routeParams.from),
      Analysts: parseInt(routeParams.analystid)
    });
  }

  fetchData(routeParams?: any) {
    let researchAuthor = routeParams ? routeParams.analystid : this.filtersForm.controls['Analysts'].value;
    let endDate = routeParams ? this.calendarUtility.formatDate(routeParams.to) : this.calendarUtility.formatDate(this.filtersForm.controls['rangeDatePickerTo'].value);
    let startDate = routeParams ? this.calendarUtility.formatDate(routeParams.from) : this.calendarUtility.formatDate(this.filtersForm.controls['rangeDatePickerFrom'].value);
    if (researchAuthor !== '' && endDate !== '' && startDate !== '') {
      this.dataLoading = true;
      this.dataService.getResearchReadsData(researchAuthor, startDate, endDate).subscribe((data: any) => {
        this.rowData = data[0];
        //this.enableDetail = data[2].toLowerCase() == 'true' || data[1];
        this.enableDetail =  data[1];
        this.passValuestoGrid();
        this.dataLoading = false;
      });
    }
  }

  rangeDatePickerValueChange() {
    if (this.filtersForm.controls['rangeDatePickerTo'].value === null) {
      this.filtersForm.patchValue({
        rangeDatePickerTo: new Date()
      });
    }
    if (this.filtersForm.controls['rangeDatePickerFrom'].value === null) {
      this.filtersForm.patchValue({
        rangeDatePickerFrom: new Date()
      });
    } 
     var FromDt=new Date(this.datePipe.transform(this.calendarUtility.formatDate(this.filtersForm.controls['rangeDatePickerFrom'].value), 'MM-dd-yyyy'));
     var ToDt= new Date(this.datePipe.transform(this.calendarUtility.formatDate(this.filtersForm.controls['rangeDatePickerTo'].value), 'MM-dd-yyyy'));
    
    // if (this.calendarUtility.formatDate(this.filtersForm.controls['rangeDatePickerFrom'].value) > this.calendarUtility.formatDate(this.filtersForm.controls['rangeDatePickerTo'].value)) {
    
    //   this.filtersForm.setErrors({ 'DateRangeInvalid': true });
    // }
    if(FromDt>ToDt)
    {
      this.filtersForm.setErrors({ 'DateRangeInvalid': true });
    }
    else {
      this.filtersForm.setErrors(null);
    }
    if (this.filtersForm.valid) {
      let analystid = this.filtersForm.controls['Analysts'].value;
      let to = new Date(this.filtersForm.controls['rangeDatePickerTo'].value);
      let from = new Date(this.filtersForm.controls['rangeDatePickerFrom'].value);
      this.router.navigate(['/research-reads'], { queryParams: { 'analystid': analystid, 'from': this.datePipe.transform(this.calendarUtility.formatDate(from), 'MM-dd-yyyy').toString(), 'to': this.datePipe.transform(this.calendarUtility.formatDate(to), 'MM-dd-yyyy').toString() } });
    }
  }

  passValuestoGrid() {
    var self=this;
    this.style = { width: '100%', height: '624px', theme: 'ag-theme-balham my-grid' };
    this.columnDefs = [
      {
        headerName: 'ID',
        field: 'PubNo',
        width: 80
      },
      {
        headerName: 'Date', field: 'Date', width: 110, enableRowGroup: true,
        valueFormatter: function (params) {
          return params.value == undefined ? '' :self.datePipe.transform(self.calendarUtility.formatDate(params.value), 'dd-MMM-yyyy');
        }
        // valueFormatter: function (params) {
        //   return params.value == undefined ? '' : new UtilityService().LocalDateDisplayFormat(params.value);
        // },
        // filterParams: {
        //   comparator: function (filterLocalDateAtMidnight, cellValue) {
        //     return new UtilityService().LocalDateComparator(filterLocalDateAtMidnight, cellValue);
        //   },
        //   browserDatePicker: true
        // }
      },
      { headerName: 'Type', field: 'Type', width: 120, filter: 'agSetColumnFilter' },
      { headerName: 'Title', field: 'Title', filter: "agTextColumnFilter", width: 700 },
      { headerName: 'Primary Author', field: 'Author', width: 120, filter: 'agSetColumnFilter' },
      {
        headerName: 'Reads', field: 'read_count', width: 80, cellClass: 'rightAlignIssueFix',
        cellRendererFramework: ResearchReadDetailsComponent,
        cellRendererParams: {
          enableDetail: this.enableDetail
        }
      }
    ];
  }

  getDataSource(params: GridApi) {
    this.gridApi = params;
    if (this.rowData.length == 0) {
      this.gridApi && this.gridApi.setRowData([]);
    }
  }

  onButtonClick(text: any) {
    if (text === 'refresh' && this.filtersForm.valid) {
      let to = new Date(this.filtersForm.controls['rangeDatePickerTo'].value) ? new Date(this.filtersForm.controls['rangeDatePickerTo'].value) : undefined;
      let from = new Date(this.filtersForm.controls['rangeDatePickerFrom'].value) ? new Date(this.filtersForm.controls['rangeDatePickerFrom'].value) : undefined;
      this.router.navigate(['/research-reads'], { queryParams: { 'analystid': this.filtersForm.controls['Analysts'].value, 'from': this.datePipe.transform(this.calendarUtility.formatDate(from), 'MM-dd-yyyy').toString(), 'to': this.datePipe.transform(this.calendarUtility.formatDate(to), 'MM-dd-yyyy').toString() } });
    }
    if (text === 'excel') {
      this.onBtExport();
    }
  }

  onBtExport() {
    this.dataLoading = true;
    setTimeout(() => {
      this.gridApi.exportDataAsExcel({
        fileName: this.gridName,
        sheetName: this.gridName
      })
    }, 0)
    setTimeout(() => {
      this.dataLoading = false;
    }, 2000)
  }

  openLink(data: any) {
    let url = '/research/researchreaddetails.aspx?PubNo=' + data.PubNo;
    window.open(url.toString(), 'FORM', 'left=50,top=50,width=1000,height=750,menubar=no,toolbar=no,location=no,directories=no,status=yes,resizable=yes,scrollbars=yes', true);
    return false;
  }
}
