import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { AgGridModule } from 'ag-grid-angular';
import { ResearchReadsComponent } from './research-reads.component';
import { AbGridModule } from '../ab-grid/ab-grid.module';
import { BeehivePageHeaderModule } from '../beehive-page-header/beehive-page-header.module';
import { MatDatepickerModule, MatSnackBarModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatCardModule, MatButtonModule, MatProgressSpinnerModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BeehiveCommonModule } from '../beehive-components.module';
import { ResearchReadDetailsComponent } from './research-read-details/research-read-details.component';
const materialsModule = [MatDatepickerModule, MatSnackBarModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatCardModule,
    MatButtonModule, BeehiveCommonModule, MatProgressSpinnerModule];

@NgModule({
    declarations: [ResearchReadsComponent, ResearchReadDetailsComponent],
    imports: [AbGridModule, CommonModule, AgGridModule.withComponents([]), BeehivePageHeaderModule, ...materialsModule, FormsModule, ReactiveFormsModule],
    providers: [],
    entryComponents: [ResearchReadDetailsComponent],
    exports: [ResearchReadsComponent],
    bootstrap: [ResearchReadsComponent]
})
export class ResearchReadsModule {

}
