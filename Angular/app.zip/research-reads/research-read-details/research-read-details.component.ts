import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-research-read-details',
  templateUrl: './research-read-details.component.html',
  styleUrls: ['./research-read-details.component.css']
})
export class ResearchReadDetailsComponent implements OnInit {

  params: any;
  enableDetail: boolean;

  constructor() { }

  ngOnInit() {
  }

  agInit(params: any): void {
    this.params = params;
    this.enableDetail = this.params.colDef.cellRendererParams.enableDetail;
  }

  onClick() {
    this.params.context.componentParent.openLink(this.params.data);
  }

}
