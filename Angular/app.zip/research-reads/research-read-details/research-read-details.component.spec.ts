import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResearchReadDetailsComponent } from './research-read-details.component';

describe('ResearchReadDetailsComponent', () => {
  let component: ResearchReadDetailsComponent;
  let fixture: ComponentFixture<ResearchReadDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResearchReadDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResearchReadDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
