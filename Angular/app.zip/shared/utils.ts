import { ColumnProperties } from "./column-properties";


// export function buildColumnDefinations(data: any): ColumnProperties[]{
//     let props: any[] = Object.keys(data);
//     let columnDefinations: ColumnProperties[] = [];
//     props.forEach((prop) => {
//       let columnproperty = {
//         headerName: prop,
//         field: prop,
//         sortable: true,
//         resizable: true,
//         suppressMenu: true
//       }
//       columnDefinations.push(columnproperty);
//     });
//     columnDefinations.push({
//       headerName: 'View',
//       field: 'View',
//       sortable: true,
//       resizable: true,
//       suppressMenu: true,
//       cellRendererFramework: ViewIndustryComponent
//     });
//     this.context = { componentParent: this };
//     return columnDefinations;
// }

