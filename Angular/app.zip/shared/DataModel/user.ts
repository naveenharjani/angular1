export class User {
    id: number;
    username: string;
    key: string;
    applicationid: string;
    JwtToken?: string;
    RefreshToken?:string;
}