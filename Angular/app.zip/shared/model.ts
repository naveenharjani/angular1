export class Model{
    ticker : string;
    companyName : string;
}