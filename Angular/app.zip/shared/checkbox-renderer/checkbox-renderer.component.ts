import { Component, OnInit } from '@angular/core';
import {AgRendererComponent} from 'ag-grid-angular';
import { BeehiveMessageService } from '../message-service';
import { DataService } from '../data.service';
import { BeehiveCookiesService } from '../cookies.service';


@Component({
  selector: 'app-checkbox-renderer',
  templateUrl: './checkbox-renderer.component.html',
  styleUrls: ['./checkbox-renderer.component.css']
})

export class AgGridCheckboxComponent implements AgRendererComponent {

  public params: any;
  private isFired:boolean;
  public isDisabled:boolean;

  constructor(private service: BeehiveMessageService, private dataService: DataService,
     private cookiesService: BeehiveCookiesService) {
}
  agInit(params: any): void {
    this.params = params;
    this.isDisabled = this.isCheckboxDisabled(params.data);
  }
  
  refresh(params: any): boolean {
    params.data.IsInCart = params.value
    if (this.cookiesService.GetUserID() && !this.isFired) {
            let row = params.data, isSelected = params.value, 
              contentType = this.getContentType(params.data),
              contentId = this.getContentId(params.data),
              payload = {
                UserId: this.cookiesService.GetUserID(),
                ContentType: contentType,
                ContentId: contentId,
                Selected: isSelected
            }
              isSelected  ? this.service.changeMessage({ 'itemAdded': true, 'itemID': contentId, 'type': contentType})
                          : this.service.changeMessage({ 'itemRemoved': true, 'itemID': contentId, 'type': contentType})
              this.dataService.saveCart(payload).subscribe(() => {});
              this.isFired =true;
    }
    params.api.refreshCells(params);
    return false;
  }

    getContentType(data: any) {
        if (data !== undefined) {
            if (data.ModelId !== undefined && data.ModelId !== null) {
                return "Model";
            }
            else if (data.AssetId !== undefined && data.AssetId !== null) {
                return "Asset";
            }
            else
            return "Research";
        }
    }

  getContentId (data:any){
    if (data !== undefined ){
      return data.ModelId !== undefined && data.ModelId !== null ? data.SecurityId 
       : data.AssetId !== undefined && data.AssetId !== null ? data.LinkId : data.Id
    } 
  }

  isCheckboxDisabled(data:any){
    if (data !== undefined){
        if (data.ModelId !== undefined && data.ModelId !== null ){
          return data.Status === "Active"  ? false
          :  true;
        } 
      if ( data.AssetId !== undefined && data.AssetId !== null ){
        return data.State === "Active"  ? false
        :  true;
      }
    }
  }

}