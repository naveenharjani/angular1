import { Injectable } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Role } from '../beehive-page-header/permissions.enums';
@Injectable({
  providedIn: 'root'
})
export class GlobaldataService {

  isInRoleCalled:boolean=false;
  isInRoleValue:boolean=false;
  constructor() { }
  isAdmin:boolean=false;
  getIsInRole(){
    var roles = this.getCookies("RolesList");    
    if (roles != "")
      {
        var roleList = roles.split(',');
        for(var i=0;i<roleList.length;i++)
          if( roleList[i]==Role.deAdministrator.toString())
          {
           return true;
          }
          else if(roleList[i]==Role.deManager.toString())
          {
            return true;
          }
        }        
    else{
        return false; 
      }
  }
  getCookies(role){
    var name = role + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
}
