import { NgModule } from '@angular/core';
import { MatButtonModule, MatDialogModule } from '@angular/material';
import { SaveAsDialogComponent } from './save-as-dialog.component';

@NgModule({
  declarations: [SaveAsDialogComponent],
  imports: [
      MatButtonModule, MatDialogModule
  ],
  exports: [
      MatButtonModule, MatDialogModule, SaveAsDialogComponent
  ],
  bootstrap: [SaveAsDialogComponent]
})
export class SaveAsDialogModule {
}
