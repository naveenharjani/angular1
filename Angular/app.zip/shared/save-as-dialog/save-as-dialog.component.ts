import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SaveAsDialogModel } from './save-as-dialog.model';

@Component({
  selector: 'app-save-as-dialog',
  templateUrl: './save-as-dialog.component.html',
  styleUrls: ['./save-as-dialog.component.css']
})
export class SaveAsDialogComponent implements OnInit {

  title: string;
  message: string;
  messageFront: string;
  messageRear: string;
  messageParam:string; 
  show:boolean;

  constructor(public dialogRef: MatDialogRef<SaveAsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: SaveAsDialogModel) { }

  ngOnInit() {
    this.message = this.data.message;    
    this.show=false;
    if(this.data.messageParam){
      this.show=true;       
    this.messageFront=this.data.messageFront;
    this.messageRear=this.data.messageRear;
    }
  }

  onConfirm(): void {
    // Close the dialog, return true
    this.dialogRef.close(true);
  }

  onDismiss(): void {
    // Close the dialog, return false
    this.dialogRef.close(false);
  }
  onCancel(): void {
    
    this.dialogRef.close();
  }

}
