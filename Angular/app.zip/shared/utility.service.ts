import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';


@Injectable()
export class UtilityService {

    constructor() { }


    ConvertDateTimetoLocal(utcDate): Date {
        var newDate = new Date(utcDate);
        newDate.setMinutes(newDate.getMinutes() - newDate.getTimezoneOffset());
        return newDate;
    }

    LocalDateDisplayFormat(utcDate): string {

        var options = {
            day: '2-digit', month: 'short', year: 'numeric'
        };//dd-MMM-yyyy HH:mm  // wednesday july 11, 2018 //20-Jul-2018 12:20 
        return utcDate == undefined ? '' : this.ConvertDateTimetoLocal(utcDate).toLocaleString("en-GB", options).replace(/ /g, '-');

    }

    LocalDateComparator(filterLocalDateAtMidnight, cellValue): any {
        var dateAsString = cellValue;
        if (dateAsString == null) return -1;
        var cellDate = new Date(dateAsString);
        cellDate.setMinutes(cellDate.getMinutes() - cellDate.getTimezoneOffset());

        if (cellDate.toLocaleDateString() == filterLocalDateAtMidnight.toLocaleDateString()) {
            return 0;
        }
        if (cellDate < filterLocalDateAtMidnight) {
            return -1;
        }
        if (cellDate > filterLocalDateAtMidnight) {
            return 1;
        }
    }

    currencyFormatter(params) {
        if (params.value == '' || params.value == null)
            return params.value;
        else
            return "\xA3" + this.formatNumber(params);
    }

    formatNumber(params) {
        if (params.value == '' || params.value == null)
            return params.value;
        else
            return Math.floor(params.value)
                .toString()
                .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
    }


}


