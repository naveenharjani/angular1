import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { EnvService } from '../../../env.service';
//import { environment } from '../../../environments/environment';
import { User } from '../DataModel/user';
import { BeehiveCookiesService } from '../cookies.service';
import { CookieService } from 'ngx-cookie';
import * as CryptoJS from  'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {   
  private userSubject: BehaviorSubject<User>;
  public user: Observable<User>;
  private integratedBaseUrl: string = this.environment.integratedBaseUrl;
  public currentUser:any;
  secretKey = "1234432156788765";
  constructor(
      private router: Router,
      private http: HttpClient,
      private environment: EnvService,
      private cookiesService: BeehiveCookiesService,
      private _CookieService: CookieService
  ) {
      this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
      this.user = this.userSubject.asObservable();
  }

  public get userValue(): User {
      return this.userSubject.value;
  }

   
  getToken(userID: string){
    let key= this.encrypt(this.environment.secretKey);
    let applicationId=this.encrypt(this.environment.applicationId);
    let headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'responseType': 'json',
        'UserName':this.encrypt(userID),
        'key':key,
        'applicationId':applicationId
    });
    return this.http.post<any>(`${this.integratedBaseUrl}Auth/GetAccessToken`, { userID},{ headers: headers })
        .pipe(map(user => {
            this.userSubject.next(user);
           // localStorage.setItem('currentUser', JSON.stringify(user));
            this.storeTokens(user);
            console.log('gettoken return' +user);
            console.log('gettoken return' +JSON.parse(localStorage.getItem('currentUser')));
            return user;
        }));
}
  refreshToken(userID: string) {
    let key=this.encrypt(this.environment.secretKey);
    let applicationId=this.encrypt(this.environment.applicationId);
    let currentUser = JSON.parse(localStorage.getItem('currentUser')) ;
    let refreshToken=currentUser["RefreshToken"];
    let headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'responseType': 'json',
        'UserName': this.encrypt(userID),
        'key':key,
        'applicationId':applicationId,
        'RefreshToken':refreshToken
    });
      return this.http.post<any>(`${this.integratedBaseUrl}Auth/GetRefreshToken`, { userID}, { headers: headers })
          .pipe(map((user) => {
                this.userSubject.next(user);   
             this.storeJwtToken(user);  
               // localStorage.setItem('currentUser', JSON.stringify(user));
              return user;              
          }))
          ;
  }

  //  methods

  findToken() { 
    this.currentUser =localStorage.getItem('currentUser')!=undefined && localStorage.getItem('currentUser')!=null ? JSON.parse(localStorage.getItem('currentUser')):null ;      
    if( this.currentUser==null){
     return null;}
    else{
    return this.currentUser.JwtToken;}
  }
  private getRefreshToken() {
    return this.currentUser.RefreshToken; 
  }

  private storeJwtToken(token: User) {
    if(token.JwtToken!=undefined || token.JwtToken!=null){
    localStorage.setItem('currentUser', JSON.stringify(token));
    this.cookiesService.SetJwtTokenCookies(JSON.stringify(token));
    this._CookieService.put('JwtCurrentUser',JSON.stringify(token));
    console.log(JSON.stringify(token));
    }
  }

  private storeTokens(tokens: User) {
    if(tokens.JwtToken!=undefined || tokens.JwtToken!=null){
    localStorage.setItem('currentUser', JSON.stringify(tokens));
    this.cookiesService.SetJwtTokenCookies(JSON.stringify(tokens));
    this._CookieService.put('JwtCurrentUser',JSON.stringify(tokens));
    console.log(JSON.stringify(tokens));
    }
  }

  public removeTokens() {
    localStorage.removeItem('currentUser');
  }

  encrypt(value : string) : string{
    //return CryptoJS.AES.encrypt(value, this.secretKey.trim()).toString();   
   var key = CryptoJS.enc.Utf8.parse(this.secretKey.trim());
   var iv = CryptoJS.enc.Utf8.parse(this.secretKey.trim());
   var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(value.toString()), key,
   {
       keySize: 128 / 8,
       iv: iv,
       mode: CryptoJS.mode.CBC,
       padding: CryptoJS.pad.Pkcs7
   });
return(encrypted.toString());
  }

}
