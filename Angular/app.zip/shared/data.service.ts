import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders, HttpErrorResponse, HttpRequest } from '@angular/common/http';
import { Observable, forkJoin, throwError, observable } from 'rxjs';
import {  of } from 'rxjs';
import {
    WINDOW_TOKEN
} from '../shared/active-xobject.service';
import { EnvService } from '../../env.service';
import { map, catchError } from 'rxjs/operators';
import { Role } from '../beehive-page-header/permissions.enums';
import { BeehiveCookiesService } from '../shared/cookies.service';

@Injectable()
export class DataService {
    private baseUrl: string = this.environment.baseUrl;
    private autocompleteUrl: string = this.environment.autoCompleteUrl;
    private gridUrl: string = this.environment.gridUrl;
    private integratedBaseUrl: string = this.environment.integratedBaseUrl;
    private prodApiUrl: string;
    private type: string;
    private tickers: Array<object> = [];
    private isInRoleReturn:boolean;
     

    constructor(private http: HttpClient, @Inject(WINDOW_TOKEN) private windowToken: any, private environment: EnvService,private cookiesService: BeehiveCookiesService) {
        this.prodApiUrl = this.windowToken.prodApiUrl;
        console.log(this.baseUrl);
        console.log(this.integratedBaseUrl);
    }

    GetModelData(userId:string): Observable<any[]> {
        return this.http.get<any[]>(this.integratedBaseUrl + "models/getmodels?userId=" + userId);
    }

    GetAllModelData(): any {
        return this.http.get(this.baseUrl + "getModelData?type=0&filter=")
    }


    GetModelDdRender(): Observable<any> {
        return this.http.get<any>(this.baseUrl + "getRenderModelDropDown?styleid=4&userid=1");

    }

    GetResearchUsage(sinceDate: Date, untilDate: Date): Observable<any[]> {
        var swhere = "";
        if (sinceDate != undefined && untilDate != undefined) {
            var until = new Date();
            until.setDate(untilDate.getDate() + 1);
            swhere = "where ACCESSDATE > '" + sinceDate.toLocaleDateString().split(',')[0] + "' AND ACCESSDATE < '" + until.toLocaleDateString().split(',')[0] + "'";
        }
        return this.http.get<any[]>(this.baseUrl + "getResearchUsage?sWHERE=" + encodeURI(swhere));
    }

    GetContentUsageDdRender(): Observable<any> {
        return this.http.get<any>(this.baseUrl + "getRenderContentUsage");

    }

    GetSourceData(source: string, sWhere: string): Observable<any[]> {
        var params = "source=" + source + "&sWhere=" + sWhere;
        console.log(this.gridUrl);
        return this.http.get<any[]>(this.gridUrl + "getDataFromSource?" + encodeURI(params));
    }

    GetTreeContentUsageData(sinceDate: Date, untilDate: Date): Observable<any[]> {
        var swhere = "";
        if (sinceDate != undefined && untilDate != undefined) {
            var until = new Date();
            until.setDate(untilDate.getDate() + 1);
            swhere = "where ACCESSDATE > '" + sinceDate.toLocaleDateString().split(',')[0] + "' AND ACCESSDATE < '" + until.toLocaleDateString().split(',')[0] + "'";
        }
        var params = "source=_tree-contentusage&sWhere=" + swhere;
        return this.http.get<any[]>(this.baseUrl + "getDataFromSource?" + encodeURI(params));
    }

    GetTreePortalUsageData(sinceDate: Date, untilDate: Date): Observable<any[]> {
        var swhere = "";
        if (sinceDate != undefined && untilDate != undefined) {
            var until = new Date();
            until.setDate(untilDate.getDate() + 1);
            swhere = "where ACCESSDATE > '" + sinceDate.toLocaleDateString().split(',')[0] + "' AND ACCESSDATE < '" + until.toLocaleDateString().split(',')[0] + "'";
        }
        var params = "source=tree-portalusage&sWhere=" + swhere;
        return this.http.get<any[]>(this.baseUrl + "getDataFromSource?" + encodeURI(params));
    }


    GetDataFromDataSource(source: string, sql: string, sqlType: string, sWhere: string, withType: Boolean): Observable<any[]> {

        var params = "source=" + source + "&sql=" + sql + "&sqlType=" + sqlType + "&sWhere=" + sWhere + "&withtype=" + withType;
        return this.http.get<any[]>(this.gridUrl + "getDataFromDataSource?" + encodeURI(params));
    }

    GetFileProcessingLog(SinceDate: Date, UntilDate: Date): Observable<any[]> {

        if (SinceDate != undefined && UntilDate != undefined) {
            var until = new Date();
            until.setDate(UntilDate.getDate() + 1);
        }
        return this.http.get<any[]>(this.baseUrl + "getFileProcessingLog?FromDate=" + SinceDate.toLocaleDateString().split(',')[0] + "&ToDate=" + UntilDate.toLocaleDateString().split(',')[0]);
    }

    // GetPortalEmbargo(): Observable<any[]> {
    //     return this.http.get<any[]>(this.baseUrl + "getPortalEmbargo");
    // }

    // GetPortalEmbargopost(columnDefs: any[]): Observable<any[]> {

    //     return this.http.post<any[]>(this.baseUrl + "AddModel", columnDefs);
    // }

    searchByText(searchText: any): Observable<any[]> {
        let params = new HttpParams()
            .set('text', searchText);
        return this.http.get<any[]>(this.autocompleteUrl, { params: params });
    }


    getToolTip(ticker: string): Observable<any> {
        let params = new HttpParams();
        params = new HttpParams().set('ticker', ticker);
        return this.http.get<any[]>(this.integratedBaseUrl + "models/" + ticker + '/tooltip');
    }

    GetAdvancedSearch(searchParams: any[]) {
        return this.http.post<any[]>(this.baseUrl + 'getSearchResults', searchParams);
    }
    GetAdvancedSearchResult(AdvSearchformData: any): Observable<any[]>  {
    // return this.http.post<any[]>(this.integratedBaseUrl + 'Beehive/getAdvanceSearchResults', AdvSearchformData);        
            let headers = new HttpHeaders();
            return this.http.post<any>(this.integratedBaseUrl + 'Beehive/getAdvanceSearchResults', AdvSearchformData, { headers: headers, reportProgress: true });        
    }
    GetAdvancedSearchCount(searchParams: any[],Style:string,UserId: string) {
        let params = new HttpParams();        
        params = params.append('style', Style);
        params = params.append('userId', UserId);
        return this.http.post<any[]>(this.baseUrl + 'getResearch', searchParams, { params: params });
    }
     

    GetMetaDataFields(field: string, style: number) {
        let params = new HttpParams()
            .set('list', field)
            .set('style', style ? style.toString() : "");
        return this.http.get<any[]>(this.baseUrl + "getPickList", { params });
    }

    GetSavedQuery(user: string) {
        let params = new HttpParams()
            .set('userId', user);
        return this.http.get<any[]>(this.baseUrl + "getSavedSearch", { params });
    }

    SaveQuery(query: any) {
        return this.http.post<any>(this.baseUrl + "saveSavedSearch", query);
    }
    UpdateQuery(query: any) {
        return this.http.post<any>(this.baseUrl + "updateSavedSearch", query);
    }
    DeleteQuery(query: any) {
        return this.http.post<any>(this.baseUrl + "deleteSavedSearch", query);
    }
    getIndustries(): Observable<any[]> {
        return this.http.get<any[]>(this.integratedBaseUrl + "industries");
    }

    getIndustry(industryID: number): Observable<any[]> {
        let params = new HttpParams(), industry: Observable<any[]>, sectors: Observable<any[]>;
        params = new HttpParams().set('list', 'industry').set('style', '1');
        industry = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });
        params = new HttpParams().set('list', 'sector').set('style', '1');
        sectors = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });
        let industryData = this.http.get<any[]>(this.integratedBaseUrl + "industries/" + industryID);
        return forkJoin([industry, sectors, industryData]).pipe(map((data: any) => {
            return data;
        }));
    }

    saveIndustry(Content: any, industryId: any): Observable<any> {
        let headers = new HttpHeaders();
        headers.set('Content-Type', 'application/json').set('Accept', 'application/json');
        if (industryId === -1)
            return this.http.post<any>(this.integratedBaseUrl + "industries", Content, { headers: headers });
        else
            return this.http.put<any>(this.integratedBaseUrl + "industries/" + industryId, Content, { headers: headers })
    }

    getProductGroups(): Observable<any[]> {
        return this.http.get<any[]>(this.integratedBaseUrl + "productgroups");
    }

    getProductGroupData(productGroupId: number): Observable<any> {
        let params = new HttpParams();
        let author: Observable<any[]>, type: Observable<any[]>, industry: Observable<any[]>, tickers: Observable<any[]> = undefined;
        params = new HttpParams().set('list', 'type').set('style', "1");
        type = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });
        params = new HttpParams().set('list', 'industry').set('style', '1');
        industry = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });
        params = new HttpParams().set('list', 'ticker').set('style', '1');
        tickers = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });
        params = new HttpParams().set('list', 'author').set('style', '1');
        author = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });
        let productGroupIDData = this.http.get<any[]>(this.integratedBaseUrl + "productgroups/" + productGroupId);
        return forkJoin([type, industry, tickers, author, productGroupIDData]).pipe(map((data: any) => {
            return data;
        }));
    }

    IsInRole1(roleId: any): Observable<any> {
        let params = new HttpParams()
            .set('text', roleId);
        return this.http.get<any[]>(this.baseUrl + "IsInRole", { params: params, withCredentials: true });
    }

    IsInRole(roleId: any):Observable<any> {   
        var roles = this.cookiesService.GetRoleList();    
        if (roles != undefined && roles !=null && roles !="")
        {
        this.isInRoleReturn= ((roles.split(',').indexOf('1') >= 0)|| (roles.split(',').indexOf(roleId.toString()) >= 0) )  ? true : false;               
        }
        return  of(this.isInRoleReturn);
    }


    saveProductGroups(Content: any, productGroupID: any): Observable<any> {
        let headers = new HttpHeaders();
        headers.set('Content-Type', 'application/json').set('Accept', 'application/json');
        if (productGroupID === -1)
            return this.http.post<any>(this.integratedBaseUrl + "productgroups", Content, { headers: headers, withCredentials: true });
        else
            return this.http.put<any>(this.integratedBaseUrl + "productgroups/" + productGroupID, Content, { headers: headers, withCredentials: true });
    }

    getContentUsage(): Observable<any[]> {
        return this.http.get<any[]>(this.baseUrl + 'getContentUsage');
    }

    getContentUsageFilters(): Observable<any[]> {
        return this.http.get<any[]>(this.baseUrl + 'getContentUsageFilters');
    }

    getSecurities(): Observable<any[]> {
        return this.http.get<any[]>(this.integratedBaseUrl + "securities");
    }

    getSecurity(securityID: number): Observable<any[]> {
        let params = new HttpParams();
        let securities: Observable<any[]>, companies: Observable<any[]>, exchanges: Observable<any[]>,
            currencies: Observable<any[]>, indexes: Observable<any[]>, countries: Observable<any[]>, regions: Observable<any[]>, gics: Observable<any[]> = undefined;

        params = new HttpParams().set('list', 'SecurityScreen').set('style', '3');
        securities = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });

        params = new HttpParams().set('list', 'company').set('style', '1');
        companies = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });

        params = new HttpParams().set('list', 'exchange').set('style', '');
        exchanges = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });

        params = new HttpParams().set('list', 'currency').set('style', '');
        currencies = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });

        params = new HttpParams().set('list', 'index').set('style', '');
        indexes = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });

        params = new HttpParams().set('list', 'country').set('style', '');
        countries = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });

        params = new HttpParams().set('list', 'region').set('style', '');
        regions = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });

        params = new HttpParams().set('list', 'gics').set('style', '');
        gics = this.http.get<any[]>(this.baseUrl + "GetPickList", { params });

        let securityData = this.http.get<any[]>(this.integratedBaseUrl + "securities/" + securityID);
        return forkJoin([securities, companies, exchanges, currencies, indexes, countries, regions, gics, securityData]).pipe(map((data: any) => {
            return data;
        }));
    }

    getSecurityScreenPickLists(securityID: number): Observable<any[]> {
        let params = new HttpParams();
        params = new HttpParams().set('list', 'SecurityScreen').set('style', '1');
        return this.http.get<any[]>(this.baseUrl + "GetPickList" , {params});
    }
    getCompanyDetailsBySecurity(securityID: number): Observable<any[]> {
        return this.http.get<any[]>(this.integratedBaseUrl + "securities/" + securityID);
    }


    getCompanySecurities(companyId: number): Observable<any[]> {
        return this.http.get<any[]>(this.integratedBaseUrl + "securities/CompanyDetails/" + companyId);
    }

    saveSecurity(Content: any, securityId: any): Observable<any> {
        let headers = new HttpHeaders();
        headers.set('Content-Type', 'application/json').set('Accept', 'application/json');
        if (securityId === -1)
            return this.http.post<any>(this.integratedBaseUrl + "securities", Content, { headers: headers });
        else
            return this.http.put<any>(this.integratedBaseUrl + "securities/" + securityId, Content, { headers: headers });
    }

    getChartData(ticker: string, type: string, securityid: number, duration: string) {

        let params = new HttpParams();
        params = params.append('duration', duration);
        params = params.append('Ticker', ticker.toString());
        params = params.append('securityid', securityid.toString());
        return this.http.get(this.baseUrl + 'getChartData', { params: params });
    }
    saveTickers(Tickers: any) {
        this.tickers = Tickers;
    }
    getTickers(): any {
        return this.tickers;
    }
    getChartsImage(id: number, ticker: string, type: string): Observable<Blob> {
        let params = new HttpParams();
        params = params.append('securityid', id.toString());
        params = params.append('ticker', ticker);
        params = params.append('type', type);
        return this.http.get(this.baseUrl + 'GetChartsImage', { params: params, responseType: 'blob' });
    }

    executeBatchJob() {
        return this.http.get(this.baseUrl + 'executeBatchJob');
    }

    getClientIPAddress(): Observable<any> {
        return this.http.get(this.baseUrl + 'GetIPAddress');
    }

    getEmailBody(research: string, id: string): Observable<any> {
        let params = new HttpParams();
        params = params.append('type', research);
        params = params.append('id', id);
        if (id.indexOf(',') < 0)
            return this.http.get(this.baseUrl + 'gethtmlemail', { params: params, responseType: 'text' });
        else if (id.indexOf(',') > 0) {
            let payload = {
                type: research,
                id: id
            }
            let headers = new HttpHeaders();
            headers.set('Content-Type', 'application/json').set('Accept', 'application/json');
            return this.http.post<any>(this.baseUrl + 'gethtmlemail/', payload, { headers: headers });
        }
    }

    getDistributionList(userID: string): Observable<any> {
        let params = new HttpParams();
        params = params.append('userId', userID);
        return this.http.get(this.baseUrl + 'getDistributionList', { params: params });
    }

    queueEmail(payload: any): Observable<any> {
        let headers = new HttpHeaders();
        headers.set('Content-Type', 'application/json').set('Accept', 'application/json');
        return this.http.post<any>(this.baseUrl + 'queueEmail/', payload, { headers: headers });
    }

    saveCart(payload: any): Observable<any> {
        let headers = new HttpHeaders();
        headers.set('Content-Type', 'application/json').set('Accept', 'application/json');
        return this.http.post<any>(this.baseUrl + 'saveCart/', payload, { headers: headers });
    }

    getCart(userID: string): Observable<any> {
        let params = new HttpParams();
        params = params.append('userId', userID)
        return this.http.get(this.baseUrl + 'getCart', { params: params });
    }

    deleteCart(userID: string): Observable<any> {
        let params = new HttpParams();
        params = params.append('userId', userID)
        return this.http.get(this.baseUrl + 'deleteCart', { params: params });
    }

    impersonate(fileNames: string, userID: string): Observable<any> {
        let params = new HttpParams();
        params = params.append('fileNames', fileNames);
        params = params.append('userID', userID);
        return this.http.get(this.baseUrl + 'impersonate', { params: params, responseType: 'text' });
    }

    modelsHistory(ticker: string): Observable<any[]> {
        let params = new HttpParams()
            .set('ticker', ticker)
        return this.http.get<any[]>(this.integratedBaseUrl + "models/modelsHistory", { params: params });
    }

    deleteModel(ModelId: string, UserID: string): Observable<any> {
        let data = ModelId + ',' + UserID;
        let params = new HttpParams()
            .set('id', ModelId)
            .set('UserID', UserID);
        return this.http.delete<any>(this.integratedBaseUrl + "models", { params: params });
    }

    getDatabaseLogs(productGroupID: string): Observable<any[]> {
        let params = new HttpParams()
            .set('productGroupId', productGroupID)
        return this.http.get<any[]>(this.integratedBaseUrl + "productgroups/delta", { params: params });
    }

    getDecks(): Observable<any[]> {
        return this.http.get<any[]>(this.integratedBaseUrl + "decks");
    }

    getAnalyst(): Observable<any[]> {
        let params = new HttpParams().set('list', 'author').set('style', '2');
        return this.http.get<any[]>(this.baseUrl + "GetPickList", { params });
    }

    uploadDecks(formData: any): Observable<any[]> {
        let headers = new HttpHeaders();
        headers.set('Content-Type', 'application/json').set('Accept', 'application/json');
        return this.http.post<any>(this.integratedBaseUrl + 'Decks/UploadDecks', formData, { headers: headers, reportProgress: true });
    }

    expireDecks(deckID: string, editorID: string): Observable<any> {
        let params = new HttpParams().set('DeckId', deckID.toString()).set('EditorId', editorID);
        return this.http.delete<any>(this.integratedBaseUrl + 'Decks/Expire', { params });
    }

    public downloadDecks(deckID: string): Observable<Blob> {
        let params = new HttpParams();
        params = params.append('deckID', deckID.toString());
        return this.http.get(this.integratedBaseUrl + 'Decks/DownloadDecks', { params: params, responseType: 'blob' }).pipe(
            catchError(this.handleException)
        );
    }

    handleException(error: HttpErrorResponse) {
        window.alert('Unable to Download, Please try Uploading the Asset, before Downloaing in case not uploaded earlier. Otherwise please contact System Admin');
        return throwError(error);
    }

    getResearchReadsData(analystid: string, startDate: string, endDate: string): Observable<any[]> {
        let researchReads: Observable<any[]>, _isInRole: Observable<boolean>,researchReadsDetailsKey: Observable<boolean>;
        let params = new HttpParams().set('analystId', analystid.toString()).set('startDate', startDate).set('endDate', endDate);
        researchReads = this.http.get<any[]>(this.baseUrl + "getResearchStats/", { params });
        this.IsInRole(Role.deManager).subscribe(
          val=>_isInRole=of(val)
        );
       
        //researchReadsDetailsKey = this.http.get<boolean>(this.baseUrl + "researchReadsDetailsKey");
        // return forkJoin([researchReads, isInRole, researchReadsDetailsKey]).pipe(map((data: any) => {
        //     return data;
        // }));
        return forkJoin([researchReads, _isInRole]).pipe(map((data: any) => {
            return data;
        }));
    }

    getAssets(UserId: string): Observable<any[]> {
        let params = new HttpParams().set('userId', UserId.toString())
        return this.http.get<any[]>(this.integratedBaseUrl + "assets/getassets/", { params });
    }

    getAssetsFormData(UserId: string): Observable<any[]> {
        let assetTypes: Observable<any[]>; let assetOwners: Observable<any[]>;
        assetTypes = this.http.get<any[]>(this.integratedBaseUrl + "Assets/GetAssetTypes/");
        let params = new HttpParams().set('userId', UserId.toString());
        assetOwners = this.http.get<any[]>(this.integratedBaseUrl + "Assets/GetAssetOwners/", { params });
        return forkJoin([assetTypes, assetOwners]).pipe(map((data: any) => {
            return data;
        }));
    }

    
    SearchAdvanceResearch(formData: any): Observable<any[]> {
        let headers = new HttpHeaders();
        return this.http.post<any>(this.integratedBaseUrl + 'Beehive/searchResearchQuery/', formData, { headers: headers, reportProgress: true });
    }

    expireAsset(assetId: string, UserId: string): Observable<any> {
        let params = new HttpParams().set('assetId', assetId.toString()).set('userId', UserId);
        return this.http.delete<any>(this.integratedBaseUrl + 'Assets/expireAsset', { params });
    }

    getAsset(AssetId: string): Observable<any> {
        let params = new HttpParams().set('assetId', AssetId.toString());
        return this.http.get<any>(this.integratedBaseUrl + 'Assets/GetAsset', { params });
    }

    downloadAsset(AssetId: string, AssetTypeId: string): Observable<Blob> {
        let params = new HttpParams();
        params = params.append('AssetId', AssetId.toString()).append('AssetTypeId', AssetTypeId.toString());
        return this.http.get(this.integratedBaseUrl + 'Assets/DownloadAsset', { params: params, responseType: 'blob' }).pipe(
            catchError(this.handleException)
        );
    }

    getAssetHistory(linkId: string): Observable<any> {
        let params = new HttpParams().set('linkId', linkId.toString());
        return this.http.get<any>(this.integratedBaseUrl + 'Assets/GetAssetHistory/', { params });
    }

    uploadAsset(formData: any): Observable<any[]> {
        let headers = new HttpHeaders();
        return this.http.post<any>(this.integratedBaseUrl + 'Assets/SaveAsset/', formData, { headers: headers, reportProgress: true });
    }

    getModelDownloadsData(dept: string, startDate: string, endDate: string): Observable<any[]> {
        let researchReads: Observable<any[]>, _isInRole: Observable<boolean>;
        let params = new HttpParams().set('dept', dept.toString()).set('startDate', startDate).set('endDate', endDate);
        researchReads = this.http.get<any[]>(this.baseUrl + "getModelStats/", { params });
        this.IsInRole(Role.deManager).subscribe(
            val=>_isInRole=of(val)
          );
        return forkJoin([researchReads, _isInRole]).pipe(map((data: any) => {
            return data;
        }));
    }

    getUsage(type: string, startDate: string, endDate: string): Observable<any[]> {
        let getUsageData: Observable<any[]>, typeData: Observable<string>;
        let params = new HttpParams().set('type', type.toString()).set('startDate', startDate.toString()).set('endDate', endDate.toString());
        getUsageData= this.http.get<any[]>(this.baseUrl + 'getUsage/', { params });
         
        return getUsageData;
    }

    resetExpire(assetId: string, ExpiryDays: string): Observable<any[]> {
        let params = new HttpParams().set('AssetId', assetId.toString()).set('ExpiryDays', ExpiryDays.toString());
        return this.http.delete<any>(this.integratedBaseUrl + 'Assets/resetExpire', { params });
    }

    getResearchCoverage(userID:any):Observable<any[]> {
        let params = new HttpParams().set('userId',userID.toString());
        return this.http.get<any>(this.integratedBaseUrl + 'Beehive/GetResearchCoverage',{params});
    }
    getResearchCoverageDetails(securityID:any):Observable<any[]>{
        let params = new HttpParams().set('securityId', securityID.toString());
        return this.http.get<any>(this.integratedBaseUrl + 'Beehive/GetResearchCoverageDetail', { params });
    }

    getFacebookNames():Observable<any[]>{
        return this.http.get<any>(this.integratedBaseUrl + 'Beehive/GetFacebookNames');
    }
    
    getDistributionSites():Observable<any[]>{
        return this.http.get<any>(this.integratedBaseUrl + 'Beehive/GetDistributionSites');
    }
    
    getAdvanceResearchData(): Observable<any[]> {         
        let AdvResearchData: Observable<any[]>;  
        AdvResearchData = this.http.get<any[]>(this.integratedBaseUrl + "Beehive/GetPickLists/");
        return forkJoin([ AdvResearchData]).pipe(map((data: any) => {
            return data;
        }));
    }
    getAdvanceResearchDataList(field: string, style: number): Observable<any[]> {    
        let params = new HttpParams()
            .set('list', field)
            .set('style', style ? style.toString() : "");
         return this.http.get<any[]>(this.baseUrl + "getPickList", { params });   
    }
    getAdvanceTickerList(Style: string): Observable<any[]> {     
        let TickerList: Observable<any[]>;  
        let params = new HttpParams();        
        params = params.append('style', Style);
        // TickerList= this.http.get<any[]>(this.baseUrl + "GetTickerList", { params });
        // return TickerList;
        TickerList = this.http.get<any[]>(this.integratedBaseUrl + "Beehive/GetTickerList/", { params: params });
        return forkJoin([ TickerList]).pipe(map((data: any) => {
            return data;
        }));
    }
    getAdvanceIndustriesList(Style: string): Observable<any[]> {      
        let IndustriesList: Observable<any[]>;  
        let params = new HttpParams();        
        params = params.append('style', Style);
        IndustriesList = this.http.get<any[]>(this.integratedBaseUrl + "Beehive/GetIndustriesList/", { params: params });
        return forkJoin([ IndustriesList]).pipe(map((data: any) => {
            return data;
        }));
    }
    getAdvanceAnalystsList(Style: string): Observable<any[]> {      
        let AnalystsList: Observable<any[]>;  
        let params = new HttpParams();        
        params = params.append('Style', Style);
        AnalystsList = this.http.get<any[]>(this.integratedBaseUrl + "Beehive/GetAnalystsList/", { params: params });
        return forkJoin([ AnalystsList]).pipe(map((data: any) => {
            return data;
        }));
    }

    getChangeFeedEvents(startDate:string,endDate:string): Observable<any> {
        let params = new HttpParams()
            .set('fromDate', startDate)
            .set('toDate', endDate);
         //return this.http.get<any[]>(this.baseUrl + "getPickList", { params }); 
        return this.http.get<any>(this.integratedBaseUrl + 'BlueMatrix/ChangeFeedEvents',{params});
    }
    getChangeFeedXml(changeEvent:any): Observable<any> {
        let HTTPOptions:Object = {  
            headers: new HttpHeaders()  
              .set('Content-Type', 'application/json')  
              .append('Access-Control-Allow-Methods', 'GET')  
              .append('Access-Control-Allow-Origin', '*')  
              .append('Access-Control-Allow-Headers', "Access-Control-Allow-Headers, Access-Control-Allow-Origin, Access-Control-Request-Method"),  
            responseType: 'text'  
          };
        return this.http.post<any>(this.integratedBaseUrl + 'BlueMatrix/ChangeFeedXml', JSON.stringify(changeEvent),HTTPOptions);
    }
    getMeetingReplays(): Observable<any[]> {
        return this.http.get<any[]>(this.integratedBaseUrl + "Beehive/GetMeetingReplays");
    }
    getMeetingReplaysHistorial(MeetingName: string): Observable<any[]> {
        let params = new HttpParams()
            .set('MeetingName', MeetingName)
        return this.http.get<any[]>(this.integratedBaseUrl + "beehive/GetMeetingReplaysHistorial", { params: params });
    }
    updateChangeFeedEventStatus(eventId:number,status:any): Observable<any> {
        let params = new HttpParams()
            .set('eventId', eventId.toString())
            .set('status', status);
        return this.http.get<any>(this.integratedBaseUrl + "BlueMatrix/UpdateChangeFeedStatus",{params:params});
    }
}