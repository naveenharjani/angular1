import { Injectable } from "@angular/core";
import { CookieService } from 'ngx-cookie';
import { BehaviorSubject } from "rxjs";
import { CookieOptions } from 'ngx-cookie';

@Injectable()
export class BeehiveCookiesService {
    constructor(private cookieService: CookieService) {

    }

    defaultOption: CookieOptions = {
        storeUnencoded: true,
        path: '/'
    };

    Cart$: BehaviorSubject<string[]> = new BehaviorSubject([]);




    GetCartSubject(): BehaviorSubject<string[]> {
        if (this.Cart$.getValue().length == 0) {
            this.Cart$.next(this.GetCartItems());
        }

        return this.Cart$;
    }

    GetCartItems(): string[] {
        let cookies = this.cookieService.get("CART");

        if (cookies && cookies != "empty")
            return cookies.split('|');
        else
            return [];
    }

    UpdateCart() {
        this.Cart$.next(this.GetCartItems());
    }
    AddCartItem(fileName: string) {

        if (this.Cart$.value.indexOf(fileName) < 0) {
            let cart = this.GetCartItems();
            cart.push(fileName);

            let cartString = this.GetCartString(cart);

            this.cookieService.put('DECART', cartString, this.defaultOption);
            this.Cart$.next(cart);
        }

    }
    RemoveCartItem(fileName: string) {
        let cookies = this.GetCartItems();
        let index = cookies.indexOf(fileName);

        if (index >= 0)
            cookies.splice(index, 1);

        let cookiesString = this.GetCartString(cookies);

        this.cookieService.put('DECART', cookiesString, this.defaultOption);
        this.Cart$.next(cookies);
    }

    GetCartString(cookies: string[]): string {
        let toString = cookies.join('|');
        return toString;
    }

    GetLoggedInUser(): string {
        let UserName = this.cookieService.get("NTAccount");
        if (UserName == '' || UserName == null || UserName == undefined) {
            UserName = this.cookieService.get("ApplicationUserName");
            this.cookieService.put('NTAccount', UserName);
        }
        return this.cookieService.get("NTAccount");
    }

    GetRoleList(): string {
        return this.cookieService.get("RolesList") //? this.cookieService.get("RolesList") : '1';
    }

    GetLoggedTimeStamp(): string {
        return this.cookieService.get("TimeStamp");
    }

    GetUserID(): string {
        return this.cookieService.get("UserID") //? this.cookieService.get("UserID") : '2849';
    }

    GetFranchiseList(): string {
        //this.cookieService.put('FranchiseList', '804,823,521');
        return this.cookieService.get("FranchiseList");
    }

    GetSelectedRows(): string {
        let cookiesString = this.cookieService.get('DECART');
        let cookiesStringArray = cookiesString && cookiesString.split('|');
        let selectedIDs = '';
        cookiesStringArray && cookiesStringArray.forEach((element) => {
            selectedIDs = selectedIDs + element.split('$')[1] + ','
        });
        return selectedIDs.substring(0, selectedIDs.length - 1).trim();
    }

    SetJwtTokenCookies(currentUser: any) {  
       console.log(currentUser); 
        console.log(JSON.parse(currentUser));   

        this.cookieService.put("JwtToken",JSON.parse(currentUser).JwtToken);
        this.cookieService.put("RefreshToken",JSON.parse(currentUser).RefreshToken);                
        this.cookieService.put("JwtExpiryTime",JSON.parse(currentUser).ExpiryTime.toString());
       
                                
       // this.cookieService.put("JwtCurrentUser",JSON.stringify(currentUser));               
    }

}