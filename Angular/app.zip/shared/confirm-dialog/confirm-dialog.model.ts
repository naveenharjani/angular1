export class ConfirmDialogModel {

    constructor(public title: string, public message: string,public messageFront:string,
        public messageRear:string,public messageParam:string) {
    }
}
