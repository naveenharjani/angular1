import { NgModule } from '@angular/core';
import { MatButtonModule, MatDialogModule } from '@angular/material';
import { ConfirmDialogComponent } from './confirm-dialog.component';

@NgModule({
    declarations: [ConfirmDialogComponent],
    imports: [
        MatButtonModule, MatDialogModule
    ],
    exports: [
        MatButtonModule, MatDialogModule, ConfirmDialogComponent
    ],
    bootstrap: [ConfirmDialogComponent]
})
export class ConfirmDialogModule {
}