export interface ColumnProperties {
    headerName: string;
    field: string;
    width?: number;
    sortable?: boolean;
    resizable?: boolean;
    dataType?: string;
    suppressMenu?: boolean;
    cellRendererFramework?: any;
}


export interface RowProperties{
    [key: string] : any
}

