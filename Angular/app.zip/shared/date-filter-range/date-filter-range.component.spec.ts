import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DateFilterRangeComponent } from './date-filter-range.component';

describe('DateFilterRangeComponent', () => {
  let component: DateFilterRangeComponent;
  let fixture: ComponentFixture<DateFilterRangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DateFilterRangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DateFilterRangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
