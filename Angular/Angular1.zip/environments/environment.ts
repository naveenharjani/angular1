export const environment = {
  production: false,
  app: "Beehive",
  integratedBaseUrl: '/api/',
  baseUrl: '/api/beehive/',
  autoCompleteUrl: '/api/beehiveapi/getSearchAutocomplete',
  gridUrl: 'http://api1-dr.beehive.com/api/beehive/',
  cartAttachmentsUrl: 'http://institutional-dev.beehive.com/files/tmp/cart/',
  bernsteinLogo: '/assets/bernstein_logo.png',
  tickerSearchUrl: '../research/researchresults.html?ticker.name={0}',
  analystSearchUrl: '../research/researchresults.html?author.name={0}',
  freeTextSearchUrl: '../research/researchresults.html?Text={0}',
  financialsSearchUrl: '../research/estimates.aspx?analystid=-1&ticker={0}&max=1000',
  chartSearchUrl: '../charts/PriceCharts.aspx$?type=threeyrpricechart&ticker={0}',
  modelSearchUrl: '../research/models.aspx?analystid=&ticker={0}',
  cartUrl: '/html/index.html#/cart',
  textSearchEnabled: true,
  showTypeaheadContent: true,
  AssetsConfirmMessage: "Are you sure?",
  AssetsExpiryDays: '90',
  AssetsValidationMessage: 'Please fill the required fields',
  SiteUrl: 'http://institutional-poc.beehive.com/',
  DownloadsFromDays: 5,
  UsageFromDays: 2,
  researchscreen: [
    {
        ControlName: "Tickers",
        PropName: "ticker.id"
    },
    {
        ControlName: "Industries",
        PropName: "industry.id"
    },
    {
        ControlName: "Analysts",
        PropName: "author.id"
    },
    {
        ControlName: "Authors",
        PropName: "author.id"
    },
    {
        ControlName: "Type",
        PropName: "typeId"
    },
    {
        ControlName: "SubType",
        PropName: "subType"
    },
    {
        ControlName: "Keyword",
        PropName: "keyword.id"
    },
    {
        ControlName: "Investorthemes",
        PropName: "ticker.Investorthemes"
    },
    {
        ControlName: "Thematictag",
        PropName: "ticker.Thematictag"
    },
    {
        ControlName: "Coverageaction",
        PropName: "ticker.coverageAction"
    },
    {
        ControlName: "Ratingaction",
        PropName: "ticker.ratingAction"
    },
    {
        ControlName: "Targetpriceaction",
        PropName: "ticker.targetPriceAction"
    },
    {
        ControlName: "Estimateaction",
        PropName: "ticker.estimateAction"
    },
    {
        ControlName: "Since",
        PropName: "since"
    },
    {
        ControlName: "Until",
        PropName: "until"
    },
    {
        ControlName: "Text",
        PropName: "text"
    },
    {
        ControlName: "PUBNO",
        PropName: "pubno"
    }
    ],
  advancedSearchFields: [
    {
    FieldName: "Tickers",
    FieldValue: "ticker.id",
    FormType: "Dropdown",
    FormPosition: "Main",
    ControlName: "Tickers"
    },
    {
    FieldName: "Industries",
    FieldValue: "industry.id",
    FormType: "Dropdown",
    FormPosition: "Main",
    ControlName: "Industries"
    },
    {
    FieldName: "Analysts",
    FieldValue: "analyst.id",
    FormType: "Dropdown",
    FormPosition: "Main",
    ControlName: "Analysts"
    },
    {
    FieldName: "Type",
    FieldValue: "typeId",
    FormType: "Dropdown",
    FormPosition: "Rest",
    ControlName: "Type"
    },

    {
    FieldName: "SubType",
    FieldValue: "subType",
    FormType: "Dropdown",
    FormPosition: "Rest",
    ControlName: "SubType"
    },
    {
    FieldName: "Keyword",
    FieldValue: "keyword.id",
    FormType: "Dropdown",
    FormPosition: "Rest",
    ControlName: "Keyword"
    },
    {
    FieldName: "Investor Theme",
    FieldValue: "investorTheme.id",
    FormType: "Dropdown",
    FormPosition: "Rest",
    ControlName: "Investorthemes"
    },
    {
    FieldName: "Thematic Tags",
    FieldValue: "thematicTagId",
    FormType: "Dropdown",
    FormPosition: "Rest",
    ControlName: "Thematictag"
    },
    {
    FieldName: "Coverage Action",
    FieldValue: "ticker.coverageAction",
    FormType: "Dropdown",
    FormPosition: "Rest",
    ControlName: "Coverageaction"
    },
    {
    FieldName: "Rating Action",
    FieldValue: "ticker.ratingAction",
    FormType: "Dropdown",
    FormPosition: "Rest",
    ControlName: "Ratingaction"
    },
    {
    FieldName: "Target Price Action",
    FieldValue: "ticker.targetPriceAction",
    FormType: "Dropdown",
    FormPosition: "Rest",
    ControlName: "Targetpriceaction"
    },
    {
    FieldName: "Estimate Action",
    FieldValue: "ticker.estimateAction",
    FormType: "Dropdown",
    FormPosition: "Rest",
    ControlName: "Estimateaction"
    },
    {
    FieldName: "Since",
    FieldValue: "since",
    FormType: "Date",
    FormPosition: "Main",
    ControlName: ""
    },
    {
    FieldName: "Until",
    FieldValue: "until",
    FormType: "Date",
    FormPosition: "Rest",
    ControlName: ""
    },
    {
    FieldName: "Title",
    FieldValue: "title",
    FormType: "Text",
    FormPosition: "Rest",
    ControlName: ""
    },
    {
    FieldName: 'Text',
    FieldValue: "text",
    FormType: "Text",
    FormPosition: "Main1",
    ControlName: ""
    },
    {
    FieldName: 'PubNo',
    FieldValue: "pubno",
    FormType: "Text",
    FormPosition: "Rest",
    ControlName: ""
    }
      ],

  menuItems: [
    {
      Id: 1,
      Label: 'HOME',
      url: '/research/default.asp'
    },
    {
      Id: 2,
      Label: 'RESEARCH',
      Url: '/research/research.asp'
    },
    {
      Id: 3,
      Label: 'FINANCIALS',
      Url: '/research/research.asp'
    },
    {
      Id: 4,
      Label: 'MODELS',
      Url: '/research/models.aspx'
    },
    {
      Id: 5,
      Label: 'DISCLOSURES',
      Url: '/disclosures/menu.asp'
    },
    {
      Id: 6,
      Label: 'POC',
      Url: '#',
      SubMenu:
        [{
          Id: 1,
          Label: 'CHARTS',
          Url: '/charts/PriceCharts.aspx'
        }]
    }
  ],

  gridFilters: [
    {
      "Display": "Content Usage (CRM)",
      "Value": "_contentusage"
    },
    {
      "Display": "Web Usage (CRM)",
      "Value": "_webusage"
    },
    {
      "Display": "Quota (CRM)",
      "Value": "_quota"
    },
    {
      "Display": "Trending Readership (CRM)",
      "Value": "_trending_readership"
    },
    {
      "Display": "Bernstein Reads (CRM)",
      "Value": "_bernsteinreads"
    },
    {
      "Display": "Portal Clicks by Account (CRM)",
      "Value": "_portalclicksCRM"
    },
    {
      "Display": "Authors",
      "Value": "authors"
    },
    {
      "Display": "Securities",
      "Value": "securities"
    },
    {
      "Display": "Coverage",
      "Value": "coverage"
    },
    {
      "Display": "Product Groups",
      "Value": "productgroups"
    },
    {
      "Display": "Distribution Sites",
      "Value": "distributionsites"
    },
    {
      "Display": "Portal Clicks (by email domain)",
      "Value": "portalclicks"
    },
    {
      "Display": "Portal Clicks (by account)",
      "Value": "portalclicks2"
    },
    {
      "Display": "Top Portal Contacts",
      "Value": "topportalcontacts"
    },
    {
      "Display": "Portal Embargo",
      "Value": "portalembargo"
    },
    {
      "Display": "Portal Load Log",
      "Value": "portalloadlog"
    },
    {
      "Display": "File Processing Log",
      "Value": "fileprocessinglog"
    }
  ]
  ,applicationId:"beehive"
  ,secretKey:"aaa111"
  ,menuLocation:"/angular-dist/menu.html"

};

